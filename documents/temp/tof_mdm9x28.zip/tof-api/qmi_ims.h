#ifndef QMI_IMS_H
#define QMI_IMS_H

/******************************************************************************
  @file    qmi_ims.h
  @brief   QMI IMS header

  $Id$

  DESCRIPTION

  INITIALIZATION AND SEQUENCING REQUIREMENTS

  ---------------------------------------------------------------------------
  Copyright (c) 2013 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/

#include "qmi_ims_srvc.h"
#include "TOF_API.h"

//chad_20160602 start>>>
typedef enum
{
  REQUEST_SESSION_TIMER             = 0,
  REQUEST_MIN_TIMER               = 1,
  REQUEST_AMR_CODEC_MODE_SET  = 2,
  REQUEST_AMR_WB_CODEC_MODE_SET  = 3,
  REQUEST_AMR_PAYLOAD_FORMAT  = 4,
  REQUEST_AMR_WB_PAYLOAD_FORMAT = 5,
  REQUEST_AMR_WB_ENABLE               = 6
} ims_voip_request_type;
//chad_20160602 end <<<


/*===========================================================================
  FUNCTION
===========================================================================*/
extern bool qmi_ims_srvc_init();
extern int qmi_ims_srvc_release();

extern uint8 ril_request_get_ims_reg_info(ims_reg_request_type req_type, RIL_Ims_Reg_Info *ims_info);
extern uint8 ril_request_set_ims_reg_info(ims_reg_request_type req_type, RIL_Ims_Reg_Info ims_info);
extern uint8 ril_request_get_ims_user_info(int request, RIL_Ims_User_Info *ims_info);
extern uint8 ril_request_set_ims_user_info(int request, RIL_Ims_User_Info ims_info);
extern uint8 ril_request_get_ims_sip_info(ims_sip_request_type request, RIL_Ims_Sip_Info *ims_info);
extern uint8 ril_request_set_ims_sip_info(ims_sip_request_type request, RIL_Ims_Sip_Info ims_info);
extern uint8 ril_request_get_amr_wb_enable(boolean *amr_wb_enable);
extern uint8 ril_request_set_amr_wb_enable(boolean amr_wb_enable);
extern uint8 ril_request_get_ims_voip_info(int request, RIL_Ims_Voip_Info *ims_info);
extern uint8 ril_request_set_ims_voip_info(int request, RIL_Ims_Voip_Info ims_info);
extern uint8 ril_request_get_ims_qipcall_info(uint8 *hd_mode);
extern uint8 ril_request_set_ims_qipcall_info(uint8 hd_mode);
extern uint8 ril_request_get_ims_sip_timer_info(RIL_Ims_Sip_Timer_Info *ims_info);
extern uint8 ril_request_set_ims_sip_timer_info(RIL_Ims_Sip_Timer_Info ims_info);

#endif /* QMI_IMS_H */