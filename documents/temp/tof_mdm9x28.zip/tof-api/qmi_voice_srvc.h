//dsji_20130204

/******************************************************************************
  @file    qmi_voice_srvc.h
  @brief   QMI message library VOICE service definitions

  DESCRIPTION
  This file contains common, external header file definitions for QMI
  interface library.

  INITIALIZATION AND SEQUENCING REQUIREMENTS
  qmi_voice_srvc_init_client() must be called to create one or more clients
  tof_qmi_voice_srvc_release_client() must be called to delete each client when
  finished.

  $Header: //source/qcom/qct/modem/datacommon/qmimsglib/dev/work/inc/qmi_voice_srvc.h#5 $
  $DateTime: 2009/07/15 10:38:12 $
  ---------------------------------------------------------------------------
  Copyright (c) 2013 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/
#ifndef QMI_VOICE_SRVC_H
#define QMI_VOICE_SRVC_H



#include "qmi.h"
#include "voice_service_v02.h"

#include "TOF_Definition.h"



#ifdef __cplusplus
extern "C" {
#endif
	
	
	
/*--------------------------------------------------------------------------- 
  QMI_TYPE_* - for common tlv definition to all qmi services.
---------------------------------------------------------------------------*/                        
#define QMI_TYPE_REQUIRED_PARAMETERS  (0x01)
#define QMI_TYPE_RESULT_CODE          (0x02)
#define QMI_TYPE_EXT_ERROR_INFO       (0xE0)
#define QMI_TYPE_PARTIAL_OPER_FAILURE (0xE1)

/*---------------------------------------------------------------------------
  Major and Minor Version Nos for VOICE
---------------------------------------------------------------------------*/
#define VOICEI_BASE_VER_MAJOR    (2)
#define VOICEI_BASE_VER_MINOR    (1)

#define VOICEI_ADDENDUM_VER_MAJOR  (0)
#define VOICEI_ADDENDUM_VER_MINOR  (0)

#define QMI_VOICE_STD_MSG_SIZE QMI_MAX_STD_MSG_SIZE

/*---------------------------------------------------------------------------
  VOICE Command enum type - not equal to the actual command values!
  mapping is in qmi_voice_cmd_callbacks table

  DO NOT REORDER THIS ENUM!
---------------------------------------------------------------------------*/
typedef enum
{
	VOICEI_CMD_MIN                      = 0,
	VOICEI_CMD_INDICATION_REGISTER      = VOICEI_CMD_MIN,
	VOICEI_CMD_DIAL_CALL,
	VOICEI_CMD_END_CALL,
	VOICEI_CMD_ANSWER_CALL,
	VOICEI_CMD_GET_CALL_INFO,
	VOICEI_CMD_SEND_FLASH,
	VOICEI_CMD_BURST_DTMF,
	VOICEI_CMD_START_CONT_DTMF,
	VOICEI_CMD_STOP_CONT_DTMF,
	VOICEI_CMD_SET_PREFERRED_PRIVACY,
	VOICEI_CMD_SUPS_MNG_CALLS,
	VOICEI_CMD_SUPS_GET_CLIP,
	VOICEI_CMD_SUPS_GET_COLP,
	VOICEI_CMD_SUPS_GET_CALL_WAITING,
	VOICEI_CMD_SUPS_GET_CALL_BARRING,
	VOICEI_CMD_SUPS_SET_CALL_BARRING,
	VOICEI_CMD_GET_CLIR,
	VOICEI_CMD_GET_CALL_FORWARDING,
	VOICEI_CMD_GET_ALL_CALL_INFO ,
	VOICEI_CMD_SUPS_SET_SUPS_SERVICE,
	VOICEI_CMD_SUPS_ORIG_USSD,
	VOICEI_CMD_SUPS_ANSWER_USSD,
	VOICEI_CMD_SUPS_CANCEL_USSD,
	VOICEI_CMD_SET_CONFIG_ITEMS,
	VOICEI_CMD_GET_CONFIG_ITEMS,
	VOICEI_CMD_SUPS_GET_COLR,
	VOICEI_CMD_BIND_SUBSCRIPTION,
	VOICEI_CMD_SUPS_ORIG_USSD_NO_WAIT,
	VOICEI_CMD_ALS_SET_LINE_SWITCHING,
	VOICEI_CMD_ALS_SELECT_LINE,
	VOICEI_CMD_SUPS_MANAGE_IP_CALLS,
	VOICEI_CMD_ALS_GET_LINE_SWITCHING_STATUS,
	VOICEI_CMD_ALS_GET_SELECTED_LINE,
	VOICEI_CMD_SUPS_GET_CNAP,
	VOICEI_CMD_MAX, 
	VOICEI_CMD_WIDTH                    = 0xFFFF          
} qmi_voicei_cmd_e_type;

typedef enum
{
	QMI_VOICE_CM_IF_CMD_INVALID_IND,
	QMI_VOICE_CM_IF_CMD_OTASP_STATUS_IND,
	QMI_VOICE_CM_IF_CMD_INFO_REC_IND,
	QMI_VOICE_CM_IF_CMD_DTMF_IND,
	QMI_VOICE_CM_IF_CMD_PRIVACY_IND,
	QMI_VOICE_CM_IF_CMD_ALL_CALL_STATUS_IND,
	QMI_VOICE_CM_IF_CMD_SUPS_NOTIFICATION_IND,
	QMI_VOICE_CM_IF_CMD_SUPS_USSD_RELEASE_IND,
	QMI_VOICE_CM_IF_CMD_SUPS_USSD_IND,
	QMI_VOICE_CM_IF_CMD_SUPS_ORIG_USSD_NO_WAIT_IND,
	QMI_VOICE_CM_IF_CMD_AOC_LOW_FUNDS_IND,
	QMI_VOICE_CM_IF_CMD_MODIFIED_IND,
	QMI_VOICE_CM_IF_CMD_MODIFY_ACCEPT_IND,
	QMI_VOICE_CM_IF_CMD_SPEECH_CODEC_INFO_IND,
	QMI_VOICE_CM_IF_CMD_HANDOVER_IND,
	QMI_VOICE_CM_IF_CMD_CONFERENCE_INFO_IND,
	QMI_VOICE_CM_IF_CMD_CONFERENCE_JOIN_IND,
	QMI_VOICE_CM_IF_CMD_CONFERENCE_PARTICIPANT_UPDATE_IND,
	QMI_VOICE_CM_IF_CMD_EXT_BRST_INTL_IND,
//20161012 yjoh, add eCall ind
	QMI_VOICE_CM_IF_CMD_ECALL_EVENT_IND
} qmi_voice_indication_id_type;

/* Custom named TLV IDs*/

/*---------------------------------------------------------------------------
  Optional TLVs
---------------------------------------------------------------------------*/
#define VOICEI_IND_REG_DTMF						(0x10)
#define VOICEI_IND_REG_VOICE_PRIV				(0x11)
#define VOICEI_IND_REG_SUPS_NOTIFY				(0x12)
#define VOICEI_IND_REG_CALL_EVENTS_NOTIFY		(0x13)
#define VOICEI_IND_REG_HANDOVER_NOTIFY			(0x14)
#define VOICEI_IND_REG_SPEECH_NOTIFY			(0x15)
#define VOICEI_IND_REG_USSD_NOTIFY				(0x16)
#define VOICEI_IND_REG_SUPS_OTHER_NOTIFY		(0x17)
#define VOICEI_IND_REG_MODIFICATION_NOTIFY		(0x18)
#define VOICEI_IND_REG_UUS_NOTIFY				(0x19)
#define VOICEI_IND_REG_AOC_NOTIFY				(0x1A)
#define VOICEI_IND_REG_CONF_NOTIFY				(0x1B)
#define VOICEI_IND_REG_EXT_BRST_INTL_NOTIFY     (0x1C)
//20161012 yjoh, add eCall ind
#define VOICEI_IND_REG_ECALL_EVENT_NOTIFY     (0x25)

typedef enum
{
	VOICE_IND_REG_MASK_DTMF						= 1,
	VOICE_IND_REG_MASK_VOICE_PRIV				= 2,
	VOICE_IND_REG_MASK_SUPS_NOTIFY				= 4,
	VOICE_IND_REG_MASK_CALL_EVENTS_NOTIFY		= 8,
	VOICE_IND_REG_MASK_HANDOVER_NOTIFY			= 16,
	VOICE_IND_REG_MASK_SPEECH_NOTIFY			= 32,
	VOICE_IND_REG_MASK_USSD_NOTIFY				= 64,
	VOICE_IND_REG_MASK_SUPS_OTHER_NOTIFY		= 128,
	VOICE_IND_REG_MASK_MODIFICATION_NOTIFY		= 256,
	VOICE_IND_REG_MASK_UUS_NOTIFY				= 512,
	VOICE_IND_REG_MASK_AOC_NOTIFY				= 1024,
	VOICE_IND_REG_MASK_CONF_NOTIFY				= 2048,
	VOICE_IND_REG_MASK_EXT_BRST_INTL_NOTIFY		= 4096,
//20161012 yjoh, add eCall ind	
	VOICE_IND_REG_MASK_ECALL_EVENT_NOTIFY		= 8192
} voice_ind_reg_mask;

#define VOICEI_DIAL_CALL_TYPE					(0x10)
#define VOICEI_DIAL_CLIR_TYPE					(0x11)
#define VOICEI_DIAL_UUS_INFO					(0x12)
#define VOICEI_DIAL_CUG							(0x13)
#define VOICEI_DIAL_CALL_ID						(0x10)
#define VOICEI_DIAL_ALPHA_ID					(0x11)
#define VOICEI_DIAL_EMER_CAT					(0x14)
#define VOICEI_DIAL_CALLED_PARTY_SUB_ADDRRESS   (0x15)
#define VOICEI_DIAL_SRV_TYPE					(0x16)
#define VOICEI_DIAL_SIP_URI_OVERFLOW			(0x17)
#define VOICEI_DIAL_AUDIO_ATTRIB				(0x18)
#define VOICEI_DIAL_VIDEO_ATTRIB				(0x19)
#define VOICEI_DIAL_IP_CALL_PI					(0x1A)

#define VOICEI_DIAL_CC_RESULT_TYPE				(0x12)
#define VOICEI_DIAL_CC_RESULT_SUPS				(0x13)
#define VOICEI_DIAL_RESP_END_REASON				(0x14)

#define VOICEI_BURST_DTMF_LEN			(0x10)
#define VOICEI_BURST_DTMF_CALL_ID		(0x10)

#define VOICEI_END_CALL_ID				(0x10)

#define VOICEI_ANSWER_CALL_ID			(0x10)

#define VOICEI_ANSWER_CALL_TYPE			(0x10)
#define VOICEI_ANSWER_AUDIO_ATTRIB		(0x11)
#define VOICEI_ANSWER_VIDEO_ATTRIB		(0x12)
#define VOICEI_ANSWER_IP_CALL_PI		(0x13)

#define VOICEI_GET_CALL_INFO				(0x10)
#define VOICEI_GET_CALL_RP_NUM				(0x11)
#define VOICEI_GET_CALL_SO					(0x12)
#define VOICEI_GET_CALL_VP					(0x13)
#define VOICEI_GET_CALL_OTSP				(0x14)
#define VOICEI_GET_CALL_RP_NAME				(0x15)
#define VOICEI_GET_CALL_UUS_INFO			(0x16)
#define VOICEI_GET_CALL_ALERTING			(0x17)
#define VOICEI_GET_CALL_ALPHA				(0x18)
#define VOICEI_GET_CALL_CONN_NUM_INFO       (0x19)
#define VOICEI_GET_CALL_DIAGNOSTICS			(0x1A)
#define VOICEI_GET_CALL_ALERTING_PATTERN	(0x1B)
#define VOICEI_GET_CALL_AUDIO_ATTRIB		(0x1C)
#define VOICEI_GET_CALL_VIDEO_ATTRIB		(0x1D)

#define VOICEI_SEND_FLASH_CALL_ID			(0x10)

#define VOICEI_START_CONT_DTMF_CALL_ID		(0x10)

#define VOICEI_STOP_CONT_DTMF_CALL_ID		(0x10)

#define VOICEI_DTMF_IND_PW						(0x10)
#define VOICEI_DTMF_IND_DIG_INT					(0x11)

#define VOICEI_ALL_CALL_IND_RP_NUM					(0x10)
#define VOICEI_ALL_CALL_IND_RP_NAME					(0x11)
#define VOICEI_ALL_CALL_IND_ALERTING				(0x12)
#define VOICEI_ALL_CALL_IND_SO						(0x13)
#define VOICEI_ALL_CALL_IND_END_REASON				(0x14)
#define VOICEI_ALL_CALL_IND_ALPHA					(0x15)
#define VOICEI_ALL_CALL_IND_CONNECTED_NUM			(0x16)
#define VOICEI_ALL_CALL_IND_DIAGNOSTICS				(0x17)
#define VOICEI_ALL_CALL_IND_CALLED_PARTY_NUM		(0x18)
#define VOICEI_ALL_CALL_IND_REDIRECTING_PARTY_NUM	(0x19)
#define VOICEI_ALL_CALL_IND_ALERTING_PATTERN		(0x1A)
#define VOICEI_ALL_CALL_IND_AUDIO_ATTRIB			(0x1B)
#define VOICEI_ALL_CALL_IND_VIDEO_ATTRIB			(0x1C)
#define VOICEI_ALL_CALL_IND_IS_SRVCC_CALL     (0x1F)
#define VOICEI_ALL_CALL_IND_ORIG_FAIL_REASON   (0x2A) //hongsg 20140814

#define VOICEI_GET_ALL_CALL_INFO					(0x10)
#define VOICEI_GET_ALL_CALL_RP_NUM					(0x11)
#define VOICEI_GET_ALL_CALL_RP_NAME					(0x12)
#define VOICEI_GET_ALL_CALL_ALERTING				(0x13)
#define VOICEI_GET_ALL_CALL_UUS_INFO				(0x14)
#define VOICEI_GET_ALL_CALL_SO						(0x15)
#define VOICEI_GET_ALL_CALL_OTASP					(0x16)
#define VOICEI_GET_ALL_CALL_VP						(0x17)
#define VOICEI_GET_ALL_CALL_END_REASON				(0x18)
#define VOICEI_GET_ALL_CALL_ALPHA					(0x19)
#define VOICEI_GET_ALL_CALL_CONNECTED_NUM			(0x1A)
#define VOICEI_GET_ALL_CALL_DIAGNOSTICS				(0x1B)
#define VOICEI_GET_ALL_CALL_CALLED_PARTY_NUM		(0x1C)
#define VOICEI_GET_ALL_CALL_REDIRECTING_PARTY_NUM	(0x1D)
#define VOICEI_GET_ALL_CALL_ALERTING_PATTERN		(0x1E)
#define VOICEI_GET_ALL_CALL_AUDIO_ATTRIBUTE			(0x1F)
#define VOICEI_GET_ALL_CALL_VIDEO_ATTRIBUTE			(0x20)
#define VOICEI_GET_ALL_CALL_IS_SRVCC_CALL       (0x23)

#define VOICEI_MNG_CALLS_CALL_ID        (0x10)
#define VOICEI_MNG_CALLS_FAILURE_CAUSE  (0x10)

#define VOICEI_SUPS_NOTIFY_IND_CUG      (0x10)
#define VOICEI_SUPS_NOTIFY_IND_ECT      (0x11)

#define VOICEI_SET_SUPS_SC              (0x10)
#define VOICEI_SET_SUPS_BARR_PWD        (0x11)
#define VOICEI_SET_SUPS_FWD_NUM         (0x12)
#define VOICEI_SET_SUPS_NR_TIMER        (0x13)
#define VOICEI_SET_SUPS_NUM_TYPE_PLAN   (0x14)
#define VOICEI_SET_SUPS_SC_EXT          (0x15)

#define VOICEI_SET_SUPS_FAILURE_CAUSE		(0X10)
#define VOICEI_SET_SUPS_ALPHA_ID			(0X11)
#define VOICEI_SET_SUPS_CC_RESULT_TYPE		(0x12)
#define VOICEI_SET_SUPS_CC_RESULT_CALL_ID	(0X13)
#define VOICEI_SET_SUPS_CC_RESULT_SUPS		(0X14)
#define VOICEI_SET_SUPS_SERVICE_STATUS		(0X15)

#define VOICEI_GET_CW_SC					(0x10)
#define VOICEI_GET_CW_REQ_SC_EXT            (0x11)

#define VOICEI_GET_CW_FAILURE_CAUSE			(0X11)
#define VOICEI_GET_CW_ALPHA_ID				(0X12)
#define VOICEI_GET_CW_CC_RESULT_TYPE		(0x13)
#define VOICEI_GET_CW_CC_RESULT_CALL_ID		(0X14)
#define VOICEI_GET_CW_CC_RESULT_SUPS		(0X15)
#define VOICEI_GET_CW_RESP_SC_EXT			(0x16)

#define VOICEI_GET_CB_SC					(0x10)
#define VOICEI_GET_CB_REQ_SC_EXT            (0X11)

#define VOICEI_GET_CB_FAILURE_CAUSE			(0X11)
#define VOICEI_GET_CB_ALPHA_ID				(0X12)
#define VOICEI_GET_CB_CC_RESULT_TYPE		(0x13)
#define VOICEI_GET_CB_CC_RESULT_CALL_ID		(0X14)
#define VOICEI_GET_CB_CC_RESULT_SUPS		(0X15)
#define VOICEI_GET_CB_RESP_SC_EXT           (0X16)

#define VOICEI_GET_CLIP_RESP				(0x10)
#define VOICEI_GET_CLIP_FAILURE_CAUSE		(0X11)
#define VOICEI_GET_CLIP_ALPHA_ID			(0X12)
#define VOICEI_GET_CLIP_CC_RESULT_TYPE		(0x13)
#define VOICEI_GET_CLIP_CC_RESULT_CALL_ID	(0X14)
#define VOICEI_GET_CLIP_CC_RESULT_SUPS		(0X15)

#define VOICEI_GET_COLP_RESP				(0x10)
#define VOICEI_GET_COLP_FAILURE_CAUSE		(0X11)
#define VOICEI_GET_COLP_ALPHA_ID			(0X12)
#define VOICEI_GET_COLP_CC_RESULT_TYPE		(0x13)
#define VOICEI_GET_COLP_CC_RESULT_CALL_ID	(0X14)
#define VOICEI_GET_COLP_CC_RESULT_SUPS		(0X15)

#define VOICEI_GET_CLIR_RESP				(0x10)
#define VOICEI_GET_CLIR_FAILURE_CAUSE		(0X11)
#define VOICEI_GET_CLIR_ALPHA_ID			(0X12)
#define VOICEI_GET_CLIR_CC_RESULT_TYPE		(0x13)
#define VOICEI_GET_CLIR_CC_RESULT_CALL_ID	(0X14)
#define VOICEI_GET_CLIR_CC_RESULT_SUPS		(0X15)

#define VOICEI_GET_CF_SC					(0x10) //Optional Request TLV
#define VOICEI_GET_CF_REQ_SC_EXT			(0x11) 

#define VOICEI_GET_CF_INFO					(0x10)
#define VOICEI_GET_CF_FAILURE_CAUSE			(0X11)
#define VOICEI_GET_CF_ALPHA_ID				(0X12)
#define VOICEI_GET_CF_CC_RESULT_TYPE		(0x13)
#define VOICEI_GET_CF_CC_RESULT_CALL_ID		(0X14)
#define VOICEI_GET_CF_CC_RESULT_SUPS		(0X15)
#define VOICEI_GET_CF_EXTEN_INFO			(0X16)
#define VOICEI_GET_CF_EXTEN2_INFO			(0X17)

#define VOICEI_GET_ALS_LINE_SWITCH_STATUS   (0x10)

#define VOICEI_GET_ALS_SELECTED_LINE        (0x10)

#define VOICEI_SET_CB_PWD_FAILURE_CAUSE		(0X10)
#define VOICEI_SET_CB_PWD_ALPHA_ID			(0X11)
#define VOICEI_SET_CB_PWD_CC_RESULT_TYPE	(0x12)
#define VOICEI_SET_CB_PWD_CC_RESULT_CALL_ID	(0X13)
#define VOICEI_SET_CB_PWD_CC_RESULT_SUPS	(0X14)

#define VOICEI_ORIG_USSD_FAILURE_CAUSE		(0X10)
#define VOICEI_ORIG_USSD_ALPHA_ID			(0X11)
#define VOICEI_ORIG_USSD_DATA				(0X12)
#define VOICEI_ORIG_USSD_CC_RESULT_TYPE		(0x13)
#define VOICEI_ORIG_USSD_CC_RESULT_CALL_ID  (0X14)
#define VOICEI_ORIG_USSD_CC_RESULT_SUPS     (0X15)
#define VOICEI_ORIG_USSD_DATA_UTF16         (0x16) 

#define VOICEI_USSD_IND_DATA               (0x10)
#define VOICEI_USSD_IND_DATA_UTF16         (0x11)

#define VOICEI_FLASH_PAYLOAD    (0x10)
#define VOICEI_FLASH_TYPE       (0x11)

#define VOICEI_ORIG_USSD_NO_WAIT_ERROR			(0x10)
#define VOICEI_ORIG_USSD_NO_WAIT_FAILURE_CAUSE  (0x11)
#define VOICEI_ORIG_USSD_NO_WAIT_DATA           (0x12)
#define VOICEI_ORIG_USSD_NO_WAIT_ALPHA_ID       (0x13)
#define VOICEI_ORIG_USSD_NO_WAIT_DATA_UTF16		(0x13)

#define VOICEI_MODEM_CONFIG_AUTO_ANSWER		(0x10)
#define VOICEI_MODEM_CONFIG_AIR_TIMER		(0x11)
#define VOICEI_MODEM_CONFIG_ROAM_TIMER		(0x12)
#define VOICEI_MODEM_CONFIG_TTY_MODE		(0x13)
#define VOICEI_MODEM_CONFIG_PREF_VOICE_SO   (0x14)
#define VOICEI_MODEM_GET_CONFIG_AMR_STATUS           (0x15)
#define VOICEI_MODEM_CONFIG_VOICE_PRIVACY	(0x16)
#define VOICEI_MODEM_CONFIG_NAM_ID			(0x17)
#define VOICEI_MODEM_GET_CONFIG_PREF_VOICE_DOMAIN    (0x18)


#define VOICEI_BIND_SUBSCRIPTION			(0x10)

#define VOICEI_MNG_IP_CALLS_CALL_ID				(0x10)
#define VOICEI_MNG_IP_CALLS_CALL_TYPE			(0x11)
#define VOICEI_MNG_IP_CALLS_AUDIO_ATTRIB		(0x12)
#define VOICEI_MNG_IP_CALLS_VIDEO_ATTRIB		(0x13)
#define VOICEI_MNG_IP_CALLS_SIP_URI				(0x14)
#define VOICEI_MNG_IP_CALLS_RESP_FAILURE_CAUSE  (0x11)

#define VOICEI_GET_COLR_RESP				(0x10)
#define VOICEI_GET_COLR_FAILURE_CAUSE		(0X11)
#define VOICEI_GET_COLR_ALPHA_ID			(0X12)
#define VOICEI_GET_COLR_CC_RESULT_TYPE		(0x13)
#define VOICEI_GET_COLR_CC_RESULT_CALL_ID	(0X14)
#define VOICEI_GET_COLR_CC_RESULT_SUPS		(0X15)

#define VOICEI_MODIFIED_CALL_ID				(0x01)
#define VOICEI_MODIFIED_CALL_TYPE			(0x10)
#define VOICEI_MODIFIED_CALL_AUDIO_ATTRIB   (0x11)
#define VOICEI_MODIFIED_CALL_VIDEO_ATTRIB   (0x12)

#define VOICEI_MODIFY_ACCEPT_CALL_ID		(0x01)
#define VOICEI_MODIFY_ACCEPT_CALL_TYPE		(0x10)
#define VOICEI_MODIFY_ACCEPT_AUDIO_ATTRIB   (0x11)
#define VOICEI_MODIFY_ACCEPT_VIDEO_ATTRIB   (0x12)

#define VOICEI_GET_CNAP_RESP				(0x10)
#define VOICEI_GET_CNAP_FAILURE_CAUSE		(0X11)
#define VOICEI_GET_CNAP_ALPHA_ID			(0X12)
#define VOICEI_GET_CNAP_CC_RESULT_TYPE		(0x13)
#define VOICEI_GET_CNAP_CC_RESULT_CALL_ID	(0X14)
#define VOICEI_GET_CNAP_CC_RESULT_SUPS		(0X15)

/*---------------------------------------------------------------------------
  Response TLVs
---------------------------------------------------------------------------*/

#define VOICEI_INFO_REC_CALL_ID			(0x01)
#define VOICEI_CALL_STATUS				(0x01)
#define VOICEI_DTMF_INFORMATION			(0x01)
#define VOICEI_SIGNAL_INFO				(0x10)
#define VOICEI_CALLER_ID				(0x11)
#define VOICEI_DISPLAY_INFO				(0x12)
#define VOICEI_EXT_DISPLAY_INFO			(0x13)
#define VOICEI_CALLER_NAME_INFO			(0x14)
#define VOICEI_CALL_WAITING_IND			(0x15)
#define VOICEI_CONN_NUM_INFO			(0x16)
#define VOICEI_CALLING_PARTY_NUM_INFO	(0x17)
#define VOICEI_CALLED_PARTY_NUM_INFO	(0x18)
#define VOICEI_REDIRECT_NUM_INFO		(0x19)
#define VOICEI_NSS_CLIR_INFO			(0x1A)
#define VOICEI_NSS_AUD_CTRL_INFO		(0x1B)
#define VOICEI_NSS_RELEASE_INFO			(0x1C)
#define VOICEI_LINE_CTRL_INFO			(0x1D)
#define VOICEI_EXT_DISPLAY_INFO_RECORD  (0x1E)

#define VOICEI_OTASP_STATUS				(0x01)

#define VOICEI_PRIVACY_INFO             (0x01)
#define VOICEI_CALL_END_REASON          (0x10)
#define VOICEI_CALL_TYPE                (0x11)
#define VOICEI_ALL_CALL_STATUS          (0x01)
#define VOICEI_SUPS_NOTIFY_INFO         (0x01)
#define VOICEI_USSD_NOTIFY_TYPE         (0x01)
#define VOICEI_UUS_IND_DATA             (0x01)

#define VOICEI_SUPS_IND_SERVICE_INFO		(0x01)
#define VOICEI_SUPS_IND_SERVICE_CLASS		(0x10)
#define VOICEI_SUPS_IND_REASON				(0x11)
#define VOICEI_SUPS_IND_CFW_NUM				(0x12)
#define VOICEI_SUPS_IND_CFW_NR_TIMER		(0x13)
#define VOICEI_SUPS_IND_USS_INFO			(0x14)
#define VOICEI_SUPS_IND_CALL_ID				(0x15)
#define VOICEI_SUPS_IND_ALPHA				(0x16)
#define VOICEI_SUPS_IND_PWD					(0x17)
#define VOICEI_SUPS_IND_NEW_PWD				(0x18)
#define VOICEI_SUPS_IND_SUPS_DATA_SOURCE	(0x19)
#define VOICEI_SUPS_IND_FAILURE_CAUSE       (0x1A)
#define VOICEI_SUPS_IND_CF_NTWK_DATA        (0x1B)
#define VOICEI_SUPS_IND_CLIR_STATUS         (0x1C)
#define VOICEI_SUPS_IND_CLIP_STATUS         (0x1D)
#define VOICEI_SUPS_IND_COLP_STATUS         (0x1E)
#define VOICEI_SUPS_IND_COLR_STATUS         (0x1F)
#define VOICEI_SUPS_IND_CNAP_STATUS         (0x20)
#define VOICEI_SUPS_IND_USS_INFO_UTF16      (0x21)
#define VOICEI_SUPS_IND_SERVICE_CLASS_EXT   (0x22)
#define VOICEI_SUPS_IND_CF_NTWK_DATA_EXT    (0x23)

#define VOICEI_SPEECH_CODEC_INFO_NW_MODE		(0x010)
#define VOICEI_SPEECH_CODEC_INFO_CODEC_TYPE		(0x011)
#define VOICEI_SPEECH_CODEC_INFO_SAMPLE_RATE	(0x012)

#define VOICEI_HANDOVER_STATE								(0x01)

#define VOICEI_EXT_BRST_INTL_DATA							(0x01)

#define VOICEI_CONFERENCE_CONF_INFO_XML_DATA				(0x01)
#define VOICEI_CONFERENCE_CONF_INFO_SEQUENCE_NUM			(0x02)
#define VOICEI_CONFERENCE_CONF_INFO_TOTAL_XML_FILE_LENGTH	(0x10)

#define VOICEI_CONFERENCE_JOIN_CALL_ID              (0x01)
#define VOICEI_CONFERENCE_JOIN_PARTICIPANT_INFO     (0x02)

#define VOICEI_CONFERENCE_PARTICIPANT_UPDATE_INFO	(0x01)

//20161012 yjoh, add eCall ind	
#define VOICEI_ECALL_EVENT_IND      (0x10)

/*---------------------------------------------------------------------------
  QMI asynchronous responses
---------------------------------------------------------------------------*/

typedef void (*qmi_voice_user_async_cb_type)( int					user_handle,
											  qmi_service_id_type   service_id,
											  void*					user_data );

typedef void (*qmi_voice_indication_hdlr_type)( int								user_handle,
											    qmi_service_id_type				service_id,
												void							*user_data,
												qmi_voice_indication_id_type	voice_ind_id,
												void*							voice_ind_data );

EXTERN int	qmi_voice_indication_register( int				client_handle,
										   unsigned int		voice_ind_reg,
										   int*				qmi_err_code );

EXTERN int	qmi_voice_msg_req( int client_handle,
							   int qmi_voice_msg_id,
							   void* req_data,
							   void* rsp_data,
							   qmi_voice_user_async_cb_type	user_cb,
							   void* user_data );



/*===========================================================================
  FUNCTION
===========================================================================*/
//Function
EXTERN qmi_client_handle_type tof_qmi_voice_srvc_init_client
(
  const char                    *dev_id,
  qmi_voice_indication_hdlr_type  user_ind_msg_hdlr,
  void                          *user_ind_msg_hdlr_user_data,
  int                           *qmi_err_code
);

EXTERN int tof_tof_qmi_voice_srvc_release_client
(
  int      user_handle,
  int      *qmi_err_code
);



#ifdef __cplusplus
}
#endif



#endif
