#ifndef AP_LIB_H
#define AP_LIB_H

/******************************************************************************
  @file    ap_lib.h
  @brief   The TOF API for application processor

  DESCRIPTION

  GPIO CONTROL

  ---------------------------------------------------------------------------
  Copyright (c) 2016 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>

#define GPIO_OUTPUT 1
#define GPIO_INPUT 0
#define GPIO_HIGH  1
#define GPIO_LOW  0

#define GPIO_NONE  "none"
#define GPIO_FALLING "falling"
#define GPIO_RISING "rising"
#define GPIO_BOTH  "both"

#define SYSFS_GPIO_DIR "/sys/class/gpio"
#define AP_VERSION_PATH "/etc/version.info"

#define SYSFS_USB_ENABLE "/sys/class/android_usb/android0/enable"
#define SYSFS_USB_IDPRODUCT "/sys/class/android_usb/android0/idProduct"
#define SYSFS_USB_IDVENDOR "/sys/class/android_usb/android0/idVendor"
#define SYSFS_USB_DIAG_CLIENTS "/sys/class/android_usb/android0/f_diag/clients"
#define SYSFS_USB_ACM_TRANSPORTS "/sys/class/android_usb/android0/f_acm/acm_transports"
#define SYSFS_USB_SERIAL_TRANSPORTS "/sys/class/android_usb/android0/f_serial/transports"
#define SYSFS_USB_FUNCTIONS "/sys/class/android_usb/android0/functions"
#define SYSFS_USB_REMOTE_WAKEUP "/sys/class/android_usb/android0/remote_wakeup"
#define USB_PID_LENGTH 4
#define USB_PID_3100 "3100"
#define USB_PID_3300 "3300"
#define USB_PID_3301 "3301"

#define SYSFS_USB_MODE "/sys/kernel/debug/msm_otg/mode"

#define CLOCK_CONFIG_FILE "/data/clock_config"
#define NTP_CONFIG_FILE "/data/ntp_config"
#define TIME_DAEMON_NAME "time_daemon"
#define REBOOT_REASON_FILE "/data/reboot_reason"
#define REBOOT_REASON_LENGTH 50

#define DEFAULT_GMT 0
#define DEFAULT_NTP_PORT 123
#define DEFAULT_NTP_COUNT 10
#define DEFAULT_NTP_DELAY 3000

#define MAX_BUF 64

#define RESULT_SUCCESS  (0)
#define RESULT_FAIL     (1)

#ifdef __cplusplus
extern "C" {
#endif
typedef enum
{
  // ## sync with TOF JAVA APIs.. do not change ordering..  ##
  CLK_INVALID = 0,
  CLK_NITZ, // 1
  CLK_GNSS, // 2
  CLK_NTP,  // 3
  CLK_MAX
} CLOCK_TYPE;

int gpio_export( int gpio);
int gpio_is_exported( int gpio);
int gpio_unexport( int gpio);
int gpio_get_dir( int gpio,  char *dir);
int gpio_set_dir( int gpio,  int dir);
int gpio_get_val( int gpio,  int *val);
int gpio_set_val( int gpio,  int val);
int gpio_get_edge(int gpio, char *edge);
int gpio_set_edge( int gpio, char *edge);
int gpio_fd_open(int gpio);
int gpio_fd_close(int fd);
int gpio_read(int fd, int *val);

int (*gpio_check)(int gpio);
int (*gpio_trans)(int gpio);
void (*print_supported_gpios)(void);

int gpio_check_clarion( int gpio);
int gpio_trans_clarion( int gpio);
void print_supported_gpios_clarion(void);
int gpio_check_bosch( int gpio);
int gpio_trans_bosch( int gpio);
void print_supported_gpios_bosch(void);

int check_usb_composition(char *idproduct);
int change_usb_composition(char *idproduct, int make_default);
int is_supported_usb_composition(char *idproduct);
int get_enabled_usb_composition(void);
int disable_usb_compositon(void);

int get_usb_mode(char *buf);
int change_usb_mode(char *mode);
int GetPIDbyName(char* pidName);
int write_clock_config(int source, int gmt);
#ifdef __cplusplus
}
#endif

#endif
