/*===========================================================================

MODULE
   WIRELESS MODEM MANAGER
 
DESCRIPTION
  Wireless Modem Manager����
  
===========================================================================*/

/*===========================================================================
                        EDIT HISTORY FOR MODULE

when      who         what, where, why
----------------------------------------------------------------------------
090827    JG          create
===========================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h> // for floor()
#include "wmmdiag_packet_gw.h"
#include "wmmdiag_packet.h"
#include "TOF_API.h"

/*===========================================================================
  Constant Define
===========================================================================*/

/*===========================================================================
  Type Define
===========================================================================*/

/*===========================================================================
  Variable Declare
===========================================================================*/

#define DEBUG_MAX_LINE_LEN 32

#define DEBUG_TRIPLE_ELEM_LEN 10
#define DEBUG_DOUBLE_ELEM_LEN 15
#define DEBUG_SINGLE_ELEM_LEN 30

#define DEBUG_POS_1_3 0
#define DEBUG_POS_2_3 11
#define DEBUG_POS_3_3 22
#define DEBUG_POS_1_2 0
#define DEBUG_POS_2_2 16
#define DEBUG_POS_1_1 0

//Debug ��ũ���� ���δ� 32+2byte�� 15����.
#define DEBUG_SCRN_MAX_BUF_LEN 512


#define EMPTY_LINE_BUF() \
  memset(line_buf, ' ', sizeof(char)*DEBUG_MAX_LINE_LEN);\
  line_buf[DEBUG_MAX_LINE_LEN] = '\r';\
  line_buf[DEBUG_MAX_LINE_LEN+1] = '\n';\
  line_buf[DEBUG_MAX_LINE_LEN+2] = '\0'

#define NA_VAL 0xFF

#define IS_DIGIT(c) (((c)>='0')&&((c)<='9'))

static const char aMINTable1[10] = 
{ '1', '2', '3', '4', '5', '6', '7', '8', '9', '0' };

static const unsigned short aMINTable2[10] =
{ 9, 0, 1, 2, 3, 4, 5, 6, 7, 8 };

/*==========================================================================

FUNCTION wmmutil_check_pin_code
 
DESCRIPTION
  �Է��� Pin Code�� ���Ǵ��� äũ..
RETURN
  
===========================================================================*/ 
boolean wmmutil_check_pin_code(char *pin_code) 
{
  size_t idx;
  size_t pin_code_len;
  pin_code_len = strlen(pin_code);
  
  if(pin_code_len<4 || pin_code_len>8)
    return FALSE;
  for(idx=0; idx<pin_code_len; idx++) {
    if(IS_DIGIT(pin_code[idx])==FALSE)
      return FALSE;
  }
  return TRUE;
}
/*==========================================================================

FUNCTION wmmutil_check_puk_code
 
DESCRIPTION
  �Է��� PUK Code�� ���Ǵ��� äũ..
RETURN
  
===========================================================================*/ 
boolean wmmutil_check_puk_code(char *puk_code) 
{
  size_t idx;
  size_t puk_code_len;
  puk_code_len = strlen(puk_code);
  
  if(puk_code_len!=8)
    return FALSE;
  for(idx=0; idx<puk_code_len; idx++) {
    if(IS_DIGIT(puk_code[idx])==FALSE)
      return FALSE;
  }
  return TRUE;
}

/*======================================================================

FUNCTION convertStringToHexa
 
DESCRIPTION
	
======================================================================*/

int convertStringToHexa( const char* string, char* hexa )
{
       int i=0;
			 int stringLen = strlen( string );
       int hexaIndex = 0;
       int intValue = 0;
       char stringBuf[ 3 ];

       if ( 0 != stringLen % 2 )
             return 0;

       for (  i = 0; i < stringLen; i += 2 )
       {
             stringBuf[ 0 ] = string[ i ];
             stringBuf[ 1 ] = string[ i + 1 ];
             stringBuf[ 2 ] = 0;

             sscanf( stringBuf, "%x", &intValue );

             hexa[ hexaIndex++ ] = (char)intValue;

             //printf( "%d\n", intValue );	//dsji_20110111
       }

		hexa[ hexaIndex ] = 0;

       return hexaIndex;
}

/*======================================================================

FUNCTION HK_MDM_convertHexaToString
 
DESCRIPTION
	
======================================================================*/

void convertHexaToString( const char* hexa, char* string, int hexaLen)
{
			 int i;
       string[ 0 ] = 0;
       char stringBuf[ 64 ];

       for (  i = 0; i < hexaLen; ++i )
       {
             sprintf( stringBuf, "%02x", hexa[ i ] );

             if ( strlen( stringBuf ) > 2 )
             {
                    stringBuf[ 0 ] = stringBuf[ 6 ];
                    stringBuf[ 1 ] = stringBuf[ 7 ];
                    stringBuf[ 2 ] = 0;
             }

             strcat( string, stringBuf );
       }
}

/*===========================================================================

FUNCTION 
  sConvertMIN2_ASC

DESCRIPTION
  
===========================================================================*/
void sConvertMIN2_ASC(unsigned short wAreaCode, char* pszTXT)
{
	*pszTXT++  = aMINTable1[wAreaCode/100];
	wAreaCode %= 100;
	*pszTXT++  = aMINTable1[wAreaCode/10];
	*pszTXT++  = aMINTable1[wAreaCode%10];
	*pszTXT    = '\0';
}

/*===========================================================================

FUNCTION 
  sConvertMIN1_ASC

DESCRIPTION
  
===========================================================================*/
void sConvertMIN1_ASC(unsigned int dwPhoneNum, char* pszTXT)
{
  int iLoop;

  if( dwPhoneNum == 0 ) {
    for( iLoop=0; iLoop<7; iLoop++ ) {
      *pszTXT++ = '0';
    }
  } else {
    iLoop = (unsigned short) (dwPhoneNum>>14);
    *pszTXT++ = aMINTable1[iLoop/100];
    iLoop %= 100;
    *pszTXT++ = aMINTable1[iLoop/10];
    *pszTXT++ = aMINTable1[iLoop%10];
    dwPhoneNum &= 0x3FFFL;                /* get bottom 14 bits */
    /* next digit is top 4 bits */
    iLoop = (unsigned short) (( dwPhoneNum >> 10 ) & 0xF );
    *pszTXT++ = (char) (((iLoop == 10 ) ? 0 : iLoop) + '0' );
    iLoop = (unsigned short) (dwPhoneNum & 0x3FF);  /* get bottom 10 bits */
    *pszTXT++ = aMINTable1[iLoop/100];
    iLoop %= 100;
    *pszTXT++ = aMINTable1[iLoop/10];
    *pszTXT++ = aMINTable1[iLoop%10];
  }
  *pszTXT = '\0';
}

uint8 dsatetsime_convert_rssi
(
  uint16    rssi,    /* Call Manager RSSI as positive integer */
  uint8     scale    /* ATCOP scaling factor */
)
{
  uint8 siglvl = 0;

  /* Note: RSSI dbm is really a negative value        */
  if ((RSSI_MIN < rssi) &&
      (RSSI_MAX > rssi))
  {
    /* Round to nearest integer on scale */
    siglvl = (uint8)floor(((rssi * RSSI_SLOPE + RSSI_OFFSET) *
                            scale)/100 + 0.5);
  }
  else if ((RSSI_MAX <= rssi) && 
           (RSSI_NO_SIGNAL != rssi)) 
  {
    siglvl = RSSI_TOOLO_CODE;
  }
  else if (RSSI_MIN >= rssi)
  {
    siglvl = RSSI_TOOHI_CODE;  /* Capped maximum */
  }
  else
  {
    //QSR_MSG_MED( 1565908731ULL,  "RSSI outside signal range: %d", rssi, 0, 0 );//auto-gen, to change remove 'QSR_' and first param
    siglvl = RSSI_UNKNOWN_CODE;
  }
     
  return siglvl;
} /* dsatetsime_convert_rssi */

uint8 dsatetsime_gsm_convert_rssi
(
  uint16    rssi,    /* Call Manager RSSI as positive integer */
  uint8     scale    /* ATCOP scaling factor */
)
{
  uint8 siglvl = 0;

  /***********************************
          level 0 = less than -110
          level 1 = -110
          level 2 = -109
                   :
          level 62 = -49
          level 63 = greater than -48
  ***********************************/
  /* Note: RSSI dbm is really a negative value        */
  if ((GSM_RSSI_MIN <= rssi) &&
      (GSM_RSSI_MAX >= rssi))
  {
    /* Round to nearest integer on scale */
    siglvl = 111 - rssi;
  }
  else if (GSM_RSSI_MIN > rssi) 
  {
    siglvl = GSM_RSSI_TOOHI_CODE;  //63
  }
  else if (GSM_RSSI_MAX < rssi)
  {
    siglvl = GSM_RSSI_TOOLO_CODE;  //0
  }
  
  return siglvl;
} /* dsatetsime_convert_rssi */

boolean Check_Vendor_Firmware_Match(char *sw_ver, uint8 vendor)
{
  uint8 match = FALSE;

  //LOGD("Check_Vendor_Firmware_Match vendor string: [%s] modem firmware version: [%s]", wmmdbg_vendor_type_str(vendor), sw_ver);

  switch (vendor)
  {
    case WMM_VENDOR_T_SKT:
      if(strstr(sw_ver, "_SKT") != NULL) match = TRUE;
      break;
    case WMM_VENDOR_T_KT:
      if(strstr(sw_ver, "_KT") != NULL) match = TRUE;
      break;
    case WMM_VENDOR_I_SKT:
      if(strstr(sw_ver, "_RSKT") != NULL) match = TRUE;
      break;
    case WMM_VENDOR_I_KT:
      if(strstr(sw_ver, "_RKT") != NULL) match = TRUE;
      break;
    case WMM_VENDOR_I_VZW:
      if(strstr(sw_ver, "_RVZW") != NULL || strstr(sw_ver, "LTD-VH1000") != NULL) match = TRUE;
      break;      
    case WMM_VENDOR_I_CHU:
      if(strstr(sw_ver, "_RCHU") != NULL) match = TRUE;
      break;  
    case WMM_VENDOR_T_QZKT:
      if(strstr(sw_ver, "_QZKT") != NULL) match = TRUE;
      break;
    case WMM_VENDOR_I_LTE_SKT:
      if(strstr(sw_ver, "_LSKT") != NULL) match = TRUE;
      break;      
    case WMM_VENDOR_I_LTE_KT:
      if(strstr(sw_ver, "_LKT") != NULL) match = TRUE;
      break;  
    case WMM_VENDOR_I_LTE_VZW:
      if(strstr(sw_ver, "_LVZW") != NULL) match = TRUE;
      break;
		case WMM_VENDOR_D_KT:
			if(strstr(sw_ver, "_DKT") != NULL ) match = TRUE;
			break;
		case WMM_VENDOR_G_SKT:
			if(strstr(sw_ver, "_GSKT") != NULL ) match = TRUE;
			break;
    default:
      match = FALSE;
      break;       
  }

  return match;
} /* Check_Vendor_Firmware_Match */

void print_screen_message(char *msg, int len)
{
  int i=0;
  printf("\n\n");   
  for( i=0;i<len;i++)
    printf("[%d]: %d (0x%x)\n",i, (unsigned char)msg[i], (unsigned char)msg[i]);  
  printf("\n\n");
}

void print_log_message(char *msg, int len)
{
  int i=0;
  for( i=0;i<len;i++)
    MSG_LOW("[%d]: %d (0x%x)",i, (unsigned char)msg[i], (unsigned char)msg[i]);  
}


