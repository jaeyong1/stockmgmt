/******************************************************************************
  @file    qmi_imsa.cpp
  @brief   The QMI imsa client

  DESCRIPTION

  INITIALIZATION AND SEQUENCING REQUIREMENTS

  ---------------------------------------------------------------------------
  Copyright (c) 2013 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/

#include <string.h>
#include "qmi.h"
#include "qmi_imsa.h"


/* Log assertion level message */
#define QCRIL_ASSERT( xx_exp )                                         \
  if ( !( xx_exp ) )                                                       \
  {                                                                        \
    MSG_FATAL( "*****ASSERTION FAILED*****",0,0,0); \
  } 

qmi_client_handle_type imsa_client_handle = QMI_INVALID_CLIENT_HANDLE;  

#define QMI_IMSA_REGISTRATION_STATUS_IND_V01 0x0023
#define QMI_IMSA_SERVICE_STATUS_IND_V01 0x0024
#define QMI_IMSA_ACS_STATUS_IND_V01 0x0027

/*=========================================================================

  FUNCTION:  qmi_imsa_indication_cb

===========================================================================*/
/*!
    @brief
    Callback for QMI indications.

    @return
    None
*/
/*=========================================================================*/
void qmi_imsa_indication_cb
(
  int                            user_handle,
  qmi_service_id_type            service_id,
  void                         * user_data,
  qmi_imsa_indication_id_type     ind_id,
  qmi_imsa_indication_data_type * ind_data_ptr
)
{
  int                               ind_params_tot_size = 0;
  imsa_0024_ind_s *imsa_0024_ind;  
  imsa_0023_ind_s *imsa_0023_ind;
  imsa_0027_ind_s *imsa_0027_ind;

  switch(ind_id)
  {
    case QMI_IMSA_SERVICE_STATUS_IND_V01:
      imsa_0024_ind = (imsa_0024_ind_s *)ind_data_ptr;            
    break;
    
    case QMI_IMSA_REGISTRATION_STATUS_IND_V01:
      imsa_0023_ind = (imsa_0023_ind_s *)ind_data_ptr;            
    break;

    case QMI_IMSA_ACS_STATUS_IND_V01:
      imsa_0027_ind = (imsa_0027_ind_s *)ind_data_ptr;            
    break;
    
    default:
    break;
  }

  return;
} /* qmi_imsa_indication_cb */

/*===========================================================================

  FUNCTION  qmi_imsa_srvc_init
  
===========================================================================*/
bool qmi_imsa_srvc_init()
{
  int rc = QMI_INTERNAL_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;

  imsa_0022_req_s imsa_0022_req;

  if(imsa_client_handle != QMI_INVALID_CLIENT_HANDLE) 
  {
    printf("qmi_ims_init()imsa_client_handle already exist = %x \r\n", imsa_client_handle);
    return RESULT_SUCCESS;
  }
  
  imsa_client_handle = qmi_imsa_srvc_init_client(QMI_PORT_RMNET_0,
                                                 qmi_imsa_indication_cb, // callback function. 
                                                 NULL, 
                                                 &qmi_err_code);

  if(imsa_client_handle == INVALID_HANDLE_VALUE)
  {
    MSG_ERROR("[IMS]error on qmi_imsa_srvc_init_client",0 ,0, 0);
    return RESULT_FAILURE;
  }

  memset(&imsa_0022_req, 0, sizeof(imsa_0022_req_s));

#if 0  
  imsa_0022_req.t10_valid = TRUE;
  imsa_0022_req.t10.reg_status_config = 0x01;
  
  imsa_0022_req.t11_valid = TRUE;
  imsa_0022_req.t11.service_status_config = 0x01;

  imsa_0022_req.t14_valid = TRUE;
  imsa_0022_req.t14.acs_status_config = 0x01;
#endif
  rc = qmi_imsa_indication_register((int)imsa_client_handle,
                                              &imsa_0022_req,
                                              &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_imsa_indication_register!! rc: %d err_code : %d",rc,qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;
} /* qmi_imsa_srvc_init */

/*===========================================================================

  FUNCTION  qmi_imsa_srvc_release
  
===========================================================================*/
bool qmi_imsa_srvc_release()
{
  bool ret = FALSE;
  int qmi_err_code = QMI_INTERNAL_ERR;

  if(imsa_client_handle == INVALID_HANDLE_VALUE)
    return FALSE;

  ret = qmi_imsa_srvc_release_client((int)imsa_client_handle, &qmi_err_code);
  if(ret)
    imsa_client_handle = INVALID_HANDLE_VALUE;
  return ret;
}

/*===========================================================================

  FUNCTION  ril_request_get_service_status_info
  
===========================================================================*/
uint8 ril_request_get_service_status_info(int request, RIL_Imsa_Service_Status_Info *service_status)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  imsa_0021_rsp_s imsa_0021_rsp;

  memset(&imsa_0021_rsp, 0, sizeof(imsa_0021_rsp_s));
  
  if(imsa_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_imsa_get_service_status_info((int)imsa_client_handle, &imsa_0021_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[IMSA] qmi_imsa_get_service_status_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    switch(request)
    {
      case REQUEST_VOIP_SERVICE_STATUS:
        MSG_HIGH("VOIP Service Status : %d", imsa_0021_rsp.t11.voip_service_status, 0, 0);
        service_status->voip_service_status = imsa_0021_rsp.t11.voip_service_status;
      break;

      default:
      break;
    }

    return RESULT_SUCCESS;
  }

}
/*===========================================================================

  FUNCTION  ril_request_get_ims_reg_status_info
  
===========================================================================*/
uint8 ril_request_get_ims_reg_status_info(RIL_Imsa_Reg_Status_Info *ims_status)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  imsa_0020_rsp_s imsa_0020_rsp;

  memset(&imsa_0020_rsp, 0, sizeof(imsa_0020_rsp_s));
  
  if(imsa_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_imsa_get_reg_status_info((int)imsa_client_handle, &imsa_0020_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[IMSA] qmi_imsa_get_reg_status_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    MSG_HIGH("IMS REG Status : %d", imsa_0020_rsp.t10.ims_registered, 0, 0);
    ims_status->ims_registered = imsa_0020_rsp.t10.ims_registered;

    if (ims_status->ims_registered == FALSE)
      {
        MSG_HIGH("IMS REG Fail Code : %d", imsa_0020_rsp.t11.ims_registration_failure_error_code, 0, 0);
        ims_status->ims_registration_failure_error_code = imsa_0020_rsp.t11.ims_registration_failure_error_code;
      }

    return RESULT_SUCCESS;
  }

}

#if 0 //chad_temp
//--> UNSOL_HK_IMS_ACS_FAILURE_503_ERROR_CODE
void qmi_imsa_acs_failure_503_error_code_ind()
{
	sRILCommand cmd;
	
	MSG_HIGH("RIL_UNSOL_HK_IMS_ACS_FAILURE_503_ERROR_CODE", 0, 0, 0);
	cmd.ID = RIL_UNSOL_HK_IMS_ACS_FAILURE_503_ERROR_CODE;
	cRILCommandSimulator::getInstance().sendUnsolicitedCommand( cmd );
}
//<-- UNSOL_HK_IMS_ACS_FAILURE_503_ERROR_CODE hongsg 20140813
#endif //chad_temp
