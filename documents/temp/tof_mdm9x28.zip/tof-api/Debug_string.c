/******************************************************************************
  @file    Debug_string.c
  @brief   The QMI TOF API

  DESCRIPTION

  INITIALIZATION AND SEQUENCING REQUIREMENTS

  ---------------------------------------------------------------------------
  Copyright (c) 2016 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "TOF_API.h"
#include "Debug_string.h"
#include "qmi_nas.h"


#define STR(str) #str
static char debug_value_str[20];
#define return_number \
{\
  sprintf(debug_value_str,"%ld",value);\
  return debug_value_str;\
}

char *EVENT_E_TYPE_str(int32 value)
{
  switch(value)
  {
       case TOF_EVENT_GET_MODEM_VERSION:return STR(TOF_EVENT_GET_MODEM_VERSION);  //
  }

  return_number;
}

/*===========================================================================

  FUNCTION  registration_status_str
  
===========================================================================*/
char *registration_status_str(uint8 value)
{
  int ivalue = 0;

  if (value >= 10)
  {
    ivalue = (int) value - 10;
  }
  else
  {
    ivalue = (int) value;
  }

  switch(ivalue)
  {
    case NET_REG_NONE:return STR(REG_NONE);
    case NET_REG_HOME:return STR(REG_HOME);  
    case NET_REG_SEARCHING:return STR(REG_SEARCHING);
    case NET_REG_DENIED:return STR(REG_DENIED);
    case NET_REG_UNKNOWN:return STR(REG_UNKNOWN);
    case NET_REG_ROAMING:return STR(REG_ROAMING);
    default:return STR(None);
  }
  return_number;
}

/*===========================================================================

  FUNCTION  attach_status_str
  
===========================================================================*/
char *attach_status_str(uint8 value)
{
  switch(value)
  {
    case WMM_ATTACH_STATE_UNKNOWN:return STR(UNKNOWN);
    case WMM_ATTACH_STATE_ATTACHED:return STR(ATTACHED);  
    case WMM_ATTACH_STATE_DETACHED:return STR(DETACHED);
    default:return STR(None);
  }
  return_number;
}

/*===========================================================================

  FUNCTION  ril_act_e_type_str
  
===========================================================================*/
char *ril_act_e_type_str(uint8 value)
{
  switch(value)
  {
    case RIL_ACT_UNKNOWN:return STR(UNKNOWN);
    case RIL_ACT_GPRS:return STR(GPRS);  
    case RIL_ACT_EDGE:return STR(EDGE);
    case RIL_ACT_UMTS:return STR(UMTS);
    case RIL_ACT_IS95A:return STR(IS95A);
    case RIL_ACT_IS95B:return STR(IS95B);
    case RIL_ACT_1XRTT:return STR(1XRTT);
    case RIL_ACT_EVDO0:return STR(EVDO0);
    case RIL_ACT_EVDOA:return STR(EVDOA);  
    case RIL_ACT_HSDPA:return STR(HSDPA);
    case RIL_ACT_HSUPA:return STR(HSUPA);
    case RIL_ACT_HSPA:return STR(HSPA);
    case RIL_ACT_EVDOB:return STR(EVDOB);
    case RIL_ACT_EHRPD:return STR(EHRPD);
    case RIL_ACT_LTE:return STR(LTE);
    case RIL_ACT_HSPAP:return STR(HSPAP);
    case RIL_ACT_GSM:return STR(GSM);
    default:return STR(None);
  }
  return_number;
}

/*===========================================================================

  FUNCTION  sys_srv_domain_e_type_str
  
===========================================================================*/
char *sys_srv_domain_e_type_str(uint8 value)
{
  switch(value)
  {
    //case SYS_SRV_DOMAIN_NONE:return STR(NONE);
    case SYS_SRV_DOMAIN_NO_SRV:return STR(NO_SRV);  
    case SYS_SRV_DOMAIN_CS_ONLY:return STR(CS);
    case SYS_SRV_DOMAIN_PS_ONLY:return STR(PS);
    case SYS_SRV_DOMAIN_CS_PS:return STR(CS_PS);
    case SYS_SRV_DOMAIN_CAMPED:return STR(RELEASING);
    default:return STR(UNKNOWN);
  }
  return_number;
}

/*===========================================================================

  FUNCTION  pref_mode_e_type_str
  
===========================================================================*/
char *pref_mode_e_type_str(uint8 value)
{
  switch(value)
  {
    case NAS_0033_NET_SEL_PREF_AUTOMATIC:return STR(AUTOMATIC);  
    case NAS_0033_NET_SEL_PREF_MANUAL:return STR(MANUAL);
    default:return STR(UNKNOWN);
  }
  return_number;
}

/*======================================================================

FUNCTION      reject_cause_string

DESCRIPTION
  rrc state enum string

======================================================================*/ 
char *reject_cause_string(int value) {
  switch(value) {
  
    case REG_NONE:return STR(REG_NONE);//                                  0x00
    case REG_SUCCESS:return STR(REG_SUCCESS);//                                  0x01
    case REG_REGISTERING:return STR(REG_REGISTERING);//                     0xFF      // daejang 20070217
    case IMSI_UNKNOWN_IN_HLR:return STR(IMSI_UNKNOWN_IN_HLR);//                             0x02
    case ILLEGAL_MS:return STR(ILLEGAL_MS);//                                      0x03
    case IMSI_UNKNOWN_IN_VLR:return STR(IMSI_UNKNOWN_IN_VLR);//                             0x04
    case IMEI_NOT_ACCEPTED:return STR(IMEI_NOT_ACCEPTED);//                               0x05
    case ILLEGAL_ME:return STR(ILLEGAL_ME);//                                      0x06
    case GPRS_SERVICES_NOT_ALLOWED:return STR(GPRS_SERVICES_NOT_ALLOWED);//                       0x07
    case GPRS_SERVICES_AND_NON_GPRS_SERVICES_NOT_ALLOWED:return STR(GPRS_SERVICES_AND_NON_GPRS_SERVICES_NOT_ALLOWED);// 0x08
    case MS_IDENTITY_CANNOT_BE_DERIVED_BY_THE_NETWORK:return STR(MS_IDENTITY_CANNOT_BE_DERIVED_BY_THE_NETWORK);//    0x09
    case IMPLICITLY_DETACHED:return STR(IMPLICITLY_DETACHED);//                             0x0A
    case PLMN_NOT_ALLOWED:return STR(PLMN_NOT_ALLOWED);//                                0x0B
    case LA_NOT_ALLOWED:return STR(LA_NOT_ALLOWED);//                                  0x0C
    case NATIONAL_ROAMING_NOT_ALLOWED:return STR(NATIONAL_ROAMING_NOT_ALLOWED);//                    0x0D
    case GPRS_SERVICES_NOT_ALLOWED_IN_THIS_PLMN:return STR(GPRS_SERVICES_NOT_ALLOWED_IN_THIS_PLMN);//          0x0E
    case NO_SUITABLE_CELLS_IN_LA:return STR(NO_SUITABLE_CELLS_IN_LA);//                         0x0F
    case MSC_TEMPORARILY_NOT_REACHABLE:return STR(MSC_TEMPORARILY_NOT_REACHABLE);//                   0x10
    case NETWORK_FAILURE:return STR(NETWORK_FAILURE);//                                 0x11
    case MAC_FAILURE:return STR(MAC_FAILURE);//                                     0x14
    case SYNCH_FAILURE:return STR(SYNCH_FAILURE);//                                   0x15
    case CONGESTTION:return STR(CONGESTTION);//                                     0x16
    case GSM_AUTH_UNACCEPTED:return STR(GSM_AUTH_UNACCEPTED);//                             0x17
    case SERVICE_OPTION_NOT_SUPPORTED:return STR(SERVICE_OPTION_NOT_SUPPORTED);//                    0x20
    case REQ_SERV_OPT_NOT_SUBSCRIBED:return STR(REQ_SERV_OPT_NOT_SUBSCRIBED);//                     0x21
    case SERVICE_OPT__OUT_OF_ORDER:return STR(SERVICE_OPT__OUT_OF_ORDER);//                       0x22
    case CALL_CANNOT_BE_IDENTIFIED:return STR(CALL_CANNOT_BE_IDENTIFIED);//                       0x26
    case NO_PDP_CONTEXT_ACTIVATED:return STR(NO_PDP_CONTEXT_ACTIVATED);//                        0x28
    case RETRY_UPON_ENTRY_INTO_A_NEW_CELL_MIN_VALUE:return STR(RETRY_UPON_ENTRY_INTO_A_NEW_CELL_MIN_VALUE);//      0x30
    case RETRY_UPON_ENTRY_INTO_A_NEW_CELL_MAX_VALUE:return STR(RETRY_UPON_ENTRY_INTO_A_NEW_CELL_MAX_VALUE);//      0x3F
    case SEMANTICALLY_INCORRECT_MSG:return STR(SEMANTICALLY_INCORRECT_MSG);//                      0x5F
    case INVALID_MANDATORY_INFO:return STR(INVALID_MANDATORY_INFO);//                          0x60
    case MESSAGE_TYPE_NON_EXISTANT:return STR(MESSAGE_TYPE_NON_EXISTANT);//                       0x61
    case MESSAGE_TYPE_NOT_COMP_PRT_ST:return STR(MESSAGE_TYPE_NOT_COMP_PRT_ST);//                    0x62
    case IE_NON_EXISTANT:return STR(IE_NON_EXISTANT);//                                 0x63
    case MSG_NOT_COMPATIBLE_PROTOCOL_STATE:return STR(MSG_NOT_COMPATIBLE_PROTOCOL_STATE);//               0x65
  }
  return "Protocol error, unspecified";
}

/*======================================================================

FUNCTION      service_status_str

DESCRIPTION
  rrc state enum string

======================================================================*/ 
char *service_status_str(int value) {

  switch(value){
    case SYS_SRV_STATUS_NONE:return STR(NONE);// = -1,
      /* FOR INTERNAL USE ONLY!                 */
  
    case SYS_SRV_STATUS_NO_SRV:return STR(NO_SRV);//,
      /* No service                             */
  
    case SYS_SRV_STATUS_LIMITED:return STR(LIMITED);//,
      /* Limited service                        */
  
    case SYS_SRV_STATUS_SRV:return STR(SRV);//,
      /* Service available                      */
  
    case SYS_SRV_STATUS_LIMITED_REGIONAL:return STR(LIMITED_REGION);//,
      /* Limited regional service               */
  
    case SYS_SRV_STATUS_PWR_SAVE:return STR(PWR_SAVE);//,
      /* MS is in power save or deep sleep      */
  
    case SYS_SRV_STATUS_MAX:
      /* FOR INTERNAL USE OF CM ONLY!           */
  
  #ifdef FEATURE_RPC
  #error code not present
  #endif /* FEATURE_RPC */
    default:
      return "Unknown";
    }
}

/*===========================================================================

  FUNCTION  radio_interface_str
  
===========================================================================*/
char *radio_interface_str(uint8 value)
{
  switch(value)
  {
    case RADIO_IF_NO_SVC:return STR(NO_SVC);
    case RADIO_IF_CDMA_1X:return STR(CDMA_1X);  
    case RADIO_IF_CDMA_1XEVDO:return STR(CDMA_1XEVDO);
    case RADIO_IF_AMPS:return STR(AMPS);
    case RADIO_IF_GSM:return STR(GSM);
    case RADIO_IF_UMTS:return STR(UMTS);
    case RADIO_IF_LTE:return STR(LTE);
    case RADIO_IF_TDSCDMA:return STR(TDSCDMA);
    default:return STR(None);
  }
  return_number;
}

/*===========================================================================

  FUNCTION  emm_state_type_str
  
===========================================================================*/
char *emm_state_type_str(uint8 value)
{
  switch(value)
  {
    case EMM_NULL:return STR(NULL);
    case EMM_DEREGISTERED:return STR(DEREGISTR);  
    case EMM_REGISTERED_INITIATED:return STR(REG_INIT);
    case EMM_REGISTERED:return STR(REGISTERED);
    case EMM_TRACKING_AREA_UPDATING_INITIATED:return STR(TAU_INIT);
    case EMM_SERVICE_REQUEST_INITIATED:return STR(SVC_REQ_INIT);
    case EMM_DEREGISTERED_INITIATED:return STR(DEREGINIT);
    case EMM_INVALID_STATE:return STR(INVALID);
    default:return STR(NULL);
  }
  return_number;
}

/*===========================================================================

  FUNCTION  emm_deregistered_substate_type_str
  
===========================================================================*/
char *emm_deregistered_substate_type_str(uint8 value)
{
  switch(value)
  {
    case EMM_DEREGISTERED_NO_IMSI:return STR(NO_IMSI);
    case EMM_DEREGISTERED_PLMN_SEARCH:return STR(PLMN_SRCH);  
    case EMM_DEREGISTERED_ATTACH_NEEDED:return STR(ATT_NEED);
    case EMM_DEREGISTERED_NO_CELL_AVAILABLE:return STR(NO_CELL);
    case EMM_DEREGISTERED_ATTEMPTING_TO_ATTACH:return STR(ACC2ATT);
    case EMM_DEREGISTERED_NORMAL_SERVICE:return STR(NORMAL);
    case EMM_DEREGISTERED_LIMITED_SERVICE:return STR(LTD_SVC);
    case EMM_DEGEGISTERED_WAITING_PDN_CONN_REQ:return STR(PDN_CONN_REQ);
    default:return STR(UNKNOWN);
  }
  return_number;
}

/*===========================================================================

  FUNCTION  emm_registered_initiated_substate_type_str
  
===========================================================================*/
char *emm_registered_initiated_substate_type_str(uint8 value)
{
  switch(value)
  {
    case EMM_WAITING_FOR_NW_RESPONSE:return STR(WAIT4NW_REP);
    case EMM_WAITING_FOR_ESM_RESPONSE:return STR(WAIT4ESM_REP);  
    default:return STR(UNKNOWN);
  }
  return_number;
}

/*===========================================================================

  FUNCTION  emm_registered_substate_type_str
  
===========================================================================*/
char *emm_registered_substate_type_str(uint8 value)
{
  switch(value)
  {
    case EMM_REGISTERED_NORMAL_SERVICE:return STR(NORMAL);
    case EMM_REGISTERED_UPDATE_NEEDED:return STR(UDT_NEED);  
    case EMM_REGISTERED_ATTEMPTING_TO_UPDATE:return STR(ACC2UPD);
    case EMM_REGISTERED_NO_CELL_AVAILABLE:return STR(NO_CELL);
    case EMM_REGISTERED_PLMN_SEARCH:return STR(PLMN_SRCH);
    case EMM_REGISTERED_LIMITED_SERVICE:return STR(LTD_SVC);
    case EMM_REGISTERED_ATTEMPTING_TO_UPDATE_MM:return STR(ACC2UPDMM);
    case EMM_REGISTERED_IMSI_DETACH_INITIATED:return STR(IMSI_DET);
    case EMM_REGISTERED_WAITING_FOR_ESM_ISR_STATUS:return STR(WAIT4ESM_ISR);
    default:return STR(UNKNOWN);
  }
  return_number;
}

/*===========================================================================

  FUNCTION  emm_connection_state_type_str
  
===========================================================================*/
char *emm_connection_state_type_str(uint8 value)
{
  switch(value)
  {
    case EMM_IDLE_STATE:return STR(IDLE);
    case EMM_WAITING_FOR_RRC_CONFIRMATION_STATE:return STR(WAIT_RRC_CONFIRM);  
    case EMM_CONNECTED_STATE:return STR(CONNECTED);
    case EMM_RELEASING_RRC_CONNECTION_STATE:return STR(RELEASING);
    default:return STR(UNKNOWN);
  }
  return_number;
}

/*===========================================================================

  FUNCTION  emcb_e_type_str
  
===========================================================================*/
char *emcb_e_type_str(uint8 value)
{
  switch(value)
  {
    case QMI_RIL_EME_CBM_INVALID:return STR(EMCB_INVALID);  
    case QMI_RIL_EME_CBM_NOT_ACTIVE:return STR(EMCB_INACTIVE);
    case QMI_RIL_EME_CBM_ACTIVE:return STR(EMCB_ACTIVE);
    default:return STR(UNKNOWN);
  }
  return_number;
}

#ifdef FEATURE_LGIT_TIME
/*===========================================================================

  FUNCTION  nitz_state_e_type_str
  
===========================================================================*/
char *nitz_state_e_type_str(uint8 value)
{
  switch(value)
  {
    case NITZ_TIME_MANAGER_STATE_TRY_UPDATE:return STR(TRY_UPDATE);  
    case NITZ_TIME_MANAGER_STATE_UPDATED:return STR(UPDATED);
    case NITZ_TIME_MANAGER_STATE_WAIT_FOR_TRY_UPDATE:return STR(WAIT_FOR_TRY_UPDATE);    
    default:return STR(UNKNOWN);
  }
  return_number;
}
#endif

/*===========================================================================

  FUNCTION  mode_pref_type_str
  
===========================================================================*/
char *mode_pref_type_str(uint16 value)
{
  switch(value)
  {
    case QMI_NAS_RAT_MODE_PREF_CDMA:return STR(CDMA);  
    case QMI_NAS_RAT_MODE_PREF_HRPD:return STR(HRPD);  
    case QMI_NAS_RAT_MODE_PREF_GSM:return STR(GSM);  
    case QMI_NAS_RAT_MODE_PREF_LTE:return STR(LTE);  
    case QMI_NAS_RAT_MODE_PREF_CDMA_HRPD:return STR(CDMA_HRPD);  
    case QMI_NAS_RAT_MODE_PREF_GSM_UMTS:return STR(GSM_UMTS);  
    case QMI_NAS_RAT_MODE_PREF_UMTS_LTE:return STR(UMTS_LTE);  
    case QMI_NAS_RAT_MODE_PREF_GSM_UMTS_CDMA_HRPD:return STR(GSM_UMTS_CDMA_HRPD);  
    case QMI_NAS_RAT_MODE_PREF_CDMA_HRPD_LTE:return STR(CDMA_HRPD_LTE);  
    case QMI_NAS_RAT_MODE_PREF_GSM_UMTS_CDMA_HRPD_LTE:return STR(GSM_UMTS_CDMA_HRPD_LTE);             
                                
    default:return STR(UNKNOWN);
  }
  return_number;
}




