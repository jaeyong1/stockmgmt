
/******************************************************************************
  @file    qmi_voice.cpp
  @brief   The QMI voice client

  DESCRIPTION

  INITIALIZATION AND SEQUENCING REQUIREMENTS

  ---------------------------------------------------------------------------
  Copyright (c) 2016 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/



#include <string.h>
#include "qmi.h"
#include "qmi_voice.h"

#include "qmi_nas.h" //VOLTE_CALL_TYPE

#define QCRIL_ASSERT( xx_exp ) if ( !( xx_exp ) ) { MSG_FATAL( "***** assertion fail *****", 0, 0, 0 );	}



HANDLE g_voice_client_handle = INVALID_HANDLE_VALUE;



voice_get_all_call_info_resp_msg_v02 g_voice_all_call_info;
call_end_reason_enum_v02             g_voice_call_end_reason = QMI_VOICE_CALL_END_REASON_UNSPECIFIED;
voice_speech_codec_enum_v02          g_voice_speech_codec;
voice_basic_call_info_type           g_voice_basic_call_info;



void	update_g_voice_all_call_info( voice_get_all_call_info_resp_msg_v02* call_info )
{
	memcpy( &g_voice_all_call_info, call_info, sizeof( g_voice_all_call_info ) );
}

void update_g_voice_basic_call_info( voice_call_info2_type_v02* call_info )
{
  memcpy( &g_voice_all_call_info.call_info, call_info, sizeof( voice_call_info2_type_v02 ) );
}

//dsji_20130617 add {
voice_get_clir_resp_msg_v02		g_clir;
voice_get_clip_resp_msg_v02		g_clip;
voice_get_colp_resp_msg_v02		g_colp;
voice_get_colr_resp_msg_v02		g_colr;
voice_get_call_forwarding_resp_msg_v02	g_call_forward;
voice_get_call_waiting_resp_msg_v02		g_call_waiting;
//dsji_20130617 add }

//dsji_20130620 add {
uint32	g_clir_n = 0;
uint32 g_clip_n = 0;
uint32 g_colp_n = 0;
//dsji_20130620 add }

//dsji_20150121 add {
voice_call_wait_for_event_complete_type g_voice_call_wait_for_event_complete = VOICE_CALL_WAIT_FOR_EVENT_COMPLETE_TYPE_NONE;

void	enter_voice_call_wait_for_event_complete( voice_call_wait_for_event_complete_type event )
{
  g_voice_call_wait_for_event_complete = event;

  MSG_HIGH( "[VOICE] enter_voice_call_wait_for_event_complete() type:%d", g_voice_call_wait_for_event_complete, 0, 0 );
  //ALOGD( "[VOICE] enter_voice_call_wait_for_event_complete() type:%d", g_voice_call_wait_for_event_complete, 0, 0 );
}

void	leave_voice_call_wait_for_event_complete()
{
  g_voice_call_wait_for_event_complete = VOICE_CALL_WAIT_FOR_EVENT_COMPLETE_TYPE_NONE;

  MSG_HIGH( "[VOICE] leave_voice_call_wait_for_event_complete()", 0, 0, 0 );
  //ALOGD( "[VOICE] leave_voice_call_wait_for_event_complete()", 0, 0, 0 );
}

voice_call_wait_for_event_complete_type	get_voice_call_wait_for_event_complete_type()
{
  //MSG_HIGH( "[VOICE] get_voice_call_wait_for_event_complete_type() type:%d", g_voice_call_wait_for_event_complete, 0, 0 );
  //ALOGD( "[VOICE] get_voice_call_wait_for_event_complete_type() type:%d", g_voice_call_wait_for_event_complete, 0, 0 );
	
  return g_voice_call_wait_for_event_complete;
}
//dsji_20150121 add }

void	update_g_voice_call_end_reason( call_end_reason_enum_v02 reason )
{
	g_voice_call_end_reason = reason;
}



//dsji_20141111 add {
boolean 	can_dial( void )
{
	unsigned int i;

	for ( i = 0; i < g_voice_all_call_info.call_info_len; ++i )	//can dial, if current call count is 0
	{
	  switch ( g_voice_all_call_info.call_info[ i ].call_state )
		{
		//can't dial, while another call is dialing
		case CALL_STATE_CC_IN_PROGRESS_V02:
		case CALL_STATE_ORIGINATING_V02:
		case CALL_STATE_ALERTING_V02:

		//can't dial, while another call is incoming
		case CALL_STATE_SETUP_V02:
		case CALL_STATE_INCOMING_V02:
	  case CALL_STATE_WAITING_V02:

		//can dial, when another call is is conversation or hold state
		//case CALL_STATE_CONVERSATION_V02:
	  //case CALL_STATE_HOLD_V02:
	  
		//can't dial, while another call is disconnecting
	  case CALL_STATE_DISCONNECTING_V02:
		case CALL_STATE_END_V02:
		  {
				MSG_ERROR( "[VOICE] can_dial() : can't dial, i:%d, call_id:%d, call_state:%s",
																i,
					         							g_voice_all_call_info.call_info[ i ].call_id,
					         							get_call_state_string( g_voice_all_call_info.call_info[ i ].call_state ) );
				
				return FALSE;	
			}
			break;
		}	
	}	

	return TRUE;
}
//dsji_20141111 add }



uint8_t	get_voice_call_id( unsigned int voice_call_state_mask )
{
	unsigned int i;
	bool match = FALSE;

	for ( i = 0; i < g_voice_all_call_info.call_info_len; ++i )
	{
		switch ( g_voice_all_call_info.call_info[ i ].call_state )
		{
		case CALL_STATE_ORIGINATING_V02:	if ( voice_call_state_mask & GET_VOICE_CALL_STATE_MASK_ORIGINATING )	match = TRUE; break;
		case CALL_STATE_INCOMING_V02:		if ( voice_call_state_mask & GET_VOICE_CALL_STATE_MASK_INCOMING )		match = TRUE; break;
		case CALL_STATE_CONVERSATION_V02:	if ( voice_call_state_mask & GET_VOICE_CALL_STATE_MASK_CONVERSATION )	match = TRUE; break;
		case CALL_STATE_CC_IN_PROGRESS_V02:	if ( voice_call_state_mask & GET_VOICE_CALL_STATE_MASK_CC_IN_PROGRESS )	match = TRUE; break;
		case CALL_STATE_ALERTING_V02:		if ( voice_call_state_mask & GET_VOICE_CALL_STATE_MASK_ALERTING )		match = TRUE; break;
		case CALL_STATE_HOLD_V02:			if ( voice_call_state_mask & GET_VOICE_CALL_STATE_MASK_HOLD )			match = TRUE; break;
		case CALL_STATE_WAITING_V02:		if ( voice_call_state_mask & GET_VOICE_CALL_STATE_MASK_WAITING )		match = TRUE; break;
		//dsji_20150109 modify {
		case CALL_STATE_DISCONNECTING_V02:
			{
				if ( voice_call_state_mask & GET_VOICE_CALL_STATE_MASK_DISCONNECTING )
				{
					MSG_LOW( "[VOICE] get_voice_call_id() get disconnecting state call, call_id:%d, call_type:%s, direction:%s", 
																g_voice_all_call_info.call_info[ i ].call_id,
																get_call_type_string( g_voice_all_call_info.call_info[ i ].call_type ),
																get_direction_string( g_voice_all_call_info.call_info[ i ].direction ) );
				  match = TRUE;
				}
			}
			break;
		//dsji_20150109 modify }
		case CALL_STATE_END_V02:			if ( voice_call_state_mask & GET_VOICE_CALL_STATE_MASK_END )			match = TRUE; break;
		case CALL_STATE_SETUP_V02:			if ( voice_call_state_mask & GET_VOICE_CALL_STATE_MASK_SETUP )			match = TRUE; break;
		}

		if ( TRUE == match )
			return g_voice_all_call_info.call_info[ i ].call_id;
	}

	return QMI_VOICE_CALL_INVALID_ID;
}



uint8_t	get_active_voice_call_id( void )
{
	return get_voice_call_id( GET_VOICE_CALL_STATE_MASK_ORIGINATING		| 
							  GET_VOICE_CALL_STATE_MASK_INCOMING		|
							  GET_VOICE_CALL_STATE_MASK_CONVERSATION	|
							  GET_VOICE_CALL_STATE_MASK_CC_IN_PROGRESS	|
							  GET_VOICE_CALL_STATE_MASK_ALERTING		|
							  GET_VOICE_CALL_STATE_MASK_SETUP );
}



uint8_t	get_wait_or_background_voice_call_id( void )
{
	return get_voice_call_id( GET_VOICE_CALL_STATE_MASK_HOLD		|
							  GET_VOICE_CALL_STATE_MASK_WAITING );
}


//dsji_20141030 add {
unsigned int 				get_voice_call_current_num()
{
	return g_voice_all_call_info.call_info_len;
}




call_type_enum_v02		get_voice_call_call_type( uint8 call_id )
{
	unsigned int i;
	
	for ( i = 0; i < g_voice_all_call_info.call_info_len; ++i )
	{
	  if ( g_voice_all_call_info.call_info[ i ].call_id == call_id )
  	{
  	  return g_voice_all_call_info.call_info[ i ].call_type;
  	}
	}

	return CALL_TYPE_ENUM_MAX_ENUM_VAL_V02;
}



call_state_enum_v02		get_voice_call_call_state( uint8 call_id )
{
	unsigned int i;
	
	for ( i = 0; i < g_voice_all_call_info.call_info_len; ++i )
	{
	  if ( g_voice_all_call_info.call_info[ i ].call_id == call_id )
  	{
  	  return g_voice_all_call_info.call_info[ i ].call_state;
  	}
	}

	return CALL_STATE_ENUM_MAX_ENUM_VAL_V02;
}
//dsji_20141030 add }




void	qmi_voice_indication_cb( int								user_handle,
								 qmi_service_id_type				service_id,
								 void*								user_data,
								 qmi_voice_indication_id_type		voice_ind_id,
								 void*								voice_ind_data )
{
	switch ( voice_ind_id )
	{
	case QMI_VOICE_CM_IF_CMD_ALL_CALL_STATUS_IND:
		{
			//dsji_20150121 add {
			voice_call_wait_for_event_complete_type event = get_voice_call_wait_for_event_complete_type();

			
			if ( VOICE_CALL_WAIT_FOR_EVENT_COMPLETE_TYPE_NONE == event )
			{
				//Send_UnsolicitedResponse( RIL_UNSOL_RESPONSE_CALL_STATE_CHANGED, NULL, 0 );
				EventNotifyEnqueue(TOF_EVENT_RESPONSE_CALL_STATE_CHANGED, 0, 0);
			}
			else
			{
			  MSG_HIGH( "[VOICE] qmi_voice_indication_cb() don't indicate TOF_EVENT_RESPONSE_CALL_STATE_CHANGED while waiting for event complete, event:%d", event, 0, 0 );
			}
			//dsji_20150121 add }			
		}
		break;

  //--> RIL_UNSOL_CDMA_OTA_PROVISION_STATUS
	case QMI_VOICE_CM_IF_CMD_OTASP_STATUS_IND:
    {
      // Nothing to do.
    }
		break;
  //<-- RIL_UNSOL_CDMA_OTA_PROVISION_STATUS

	case QMI_VOICE_CM_IF_CMD_INVALID_IND:
		break;

		//dsji_20140402 add {
		//dsji_20130702 add {
	case QMI_VOICE_CM_IF_CMD_SUPS_USSD_IND:
		{
			voice_ussd_ind_msg_v02* voice_ussd_ind = (voice_ussd_ind_msg_v02*)voice_ind_data;	//dsji_20140409 bug fix

			if ( FURTHER_USER_ACTION_REQUIRED_V02 == voice_ussd_ind->notification_type )
			{
				voice_answer_ussd_resp_msg_v02 rsp;

				if ( TRUE != request_ussd_answer( &rsp ) )
				{
					//log
				}
			}
			
			TOF_USSD_NOTIFY_INFO tof_ussd_notify_info;
			memset( &tof_ussd_notify_info, 0x0, sizeof( tof_ussd_notify_info ) );
		
//E_USSD_RETTURN_RESULT			= 0x00
//E_USSD_REJECT					= 0x01
//E_USSD_RETTURN_ERROR			= 0x02
//E_USSD_NETWORK_INVOKE			= 0x03
//E_USSD_NOTIFY 				= 0x04

			tof_ussd_notify_info.event_id = 0x04;	//return result
			tof_ussd_notify_info.event_param = 0x00;	//no param
			tof_ussd_notify_info.ussd_context_info.ussd_id = 0x00;	//dummy
			tof_ussd_notify_info.ussd_context_info.dcs = voice_ussd_ind->uss_info.uss_dcs;
			tof_ussd_notify_info.ussd_context_info.data_len = voice_ussd_ind->uss_info.uss_data_len;
			memcpy( tof_ussd_notify_info.ussd_context_info.data_buf, voice_ussd_ind->uss_info.uss_data, voice_ussd_ind->uss_info.uss_data_len );

			//dsji_20150416 add {
			MSG_HIGH( "RIL_UNSOL_HK_USSD_REPORT : %s", tof_ussd_notify_info.ussd_context_info.data_buf, 0, 0 );
			//dsji_20150416 add }
			
			//Send_UnsolicitedResponse( RIL_UNSOL_HK_USSD_REPORT, &ril_ussd_notify_info, sizeof( RIL_USSD_NOTIFY_INFO ) );	
		}
		break;
		//dsji_20130702 add }
		//dsji_20140402 add }

//20161012 yjoh, add eCall ind	
	case QMI_VOICE_CM_IF_CMD_ECALL_EVENT_IND:
	{
	voice_ecall_event_ind_msg_v02* voice_ecall_tx_ind = (voice_ecall_event_ind_msg_v02*)voice_ind_data;
	
	//printf("eCall Tx status ind : %x \n", voice_ecall_tx_ind->ecall_event_ind , 0, 0);
    EventNotifyEnqueue(TOF_EVENT_ECALL_IND,  voice_ecall_tx_ind->ecall_event_ind,0);				
	}
	break;
		
	default:
	  break;
	}

	return;
}



boolean	tof_qmi_voice_init( void )
{

	int r = QMI_INTERNAL_ERR;
	int qmi_err_code = QMI_SERVICE_ERR_NONE;
	unsigned voice_ind_reg_mask;

	memset( &g_voice_all_call_info, 0x0, sizeof( g_voice_all_call_info ) );

	if(g_voice_client_handle != QMI_INVALID_CLIENT_HANDLE) return RESULT_SUCCESS;

	/* Bring up voice service for second port */
  if ((g_voice_client_handle = tof_qmi_voice_srvc_init_client (QMI_PORT_RMNET_0,
                                                 qmi_voice_indication_cb, // callback function. 
                                                 NULL, 
                                                 &qmi_err_code)) < 0)
  {
    MSG_ERROR("Unable to start VOICE service voice_client_handle= %x, qmi_err_code=%x\n", 
           g_voice_client_handle, 
           qmi_err_code,
           0);
    return RESULT_FAILURE;
  }
  else
  {
    MSG_HIGH("Opened VOICE Client. voice_client_handle= %x \r\n", g_voice_client_handle,0,0);
  }

	/*Event Register*/
	
  voice_ind_reg_mask = ( VOICE_IND_REG_MASK_DTMF	|
                         VOICE_IND_REG_MASK_CALL_EVENTS_NOTIFY |
                         VOICE_IND_REG_MASK_SPEECH_NOTIFY|
                		 VOICE_IND_REG_MASK_ECALL_EVENT_NOTIFY //20161012 yjoh, add eCall ind
	);
	
	r = qmi_voice_indication_register( (int)g_voice_client_handle,
								   voice_ind_reg_mask,
								   &qmi_err_code );
		
	if ( QMI_NO_ERR != r || QMI_SERVICE_ERR_NONE != qmi_err_code )
	{
		MSG_ERROR( "[VOICE] qmi_voice_indication_register() fail, error:%d, qmi error:%d", r, qmi_err_code,0);
		return RESULT_FAILURE;
	}

  return RESULT_SUCCESS;
}



boolean	tof_qmi_voice_release( void )
{
	int qmi_err_code = QMI_INTERNAL_ERR;
  int rc = QMI_NO_ERR;

  if(g_voice_client_handle == QMI_INVALID_CLIENT_HANDLE) return RESULT_SUCCESS;
   
  if(g_voice_client_handle != QMI_INVALID_CLIENT_HANDLE)
  {
    rc = tof_tof_qmi_voice_srvc_release_client(g_voice_client_handle, &qmi_err_code);
    if(rc != QMI_NO_ERR)
    {
      MSG_HIGH("tof_tof_qmi_voice_srvc_release_client rc = %d, qmi_err_code \n", rc, qmi_err_code,0);
      return RESULT_FAILURE;
    } 
  }
  else
  {
    MSG_ERROR("tof_qmi_release voice_client_handle= %x\r\n", g_voice_client_handle,0,0);
  }

  return RESULT_SUCCESS;
}

bool	request_get_current_calls( void )
{
  int i=0, r = QMI_NO_ERR;
  call_type_enum_v02 call_type;

  voice_get_all_call_info_resp_msg_v02	rsp;

  memset( &rsp, 0x0, sizeof( rsp ) );

  r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_GET_ALL_CALL_INFO_REQ_V02,
						   NULL,
						   (void*)&rsp,
						   NULL,
						   NULL );

  if ( QMI_NO_ERR != r )
  {
    MSG_ERROR( "[VOICE] request_get_current_calls() fail, error:%d", r, 0, 0 );
    return FALSE;
  }

  if ( QMI_RESULT_SUCCESS_V01 != rsp.resp.result )
  {
    MSG_ERROR( "[VOICE] request_get_current_calls() rsp fail, error:%d", rsp.resp.error, 0, 0 );
    return FALSE;
  }

  update_g_voice_all_call_info( &rsp );

  for(i=0; i<g_voice_all_call_info.call_info_len; i++)
  {
    // 20130925_jgkim convert call type
    call_type = convert_call_state(g_voice_all_call_info.call_info[ i ].direction,
                                   g_voice_all_call_info.call_info[ i ].call_type,
                                   g_voice_all_call_info.call_info[ i ].call_state,
                                   g_voice_speech_codec);

    MSG_HIGH("[VOICE] current_call_info : call_id = %d call_type = %s call_state = %s", 
                      g_voice_all_call_info.call_info[ i ].call_id,
                      get_call_type_string( call_type ),
                      get_call_state_string( g_voice_all_call_info.call_info[ i ].call_state ));
 
  }

	return TRUE;
}



bool	request_dial( TOF_Dial *tof_dial )
{
	int r = QMI_NO_ERR;

	voice_dial_call_req_msg_v02		req;
	voice_dial_call_resp_msg_v02	rsp;

  uint8 hd_voice = 0;
  uint8 ret = RESULT_SUCCESS;
	  
  uint32 nw_reg_status_overview; //VOLTE_CALL_TYPE

  //dsji_20141111 modify {
	if ( FALSE == can_dial() )
	{
	  MSG_ERROR( "[VOICE] request_dial() : can_dial() fail", 0, 0, 0 );
		return FALSE;	
	}
	//dsji_20141111 modify }
	
	memset( &req, 0x0, sizeof( req ) );
	memset( &rsp, 0x0, sizeof( rsp ) );

    if(tof_dial->address == NULL)
    {
      MSG_ERROR("[VOICE] request_dial() : Dial Number is empty",0,0,0);
      return FALSE;
    }

	strcpy( req.calling_number, tof_dial->address );

	//dsji_20130620 add {
	switch ( g_clir_n )
	{
	case 1:
		{
			req.clir_type_valid = TRUE; 
			req.clir_type = CLIR_INVOCATION_V02;
		}
		break;
		
	case 2:
		{
			req.clir_type_valid = TRUE;
			req.clir_type = CLIR_SUPPRESSION_V02;
		}
		break;
	}
	//dsji_20130620 add }

//--> VOLTE_CALL_TYPE
  if((wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW) || (wmm_get_vendor_type() == WMM_VENDOR_C_TCU_VZW))
  {
    nw_reg_status_overview = qmi_ril_nw_reg_get_status_overview();
    MSG_HIGH(".. nw reg status overview %d", (int)nw_reg_status_overview, 0, 0);

    req.call_type_valid = TRUE;
	
    ret = ril_request_get_ims_qipcall_info(&hd_voice);
    MSG_HIGH("[request_dial]GET_VoLTE = %d", hd_voice,0,0);

    if(( QMI_RIL_NW_REG_VOIP_CALLS_AVAILABLE & nw_reg_status_overview ) && (hd_voice == TRUE))
    {
      req.call_type = CALL_TYPE_VOICE_IP_V02; //CALL_TYPE_VOICE_IP : do VOIP whenever we can use it
    }
    else
    {
      req.call_type = CALL_TYPE_VOICE_V02;
    }
  }
//<-- VOLTE_CALL_TYPE
	
	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_DIAL_CALL_REQ_V02,
						   (void*)&req,
						   (void*)&rsp,
						   NULL,
						   NULL );

	if ( TRUE == rsp.end_reason_valid )
		MSG_ERROR( "[VOICE] request_dial() end_reason_valid, reason :%d", rsp.end_reason, 0, 0 );
		update_g_voice_call_end_reason( rsp.end_reason );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[VOICE] request_dial() fail, error:%d", r, 0, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != rsp.resp.result )
	{
		MSG_ERROR( "[VOICE] request_dial() rsp fail, error:%d", rsp.resp.error, 0, 0 );
		return FALSE;
	}

	return TRUE;
}

/*=========================================================
	FUNCTION	: REQUEST_ECALL_DIAL [request_ecall_dial]

	DESCRIPTION

	DEPENDENCIES

	RETURN VALUES

	SIDE EFFECTS

	NOTES
		20160921	SH.Lee		Created.
=========================================================*/
bool	request_ecall_dial( int mode )
{
  int r = QMI_NO_ERR;

  voice_dial_call_req_msg_v02		req;
  voice_dial_call_resp_msg_v02	rsp;

  uint8 ret = RESULT_SUCCESS;
	  
// LGInnotek-SH.Lee-20160921, Need to check how to operate when eCall/ERA Glonass are triggerred while VOLTE is connected
//	  uint32 nw_reg_status_overview; //VOLTE_CALL_TYPE

// LGInnotek-SH.Lee-20160921, Need to check how to operate when eCall/ERA Glonass are triggerred while other voice call is activated.
//		if ( FALSE == can_dial() )
//		{
//		  MSG_ERROR( "[VOICE] request_ecall_dial() : can_dial() fail", 0, 0, 0 );
//			return FALSE;	
//		}
	
  memset( &req, 0x0, sizeof( req ) );
  memset( &rsp, 0x0, sizeof( rsp ) );

  if(mode < 0 || mode > 3)
  {
    MSG_ERROR("[VOICE]request_ecall_dial : Invalid argument[%d] \n",mode,0,0);
    return FALSE;
  }

// LGInnotek-SH.Lee-20160921, Need to add vendor typr if it is fixed
//  if(wmm_get_vendor_type() == WMM_VENDOR_C_TCU_JPN )
//  {
//	    nw_reg_status_overview = qmi_ril_nw_reg_get_status_overview();
//	    MSG_HIGH(".. nw reg status overview %d", (int)nw_reg_status_overview, 0, 0);
//	
  req.call_type_valid = TRUE;
  req.call_type = CALL_TYPE_ECALL_V02;

  req.emer_cat_valid = TRUE;
  req.ecall_variant_valid = TRUE;
  switch(mode)
  {
    case 0: //test call
      req.ecall_variant = ECALL_TEST_V02;
      req.emer_cat = 0x20;
    break;

    case 1: //reconfig call
      req.ecall_variant = ECALL_RECONFIG_V02;
    break;

    case 2: //manual
      req.ecall_variant = ECALL_EMERGENCY_V02;
      req.emer_cat = 0x20;
    break;

    case 3: //auto
      req.ecall_variant = ECALL_EMERGENCY_V02;
      req.emer_cat = 0x40;
    break;
  }
//  }
	
  r = qmi_voice_msg_req( (int)g_voice_client_handle,
		   QMI_VOICE_DIAL_CALL_REQ_V02,
		   (void*)&req,
		   (void*)&rsp,
		   NULL,
		   NULL );

  if ( TRUE == rsp.end_reason_valid )
    update_g_voice_call_end_reason( rsp.end_reason );

  if ( QMI_NO_ERR != r )
  {
    MSG_ERROR( "[ECALL] request_ecall_dial() fail, error:%d, rsp.end_reason:%d", r, rsp.end_reason, 0 );
    return FALSE;
  }

  if ( QMI_RESULT_SUCCESS_V01 != rsp.resp.result )
  {
    MSG_ERROR( "[ECALL] request_ecall_dial() rsp fail, error:%d", rsp.resp.error, 0, 0 );
    return FALSE;
  }

  return TRUE;
}

//20160921 yjoh
#define  UPCASE( c ) ( ((c) >= 'a' && (c) <= 'z') ? ((c) - 0x20) : (c) )
#define MAX_VAL_NUM_ITEM 0xFFFFFFFF /*  Max value of a numeric AT parm     */
static bool asciiToInteger
(
  uint8 *val_arg_ptr,      /*  value returned  */
  const byte *s,                        /*  points to string to eval  */
  unsigned int r                        /*  radix */
)
{
  byte c;
  unsigned int val, val_lim, dig_lim;
  int i = 0;

  val = 0;
  val_lim =  ((unsigned int)MAX_VAL_NUM_ITEM / r);
  dig_lim =  ((unsigned int)MAX_VAL_NUM_ITEM % r);
  while ( (c = *s++) != '\0')
  {
    if (c != ' ')
    {
      c = (byte) UPCASE (c);
      if (c >= '0' && c <= '9')
      {
        c -= '0';
      }
      else if (c >= 'A')
      {
        c -= 'A' - 10;
      }
       else
      {
	      	MSG_ERROR( "[ECALL] asciiToInteger() fail, char code too small %c",c, 0, 0 );
	       return FALSE;
      }
      if (c >= r || val > val_lim
          || (val == val_lim && c > dig_lim))
      {
	      MSG_ERROR( "[ECALL] asciiToInteger() fail, char code too large", 0, 0, 0 );
	      return FALSE;
      }
      else
      {
        val = c;
		//MSG_ERROR( "[ECALL] asciiToInteger(), val = %c ", c, 0, 0 );
      }
	  
    }
    val_arg_ptr[i] =  val;
	i++;
  }

  if ( i% 2 != 0 )
  {
	      MSG_ERROR( "[ECALL] asciiToInteger() fail, it is odd number ", 0, 0, 0 );
	      return FALSE;
  }
  return TRUE;

}

bool	request_ecall_set_msd(int mode, char* msd_data)
{
	int r = QMI_NO_ERR;
    bool result = TRUE;
	voice_set_ecall_msd_req_msg_v02	req;
	voice_set_ecall_msd_resp_msg_v02	rsp;

	uint8 ret = RESULT_SUCCESS;

	int i=0;
	int j=0;
	uint8 msd_input[ECALL_MSD_MAX_LEN ]={0,};
	uint8 temp_msd_array[ECALL_MSD_MAX_LEN  * 2 +1 ] = {0,};

	memset( &req, 0x0, sizeof( req ) );
	memset( &rsp, 0x0, sizeof( rsp ) );
	memset(&msd_input, 0, sizeof(msd_input));
	memset(&temp_msd_array, 0, sizeof(temp_msd_array));

//convert 
	result=asciiToInteger(temp_msd_array, msd_data, 16);

	if ( result != TRUE )
	{
		MSG_ERROR( "[ECALL] asciiToInteger() fail, OUT_OF_RANGE", 0, 0, 0 );
		return FALSE;
	}
	
	for(i=0 ; i < ECALL_MSD_MAX_LEN  * 2 ; i+=2 )
	{
		msd_input[j] = ( temp_msd_array[i] * 16 ) + temp_msd_array[i+1];
		//MSG_HIGH("[ECALL] msd_input[%d]: %x", j, msd_input[j],0);
		j++;
	}

  switch(mode)
  {
    case 0: //PUSH
		req.ecall_tx_mode=0x00;
    break;
		
	case 1: //pull
		req.ecall_tx_mode=0x01;
    break;
		
  	}
	req.ecall_msd_valid = TRUE;
	req.ecall_msd_len =ECALL_MSD_MAX_LEN;
	memcpy(req.ecall_msd,msd_input,ECALL_MSD_MAX_LEN);

	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_ECALL_SET_MSD_V02,
						   (void*)&req,
						   (void*)&rsp,
						   NULL,
						   NULL );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[ECALL] request_ecall_set_msd() fail, error:%d", r, 0, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != rsp.resp.result )
	{
		MSG_ERROR( "[ECALL] request_ecall_set_msd() rsp fail, error:%d", rsp.resp.error, 0, 0 );
		return FALSE;
	}

	return TRUE;
}

//dsji_20150121 add {
bool 	check_hangup_complete( uint8 call_id )
{
	int check_hangup_complete_timeout = 40;		//timeout is 6 sec( = 0.15 sec x 40 )
	int i;

	enter_voice_call_wait_for_event_complete( VOICE_CALL_WAIT_FOR_EVENT_COMPLETE_TYPE_HANGUP );

	for ( i = 0; i < check_hangup_complete_timeout; ++i )	//check for 6 sec
	{
	  //local_msleep( 150 );	//check per 0.15 sec
	  usleep(150*1000);//check per 0.5 sec

		if ( TRUE == request_get_current_calls() )
		{
			call_state_enum_v02 call_state = get_voice_call_call_state( call_id );

			MSG_HIGH( "[VOICE] check_hangup_complete() request_get_current_calls() ok, call_id:%d, call_state:%s", call_id, get_call_state_string( call_state ), 0 );

			switch ( call_state )
			{
			case CALL_STATE_ORIGINATING_V02:			//impossible
		  case CALL_STATE_CC_IN_PROGRESS_V02:		//impossible
		  case CALL_STATE_ALERTING_V02:					//impossible
		  case CALL_STATE_CONVERSATION_V02:			//impossible
		  case CALL_STATE_HOLD_V02:							//impossible
		  case CALL_STATE_DISCONNECTING_V02:		//not hangup yet
		  case CALL_STATE_END_V02:							//not hangup yet
		  	{
		  	}
				break;

		  case CALL_STATE_INCOMING_V02:	//maybe hangup complete and new call incoming immediately, so think hangup complete
		  case CALL_STATE_WAITING_V02:	//maybe hangup complete and new call incoming immediately, so think hangup complete
		  case CALL_STATE_SETUP_V02:		//maybe hangup complete and new call incoming immediately, so think hangup complete
		  case CALL_STATE_ENUM_MAX_ENUM_VAL_V02:	//hangup complete
		  	{
					leave_voice_call_wait_for_event_complete();
					EventNotifyEnqueue(TOF_EVENT_RESPONSE_CALL_STATE_CHANGED_TO_DELAYED_HANGUP, (uint32)call_id, 0); //jaeyong1.park 2017-01-11 AS057-1077
					MSG_HIGH( "[VOICE] check_hangup_complete() hangup complete!", 0, 0, 0 );
					
					return TRUE;
		  	}
		  	break;
			}
		}
		else
		{
			MSG_ERROR( "[VOICE] check_hangup_complete() request_get_current_calls() fail", 0, 0, 0 );
		}

		MSG_HIGH( "[VOICE] check_hangup_complete() waiting for hangup complete... %d msec", ( ( i + 1 ) * 150 ), 0, 0 );	
	}

	leave_voice_call_wait_for_event_complete();

	MSG_ERROR( "[VOICE] check_hangup_complete() hangup not complete", 0, 0, 0 );

	return FALSE;
}
//dsji_20150121 add }



//dsji_20141111 modify {
bool	request_hangup( uint8 call_id )
{
	int r = QMI_NO_ERR;

	voice_end_call_req_msg_v02	req;
	voice_end_call_resp_msg_v02	rsp;

	memset( &req, 0x0, sizeof( req ) );
	memset( &rsp, 0x0, sizeof( rsp ) );

	req.call_id = call_id;

	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_END_CALL_REQ_V02,
						   (void*)&req,
						   (void*)&rsp,
						   NULL,
						   NULL );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[VOICE] request_hangup() fail, error:%d", r, 0, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != rsp.resp.result )
	{
		MSG_ERROR( "[VOICE] request_hangup() rsp fail, error:%d", rsp.resp.error, 0, 0 );
		return FALSE;
	}

	return check_hangup_complete( call_id );	//dsji_20150121 add
}
//dsji_20141111 modify }

/*-----------------------------------------------------------------------------------------
request_hangup_all_voice_call()
-----------------------------------------------------------------------------------------*/
bool	request_hangup_all_voice_call( void )
{
	//dsji_20141111 modify {
  if((wmm_get_vendor_type() != WMM_VENDOR_I_LTE_VZW ) && ( wmm_get_vendor_type() != WMM_VENDOR_I_LTE_VZW ))
  {
    bool result = TRUE;
	  unsigned int i;

		for ( i = 0; i < g_voice_all_call_info.call_info_len; ++i )
		{
		  switch ( g_voice_all_call_info.call_info[ i ].call_state )
			{
			case CALL_STATE_CC_IN_PROGRESS_V02:
			case CALL_STATE_ORIGINATING_V02:
			case CALL_STATE_ALERTING_V02:

			case CALL_STATE_SETUP_V02:
			case CALL_STATE_INCOMING_V02:
		  case CALL_STATE_WAITING_V02:

			case CALL_STATE_CONVERSATION_V02:
		  case CALL_STATE_HOLD_V02:

			case CALL_STATE_DISCONNECTING_V02:	//dsji_20150109 modify, to end disconnecting state call
			//no need to hangup, already hangup
			//case CALL_STATE_END_V02:
			  {
					if ( FALSE == request_hangup( g_voice_all_call_info.call_info[ i ].call_id ) )
					{
						MSG_ERROR( "[VOICE] request_hangup_all_voice_call() : fail, i:%d, call_id:%d, call_state:%s",
						         i,
						         g_voice_all_call_info.call_info[ i ].call_id,
						         get_call_state_string( g_voice_all_call_info.call_info[ i ].call_state ) );

						result = FALSE;	//at least one call is fail, request_hangup_all_voice_call() is fail
				  }
		    }
 			  break;
		  }
		}

		return result;
  }
	//dsji_20141111 modify }
	
	return request_manage_calls( SUPS_TYPE_END_ALL_CALLS_V02 );
}


//dsji_20141111 modify {
/*
* MO call sequence
	CC_IN_PROGRESS -> ORIGINATING -> ALERTING -> CONVERSATION

* MT call sequence
	in case of FG call is exist(etc.CONVERSATION)
		CC_SETUP(CSFB only) -> WAITING -> CONVERSATION

	in case of BG call is exist(etc.HOLD)
		CC_SETUP(CSFB only) -> INCOMING -> CONVERSATION

* end call sequence
	CONVERSATION -> DISCONNECTING(CSFB only) -> END

* decide FG or BG call by call state
	CC_IN_PROGRESS	-> FG call
	ORIGINATING			-> FG call
	ALERTING				-> FG call

	SETUP						-> FG call with INCOMING, BG call with WAITING
	INCOMING				-> FG call
	WAITING					-> BG call

	CONVERSATION		-> FG call
	HOLD						-> BG call

	DISCONNECTING		-> FG or BG call
	END							-> FG or BG call
*/
bool	request_hangup_waiting_or_background( void )
{
  if ((wmm_get_vendor_type() != WMM_VENDOR_I_LTE_VZW ) && ( wmm_get_vendor_type() != WMM_VENDOR_I_LTE_VZW ))
	{
		uint8_t hangup_call_id;
		
		switch ( get_voice_call_current_num() )
		{
		case 1:
			{
				hangup_call_id = get_voice_call_id( GET_VOICE_CALL_STATE_MASK_SETUP |							//FG or BG call, but decide to hangup
																							GET_VOICE_CALL_STATE_MASK_INCOMING |					//FG call, but decide to hangup(QCT's action)
																							GET_VOICE_CALL_STATE_MASK_WAITING | 					//BG call, hangup
																							GET_VOICE_CALL_STATE_MASK_DISCONNECTING |			//FG or BG call, but decide to hangup	//dsji_20150109 modify, to end disconnecting state call
																							GET_VOICE_CALL_STATE_MASK_HOLD );							//BG call, hangup
																							//GET_VOICE_CALL_STATE_MASK_CC_IN_PROGRESS		//FG call
																							//GET_VOICE_CALL_STATE_MASK_ORIGINATING				//FG call
																							//GET_VOICE_CALL_STATE_MASK_ALERTING					//FG call
																							//GET_VOICE_CALL_STATE_MASK_CONVERSATION			//FG call
																							//GET_VOICE_CALL_STATE_MASK_END								//already hangup
			}
			break;

		case 2:
			{
				hangup_call_id = get_voice_call_id( GET_VOICE_CALL_STATE_MASK_SETUP |							//FG or BG call, but decide to hangup
																							GET_VOICE_CALL_STATE_MASK_WAITING | 					//BG call, hangup
																							GET_VOICE_CALL_STATE_MASK_HOLD );							//BG call, hangup
																							//GET_VOICE_CALL_STATE_MASK_CC_IN_PROGRESS		//FG call
																							//GET_VOICE_CALL_STATE_MASK_ORIGINATING				//FG call
																							//GET_VOICE_CALL_STATE_MASK_ALERTING					//FG call
																							//GET_VOICE_CALL_STATE_MASK_INCOMING					//FG call
																							//GET_VOICE_CALL_STATE_MASK_CONVERSATION			//FG call
																							//GET_VOICE_CALL_STATE_MASK_DISCONNECTING			//already hangup
																							//GET_VOICE_CALL_STATE_MASK_END								//already hangup

				//dsji_20150109 add { to end disconnecting state call
				//no BG call
				if ( QMI_VOICE_CALL_INVALID_ID == hangup_call_id )
				{
					//no FG call					
					if ( QMI_VOICE_CALL_INVALID_ID == get_voice_call_id( GET_VOICE_CALL_STATE_MASK_CC_IN_PROGRESS | 
																																 GET_VOICE_CALL_STATE_MASK_ORIGINATING |
																																 GET_VOICE_CALL_STATE_MASK_ALERTING |
																																 GET_VOICE_CALL_STATE_MASK_INCOMING |
																																 GET_VOICE_CALL_STATE_MASK_CONVERSATION ) )
					{
						//only remain DISCONNECTING or END call, but we don't know that this call is FG or BG call... just hang up!
						hangup_call_id = get_voice_call_id( GET_VOICE_CALL_STATE_MASK_DISCONNECTING );
					}
				}											
				//dsji_20150109 add }
			}
			break;

		default:
			{
	    	MSG_ERROR( "[VOICE] request_hangup_waiting_or_background() : can't process over 2 call", 0, 0, 0 );

				return FALSE;
			}
			break;
		}
																								
		if ( QMI_VOICE_CALL_INVALID_ID != hangup_call_id )
		{
	    MSG_HIGH( "[VOICE] request_hangup_waiting_or_background() : request_hangup(), hangup_call_id:%d", hangup_call_id, 0, 0 );	
		
			return request_hangup( hangup_call_id );
		}
		else
		{
    	MSG_ERROR( "[VOICE] request_hangup_waiting_or_background() : no call to hangup", 0, 0, 0 );	
			
			return FALSE;
		}
  }	
	
	return request_manage_calls( SUPS_TYPE_RELEASE_HELD_OR_WAITING_V02 );
}



bool	request_hangup_foreground_resume_background( void )
{
  if ((wmm_get_vendor_type() != WMM_VENDOR_I_LTE_VZW ) && ( wmm_get_vendor_type() != WMM_VENDOR_I_LTE_VZW ))
	{
		uint8_t hangup_call_id, resume_call_id;

		switch ( get_voice_call_current_num() )
		{
		case 1:	//in case of 1 call
			{
				resume_call_id = get_voice_call_id( GET_VOICE_CALL_STATE_MASK_HOLD );

				//in case of 1 call, hold call is the only BG call. so if have a hold call, retrive it
				if ( QMI_VOICE_CALL_INVALID_ID != resume_call_id )
				{
		    	MSG_HIGH( "[VOICE] request_hangup_foreground_resume_background() : request_switch_waiting_or_holding_and_active(), resume_call_id:%d", resume_call_id, 0, 0 );	
					
					return request_switch_waiting_or_holding_and_active();
				}
				//if don't have a hold call, there is no more BG call. so hangup FG call
				else
				{
					hangup_call_id = get_voice_call_id( GET_VOICE_CALL_STATE_MASK_CC_IN_PROGRESS | 				//FG call, hangup
																								GET_VOICE_CALL_STATE_MASK_ORIGINATING |						//FG call, hangup
																								GET_VOICE_CALL_STATE_MASK_ALERTING |							//FG call, hangup
																								GET_VOICE_CALL_STATE_MASK_SETUP |									//FG call in 1 call, hangup
																								GET_VOICE_CALL_STATE_MASK_INCOMING |							//FG call, hangup
																								GET_VOICE_CALL_STATE_MASK_CONVERSATION |					//FG call, hangup
																							  GET_VOICE_CALL_STATE_MASK_DISCONNECTING |					//FG or BG call, but decide to hangup	//dsji_20150109 modify, to end disconnecting state call
																								GET_VOICE_CALL_STATE_MASK_WAITING );							//impossible state in 1 call, but decide to hangup
																							//GET_VOICE_CALL_STATE_MASK_HOLD								//already check above, not exist
																							//GET_VOICE_CALL_STATE_MASK_END									//already hangup
																							
					if ( QMI_VOICE_CALL_INVALID_ID != hangup_call_id )
					{
			    	MSG_HIGH( "[VOICE] request_hangup_foreground_resume_background() : request_hangup(), hangup_call_id:%d", hangup_call_id, 0, 0 );	

						return request_hangup( hangup_call_id );
					}
					else
					{				
		    		MSG_ERROR( "[VOICE] request_hangup_foreground_resume_background() : no call to hangup", 0, 0, 0 );
						
						return FALSE;
					}
				}
			}
			break;

		case 2:	//in case of 2 call
			{
				hangup_call_id = get_voice_call_id( GET_VOICE_CALL_STATE_MASK_CONVERSATION );
				
				resume_call_id = get_voice_call_id( GET_VOICE_CALL_STATE_MASK_SETUP |
																							GET_VOICE_CALL_STATE_MASK_WAITING |
																							GET_VOICE_CALL_STATE_MASK_HOLD );
				
				if ( QMI_VOICE_CALL_INVALID_ID != hangup_call_id )
				{
					if ( QMI_VOICE_CALL_INVALID_ID != resume_call_id )
					{
						//FG call(CONVERSATION)
						//BG call(SETUP or WAITING or HOLD)
						
			    	MSG_HIGH( "[VOICE] request_hangup_foreground_resume_background() : request_manage_calls(), hangup_call_id:%d, resume_call_id:%d", hangup_call_id, resume_call_id, 0 );	
					
						return request_manage_calls( SUPS_TYPE_RELEASE_ACTIVE_ACCEPT_HELD_OR_WAITING_V02 );
					}
					else
					{
						//FG call(CONVERSATION)
						//BG call(no SETUP and no WAITING and no HOLD)
						
						//possible BG call state is like below
						
						//CC_IN_PROGRESS			//before 1 conversation call is changing to HOLD state, it is possible.
						//ORIGINATING					//before 1 conversation call is changing to HOLD state, it is possible.
						if ( QMI_VOICE_CALL_INVALID_ID != get_voice_call_id( GET_VOICE_CALL_STATE_MASK_CC_IN_PROGRESS | 
																																	 GET_VOICE_CALL_STATE_MASK_ORIGINATING ) )
						{
			    		MSG_ERROR( "[VOICE] request_hangup_foreground_resume_background() : can't process in ORIGINATING state", 0, 0, 0 );
							
							return FALSE;
						}
						
						//ALERTING						//impossible state in existing 1 conversation call
						//SETUP								//already check above, not exist
						//INCOMING						//impossible state in existing 1 conversation call
						//WAITING							//already check above, not exist
						//HOLD								//already check above, not exist
						//CONVERSATION				//already check above, exist
						//DISCONNECTING				//already hangup, if FG call, no need to hangup. if BG call, can't resume
						//END									//already hangup, if FG call, no need to hangup. if BG call, can't resume

						//as a result, possible BG call state is DISCONNECTING or END. so no need to process about BG call and hangup FG call

			    	MSG_HIGH( "[VOICE] request_hangup_foreground_resume_background() : request_hangup(), hangup_call_id:%d", hangup_call_id, 0, 0 );

						return request_hangup( hangup_call_id );
					}
				}
				else
				{
					if ( QMI_VOICE_CALL_INVALID_ID != resume_call_id )
					{
						//FG call(no CONVERSATION)
						//BG call(SETUP or WAITING or HOLD)
						
						hangup_call_id = get_voice_call_id( GET_VOICE_CALL_STATE_MASK_CC_IN_PROGRESS |		//FG call, hangup
																									GET_VOICE_CALL_STATE_MASK_ORIGINATING |				//FG call, hangup
																									GET_VOICE_CALL_STATE_MASK_ALERTING |					//FG call, hangup
																								  GET_VOICE_CALL_STATE_MASK_DISCONNECTING |			//FG or BG call, but decide to hangup	//dsji_20150109 modify, to end disconnecting state call
																									GET_VOICE_CALL_STATE_MASK_INCOMING );					//FG call, hangup
																								//GET_VOICE_CALL_STATE_MASK_CONVERSATION		//already check above, not exist
																								//GET_VOICE_CALL_STATE_MASK_SETUP						//BG call
																								//GET_VOICE_CALL_STATE_MASK_WAITING					//BG call
																								//GET_VOICE_CALL_STATE_MASK_HOLD						//BG call
																								//GET_VOICE_CALL_STATE_MASK_END							//already hangup
																								
						if ( QMI_VOICE_CALL_INVALID_ID != hangup_call_id )
						{
				    	MSG_HIGH( "[VOICE] request_hangup_foreground_resume_background() : request_hangup(), hangup_call_id:%d", hangup_call_id, 0, 0 );	
						
							return request_hangup( hangup_call_id );

							//we should call request_switch_waiting_or_holding_and_active() function at this point to resume BG call
							//but it doesn't work(QCT's default action)
							//so we depend on exception code
							//afer calling request_get_current_calls(), if there is one hold call, we call request_switch_waiting_or_holding_and_active() function
							//then hold call is retrieved.
						}
						else
						{
			    		MSG_ERROR( "[VOICE] request_hangup_foreground_resume_background() : no call to hangup", 0, 0, 0 );
							
							return FALSE;
						}
					}
					else
					{
						//FG call(no CONVERSATION)
						//BG call(no SETUP and no WAITING and no HOLD)
					
						hangup_call_id = get_voice_call_id( GET_VOICE_CALL_STATE_MASK_CC_IN_PROGRESS |		//FG call, hangup
																									GET_VOICE_CALL_STATE_MASK_ORIGINATING |				//FG call, hangup
																									GET_VOICE_CALL_STATE_MASK_INCOMING |					//FG call, hangup
																									GET_VOICE_CALL_STATE_MASK_ALERTING );					//FG call, hangup
																								//GET_VOICE_CALL_STATE_MASK_SETUP						//already check above, not exist
																								//GET_VOICE_CALL_STATE_MASK_WAITING					//already check above, not exist
																								//GET_VOICE_CALL_STATE_MASK_CONVERSATION		//already check above, not exist
																								//GET_VOICE_CALL_STATE_MASK_HOLD						//already check above, not exist
																								//GET_VOICE_CALL_STATE_MASK_DISCONNECTING		//check below
																								//GET_VOICE_CALL_STATE_MASK_END							//already hangup
																								
						//dsji_20150109 add { to end disconnecting state call
						//no FG call
						if ( QMI_VOICE_CALL_INVALID_ID == hangup_call_id )
						{
						  //only remain DISCONNECTING or END call, but we don't know that this call is FG or BG call... just hang up!
						  hangup_call_id = get_voice_call_id( GET_VOICE_CALL_STATE_MASK_DISCONNECTING );
						}
						//dsji_20150109 add }
						
						if ( QMI_VOICE_CALL_INVALID_ID != hangup_call_id )
						{
				    	MSG_HIGH( "[VOICE] request_hangup_foreground_resume_background() : request_hangup(), hangup_call_id:%d", hangup_call_id, 0, 0 );	

							return request_hangup( hangup_call_id );
						}
						else
						{
			    		MSG_ERROR( "[VOICE] request_hangup_foreground_resume_background() : no call to hangup", 0, 0, 0 );
							
							return FALSE;
						}
					}
				}				
			}
			break;

		default:
			{
	    	MSG_ERROR( "[VOICE] request_hangup_foreground_resume_background() : can't process over 2 call", 0, 0, 0 );
				
				return FALSE;
			}
			break;
		}
  }

	return request_manage_calls( SUPS_TYPE_RELEASE_ACTIVE_ACCEPT_HELD_OR_WAITING_V02 );
}



bool	request_switch_waiting_or_holding_and_active( void )
{
  if ((wmm_get_vendor_type() != WMM_VENDOR_I_LTE_VZW ) && ( wmm_get_vendor_type() != WMM_VENDOR_I_LTE_VZW ))
	{
		uint8_t hold_call_id, resume_call_id;
		request_get_current_calls();//jaeyong1.park AS057-1117

		resume_call_id = get_voice_call_id( GET_VOICE_CALL_STATE_MASK_HOLD |
																					GET_VOICE_CALL_STATE_MASK_SETUP |
																					GET_VOICE_CALL_STATE_MASK_WAITING );

		hold_call_id = get_voice_call_id( GET_VOICE_CALL_STATE_MASK_CONVERSATION );

		switch ( get_voice_call_current_num() )
		{
		case 1:
			{
				if ( QMI_VOICE_CALL_INVALID_ID != resume_call_id || QMI_VOICE_CALL_INVALID_ID != hold_call_id )
				{
	    		MSG_HIGH( "[VOICE] request_switch_waiting_or_holding_and_active() : request_manage_calls(), resume_call_id:%d, hold_call_id:%d", resume_call_id, hold_call_id, 0 );
					
					return request_manage_calls( SUPS_TYPE_HOLD_ACTIVE_ACCEPT_WAITING_OR_HELD_V02 );
				}
				else
				{
	    		MSG_ERROR( "[VOICE] request_switch_waiting_or_holding_and_active() : resume or hold call id must be exist", 0, 0, 0 );

				  return FALSE;
				}
			}
			break;

		case 2:
			{
				if ( QMI_VOICE_CALL_INVALID_ID != resume_call_id && QMI_VOICE_CALL_INVALID_ID != hold_call_id )
				{
	    		MSG_HIGH( "[VOICE] request_switch_waiting_or_holding_and_active() : request_manage_calls(), resume_call_id:%d, hold_call_id:%d", resume_call_id, hold_call_id, 0 );
					
					return request_manage_calls( SUPS_TYPE_HOLD_ACTIVE_ACCEPT_WAITING_OR_HELD_V02 );
				}
				else
				{
	    		MSG_ERROR( "[VOICE] request_switch_waiting_or_holding_and_active() : resume and hold call id must be exist, resume_call_id:%d, hold_call_id:%d", resume_call_id, hold_call_id, 0 );

				  return FALSE;
				}
			}
			break;

		default:
			{
			MSG_ERROR( "[VOICE] request_switch_waiting_or_holding_and_active() : can't process over 2 call, current num of calls :%d ", get_voice_call_current_num(), 0, 0 );
				return FALSE;
			}
			break;
		}
  }
	
	return request_manage_calls( SUPS_TYPE_HOLD_ACTIVE_ACCEPT_WAITING_OR_HELD_V02 );
}
//dsji_20141111 modify }



bool	request_last_call_fail_cause( call_end_reason_enum_v02* cause )
{

	//*cause = g_voice_call_end_reason;

  switch (g_voice_call_end_reason)
  {
    case QMI_FAILURE_CAUSE_REL_NORMAL_V02:                     //0x19, VOLTE Call �� ���濡 ���ؼ� ���� ����Ǵ� ���
    case QMI_FAILURE_CAUSE_CLIENT_END_V02:                     //0x1D, VOLTE Call �� ���� ���� �����ϴ� ���
    case QMI_FAILURE_CAUSE_NORMAL_CALL_CLEARING_V02:           //0x91, CSFB Call �����ϴ� ���(�� �ΰ��� ��� ����)
    case QMI_FAILURE_CAUSE_NORMAL_UNSPECIFIED_V02:             //0x9C, CSFB Call �� ������ �ޱ� ���� ���� ���� �����ϴ� ���
      *cause = (call_end_reason_enum_v02) CALL_FAIL_NORMAL;    //16
      break;

    case QMI_FAILURE_CAUSE_USER_BUSY_V02:  //0x92
      *cause = (call_end_reason_enum_v02) CALL_FAIL_BUSY;  //17
      break;

    case QMI_FAILURE_CAUSE_NO_SRV_V02:  //0x15
//      *cause = (call_end_reason_enum_v02) CALL_FAIL_ERROR_UNSPECIFIED; //0xffff
	case QMI_FAILURE_CAUSE_RADIO_LINK_LOST_V02:  //jaeyong1.park 2017-01-31 add new cause
      *cause = (call_end_reason_enum_v02) CALL_FAIL_NO_NETWORK ; //jaeyong1.park 2017-01-31 add new cause
      break;

    case QMI_FAILURE_CAUSE_NO_FULL_SRV_V02:  //0x6C
    case QMI_FAILURE_CAUSE_MAX_PS_CALLS_V02: //0x6D
    case QMI_FAILURE_CAUSE_NO_CIRCUIT_OR_CHANNEL_AVAILABLE_V02:  //0x9D
    case QMI_FAILURE_CAUSE_SWITCHING_EQUIPMENT_CONGESTION_V02:  //0xA0
    case QMI_FAILURE_CAUSE_NETWORK_CONGESTION_V02:	// 0xD1, jaeyong1.park 2017-01-31
      *cause = (call_end_reason_enum_v02) CALL_FAIL_CONGESTION;  //34
      break;

    case QMI_FAILURE_CAUSE_CDMA_LOCK_V02:  //0x14
      *cause = (call_end_reason_enum_v02) CALL_FAIL_CDMA_LOCKED_UNTIL_POWER_CYCLE; //1000
      break;

    case QMI_FAILURE_CAUSE_FADE_V02:  //0x16
      *cause = (call_end_reason_enum_v02) CALL_FAIL_CDMA_DROP; //1001
      break;

    case QMI_FAILURE_CAUSE_INTERCEPT_V02:  //0x17
      *cause = (call_end_reason_enum_v02) CALL_FAIL_CDMA_INTERCEPT; //1002
      break;

    case QMI_FAILURE_CAUSE_REORDER_V02:  //0x18
      *cause = (call_end_reason_enum_v02) CALL_FAIL_CDMA_REORDER; //1003
      break;

    case QMI_FAILURE_CAUSE_REL_SO_REJ_V02:  //0x1A
      *cause = (call_end_reason_enum_v02) CALL_FAIL_CDMA_SO_REJECT; //1004
      break;

    case QMI_FAILURE_CAUSE_RETRY_ORDER_V02:  //0x25
      *cause = (call_end_reason_enum_v02) CALL_FAIL_CDMA_RETRY_ORDER; //1005
      break;

    case QMI_FAILURE_CAUSE_ACC_FAIL_V02:         //0x24
    case QMI_FAILURE_CAUSE_MAX_ACCESS_PROBE_V02: //0x20
      *cause = (call_end_reason_enum_v02) CALL_FAIL_CDMA_ACCESS_FAILURE; //1006
      break;

    case QMI_FAILURE_CAUSE_INCOM_CALL_V02:  //0x1B
      *cause = (call_end_reason_enum_v02) CALL_FAIL_CDMA_PREEMPTED; //1007
      break;

    case QMI_FAILURE_CAUSE_EMERGENCY_FLASHED_V02:  //0x2C
      *cause = (call_end_reason_enum_v02) CALL_FAIL_CDMA_NOT_EMERGENCY; //1008
      break;

    case QMI_FAILURE_CAUSE_ACM_LIMIT_EXCEEDED_V02:   //0xAA
      *cause = (call_end_reason_enum_v02) CALL_FAIL_ACM_LIMIT_EXCEEDED;  //68
      break;

    case QMI_FAILURE_CAUSE_ACCESS_CLASS_BLOCKED_V02:  //0xDB
      *cause = (call_end_reason_enum_v02) CALL_FAIL_CALL_BARRED;  //240
      break;

    case QMI_FAILURE_CAUSE_IMSI_UNKNOWN_IN_VLR_V02:        //0xC7
        *cause = (call_end_reason_enum_v02) CALL_FAIL_IMSI_UNKNOWN_IN_VLR;  //242
        break;

    case QMI_FAILURE_CAUSE_IMEI_NOT_ACCEPTED_V02:          //0xC8
      *cause = (call_end_reason_enum_v02) CALL_FAIL_IMEI_NOT_ACCEPTED;  //243
      break;

	case QMI_FAILURE_CAUSE_USER_ALERTING_NO_ANSWER_V02:  //jaeyong1.park 2017-01-31 add new cause
	  *cause = (call_end_reason_enum_v02) CALL_FAIL_NO_ANSWER;
	  break;

	case QMI_FAILURE_CAUSE_REJECTED_BY_USER_V02:  //jaeyong1.park 2017-01-31 add new cause
	case QMI_FAILURE_CAUSE_CALL_REJECTED_V02:
	  *cause = (call_end_reason_enum_v02) CALL_FAIL_REMOTE_REJECTED ;
	  break;		

	case QMI_FAILURE_CAUSE_INVALID_NUMBER_FORMAT_V02:
	case QMI_FAILURE_CAUSE_UNASSIGNED_NUMBER_V02:
	  *cause = (call_end_reason_enum_v02) CALL_FAIL_UNOBTAINABLE_NUMBER ;		
	  MSG_HIGH( "[VOICE] request_last_call_fail_cause() - CALL_FAIL_UNOBTAINABLE_NUMBER", g_voice_call_end_reason, 0, 0 );
		  
	  break;
	  
    default:     
	  MSG_HIGH( "[VOICE] request_last_call_fail_cause() : %d is not defined", g_voice_call_end_reason, 0, 0 );
      *cause = (call_end_reason_enum_v02) CALL_FAIL_ERROR_UNSPECIFIED;
      break;
  }  

  return TRUE;
}

//dsji_20150420 add {
uint8_t find_incoming_voice_call_id( void )
{
	uint8_t incoming_voice_call_id = QMI_VOICE_CALL_INVALID_ID;
	
	int time_out = 12;		//timeout is 6 sec( = 0.5 sec x 12 )
	int i;
	
	for ( i = 0; i < time_out; ++i )	//check for 6 sec
	{
		incoming_voice_call_id = get_voice_call_id( GET_VOICE_CALL_STATE_MASK_INCOMING );

		if ( QMI_VOICE_CALL_INVALID_ID != incoming_voice_call_id )
		{
			MSG_HIGH( "[VOICE] find_incoming_voice_call_id() find incoming call, call_id:%d", incoming_voice_call_id, 0, 0 );
			
		  return incoming_voice_call_id;
		}
		
	  //local_msleep( 500 );	//check per 0.5 sec
	  usleep(500*1000);//check per 0.5 sec
	  
		MSG_HIGH( "[VOICE] find_incoming_voice_call_id() waiting for incoming call... %d msec", ( ( i + 1 ) * 500 ), 0, 0 );
		
		if ( FALSE == request_get_current_calls() )
		{
			MSG_ERROR( "[VOICE] find_incoming_voice_call_id() request_get_current_calls() fail", 0, 0, 0 );
		}		
	}

	MSG_ERROR( "[VOICE] find_incoming_voice_call_id() can't find incoming voice call", 0, 0, 0 );

	return QMI_VOICE_CALL_INVALID_ID;
}
//dsji_20150420 add }

bool	request_answer( void )
{
	int r = QMI_NO_ERR;
	uint8_t incoming_voice_call_id;

	voice_answer_call_req_msg_v02	req;
	voice_answer_call_resp_msg_v02	rsp;

	memset( &req, 0x0, sizeof( req ) );
	memset( &rsp, 0x0, sizeof( rsp ) );

	//dsji_20150420 add
	incoming_voice_call_id = find_incoming_voice_call_id();

	if ( QMI_VOICE_CALL_INVALID_ID == incoming_voice_call_id )
	{
		MSG_ERROR( "[VOICE] request_answer() fail, can't find incoming voice call id", 0, 0, 0 );
		return FALSE;
	}
	//dsji_20150420 add

	req.call_id = incoming_voice_call_id;

	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_ANSWER_CALL_REQ_V02,
						   (void*)&req,
						   (void*)&rsp,
						   NULL,
						   NULL );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[VOICE] qmi_voice_msg_req() fail, error:%d", r, 0, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != rsp.resp.result )
	{
		MSG_ERROR( "[VOICE] qmi_voice_msg_req() rsp fail, error:%d", rsp.resp.error, 0, 0 );
		return FALSE;
	}

	return TRUE;
}



bool	request_dtmf_start( char* key )
{
	int r = QMI_NO_ERR;
	uint8_t conversation_voice_call_id;

	voice_start_cont_dtmf_req_msg_v02	req;
	voice_start_cont_dtmf_resp_msg_v02	rsp;

	memset( &req, 0x0, sizeof( req ) );
	memset( &rsp, 0x0, sizeof( rsp ) );

	request_get_current_calls(); //update current call, before search call id

	conversation_voice_call_id = get_voice_call_id( GET_VOICE_CALL_STATE_MASK_CONVERSATION );

	if ( QMI_VOICE_CALL_INVALID_ID == conversation_voice_call_id )
	//dsji_20141224 modify {
	{
		conversation_voice_call_id = get_voice_call_id( GET_VOICE_CALL_STATE_MASK_ALERTING );

		if ( QMI_VOICE_CALL_INVALID_ID == conversation_voice_call_id )
			return FALSE;
	}
	//dsji_20141224 modify }

	req.cont_dtmf_info.call_id = conversation_voice_call_id;
	req.cont_dtmf_info.digit = *key;

	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_START_CONT_DTMF_REQ_V02,
						   (void*)&req,
						   (void*)&rsp,
						   NULL,
						   NULL );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[VOICE] request_dtmf_start() fail, error:%d", r, 0, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != rsp.resp.result )
	{
		MSG_ERROR( "[VOICE] request_dtmf_start() rsp fail, error:%d", rsp.resp.error, 0, 0 );
		return FALSE;
	}

	return TRUE;
}



bool	request_dtmf_stop()
{
	int r = QMI_NO_ERR;
	uint8_t conversation_voice_call_id;

	voice_stop_cont_dtmf_req_msg_v02	req;
	voice_stop_cont_dtmf_resp_msg_v02	rsp;

	memset( &req, 0x0, sizeof( req ) );
	memset( &rsp, 0x0, sizeof( rsp ) );

	request_get_current_calls(); //update current call, before search call id

	conversation_voice_call_id = get_voice_call_id( GET_VOICE_CALL_STATE_MASK_CONVERSATION );

	if ( QMI_VOICE_CALL_INVALID_ID == conversation_voice_call_id )
	//dsji_20141224 modify {
	{
		conversation_voice_call_id = get_voice_call_id( GET_VOICE_CALL_STATE_MASK_ALERTING );
	
		if ( QMI_VOICE_CALL_INVALID_ID == conversation_voice_call_id )
			return FALSE;
	}
	//dsji_20141224 modify }

	req.call_id = conversation_voice_call_id;

	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_STOP_CONT_DTMF_REQ_V02,
						   (void*)&req,
						   (void*)&rsp,
						   NULL,
						   NULL );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[VOICE] request_dtmf_stop() fail, error:%d", r, 0, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != rsp.resp.result )
	{
		MSG_ERROR( "[VOICE] request_dtmf_stop() rsp fail, error:%d", rsp.resp.error, 0, 0 );
		return FALSE;
	}

	return TRUE;
}

bool request_dtmf(char* dtmf_data)
{

/*
The messages when sent across the air interface should contain the following information:
a)	START DTMF: Containing the digit value (0-9,*,#);
b)	START DTMF ACKNOWLEDGE: Containing the digit value (0-9,*,#) 
                            corresponding to the DTMF tone that the network applies towards the remote user;
c)	STOP DTMF: No further info;
d)	STOP DTMF ACKNOWLEDGE: No further info.

Only a single digit will be passed in each START DTMF and START DTMF ACKNOWLEDGE message.
The messages will be passed transparently through the base station and interpreted at the MSC. 
On receipt of a START DTMF message, the MSC will connect the correct dual-tone to line. 
This tone will remain connected until either the call is cleared or a STOP DTMF message is received.
As an operator option, the tone may be ceased after a pre-determined time whether or not a STOP DTMF message has been received.

If the implementation is currently playing a tone requested via
TOF_request_dtmf_start, that tone should be cancelled and the new tone
should be played instead

NOTE 1:	In ETSI ES 201 235-2 [12a] the minimum duration of a DTMF tone is 65ms.
NOTE 2: In ETSI ES 201 235-2 [12a] the minimum gap between DTMF tones is 65ms.
NOTE 3: If the Network operator implements the time limit option, 
        then the tone ends if the timer expires before the 'Stop DTMF' is received.
*/
  int r = QMI_NO_ERR;
	uint8_t conversation_voice_call_id;

	voice_start_cont_dtmf_req_msg_v02	start_cont_dtmf_req;
	voice_start_cont_dtmf_resp_msg_v02 start_cont_dtmf_rsp;

	voice_stop_cont_dtmf_req_msg_v02	stop_cont_dtmf_req;
	voice_stop_cont_dtmf_resp_msg_v02	stop_cont_dtmf_rsp;

	conversation_voice_call_id = get_voice_call_id( GET_VOICE_CALL_STATE_MASK_CONVERSATION );

	request_get_current_calls(); //update current call, before search call id

	if ( QMI_VOICE_CALL_INVALID_ID == conversation_voice_call_id )
	{
		conversation_voice_call_id = get_voice_call_id( GET_VOICE_CALL_STATE_MASK_ALERTING );

		if ( QMI_VOICE_CALL_INVALID_ID == conversation_voice_call_id )
			{
			return FALSE;
			}
	}

	start_cont_dtmf_req.cont_dtmf_info.call_id = conversation_voice_call_id;
	start_cont_dtmf_req.cont_dtmf_info.digit = *dtmf_data;
	stop_cont_dtmf_req.call_id = conversation_voice_call_id;

	//Send DTMF Start
	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_START_CONT_DTMF_REQ_V02,
						   (void*)&start_cont_dtmf_req,
						   (void*)&start_cont_dtmf_rsp,
						   NULL,
						   NULL );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[VOICE] request_dtmf_start() fail, error:%d", r, 0, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != start_cont_dtmf_rsp.resp.result )
	{
		MSG_ERROR( "[VOICE] request_dtmf_start() rsp fail, error:%d", start_cont_dtmf_rsp.resp.error, 0, 0 );
		return FALSE;
	}

	usleep( 1000 * 120 );//micro sleep 1000 * 1000 = 1sec ///* DTMF inter-digit interval, 120ms */
	
	//Send DTMF Stop
	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_STOP_CONT_DTMF_REQ_V02,
						   (void*)&stop_cont_dtmf_req,
						   (void*)&stop_cont_dtmf_rsp,
						   NULL,
						   NULL );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[VOICE] request_dtmf_stop() fail, error:%d", r, 0, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != stop_cont_dtmf_rsp.resp.result )
	{
		MSG_ERROR( "[VOICE] request_dtmf_stop() rsp fail, error:%d", stop_cont_dtmf_rsp.resp.error, 0, 0 );
		return FALSE;
	}

	return TRUE;
}

bool request_cdma_burst_dtmf(char* dtmf_data) //BKS_20131127 modify
{
  int r = QMI_NO_ERR;
  const char *dtmf_ptr;
  const char *onlength_ptr;
  const char *offlength_ptr;
  char *end_ptr = NULL;

  int dtmf_str_len = 0;
  long ret_val;

  dtmf_onlength_enum_v02 on_length = DTMF_ONLENGTH_95MS_V02; /* DTMF pulse width, 150ms */
  dtmf_offlength_enum_v02 off_length = DTMF_OFFLENGTH_60MS_V02; /* DTMF inter-digit interval, 150ms */
	 
  voice_burst_dtmf_req_msg_v02    req;
  voice_burst_dtmf_resp_msg_v02  rsp;

  memset( &req, 0x0, sizeof( voice_burst_dtmf_req_msg_v02 ) );
  memset( &rsp, 0x0, sizeof( voice_burst_dtmf_resp_msg_v02 ) );

  request_get_current_calls(); //update current call, before search call id

  dtmf_ptr =  ((const char **)dtmf_data)[0];
  onlength_ptr = ((const char**)dtmf_data)[1];
  offlength_ptr = ((const char**)dtmf_data)[2]; 


#if 1
  if( dtmf_ptr == NULL || onlength_ptr == NULL || offlength_ptr == NULL )
  {
   return FALSE;
  }

  dtmf_str_len = strlen(dtmf_ptr);
  
  if(dtmf_str_len > QMI_VOICE_DIGIT_BUFFER_MAX_V02)
  {
    return FALSE;
  }

  /* Convert DTMF ON length string to DTMF ON duration */
  ret_val = strtol( onlength_ptr, &end_ptr, 0 );

  switch(ret_val)
  {
    case 95:
	on_length =  DTMF_ONLENGTH_95MS_V02;
   	break;

    case 0:
    case 150:
	on_length = DTMF_ONLENGTH_150MS_V02;	
	break;

    case 200:
	on_length = DTMF_ONLENGTH_200MS_V02;	
	break;	

    case 250:
	on_length = DTMF_ONLENGTH_250MS_V02;	
	break;

    case 300:
	on_length = DTMF_ONLENGTH_300MS_V02;	
	break;

    case 350:
	on_length = DTMF_ONLENGTH_350MS_V02;	
	break;

    default:
	on_length = DTMF_ONLENGTH_SMS_V02;	//? Ȯ�� �ʿ�...
	break;
	
  }

/* Convert DTMF OFF length string to DTMF OFF duration */
  ret_val = strtol( offlength_ptr, &end_ptr, 0 );

  switch(ret_val)
  {
    case 60:
	off_length = DTMF_OFFLENGTH_60MS_V02;
	break;

    case 100:
	off_length = DTMF_OFFLENGTH_100MS_V02;
	break;

    case 150:
	off_length = DTMF_OFFLENGTH_150MS_V02;
	break;
	
    case 200:
	off_length = DTMF_OFFLENGTH_200MS_V02;
	break;

    default:
	off_length = DTMF_OFFLENGTH_150MS_V02;
	break;	
  }
#endif

  req.burst_dtmf_info.call_id = get_voice_call_id( GET_VOICE_CALL_STATE_MASK_CONVERSATION );
  req.burst_dtmf_info.digit_buffer_len =dtmf_str_len;
  memcpy( (char*)req.burst_dtmf_info.digit_buffer, dtmf_ptr,req.burst_dtmf_info.digit_buffer_len );
  req.burst_dtmf_info.digit_buffer[req.burst_dtmf_info.digit_buffer_len] = '\0'; 

  req.dtmf_lengths_valid = TRUE; // ? Ȯ�� �ʿ�...
  req.dtmf_lengths.dtmf_onlength = on_length;
  req.dtmf_lengths.dtmf_offlength = off_length;
  
  r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_BURST_DTMF_REQ_V02,
						   (void*)&req,
						   (void*)&rsp,
						   NULL,
						   NULL );

  if ( QMI_NO_ERR != r )
  {
    return FALSE;
  }
  
  if ( QMI_RESULT_SUCCESS_V01 != rsp.resp.result )
  {
    return FALSE;
  }

  return TRUE;
}


bool	request_manage_calls( sups_type_enum_v02 sups_type )
{
	int r = QMI_NO_ERR;

	voice_manage_calls_req_msg_v02	req;
	voice_manage_calls_resp_msg_v02	rsp;

	memset( &req, 0x0, sizeof( req ) );
	memset( &rsp, 0x0, sizeof( rsp ) );

	req.sups_type = sups_type;

	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_MANAGE_CALLS_REQ_V02,
						   (void*)&req,
						   (void*)&rsp,
						   NULL,
						   NULL );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[VOICE] request_manage_calls() fail, sups_type:%d, error:%d", sups_type, r, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != rsp.resp.result )
	{
		MSG_ERROR( "[VOICE] request_manage_calls() rsp fail, sups_type:%d, error:%d", sups_type, rsp.resp.error, 0 );
		return FALSE;
	}

	return TRUE;
}



bool	request_set_clir( int n )
{
	g_clir_n = n;	//dsji_20130620 add
#if 0	//dsji_20130620 disable
	int r = QMI_NO_ERR;

	voice_set_clir_req_msg	req;
	voice_set_clir_resp_msg	rsp;

	memset( &req, 0x0, sizeof( req ) );
	memset( &rsp, 0x0, sizeof( rsp ) );

	req.n = n;

	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_SET_CLIR_REQ,
						   (void*)&req,
						   (void*)&rsp,
						   NULL,
						   NULL );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[VOICE] request_set_clir() fail, error:%d", r, 0, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != rsp.resp.result )
	{
		MSG_ERROR( "[VOICE] request_set_clir() rsp fail, error:%d", rsp.resp.error, 0, 0 );
		return FALSE;
	}
#endif
	return TRUE;
}



bool	request_get_clir()
{
	int r = QMI_NO_ERR;

	voice_get_clir_resp_msg_v02	rsp;

	memset( &rsp, 0x0, sizeof( rsp ) );

	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_GET_CLIR_REQ_V02,
						   NULL,
						   (void*)&rsp,
						   NULL,
						   NULL );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[VOICE] request_get_clir() fail, error:%d", r, 0, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != rsp.resp.result )
	{
		MSG_ERROR( "[VOICE] request_get_clir() rsp fail, error:%d", rsp.resp.error, 0, 0 );
		return FALSE;
	}

	memcpy( &g_clir, &rsp, sizeof( g_clir ) );	//dsji_20130617 add

	return TRUE;
}



bool	request_set_call_waiting( int32* data )
{
	int r = QMI_NO_ERR;

	voice_set_sups_service_req_msg_v02	req;
	voice_set_sups_service_resp_msg_v02	rsp;

	voice_service_enum_v02 voice_service;

	memset( &req, 0x0, sizeof( req ) );
	memset( &rsp, 0x0, sizeof( rsp ) );

	if ( TRUE == data[ 0 ] )
		voice_service = VOICE_SERVICE_ACTIVATE_V02;
	else
		voice_service = VOICE_SERVICE_DEACTIVATE_V02;

	req.supplementary_service_info.voice_service = voice_service;
	req.supplementary_service_info.reason = VOICE_REASON_CALLWAITING_V02;

	if ( 0 != data[ 1 ] )
	{
		req.service_class_valid = TRUE;
		req.service_class = data[ 1 ];
	}

	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_SET_SUPS_SERVICE_REQ_V02,
						   (void*)&req,
						   (void*)&rsp,
						   NULL,
						   NULL );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[VOICE] request_set_call_waiting() fail, error:%d", r, 0, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != rsp.resp.result )
	{
		MSG_ERROR( "[VOICE] request_set_call_waiting() rsp fail, error:%d", rsp.resp.error, 0, 0 );
		return FALSE;
	}

	return TRUE;
}



bool	request_query_call_waiting( int32 service_class )
{
	int r = QMI_NO_ERR;

	voice_get_call_waiting_req_msg_v02	req;
	voice_get_call_waiting_resp_msg_v02	rsp;

	memset( &req, 0x0, sizeof( req ) );
	memset( &rsp, 0x0, sizeof( rsp ) );

	if ( 0 != service_class )
	{
		req.service_class_valid = TRUE;
		req.service_class = service_class;
	}

	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_GET_CALL_WAITING_REQ_V02,
						   (void*)&req,
						   (void*)&rsp,
						   NULL,
						   NULL );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[VOICE] request_query_call_waiting() fail, error:%d", r, 0, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != rsp.resp.result )
	{
		MSG_ERROR( "[VOICE] request_query_call_waiting() rsp fail, error:%d", rsp.resp.error, 0, 0 );
		return FALSE;
	}

	memcpy( &g_call_waiting, &rsp, sizeof( g_call_waiting ) );	//dsji_20130617 add

	return TRUE;
}



bool	request_set_call_forward( TOF_CallForwardInfo* tof_call_forward_info )
{
	int r = QMI_NO_ERR;

	voice_set_sups_service_req_msg_v02	req;
	voice_set_sups_service_resp_msg_v02	rsp;

	voice_service_enum_v02	voice_service;
	voice_reason_enum_v02	reason;
	voice_num_type_enum_v02	num_type;
	voice_num_plan_enum_v02	num_plan;

	memset( &req, 0x0, sizeof( req ) );
	memset( &rsp, 0x0, sizeof( rsp ) );

	switch ( tof_call_forward_info->status )
	{
	case 0:	voice_service = VOICE_SERVICE_DEACTIVATE_V02;	break;
	case 1: voice_service = VOICE_SERVICE_ACTIVATE_V02;		break;
	case 2:													return FALSE;	//interrogate
	case 3: voice_service = VOICE_SERVICE_REGISTER_V02;		break;
	case 4: voice_service = VOICE_SERVICE_ERASE_V02;		break;
	default:												return FALSE;
	}

	req.supplementary_service_info.voice_service = voice_service;

	switch ( tof_call_forward_info->reason )
	{
	case 0: reason = VOICE_REASON_FWD_UNCONDITIONAL_V02;	break;
	case 1: reason = VOICE_REASON_FWD_MOBILEBUSY_V02;		break;
	case 2: reason = VOICE_REASON_FWD_NOREPLY_V02;			break;
	case 3: reason = VOICE_REASON_FWD_UNREACHABLE_V02;		break;
	case 4: reason = VOICE_REASON_FWD_ALLFORWARDING_V02;	break;
	case 5: reason = VOICE_REASON_FWD_ALLCONDITIONAL_V02;	break;
	default:												return FALSE;
	}
	
	req.supplementary_service_info.reason = reason;

	if ( NULL != tof_call_forward_info->number )
	{
		req.number_valid = TRUE;
		strcpy( req.number, tof_call_forward_info->number );
	}

	if ( 0 != tof_call_forward_info->timeSeconds )
	{
		req.timer_value_valid = TRUE;
		req.timer_value = tof_call_forward_info->timeSeconds;
	}

	req.num_type_plan_valid = TRUE;
	switch ( tof_call_forward_info->toa )	//ts 24.008 10.5.4.7
	{
	case 129:	num_type = QMI_VOICE_NUM_TYPE_NATIONAL_V02;			break;
	case 145:	num_type = QMI_VOICE_NUM_TYPE_INTERNATIONAL_V02;	break;
	default:														return FALSE;
	}
	num_plan = QMI_VOICE_NUM_PLAN_UNKNOWN_V02;

	req.num_type_plan.num_type = num_type;
	req.num_type_plan.num_plan = num_plan;
	
	if ( 0 != tof_call_forward_info->serviceClass )
	{
		req.service_class_valid = TRUE;
		req.service_class = tof_call_forward_info->serviceClass;
	}

	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_SET_SUPS_SERVICE_REQ_V02,
						   (void*)&req,
						   (void*)&rsp,
						   NULL,
						   NULL );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[VOICE] request_set_call_forward() fail, error:%d", r, 0, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != rsp.resp.result )
	{
		MSG_ERROR( "[VOICE] request_set_call_forward() rsp fail, error:%d", rsp.resp.error, 0, 0 );
		return FALSE;
	}

	return TRUE;
}



bool request_query_call_forward_status( TOF_CallForwardInfo* tof_call_forward_info )
{
	int r = QMI_NO_ERR;

	voice_get_call_forwarding_req_msg_v02	req;
	voice_get_call_forwarding_resp_msg_v02	rsp;

	voice_reason_enum_v02	reason;

	memset( &req, 0x0, sizeof( req ) );
	memset( &rsp, 0x0, sizeof( rsp ) );

	if ( 2 != tof_call_forward_info->status )	//only interrogate
		return FALSE;

	switch ( tof_call_forward_info->reason )
	{
	case 0: reason = VOICE_REASON_FWD_UNCONDITIONAL_V02;	break;
	case 1: reason = VOICE_REASON_FWD_MOBILEBUSY_V02;		break;
	case 2: reason = VOICE_REASON_FWD_NOREPLY_V02;			break;
	case 3: reason = VOICE_REASON_FWD_UNREACHABLE_V02;		break;
	case 4: reason = VOICE_REASON_FWD_ALLFORWARDING_V02;	break;
	case 5: reason = VOICE_REASON_FWD_ALLCONDITIONAL_V02;	break;
	default:												return FALSE;
	}
	
	req.reason = reason;

	if ( 0 != tof_call_forward_info->serviceClass )
	{
		req.service_class_valid = TRUE;
		req.service_class = tof_call_forward_info->serviceClass;
	}

	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_GET_CALL_FORWARDING_REQ_V02,
						   (void*)&req,
						   (void*)&rsp,
						   NULL,
						   NULL );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[VOICE] request_query_call_forward_status() fail, error:%d", r, 0, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != rsp.resp.result )
	{
		MSG_ERROR( "[VOICE] request_query_call_forward_status() rsp fail, error:%d", rsp.resp.error, 0, 0 );
		return FALSE;
	}

	memcpy( &g_call_forward, &rsp, sizeof( g_call_forward ) );	//dsji_20130617 add

	return TRUE;
}



bool	request_set_clip( int n )
{
	g_clip_n = n;	//dsji_20130620 add
#if 0	//dsji_20130620 disable
	int r = QMI_NO_ERR;

	voice_set_clip_req_msg	req;
	voice_set_clip_resp_msg	rsp;

	memset( &req, 0x0, sizeof( req ) );
	memset( &rsp, 0x0, sizeof( rsp ) );

	req.n = n;

	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_SET_CLIP_REQ,
						   (void*)&req,
						   (void*)&rsp,
						   NULL,
						   NULL );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[VOICE] request_set_clip() fail, error:%d", r, 0, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != rsp.resp.result )
	{
		MSG_ERROR( "[VOICE] request_set_clip() rsp fail, error:%d", rsp.resp.error, 0, 0 );
		return FALSE;
	}
#endif
	return TRUE;
}



bool	request_get_clip( void )
{
	int r = QMI_NO_ERR;

	voice_get_clip_resp_msg_v02	rsp;

	memset( &rsp, 0x0, sizeof( rsp ) );

	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_GET_CLIP_REQ_V02,
						   NULL,
						   (void*)&rsp,
						   NULL,
						   NULL );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[VOICE] request_get_clip() fail, error:%d", r, 0, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != rsp.resp.result )
	{
		MSG_ERROR( "[VOICE] request_get_clip() rsp fail, error:%d", rsp.resp.error, 0, 0 );
		return FALSE;
	}

	memcpy( &g_clip, &rsp, sizeof( g_clip ) );	//dsji_20130617 add

	return TRUE;
}



bool	request_set_colp( int n )
{
	g_colp_n = n;	//dsji_20130620 add
#if 0	//dsji_20130620 disable
	int r = QMI_NO_ERR;

	voice_set_colp_req_msg	req;
	voice_set_colp_resp_msg	rsp;

	memset( &req, 0x0, sizeof( req ) );
	memset( &rsp, 0x0, sizeof( rsp ) );

	req.n = n;

	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_SET_COLP_REQ,
						   (void*)&req,
						   (void*)&rsp,
						   NULL,
						   NULL );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[VOICE] request_set_colp() fail, error:%d", r, 0, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != rsp.resp.result )
	{
		MSG_ERROR( "[VOICE] request_set_colp() rsp fail, error:%d", rsp.resp.error, 0, 0 );
		return FALSE;
	}
#endif
	return TRUE;
}



bool	request_get_colp( void )
{
	int r = QMI_NO_ERR;

	voice_get_colp_resp_msg_v02	rsp;

	memset( &rsp, 0x0, sizeof( rsp ) );

	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_GET_COLP_REQ_V02,
						   NULL,
						   (void*)&rsp,
						   NULL,
						   NULL );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[VOICE] request_get_colp() fail, error:%d", r, 0, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != rsp.resp.result )
	{
		MSG_ERROR( "[VOICE] request_get_colp() rsp fail, error:%d", rsp.resp.error, 0, 0 );
		return FALSE;
	}

	memcpy( &g_colp, &rsp, sizeof( g_colp ) );	//dsji_20130617 add

	return TRUE;
}



bool	request_get_colr( void )
{
	int r = QMI_NO_ERR;

	voice_get_clir_resp_msg_v02	rsp;

	memset( &rsp, 0x0, sizeof( rsp ) );

	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_GET_COLR_REQ_V02,
						   NULL,
						   (void*)&rsp,
						   NULL,
						   NULL );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[VOICE] request_get_clir() fail, error:%d", r, 0, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != rsp.resp.result )
	{
		MSG_ERROR( "[VOICE] request_get_clir() rsp fail, error:%d", rsp.resp.error, 0, 0 );
		return FALSE;
	}

	memcpy( &g_colr, &rsp, sizeof( g_colr ) );	//dsji_20130617 add

	return TRUE;
}

//chad_20160602 start >>>
boolean request_set_volte(boolean on_off)
{
  boolean ret_val = TRUE;

  if(ril_request_set_ims_qipcall_info(on_off) == RESULT_FAILURE)
  {
    ret_val = FALSE;
  }

  MSG_ERROR( "[VOICE] request_set_volte() ret_val =%d",ret_val, 0, 0 );
  return ret_val;
}

uint8 request_get_volte(void)
{
  uint8 ret_val = 0;
  uint8 hd_voice = 0;
  
  if(ril_request_get_ims_qipcall_info(&hd_voice) == RESULT_FAILURE)
  {
    ret_val = 0xFF;
  }
  else
  {
    if(hd_voice == TRUE)
    {
      ret_val = 1;
    }    
  }
  
  MSG_ERROR( "[VOICE] request_set_volte() ret_val =%d",ret_val, 0, 0 );
  return ret_val;
}

//chad_20160602 end <<<

//dsji_20140922 add {
void  log_ussd_context( TOF_USSD_CONTEXT_INFO* tof_ussd_context_info, voice_uss_info_type_v02* qmi_uss_info )
{
  int i = 0;
  char hexa_char[ 64 ];
	char hexa_string[ 2048 ];
	char line_hexa_string[ 128 ];

	memset( hexa_char, 0, sizeof( hexa_char ) );
	memset( hexa_string, 0, sizeof( hexa_string ) );

  for ( i = 0; i < qmi_uss_info->uss_data_len; ++i )
  {
    sprintf( hexa_char, "%02x", qmi_uss_info->uss_data[ i ] );

    if ( strlen( hexa_char ) > 2 )
    {
      hexa_char[ 0 ] = hexa_char[ 6 ];
      hexa_char[ 1 ] = hexa_char[ 7 ];
      hexa_char[ 2 ] = 0;
    }
		
    strcat( hexa_string, hexa_char );
  }

	MSG_MED( "[VOICE] log_ussd_context(), tof_dcs:%d, tof_ussd_id:%d", tof_ussd_context_info->dcs, tof_ussd_context_info->ussd_id, 0 );
	MSG_MED( "[VOICE] log_ussd_context(), data_len:%d, dcs:%d", qmi_uss_info->uss_data_len, qmi_uss_info->uss_dcs, 0 );

	for ( i = 0; i < strlen( hexa_string ); ++i )
	{
		if ( 0 == ( i % 20 ) )
		{
			memset( line_hexa_string, 0, sizeof( line_hexa_string ) );
			memcpy( line_hexa_string, &( hexa_string[ i ] ), 20 );
			
			MSG_LOW( "%s",	line_hexa_string, 0, 0 );
		}
	}
}
//dsji_20140922 add }



//dsji_20130702 add {
bool	request_ussd_transmit( TOF_USSD_CONTEXT_INFO* tof_ussd_context_info, voice_orig_ussd_resp_msg_v02* rsp )
{
	int r = QMI_NO_ERR;
	int max_ussd_size = ( QMI_VOICE_USS_DATA_MAX_V02 * 7 ) / 8;	//ucs2 -> ksc5601
	uss_dcs_enum_v02 qmi_uss_dcs = USS_DCS_ASCII_V02;	//dsji_20140922 add

	if ( tof_ussd_context_info->data_len > max_ussd_size )
	{
		MSG_ERROR( "[VOICE] request_ussd_transmit() fail, ussd size overflow, ussd_size:%d", tof_ussd_context_info->data_len, 0, 0 );
		return FALSE;
	}

	voice_orig_ussd_req_msg_v02		req;

	memset( &req, 0x0, sizeof( req ) );
	memset( rsp, 0x0, sizeof( voice_orig_ussd_resp_msg_v02 ) );

	//dsji_20140922 add {
	switch ( tof_ussd_context_info->dcs )
	{
	case 0x00:	//7bit
	  qmi_uss_dcs = USS_DCS_ASCII_V02;
		break;
		
	case 0x04:	//8bit
	  qmi_uss_dcs = USS_DCS_8BIT_V02;
	  break;
	
	case 0x08:	//ucs2
	  qmi_uss_dcs = USS_DCS_UCS2_V02;
	  break;
		
	case 0x19:	//ksc5601
	case 0xa1:
	case 0xa2:
	case 0xa3:
		qmi_uss_dcs = USS_DCS_KSC5601_V02;
		break;
	}
	//dsji_20140922 add }

	req.uss_info.uss_dcs = qmi_uss_dcs;//(uss_dcs_enum_v02)ril_ussd_context_info->dcs;	//dsji_20140922 bug fix
	req.uss_info.uss_data_len = tof_ussd_context_info->data_len;
	memcpy( req.uss_info.uss_data, tof_ussd_context_info->data_buf, tof_ussd_context_info->data_len );

	log_ussd_context( tof_ussd_context_info, &(req.uss_info) );

	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_ORIG_USSD_REQ_V02,
						   (void*)&req,
						   (void*)rsp,
						   NULL,
						   NULL );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[VOICE] request_ussd_transmit() fail, error:%d", r, 0, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != rsp->resp.result )
	{
		MSG_ERROR( "[VOICE] request_ussd_transmit() rsp fail, error:%d", rsp->resp.error, 0, 0 );
		return FALSE;
	}

	return TRUE;
}
//dsji_20130702 add }



//dsji_20140402 add {
bool	request_ussd_answer( voice_answer_ussd_resp_msg_v02* rsp )
{
	int r = QMI_NO_ERR;

	voice_answer_ussd_req_msg_v02		req;

	memset( &req, 0x0, sizeof( req ) );
	memset( rsp, 0x0, sizeof( voice_answer_ussd_resp_msg_v02 ) );

	req.uss_info.uss_dcs = USS_DCS_KSC5601_V02;
	req.uss_info.uss_data_len = 0;

	r = qmi_voice_msg_req( (int)g_voice_client_handle,
						   QMI_VOICE_ANSWER_USSD_REQ_V02,
						   (void*)&req,
						   (void*)rsp,
						   NULL,
						   NULL );

	if ( QMI_NO_ERR != r )
	{
		MSG_ERROR( "[VOICE] request_ussd_answer() fail, error:%d", r, 0, 0 );
		return FALSE;
	}

	if ( QMI_RESULT_SUCCESS_V01 != rsp->resp.result )
	{
		MSG_ERROR( "[VOICE] request_ussd_answer() rsp fail, error:%d", rsp->resp.error, 0, 0 );
		return FALSE;
	}

	return TRUE;
}
//dsji_20140402 add }




char*	get_call_state_string( call_state_enum_v02 call_state )
{
	static char* string = NULL;

	switch ( call_state )
	{
	case CALL_STATE_ORIGINATING_V02:	string = "origination";		break;
	case CALL_STATE_INCOMING_V02:		string = "incoming";		break;
	case CALL_STATE_CONVERSATION_V02:	string = "conversation";	break;
	case CALL_STATE_CC_IN_PROGRESS_V02:	string = "cc in progress";	break;
	case CALL_STATE_ALERTING_V02:		string = "alerting";		break;
	case CALL_STATE_HOLD_V02:			string = "hold";			break;
	case CALL_STATE_WAITING_V02:		string = "waiting";			break;
	case CALL_STATE_DISCONNECTING_V02:	string = "disconnecting";	break;
	case CALL_STATE_END_V02:			string = "end";				break;
	case CALL_STATE_SETUP_V02:			string = "setup";			break;
	default:							string = "invalid";			break;
	}

	return string;
}



char*	get_direction_string( call_direction_enum_v02 direction )
{
	static char* string = NULL;

	switch ( direction )
	{
	case CALL_DIRECTION_MO_V02:	string = "MO";		break;
	case CALL_DIRECTION_MT_V02:	string = "MT";		break;
	default:					string = "invalid";	break;
	}

	return string;
}

char*	get_call_type_string( call_type_enum_v02 call_type )
{
	static char* string = NULL;

	switch ( call_type )
	{
	case CALL_TYPE_VOICE_V02:	string = "voice";		break;
	case CALL_TYPE_VOICE_IP_V02:	string = "voip";		break;
	default:					string = "invalid";	break;
	}

	return string;
}

/*===========================================================================

  FUNCTION  convert_phone_number

  covert +821012345678> to 01012345678
  
===========================================================================*/
void convert_phone_number(char before_number[], char after_number[])
{
  int i=0;

  if((before_number[0] == '+') &&
     (before_number[1] == '8') &&
     (before_number[2] == '2'))
  {
    after_number[0] = '0';
    for(i=3; i<strlen(before_number); i++)
    {
      after_number[i-2] = before_number[i];
    }      
  }
  else
  {
    memcpy(after_number, before_number, strlen(before_number));
  }
}

/*===========================================================================

  FUNCTION  convert_call_state
  
===========================================================================*/
call_type_enum_v02 convert_call_state(call_direction_enum_v02 direction, 
                                      call_type_enum_v02 call_type, 
                                      call_state_enum_v02 call_state, 
                                      voice_speech_codec_enum_v02 call_codec)
{
  call_type_enum_v02 result = CALL_TYPE_VOICE_V02;

  // incoming call
  if(call_state == CALL_STATE_INCOMING_V02)
  {
    result = CALL_TYPE_VOICE_V02;
  }
  // codec ������ conversation ���°� �� �� ind�� �ö� ��
  // call state�� originating, incoming, alerting ������ ��� codec ������ ���� ������ call type���� ǥ�õǰ� ��
  else if(call_state == CALL_STATE_ORIGINATING_V02 || 
             call_state == CALL_STATE_ALERTING_V02 ||
             call_state == CALL_STATE_CC_IN_PROGRESS_V02 )
  {
    result = call_type;
  }
  else if(call_codec == VOICE_SPEECH_CODEC_AMR_WB_V02)
  {
    result = CALL_TYPE_VOICE_IP_V02;
  }
  else
  {
    result = CALL_TYPE_VOICE_V02;
  }

  return result;
}

/*===========================================================================

  FUNCTION  get_voice_call_end_reason_string
  
===========================================================================*/
char*	get_voice_call_end_reason_string( call_end_reason_enum_v02 voice_call_end_reason )
{
  static char* string = NULL;

  switch ( voice_call_end_reason )
  {
    case QMI_FAILURE_CAUSE_CLIENT_END_V02:                         string = "CLIENT_END";		break;
    case QMI_FAILURE_CAUSE_NORMAL_CALL_CLEARING_V02:               string = "NORMAL_CALL_CLEARING";		break;
    case QMI_FAILURE_CAUSE_REL_NORMAL_V02:                         string = "REL_NORMAL";		break;
    case QMI_FAILURE_CAUSE_NORMAL_UNSPECIFIED_V02:                 string = "NORMAL_UNSPECIFIED";		break;
    case QMI_FAILURE_CAUSE_USER_BUSY_V02:                          string = "USER_BUSY";	break;
    case QMI_FAILURE_CAUSE_NO_CIRCUIT_OR_CHANNEL_AVAILABLE_V02:    string = "NO_CIRCUIT_OR_CHANNEL_AVAILABLE";	break;
    case QMI_FAILURE_CAUSE_SWITCHING_EQUIPMENT_CONGESTION_V02:     string = "SWITCHING_EQUIPMENT_CONGESTION";		break;
    case QMI_FAILURE_CAUSE_ACM_LIMIT_EXCEEDED_V02:                 string = "ACM_LIMIT_EXCEEDED";			break;
    case QMI_FAILURE_CAUSE_ACCESS_CLASS_BLOCKED_V02:               string = "ACCESS_CLASS_BLOCKED";			break;
    case QMI_FAILURE_CAUSE_IMSI_UNKNOWN_IN_VLR_V02:                string = "IMSI_UNKNOWN_IN_VLR";	break;
    case QMI_FAILURE_CAUSE_IMEI_NOT_ACCEPTED_V02:                  string = "IMEI_NOT_ACCEPTED";				break;
    default:                                                       string = "NOT_DEFINED";			break;
  }

  return string;
}

//--> RIL_UNSOL_CALL_RING
/*===========================================================================

FUNCTION  qmi_voice_make_incoming_call_ring

===========================================================================*/
void qmi_voice_make_incoming_call_ring(TOF_CDMA_SignalInfoRecord* info_rec)
{
  TOF_CDMA_SignalInfoRecord *temp_rec = NULL;
  TOF_CDMA_SignalInfoRecord signal_rec;

  memset(&signal_rec, 0x0, sizeof(TOF_CDMA_SignalInfoRecord));
  temp_rec = &signal_rec;
  if(NULL != info_rec)
  {
    MSG_HIGH("[VOICE] TOF_UNSOL_CALL_RING", 0, 0, 0);
    temp_rec = info_rec;
    //Send_UnsolicitedResponse (RIL_UNSOL_CALL_RING, temp_rec, sizeof(RIL_CDMA_SignalInfoRecord));
  }
} /* qmi_voice_make_incoming_call_ring */
//<-- RIL_UNSOL_CALL_RING

//--> RIL_REQUEST_CDMA_QUERY_PREFERRED_VOICE_PRIVACY_MODE
/*===========================================================================

FUNCTION  qmi_voice_request_query_preferred_voice_privacy_mode

===========================================================================*/
uint8 qmi_voice_request_query_preferred_voice_privacy_mode(int *privacy_reference)
{
  int tof_req_res = QMI_NO_ERR;
  int ret = RESULT_SUCCESS;
  
  voice_get_config_req_msg_v02 qmi_request;
  voice_get_config_resp_msg_v02 qmi_response;
  
  memset( &qmi_request, 0x0, sizeof( qmi_request ) );
  memset( &qmi_response, 0x0, sizeof( qmi_response ) );
  
  qmi_request.voice_privacy_valid = TRUE;
  qmi_request.voice_privacy = 0x01;
  
  tof_req_res = qmi_voice_msg_req( (int)g_voice_client_handle,
                                   QMI_VOICE_GET_CONFIG_REQ_V02,
                                   (void*)&qmi_request,
                                   (void*)&qmi_response,
                                   NULL,
                                   NULL );
  
  if ( QMI_NO_ERR != tof_req_res )
  {
    MSG_ERROR( "[VOICE] qmi_voice_request_query_preferred_voice_privacy_mode() fail, error:%d", tof_req_res, 0, 0 );
    return RESULT_FAILURE;
  }
  
  if ( QMI_RESULT_SUCCESS_V01 != qmi_response.resp.result )
  {
    MSG_ERROR( "[VOICE] qmi_voice_request_query_preferred_voice_privacy_mode() rsp fail, error:%d", qmi_response.resp.error, 0, 0 );
    return RESULT_FAILURE;
  }

  if(qmi_response.current_voice_privacy_pref_valid)
  {
    *privacy_reference = qmi_response.current_voice_privacy_pref;
  }
  
  return RESULT_SUCCESS;  
}
//<-- RIL_REQUEST_CDMA_QUERY_PREFERRED_VOICE_PRIVACY_MODE

//--> RIL_REQUEST_CDMA_SET_PREFERRED_VOICE_PRIVACY_MODE
/*===========================================================================

FUNCTION  qmi_voice_request_set_preferred_voice_privacy_mode

===========================================================================*/
uint8 qmi_voice_request_set_preferred_voice_privacy_mode(int voice_privacy)
{
  int tof_req_res = QMI_NO_ERR;
  int ret = RESULT_SUCCESS;
  
  voice_set_preferred_privacy_req_msg_v02 set_preferred_privacy_req_msg;
  voice_set_preferred_privacy_resp_msg_v02 set_preferred_privacy_resp_msg;
  
  memset( &set_preferred_privacy_req_msg, 0x0, sizeof( set_preferred_privacy_req_msg ) );
  memset( &set_preferred_privacy_resp_msg, 0x0, sizeof( set_preferred_privacy_resp_msg ) );

  switch(voice_privacy)
  {
    case 0:
      set_preferred_privacy_req_msg.privacy_pref = (voice_privacy_enum_v02)0x00;
      break;
    case 1:
      set_preferred_privacy_req_msg.privacy_pref = (voice_privacy_enum_v02)0x01;
      break;
    default:
      set_preferred_privacy_req_msg.privacy_pref = (voice_privacy_enum_v02)0x00;
      break;
  }

  MSG_HIGH("voice privacy mode preference set %d", set_preferred_privacy_req_msg.privacy_pref, 0, 0);
  
  tof_req_res = qmi_voice_msg_req( (int)g_voice_client_handle,
                                   QMI_VOICE_SET_PREFERRED_PRIVACY_REQ_V02,
                                   (void*)&set_preferred_privacy_req_msg,
                                   (void*)&set_preferred_privacy_resp_msg,
                                   NULL,
                                   NULL );
  
  if ( QMI_NO_ERR != tof_req_res )
  {
    MSG_ERROR( "[VOICE] qmi_voice_request_set_preferred_voice_privacy_mode() fail, error:%d", tof_req_res, 0, 0 );
    return RESULT_FAILURE;
  }
  
  if ( QMI_RESULT_SUCCESS_V01 != set_preferred_privacy_resp_msg.resp.result )
  {
    MSG_ERROR( "[VOICE] qmi_voice_request_set_preferred_voice_privacy_mode() rsp fail, error:%d", set_preferred_privacy_resp_msg.resp.error, 0, 0 );
    return RESULT_FAILURE;
  }
  
  return RESULT_SUCCESS;
}
//<-- RIL_REQUEST_CDMA_SET_PREFERRED_VOICE_PRIVACY_MODE


