/******************************************************************************
  @file    qmi_uim.cpp
  @brief   The QMI uim client

  DESCRIPTION

  INITIALIZATION AND SEQUENCING REQUIREMENTS

  ---------------------------------------------------------------------------
  Copyright (c) 2013 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/

#include <string.h>
#include <qmi.h>
#include "qmi_platform.h"
#include "qmi_uim.h"
#include "qmi_dms.h"
#include "TOF_API.h"
#include "TOF_Definition.h"

/* Log assertion level message */
#define QCRIL_ASSERT( xx_exp )                                         \
  if ( !( xx_exp ) )                                                       \
  {                                                                        \
    MSG_FATAL( "*****ASSERTION FAILED*****",0,0,0); \
  } 

#define QCRIL_UIM_INVALID_APP_INDEX_VALUE 0xff
#define QCRIL_UIM_INVALID_SLOT_INDEX_VALUE 0xff

#define MMGSDI_ICCID_LEN (10)

#define QMI_BCD_LOW_DIGIT(a) ((a) & 0x0F)
#define QMI_BCD_HIGH_DIGIT(a) (((a) >> 4) & 0x0F)

/* Instance ID */
typedef enum
{
  QCRIL_DEFAULT_INSTANCE_ID = 0,
  QCRIL_SECOND_INSTANCE_ID  = 1,
  QCRIL_MAX_INSTANCE_ID
} qcril_instance_id_e_type;

typedef enum
{
  QCRIL_UIM_PROVAPP_TYPE_GW_PRI = 0,
  QCRIL_UIM_PROVAPP_TYPE_GW_SEC,
  QCRIL_UIM_PROVAPP_TYPE_1X_PRI,
  QCRIL_UIM_PROVAPP_TYPE_1X_SEC
} qcril_uim_provapp_type_e_type;

qmi_client_handle_type uim_client_handle = QMI_INVALID_CLIENT_HANDLE;

//qmi_uim_get_card_status_rsp_type card_status;
RIL_CardStatus_v6 ril_cardstatus;

RIL_CardStatus_v6 card_status;

//tof_api.c
extern RIL_CardStatus_v6 tof_card_status;

static void qcril_uim_construct_card_status
(
  RIL_CardStatus_v6                 * ril_card_status_ptr,
  const qmi_uim_card_status_type    * card_status_ptr,
  uint8                               slot
);

/*=========================================================================

  FUNCTION:  qcril_uim_indication_cb

===========================================================================*/
/*!
    @brief
    Callback for QMI indications.

    @return
    None
*/
/*=========================================================================*/
void qmi_uim_indication_cb
(
  int                            user_handle,
  qmi_service_id_type            service_id,
  void                         * user_data,
  qmi_uim_indication_id_type     ind_id,
  qmi_uim_indication_data_type * ind_data_ptr
)
{
  int                               ind_params_tot_size = 0;

  printf("qmi_uim_indication_cb= %d \r\n", ind_id);

  switch(ind_id)
  {
    case QMI_UIM_SRVC_STATUS_CHANGE_IND_MSG:
      {
        qcril_uim_construct_card_status(&card_status, &ind_data_ptr->status_change_ind, 0);
        memcpy(&tof_card_status, &card_status, sizeof(RIL_CardStatus_v6));
        
#if 0
        if(wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW)
          wmm_set_cdma_radio_state_from_card_status();
        else
          wmm_set_radio_state_from_card_status();
#endif        
        //ALOGD(" [UIM] QMI_UIM_SRVC_STATUS_CHANGE_IND_MSG Card_state : %d Card_error : %d",ind_data_ptr->status_change_ind.card[0].card_state,ind_data_ptr->status_change_ind.card[0].card_error);
        MSG_HIGH(" [UIM] QMI_UIM_SRVC_STATUS_CHANGE_IND_MSG Card_state : %d Card_error : %d",ind_data_ptr->status_change_ind.card[0].card_state,ind_data_ptr->status_change_ind.card[0].card_error,0);
      }
      EventNotifyEnqueue(TOF_EVENT_RESPONSE_SIM_STATUS_CHANGED, 0, 0);
      break;      
	  
    case QMI_UIM_SRVC_REFRESH_IND_MSG:
      {
        MSG_HIGH("[UIM]QMI_UIM_SRVC_REFRESH_IND_MSG",0,0,0);
        //ALOGD("[UIM]QMI_UIM_SRVC_REFRESH_IND_MSG");
        if(wmm_get_ota_state() == WMM_STATE_OTA_NONE)
        {
          //UI Notify �� Reset ������ ����� Spec �̳� UI �׸��� �����ʿ�
          wmm_sim_refresh_reset();
          MSG_HIGH("[UIM]QMI_UIM_SRVC_REFRESH_IND_MSG in WMM_STATE_OTA_NONE",0,0,0);
          //ALOGD("[UIM]QMI_UIM_SRVC_REFRESH_IND_MSG in WMM_STATE_OTA_NONE");
        }
        if(ind_data_ptr->refresh_ind.refresh_event.refresh_stage == QMI_UIM_REFRESH_STAGE_START)
          EventNotifyEnqueue(TOF_IND_SIM_REFRESH, 0, 0);
      }
      break;
	  
    case QMI_UIM_SRVC_OTA_IND_MSG:
      {
        int OTAEndCause = E_OTA_REGISTERED;
        
        OTAEndCause = (int)ind_data_ptr->ota_result;

        wmm_set_ota_state_from_uim_ind((int)ind_data_ptr->ota_result);
//        Send_UnsolicitedResponse( RIL_UNSOL_HK_OTA_END_PROCESS, &OTAEndCause, sizeof( OTAEndCause ) );
        //ALOGD("[UIM]QMI_UIM_SRVC_OTA_IND_MSG : ota_result : %d ",ind_data_ptr->ota_result);
        MSG_HIGH("[UIM]QMI_UIM_SRVC_OTA_IND_MSG : ota_result : %d ",ind_data_ptr->ota_result,0,0);
      }
      break;

    default:
      break;
  }

  return;
} /* qcril_uim_indication_cb */

/*=========================================================================

  FUNCTION:  qmi_uim_async_cb

===========================================================================*/
/*!
    @brief
    Callback for QMI async.

    @return
    None
*/
/*=========================================================================*/
void qmi_uim_async_cb
(
  int                            user_handle,
  qmi_service_id_type            service_id,
  qmi_uim_rsp_data_type        * rsp_data,
  void                         * user_data
)
{
  MSG_MED("[UIM]qmi_uim_async_cb!!",0,0,0);
	return;
} /* qmi_uim_async_cb */

/*===========================================================================

  FUNCTION  tof_qmi_uim_init
  
===========================================================================*/
boolean tof_qmi_uim_init()
{
  int qmi_err_code = QMI_NO_ERR;
  int rc = QMI_INTERNAL_ERR;  
  qmi_uim_rsp_data_type	rsp_data;
  qmi_uim_event_reg_params_type  event_reg_params;
  
  if(uim_client_handle != QMI_INVALID_CLIENT_HANDLE) RESULT_SUCCESS;
  
  /* Bring up UIM service for second port */
  if ((uim_client_handle = tof_tof_qmi_uim_srvc_init_client (QMI_PORT_RMNET_0,
                                                 qmi_uim_indication_cb, // callback function. 
                                                 NULL, 
                                                 &qmi_err_code)) < 0)
  {
    printf("Unable to start UIM service uim_client_handle= %x, qmi_err_code=%x\n", 
           uim_client_handle, 
           qmi_err_code);
    return RESULT_FAILURE;
  }
  else
  {
    printf("Opened UIM Client. uim_client_handle= %x \r\n", uim_client_handle);
  }  

  /* Register for events first */
  memset(&event_reg_params, 0, sizeof(qmi_uim_event_reg_params_type));
  event_reg_params.card_status = QMI_UIM_TRUE;
  
  rc = qmi_uim_event_reg((int)uim_client_handle,
  						   &event_reg_params,
  						   &rsp_data);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
  	MSG_ERROR("[UIM]qmi_uim_event_reg!! rc: %d err_code : %d",rc,qmi_err_code, 0);
  	return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;
}

/*===========================================================================

  FUNCTION  tof_qmi_uim_srvc_release
  
===========================================================================*/
int tof_qmi_uim_srvc_release()
{
  int ret = QMI_INTERNAL_ERR;
  int qmi_err_code = QMI_INTERNAL_ERR;
  int app_index = 0;

  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return ret;

	for (app_index = 0; app_index < card_status.num_applications; app_index++)
	{
		if(card_status.applications[app_index].aid_ptr != NULL)
		{
			free(card_status.applications[app_index].aid_ptr);
			card_status.applications[app_index].aid_ptr = NULL;
		}
	}

  ret = tof_tof_qmi_uim_srvc_release_client((int)uim_client_handle, &qmi_err_code);

  if(ret == QMI_NO_ERR)
    uim_client_handle = INVALID_HANDLE_VALUE;
  
  return ret;
}

/*===========================================================================

  FUNCTION  tof_qmi_uim_release
  
===========================================================================*/
boolean tof_qmi_uim_release()
{
   int qmi_err_code = QMI_NO_ERR;
   int rc = QMI_NO_ERR;

   if(uim_client_handle == QMI_INVALID_CLIENT_HANDLE) return RESULT_SUCCESS;
   
  if(uim_client_handle != QMI_INVALID_CLIENT_HANDLE)
  {
    rc = tof_tof_qmi_uim_srvc_release_client(uim_client_handle, &qmi_err_code);
    if(rc != QMI_NO_ERR)
    {
      printf("tof_tof_qmi_uim_srvc_release_client rc = %d, qmi_err_code \n", rc, qmi_err_code);
      return RESULT_FAILURE;
    } 
  }
  else
  {
    printf("tof_qmi_release uim_client_handle= %x\r\n", uim_client_handle);
  }

  return RESULT_SUCCESS;
}


/*=========================================================================

  FUNCTION:  qcril_uim_bin_to_hexchar

===========================================================================*/
/*!
    @brief
    Converts a single character from ASCII to binary

    @return
    Binary value of the ASCII characters
*/
/*=========================================================================*/
char qcril_uim_bin_to_hexchar
(
  uint8 ch
)
{
  QCRIL_ASSERT(ch < 0x10);

  if (ch < 0x0a)
  {
    return (ch + '0');
  }
  return (ch + 'a' - 10);
} /* qcril_uim_bin_to_hexchar */

/*=========================================================================

  FUNCTION:  qcril_uim_bin_to_hexstring

===========================================================================*/
/*!
    @brief
    Converts a binary buffer into a string in ASCII format.
    Memory is not allocated for this conversion.

    @return
    None
*/
/*=========================================================================*/
void qcril_uim_bin_to_hexstring
(
  const uint8*  buffer_ptr,
  uint16        buffer_size,
  char*         string_ptr,
  uint16        string_size
)
{
  int    i = 0;

  QCRIL_ASSERT(buffer_ptr != NULL);
  QCRIL_ASSERT(string_ptr != NULL);
  
  QCRIL_ASSERT(string_size >= (buffer_size * 2) + sizeof(char));
  
  memset(string_ptr, 0, string_size);
  
  for (i = 0; i < buffer_size; i++)
  {
    string_ptr[i * 2] = qcril_uim_bin_to_hexchar((buffer_ptr[i] >> 4) & 0x0F);
    string_ptr[i * 2 + 1] = qcril_uim_bin_to_hexchar(buffer_ptr[i] & 0x0F);
  }
  string_ptr[buffer_size * 2] = 0x0;
} /* qcril_uim_bin_to_hexstring */

/*=========================================================================

  FUNCTION:  qcril_uim_alloc_bin_to_hexstring

===========================================================================*/
/*!
    @brief
    Converts a binary buffer into a string in ASCII format.
    Memory is allocated for the conversion.

    @return
    Pointer to the NULL terminated string
*/
/*=========================================================================*/
char* qcril_uim_alloc_bin_to_hexstring
(
  const uint8*  buffer_ptr,
  uint16        buffer_size
)
{
  char*  out_ptr    = NULL;
  uint16 string_len = 0;
  
  QCRIL_ASSERT(buffer_ptr != NULL);
  
  string_len = (buffer_size * 2) + sizeof(char);
  
  out_ptr = (char *)malloc(string_len);
  
  if (out_ptr != NULL)
  {
    qcril_uim_bin_to_hexstring(buffer_ptr, buffer_size, out_ptr, string_len);
  }
  
  return out_ptr;
} /* qcril_uim_alloc_bin_to_hexstring */

/*===========================================================================

  FUNCTION:  qcril_uim_convert_perso_state_code_required

===========================================================================*/
/*!
    @brief
    Converts qmi_uim_perso_feature_id_type to RIL_PersoSubstate for the 
    cases where the codes for personalization codes are needed. 

    @return
    Mapped RIL_PersoSubstate.
*/
/*=========================================================================*/
static RIL_PersoSubstate qcril_uim_convert_perso_state_code_required
(
  qmi_uim_perso_feature_id_type   qmi_perso_feature_id
)
{
  RIL_PersoSubstate   perso_substate = RIL_PERSOSUBSTATE_UNKNOWN;

  switch(qmi_perso_feature_id)
  {
    case QMI_UIM_PERSO_FEATURE_GW_NW:
      perso_substate = RIL_PERSOSUBSTATE_SIM_NETWORK;            
      break;
    case QMI_UIM_PERSO_FEATURE_GW_NS:
      perso_substate = RIL_PERSOSUBSTATE_SIM_NETWORK_SUBSET;
      break;
    case QMI_UIM_PERSO_FEATURE_GW_SP:
      perso_substate = RIL_PERSOSUBSTATE_SIM_SERVICE_PROVIDER; 
      break;
    case QMI_UIM_PERSO_FEATURE_GW_CP:
      perso_substate = RIL_PERSOSUBSTATE_SIM_CORPORATE;
      break;
    case QMI_UIM_PERSO_FEATURE_GW_SIM:
      perso_substate = RIL_PERSOSUBSTATE_SIM_SIM;
      break;
    case QMI_UIM_PERSO_FEATURE_1X_NW1:
      perso_substate = RIL_PERSOSUBSTATE_RUIM_NETWORK1;
      break;
    case QMI_UIM_PERSO_FEATURE_1X_NW2:
      perso_substate = RIL_PERSOSUBSTATE_RUIM_NETWORK2;
      break;
    case QMI_UIM_PERSO_FEATURE_1X_HRPD:
      perso_substate = RIL_PERSOSUBSTATE_RUIM_HRPD;
      break;
    case QMI_UIM_PERSO_FEATURE_1X_SP:
      perso_substate = RIL_PERSOSUBSTATE_RUIM_SERVICE_PROVIDER;      
      break;
    case QMI_UIM_PERSO_FEATURE_1X_CP:
      perso_substate = RIL_PERSOSUBSTATE_RUIM_CORPORATE;
      break;
    case QMI_UIM_PERSO_FEATURE_1X_RUIM:
      perso_substate = RIL_PERSOSUBSTATE_RUIM_RUIM;
      break;
    case QMI_UIM_PERSO_FEATURE_UNKNOWN:
    default:
      perso_substate = RIL_PERSOSUBSTATE_UNKNOWN;
      break;
  }
  return perso_substate;
} /* qcril_uim_convert_perso_state_code_required */

/*===========================================================================

  FUNCTION:  qcril_uim_convert_perso_state_puk_required

===========================================================================*/
/*!
    @brief
    Converts qmi_uim_perso_feature_id_type to RIL_PersoSubstate for the 
    cases where PUK for personalization codes are needed. 

    @return
    Mapped RIL_PersoSubstate.
*/
/*=========================================================================*/
static RIL_PersoSubstate qcril_uim_convert_perso_state_puk_required
(
  qmi_uim_perso_feature_id_type   qmi_perso_feature_id
)
{
  RIL_PersoSubstate   perso_substate = RIL_PERSOSUBSTATE_UNKNOWN;

  switch(qmi_perso_feature_id)
  {
    case QMI_UIM_PERSO_FEATURE_GW_NW:
      perso_substate = RIL_PERSOSUBSTATE_SIM_NETWORK_PUK;
      break;
    case QMI_UIM_PERSO_FEATURE_GW_NS:
      perso_substate = RIL_PERSOSUBSTATE_SIM_NETWORK_SUBSET_PUK;
      break;
    case QMI_UIM_PERSO_FEATURE_GW_SP:
      perso_substate = RIL_PERSOSUBSTATE_SIM_SERVICE_PROVIDER_PUK;
      break;
    case QMI_UIM_PERSO_FEATURE_GW_CP:
      perso_substate = RIL_PERSOSUBSTATE_SIM_CORPORATE_PUK;
      break;
    case QMI_UIM_PERSO_FEATURE_GW_SIM:
      perso_substate = RIL_PERSOSUBSTATE_SIM_SIM_PUK;
      break;
    case QMI_UIM_PERSO_FEATURE_1X_NW1:
      perso_substate = RIL_PERSOSUBSTATE_RUIM_NETWORK1_PUK;
      break;
    case QMI_UIM_PERSO_FEATURE_1X_NW2:
      perso_substate = RIL_PERSOSUBSTATE_RUIM_NETWORK2_PUK;
      break;
    case QMI_UIM_PERSO_FEATURE_1X_HRPD:
      perso_substate = RIL_PERSOSUBSTATE_RUIM_HRPD_PUK;
      break;
    case QMI_UIM_PERSO_FEATURE_1X_SP:
      perso_substate = RIL_PERSOSUBSTATE_RUIM_SERVICE_PROVIDER_PUK;
      break;
    case QMI_UIM_PERSO_FEATURE_1X_CP:
      perso_substate = RIL_PERSOSUBSTATE_RUIM_CORPORATE_PUK;
      break;
    case QMI_UIM_PERSO_FEATURE_1X_RUIM:
      perso_substate = RIL_PERSOSUBSTATE_RUIM_RUIM_PUK;
      break;
    case QMI_UIM_PERSO_FEATURE_UNKNOWN:
    default:
      perso_substate = RIL_PERSOSUBSTATE_UNKNOWN;
      break;
  }
  return perso_substate;
} /* qcril_uim_convert_perso_state_puk_required */

/*===========================================================================

  FUNCTION:  qcril_uim_convert_card_state

===========================================================================*/
/*!
    @brief
    Converts a qmi_uim_card_state_type to RIL_CardState. Mapped RIL_CardState
    is updated in the passed pointer.

    @return
    None.
*/
/*=========================================================================*/
static void qcril_uim_convert_card_state
(
  RIL_CardState             * ril_card_state_ptr, 
  qmi_uim_card_state_type     qmi_card_state,
  qmi_uim_card_error_type     qmi_card_error
)
{
  QCRIL_ASSERT( ril_card_state_ptr != NULL );

  switch(qmi_card_state)
  {
    case QMI_UIM_CARD_STATE_ABSENT:
      *ril_card_state_ptr = RIL_CARDSTATE_ABSENT;
      break;

    case QMI_UIM_CARD_STATE_PRESENT:
      *ril_card_state_ptr = RIL_CARDSTATE_PRESENT;
      break;

    case QMI_UIM_CARD_STATE_ERROR:
      { /* non DSDS */
        if ((qmi_card_error == QMI_UIM_CARD_ERROR_NO_ATR_RECEIVED) ||
            (qmi_card_error == QMI_UIM_CARD_ERROR_UNKNOWN_REMOVED) ||
            (qmi_card_error == QMI_UIM_CARD_ERROR_POWER_DOWN))
        {
          *ril_card_state_ptr = RIL_CARDSTATE_ABSENT;
        }
        else
        {
          *ril_card_state_ptr = RIL_CARDSTATE_ERROR;
        }
      }
      break;

    default:
      *ril_card_state_ptr = RIL_CARDSTATE_ERROR;
      break;
  }
} /* qcril_uim_convert_card_state */

/*===========================================================================

  FUNCTION:  qcril_uim_convert_pin_state

===========================================================================*/
/*!
    @brief
    Converts a qmi_uim_pin_status_type to RIL_PinState. Mapped RIL_PinState
    is updated in the passed pointer.

    @return
    None.
*/
/*=========================================================================*/
static void qcril_uim_convert_pin_state
(
  RIL_PinState              * ril_pin_state_ptr, 
  qmi_uim_pin_status_type     qmi_pin_state
)
{
  QCRIL_ASSERT( ril_pin_state_ptr != NULL );

  switch(qmi_pin_state)
  {
    case QMI_UIM_PIN_STATE_ENABLED_NOT_VERIFIED:
      *ril_pin_state_ptr = RIL_PINSTATE_ENABLED_NOT_VERIFIED;
      break;

    case QMI_UIM_PIN_STATE_ENABLED_VERIFIED:
      *ril_pin_state_ptr = RIL_PINSTATE_ENABLED_VERIFIED;
      break;

    case QMI_UIM_PIN_STATE_DISABLED:
      *ril_pin_state_ptr = RIL_PINSTATE_DISABLED;
      break;

    case QMI_UIM_PIN_STATE_BLOCKED:
      *ril_pin_state_ptr = RIL_PINSTATE_ENABLED_BLOCKED;
      break;

    case QMI_UIM_PIN_STATE_PERM_BLOCKED:
      *ril_pin_state_ptr = RIL_PINSTATE_ENABLED_PERM_BLOCKED;
      break;

    case QMI_UIM_PIN_STATE_UNKNOWN:
    default:
      *ril_pin_state_ptr = RIL_PINSTATE_UNKNOWN;
      break;
  }
} /* qcril_uim_convert_pin_state */

/*===========================================================================

  FUNCTION:  qcril_uim_update_prov_app_index

===========================================================================*/
/*!
    @brief
    Checks if the passed provisioning app index belongs to the input slot
    requested for. If yes, respective index variables - GSM/UMTS or CDMA of
    RIL_CardStatus_v6 are updated based on the type of the provisioning app.

    @return
    None.

*/
/*=========================================================================*/
static void qcril_uim_update_prov_app_index
(
  unsigned short        input_index,
  uint8                 input_slot,
  RIL_CardStatus_v6   * ril_card_status_ptr,
  int                   prov_app_type
)
{
  uint8 prov_app_index = QCRIL_UIM_INVALID_APP_INDEX_VALUE;
  uint8 prov_app_slot  = QCRIL_UIM_INVALID_SLOT_INDEX_VALUE;

  QCRIL_ASSERT( ril_card_status_ptr != NULL );

  prov_app_index = input_index & 0xFF;
  prov_app_slot  = (input_index >> 8) & 0xFF;

  /* Check if the passed prov app's slot matches with the card index */
  if ((input_slot == prov_app_slot) &&
      (prov_app_index < RIL_CARD_MAX_APPS))
  {
    switch(prov_app_type)
    {
      case QCRIL_UIM_PROVAPP_TYPE_GW_PRI:
      case QCRIL_UIM_PROVAPP_TYPE_GW_SEC:
        ril_card_status_ptr->gsm_umts_subscription_app_index = prov_app_index;
        break;

      case QCRIL_UIM_PROVAPP_TYPE_1X_PRI:
      case QCRIL_UIM_PROVAPP_TYPE_1X_SEC:
        ril_card_status_ptr->cdma_subscription_app_index = prov_app_index;
        break;

      default:
        break;
    }
  }
} /* qcril_uim_update_prov_app_index */

/*===========================================================================

  FUNCTION:  qcril_uim_convert_app_type

===========================================================================*/
/*!
    @brief
    Converts a qmi_uim_app_type to RIL_AppType. Mapped RIL_AppType
    is updated in the passed pointer.

    @return
    None.
*/
/*=========================================================================*/
static void qcril_uim_convert_app_type
(
  RIL_AppType               * ril_app_type_ptr,
  qmi_uim_app_type            qmi_app_type
)
{
  QCRIL_ASSERT( ril_app_type_ptr != NULL );

  switch(qmi_app_type)
  {
    case QMI_UIM_APP_SIM:
      *ril_app_type_ptr = RIL_APPTYPE_SIM;
      break;

    case QMI_UIM_APP_USIM:
      *ril_app_type_ptr = RIL_APPTYPE_USIM;
      break;

    case QMI_UIM_APP_RUIM:
      *ril_app_type_ptr = RIL_APPTYPE_RUIM;
      break;

    case QMI_UIM_APP_CSIM:
      *ril_app_type_ptr = RIL_APPTYPE_CSIM;
      break;

    case QMI_UIM_APP_UNKNOWN:
    default:
      *ril_app_type_ptr = (RIL_AppType)QMI_UIM_APP_STATE_UNKNOWN;
      break;
  }
} /* qcril_uim_convert_app_type */

/*===========================================================================

  FUNCTION:  qcril_uim_convert_app_state_to_ril

===========================================================================*/
/*!
    @brief
    Converts a qmi_uim_app_state_type to RIL_AppState. Mapped RIL_AppState
    is updated in the passed pointer.

    @return
    None.
*/
/*=========================================================================*/
static void qcril_uim_convert_app_state_to_ril
(
  RIL_AppState              * ril_app_state_ptr,
  qmi_uim_app_state_type      qmi_app_state
)
{
  QCRIL_ASSERT( ril_app_state_ptr != NULL );

  switch(qmi_app_state)
  {
    case QMI_UIM_APP_STATE_UNKNOWN:
      *ril_app_state_ptr = RIL_APPSTATE_UNKNOWN;
      break;

    case QMI_UIM_APP_STATE_DETECTED:
      *ril_app_state_ptr = RIL_APPSTATE_DETECTED;
      break;

    case QMI_UIM_APP_STATE_PIN_REQUIRED:
      *ril_app_state_ptr = RIL_APPSTATE_PIN;
      break;

    case QMI_UIM_APP_STATE_PUK1_REQUIRED:
    case QMI_UIM_APP_STATE_BLOCKED:
      *ril_app_state_ptr = RIL_APPSTATE_PUK;
      break;

    case QMI_UIM_APP_STATE_PERSO:
      *ril_app_state_ptr = RIL_APPSTATE_SUBSCRIPTION_PERSO;
      break;

    case QMI_UIM_APP_STATE_ILLEGAL:
      *ril_app_state_ptr = RIL_APPSTATE_READY; // android 4.2 define base 
      break;

    case QMI_UIM_APP_STATE_READY:
      *ril_app_state_ptr = RIL_APPSTATE_READY;
      break;

    default:
      *ril_app_state_ptr = (RIL_AppState)QMI_UIM_APP_STATE_UNKNOWN;
      break;
  }
} /* qcril_uim_convert_app_state_to_ril */


/*===========================================================================

  FUNCTION:  qcril_uim_convert_perso_state_all

===========================================================================*/
/*!
    @brief
    Converts a qmi_uim_app_state_type to RIL_PersoSubstate. Mapped 
    RIL_PersoSubstate is updated in the passed pointer.

    @return
    None.
*/
/*=========================================================================*/
static void qcril_uim_convert_perso_state_all
(
  RIL_PersoSubstate             * ril_perso_substate_ptr,
  qmi_uim_perso_state_type        qmi_perso_state,
  qmi_uim_perso_feature_id_type   qmi_perso_feature_id
)
{
  QCRIL_ASSERT( ril_perso_substate_ptr != NULL );

  switch(qmi_perso_state)
  {    
    case QMI_UIM_PERSO_STATE_IN_PROGRESS:
      *ril_perso_substate_ptr = RIL_PERSOSUBSTATE_IN_PROGRESS;
      break;

    case QMI_UIM_PERSO_STATE_READY:
      *ril_perso_substate_ptr = RIL_PERSOSUBSTATE_READY;
      break;

    case QMI_UIM_PERSO_STATE_CODE_REQUIRED:
      *ril_perso_substate_ptr = 
        qcril_uim_convert_perso_state_code_required(qmi_perso_feature_id);
      break;

    /* Currently mapping permanently blocked case to PUK */
    case QMI_UIM_PERSO_STATE_PUK_REQUIRED:
    case QMI_UIM_PERSO_STATE_PERM_BLOCKED:
      *ril_perso_substate_ptr = 
        qcril_uim_convert_perso_state_puk_required(qmi_perso_feature_id);
      break;

    case QMI_UIM_PERSO_STATE_UNKNOWN:
    default:
      *ril_perso_substate_ptr = RIL_PERSOSUBSTATE_UNKNOWN;
      break;
  }
} /* qcril_uim_convert_perso_state_all */

/*===========================================================================

  FUNCTION:  qcril_uim_add_aid_info

===========================================================================*/
/*!
    @brief
    Updates the passed RIL AID pointer with AID data if it has been received 
    from QMI, does nothing otherwise.

    @return
    None.
*/
/*=========================================================================*/
static void qcril_uim_add_aid_info
(
  char             ** ril_aid_ptr,
  const char       *  qmi_aid_ptr,
  unsigned char       qmi_aid_len
)
{
  QCRIL_ASSERT( ril_aid_ptr != NULL );
  QCRIL_ASSERT( qmi_aid_ptr != NULL );

  if(*ril_aid_ptr != NULL)
  {
    free(*ril_aid_ptr);
    *ril_aid_ptr = NULL;
  }

  /* Convert the AID in hex to a null terminated ASCII string 
     The function qcril_uim_alloc_bin_to_hexstring will perform the malloc & data conversion */
  *ril_aid_ptr = qcril_uim_alloc_bin_to_hexstring((const uint8*)qmi_aid_ptr, 
                                                  qmi_aid_len);

  if (*ril_aid_ptr == NULL)
  {
    MSG_ERROR("Unable to allocate aid_ptr",0,0,0);
  }
} /* qcril_uim_add_aid_info */

/*===========================================================================

  FUNCTION:  qcril_uim_construct_card_status

===========================================================================*/
/*!
    @brief
    Constructs the RIL card status from our internal QMI card status type.
    Also, an appropriate card state name is filled.  

    @return
    None.
*/
/*=========================================================================*/
static void qcril_uim_construct_card_status
(
  RIL_CardStatus_v6                 * ril_card_status_ptr,
  const qmi_uim_card_status_type    * card_status_ptr,
  uint8                               slot
)
{
  int                   app_index = 0;
  int                   max_apps  = 0;
  qmi_uim_rsp_data_type get_label_rsp;

  QCRIL_ASSERT( ril_card_status_ptr != NULL );
  QCRIL_ASSERT( card_status_ptr != NULL );
  QCRIL_ASSERT( slot < QMI_UIM_MAX_CARD_COUNT );

  memset(ril_card_status_ptr, 0, sizeof(RIL_CardStatus_v6));
  memset(&get_label_rsp, 0, sizeof(qmi_uim_rsp_data_type));

  /* Update Card state */
  qcril_uim_convert_card_state(&ril_card_status_ptr->card_state,
                               card_status_ptr->card[slot].card_state,
                               card_status_ptr->card[slot].card_error);
  /* Update UPIN state */
  qcril_uim_convert_pin_state(&ril_card_status_ptr->universal_pin_state, 
                              card_status_ptr->card[slot].upin_state);

  /* Init App indexes */
  ril_card_status_ptr->gsm_umts_subscription_app_index = -1;
  ril_card_status_ptr->cdma_subscription_app_index = -1;
  ril_card_status_ptr->ims_subscription_app_index = -1;

  /* Update App indexes */
  qcril_uim_update_prov_app_index(card_status_ptr->index_gw_pri_prov, slot,
                                  ril_card_status_ptr, QCRIL_UIM_PROVAPP_TYPE_GW_PRI);
  qcril_uim_update_prov_app_index(card_status_ptr->index_gw_sec_prov, slot,
                                  ril_card_status_ptr, QCRIL_UIM_PROVAPP_TYPE_GW_SEC);
  qcril_uim_update_prov_app_index(card_status_ptr->index_1x_pri_prov, slot,
                                  ril_card_status_ptr, QCRIL_UIM_PROVAPP_TYPE_1X_PRI);
  qcril_uim_update_prov_app_index(card_status_ptr->index_1x_sec_prov, slot,
                                  ril_card_status_ptr, QCRIL_UIM_PROVAPP_TYPE_1X_SEC);

  max_apps = (card_status_ptr->card[slot].num_app <= RIL_CARD_MAX_APPS)
              ? card_status_ptr->card[slot].num_app : RIL_CARD_MAX_APPS;

  ril_card_status_ptr->num_applications = max_apps;

  for (app_index = 0; app_index < max_apps; app_index++)
  {
    qcril_uim_convert_app_type(&ril_card_status_ptr->applications[app_index].app_type, 
                               card_status_ptr->card[slot].application[app_index].app_type);
    qcril_uim_convert_app_state_to_ril(&ril_card_status_ptr->applications[app_index].app_state, 
                                       card_status_ptr->card[slot].application[app_index].app_state);
    qcril_uim_convert_perso_state_all(&ril_card_status_ptr->applications[app_index].perso_substate, 
                                      card_status_ptr->card[slot].application[app_index].perso_state,
                                      card_status_ptr->card[slot].application[app_index].perso_feature);
    qcril_uim_add_aid_info(&ril_card_status_ptr->applications[app_index].aid_ptr, 
                           card_status_ptr->card[slot].application[app_index].aid_value,
                           card_status_ptr->card[slot].application[app_index].aid_len);

    qcril_uim_convert_pin_state(&ril_card_status_ptr->applications[app_index].pin1,
                                card_status_ptr->card[slot].application[app_index].pin1_state);
    qcril_uim_convert_pin_state(&ril_card_status_ptr->applications[app_index].pin2,
                                card_status_ptr->card[slot].application[app_index].pin2_state);
  }
} /* qcril_uim_construct_card_status */

/*===========================================================================

  FUNCTION  ril_request_get_sim_status
  
===========================================================================*/
uint8 ril_request_get_sim_status(RIL_CardStatus_v6 *pcard_status)
{
  int rc = QMI_NO_ERR;
  qmi_uim_rsp_data_type	rsp_data;
  
  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_uim_get_card_status((int)uim_client_handle,NULL,NULL,&rsp_data);
  if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]qmi_uim_get_card_status!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    qcril_uim_construct_card_status(pcard_status, &rsp_data.rsp_data.get_card_status_rsp.card_status, 0);

    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  ril_request_get_est_list
  
===========================================================================*/
uint8 ril_request_get_est_list(wmmdiag_get_est_rsp_type *est_list)
{
  int rc = QMI_NO_ERR;
  static char file_path[4];
  char ef_est[100];
  qmi_uim_read_transparent_params_type params;
  qmi_uim_rsp_data_type	rsp_data;
  int result = RESULT_FAILURE;

  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
  
  file_path[0] = 0x3F;
  file_path[1] = 0x00;
  file_path[2] = 0x7F;
  file_path[3] = 0xFF;

  params.session_info.session_type = QMI_UIM_SESSION_TYPE_PRI_GW_PROV;
  params.session_info.aid.data_len = 0;
  params.session_info.aid.data_ptr = NULL;

  params.file_id.file_id = 0x6F56;   /* EF EST */
  params.file_id.path.data_len = 4;
  params.file_id.path.data_ptr = (unsigned char*)file_path;
  params.offset = 0;
  params.length = 0;
    
  rc = qmi_uim_read_transparent((int)uim_client_handle,&params,NULL,NULL,&rsp_data);
  if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]qmi_uim_read_transparent!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
    result = RESULT_FAILURE;
  }
  else
  {
    if((rsp_data.rsp_data.read_transparent_rsp.sw1 == 0x90) || (rsp_data.rsp_data.read_transparent_rsp.sw2 == 0x00))
    {
      est_list->result = TRUE;
      memcpy(ef_est,rsp_data.rsp_data.read_transparent_rsp.content.data_ptr ,rsp_data.rsp_data.read_transparent_rsp.content.data_len);
      est_list->est_available[0] = 0x01 & ef_est[0];
      est_list->est_available[1] = 0x02 & ef_est[0];
      est_list->est_available[2] = 0x04 & ef_est[0];
        
      result = RESULT_SUCCESS;
    }
    else
    {
      est_list->result = FALSE;        
      result = RESULT_SUCCESS;
    }
  }

  if(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr != NULL)
  {
	  free(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr);
	  rsp_data.rsp_data.read_transparent_rsp.content.data_ptr = NULL;
  }

  return result;
}

/*===========================================================================

  FUNCTION  ril_request_get_ust_list
  
===========================================================================*/
uint8 ril_request_get_ust_list(wmmdiag_get_ust_rsp_type *ust_list)
{
  int rc = QMI_NO_ERR;
  static char file_path[4];
  char ef_ust[100];
  qmi_uim_read_transparent_params_type params;
  qmi_uim_rsp_data_type	rsp_data;
  int i, j = 0;
  int result = RESULT_FAILURE;

  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
  
  file_path[0] = 0x3F;
  file_path[1] = 0x00;
  file_path[2] = 0x7F;
  file_path[3] = 0xFF;

  params.session_info.session_type = QMI_UIM_SESSION_TYPE_PRI_GW_PROV;
  params.session_info.aid.data_len = 0;
  params.session_info.aid.data_ptr = NULL;

  params.file_id.file_id = 0x6F38;   /* EF UST */
  params.file_id.path.data_len = 4;
  params.file_id.path.data_ptr = (unsigned char*)file_path;
  params.offset = 0;
  params.length = 0;
    
  rc = qmi_uim_read_transparent((int)uim_client_handle,&params,NULL,NULL,&rsp_data);
  if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]qmi_uim_read_transparent!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
    result = RESULT_FAILURE;
  }
  else
  {
    if((rsp_data.rsp_data.read_transparent_rsp.sw1 == 0x90) || (rsp_data.rsp_data.read_transparent_rsp.sw2 == 0x00))
    {
      ust_list->result = TRUE;
      memcpy(ef_ust,rsp_data.rsp_data.read_transparent_rsp.content.data_ptr ,rsp_data.rsp_data.read_transparent_rsp.content.data_len);
      for(i=0;i<KTF_UST_ITEM_NUM-2;i+=8) //8 * 7 =56
      {
        ust_list->ust_available[i] = ef_ust[j] & 0x1;
		ust_list->ust_available[i+1] = ef_ust[j] & 0x2;
		ust_list->ust_available[i+2] = ef_ust[j] & 0x4;
		ust_list->ust_available[i+3] = ef_ust[j] & 0x8;
		ust_list->ust_available[i+4] = ef_ust[j] & 0x10;
		ust_list->ust_available[i+5] = ef_ust[j] & 0x20;
		ust_list->ust_available[i+6] = ef_ust[j] & 0x40;
		ust_list->ust_available[i+7] = ef_ust[j] & 0x80;
		j++;
      }

      // 57 & 58
      ust_list->ust_available[i] = ef_ust[j] & 0x1;
      ust_list->ust_available[i+1] = ef_ust[j] & 0x2;
      
      for(i=0;i<KTF_UST_ITEM_NUM;i++)
      {
        if(ust_list->ust_available[i])
          ust_list->ust_available[i] = TRUE;
        else
          ust_list->ust_available[i] = FALSE;
      }
              
      result = RESULT_SUCCESS;
    }
    else
    {
      ust_list->result = FALSE;        
      result = RESULT_SUCCESS;
    }
  }

  if(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr != NULL)
  {
	  free(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr);
	  rsp_data.rsp_data.read_transparent_rsp.content.data_ptr = NULL;
  }

  return result;
}

/*===========================================================================

  FUNCTION  ril_request_get_fplmn_list
  
===========================================================================*/
uint8 ril_request_get_fplmn_list(wmmdiag_get_fplmn_rsp_type *fplmn_list)
{
  int rc = QMI_NO_ERR;
  static char file_path[4];
  unsigned char ef_fplmn[512];
  qmi_uim_read_transparent_params_type params;
  qmi_uim_rsp_data_type	rsp_data;
  int i , j = 0;
  int result = RESULT_FAILURE;

  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
  
  file_path[0] = 0x3F;
  file_path[1] = 0x00;
  file_path[2] = 0x7F;
  file_path[3] = 0xFF;

  params.session_info.session_type = QMI_UIM_SESSION_TYPE_PRI_GW_PROV;
  params.session_info.aid.data_len = 0;
  params.session_info.aid.data_ptr = NULL;

  params.file_id.file_id = 0x6F7B;   /* EF FPLMN */
  params.file_id.path.data_len = 4;
  params.file_id.path.data_ptr = (unsigned char*)file_path;
  params.offset = 0;
  params.length = 0;
    
  rc = qmi_uim_read_transparent((int)uim_client_handle,&params,NULL,NULL,&rsp_data);
  if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]qmi_uim_read_transparent!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
    result = RESULT_FAILURE;
  }
  else
  {
    if((rsp_data.rsp_data.read_transparent_rsp.sw1 == 0x90) || (rsp_data.rsp_data.read_transparent_rsp.sw2 == 0x00))
    {
      memcpy(ef_fplmn,rsp_data.rsp_data.read_transparent_rsp.content.data_ptr ,rsp_data.rsp_data.read_transparent_rsp.content.data_len);
      fplmn_list->item_cnt = 0;
      j = 0;
      for(i=0;i<rsp_data.rsp_data.read_transparent_rsp.content.data_len;i+=3)
      {
        if(ef_fplmn[i] == 0xFF)
        {
          result = RESULT_SUCCESS;
          break;
        }
        else
        {
          fplmn_list->fplmn_item[j].fplmn[0] = 'M';
          fplmn_list->fplmn_item[j].fplmn[1] = 'C';
          fplmn_list->fplmn_item[j].fplmn[2] = 'C';
          fplmn_list->fplmn_item[j].fplmn[3] = ':';
          fplmn_list->fplmn_item[j].fplmn[4] = (ef_fplmn[i] & 0xF) + '0';
          fplmn_list->fplmn_item[j].fplmn[5]  = ((ef_fplmn[i] & 0xF0) >> 4) + '0';
          fplmn_list->fplmn_item[j].fplmn[6] =  (ef_fplmn[i+1]  & 0xF) + '0';
          fplmn_list->fplmn_item[j].fplmn[7] = '/';
          fplmn_list->fplmn_item[j].fplmn[8] = 'M';
          fplmn_list->fplmn_item[j].fplmn[9] = 'N';
          fplmn_list->fplmn_item[j].fplmn[10] = 'C';
          fplmn_list->fplmn_item[j].fplmn[11] = ':';          
          fplmn_list->fplmn_item[j].fplmn[12] =  (ef_fplmn[i+2]  & 0xF) + '0';
          fplmn_list->fplmn_item[j].fplmn[13] =  ((ef_fplmn[i+2]  & 0xF0) >> 4) + '0';
        }
        fplmn_list->item_cnt++;
        j++;
      }
      result = RESULT_SUCCESS;
    }
    else
    {
      //ust_list->result = FALSE;        
      result = RESULT_SUCCESS;
    }
  }

  if(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr != NULL)
  {
	  free(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr);
	  rsp_data.rsp_data.read_transparent_rsp.content.data_ptr = NULL;
  }

  return result;
}

/*===========================================================================

  FUNCTION  ril_request_get_plmnwact_list
  
===========================================================================*/
uint8 ril_request_get_plmnwact_list(wmmdiag_plmnwact_list_type *plmn_list)
{
  int rc = QMI_NO_ERR;
  static char file_path[4];
  unsigned char *ef_plmn = NULL;
  qmi_uim_read_transparent_params_type params;
  qmi_uim_rsp_data_type	rsp_data;
  int i, j = 0;
  int result = RESULT_FAILURE;

  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
  
  file_path[0] = 0x3F;
  file_path[1] = 0x00;
  file_path[2] = 0x7F;
  file_path[3] = 0xFF;

  params.session_info.session_type = QMI_UIM_SESSION_TYPE_PRI_GW_PROV;
  params.session_info.aid.data_len = 0;
  params.session_info.aid.data_ptr = NULL;

  params.file_id.file_id = 0x6F60;   /* EF PLMNwAcT */
  params.file_id.path.data_len = 4;
  params.file_id.path.data_ptr = (unsigned char*)file_path;
  params.offset = 0;
  params.length = 0;
    
  rc = qmi_uim_read_transparent((int)uim_client_handle,&params,NULL,NULL,&rsp_data);
  if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]qmi_uim_read_transparent!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
    result = RESULT_FAILURE;
  }
  else
  {
    if((rsp_data.rsp_data.read_transparent_rsp.sw1 == 0x90) || (rsp_data.rsp_data.read_transparent_rsp.sw2 == 0x00))
    {
      ef_plmn = (unsigned char *)malloc(rsp_data.rsp_data.read_transparent_rsp.content.data_len*sizeof(unsigned char));
      memcpy(ef_plmn,rsp_data.rsp_data.read_transparent_rsp.content.data_ptr ,rsp_data.rsp_data.read_transparent_rsp.content.data_len);
      plmn_list->item_cnt = 0;
      j = 0;
      for(i=0;i<rsp_data.rsp_data.read_transparent_rsp.content.data_len;i+=5)
      {
        if(ef_plmn[i] == 0xFF)
        {
          plmn_list->plmn[j].mcc[0] = 0x46;
          plmn_list->plmn[j].mcc[1]  =0x46;
          plmn_list->plmn[j].mcc[2] =  0x46;
          plmn_list->plmn[j].mcc[3] =  0x0;
          plmn_list->plmn[j].mnc[0] = 0x46;
          plmn_list->plmn[j].mnc[1]  = 0x46;
          plmn_list->plmn[j].mnc[2]  = 0x46;
          plmn_list->plmn[j].mnc[3]  = 0x0;

          plmn_list->plmn[j].rat = 0; //make none
        }
        else
        {
          plmn_list->plmn[j].mcc[0] = (ef_plmn[i] & 0xF) + '0';
          plmn_list->plmn[j].mcc[1]  = ((ef_plmn[i] & 0xF0) >> 4) + '0';
          plmn_list->plmn[j].mcc[2] =  (ef_plmn[i+1]  & 0xF) + '0';
          plmn_list->plmn[j].mcc[3] =  0x0;
          if(((ef_plmn[i+1] & 0xF0) >> 4) ==  0xF)
          {
            plmn_list->plmn[j].mnc[0] = (ef_plmn[i+2] & 0xF) + '0';
            plmn_list->plmn[j].mnc[1]  = ((ef_plmn[i+2] & 0xF0) >> 4) + '0';
            plmn_list->plmn[j].mnc[2]  = 0x0;
          }
          else
          {
            plmn_list->plmn[j].mnc[0] = (ef_plmn[i+2] & 0xF) + '0';          // isyoon20150203 SIM EF Spec
            plmn_list->plmn[j].mnc[1]  = ((ef_plmn[i+2] & 0xF0) >> 4) + '0'; // isyoon20150203 SIM EF Spec
            plmn_list->plmn[j].mnc[2]  = ((ef_plmn[i+1] & 0xF0) >> 4) + '0'; // isyoon20150203 SIM EF Spec
            plmn_list->plmn[j].mnc[3]  = 0x0;
          }


          plmn_list->plmn[j].rat = 0; //make none
          if(ef_plmn[i+3] & 0x80)
            plmn_list->plmn[j].rat = 1;
          if(ef_plmn[i+3] & 0x40)
            plmn_list->plmn[j].rat += 8;
          if(ef_plmn[i+4] & 0x80)
            plmn_list->plmn[j].rat += 2;
          if(ef_plmn[i+4] & 0x40)
            plmn_list->plmn[j].rat += 4;
        }

        plmn_list->item_cnt++;
        j++;
      }
      result = RESULT_SUCCESS;
    }
    else
    {
      //ust_list->result = FALSE;        
      result = RESULT_SUCCESS;
    }
  }

  if(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr != NULL)
  {
	  free(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr);
	  rsp_data.rsp_data.read_transparent_rsp.content.data_ptr = NULL;
  }
  
  if(ef_plmn != NULL)
    free(ef_plmn);
  
  return result;
}

/*===========================================================================

  FUNCTION  ril_request_set_plmnwact_list
  
===========================================================================*/
uint8 ril_request_set_plmnwact_list(wmmdiag_plmnwact_list_type plmn_list, int count)
{
  int rc = QMI_NO_ERR;
  static char file_path[4];
  unsigned char *ef_plmn = NULL;
  qmi_uim_write_transparent_params_type params;
  qmi_uim_rsp_data_type	rsp_data;
  int i , j = 0;
  int result = RESULT_FAILURE;
  uint8 len_mnc;

  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  ef_plmn = (unsigned char *)malloc(count * 5*sizeof(unsigned char));
  memset(ef_plmn, 0xFF, sizeof(ef_plmn));
  
  file_path[0] = 0x3F;
  file_path[1] = 0x00;
  file_path[2] = 0x7F;
  file_path[3] = 0xFF;

  params.session_info.session_type = QMI_UIM_SESSION_TYPE_PRI_GW_PROV;
  params.session_info.aid.data_len = 0;
  params.session_info.aid.data_ptr = NULL;

  params.file_id.file_id = 0x6F60;   /* EF PLMNwAcT */
  params.file_id.path.data_len = 4;
  params.file_id.path.data_ptr = (unsigned char*)file_path;
  params.offset = 0;
  params.data.data_len = count * 5;
  params.data.data_ptr = (unsigned char*)ef_plmn;

  for(i=0;i<params.data.data_len;i+=5)
  {
    if(plmn_list.plmn[j].mcc[0] == 0x46 && plmn_list.plmn[j].mnc[1] == 0x46) //0x66 it means clear
    {
      ef_plmn[i] = 0xFF;
      ef_plmn[i+1] = 0xFF;
      ef_plmn[i+2] = 0xFF;
      ef_plmn[i+3] = 0xFF;
      ef_plmn[i+4] = 0xFF;
    }
    else
    {
      len_mnc = strlen((char *)plmn_list.plmn[j].mnc);
      
      if(len_mnc == 3)
      {
        ef_plmn[i] = (0xf & (plmn_list.plmn[j].mcc[0] - '0')) | (0xf0 & ((plmn_list.plmn[j].mcc[1] - '0')<<4)); 
        ef_plmn[i+1] = 0xf & (plmn_list.plmn[j].mcc[2] - '0') | (0xf0 & ((plmn_list.plmn[j].mnc[2] - '0')<<4));   // isyoon20150203 SIM EF Spec
        ef_plmn[i+2] = (0xf & (plmn_list.plmn[j].mnc[0] - '0')) | (0xf0 & ((plmn_list.plmn[j].mnc[1] - '0')<<4)); // isyoon20150203 SIM EF Spec
      }
      else
      {
        ef_plmn[i] = (0xf & (plmn_list.plmn[j].mcc[0] - '0')) | (0xf0 & ((plmn_list.plmn[j].mcc[1] - '0')<<4));
        ef_plmn[i+1] = 0xf & (plmn_list.plmn[j].mcc[2] - '0') | 0xf0;
        ef_plmn[i+2] = (0xf & (plmn_list.plmn[j].mnc[0] - '0')) | (0xf0 & ((plmn_list.plmn[j].mnc[1] - '0')<<4));
      }

      if(plmn_list.plmn[j].mnc[2] >= '0')
        ef_plmn[i+3] = 0xf & (plmn_list.plmn[j].mnc[2] - '0');
      else
        ef_plmn[i+3] = 0x0;

      ef_plmn[i+4] = 0x0;
      if(plmn_list.plmn[j].rat & 0x1)
        ef_plmn[i+3] |= 0x80;
      if(plmn_list.plmn[j].rat & 0x8)
        ef_plmn[i+3] |= 0x40;
      if(plmn_list.plmn[j].rat & 0x2)
        ef_plmn[i+4] = 0x80;
      if(plmn_list.plmn[j].rat & 0x4)
        ef_plmn[i+4] |= 0x40;    
    }
    j++; 
  }

  rc = qmi_uim_write_transparent((int)uim_client_handle,&params,NULL,NULL,&rsp_data);
  if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]qmi_uim_write_transparent!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
    result = RESULT_FAILURE;
  }
  else
  {
    result = RESULT_SUCCESS;
  }
  
  if(ef_plmn != NULL)
    free(ef_plmn);
  
  return result;
}

/*===========================================================================

  FUNCTION  ril_request_get_oplmnwact_list
  
===========================================================================*/
uint8 ril_request_get_oplmnwact_list(wmmdiag_plmnwact_list_type *plmn_list)
{
  int rc = QMI_NO_ERR;
  static char file_path[4];
  unsigned char *ef_plmn = NULL;
  qmi_uim_read_transparent_params_type params;
  qmi_uim_rsp_data_type	rsp_data;
  int i, j = 0;
  int result = RESULT_FAILURE;

  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
  
  file_path[0] = 0x3F;
  file_path[1] = 0x00;
  file_path[2] = 0x7F;
  file_path[3] = 0xFF;

  params.session_info.session_type = QMI_UIM_SESSION_TYPE_PRI_GW_PROV;
  params.session_info.aid.data_len = 0;
  params.session_info.aid.data_ptr = NULL;

  params.file_id.file_id = 0x6F61;   /* EF OPLMNwAcT */
  params.file_id.path.data_len = 4;
  params.file_id.path.data_ptr = (unsigned char*)file_path;
  params.offset = 0;
  params.length = 0;
    
  rc = qmi_uim_read_transparent((int)uim_client_handle,&params,NULL,NULL,&rsp_data);
  if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]qmi_uim_read_transparent!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
    result = RESULT_FAILURE;
  }
  else
  {
    if((rsp_data.rsp_data.read_transparent_rsp.sw1 == 0x90) || (rsp_data.rsp_data.read_transparent_rsp.sw2 == 0x00))
    {
      ef_plmn = (unsigned char *)malloc(rsp_data.rsp_data.read_transparent_rsp.content.data_len*sizeof(unsigned char));
      memcpy(ef_plmn,rsp_data.rsp_data.read_transparent_rsp.content.data_ptr ,rsp_data.rsp_data.read_transparent_rsp.content.data_len);
      plmn_list->item_cnt = 0;
      j = 0;
      for(i=0;i<rsp_data.rsp_data.read_transparent_rsp.content.data_len;i+=5)
      {
        if(ef_plmn[i] == 0xFF)
        {
          result = RESULT_SUCCESS;
          break;
        }
        else
        {
          plmn_list->plmn[j].mcc[0] = (ef_plmn[i] & 0xF) + '0';
          plmn_list->plmn[j].mcc[1]  = ((ef_plmn[i] & 0xF0) >> 4) + '0';
          plmn_list->plmn[j].mcc[2] =  (ef_plmn[i+1]  & 0xF) + '0';
          plmn_list->plmn[j].mcc[3] =  0x0;
          plmn_list->plmn[j].mnc[0] = (ef_plmn[i+2] & 0xF) + '0';
          plmn_list->plmn[j].mnc[1]  = ((ef_plmn[i+2] & 0xF0) >> 4) + '0';
          
          if( (ef_plmn[i+3] & 0xF) > 0)
          {
            plmn_list->plmn[j].mnc[2] =  (ef_plmn[i+3]  & 0xF) + '0';
            plmn_list->plmn[j].mnc[3]  = 0x0;
          }
          else
            plmn_list->plmn[j].mnc[2]  = 0x0;

          plmn_list->plmn[j].rat = 0; //make none
          if(ef_plmn[i+3] & 0x80)
            plmn_list->plmn[j].rat = 1;
          if(ef_plmn[i+3] & 0x40)
            plmn_list->plmn[j].rat += 8;
          if(ef_plmn[i+4] & 0x80)
            plmn_list->plmn[j].rat += 2;
          if(ef_plmn[i+4] & 0x80)
            plmn_list->plmn[j].rat += 4;
        }
        plmn_list->item_cnt++;
        j++;
      }
      result = RESULT_SUCCESS;
    }
    else
    {
      //ust_list->result = FALSE;        
      result = RESULT_SUCCESS;
    }
  }

  if(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr != NULL)
  {
	  free(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr);
	  rsp_data.rsp_data.read_transparent_rsp.content.data_ptr = NULL;
  }
  
  if(ef_plmn != NULL)
    free(ef_plmn);
  
  return result;
}

/*===========================================================================

  FUNCTION  ril_request_get_hplmnwact_list
  
===========================================================================*/
uint8 ril_request_get_hplmnwact_list(wmmdiag_plmnwact_list_type *plmn_list)
{
  int rc = QMI_NO_ERR;
  static char file_path[4];
  unsigned char *ef_plmn = NULL;
  qmi_uim_read_transparent_params_type params;
  qmi_uim_rsp_data_type	rsp_data;
  int i, j = 0;
  int result = RESULT_FAILURE;

  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
  
  file_path[0] = 0x3F;
  file_path[1] = 0x00;
  file_path[2] = 0x7F;
  file_path[3] = 0xFF;

  params.session_info.session_type = QMI_UIM_SESSION_TYPE_PRI_GW_PROV;
  params.session_info.aid.data_len = 0;
  params.session_info.aid.data_ptr = NULL;

  params.file_id.file_id = 0x6F62;   /* EF HPLMNwAcT */
  params.file_id.path.data_len = 4;
  params.file_id.path.data_ptr = (unsigned char*)file_path;
  params.offset = 0;
  params.length = 0;
    
  rc = qmi_uim_read_transparent((int)uim_client_handle,&params,NULL,NULL,&rsp_data);
  if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]qmi_uim_read_transparent!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
    result = RESULT_FAILURE;
  }
  else
  {
    if((rsp_data.rsp_data.read_transparent_rsp.sw1 == 0x90) || (rsp_data.rsp_data.read_transparent_rsp.sw2 == 0x00))
    {
      ef_plmn = (unsigned char *)malloc(rsp_data.rsp_data.read_transparent_rsp.content.data_len*sizeof(unsigned char));
      memcpy(ef_plmn,rsp_data.rsp_data.read_transparent_rsp.content.data_ptr ,rsp_data.rsp_data.read_transparent_rsp.content.data_len);
      plmn_list->item_cnt = 0;
      j = 0;
      for(i=0;i<rsp_data.rsp_data.read_transparent_rsp.content.data_len;i+=5)
      {
        if(ef_plmn[i] == 0xFF)
        {
          result = RESULT_SUCCESS;
          break;
        }
        else
        {
          plmn_list->plmn[j].mcc[0] = (ef_plmn[i] & 0xF) + '0';
          plmn_list->plmn[j].mcc[1]  = ((ef_plmn[i] & 0xF0) >> 4) + '0';
          plmn_list->plmn[j].mcc[2] =  (ef_plmn[i+1]  & 0xF) + '0';
          plmn_list->plmn[j].mcc[3] =  0x0;
          plmn_list->plmn[j].mnc[0] = (ef_plmn[i+2] & 0xF) + '0';
          plmn_list->plmn[j].mnc[1]  = ((ef_plmn[i+2] & 0xF0) >> 4) + '0';
          plmn_list->plmn[j].mnc[2]  = 0x0;

          plmn_list->plmn[j].rat = 0; //make none
          if(ef_plmn[i+3] & 0x80)
            plmn_list->plmn[j].rat = 1;
          if(ef_plmn[i+3] & 0x40)
            plmn_list->plmn[j].rat += 8;
          if(ef_plmn[i+4] & 0x80)
            plmn_list->plmn[j].rat += 2;
          if(ef_plmn[i+4] & 0x80)
            plmn_list->plmn[j].rat += 4;
        }
        plmn_list->item_cnt++;
        j++;
      }
      result = RESULT_SUCCESS;
    }
    else
    {
      //ust_list->result = FALSE;        
      result = RESULT_SUCCESS;
    }
  }

  if(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr != NULL)
  {
	  free(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr);
	  rsp_data.rsp_data.read_transparent_rsp.content.data_ptr = NULL;
  }
  
  if(ef_plmn != NULL)
    free(ef_plmn);
  
  return result;
}

/*===========================================================================

  FUNCTION  ril_request_get_hplmnwact_list
  
===========================================================================*/
uint8 ril_request_get_acm_max(HKS_ACM_MAX_INFO_TYPE *acm_max)
{
  int rc = QMI_NO_ERR;
  static char file_path[4];
  qmi_uim_read_transparent_params_type params;
  qmi_uim_rsp_data_type	rsp_data;
  int i, j = 0;
  int result = RESULT_FAILURE;

  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
  
  file_path[0] = 0x3F;
  file_path[1] = 0x00;
  file_path[2] = 0x7F;
  file_path[3] = 0xFF;

  params.session_info.session_type = QMI_UIM_SESSION_TYPE_PRI_GW_PROV;
  params.session_info.aid.data_len = 0;
  params.session_info.aid.data_ptr = NULL;

  params.file_id.file_id = 0x6F37;   /* EF ACMmax */
  params.file_id.path.data_len = 4;
  params.file_id.path.data_ptr = (unsigned char*)file_path;
  params.offset = 0;
  params.length = 0;
    
  rc = qmi_uim_read_transparent((int)uim_client_handle,&params,NULL,NULL,&rsp_data);
  if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]qmi_uim_read_transparent!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
    result = RESULT_FAILURE;
  }
  else
  {
    acm_max->acm_max[0] = rsp_data.rsp_data.read_transparent_rsp.content.data_ptr[0];
    acm_max->acm_max[1] = rsp_data.rsp_data.read_transparent_rsp.content.data_ptr[1];
    acm_max->acm_max[2] = rsp_data.rsp_data.read_transparent_rsp.content.data_ptr[2];

    result = RESULT_SUCCESS;
  }

  if(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr != NULL)
  {
	  free(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr);
	  rsp_data.rsp_data.read_transparent_rsp.content.data_ptr = NULL;
  }

  return result;
}

/*===========================================================================

  FUNCTION  ril_request_get_imsi_hex
  
===========================================================================*/
uint8 ril_request_get_imsi_hex(uint8 *imsi)
{
  int rc = QMI_NO_ERR;
  static char file_path[4];
  qmi_uim_read_transparent_params_type params;
  qmi_uim_rsp_data_type	rsp_data;
  int i, j = 0;
  int result = RESULT_FAILURE;

  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
  
  file_path[0] = 0x3F;
  file_path[1] = 0x00;
  file_path[2] = 0x7F;
  file_path[3] = 0xFF;

  params.session_info.session_type = QMI_UIM_SESSION_TYPE_PRI_GW_PROV;
  params.session_info.aid.data_len = 0;
  params.session_info.aid.data_ptr = NULL;

  params.file_id.file_id = 0x6F07;   /* EF IMSI */
  params.file_id.path.data_len = 4;
  params.file_id.path.data_ptr = (unsigned char*)file_path;
  params.offset = 0;
  params.length = 0;
    
  rc = qmi_uim_read_transparent((int)uim_client_handle,&params,NULL,NULL,&rsp_data);
  if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]qmi_uim_read_transparent!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
    result = RESULT_FAILURE;
  }
  else
  {
    memcpy(imsi, rsp_data.rsp_data.read_transparent_rsp.content.data_ptr, 9);
    
    result = RESULT_SUCCESS;
  }

  if(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr != NULL)
  {
	  free(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr);
	  rsp_data.rsp_data.read_transparent_rsp.content.data_ptr = NULL;
  }

  return result;
}

/*===========================================================================

  FUNCTION  ril_request_get_iccid_hex
  
===========================================================================*/
uint8 ril_request_get_iccid_hex(uint8 *iccid)
{
  int rc = QMI_NO_ERR;
  static char file_path[2];
  qmi_uim_read_transparent_params_type params;
  qmi_uim_rsp_data_type	rsp_data;
  int i, j = 0;
  int result = RESULT_FAILURE;

  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
  
  file_path[0] = 0x3F;
  file_path[1] = 0x00;
  //file_path[2] = 0x7F;
  //file_path[3] = 0xFF;

  params.session_info.session_type = QMI_UIM_SESSION_TYPE_PRI_GW_PROV;
  params.session_info.aid.data_len = 0;
  params.session_info.aid.data_ptr = NULL;

  params.file_id.file_id = 0x2FE2;   /* EF ICCID */
  params.file_id.path.data_len = 2;
  params.file_id.path.data_ptr = (unsigned char*)file_path;
  params.offset = 0;
  params.length = 0;
    
  rc = qmi_uim_read_transparent((int)uim_client_handle,&params,NULL,NULL,&rsp_data);
  if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]qmi_uim_read_transparent!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
    result = RESULT_FAILURE;
  }
  else
  {
    memcpy(iccid, rsp_data.rsp_data.read_transparent_rsp.content.data_ptr, 10);
    
    result = RESULT_SUCCESS;
  }

  if(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr != NULL)
  {
	  free(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr);
	  rsp_data.rsp_data.read_transparent_rsp.content.data_ptr = NULL;
  }

  return result;
}

/*===========================================================================

  FUNCTION  ril_request_get_fplmn_hex
  
===========================================================================*/
uint8 ril_request_get_fplmn_hex(uint8 *fplmn)
{
  int rc = QMI_NO_ERR;
  static char file_path[4];
  qmi_uim_read_transparent_params_type params;
  qmi_uim_rsp_data_type	rsp_data;
  int i, j = 0;
  int result = RESULT_FAILURE;

  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
  
  file_path[0] = 0x3F;
  file_path[1] = 0x00;
  file_path[2] = 0x7F;
  file_path[3] = 0xFF;

  params.session_info.session_type = QMI_UIM_SESSION_TYPE_PRI_GW_PROV;
  params.session_info.aid.data_len = 0;
  params.session_info.aid.data_ptr = NULL;

  params.file_id.file_id = 0x6F7B;   /* EF FPLMN */
  params.file_id.path.data_len = 4;
  params.file_id.path.data_ptr = (unsigned char*)file_path;
  params.offset = 0;
  params.length = 0;
    
  rc = qmi_uim_read_transparent((int)uim_client_handle,&params,NULL,NULL,&rsp_data);
  if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]qmi_uim_read_transparent!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
    result = RESULT_FAILURE;
  }
  else
  {
    memcpy(fplmn, rsp_data.rsp_data.read_transparent_rsp.content.data_ptr, 12);
    
    result = RESULT_SUCCESS;
  }

  if(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr != NULL)
  {
	  free(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr);
	  rsp_data.rsp_data.read_transparent_rsp.content.data_ptr = NULL;
  }

  return result;
}

/*===========================================================================

  FUNCTION  ril_request_set_fplmn_hex
  
===========================================================================*/
uint8 ril_request_set_fplmn_hex(uint8 *fplmn)
{
  int rc = QMI_NO_ERR;
  static char file_path[4];
  qmi_uim_write_transparent_params_type params;
  qmi_uim_rsp_data_type	rsp_data;
  int result = RESULT_FAILURE;

  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
  
  file_path[0] = 0x3F;
  file_path[1] = 0x00;
  file_path[2] = 0x7F;
  file_path[3] = 0xFF;

  params.session_info.session_type = QMI_UIM_SESSION_TYPE_PRI_GW_PROV;
  params.session_info.aid.data_len = 0;
  params.session_info.aid.data_ptr = NULL;

  params.file_id.file_id = 0x6F7B;   /* EF FPLMN */
  params.file_id.path.data_len = 4;
  params.file_id.path.data_ptr = (unsigned char*)file_path;
  params.offset = 0;
  params.data.data_len = 12;
  params.data.data_ptr = (unsigned char*)fplmn;

  rc = qmi_uim_write_transparent((int)uim_client_handle,&params,NULL,NULL,&rsp_data);
  if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]qmi_uim_write_transparent!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
    result = RESULT_FAILURE;
  }
  else
  {
    result = RESULT_SUCCESS;
  }
  
  return result;
}

/*===========================================================================

  FUNCTION  ril_request_get_iccid
  
===========================================================================*/
uint8 ril_request_get_iccid(char* iccid)
{
  int rc = QMI_NO_ERR;
  static char file_path[2];
  qmi_uim_read_transparent_params_type params;
  qmi_uim_rsp_data_type	rsp_data;
  int i, j = 0;
  uint8                   current_byte;
  char                    uim_id[MMGSDI_ICCID_LEN * 2 + 1];  
  int result = RESULT_FAILURE;

  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(uim_id, 0, MMGSDI_ICCID_LEN * 2 + 1);
  
  file_path[0] = 0x3F;
  file_path[1] = 0x00;

  params.session_info.session_type = QMI_UIM_SESSION_TYPE_PRI_GW_PROV;
  params.session_info.aid.data_len = 0;
  params.session_info.aid.data_ptr = NULL;

  params.file_id.file_id = 0x2FE2;   /* EF ICCID */
  params.file_id.path.data_len = 2;
  params.file_id.path.data_ptr = (unsigned char*)file_path;
  params.offset = 0;
  params.length = 0;
    
  rc = qmi_uim_read_transparent((int)uim_client_handle,&params,NULL,NULL,&rsp_data);
  if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]ril_request_get_iccid %d",rc,rsp_data.qmi_err_code,0);
    result = RESULT_FAILURE;
  }
  else
  {
    for(i = 0; i < MMGSDI_ICCID_LEN; i++)
    {
      current_byte = rsp_data.rsp_data.read_transparent_rsp.content.data_ptr[i];
      if(QMI_BCD_LOW_DIGIT(current_byte) < 0x0A)
        uim_id[i * 2] = QMI_BCD_LOW_DIGIT(current_byte) + '0';
      else if(QMI_BCD_LOW_DIGIT(current_byte) < 0x0F)
        uim_id[i * 2] = QMI_BCD_LOW_DIGIT(current_byte) + 'A';
      else if(QMI_BCD_LOW_DIGIT(current_byte) == 0x0F)
        break;
      else
      {
        return RESULT_FAILURE;
      }

      if(QMI_BCD_HIGH_DIGIT(current_byte) < 0x0A)
        uim_id[i * 2 + 1] = QMI_BCD_HIGH_DIGIT(current_byte) + '0';
      else if(QMI_BCD_HIGH_DIGIT(current_byte) < 0x0F)
        uim_id[i * 2 + 1] = QMI_BCD_HIGH_DIGIT(current_byte) + 'A';
      else if(QMI_BCD_HIGH_DIGIT(current_byte) == 0x0F)
        break;
      else
      {
        return RESULT_FAILURE;
      }
    }
    
    strcpy(iccid, uim_id);
    printf("ril_request_get_iccid= %s\r\n", iccid);
    
    result = RESULT_SUCCESS;
  }

  if(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr != NULL)
  {
	  free(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr);
	  rsp_data.rsp_data.read_transparent_rsp.content.data_ptr = NULL;
  }

  return result;
}

/*===========================================================================

  FUNCTION  uim_read_data
  
===========================================================================*/
uint8 uim_read_data(uim_ef_data_type *uim_data, uint8 type)
{
  int rc = QMI_NO_ERR;
  static char file_path[4];
  qmi_uim_get_file_attributes_params_type get_file_attributes_param;
  uint8 file_type;
  qmi_uim_read_transparent_params_type read_transparent_param;
  qmi_uim_read_record_params_type read_record_param;
  qmi_uim_rsp_data_type	rsp_data;
  int i, j = 0;
  int result = RESULT_SUCCESS;

  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  //Step 1 : Get file attributes
  file_path[0] = 0x3F;
  file_path[1] = 0x00;
  file_path[2] = 0x7F;
  file_path[3] = 0xFF;

  get_file_attributes_param.session_info.session_type = (qmi_uim_session_type)type;
  get_file_attributes_param.session_info.aid.data_len = 0;
  get_file_attributes_param.session_info.aid.data_ptr = NULL;

  get_file_attributes_param.file_id.file_id = uim_data->file_id;   /* EF IMSI */
  get_file_attributes_param.file_id.path.data_len = 4;
  get_file_attributes_param.file_id.path.data_ptr = (unsigned char*)file_path;
    
  rc = qmi_uim_get_file_attributes((int)uim_client_handle,&get_file_attributes_param,NULL,NULL,&rsp_data);
  if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]qmi_uim_get_file_attributes!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
    result = RESULT_FAILURE;
  }
  else
  {
    file_type = rsp_data.rsp_data.get_file_attributes_rsp.file_type;
  }

  if(rsp_data.rsp_data.get_file_attributes_rsp.raw_value.data_ptr != NULL)
  {
	  free(rsp_data.rsp_data.get_file_attributes_rsp.raw_value.data_ptr);
	  rsp_data.rsp_data.get_file_attributes_rsp.raw_value.data_ptr = NULL;
  }
  
  //Step 2 : Read EF
  if(result != RESULT_FAILURE)
  {
    if(file_type == QMI_UIM_FILE_TYPE_TRANSPARENT)
    {
      read_transparent_param.session_info.session_type = (qmi_uim_session_type)type;
      read_transparent_param.session_info.aid.data_len = 0;
      read_transparent_param.session_info.aid.data_ptr = NULL;

      read_transparent_param.file_id.file_id = uim_data->file_id;   /* EF IMSI */
      read_transparent_param.file_id.path.data_len = 4;
      read_transparent_param.file_id.path.data_ptr = (unsigned char*)file_path;
      read_transparent_param.offset = 0;
      read_transparent_param.length = 0;

      rc = qmi_uim_read_transparent((int)uim_client_handle,&read_transparent_param,NULL,NULL,&rsp_data);
      if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
      {
        MSG_ERROR("[UIM]qmi_uim_read_transparent!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
        result = RESULT_FAILURE;
      }
      else
      {
        if((rsp_data.rsp_data.read_transparent_rsp.sw1 == 0x90) || (rsp_data.rsp_data.read_transparent_rsp.sw2 == 0x00))
        {
          uim_data->data_len = rsp_data.rsp_data.read_transparent_rsp.content.data_len;
          memcpy(uim_data->data,rsp_data.rsp_data.read_transparent_rsp.content.data_ptr ,rsp_data.rsp_data.read_transparent_rsp.content.data_len);
            
          result = RESULT_SUCCESS;
        }
        else
        {
          result = RESULT_FAILURE;
        }
      }

      if(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr != NULL)
      {
  	    free(rsp_data.rsp_data.read_transparent_rsp.content.data_ptr);
  	    rsp_data.rsp_data.read_transparent_rsp.content.data_ptr = NULL;
      }
    }
    else if(file_type == QMI_UIM_FILE_TYPE_CYCLIC || file_type == QMI_UIM_FILE_TYPE_LINEAR_FIXED)
    {
      read_record_param.session_info.session_type = (qmi_uim_session_type)type;
      read_record_param.session_info.aid.data_len = 0;
      read_record_param.session_info.aid.data_ptr = NULL;

      read_record_param.file_id.file_id = uim_data->file_id;   /* EF PLMN Network Name */
      read_record_param.file_id.path.data_len = 4;
      read_record_param.file_id.path.data_ptr = (unsigned char*)file_path;
      read_record_param.record = uim_data->record;
      read_record_param.length = 0;

      rc = qmi_uim_read_record((int)uim_client_handle,&read_record_param,NULL,NULL,&rsp_data);
      if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
      {
        MSG_ERROR("[UIM]qmi_uim_read_record!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
        result = RESULT_FAILURE;
      }
      else
      {
        if((rsp_data.rsp_data.read_record_rsp.sw1 == 0x90) || (rsp_data.rsp_data.read_record_rsp.sw2 == 0x00))
        {
          uim_data->data_len = rsp_data.rsp_data.read_record_rsp.content.data_len;
          memcpy(uim_data->data,rsp_data.rsp_data.read_record_rsp.content.data_ptr ,rsp_data.rsp_data.read_record_rsp.content.data_len);
            
          result = RESULT_SUCCESS;
        }
        else
        {
          result = RESULT_FAILURE;
        }
      }

      if(rsp_data.rsp_data.read_record_rsp.content.data_ptr != NULL)
      {
  	    free(rsp_data.rsp_data.read_record_rsp.content.data_ptr);
  	    rsp_data.rsp_data.read_record_rsp.content.data_ptr = NULL;
      }
    }
    else
      result = RESULT_FAILURE;
  }
  return result;
}

/*===========================================================================

  FUNCTION  uim_write_data
  
===========================================================================*/
uint8 uim_write_data(uim_ef_data_type *uim_data, uint8 type)
{
  int rc = QMI_NO_ERR;
  static char file_path[4];
  qmi_uim_get_file_attributes_params_type get_file_attributes_param;
  uint8 file_type;
  qmi_uim_write_transparent_params_type write_transparent_param;
  qmi_uim_write_record_params_type write_record_param;
  qmi_uim_rsp_data_type	rsp_data;
  int i, j = 0;
  int result = RESULT_SUCCESS;

  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  //Step 1 : Get file attributes
  file_path[0] = 0x3F;
  file_path[1] = 0x00;
  file_path[2] = 0x7F;
  file_path[3] = 0xFF;

  get_file_attributes_param.session_info.session_type = (qmi_uim_session_type)type;
  get_file_attributes_param.session_info.aid.data_len = 0;
  get_file_attributes_param.session_info.aid.data_ptr = NULL;

  get_file_attributes_param.file_id.file_id = uim_data->file_id;   /* EF IMSI */
  get_file_attributes_param.file_id.path.data_len = 4;
  get_file_attributes_param.file_id.path.data_ptr = (unsigned char*)file_path;
    
  rc = qmi_uim_get_file_attributes((int)uim_client_handle,&get_file_attributes_param,NULL,NULL,&rsp_data);
  if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]qmi_uim_get_file_attributes!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
    result = RESULT_FAILURE;
  }
  else
  {
    file_type = rsp_data.rsp_data.get_file_attributes_rsp.file_type;
  }

  if(rsp_data.rsp_data.get_file_attributes_rsp.raw_value.data_ptr != NULL)
  {
	  free(rsp_data.rsp_data.get_file_attributes_rsp.raw_value.data_ptr);
	  rsp_data.rsp_data.get_file_attributes_rsp.raw_value.data_ptr = NULL;
  }
  
  //Step 2 : Read EF
  if(result != RESULT_FAILURE)
  {
    if(file_type == QMI_UIM_FILE_TYPE_TRANSPARENT)
    {
      write_transparent_param.session_info.session_type = (qmi_uim_session_type)type;
      write_transparent_param.session_info.aid.data_len = 0;
      write_transparent_param.session_info.aid.data_ptr = NULL;

      write_transparent_param.file_id.file_id = uim_data->file_id;   /* EF IMSI */
      write_transparent_param.file_id.path.data_len = 4;
      write_transparent_param.file_id.path.data_ptr = (unsigned char*)file_path;
      write_transparent_param.offset = uim_data->offset;
      write_transparent_param.data.data_len = uim_data->data_len;
      write_transparent_param.data.data_ptr = (unsigned char*)uim_data->data;

      rc = qmi_uim_write_transparent((int)uim_client_handle,&write_transparent_param,NULL,NULL,&rsp_data);
      if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
      {
        MSG_ERROR("[UIM]qmi_uim_write_transparent!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
        result = RESULT_FAILURE;
      }
      else
      {
        if((rsp_data.rsp_data.write_transparent_rsp.sw1 == 0x90) || (rsp_data.rsp_data.write_transparent_rsp.sw2 == 0x00))
        {
          result = RESULT_SUCCESS;
        }
        else
        {
          result = RESULT_FAILURE;
        }
      }

      #if 0
      if(rsp_data.rsp_data.write_transparent_rsp.content.data_ptr != NULL)
      {
  	    free(rsp_data.rsp_data.write_transparent_rsp.content.data_ptr);
  	    rsp_data.rsp_data.write_transparent_rsp.content.data_ptr = NULL;
      }
      #endif
    }
    else if(file_type == QMI_UIM_FILE_TYPE_CYCLIC || file_type == QMI_UIM_FILE_TYPE_LINEAR_FIXED)
    {
      write_record_param.session_info.session_type = (qmi_uim_session_type)type;
      write_record_param.session_info.aid.data_len = 0;
      write_record_param.session_info.aid.data_ptr = NULL;

      write_record_param.file_id.file_id = uim_data->file_id;   /* EF PLMN Network Name */
      write_record_param.file_id.path.data_len = 4;
      write_record_param.file_id.path.data_ptr = (unsigned char*)file_path;
      write_record_param.record = uim_data->record;
      write_record_param.data.data_len = uim_data->data_len;
      write_record_param.data.data_ptr = (unsigned char*)uim_data->data;

      rc = qmi_uim_write_record((int)uim_client_handle,&write_record_param,NULL,NULL,&rsp_data);
      if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
      {
        MSG_ERROR("[UIM]qmi_uim_write_record!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
        result = RESULT_FAILURE;
      }
      else
      {
        if((rsp_data.rsp_data.write_record_rsp.sw1 == 0x90) || (rsp_data.rsp_data.write_record_rsp.sw2 == 0x00))
        {     
          result = RESULT_SUCCESS;
        }
        else
        {
          result = RESULT_FAILURE;
        }
      }

      #if 0
      if(rsp_data.rsp_data.write_record_rsp.content.data_ptr != NULL)
      {
  	    free(rsp_data.rsp_data.write_record_rsp.content.data_ptr);
  	    rsp_data.rsp_data.write_record_rsp.content.data_ptr = NULL;
      }
      #endif
    }
    else
      result = RESULT_FAILURE;
  }
  return result;
}


/*===========================================================================

  FUNCTION  ril_ota_request
  
===========================================================================*/
uint8 ril_ota_request()
{
  int rc = QMI_NO_ERR;
  //qmi_uim_rsp_data_type	rsp_data;
  
  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_uim_ota_request((int)uim_client_handle,&qmi_uim_async_cb,NULL,NULL);
  if(rc != QMI_NO_ERR)
  {
    MSG_ERROR("[UIM]ril_ota_request!! rc: %d",rc,0,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  request_ota_mode
  
===========================================================================*/
uint8 request_ota_mode(uint8* ota_mode)
{
  int rc = QMI_NO_ERR;
  
  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  MSG_HIGH("[UIM] request_ota_mode : %d", ota_mode,0,0);
  rc = qmi_uim_get_ota_mode((int)uim_client_handle,ota_mode);
  if(rc != QMI_NO_ERR)
  {
    MSG_ERROR("[UIM]qmi_uim_get_ota_mode!! rc: %d",rc,0,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  get_uicc_lock
  
===========================================================================*/
uint8 get_uicc_lock(uint8* uicc_lock)
{
  int rc = QMI_NO_ERR;
  
  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_uim_get_uicc_lock((int)uim_client_handle,uicc_lock);
  if(rc != QMI_NO_ERR)
  {
    MSG_ERROR("[UIM]qmi_uim_get_ota_mode!! rc: %d",rc,0,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  set_uicc_lock
  
===========================================================================*/
uint8 set_uicc_lock(uint8 uicc_lock)
{
  int rc = QMI_NO_ERR;
  
  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
  
  rc = qmi_uim_set_uicc_lock((int)uim_client_handle,uicc_lock);
  if(rc != QMI_NO_ERR)
  {
    MSG_ERROR("[UIM]qmi_uim_get_ota_mode!! rc: %d",rc,0,0);
    return RESULT_FAILURE;
  }
  else
  {
    MSG_HIGH("[UIM] set_uicc_lock success : %d", uicc_lock,0,0);
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  uicc_power_down
  
===========================================================================*/
uint8 uicc_power_down()
{
  int rc = QMI_NO_ERR;
  qmi_uim_power_down_params_type param;
  qmi_uim_rsp_data_type rsp_data;
  
  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  param.slot = QMI_UIM_SLOT_1;
  rc = qmi_uim_power_down((int)uim_client_handle, &param, NULL, NULL, &rsp_data);
  if(rc != QMI_NO_ERR)
  {
    MSG_ERROR("[UIM]qmi_uim_get_ota_mode!! rc: %d",rc,0,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  uicc_power_up
  
===========================================================================*/
uint8 uicc_power_up()
{
  int rc = QMI_NO_ERR;
  qmi_uim_power_up_params_type param;
  qmi_uim_rsp_data_type rsp_data;
  
  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
  
  param.slot = QMI_UIM_SLOT_1;
  rc = qmi_uim_power_up((int)uim_client_handle, &param, NULL, NULL, &rsp_data);
  if(rc != QMI_NO_ERR)
  {
    MSG_ERROR("[UIM]qmi_uim_get_ota_mode!! rc: %d",rc,0,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  ril_ota_need_registration
  
===========================================================================*/
uint8 ril_ota_need_registration(uint8* ota_need)
{
  uint32 ret = RESULT_SUCCESS;
  int rc = QMI_NO_ERR;
  uint8 voice_number[33] = {0,};
  uint8 outofbox_number[33] = {0,};
  
  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  ret = ril_request_get_phone_number((char *)voice_number);
  if(ret == RESULT_SUCCESS)
  {
    //make outofbox_number to NULL
    memset(outofbox_number, 0x30, strlen((char *)voice_number));
    if (strcmp((char *)voice_number, (char *)outofbox_number) == 0)
    {
      *ota_need = TRUE;
    }
    else
      *ota_need = FALSE;
  }
  else
  {
    MSG_ERROR("[UIM]ril_request_get_phone_number!! ret: %d",ret,0,0);
    return RESULT_FAILURE;
  }
    
  return RESULT_SUCCESS;
}

/*===========================================================================

  FUNCTION  set_usim_onchip
  
===========================================================================*/
uint8 set_usim_onchip(uint8 mode)
{
  int rc = QMI_NO_ERR;
  
  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  ALOGD("set_usim_onchip mode: %d", mode);
  MSG_ERROR("set_usim_onchip mode: %d", mode,0,0);  
    
  rc = qmi_uim_set_onchip((int)uim_client_handle,mode);
  if(rc != QMI_NO_ERR)
  {
    MSG_ERROR("[UIM]qmi_uim_set_onchip!! rc: %d",rc,0,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  request_get_pin_status
  
===========================================================================*/
uint8 request_get_pin_status(Card_PinStatus *pin_status)
{
  int rc = QMI_NO_ERR;
  qmi_uim_rsp_data_type	rsp_data;
  
  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_uim_get_card_status((int)uim_client_handle,NULL,NULL,&rsp_data);
  if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]qmi_uim_get_card_status!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    pin_status->pin1_state = (RIL_PinState)rsp_data.rsp_data.get_card_status_rsp.card_status.card[0].application[0].pin1_state;
    pin_status->pin1_num_retries = rsp_data.rsp_data.get_card_status_rsp.card_status.card[0].application[0].pin1_num_retries;
    pin_status->puk1_num_retries = rsp_data.rsp_data.get_card_status_rsp.card_status.card[0].application[0].puk1_num_retries;
    pin_status->pin2_state = (RIL_PinState)rsp_data.rsp_data.get_card_status_rsp.card_status.card[0].application[0].pin2_state;
    pin_status->pin2_num_retries = rsp_data.rsp_data.get_card_status_rsp.card_status.card[0].application[0].pin2_num_retries;
    pin_status->puk2_num_retries = rsp_data.rsp_data.get_card_status_rsp.card_status.card[0].application[0].puk2_num_retries;

    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  set_usim_onchip
  
===========================================================================*/
uint8 set_pin_protection(qmi_uim_set_pin_protection_params_type *params)
{
  int rc = QMI_NO_ERR;
  qmi_uim_rsp_data_type	rsp_data;
  
  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_uim_set_pin_protection((int)uim_client_handle,params,NULL,NULL,&rsp_data);
  if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]qmi_uim_set_pin_protection!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  unbloock_pin
  
===========================================================================*/
uint8 unbloock_pin(qmi_uim_unblock_pin_params_type *params)
{
  int rc = QMI_NO_ERR;
  qmi_uim_rsp_data_type	rsp_data;
  
  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_uim_unblock_pin((int)uim_client_handle,params,NULL,NULL,&rsp_data);
  if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]qmi_uim_unblock_pin!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  change_pin
  
===========================================================================*/
uint8 change_pin(qmi_uim_change_pin_params_type *params)
{
  int rc = QMI_NO_ERR;
  qmi_uim_rsp_data_type	rsp_data;
  
  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_uim_change_pin((int)uim_client_handle,params,NULL,NULL,&rsp_data);
  if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]qmi_uim_change_pin!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  get_rtre_config
  
===========================================================================*/
uint8 get_rtre_config(uint16* rtre_value)
{
  int rc = QMI_NO_ERR;
  
  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_uim_get_rtre_config((int)uim_client_handle,rtre_value);
  if(rc != QMI_NO_ERR)
  {
    MSG_ERROR("[UIM]get_rtre_config!! rc: %d",rc,0,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  set_rtre_value
  
===========================================================================*/
uint8 set_rtre_value(uint16 rtre_value)
{
  int rc = QMI_NO_ERR;
  
  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_uim_set_rtre_config((int)uim_client_handle,rtre_value);
  if(rc != QMI_NO_ERR)
  {
    MSG_ERROR("[UIM]qmi_uim_set_rtre_config!! rc: %d",rc,0,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  get_bip_config
  
===========================================================================*/
uint8 get_bip_config(uint16* bip_value)
{
  int rc = QMI_NO_ERR;
  
  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_uim_get_bip_config((int)uim_client_handle,bip_value);
  if(rc != QMI_NO_ERR)
  {
    MSG_ERROR("[UIM]get_bip_config!! rc: %d",rc,0,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  set_bip_value
  
===========================================================================*/
uint8 set_bip_value(uint16 bip_value)
{
  int rc = QMI_NO_ERR;
  
  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_uim_set_bip_config((int)uim_client_handle,bip_value);
  if(rc != QMI_NO_ERR)
  {
    MSG_ERROR("[UIM]qmi_uim_set_bip_config!! rc: %d",rc,0,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

uint8 get_vzwlpm_config(uint16* vzw_lpm)
{
  int rc = QMI_NO_ERR;
  
  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_uim_get_vzwlpm_config((int)uim_client_handle, vzw_lpm);
  if(rc != QMI_NO_ERR)
  {
    MSG_ERROR("[UIM]get_vzwlpm_config!! rc: %d",rc,0,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

uint8 set_vzwlpm_config(uint16 vzw_lpm)
{
  int rc = QMI_NO_ERR;
  
  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_uim_set_vzwlpm_config((int)uim_client_handle,vzw_lpm);
  if(rc != QMI_NO_ERR)
  {
    MSG_ERROR("[UIM]set_vzwlpm_config!! rc: %d",rc,0,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  ril_request_register_refresh_all
  
===========================================================================*/
uint8 ril_request_register_refresh_all(uint8* aid)
{
  int rc = QMI_NO_ERR;
  qmi_uim_refresh_register_params_type param;
  qmi_uim_rsp_data_type rsp_data;
  
  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  param.session_info.session_type = QMI_UIM_SESSION_TYPE_PRI_GW_PROV;
  if(aid)
  {
    param.session_info.aid.data_len = sizeof(aid);
    param.session_info.aid.data_ptr = (unsigned char *)aid;
  }
  else
    return RESULT_FAILURE;
  
  param.reg_for_refresh = (qmi_uim_bool_type)TRUE;
 
  rc = qmi_uim_refresh_register_all((int)uim_client_handle, &param, NULL, NULL, &rsp_data);
  if(rc != QMI_NO_ERR)
  {
    MSG_ERROR("[UIM]qmi_uim_refresh_register_all!! rc: %d",rc,0,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  verify_pin
  
===========================================================================*/
uint8 verify_pin(qmi_uim_verify_pin_params_type *params)
{
  int rc = QMI_NO_ERR;
  qmi_uim_rsp_data_type	rsp_data;
  
  if(uim_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_uim_verify_pin((int)uim_client_handle,params,NULL,NULL,&rsp_data);
  if(rc != QMI_NO_ERR || rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]qmi_uim_verify_pin!! rc: %d err_code : %d",rc,rsp_data.qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}