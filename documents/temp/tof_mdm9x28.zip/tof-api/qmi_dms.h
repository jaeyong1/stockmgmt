#ifndef QMI_DMS_H
#define QMI_DMS_H

/******************************************************************************
  @file    qmi_dms.h
  @brief   QMI DMS header

  $Id$

  DESCRIPTION

  INITIALIZATION AND SEQUENCING REQUIREMENTS

  ---------------------------------------------------------------------------
  Copyright (c) 2013 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/
#include "qmi_dms_srvc.h"

#include "TOF_API.h"

#ifdef __cplusplus
  extern "C" {
#endif


/*===========================================================================
  FUNCTION
===========================================================================*/
extern bool tof_qmi_dms_srvc_init();
extern int tof_qmi_dms_srvc_release();
extern uint8 ril_request_get_phone_number(char* voice_number);
extern uint8 ril_request_get_imsi(char* imsi);
extern uint8 ril_request_get_imei(char* imei);
extern uint8 ril_request_device_identity(dms_get_device_serial_numbers_resp_msg_v01* identity);
#ifdef BOGUS //RIL_REQUEST_CDMA_SUBSCRIPTION
extern uint8 ril_request_cdma_subscription(dms_get_cdma_subscription_msg* subscription);
#endif /* BOGUS */
extern uint8 request_set_pin_protection(dms_uim_set_pin_protection_req_msg_v01* params);
extern uint8 request_unblock_pin(dms_uim_unblock_pin_req_msg_v01* params);
extern uint8 request_change_pin(dms_uim_change_pin_req_msg_v01* params);
extern uint8 ril_request_hk_modem_reset();
extern uint8 request_get_vendor(uint8* vendor);
extern uint8 request_set_vendor(char vendor);
extern uint8 request_get_oprt_mode(uint8 *oprt_mode);
extern uint8 request_set_oprt_mode(uint8 oprt_mode);
extern uint8 request_get_modem_sw_version (dms_get_modem_sw_version_resp_msg_v01 *get_modem_sw_version_rsp);

//05/24/2013 Added by ssaulaby09
extern uint8 HK_MDM_Get96HConfig(UINT16 *time, BOOL *delay, UINT8 *delay_time, BOOL *relcall, BOOL *msgtoggle);
extern uint8 HK_MDM_Set96HConfig(UINT16 time, BOOL delay, UINT8 delay_time, BOOL relcall, BOOL msgtoggle);
extern uint8 HK_MDM_Get96HMode_Rat_Mode_Set(boolean *enable_rat_mode, UINT16 *enter_rat_mode);
extern uint8 HK_MDM_Set96HMode_Rat_Mode_Set(boolean enable_rat_mode, UINT16 enter_rat_mode);
extern uint8 HK_MDM_MODEM_INIT(void);
extern uint8 request_qmi_dms_nv_read(uint16 item, uint8 *item_data);
extern uint8 request_qmi_dms_nv_read_ext(uint16 item, uint16 context, uint8 *item_data);
extern uint8 request_qmi_dms_nv_write(uint16 item, uint8 *item_data);
extern uint8 request_qmi_dms_nv_write_ext(uint16 item, uint16 context, uint8 *item_data);
extern uint8 qmi_nas_dms_fetch_cur_prl_only(uint8   * prl_only,int      * qmi_err_code); //BKS_20131224 add
extern uint8 request_qmi_dms_get_gmmp_domain_manufacture(dms_gmmp_domain_manufacture_msg_v01 *pGmmp_domain_manufacture);
extern uint8 request_qmi_dms_set_gmmp_domain_manufacture(dms_gmmp_domain_manufacture_msg_v01 *pGmmp_domain_manufacture);
extern uint8 request_qmi_dms_get_gmmp_server_ip_port_num(dms_gmmp_server_ip_port_num_msg_v01 *pGmmp_server_ip_port_num);
extern uint8 request_qmi_dms_set_gmmp_server_ip_port_num(dms_gmmp_server_ip_port_num_msg_v01 *pGmmp_server_ip_port_num);
extern uint8 request_qmi_dms_get_gmmp_gw_id_auth_key_device_id(dms_gmmp_gw_id_auth_key_device_id_msg_v01 *pGmmp_gw_id_auth_key_device_id);
extern uint8 request_qmi_dms_set_gmmp_gw_id_auth_key_device_id(dms_gmmp_gw_id_auth_key_device_id_msg_v01 *pGmmp_gw_id_auth_key_device_id);
extern uint8 request_qmi_dms_get_gmmp_profile_info(dms_gmmp_profile_info_msg_v01 *pGmmp_profile_info);
extern uint8 request_qmi_dms_set_gmmp_profile_info(dms_gmmp_profile_info_msg_v01 *pGmmp_profile_info);
extern uint8 request_qmi_dms_get_modem_temperature(char *temperature_val);
extern uint8 request_qmi_dms_get_modem_antdetect(int32 *main_dtct, int32 *div_dtct, int32 *main_adc, int32 *div_adc);
extern uint8 request_qmi_dms_get_modem_reset_log(boolean *reset_log_enable, int32 *reset_log_nor, int32 *reset_log_fatal);
extern uint8 request_qmi_dms_set_modem_reset_log(boolean reset_log_enable);
extern uint8 HK_MDM_MAX_POWER_CONTROL(tof_dms_max_power_type_v01 max_pwr);
extern uint8 request_qmi_dms_get_alive_monitor_config(uint8 *enable, uint8 *duration);
extern uint8 request_qmi_dms_set_alive_monitor_config(uint8 enable, uint8 duration);
extern uint8 request_qmi_dms_fs_daig_opendir (char *path, uint32 *dirp, int32 *diag_errno);
extern uint8 request_qmi_dms_fs_daig_readdir (uint32 dirp, int32 seqno, fsdiag_efs2_diag_readdir_rsp_type *read_dir_rsp);
extern uint8 request_qmi_dms_fs_daig_closedir (uint32 dirp, int32 *diag_errno);
extern uint8 request_qmi_dms_fs_daig_iter (uint8 file_op, fsdiag_iter_dirs_req_type *iter_req, byte *fs_status, fsdiag_iter_rsp_type *iter_rsp);
extern uint8 request_qmi_dms_fs_daig_read (fsdiag_read_req_type  *read_req, byte *fs_status, fsdiag_read_rsp_type *read_rsp);
extern uint8 request_qmi_dms_fs_daig_delete (fsdiag_rmfile_req_type  *read_req, byte *fs_status);
extern uint8 request_qmi_dms_fs_daig_write (fsdiag_write_req_type *write_req, byte *fs_status);
extern uint8 request_qmi_dms_fs_daig_rmdir (fsdiag_rmdir_req_type *rmdir_req, byte *fs_status);
extern uint8 request_qmi_dms_fs_daig_mkdir (fsdiag_mkdir_req_type *mkdir_req, byte *fs_status);
extern uint8 request_get_gpio(uint8 gpio_type, uint8* value);
extern uint8 request_set_gpio(uint8 gpio_type, uint8 gpio_value);
//ygpark.20141201 +
#if defined(FEATURE_LGIT_OTADM_FOTA_FUMO_VZW)
extern uint8 ril_request_fota_download_done_received();
extern uint8 ril_request_fota_install();
extern uint8 ril_request_fota_bl_install();
extern uint8 ril_request_fota_user_cancel();
#endif
//ygpark.20141201 -
extern uint8 request_set_time(uint64 user_time);

typedef struct
{
  uint16	year;
	uint8 	month;
	uint8 	day;
	uint8 	hour;
	uint8 	minute;
	uint8 	second;
} system_time_s;

extern bool request_get_system_time( system_time_s* system_time );

extern uint8 ril_request_get_exception_count(uint8 *count);
extern uint8 ril_request_get_exception_info(uint8 index, dms_modem_exception_info_type_v01 *exception_info);
extern uint8 ril_request_delete_exception_info(void);

#ifdef __cplusplus
}
#endif

#endif /* QMI_DMS_H */
