/******************************************************************************
  @file    qmi_dms_srvc.c
  @brief   The QMI DMS service layer.

  DESCRIPTION
  QMI DMS service routines.  

  INITIALIZATION AND SEQUENCING REQUIREMENTS
  tof_tof_qmi_dms_srvc_init_client() needs to be called before sending or receiving of any 
  DMS service messages

  ---------------------------------------------------------------------------
  Copyright (c) 2016 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/
#include <stdio.h>

//#include "qmi_i.h"
//#include "qmi_service.h"
#include "qmi_dms_srvc.h"
#include "qmi_uim_srvc.h"
#include "qmi_util.h"

#include "TOF_log.h"

#define QMI_DMS_EVENT_REG_MAX_TLV_SIZE 2

#define QMI_DMS_VENDOR_TLV_SIZE 1
#define QMI_DMS_96H_TLV_SIZE 5      //05/24/2013 Added by ssaulaby09
#define QMI_DMS_ALIVE_MONITOR_TLV_SIZE 2

#define QMI_DMS_96H_RAT_MODE_TLV_SIZE 3

#define QMI_DMS_MAX_POWER_TLV_SIZE 7

//Global Variable
static int dms_service_initialized = FALSE;

/*===========================================================================
  FUNCTION  qmi_dms_srvc_indication_cb
===========================================================================*/
/*!
@brief 
  This is the callback function that will be called by the generic
  services layer to report asynchronous indications.  This function will
  process the indication TLV's and then call the user registered
  functions with the indication data.   
  
@return 
  None.

@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/

static void
qmi_dms_srvc_indication_cb
(
  int                   user_handle,
  qmi_service_id_type   service_id,
  unsigned long         msg_id,
  void                                *user_ind_msg_hdlr,
  void                                *user_ind_msg_hdlr_user_data,
  unsigned char         *rx_msg_buf,
  int                   rx_msg_len
)
{
  qmi_dms_indication_id_type      ind_id = QMI_DMS_SRVC_INVALID_IND_MSG;
  qmi_dms_indication_data_type    ind_data;
  qmi_dms_indication_hdlr_type    user_ind_hdlr;
  dms_usb_status_ind_msg_v01      ind_usb_status_ind;

  unsigned char tmp;
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
	
  char tmp_buf[256] = {0};

  /* Make sure that the user indication handler isn't NULL */
  if (user_ind_msg_hdlr == NULL)
  {
    return;
  }

  memset((void*)&ind_data, 0x0, sizeof(ind_data));

  /* Get properly cast pointer to user indication handler */
  /*lint -e{611} */
  user_ind_hdlr = (qmi_dms_indication_hdlr_type) user_ind_msg_hdlr;

  switch (msg_id)
  {
	  case QMI_DMS_MODEM_USB_CONNECTED_IND:
		  memset(&ind_usb_status_ind,0,sizeof(ind_usb_status_ind));

      if(qmi_gpio_usb_status_info(rx_msg_buf,rx_msg_len,&ind_usb_status_ind) < 0)
      {
        return;
      }
      else
      {
        sprintf(tmp_buf,"%d",ind_usb_status_ind.usb_status);
        QMI_DEBUG_MSG_1("QMI_DMS_MODEM_USB_CONNECTED_IND : ind_usb_status_ind.usb_status : %d",ind_usb_status_ind.usb_status);
        EventNotifyEnqueue(TOF_EVENT_GPIO_USB_CONNECTED_IND, NULL, (uint32)tmp_buf);
      }    
	  break;
	
    case DMSI_PRM_TYPE_POWER_STATE:
    case DMSI_PRM_TYPE_BAT_LVL_RPT_LIMITS:
    case DMSI_PRM_TYPE_PIN_STATUS:
    case DMSI_PRM_TYPE_ACTIVATION_STATE:
    case DMSI_PRM_TYPE_OPRT_MODE:
    case DMSI_PRM_TYPE_UIM_GET_STATE:
    case DMSI_PRM_TYPE_WD_STATE:
    case DMSI_PRM_TYPE_PRL_INIT:
    #if 0 //comment DMS �� indication ó���� ���� �۾��ʿ���              
      {
        short  num_flows_counter = 0;

        ind_data.event_report.num_flows = 0;
        ind_id = QMI_QOS_SRVC_EVENT_REPORT_IND_MSG;
        while (rx_msg_len > 0)
        {
          if (qmi_util_read_std_tlv (&rx_msg_buf,
                                        &rx_msg_len,
                                        &type,
                                        &length,
                                        &value_ptr) < 0)
          {
            return ;
          }
          /*Check the correctness(type) of the tlv*/
          if (type == QMI_QOS_EVENT_FLOW_INFO_TLV_ID)
          {
            if (qmi_qos_srvc_process_event_report_ind (value_ptr,
                                                       length,
                                                       &ind_data.event_report,
                                                       num_flows_counter) < 0)
            {
              QMI_ERR_MSG_0( "qmi_qos_srvc_indication_cb::QMI_ERR_SYSERR \n" );
              continue;
            }
            /*
              No Need to check for Buffer overflow here. Above API already
              checks that. Makes sure max of QMI_QOS_MAX_FLOW_EVENTS are
              filled in.
            */
            ind_data.event_report.param_mask |= QMI_QOS_EVENT_REPORT_GLOBAL_FLOW_INFO_PARAM;
            num_flows_counter++;
            ind_data.event_report.num_flows = num_flows_counter;
          }
          else if (type == QMI_QOS_NW_SUPPORTED_QOS_PROFILES_TLV_ID)
          {
            int num_instances = 0;
            int index;
			unsigned short tmp;
            ind_data.event_report.param_mask |= QMI_QOS_EVENT_REPORT_NW_SUPPORTED_QOS_PROFILES_PARAM;
            READ_16_BIT_VAL (value_ptr, tmp);
            ind_data.event_report.nw_supported_qos_profiles.iface_type = (qmi_qos_iface_name_type)tmp;
            READ_8_BIT_VAL (value_ptr,ind_data.event_report.nw_supported_qos_profiles.num_profiles);
            num_instances = ind_data.event_report.nw_supported_qos_profiles.num_profiles;
            for (index = 0; index < num_instances; index++)
            {
              READ_16_BIT_VAL(value_ptr,ind_data.event_report.nw_supported_qos_profiles.profile[index]);
            }
          }
          else
          {
            QMI_DEBUG_MSG_2 ("qmi_qos_srvc_indication_cb:: Unknown TLV ID=%x, len=%d",
                             (unsigned int)type,(int)length);
            continue;
          }
        } /* while */
      }
    #endif 
      break;

//ygpark.20141201 +		
#if defined(FEATURE_LGIT_OTADM_FOTA_FUMO_VZW)
	case  DMSI_PRM_TYPE_OTADM_FOTA_DOWNLOADED:
	case DMSI_PRM_TYPE_OTADM_FOTA_DOWNLOADED_START:
	case DMSI_PRM_TYPE_OTADM_FOTA_DOWNLOADED_PAUSE:
	case DMSI_PRM_TYPE_OTADM_FOTA_DOWNLOADED_RESTART:
	case DMSI_PRM_TYPE_OTADM_FOTA_INSTALL_UNKNOWN:
	case DMSI_PRM_TYPE_OTADM_FOTA_INSTALL_FAIL:
	case DMSI_PRM_TYPE_OTADM_FOTA_INSTALL_SUCCESS:
	case DMSI_PRM_TYPE_OTADM_FOTA_SUCANCEL:
		ind_id = (qmi_dms_indication_id_type)msg_id;
	break;
#endif
//ygpark.20141201 -
    default:
      {
        QMI_DEBUG_MSG_1 ("qmi_dms_srvc_indication_cb: Unknown MsgId=%ld",msg_id);
        return;
      }
  }/*Switch*/

  /* If we got a valid/supported indication, report it */
  if (ind_id != QMI_DMS_SRVC_INVALID_IND_MSG)
  {
    /* Get properly cast pointer to user indication handler */
    /*lint -e{611} */
    user_ind_hdlr = (qmi_dms_indication_hdlr_type) user_ind_msg_hdlr;

    /* Call user registered handler */
    user_ind_hdlr (user_handle,
                   service_id,
                   user_ind_msg_hdlr_user_data,
                   ind_id,
                   &ind_data);
  }
}

/*===========================================================================
  FUNCTION  tof_qmi_dms_srvc_release
===========================================================================*/
/*!
@brief 
  This function is a callback that will be called once during client
  release  
  
@return 
  None.

@note

  - Dependencies
    - None.

  - Side Effects
    - None.
*/    
/*=========================================================================*/
int tof_qmi_dms_srvc_release (void)
{
  int  rc = QMI_NO_ERR;
  if (dms_service_initialized)
  {

    rc = qmi_service_set_srvc_functions (QMI_DMS_SERVICE,NULL);
    if (rc != QMI_NO_ERR)
    {
      printf("tof_qmi_dms_srvc_release: set srvc functions returns err=%d\n",rc);
    }
    else
    {
      printf("tof_qmi_dms_srvc_release: DMS successfully released\r\n");
      dms_service_initialized = FALSE;
    }
  }
  else
  {
    printf("tof_qmi_dms_srvc_release: Release failed, DMS not initialized\r\n");
  }
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_reg_ind_hdlr
===========================================================================*/
/*!
@brief 
  This function is a callback that will be called once during client
  initialization  
  
@return 
  None.

@note

  - Dependencies
    - None.

  - Side Effects
    - None.
*/    
/*=========================================================================*/
int qmi_dms_reg_ind_hdlr (qmi_service_ind_rx_hdlr  user_ind_msg_hdlr)
{
  int  rc = QMI_NO_ERR;
  if (!dms_service_initialized)
  {

    rc = qmi_service_set_srvc_functions (QMI_DMS_SERVICE,
                                 user_ind_msg_hdlr);
    if (rc != QMI_NO_ERR)
    {
      MSG_HIGH("tof_qmi_dms_srvc_init: set srvc functions returns err=%d", rc, 0, 0);
    }
    else
    {
      MSG_HIGH("tof_qmi_dms_srvc_init: DMS successfully initialized", 0, 0, 0);
      dms_service_initialized = TRUE;
    }
  }
  else
  {
    MSG_HIGH("tof_qmi_dms_srvc_init: Init failed, DMS already initialized", 0, 0, 0);
  }
  return rc;
}

/*===========================================================================
  FUNCTION  tof_tof_qmi_dms_srvc_init_client
===========================================================================*/
/*!
@brief 
  This function is called to initialize the DMS service.  This function
  must be called prior to calling any other DMS service functions.
  For the time being, the indication handler callback and user data
  should be set to NULL until this is implemented.  Also note that this
  function may be called multiple times to allow for multiple, independent
  clients.   
  
@return 
  0 if abort operation was sucessful, < 0 if not.  If return code is 
  QMI_INTERNAL_ERR, then the qmi_err_code will be valid and will 
  indicate which QMI error occurred.

@note

  - Dependencies
    - qmi_connection_init() must be called for the associated port first.

  - Side Effects
    - Talks to modem processor
*/    
/*=========================================================================*/
qmi_client_handle_type
tof_tof_qmi_dms_srvc_init_client
(
   const char                   *dev_id,
  qmi_dms_indication_hdlr_type  user_ind_msg_hdlr,
  void                          *user_ind_msg_hdlr_user_data,
  int                           *qmi_err_code
)
{
  qmi_client_handle_type client_handle =0;
  qmi_connection_id_type conn_id = 0;
   int err_code_connection_init;

  if ((conn_id = QMI_PLATFORM_DEV_NAME_TO_CONN_ID(dev_id)) == QMI_CONN_ID_INVALID)
  {
    return QMI_INTERNAL_ERR;
  }


  printf("lgit_tof_qmi_dms_srvc_init_client: conn_id %x\r\n",conn_id);

  if(qmi_service_connection_init(conn_id,  &err_code_connection_init) == QMI_NO_ERR)
  {
      // printf("qmi_service_connection_init: success\r\n");     

    /* Call common service layer initialization function */
    /*lint -e{611} */
    client_handle =  qmi_service_init (conn_id,
                                     QMI_DMS_SERVICE,
                                     (void *) user_ind_msg_hdlr,
                                     user_ind_msg_hdlr_user_data,
                                     qmi_err_code);

    if(client_handle > 0)  
      qmi_dms_reg_ind_hdlr(qmi_dms_srvc_indication_cb);
    else 
      printf("lgit_tof_qmi_dms_srvc_init_client: client_handle  0x%x failed \r\n",client_handle);
  }
  else printf("qmi_service_connection_init: err_code_connection_init %x\r\n",err_code_connection_init);



  return client_handle;
}

/*===========================================================================
  FUNCTION  tof_tof_qmi_dms_srvc_release_client
===========================================================================*/
/*!
@brief 
  This function is called to release a client created by the 
  tof_qmi_nas_srvc_init_client() function.  This function should be called
  for any client created when terminating a client process, especially
  if the modem processor is not reset.  The modem side QMI server has 
  a limited number of clients that it will allocate, and if they are not
  released, we will run out.  
  
@return 
  0 if abort operation was sucessful, < 0 if not.  If return code is 
  QMI_INTERNAL_ERR, then the qmi_err_code will be valid and will 
  indicate which QMI error occurred.

@note

  - Dependencies
    - qmi_connection_init() must be called for the associated port first.

  - Side Effects
    - Talks to modem processor
*/    
/*=========================================================================*/

int 
tof_tof_qmi_dms_srvc_release_client
(
  int      user_handle,
  int      *qmi_err_code
)
{
  int rc;
  rc = qmi_service_release (user_handle, qmi_err_code);

  tof_qmi_dms_srvc_release();
  return rc;     
}

/*===========================================================================
  FUNCTION  qmi_dms_event_reg
===========================================================================*/
/*!
@brief 
  Issues the Event registration command for the client. Note that this is a 
  synchronous-only function call.
  
@return 
  If return code < 0, the operation failed.  In the failure case, if the 
  return code is QMI_SERVICE_ERR, then the qmi_err_code value will give the 
  QMI error reason.  Otherwise, qmi_err_code will have meaningless data.
  
@note

  - Dependencies
    - tof_tof_qmi_dms_srvc_init_client() must be called before calling this.

  - Side Effects
    - None 
*/    
/*=========================================================================*/
int qmi_dms_event_reg
(
  int                                             client_handle,
  const dms_set_event_report_req_msg_v01           * params,
  dms_set_event_report_resp_msg_v01                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [QMI_DMS_EVENT_REG_MAX_TLV_SIZE];
  unsigned char     *param_ptr = param_buf;
  unsigned long     mask       = 0;
  int               rc;

  if((!params) || (!rsp_data))
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  #if 0 //comment �Ʒ� indication register tlv �۾� �ʿ���

  /* Prepare the TLV */
  if(params->report_mt_message_valid)
  {
    mask = params->report_mt_message;
  }

  WRITE_8_BIT_VAL(param_ptr, mask);

  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              DMSI_PRM_TYPE_REPORT_MT_MSG,
                              QMI_DMS_EVENT_REG_MAX_TLV_SIZE,
                              (void *)param_buf) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_SET_EVENT_REPORT_REQ_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
								  (int *)&rsp_data->resp.error);
  #endif
    
  return rc;
} /* qmi_dms_event_reg */

/*===========================================================================
  FUNCTION  qmi_dms_handle_get_msisdn_rsp
===========================================================================*/
/*!
@brief 
  
@return 

*/
/*=========================================================================*/
static int qmi_dms_handle_get_msisdn_rsp
(
  unsigned char                             * rx_msg,
  int                                         rx_msg_size,
  qmi_dms_rsp_data_type                                      * rsp_data
)
{
  unsigned long                          type;
  unsigned long                          length;
  unsigned char                        * value_ptr;
  

  /* Clear response buffer */
  memset((char *)&rsp_data->rsp_data.get_msisdn_rsp, 0x0 ,sizeof(dms_get_msisdn_resp_msg_v01));
  
  /* First get MSISDN mandatory field */
  if (qmi_util_read_std_tlv (&rx_msg,
                           &rx_msg_size,
                           &type,
                           &length,
                           &value_ptr) < 0)
  {
    return QMI_INTERNAL_ERR;
  }
  memcpy(rsp_data->rsp_data.get_msisdn_rsp.voice_number, value_ptr, length);

  /* loop to read the TLVs */
  while (rx_msg_size > 0)
  {
    if (qmi_util_read_std_tlv (&rx_msg,
                               &rx_msg_size,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Process the TLVS and update response data */
    switch (type)
    {
      case DMSI_PRM_TYPE_MIN:
        rsp_data->rsp_data.get_msisdn_rsp.mobile_id_number_valid = TRUE;
        memcpy(rsp_data->rsp_data.get_msisdn_rsp.mobile_id_number, value_ptr, length);
        break;

      case DMSI_PRM_TYPE_UIM_IMSI:
        rsp_data->rsp_data.get_msisdn_rsp.imsi_valid = TRUE;
        memcpy(rsp_data->rsp_data.get_msisdn_rsp.imsi, value_ptr, length);
        break;

      default:
        QMI_ERR_MSG_1 ("qmi_dms_handle_get_msisdn_rsp: unknown TLV type = %x",
                      (unsigned int)type);
        break;
    }
  }

  return QMI_NO_ERR;
} /* qmi_dms_handle_get_msisdn_rsp */

/*===========================================================================
  FUNCTION  qmi_dms_handle_get_imsi_rsp
===========================================================================*/
/*!
@brief 
  
@return 

*/
/*=========================================================================*/
static int qmi_dms_handle_get_imsi_rsp
(
  unsigned char                             * rx_msg,
  int                                         rx_msg_size,
  qmi_dms_rsp_data_type                                      * rsp_data
)
{
  unsigned long                          type;
  unsigned long                          length;
  unsigned char                        * value_ptr;
  

  /* Clear response buffer */
  memset((char *)&rsp_data->rsp_data.get_imsi_rsp, 0x0 ,sizeof(dms_uim_get_imsi_resp_msg_v01));
  
  /* First get IMSI mandatory field */
  if (qmi_util_read_std_tlv (&rx_msg,
                           &rx_msg_size,
                           &type,
                           &length,
                           &value_ptr) < 0)
  {
    return QMI_INTERNAL_ERR;
  }
  memcpy(rsp_data->rsp_data.get_imsi_rsp.imsi, value_ptr, length);

  return QMI_NO_ERR;
} /* qmi_dms_handle_get_msisdn_rsp */

/*===========================================================================
  FUNCTION  qmi_dms_handle_get_device_sn_rsp
===========================================================================*/
/*!
@brief 
  
@return 

*/
/*=========================================================================*/
static int qmi_dms_handle_get_device_sn_rsp
(
  unsigned char                             * rx_msg,
  int                                         rx_msg_size,
  qmi_dms_rsp_data_type                                      * rsp_data
)
{
  unsigned long                          type;
  unsigned long                          length;
  unsigned char                        * value_ptr;
  

  /* Clear response buffer */
  memset((char *)&rsp_data->rsp_data.get_device_sn_rsp, 0x0 ,sizeof(dms_get_device_serial_numbers_resp_msg_v01));
  
  /* loop to read the TLVs */
  while (rx_msg_size > 0)
  {
    if (qmi_util_read_std_tlv (&rx_msg,
                               &rx_msg_size,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Process the TLVS and update response data */
    switch (type)
    {
      case DMSI_PRM_TYPE_ESN:
        rsp_data->rsp_data.get_device_sn_rsp.esn_valid = TRUE;
        memcpy(rsp_data->rsp_data.get_device_sn_rsp.esn, value_ptr, length);
        break;

      case DMSI_PRM_TYPE_IMEI:
        rsp_data->rsp_data.get_device_sn_rsp.imei_valid = TRUE;
        memcpy(rsp_data->rsp_data.get_device_sn_rsp.imei, value_ptr, length);
        break;
        
      case DMSI_PRM_TYPE_MEID:
        rsp_data->rsp_data.get_device_sn_rsp.meid_valid = TRUE;
        memcpy(rsp_data->rsp_data.get_device_sn_rsp.meid, value_ptr, length);
        break;
      
      case DMSI_PRM_TYPE_IMEISV_SVN:
        rsp_data->rsp_data.get_device_sn_rsp.imeisv_svn_valid = TRUE;
        memcpy(rsp_data->rsp_data.get_device_sn_rsp.imeisv_svn, value_ptr, length);
        break;

      default:
        QMI_ERR_MSG_1 ("qmi_dms_handle_get_device_sn_rsp: unknown TLV type = %x",
                      (unsigned int)type);
        break;
    }
  }

  return QMI_NO_ERR;
} /* qmi_dms_handle_get_device_sn_rsp */

/*===========================================================================
  FUNCTION  qmi_dms_handle_get_prl_version_rsp
===========================================================================*/
/*!
@brief 
  
@return 

*/
/*=========================================================================*/
static int qmi_dms_handle_get_prl_version_rsp
(
  unsigned char                             * rx_msg,
  int                                         rx_msg_size,
  qmi_dms_rsp_data_type                                      * rsp_data
)
{
  unsigned long                          type;
  unsigned long                          length;
  unsigned char                        * value_ptr;
  

  /* Clear response buffer */
  memset((char *)&rsp_data->rsp_data.get_current_prl_info_rsp, 0x0 ,sizeof(dms_get_current_prl_info_resp_msg_v01));
  
  /* loop to read the TLVs */
  while (rx_msg_size > 0)
  {
    if (qmi_util_read_std_tlv (&rx_msg,
                               &rx_msg_size,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Process the TLVS and update response data */
    switch (type)
    {
      case QMI_TYPE_REQUIRED_PARAMETERS:
        rsp_data->rsp_data.get_current_prl_info_rsp.prl_version_valid= TRUE;
        memcpy(&rsp_data->rsp_data.get_current_prl_info_rsp.prl_version, value_ptr, length);
        break;

      default:
        QMI_ERR_MSG_1 ("qmi_dms_handle_get_prl_version_rsp: unknown TLV type = %x",
                      (unsigned int)type);
        break;
    }
  }

  return QMI_NO_ERR;
} /* qmi_dms_handle_get_device_sn_rsp */

/*===========================================================================
  FUNCTION  qmi_dms_handle_get_iccid_rsp
===========================================================================*/
/*!
@brief 
  
@return 

*/
/*=========================================================================*/
static int qmi_dms_handle_get_iccid_rsp
(
  unsigned char                             * rx_msg,
  int                                         rx_msg_size,
  qmi_dms_rsp_data_type                                      * rsp_data
)
{
  unsigned long                          type;
  unsigned long                          length;
  unsigned char                        * value_ptr;
  

  /* Clear response buffer */
  memset((char *)&rsp_data->rsp_data.get_iccid_rsp, 0x0 ,sizeof(dms_uim_get_iccid_resp_msg_v01));
  
  /* First get ICCID mandatory field */
  if (qmi_util_read_std_tlv (&rx_msg,
                           &rx_msg_size,
                           &type,
                           &length,
                           &value_ptr) < 0)
  {
    return QMI_INTERNAL_ERR;
  }
  memcpy(rsp_data->rsp_data.get_iccid_rsp.uim_id, value_ptr, length);

  return QMI_NO_ERR;
} /* qmi_dms_handle_get_iccid_rsp */

/*===========================================================================
  FUNCTION  qmi_dms_handle_get_oprt_mode_rsp
===========================================================================*/
/*!
@brief 
  
@return 

*/
/*=========================================================================*/
static int qmi_dms_handle_get_oprt_mode_rsp
(
  unsigned char                             * rx_msg,
  int                                         rx_msg_size,
  qmi_dms_rsp_data_type                                      * rsp_data
)
{
  unsigned long                          type;
  unsigned long                          length;
  unsigned char                        * value_ptr;
  

  /* Clear response buffer */
  memset((char *)&rsp_data->rsp_data.get_operating_mode_rsp, 0x0 ,sizeof(dms_get_operating_mode_resp_msg_v01));
  
  /* loop to read the TLVs */
  while (rx_msg_size > 0)
  {
    if (qmi_util_read_std_tlv (&rx_msg,
                               &rx_msg_size,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Process the TLVS and update response data */
    switch (type)
    {
      case QMI_TYPE_REQUIRED_PARAMETERS:
        memcpy(&rsp_data->rsp_data.get_operating_mode_rsp.operating_mode, value_ptr, length);
        break;

#ifdef FEATURE_DATA_QMI_ADDENDUM
      case DMSI_PRM_TYPE_HW_RESTRICTED:
        rsp_data->rsp_data.get_operating_mode_rsp.hardware_controlled_mode_valid = TRUE;
        rsp_data->rsp_data.get_operating_mode_rsp.hardware_controlled_mode = *value_ptr;          
        break;

      case DMSI_PRM_TYPE_OFFLINE_REASON:
        rsp_data->rsp_data.get_operating_mode_rsp.offline_reason_valid = TRUE;
        memcpy(&rsp_data->rsp_data.get_operating_mode_rsp.offline_reason, value_ptr, length);
        break;
#endif

      default:
        QMI_ERR_MSG_1 ("qmi_dms_handle_get_oprt_mode_rsp: unknown TLV type = %x",
                      (unsigned int)type);
        break;
    }
  }

  return QMI_NO_ERR;
} /* qmi_dms_handle_get_msisdn_rsp */

/*===========================================================================
  FUNCTION  qmi_dms_handle_get_modem_sw_version_rsp
===========================================================================*/
/*!
@brief 
  
@return 

*/
/*=========================================================================*/
static int qmi_dms_handle_get_modem_sw_version_rsp
(
  unsigned char                             * rx_msg,
  int                                         rx_msg_size,
  qmi_dms_rsp_data_type                                      * rsp_data
)
{
  unsigned long                          type;
  unsigned long                          length;
  unsigned char                        * value_ptr;
  

  /* Clear response buffer */
  memset((char *)&rsp_data->rsp_data.get_modem_sw_version_rsp, 0x0 ,sizeof(dms_get_modem_sw_version_resp_msg_v01));
  
  /* loop to read the TLVs */
  while (rx_msg_size > 0)
  {
    if (qmi_util_read_std_tlv (&rx_msg,
                               &rx_msg_size,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Process the TLVS and update response data */
    switch (type)
    {
      case QMI_TYPE_REQUIRED_PARAMETERS:
        memcpy(&rsp_data->rsp_data.get_modem_sw_version_rsp.modem_sw_version, value_ptr, length);
        break;

      case DMSI_PRM_TYPE_ASIC_VER:
        rsp_data->rsp_data.get_modem_sw_version_rsp.chip_solution_name_valid = TRUE;
        memcpy(&rsp_data->rsp_data.get_modem_sw_version_rsp.chip_solution_name, value_ptr, length);
        break;

      case DMSI_PRM_TYPE_MODEL_CODE:
        rsp_data->rsp_data.get_modem_sw_version_rsp.model_name_valid = TRUE;
        memcpy(&rsp_data->rsp_data.get_modem_sw_version_rsp.model_name, value_ptr, length);
        break;

      case DMSI_PRM_TYPE_SW_BUILD_DATE:
        rsp_data->rsp_data.get_modem_sw_version_rsp.build_date_valid = TRUE;
        memcpy(&rsp_data->rsp_data.get_modem_sw_version_rsp.build_date, value_ptr, length);
        break;

      case DMSI_PRM_TYPE_SW_BUILD_TIME:
        rsp_data->rsp_data.get_modem_sw_version_rsp.build_time_valid = TRUE;
        memcpy(&rsp_data->rsp_data.get_modem_sw_version_rsp.build_time, value_ptr, length);
        break;

      case DMSI_PRM_TYPE_BOOT_VERSION://swlee 
        memcpy(&rsp_data->rsp_data.get_modem_sw_version_rsp.modem_boot_version, value_ptr, length);
        break;		

      case DMSI_PRM_TYPE_CAL_INFORMATION:
        memcpy(&rsp_data->rsp_data.get_modem_sw_version_rsp.cal_info_version, value_ptr, length);
        break;	

      case DMSI_PRM_TYPE_HW_VERSION:
        memcpy(&rsp_data->rsp_data.get_modem_sw_version_rsp.modem_hw_version, value_ptr, length);
        break;	

        
      default:
        QMI_ERR_MSG_1 ("qmi_dms_handle_get_modem_sw_version_rsp: unknown TLV type = %x",
                      (unsigned int)type);
        break;
    }
  }

  return QMI_NO_ERR;
} /* qmi_dms_handle_get_modem_sw_version_rsp */

/*===========================================================================
  FUNCTION  qmi_dms_get_msisdn
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int qmi_dms_get_msisdn
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [QMI_DMS_EVENT_REG_MAX_TLV_SIZE];
  unsigned char     *param_ptr = param_buf;
  unsigned long     mask       = 0;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  //MSISDN req message don't need TLV field

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_GET_MSISDN_REQ_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &rsp_data->qmi_err_code);
  if (rc == QMI_NO_ERR)
  {
    rsp_data->rsp_id = DMSI_CMD_GET_MSISDN;
    if (qmi_dms_handle_get_msisdn_rsp (msg, msg_size, rsp_data) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_dms_get_msisdn: qmi_dms_get_msisdn returned error");
      rc = QMI_INTERNAL_ERR;
    }
  }
    
  return rc;
} /* qmi_dms_get_msisdn */

/*===========================================================================
  FUNCTION  qmi_dms_get_imei
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int qmi_dms_get_device_serial_number
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [QMI_DMS_EVENT_REG_MAX_TLV_SIZE];
  unsigned char     *param_ptr = param_buf;
  unsigned long     mask       = 0;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  //MSISDN req message don't need TLV field

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_GET_DEVICE_SERIAL_NUMBERS_REQ_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &rsp_data->qmi_err_code);
  if (rc == QMI_NO_ERR)
  {
    if (qmi_dms_handle_get_device_sn_rsp (msg, msg_size, rsp_data) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_dms_get_device_serial_number: qmi_dms_get_device_serial_number returned error");
      rc = QMI_INTERNAL_ERR;
    }
  }
    
  return rc;
} /* qmi_dms_get_device_serial_number */


/*===========================================================================
  FUNCTION  qmi_dms_get_prl_version
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int qmi_dms_get_prl_version
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [QMI_DMS_EVENT_REG_MAX_TLV_SIZE];
  unsigned char     *param_ptr = param_buf;
  unsigned long     mask       = 0;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  //MSISDN req message don't need TLV field

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_GET_PRL_VER_REQ_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &rsp_data->qmi_err_code);
  if (rc == QMI_NO_ERR)
  {
    if (qmi_dms_handle_get_prl_version_rsp (msg, msg_size, rsp_data) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_dms_get_prl_version: qmi_dms_get_prl_version returned error");
      rc = QMI_INTERNAL_ERR;
    }
  }
    
  return rc;
} /* qmi_dms_get_device_serial_number */

/*===========================================================================
  FUNCTION  qmi_dms_get_iccid
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int qmi_dms_get_iccid
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [QMI_DMS_EVENT_REG_MAX_TLV_SIZE];
  unsigned char     *param_ptr = param_buf;
  unsigned long     mask       = 0;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  //MSISDN req message don't need TLV field

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_UIM_GET_ICCID_REQ_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &rsp_data->qmi_err_code);
  if (rc == QMI_NO_ERR)
  {
    rsp_data->rsp_id = DMSI_CMD_GET_UIM_ICCID;
    if (qmi_dms_handle_get_iccid_rsp (msg, msg_size, rsp_data) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_dms_get_iccid: qmi_dms_get_iccid returned error");
      rc = QMI_INTERNAL_ERR;
    }
  }
    
  return rc;
} /* qmi_dms_get_iccid */

/*===========================================================================
  FUNCTION  qmi_dms_uim_write_pin_protection_tlv
===========================================================================*/
/*!
@brief 

@return 

@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
static int qmi_dms_uim_write_pin_protection_tlv
(
  unsigned char                                   ** msg,
  int                                             *  msg_size,
  const dms_uim_set_pin_protection_req_msg_v01    *  params
)
{
  unsigned char     param_buf [QMI_DMS_STD_MSG_SIZE];
  unsigned char   * param_ptr = param_buf;

  /* Next is the pin protection TLV */
  WRITE_8_BIT_VAL (param_ptr, params->pin_protection_info.pin_id);
  WRITE_8_BIT_VAL (param_ptr, params->pin_protection_info.protection_setting_enabled);
  WRITE_8_BIT_VAL (param_ptr, params->pin_protection_info.pin_value_len);
  if(params->pin_protection_info.pin_value_len <= QMI_UIM_MAX_PIN_LEN)
  {
    memcpy (param_ptr, (char *)params->pin_protection_info.pin_value, 
            params->pin_protection_info.pin_value_len);    
  }
  else
  {
    return QMI_INTERNAL_ERR;
  }
  if (qmi_util_write_std_tlv (msg,
                              msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              3 + params->pin_protection_info.pin_value_len,
                              (void *)(param_buf)) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  return QMI_NO_ERR;
} /* qmi_uim_write_pin_protection_tlv */

/*===========================================================================
  FUNCTION  qmi_dms_uim_set_pin_protection
===========================================================================*/
/*!
@brief 
  
@return 

@note

*/    
/*=========================================================================*/
int qmi_dms_uim_set_pin_protection
(
  int                                               client_handle,
  const dms_uim_set_pin_protection_req_msg_v01    * params,
  qmi_dms_rsp_data_type                           * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  int               msg_size;
  unsigned char    *tmp_msg_ptr;
  int rc;  

  if (!params)
  {
    return QMI_SERVICE_ERR;
  }

  if (!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
   * message buffer */
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);

  /* Set the message size to the complete buffer minus the header size */
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  /* Construct TLV for Set Pin protection request */
  if (qmi_dms_uim_write_pin_protection_tlv (&tmp_msg_ptr,
                                        &msg_size,
                                        params) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  /* Send message */
  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_UIM_SET_PIN_PROTECTION_REQ_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &rsp_data->qmi_err_code);

  if (rc == QMI_NO_ERR)
  {
    rsp_data->rsp_id = DMSI_CMD_SET_UIM_PIN_PROTECTION;
  }
    
  return rc;
} /* qmi_uim_set_pin_protection */

/*===========================================================================
  FUNCTION  qmi_dms_uim_write_unblock_pin_tlv
===========================================================================*/
/*!
@brief 
@return 
    
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
static int qmi_dms_uim_write_unblock_pin_tlv
(
  unsigned char                             ** msg,
  int                                       *  msg_size,
  const dms_uim_unblock_pin_req_msg_v01     *  params
)
{
  unsigned char     param_buf [QMI_DMS_STD_MSG_SIZE];
  unsigned char   * param_ptr = param_buf;
  unsigned long     size = 3;

  /* Next is the Unblock pin TLV */
  WRITE_8_BIT_VAL (param_ptr, params->pin_unblock_info.unblock_pin_id);
  WRITE_8_BIT_VAL (param_ptr, params->pin_unblock_info.puk_value_len);
  if(params->pin_unblock_info.puk_value_len <= QMI_UIM_MAX_PIN_LEN)
  {
    memcpy (param_ptr, (char *)params->pin_unblock_info.puk_value, 
            params->pin_unblock_info.puk_value_len);
    param_ptr += params->pin_unblock_info.puk_value_len;
    size += params->pin_unblock_info.puk_value_len;
  }
  else
  {
    return QMI_INTERNAL_ERR;
  }

  WRITE_8_BIT_VAL (param_ptr, params->pin_unblock_info.new_pin_value_len);
  if(params->pin_unblock_info.new_pin_value_len <= QMI_UIM_MAX_PIN_LEN)
  {
    memcpy (param_ptr, (char *)params->pin_unblock_info.new_pin_value, 
            params->pin_unblock_info.new_pin_value_len);
    size += params->pin_unblock_info.new_pin_value_len;
  }
  else
  {
    return QMI_INTERNAL_ERR;
  }

  if (qmi_util_write_std_tlv (msg,
                              msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              size,
                              (void *)(param_buf)) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  return QMI_NO_ERR;
} /* qmi_uim_write_unblock_pin_tlv */

/*===========================================================================
  FUNCTION  qmi_dms_uim_unblock_pin
===========================================================================*/
/*!
@brief 

@return 

@note
  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int qmi_dms_uim_unblock_pin
(
  int                                                 client_handle,
  const dms_uim_unblock_pin_req_msg_v01             * params,
  qmi_dms_rsp_data_type                             * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  int               msg_size;
  unsigned char    *tmp_msg_ptr;
  int rc;  

  if(!params)
  {
    return QMI_SERVICE_ERR;
  }

  if (!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
   * message buffer */
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);

  /* Set the message size to the complete buffer minus the header size */
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  /* Construct TLV for Unblock Pin request */
  if (qmi_dms_uim_write_unblock_pin_tlv (&tmp_msg_ptr,
                                     &msg_size,
                                     params) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  /* Send message */
  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_UIM_UNBLOCK_PIN_REQ_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &rsp_data->qmi_err_code);
    
  if (rc == QMI_NO_ERR)
  {
    rsp_data->rsp_id = DMSI_CMD_UNBLOCK_UIM_PIN;
  }
   
  return rc;
} /* qmi_uim_unblock_pin */

/*===========================================================================
  FUNCTION  qmi_dms_uim_write_change_pin_tlv
===========================================================================*/
/*!
@brief 

@return 

@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
static int qmi_dms_uim_write_change_pin_tlv
(
  unsigned char                             ** msg,
  int                                       *  msg_size,
  const dms_uim_change_pin_req_msg_v01      *  params
)
{
  unsigned char     param_buf [QMI_DMS_STD_MSG_SIZE];
  unsigned char   * param_ptr = param_buf;
  unsigned long     size = 3;

  /* Next is the Change pin TLV */
  WRITE_8_BIT_VAL (param_ptr, params->pin_change_info.pin_id);
  WRITE_8_BIT_VAL (param_ptr, params->pin_change_info.old_pin_value_len);
  if(params->pin_change_info.old_pin_value_len <= QMI_UIM_MAX_PIN_LEN)
  {
    memcpy (param_ptr, (char *)params->pin_change_info.old_pin_value, 
            params->pin_change_info.old_pin_value_len);
    param_ptr += params->pin_change_info.old_pin_value_len;
    size += params->pin_change_info.old_pin_value_len;
  }
  else
  {
    return QMI_INTERNAL_ERR;
  }

  WRITE_8_BIT_VAL (param_ptr, params->pin_change_info.new_pin_value_len);
  if(params->pin_change_info.new_pin_value_len <= QMI_UIM_MAX_PIN_LEN)
  {
    memcpy (param_ptr, (char *)params->pin_change_info.new_pin_value, 
            params->pin_change_info.new_pin_value_len);
    size += params->pin_change_info.new_pin_value_len;
  }
  else
  {
    return QMI_INTERNAL_ERR;
  }

  if (qmi_util_write_std_tlv (msg,
                              msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              size,
                              (void *)(param_buf)) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  return QMI_NO_ERR;
} /* qmi_uim_write_change_pin_tlv */

/*===========================================================================
  FUNCTION  qmi_dms_uim_change_pin
===========================================================================*/
/*!
@brief 

@return 

@note
  - Dependencies

  - Side Effects

*/    
/*=========================================================================*/
int qmi_dms_uim_change_pin
(
  int                                               client_handle,
  const dms_uim_change_pin_req_msg_v01            * params,
  qmi_dms_rsp_data_type                           * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  int               msg_size;
  unsigned char    *tmp_msg_ptr;
  int rc;  

  if(!params)
  {
    return QMI_SERVICE_ERR;
  }

  if (!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
   * message buffer */
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);

  /* Set the message size to the complete buffer minus the header size */
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  /* Construct TLV for Change Pin request */
  if (qmi_dms_uim_write_change_pin_tlv (&tmp_msg_ptr,
                                    &msg_size,
                                    params) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  /* Send message */
  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_UIM_CHANGE_PIN_REQ_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &rsp_data->qmi_err_code);
    
  if (rc == QMI_NO_ERR)
  {
    rsp_data->rsp_id = DMSI_CMD_CHANGE_UIM_PIN;
  }
   
  return rc;
} /* qmi_uim_change_pin */

/*===========================================================================
  FUNCTION  qmi_dms_get_vendor
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int qmi_dms_get_vendor
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [QMI_DMS_EVENT_REG_MAX_TLV_SIZE];
  unsigned char     *param_ptr = param_buf;
  unsigned long     mask       = 0;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  //MSISDN req message don't need TLV field

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_GET_MODEM_VENDOR,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &rsp_data->qmi_err_code);
  if (rc == QMI_NO_ERR)
  {
    unsigned char *tmp_msg_buf = (unsigned char *)msg;
    unsigned long                          type;
    unsigned long                          length;
    unsigned char                        * value_ptr;
    
    /* First get ICCID mandatory field */
    if (qmi_util_read_std_tlv (&tmp_msg_buf,
                             &msg_size,
                             &type,
                             &length,
                             &value_ptr) < 0)
    {
      rc = QMI_INTERNAL_ERR;
    }
    else   
    {
      if((unsigned char)type == QMI_TYPE_REQUIRED_PARAMETERS) //means vendor
        rsp_data->rsp_data.device_vendor = * value_ptr;
      else
        rc = QMI_INTERNAL_ERR;
    }
  }
    
  return rc;
} /* qmi_dms_get_vendor */

/*===========================================================================
  FUNCTION  qmi_dms_set_vendor
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int qmi_dms_set_vendor
(
  int                                             client_handle,
  byte                                          vendor,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [QMI_DMS_VENDOR_TLV_SIZE];
  unsigned char     *param_ptr = param_buf;
  unsigned long     mask       = 0;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  WRITE_8_BIT_VAL(param_ptr, vendor);

  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              QMI_DMS_VENDOR_TLV_SIZE,
                              (void *)param_buf) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_SET_MODEM_VENDOR,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
								      &rsp_data->qmi_err_code);
  if(rc != QMI_NO_ERR || rsp_data->qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_set_vendor!! rc: %d err_code : %d",rc,rsp_data->qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
    
  return rc;
} /* qmi_dms_set_vendor */

/*===========================================================================
  FUNCTION  qmi_dms_get_oprt_mode
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int qmi_dms_get_oprt_mode
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [QMI_DMS_EVENT_REG_MAX_TLV_SIZE];
  unsigned char     *param_ptr = param_buf;
  unsigned long     mask       = 0;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  //MSISDN req message don't need TLV field

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_GET_OPERATING_MODE_REQ_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &rsp_data->qmi_err_code);

  if (rc == QMI_NO_ERR)
  {
    if (qmi_dms_handle_get_oprt_mode_rsp (msg, msg_size, rsp_data) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_dms_get_oprt_mode: returned error");
      rc = QMI_INTERNAL_ERR;
    }
  }
    
  return rc;
} /* qmi_dms_get_oprt_mode */

/*===========================================================================
  FUNCTION  qmi_dms_set_oprt_mode
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int qmi_dms_set_oprt_mode
(
  int                                             client_handle,
  uint8                                          oprt_mode,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [QMI_DMS_VENDOR_TLV_SIZE];
  unsigned char     *param_ptr = param_buf;
  unsigned long     mask       = 0;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  WRITE_8_BIT_VAL(param_ptr, oprt_mode);

  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              sizeof(oprt_mode),
                              (void *)param_buf) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_SET_OPERATING_MODE_REQ_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_APN_INFO_TIMEOUT,
								      &rsp_data->qmi_err_code);
  if(rc != QMI_NO_ERR || rsp_data->qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_set_oprt_mode!! rc: %d err_code : %d",rc,rsp_data->qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
    
  return rc;
} /* qmi_dms_set_oprt_mode */

/*===========================================================================
  FUNCTION  qmi_dms_get_sw_version
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int qmi_dms_get_sw_version
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [QMI_DMS_EVENT_REG_MAX_TLV_SIZE];
  unsigned char     *param_ptr = param_buf;
  unsigned long     mask       = 0;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  //MSISDN req message don't need TLV field

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_GET_MODEM_SW_VERSION,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &rsp_data->qmi_err_code);

  if (rc == QMI_NO_ERR)
  {
    if (qmi_dms_handle_get_modem_sw_version_rsp (msg, msg_size, rsp_data) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_dms_handle_get_modem_sw_version_rsp: returned error");
      rc = QMI_INTERNAL_ERR;
    }
  }
    
  return rc;
} /* qmi_dms_get_sw_version */


/*===========================================================================
FUNCTION  qmi_dms_get_96hmode
===========================================================================*/
/*!@brief
@return   
@note
- Dependencies
- Side Effects
*/
/*=========================================================================*/
int qmi_dms_get_96hmode
(
int                                             client_handle,
qmi_dms_rsp_data_type                         * rsp_data
)
{
    unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
    unsigned char     *msg_ptr;
    int               msg_size;
    int               rc;
    if(!rsp_data)  
    {    
        return QMI_SERVICE_ERR; 
        }  
    /* Prepare the request message */
    msg_ptr = QMI_SRVC_PDU_PTR(msg);
    msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);
    rc = qmi_service_send_msg_sync (client_handle,
                                    QMI_DMS_SERVICE,
                                    QMI_DMS_GET_96HMODE,
                                    QMI_SRVC_PDU_PTR(msg),
                                    (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                    msg,
                                    &msg_size,
                                    QMI_DMS_STD_MSG_SIZE,
                                    QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                    &rsp_data->qmi_err_code);
    if (rc == QMI_NO_ERR)  
    {         
        if(msg[0] == QMI_TYPE_REQUIRED_PARAMETERS)      
        {
			memcpy(&rsp_data->rsp_data.modem_96h_mode_rsp, (void *)(msg+3), QMI_DMS_96H_TLV_SIZE);		
        }		
        else
            rc = QMI_INTERNAL_ERR;  
    }      

    return rc;
} 

/*===========================================================================
FUNCTION  qmi_dms_set_96hmode
===========================================================================
*/
/*!
@brief
@return
@note 
- Dependencies
- Side Effects
*/    
/*=========================================================================*/
int qmi_dms_set_96hmode
(  
    int                                             client_handle,  
    qmi_dms_rsp_data_type                         * rsp_data
)
{  
    unsigned char     msg[QMI_DMS_STD_MSG_SIZE];  
    unsigned char     *msg_ptr;  
    int msg_size;
    unsigned char     param_buf [QMI_DMS_96H_TLV_SIZE];
    unsigned long     mask       = 0;
    int               rc;

    if(!rsp_data)
    {    
        return QMI_SERVICE_ERR;  
    } 

    /* Prepare the request message */ 
    msg_ptr = QMI_SRVC_PDU_PTR(msg); 
    msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);  
    memset (param_buf, 0, sizeof(param_buf)); 
    memcpy( (void *)(param_buf), &rsp_data->rsp_data.modem_96h_mode_rsp, QMI_DMS_96H_TLV_SIZE);  


    if (qmi_util_write_std_tlv (&msg_ptr,                              
                                &msg_size,                              
                                QMI_TYPE_REQUIRED_PARAMETERS,                              
                                QMI_DMS_96H_TLV_SIZE,                              
                                (void *)param_buf) < 0)  
    {    
        return QMI_INTERNAL_ERR;  
    } 

    rc = qmi_service_send_msg_sync (client_handle,
                                    QMI_DMS_SERVICE,
                                    QMI_DMS_SET_96HMODE,
                                    QMI_SRVC_PDU_PTR(msg),
                                    (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                    msg,                                                  
                                    &msg_size,  
                                    QMI_DMS_STD_MSG_SIZE,  
                                    QMI_SYNC_MSG_DEFAULT_TIMEOUT,  
                                    &rsp_data->qmi_err_code); 

    if(rc != QMI_NO_ERR || rsp_data->qmi_err_code != QMI_SERVICE_ERR_NONE) 
    {   
        MSG_ERROR("[DMS]qmi_dms_set_96h mode!! rc: %d err_code : %d",rc,rsp_data->qmi_err_code,0);    
        return RESULT_FAILURE;  
    }  
    else  
        return RESULT_SUCCESS;  

    return rc; 
}

/*===========================================================================
  FUNCTION  qmi_dms_get_96hmode_rat_mode_set
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int qmi_dms_get_96hmode_rat_mode_set
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_GET_96HMODE_RAT_MODE_SET,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &rsp_data->qmi_err_code);
  if (rc == QMI_NO_ERR)
  {	  
    if(msg[0] == QMI_TYPE_REQUIRED_PARAMETERS) 
    {
      memcpy(&rsp_data->rsp_data.modem_96h_rat_mode_set_rsp, (void *)(msg+3), QMI_DMS_96H_RAT_MODE_TLV_SIZE);
    }
    else
      rc = QMI_INTERNAL_ERR;
  }
    
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_set_96hmode_rat_mode_set
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int qmi_dms_set_96hmode_rat_mode_set
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  //unsigned char     param_buf [QMI_DMS_96H_RAT_MODE_TLV_SIZE];
  unsigned long     mask       = 0;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  //memset (param_buf, 0, sizeof(param_buf));
  //memcpy( (void *)(param_buf), &rsp_data->rsp_data.modem_96h_rat_mode_set_rsp, QMI_DMS_96H_RAT_MODE_TLV_SIZE);

  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              QMI_DMS_96H_RAT_MODE_TLV_SIZE,
                              &rsp_data->rsp_data.modem_96h_rat_mode_set_rsp) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_SET_96HMODE_RAT_MODE_SET,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
								      &rsp_data->qmi_err_code);
  if(rc != QMI_NO_ERR || rsp_data->qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_set_96hmode_rat_mode_set!! rc: %d err_code : %d",rc,rsp_data->qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
    
  return rc;
 
}

/*===========================================================================
  FUNCTION  qmi_dms_modem_init
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int qmi_dms_modem_init
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  int               rc;
  
  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_MODEM_INIT,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &rsp_data->qmi_err_code);
  
  if(rc != QMI_NO_ERR || rsp_data->qmi_err_code != QMI_SERVICE_ERR_NONE)
  {	  
   	MSG_ERROR("[DMS]qmi_dms_modem_init error!! rc: %d err_code : %d",rc,rsp_data->qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
  	
    
  return rc;
} /* qmi_dms_modem_init */

/*===========================================================================
  FUNCTION  qmi_dms_nv_read
===========================================================================*/
int qmi_dms_nv_read
(
  int                                            client_handle,
  uint16                                         item,
  uint8                                          *item_data
)
{
  int rc;
  uint16 context = 0;
  rc = qmi_dms_nv_read_ext(client_handle, item, context, item_data);
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_nv_read_ext
===========================================================================*/
int qmi_dms_nv_read_ext
(
  int                                            client_handle,
  uint16                                         item,
  uint16                                         context,
  uint8                                          *item_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [sizeof(uint16)*2];
  unsigned char     *param_ptr = param_buf;
  int               rc;
  int               qmi_err_code;

  if(item_data == NULL)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  WRITE_16_BIT_VAL(param_ptr, item);
  WRITE_16_BIT_VAL(param_ptr, context);

  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              sizeof(uint16)*2,
                              (void *)param_buf) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_NV_READ,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &qmi_err_code);
  
  if (rc == QMI_NO_ERR)
  {	  
    if(msg[0] == QMI_TYPE_REQUIRED_PARAMETERS) 
    {
      memcpy(item_data, (void *)(msg+3), QMI_NV_ITEM_SIZE_MAX);
    }
    else
    {
      rc = QMI_INTERNAL_ERR;
    }
  }
    
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_nv_write
===========================================================================*/
int qmi_dms_nv_write
(
  int                                            client_handle,
  uint16                                         item,
  uint8                                          *item_data
)
{
  int rc;
  uint16 context = 0;
  rc = qmi_dms_nv_write_ext(client_handle, item, context, item_data);
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_nv_write_ext
===========================================================================*/
int qmi_dms_nv_write_ext
(
  int                                            client_handle,
  uint16                                         item,
  uint16                                         context,
  uint8                                          *item_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [sizeof(uint16)*2+QMI_NV_ITEM_SIZE_MAX];
  unsigned char     *param_ptr = param_buf;
  int               rc;
  int               qmi_err_code;

  if(item_data == NULL)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  WRITE_16_BIT_VAL(param_ptr, item);
  WRITE_16_BIT_VAL(param_ptr, context);
  memcpy(param_ptr, item_data, QMI_NV_ITEM_SIZE_MAX);
  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              sizeof(uint16)*2+QMI_NV_ITEM_SIZE_MAX,
                              (void *)param_buf) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_NV_WRITE,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &qmi_err_code);
  
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {	  
   	MSG_ERROR("[DMS]qmi_dms_nv_write_ext error!! rc: %d err_code : %d",rc,qmi_err_code,0);
    rc = QMI_INTERNAL_ERR;
  }
    
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_get_gmmp_domain_manufacture
===========================================================================*/
int qmi_dms_get_gmmp_domain_manufacture
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_GET_GMMP_DOMAIN_MANUFACTURE,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &rsp_data->qmi_err_code);
  if (rc == QMI_NO_ERR)
  {	  
    if(msg[0] == QMI_TYPE_REQUIRED_PARAMETERS) 
    {
      memcpy(&rsp_data->rsp_data.gmmp_domain_manufacture_rsp, (void *)(msg+3), sizeof(dms_gmmp_domain_manufacture_msg_v01));
    }
    else
      rc = QMI_INTERNAL_ERR;
  }
    
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_set_gmmp_domain_manufacture
===========================================================================*/
int qmi_dms_set_gmmp_domain_manufacture
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned long     mask       = 0;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              sizeof(dms_gmmp_domain_manufacture_msg_v01),
                              &rsp_data->rsp_data.gmmp_domain_manufacture_rsp) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_SET_GMMP_DOMAIN_MANUFACTURE,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
								      &rsp_data->qmi_err_code);
  if(rc != QMI_NO_ERR || rsp_data->qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_set_gmmp_domain_manufacture!! rc: %d err_code : %d",rc,rsp_data->qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
    
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_get_gmmp_server_ip_port_num
===========================================================================*/
int qmi_dms_get_gmmp_server_ip_port_num
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_GET_GMMP_SERVER_IP_PORT_NUM,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &rsp_data->qmi_err_code);
  if (rc == QMI_NO_ERR)
  {	  
    if(msg[0] == QMI_TYPE_REQUIRED_PARAMETERS) 
    {
      memcpy(&rsp_data->rsp_data.gmmp_server_ip_port_num_rsp, (void *)(msg+3), sizeof(dms_gmmp_server_ip_port_num_msg_v01));
    }
    else
      rc = QMI_INTERNAL_ERR;
  }
    
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_set_gmmp_server_ip_port_num
===========================================================================*/
int qmi_dms_set_gmmp_server_ip_port_num
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned long     mask       = 0;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              sizeof(dms_gmmp_server_ip_port_num_msg_v01),
                              &rsp_data->rsp_data.gmmp_server_ip_port_num_rsp) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_SET_GMMP_SERVER_IP_PORT_NUM,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
								      &rsp_data->qmi_err_code);
  if(rc != QMI_NO_ERR || rsp_data->qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_set_gmmp_server_ip_port_num!! rc: %d err_code : %d",rc,rsp_data->qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
    
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_get_gmmp_gw_id_auth_key_device_id
===========================================================================*/
int qmi_dms_get_gmmp_gw_id_auth_key_device_id
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_GET_GMMP_GW_ID_AUTH_KEY_DEVICE_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &rsp_data->qmi_err_code);
  if (rc == QMI_NO_ERR)
  {	  
    if(msg[0] == QMI_TYPE_REQUIRED_PARAMETERS) 
    {
      memcpy(&rsp_data->rsp_data.gmmp_gw_id_auth_key_device_id_rsp, (void *)(msg+3), sizeof(dms_gmmp_gw_id_auth_key_device_id_msg_v01));
    }
    else
      rc = QMI_INTERNAL_ERR;
  }
    
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_set_gmmp_gw_id_auth_key_device_id
===========================================================================*/
int qmi_dms_set_gmmp_gw_id_auth_key_device_id
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned long     mask       = 0;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              sizeof(dms_gmmp_gw_id_auth_key_device_id_msg_v01),
                              &rsp_data->rsp_data.gmmp_gw_id_auth_key_device_id_rsp) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_SET_GMMP_GW_ID_AUTH_KEY_DEVICE_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
								      &rsp_data->qmi_err_code);
  if(rc != QMI_NO_ERR || rsp_data->qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_set_gmmp_gw_id_auth_key_device_id!! rc: %d err_code : %d",rc,rsp_data->qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
    
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_get_gmmp_profile_info
===========================================================================*/
int qmi_dms_get_gmmp_profile_info
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_GET_GMMP_PROFILE_INFO,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &rsp_data->qmi_err_code);
  if (rc == QMI_NO_ERR)
  {	  
    if(msg[0] == QMI_TYPE_REQUIRED_PARAMETERS) 
    {
      memcpy(&rsp_data->rsp_data.gmmp_profile_info_rsp, (void *)(msg+3), sizeof(dms_gmmp_profile_info_msg_v01));
    }
    else
      rc = QMI_INTERNAL_ERR;
  }
    
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_set_gmmp_profile_info
===========================================================================*/
int qmi_dms_set_gmmp_profile_info
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned long     mask       = 0;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              sizeof(dms_gmmp_profile_info_msg_v01),
                              &rsp_data->rsp_data.gmmp_profile_info_rsp) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_SET_GMMP_PROFILE_INFO,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
								      &rsp_data->qmi_err_code);
  if(rc != QMI_NO_ERR || rsp_data->qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_set_gmmp_profile!! rc: %d err_code : %d",rc,rsp_data->qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
    
  return rc;
}


int qmi_dms_get_modem_temperature
(
  int                                             client_handle,
  char                         * temperature
){

  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  int               rc;
  int               qmi_err_code;
  
 /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);
   MSG_ERROR("[DMS]qmi_dms_get_modem_temperature!",0,0,0);
  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_MODEM_TEMPERATURE,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &qmi_err_code);
  if (rc == QMI_NO_ERR)
  {	  
    if(msg[0] == QMI_TYPE_REQUIRED_PARAMETERS) 
    {
      memcpy(temperature, (void *)(msg+3), 5);
      MSG_ERROR("[DMS]qmi_dms_get_modem_temperature!= %s", temperature,0,0);
    }
    else
      rc = QMI_INTERNAL_ERR;
  }
    
  return rc;  
}

/*===========================================================================
  FUNCTION  qmi_dms_get_modem_antdetect
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/

int qmi_dms_get_modem_antdetect
(
  int                                             client_handle,
  qmi_dms_rsp_data_type								               * rsp_data
){

  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  int               rc;
  
 /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_GET_MODEM_ANTDETECT,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &rsp_data->qmi_err_code);
  if (rc == QMI_NO_ERR)
  {	  
    if(msg[0] == QMI_TYPE_REQUIRED_PARAMETERS) 
    {
      memcpy(&rsp_data->rsp_data.modem_ant_detect_rsp, (void *)(msg+3),sizeof(dms_modem_ant_detect));
    }
    else
      rc = QMI_INTERNAL_ERR;
  }
    
  return rc;  
} 

/*===========================================================================
  FUNCTION  qmi_dms_set_modem_reset_log
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/

int qmi_dms_set_modem_reset_log
(
  int                                             client_handle,
  boolean                                           reset_log_enable,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [QMI_DMS_VENDOR_TLV_SIZE];
  unsigned char     *param_ptr = param_buf;
  int               rc;
  
  
 /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);
  MSG_ERROR("[DMS]qmi_dms_set_modem_reset_log!",0,0,0);

  memset (param_buf, 0, sizeof(param_buf));

    /* Prepare the TLV */
  WRITE_8_BIT_VAL(param_ptr, reset_log_enable);
  
  if (qmi_util_write_std_tlv (&msg_ptr,
                            &msg_size,
                            QMI_TYPE_REQUIRED_PARAMETERS,
                            sizeof(reset_log_enable),
                            (void *)param_buf) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                QMI_DMS_SERVICE,
                                QMI_DMS_SET_MODEM_RESET_LOG,
                                QMI_SRVC_PDU_PTR(msg),
                                (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                msg,                 
                                &msg_size,
                                QMI_DMS_STD_MSG_SIZE,
                                QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                &rsp_data->qmi_err_code);

  if(rc != QMI_NO_ERR || rsp_data->qmi_err_code != QMI_SERVICE_ERR_NONE)
  {	  
  	MSG_ERROR("[DMS]qmi_dms_set_modem_reset_log error!! rc: %d err_code : %d",rc,rsp_data->qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }

  return rc;
}


/*===========================================================================
  FUNCTION  qmi_dms_get_modem_reset_log
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/

int qmi_dms_get_modem_reset_log
(
  int                                             client_handle,
  qmi_dms_rsp_data_type								 * rsp_data
){
	unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
	unsigned char     *msg_ptr;
	int               msg_size;
	int               rc;
 	int               qmi_err_code;

	/* Prepare the request message */
	msg_ptr = QMI_SRVC_PDU_PTR(msg);
	msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);
	rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_GET_MODEM_RESET_LOG,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &rsp_data->qmi_err_code);

	if (rc == QMI_NO_ERR)
	{	  
		if(msg[0] == QMI_TYPE_REQUIRED_PARAMETERS) 
		{
			memcpy(&rsp_data->rsp_data.modem_reset_log_rsp.reset_log_enable, (void *)(msg+3), 1);//sizeof(dms_modem_reset_log));
			memcpy(&rsp_data->rsp_data.modem_reset_log_rsp.reset_log_normal, (void *)(msg+4), 4);//sizeof(dms_modem_reset_log));
			memcpy(&rsp_data->rsp_data.modem_reset_log_rsp.reset_log_fatal, (void *)(msg+8), 4);//sizeof(dms_modem_reset_log));						
		}     
		else
		rc = QMI_INTERNAL_ERR;
		
	}
    
	return rc;  
}

/*===========================================================================
  FUNCTION  qmi_dms_max_power_control
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
#define QMI_SYNC_MSG_MAX_POWER_TIMEOUT  10
int qmi_dms_max_power_control
(
  int                                             client_handle,
  tof_dms_max_power_type_v01      max_pwr,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [QMI_DMS_MAX_POWER_TLV_SIZE];
  unsigned char     *param_ptr = param_buf;
  int               rc;
  
  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  WRITE_8_BIT_VAL(param_ptr, max_pwr.on_off);
  WRITE_8_BIT_VAL(param_ptr, max_pwr.rat);
  WRITE_32_BIT_VAL(param_ptr, max_pwr.channel_freq);
  WRITE_8_BIT_VAL(param_ptr, max_pwr.tx_power);

  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              QMI_DMS_MAX_POWER_TLV_SIZE,
                              (void *)param_buf) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_MAX_POWER_CONTROL,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_MAX_POWER_TIMEOUT,
                                  &rsp_data->qmi_err_code);
  
  if(rc != QMI_NO_ERR || rsp_data->qmi_err_code != QMI_SERVICE_ERR_NONE)
  {	  
   	MSG_ERROR("[DMS]qmi_dms_max_power_control error!! rc: %d err_code : %d",rc,rsp_data->qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
  	
  return rc;
} /* qmi_dms_max_power_control */


/*===========================================================================
  FUNCTION  qmi_dms_get_alive_monitor_config
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int qmi_dms_get_alive_monitor_config
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_GET_ALIVE_MONITOR,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &rsp_data->qmi_err_code);
  if (rc == QMI_NO_ERR)
  {	  
    if(msg[0] == QMI_TYPE_REQUIRED_PARAMETERS) 
    {
      memcpy(&rsp_data->rsp_data.modem_alive_rsp, (void *)(msg+3), QMI_DMS_ALIVE_MONITOR_TLV_SIZE);
    }
    else
      rc = QMI_INTERNAL_ERR;
  }
    
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_set_alive_monitor_config
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int qmi_dms_set_alive_monitor_config
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [QMI_DMS_ALIVE_MONITOR_TLV_SIZE];
  unsigned long     mask       = 0;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));
  memcpy( (void *)(param_buf), &rsp_data->rsp_data.modem_alive_rsp, QMI_DMS_ALIVE_MONITOR_TLV_SIZE);

  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              QMI_DMS_ALIVE_MONITOR_TLV_SIZE,
                              (void *)param_buf) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_SET_ALIVE_MONITOR,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
								      &rsp_data->qmi_err_code);
  if(rc != QMI_NO_ERR || rsp_data->qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_set_alive_monitor_config!! rc: %d err_code : %d",rc,rsp_data->qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
    
  return rc;
 
}

/*===========================================================================
  FUNCTION  qmi_dms_fs_daig_opendir
===========================================================================*/
int qmi_dms_fs_daig_opendir
(
  int                                          client_handle,
  char                                         *path,
  uint32                                       *dirp,
  int32                                        *diag_errno
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [FS_PATH_MAX + 1];
  unsigned char     *param_ptr = param_buf;
  int               rc;
  int               qmi_err_code;

  if(path == NULL)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  memcpy(param_ptr, path, FS_PATH_MAX + 1);
  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              FS_PATH_MAX + 1,
                              (void *)param_buf) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_FS_DIAG_OPENDIR,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &qmi_err_code);
  
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {	  
   	MSG_ERROR("[DMS]qmi_dms_fs_daig_opendir error!! rc: %d err_code : %d",rc,qmi_err_code,0);
    rc = QMI_INTERNAL_ERR;
  }
  else
  {
    uint8 result;
    unsigned char *value_ptr = (unsigned char *)(msg+3);
    memcpy(&result, value_ptr++, sizeof(uint8));
    memcpy(dirp, value_ptr, sizeof(uint32));
    value_ptr+=sizeof(uint32);
    memcpy(diag_errno, value_ptr, sizeof(int32));
    if(result == FALSE)
    {
      MSG_ERROR("[DMS]qmi_dms_fs_daig_opendir error!! result: %d diag_errno : %d",result,*diag_errno,0);
      rc = QMI_INTERNAL_ERR;
    }
  }
    
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_fs_daig_readdir
===========================================================================*/
int qmi_dms_fs_daig_readdir
(
  int                                         client_handle,
  uint32                                      dirp,
  int32                                       seqno,
  fsdiag_efs2_diag_readdir_rsp_type           *read_dir_rsp
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [sizeof(uint32) + sizeof(int32)];
  unsigned char     *param_ptr = param_buf;
  int               rc;
  int               qmi_err_code;

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  WRITE_32_BIT_VAL(param_ptr, dirp);
  WRITE_32_BIT_VAL(param_ptr, seqno);
  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              sizeof(uint32) + sizeof(int32),
                              (void *)param_buf) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_FS_DIAG_READDIR,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &qmi_err_code);
  
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {	  
   	MSG_ERROR("[DMS]qmi_dms_fs_daig_readdir error!! rc: %d err_code : %d",rc,qmi_err_code,0);
    rc = QMI_INTERNAL_ERR;
  }
  else
  {
    uint8 result;
    unsigned char *value_ptr = (unsigned char *)(msg+3);
    memcpy(&result, value_ptr++, sizeof(uint8));
    memcpy(read_dir_rsp, value_ptr, sizeof(fsdiag_efs2_diag_readdir_rsp_type));
    if(result == FALSE)
    {
      MSG_ERROR("[DMS]qmi_dms_fs_daig_readdir error!! result: %d",result,0,0);
      rc = QMI_INTERNAL_ERR;
    }
  }
    
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_fs_daig_closedir
===========================================================================*/
int qmi_dms_fs_daig_closedir
(
  int                                         client_handle,
  uint32                                      dirp,
  int32                                       *diag_errno
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [sizeof(uint32)];
  unsigned char     *param_ptr = param_buf;
  int               rc;
  int               qmi_err_code;

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  WRITE_32_BIT_VAL(param_ptr, dirp);
  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              sizeof(uint32),
                              (void *)param_buf) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_FS_DIAG_CLOSEDIR,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &qmi_err_code);
  
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {	  
   	MSG_ERROR("[DMS]qmi_dms_fs_daig_closedir error!! rc: %d err_code : %d",rc,qmi_err_code,0);
    rc = QMI_INTERNAL_ERR;
  }
  else
  {
    uint8 result;
    unsigned char *value_ptr = (unsigned char *)(msg+3);
    memcpy(&result, value_ptr++, sizeof(uint8));
    memcpy(diag_errno, value_ptr, sizeof(int32));
    if(result == FALSE)
    {
      MSG_ERROR("[DMS]qmi_dms_fs_daig_closedir error!! result: %d diag_errno: %d",result,*diag_errno,0);
      rc = QMI_INTERNAL_ERR;
    }
  }
    
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_fs_daig_iter
===========================================================================*/
int qmi_dms_fs_daig_iter
(
  int                                         client_handle,
  uint8                                       file_op,
  fsdiag_iter_dirs_req_type                   *iter_req,
  byte                                        *fs_status,
  fsdiag_iter_rsp_type                        *iter_rsp
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [sizeof(uint8) + sizeof(fsdiag_iter_dirs_req_type)];
  unsigned char     *param_ptr = param_buf;
  int               rc;
  int               qmi_err_code;

  if(iter_req == NULL)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  WRITE_8_BIT_VAL(param_ptr, file_op);
  memcpy(param_ptr, iter_req, sizeof(fsdiag_iter_dirs_req_type));
  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              sizeof(uint8) + sizeof(fsdiag_iter_dirs_req_type),
                              (void *)param_buf) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_FS_DIAG_ITER,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &qmi_err_code);
  
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {	  
   	MSG_ERROR("[DMS]qmi_dms_fs_daig_iter error!! rc: %d err_code : %d",rc,qmi_err_code,0);
    rc = QMI_INTERNAL_ERR;
  }
  else
  {
    uint8 result;
    unsigned char *value_ptr = (unsigned char *)(msg+3);
    memcpy(&result, value_ptr++, sizeof(uint8));
    memcpy(fs_status, value_ptr++, sizeof(byte));
    if(result == FALSE)
    {
      MSG_ERROR("[DMS]qmi_dms_fs_daig_iter error!! result: %d fs_status: %d",result,*fs_status,0);
      rc = QMI_INTERNAL_ERR;
    }

    memcpy(iter_rsp, value_ptr, sizeof(fsdiag_iter_rsp_type));
  }
    
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_fs_daig_read
===========================================================================*/
int qmi_dms_fs_daig_read
(
  int                                         client_handle,
  fsdiag_read_req_type                        *read_req,
  byte                                        *fs_status,
  fsdiag_read_rsp_type                        *read_rsp
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [sizeof(fsdiag_read_req_type)];
  unsigned char     *param_ptr = param_buf;
  int               rc;
  int               qmi_err_code;

  if(read_req == NULL)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  memcpy(param_ptr, read_req, sizeof(fsdiag_read_req_type));
  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              sizeof(fsdiag_read_req_type),
                              (void *)param_buf) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_FS_DIAG_READ,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &qmi_err_code);
  
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {	  
   	MSG_ERROR("[DMS]qmi_dms_fs_daig_read error!! rc: %d err_code : %d",rc,qmi_err_code,0);
    rc = QMI_INTERNAL_ERR;
  }
  else
  {
    uint8 result;
    unsigned char *value_ptr = (unsigned char *)(msg+3);
    memcpy(&result, value_ptr++, sizeof(uint8));
    memcpy(fs_status, value_ptr++, sizeof(byte));
    if(result == FALSE)
    {
      MSG_ERROR("[DMS]qmi_dms_fs_daig_read error!! result: %d fs_status: %d",result,*fs_status,0);
      rc = QMI_INTERNAL_ERR;
    }

    memcpy(read_rsp, value_ptr, sizeof(fsdiag_read_rsp_type));
  }
    
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_fs_daig_delete
===========================================================================*/
int qmi_dms_fs_daig_delete
(
  int                                         client_handle,
  fsdiag_rmfile_req_type                      *delete_req,
  byte                                        *fs_status
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [sizeof(fsdiag_rmfile_req_type)];
  unsigned char     *param_ptr = param_buf;
  int               rc;
  int               qmi_err_code;

  if(delete_req == NULL)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  memcpy(param_ptr, delete_req, sizeof(fsdiag_rmfile_req_type));
  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              sizeof(fsdiag_rmfile_req_type),
                              (void *)param_buf) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_FS_DIAG_DELETE,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &qmi_err_code);
  
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {	  
   	MSG_ERROR("[DMS]qmi_dms_fs_daig_delete error!! rc: %d err_code : %d",rc,qmi_err_code,0);
    rc = QMI_INTERNAL_ERR;
  }
  else
  {
    uint8 result;
    unsigned char *value_ptr = (unsigned char *)(msg+3);
    memcpy(&result, value_ptr++, sizeof(uint8));
    memcpy(fs_status, value_ptr++, sizeof(byte));
    if(result == FALSE)
    {
      MSG_ERROR("[DMS]qmi_dms_fs_daig_delete error!! result: %d fs_status: %d",result,*fs_status,0);
      rc = QMI_INTERNAL_ERR;
    }
  }
    
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_fs_daig_write
===========================================================================*/
int qmi_dms_fs_daig_write
(
  int                                         client_handle,
  fsdiag_write_req_type                       *write_req,
  byte                                        *fs_status
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [sizeof(fsdiag_write_req_type)];
  unsigned char     *param_ptr = param_buf;
  int               rc;
  int               qmi_err_code;

  if(write_req == NULL)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  memcpy(param_ptr, write_req, sizeof(fsdiag_write_req_type));
  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              sizeof(fsdiag_write_req_type),
                              (void *)param_buf) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_FS_DIAG_WRITE,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &qmi_err_code);
  
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {	  
   	MSG_ERROR("[DMS]qmi_dms_fs_daig_write error!! rc: %d err_code : %d",rc,qmi_err_code,0);
    rc = QMI_INTERNAL_ERR;
  }
  else
  {
    uint8 result;
    unsigned char *value_ptr = (unsigned char *)(msg+3);
    memcpy(&result, value_ptr++, sizeof(uint8));
    memcpy(fs_status, value_ptr++, sizeof(byte));
    if(result == FALSE)
    {
      MSG_ERROR("[DMS]qmi_dms_fs_daig_write error!! result: %d fs_status: %d",result,*fs_status,0);
      rc = QMI_INTERNAL_ERR;
    }
  }
    
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_fs_daig_rmdir
===========================================================================*/
int qmi_dms_fs_daig_rmdir
(
  int                                         client_handle,
  fsdiag_rmdir_req_type                       *rmdir_req,
  byte                                        *fs_status
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [sizeof(fsdiag_rmdir_req_type)];
  unsigned char     *param_ptr = param_buf;
  int               rc;
  int               qmi_err_code;

  if(rmdir_req == NULL)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  memcpy(param_ptr, rmdir_req, sizeof(fsdiag_rmdir_req_type));
  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              sizeof(fsdiag_rmdir_req_type),
                              (void *)param_buf) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_FS_DIAG_RMDIR,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &qmi_err_code);
  
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {	  
   	MSG_ERROR("[DMS]qmi_dms_fs_daig_rmdir error!! rc: %d err_code : %d",rc,qmi_err_code,0);
    rc = QMI_INTERNAL_ERR;
  }
  else
  {
    uint8 result;
    unsigned char *value_ptr = (unsigned char *)(msg+3);
    memcpy(&result, value_ptr++, sizeof(uint8));
    memcpy(fs_status, value_ptr++, sizeof(byte));
    if(result == FALSE)
    {
      MSG_ERROR("[DMS]qmi_dms_fs_daig_rmdir error!! result: %d fs_status: %d",result,*fs_status,0);
      rc = QMI_INTERNAL_ERR;
    }
  }
    
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_fs_daig_mkdir
===========================================================================*/
int qmi_dms_fs_daig_mkdir
(
  int                                         client_handle,
  fsdiag_mkdir_req_type                       *mkdir_req,
  byte                                        *fs_status
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [sizeof(fsdiag_mkdir_req_type)];
  unsigned char     *param_ptr = param_buf;
  int               rc;
  int               qmi_err_code;

  if(mkdir_req == NULL)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  memcpy(param_ptr, mkdir_req, sizeof(fsdiag_mkdir_req_type));
  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              sizeof(fsdiag_mkdir_req_type),
                              (void *)param_buf) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_FS_DIAG_MKDIR,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &qmi_err_code);
  
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {	  
   	MSG_ERROR("[DMS]qmi_dms_fs_daig_mkdir error!! rc: %d err_code : %d",rc,qmi_err_code,0);
    rc = QMI_INTERNAL_ERR;
  }
  else
  {
    uint8 result;
    unsigned char *value_ptr = (unsigned char *)(msg+3);
    memcpy(&result, value_ptr++, sizeof(uint8));
    memcpy(fs_status, value_ptr++, sizeof(byte));
    if(result == FALSE)
    {
      MSG_ERROR("[DMS]qmi_dms_fs_daig_mkdir error!! result: %d fs_status: %d",result,*fs_status,0);
      rc = QMI_INTERNAL_ERR;
    }
  }
    
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_get_gpio
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int qmi_dms_get_gpio
(
  int                                             client_handle,
  uint8                                         gpio_type,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [QMI_DMS_EVENT_REG_MAX_TLV_SIZE];
  unsigned char     *param_ptr = param_buf;
  unsigned long     mask       = 0;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  WRITE_8_BIT_VAL(param_ptr, gpio_type);

  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              QMI_DMS_VENDOR_TLV_SIZE,
                              (void *)param_buf) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_GET_MODEM_GPIO_VALUE,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &rsp_data->qmi_err_code);
  if (rc == QMI_NO_ERR)
  {
    unsigned char *tmp_msg_buf = (unsigned char *)msg;
    unsigned long                          type;
    unsigned long                          length;
    unsigned char                        * value_ptr;
    
    /* get mandatory field */
    if (qmi_util_read_std_tlv (&tmp_msg_buf,
                             &msg_size,
                             &type,
                             &length,
                             &value_ptr) < 0)
    {
      rc = QMI_INTERNAL_ERR;
    }
    else   
    {
      if((unsigned char)type == QMI_TYPE_REQUIRED_PARAMETERS) //means vendor
        rsp_data->rsp_data.gpio_rsp.gpio_value = * value_ptr;
      else
        rc = QMI_INTERNAL_ERR;
    }
  }
    
  return rc;
} /* qmi_dms_get_gpio */

/*===========================================================================
  FUNCTION  qmi_dms_set_gpio
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int qmi_dms_set_gpio
(
  int                                             client_handle,
  byte                                          gpio_type,
  byte                                          gpio_value,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [QMI_DMS_ALIVE_MONITOR_TLV_SIZE];
  unsigned char     *param_ptr = param_buf;
  unsigned long     mask       = 0;
  int               rc;
  uint16 gpio_mix = 0;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  gpio_mix = gpio_type | (gpio_value << 8); //value is upper byte, type is lower byte
  WRITE_16_BIT_VAL(param_ptr, gpio_mix);

  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              QMI_DMS_ALIVE_MONITOR_TLV_SIZE,
                              (void *)param_buf) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_SET_MODEM_GPIO_VALUE,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
								      &rsp_data->qmi_err_code);
  if(rc != QMI_NO_ERR || rsp_data->qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_set_vendor!! rc: %d err_code : %d",rc,rsp_data->qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
    
  return rc;
} /* qmi_dms_set_gpio */

//ygpark.20141201 +
#if defined(FEATURE_LGIT_OTADM_FOTA_FUMO_VZW)
/*===========================================================================
  FUNCTION  request_fota_download_done_received
===========================================================================*/
EXTERN int request_fota_download_done_received
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
	unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
	unsigned char     *msg_ptr;
	int               msg_size;
	unsigned char     param_buf [QMI_DMS_EVENT_REG_MAX_TLV_SIZE];
	unsigned char     *param_ptr = param_buf;
	unsigned long     mask       = 0;
	int               rc;

	if(!rsp_data)
	{
		return QMI_SERVICE_ERR;
	}

	/* Prepare the request message */
	msg_ptr = QMI_SRVC_PDU_PTR(msg);
	msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

	memset (param_buf, 0, sizeof(param_buf));

	/* Prepare the TLV */
	//MSISDN req message don't need TLV field

	rc = qmi_service_send_msg_sync (client_handle,
								  QMI_DMS_SERVICE,
								  QMI_DMSI_CMD_VAL_FS_OTADM_FOTA_DOWNLOAD_DONE_RECEIVED_REQ_V01,
								  QMI_SRVC_PDU_PTR(msg),
								  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
								  msg,                 
								  &msg_size,
								  QMI_DMS_STD_MSG_SIZE,
								  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
								  &rsp_data->qmi_err_code);
	if (rc == QMI_NO_ERR)
	{
		QMI_ERR_MSG_0 ("qmi_dms_handle_fota_download_done_received_rsp: returned error");		
	}

	return rc;
}

/*===========================================================================
  FUNCTION  request_fota_install
===========================================================================*/
EXTERN int request_fota_install
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
	unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
	unsigned char     *msg_ptr;
	int               msg_size;
	unsigned char     param_buf [QMI_DMS_EVENT_REG_MAX_TLV_SIZE];
	unsigned char     *param_ptr = param_buf;
	unsigned long     mask       = 0;
	int               rc;

	if(!rsp_data)
	{
		return QMI_SERVICE_ERR;
	}

	/* Prepare the request message */
	msg_ptr = QMI_SRVC_PDU_PTR(msg);
	msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

	memset (param_buf, 0, sizeof(param_buf));

	/* Prepare the TLV */
	//MSISDN req message don't need TLV field

	rc = qmi_service_send_msg_sync (client_handle,
								  QMI_DMS_SERVICE,
								  QMI_DMSI_CMD_VAL_FS_OTADM_FOTA_INSTALL_REQ_V01,
								  QMI_SRVC_PDU_PTR(msg),
								  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
								  msg,                 
								  &msg_size,
								  QMI_DMS_STD_MSG_SIZE,
								  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
								  &rsp_data->qmi_err_code);
	if (rc != QMI_NO_ERR)
	{
		QMI_ERR_MSG_0 ("qmi_dms_handle_fota_install_rsp: returned error");		
	}

	return rc;
}


/*===========================================================================
  FUNCTION  request_fota_user_cancel
===========================================================================*/
EXTERN int request_fota_user_cancel
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
	unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
	unsigned char     *msg_ptr;
	int               msg_size;
	unsigned char     param_buf [QMI_DMS_EVENT_REG_MAX_TLV_SIZE];
	unsigned char     *param_ptr = param_buf;
	unsigned long     mask       = 0;
	int               rc;

	if(!rsp_data)
	{
		return QMI_SERVICE_ERR;
	}

	/* Prepare the request message */
	msg_ptr = QMI_SRVC_PDU_PTR(msg);
	msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

	memset (param_buf, 0, sizeof(param_buf));

	/* Prepare the TLV */
	//MSISDN req message don't need TLV field

	rc = qmi_service_send_msg_sync (client_handle,
								  QMI_DMS_SERVICE,
								  QMI_DMSI_CMD_VAL_FS_OTADM_FOTA_USER_CANCEL_REQ_V01,
								  QMI_SRVC_PDU_PTR(msg),
								  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
								  msg,                 
								  &msg_size,
								  QMI_DMS_STD_MSG_SIZE,
								  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
								  &rsp_data->qmi_err_code);
	if (rc != QMI_NO_ERR)
	{
		QMI_ERR_MSG_0 ("qmi_dms_handle_fota_user_cancel_rsp: returned error");		
	}

	return rc;
}

/*===========================================================================
  FUNCTION  request_fota_bl_install
===========================================================================*/
EXTERN int request_fota_bl_install
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
	unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
	unsigned char     *msg_ptr;
	int               msg_size;
	unsigned char     param_buf [QMI_DMS_EVENT_REG_MAX_TLV_SIZE];
	unsigned char     *param_ptr = param_buf;
	unsigned long     mask       = 0;
	int               rc;

	if(!rsp_data)
	{
		return QMI_SERVICE_ERR;
	}

	/* Prepare the request message */
	msg_ptr = QMI_SRVC_PDU_PTR(msg);
	msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

	memset (param_buf, 0, sizeof(param_buf));

	/* Prepare the TLV */
	//MSISDN req message don't need TLV field

	rc = qmi_service_send_msg_sync (client_handle,
								  QMI_DMS_SERVICE,
								  QMI_DMSI_CMD_VAL_FS_OTADM_FOTA_BL_INSTALL_REQ_V01,
								  QMI_SRVC_PDU_PTR(msg),
								  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
								  msg,                 
								  &msg_size,
								  QMI_DMS_STD_MSG_SIZE,
								  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
								  &rsp_data->qmi_err_code);
	if (rc != QMI_NO_ERR)
	{
		QMI_ERR_MSG_0 ("request_fota_bl_install: returned error");		
	}

	return rc;
}

#endif
//ygpark.20141201 -
/*===========================================================================
  FUNCTION  qmi_dms_set_time
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int qmi_dms_set_time
(
  int                                               client_handle,
  const dms_set_time_req_msg_v01    * params,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [12];
  unsigned char     *param_ptr = param_buf;
  int               rc;

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  WRITE_64_BIT_VAL(param_ptr, params->time_in_ms);

  if (qmi_util_write_std_tlv (&msg_ptr,
                              &msg_size,
                              QMI_TYPE_REQUIRED_PARAMETERS,
                              8,//time_in_ms is uint64
                              (void *)param_buf) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  if(params->time_reference_type_valid)
  {
    /* Prepare the TLV */
    WRITE_32_BIT_VAL(param_ptr, params->time_reference_type);

    if (qmi_util_write_std_tlv (&msg_ptr,
                                &msg_size,
                                0x10, //Optional TVL 1
                                4,//time_in_ms is uint32
                                (void *)(param_buf+8)) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }
  else
    return RESULT_FAILURE;

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_SET_TIME_RESP_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
								      &rsp_data->qmi_err_code);
  if(rc != QMI_NO_ERR || rsp_data->qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_set_time!! rc: %d err_code : %d",rc,rsp_data->qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
    
  return rc;
} /* qmi_dms_set_time */

static int qmi_gpio_usb_status_info
(
  unsigned char                                   *rx_msg,
  int                                             rx_msg_size,
  dms_usb_status_ind_msg_v01 *t_usb_status_ind
)
{
  unsigned long                          type;
  unsigned long                          length;
  unsigned char                        * value_ptr;

  /* Clear response buffer */
  memset((char *)&t_usb_status_ind->usb_status, 0x0 ,sizeof(dms_usb_status_ind_msg_v01));
  
  if (qmi_util_read_std_tlv (&rx_msg,
                           &rx_msg_size,
                           &type,
                           &length,
                           &value_ptr) < 0)
  {
    return QMI_INTERNAL_ERR;
  }
  else
  {  	
    t_usb_status_ind->usb_status = *value_ptr;		
  }
	
  return QMI_NO_ERR;

}

/*===========================================================================
  FUNCTION  qmi_dms_get_exception_count
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int qmi_dms_get_exception_count
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [QMI_DMS_EVENT_REG_MAX_TLV_SIZE];
  unsigned char     *param_ptr = param_buf;
  unsigned long     mask       = 0;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset (param_buf, 0, sizeof(param_buf));

  /* Prepare the TLV */
  //MSISDN req message don't need TLV field

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_DMS_SERVICE,
                                  QMI_DMS_GET_MODEM_EXCEPTION_COUNT_REQ_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_DMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  &rsp_data->qmi_err_code);
  
  if (rc == QMI_NO_ERR)
  {
    unsigned char *tmp_msg_buf = (unsigned char *)msg;
    unsigned long                          type;
    unsigned long                          length;
    unsigned char                        * value_ptr;
    
    /* First get ICCID mandatory field */
    if (qmi_util_read_std_tlv (&tmp_msg_buf,
                             &msg_size,
                             &type,
                             &length,
                             &value_ptr) < 0)
    {
      rc = QMI_INTERNAL_ERR;
    }
    else   
    {
      if((unsigned char)type == QMI_TYPE_REQUIRED_PARAMETERS)
        rsp_data->rsp_data.exception_count = *value_ptr;
      else
        rc = QMI_INTERNAL_ERR;
    }
  }
    
  return rc;
} /* qmi_dms_get_vendor */

/*===========================================================================
  FUNCTION  qmi_dms_get_exception_info
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int qmi_dms_get_exception_info
(
  int                                             client_handle,
  uint8                                          except_index,
  qmi_dms_rsp_data_type             * rsp_data
)
{
  unsigned char     msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char     *msg_ptr;
  int               msg_size;
  unsigned char     param_buf [QMI_DMS_EVENT_REG_MAX_TLV_SIZE];
  unsigned char     *param_ptr = param_buf;
  int               rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  MSG_ERROR("[DMS]qmi_dms_get_exception_info!",0,0,0);

 /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);
  memset (param_buf, 0, sizeof(param_buf));

    /* Prepare the TLV */
  WRITE_8_BIT_VAL(param_ptr, except_index);
  
  if (qmi_util_write_std_tlv (&msg_ptr,
                            &msg_size,
                            QMI_TYPE_REQUIRED_PARAMETERS,
                            sizeof(except_index),
                            (void *)param_buf) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                QMI_DMS_SERVICE,
                                QMI_DMS_GET_MODEM_EXCEPTION_INFO_REQ_V01,
                                QMI_SRVC_PDU_PTR(msg),
                                (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                msg,                 
                                &msg_size,
                                QMI_DMS_STD_MSG_SIZE,
                                QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                &rsp_data->qmi_err_code);

  if(rc != QMI_NO_ERR || rsp_data->qmi_err_code != QMI_SERVICE_ERR_NONE)
  {	  
  	MSG_ERROR("[DMS]qmi_dms_get_exception_info error!! rc: %d err_code : %d",rc,rsp_data->qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    if(msg[0] == QMI_TYPE_REQUIRED_PARAMETERS)
    {
      memcpy(&rsp_data->rsp_data.modem_exception_info_rsp, (void *)(msg+3), sizeof(dms_modem_exception_info_type_v01));

      #if 0
        printf("msg[00]=%x %x %x\n", msg[0], msg[1], msg[2]);
        printf("msg[03]=%x %x %x\n", msg[3], msg[4], msg[5]);                               // modem_sw_version
        printf("msg[23]=%x %x %x\n", msg[23], msg[24], msg[25]);                          // date
        printf("msg[38]=%x %x %x\n", msg[38], msg[39], msg[40]);                          // time
        printf("msg[48]=%x %x %x %x\n", msg[48], msg[49], msg[50], msg[51]);      // line
        printf("msg[52]=%x %x %x\n", msg[52], msg[53], msg[54]);                          // file
        printf("msg[102]=%x %x %x\n", msg[102], msg[103], msg[104]);                   // msg

        printf("[qmi_dms_get_exception_info data] ==============\n");
        printf("%s\n", rsp_data->rsp_data.modem_exception_info_rsp.modem_sw_version);
        printf("%s\n", rsp_data->rsp_data.modem_exception_info_rsp.exception_date);
        printf("%s\n", rsp_data->rsp_data.modem_exception_info_rsp.exception_time);
        printf("%d\n", rsp_data->rsp_data.modem_exception_info_rsp.exception_line);
        printf("%s\n", rsp_data->rsp_data.modem_exception_info_rsp.exception_file);
        printf("%s\n", rsp_data->rsp_data.modem_exception_info_rsp.exception_msg);
        printf("=========================\n");
      #endif
    }
    else
      rc = QMI_INTERNAL_ERR;
  }
  
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_dms_delete_exception_info
===========================================================================*/
/*!
@brief 
  
@return 
  
@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int qmi_dms_delete_exception_info
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
)
{
  unsigned char msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char *msg_ptr;
  int msg_size;
  int rc;

  if(!rsp_data)
  {
    return QMI_SERVICE_ERR;
  }

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                                      QMI_DMS_SERVICE,
                                                      QMI_DMS_DEL_MODEM_EXCEPTION_INFO_REQ_V01,
                                                      QMI_SRVC_PDU_PTR(msg),
                                                      (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                                      msg,
                                                      &msg_size,
                                                      QMI_DMS_STD_MSG_SIZE,
                                                      QMI_SYNC_MSG_DELETE_EXCEPTION_INFO_TIMEOUT,
                                                      &rsp_data->qmi_err_code);

  if(/*rc != QMI_NO_ERR ||*/rsp_data->qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_delete_exception_info error!! rc: %d err_code : %d",rc,rsp_data->qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }

  return rc;
}
