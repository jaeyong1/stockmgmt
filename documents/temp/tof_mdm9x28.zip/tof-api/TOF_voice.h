/******************************************************************************
	FILE:
		 TOF_voice.h
	
	DESCRIPTION:
		Define Function,Structure,variable to help the voice call function in Used only TOF layer.

  ---------------------------------------------------------------------------
  Copyright (c) 2016 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/
#include "TOF_Definition.h"
#include "TOF_log.h"

/*=========================================================================*/
// Struct
/*=========================================================================*/
	
typedef struct
{
	TOF_Call TOF_call[ 32 ];
	int TOF_call_info_len;
} voice_all_TOF_call_info_s;

/*=========================================================================*/
// Definitions
/*=========================================================================*/
voice_all_TOF_call_info_s		g_voice_all_TOF_call_info;	


/*=========================================================================*/
// Generic functions
/*=========================================================================*/
void	update_g_voice_all_TOF_call_info( TOF_Current_Call_Info* TOF_call, int TOF_call_info_len );
const char* getCallStateString( int state );

