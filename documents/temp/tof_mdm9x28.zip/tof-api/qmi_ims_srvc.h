#ifndef QMI_IMS_SRVC_H
#define QMI_IMS_SRVC_H

/******************************************************************************
  @file    qmi_ims_srvc.h
  @brief   QMI message library IMS service definitions

  DESCRIPTION
  This file contains common, external header file definitions for QMI
  interface library.

  INITIALIZATION AND SEQUENCING REQUIREMENTS
  qmi_ims_srvc_init_client() must be called to create one or more clients
  qmi_ims_srvc_release_client() must be called to delete each client when
  finished.

  $Header: //source/qcom/qct/modem/datacommon/qmimsglib/dev/work/inc/qmi_ims_srvc.h#5 $
  $DateTime: 2009/07/15 10:38:12 $
  ---------------------------------------------------------------------------
  Copyright (c) 2013 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/

#include "qmi.h"
#include "wmmdiag_packet.h"


#ifdef __cplusplus
extern "C" {
#endif

#define IMS_SETTINGS_STRING_LEN_MAX_V01 255

typedef enum
{
  REQUEST_PCSCF_PORT          = 0,
  REQUEST_PCSCF_DOMAIN        = 1,
  REQUEST_IMS_TEST_MODE       = 2
} ims_reg_request_type;

typedef enum
{
    REQUEST_DOMAIN_NAME             = 0
} ims_user_request_type;

typedef enum
{
  REQUEST_LOCAL_PORT             = 0,
  REQUEST_REG_TIMER               = 1,
  REQUEST_SUBSCRIBE_TIMER   = 2,
  REQUEST_TIMER_T1   = 3,
  REQUEST_TIMER_T2   = 4,
  REQUEST_TIMER_F    = 5
} ims_sip_request_type;

/* Custom named TLV IDs*/

/** @addtogroup imss_qmi_enums
    @{
  */
typedef enum {
  IMS_SETTINGS_RSP_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  IMS_SETTINGS_MSG_NO_ERR_V01 = 0, 
  IMS_SETTINGS_MSG_IMS_NOT_READY_V01 = 1, 
  IMS_SETTINGS_MSG_FILE_NOT_AVAILABLE_V01 = 2, 
  IMS_SETTINGS_MSG_READ_FAILED_V01 = 3, 
  IMS_SETTINGS_MSG_WRITE_FAILED_V01 = 4, 
  IMS_SETTINGS_MSG_OTHER_INTERNAL_ERR_V01 = 5, 
  IMS_SETTINGS_RSP_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}ims_settings_rsp_enum_v01;
/**
    @}
  */

/*---------------------------------------------------------------------------
 QMI_NAS_SET_IMS_SIP_INFO
---------------------------------------------------------------------------*/
#define IMS_0020_REQ_T10        (0x10)
#define IMS_0020_REQ_T11        (0x11)
#define IMS_0020_REQ_T12        (0x12)
#define IMS_0020_REQ_T13        (0x13)
#define IMS_0020_REQ_T14        (0x14)
#define IMS_0020_REQ_T15        (0x15)

typedef struct {
	struct ims_0020_req_t10_s {
	  uint16 sip_local_port; 
	} t10;

	struct ims_0020_req_t11_s {
	  uint32 timer_sip_reg;
	} t11;

	struct ims_0020_req_t12_s {
	  uint32 subscribe_timer;
	} t12; 

	struct ims_0020_req_t13_s {
	  uint32 timer_t1;
	} t13;

	struct ims_0020_req_t14_s {
	  uint32 timer_t2;
	} t14; 

	struct ims_0020_req_t15_s {
	  uint32 timer_f;
	} t15; 

	boolean t10_valid;
	boolean t11_valid;
	boolean t12_valid;
	boolean t13_valid;
	boolean t14_valid;
	boolean t15_valid;
}ims_0020_req_s;

/*---------------------------------------------------------------------------
 QMI_NAS_SET_IMS_REG_INFO
---------------------------------------------------------------------------*/
#define IMS_0021_REQ_T10        (0x10)
#define IMS_0021_REQ_T11        (0x11)
#define IMS_0021_REQ_T12        (0x12)

typedef struct {
  struct ims_0021_req_t10_s {
    uint16 pcscf_port; 
  } t10;
  struct ims_0021_req_t11_s {
    char pcscf_domain[IMS_SETTINGS_STRING_LEN_MAX_V01 + 1];
  } t11;
  struct ims_0021_req_t12_s {
    boolean ims_test_mode;
  } t12;
  
  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
}ims_0021_req_s;

/*---------------------------------------------------------------------------
 QMI_NAS_SET_IMS_USER_INFO
---------------------------------------------------------------------------*/
#define IMS_0023_REQ_T10        (0x10)

typedef struct {
  struct ims_0023_req_t10_s {
    char domain_name[IMS_SETTINGS_STRING_LEN_MAX_V01 + 1];
  } t10;

  boolean t10_valid;
}ims_0023_req_s;

/*---------------------------------------------------------------------------
 QMI_NAS_SET_IMS_VOIP_INFO
---------------------------------------------------------------------------*/
#define IMS_0024_REQ_T10        (0x10)
#define IMS_0024_REQ_T11        (0x11)
#define IMS_0024_REQ_T12        (0x12)
#define IMS_0024_REQ_T15        (0x15)
#define IMS_0024_REQ_T16        (0x16)
#define IMS_0024_REQ_T17        (0x17)
#define IMS_0024_REQ_T18        (0x18)

typedef struct {
  struct ims_0024_req_t10_s {
    uint16 session_expiry_timer; 
  } t10;
  
  struct ims_0024_req_t11_s {
    uint16 min_session_expiry;
  } t11;

  struct ims_0024_req_t12_s {
    boolean amr_wb_enable; 
  } t12;  

  struct ims_0024_req_t15_s {
    uint8 amr_mode; 
  } t15;
  
  struct ims_0024_req_t16_s {
    uint16 amr_wb_mode;
  } t16;  

  struct ims_0024_req_t17_s {
    boolean amr_octet_align; 
  } t17;
  
  struct ims_0024_req_t18_s {
    boolean amr_wb_octet_align;
  } t18;  

  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;  
  boolean t15_valid;
  boolean t16_valid;  
  boolean t17_valid;
  boolean t18_valid;
}ims_0024_req_s;


/*---------------------------------------------------------------------------
 QMI_NAS_GET_IMS_SIP_INFO
---------------------------------------------------------------------------*/
#define IMS_0025_RSP_T10        (0x10)
#define IMS_0025_RSP_T11        (0x11)
#define IMS_0025_RSP_T12        (0x12)
#define IMS_0025_RSP_T13        (0x13)
#define IMS_0025_RSP_T14        (0x14)
#define IMS_0025_RSP_T15        (0x15)
#define IMS_0025_RSP_T16        (0x16)

typedef struct {
	struct ims_0025_rsp_t11_s
	{
	  uint16 sip_local_port;
	} t11;

	struct ims_0025_rsp_t12_s
	{
	  uint32 timer_sip_reg;
	} t12;

	struct ims_0025_rsp_t13_s
	{
	  uint32 subscribe_timer;
	} t13;

	struct ims_0025_rsp_t14_s
	{
	  uint32 timer_t1;
	} t14;

	struct ims_0025_rsp_t15_s
	{
	  uint32 timer_t2;
	} t15;

	struct ims_0025_rsp_t16_s
	{
	  uint32 timer_f;
	} t16;
	

	boolean t11_valid;
	boolean t12_valid;
	boolean t13_valid;
	boolean t14_valid;
	boolean t15_valid;
	boolean t16_valid;
}ims_0025_rsp_s;

/*---------------------------------------------------------------------------
 QMI_NAS_GET_IMS_REG_INFO
---------------------------------------------------------------------------*/
#define IMS_0026_RSP_T10        (0x10)
#define IMS_0026_RSP_T11        (0x11)
#define IMS_0026_RSP_T12        (0x12)
#define IMS_0026_RSP_T13        (0x13)

typedef struct {
  struct ims_0026_rsp_t11_s
  {
    uint16 pcscf_port;
  } t11;

  struct ims_0026_rsp_t12_s
  {
    char pcscf_domain[IMS_SETTINGS_STRING_LEN_MAX_V01 + 1];
  } t12;

  struct ims_0026_rsp_t13_s
  {
    boolean ims_test_mode;
  } t13;
  
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
}ims_0026_rsp_s;

/*---------------------------------------------------------------------------
 QMI_NAS_GET_IMS_USER_INFO
---------------------------------------------------------------------------*/
#define IMS_0028_RSP_T10        (0x10)
#define IMS_0028_RSP_T11        (0x11)
#define IMS_0028_RSP_T12        (0x12)

typedef struct {
  struct ims_0028_rsp_t11_s
  {
    char domain_name[IMS_SETTINGS_STRING_LEN_MAX_V01 + 1];
  } t11;

  boolean t11_valid;
}ims_0028_rsp_s;

/*---------------------------------------------------------------------------
 QMI_NAS_GET_IMS_VOIP_INFO
---------------------------------------------------------------------------*/
#define IMS_0029_RSP_T10        (0x10)
#define IMS_0029_RSP_T11        (0x11)
#define IMS_0029_RSP_T12        (0x12)
#define IMS_0029_RSP_T13        (0x13)
#define IMS_0029_RSP_T16        (0x16)
#define IMS_0029_RSP_T17        (0x17)
#define IMS_0029_RSP_T18        (0x18)
#define IMS_0029_RSP_T19        (0x19)

typedef struct {
  struct ims_0029_rsp_t11_s
  {
    uint16 session_expiry_timer;
  } t11;

  struct ims_0029_rsp_t12_s
  {
    uint16 min_session_expiry;
  } t12;

  struct ims_0029_rsp_t13_s
  {
    boolean amr_wb_enable;
  } t13;  

  struct ims_0029_rsp_t16_s
  {
    uint8 amr_mode;
  } t16;

  struct ims_0029_rsp_t17_s
  {
    uint16 amr_wb_mode;
  } t17;  

  struct ims_0029_rsp_t18_s
  {
    boolean amr_octet_align;
  } t18;

  struct ims_0029_rsp_t19_s
  {
    boolean amr_wb_octet_align;
  } t19;  

  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
  boolean t16_valid;
  boolean t17_valid;  
  boolean t18_valid;
  boolean t19_valid;
}ims_0029_rsp_s;

/*---------------------------------------------------------------------------
  QMI_IMS_SETTING_CONFIG_IND_REG
---------------------------------------------------------------------------*/
#define IMS_002A_REQ_T10      (0x10)
#define IMS_002A_REQ_T17      (0x17)

typedef struct {
  struct ims_002A_req_t10_s {
    uint8 sip_config;
  } t10;
  
  struct ims_002A_req_t11_s {
    uint8 qipcall_config;
  } t17;

  boolean t10_valid;
  boolean t17_valid;
}ims_002A_req_s;

/*---------------------------------------------------------------------------
 QMI_NAS_SET_IMS_QIPCALL_INFO
---------------------------------------------------------------------------*/
#define IMS_0036_REQ_T12        (0x12)

typedef struct {
  struct ims_0036_req_t12_s {
    boolean volte_enabled; 
  } t12;  

  boolean t12_valid;  
}ims_0036_req_s;

/*---------------------------------------------------------------------------
 QMI_NAS_GET_IMS_QIPCALL_INFO
---------------------------------------------------------------------------*/
#define IMS_0037_RSP_T13        (0x13)

typedef struct {
  struct ims_0037_rsp_t13_s
  {
    boolean volte_enabled;
  } t13;  

  boolean t13_valid;
}ims_0037_rsp_s;

/*---------------------------------------------------------------------------
  QMI_IMS_SETTING_QIPCALL_CONFIG_IND
---------------------------------------------------------------------------*/

#define IMS_0038_IND_T10                      0x10
#define IMS_0038_IND_T12                      0x12

typedef struct {
  struct ims_0038_ind_t10_s {
    uint8 vt_calling_enabled;
  } t10;
  
  struct ims_0038_ind_t12_s {
    uint8 volte_enabled;
  } t12;
  
  boolean t10_valid;
  boolean t12_valid;
}ims_0038_ind_s;

/* Distinguishes indication message types */

typedef enum
{
   QMI_IMS_SRVC_INVALID_IND_MSG,
   QMI_IMS_SRVC_SETTINGS_REG_MGR_CONFIG_IND,
   QMI_IMS_SRVC_SETTINGS_QIPCALL_CONFIG_IND	 	
  /* To be filled in in future release */
} qmi_ims_indication_id_type;

/* Async notification reporting structure */
typedef union
{
  ims_0038_ind_s ims_0038_ind;
} qmi_ims_indication_data_type;


typedef void (*qmi_ims_indication_hdlr_type)
( 
  int                           user_handle,
  qmi_service_id_type           service_id,
  void                          *user_data,
  qmi_ims_indication_id_type    ind_id,
  qmi_ims_indication_data_type  *ind_data
);

EXTERN HANDLE qmi_ims_srvc_init_client
(
  const char                    *dev_id,
  qmi_ims_indication_hdlr_type  user_ind_msg_hdlr,
  void                          *user_ind_msg_hdlr_user_data,
  int                           *qmi_err_code
);

EXTERN int 
qmi_ims_srvc_release_client
(
  qmi_client_handle_type  client_handle,
  int                     *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_imsa_indication_register
===========================================================================*/
/*!
@brief 
  Set the IMSA indication registration state for specified control point.
     
  
@return 

@note

  - Dependencies
    - qmi_imsa_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_ims_indication_register
(
  int                                     client_handle,
  ims_002A_req_s                  *ims_002A_req,
  int                                    *qmi_err_code
);

EXTERN int
qmi_ims_get_ims_reg_info
(
  int                               client_handle,
  ims_0026_rsp_s             *ims_0026_rsp, 
  int                               *qmi_err_code
);

EXTERN int
qmi_ims_set_ims_reg_info
(
  int                               client_handle,
  ims_0021_req_s             *ims_0021_req,
  int                               *qmi_err_code
);

EXTERN int
qmi_ims_get_ims_reg
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  ims_0026_rsp_s            *ims_0026_rsp
);

EXTERN int
qmi_ims_get_ims_user_info
(
  int                               client_handle,
  ims_0028_rsp_s             *ims_0028_rsp, 
  int                               *qmi_err_code
);

EXTERN int
qmi_ims_get_ims_user
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  ims_0028_rsp_s            *ims_0028_rsp
);

EXTERN int
qmi_ims_set_ims_user_info
(
  int                               client_handle,
  ims_0023_req_s             *ims_0023_req,
  int                               *qmi_err_code
);

EXTERN int
qmi_ims_get_ims_sip_info
(
  int                               client_handle,
  ims_0025_rsp_s             *ims_0025_rsp, 
  int                               *qmi_err_code
);

EXTERN int
qmi_ims_get_ims_sip
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  ims_0025_rsp_s            *ims_0025_rsp
);

EXTERN int
qmi_ims_set_ims_sip_info
(
  int                               client_handle,
  ims_0020_req_s             *ims_0020_req,
  int                               *qmi_err_code
);

EXTERN int
qmi_ims_get_ims_voip_info
(
  int                               client_handle,
  ims_0029_rsp_s             *ims_0029_rsp, 
  int                               *qmi_err_code
);

EXTERN int
qmi_ims_get_ims_voip
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  ims_0029_rsp_s            *ims_0029_rsp
);

EXTERN int
qmi_ims_set_ims_voip_info
(
  int                               client_handle,
  ims_0024_req_s             *ims_0024_req,
  int                               *qmi_err_code
);

EXTERN int
qmi_ims_get_ims_qipcall_info
(
  int                               client_handle,
  ims_0037_rsp_s             *ims_0037_rsp, 
  int                               *qmi_err_code
);

EXTERN int
qmi_ims_get_ims_qipcall
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  ims_0037_rsp_s            *ims_0037_rsp
);

EXTERN int
qmi_ims_set_ims_qipcall_info
(
  int                               client_handle,
  ims_0036_req_s             *ims_0036_req,
  int                               *qmi_err_code
);


#ifdef __cplusplus
}
#endif

#endif /* QMI_IMS_SRVC_H  */
