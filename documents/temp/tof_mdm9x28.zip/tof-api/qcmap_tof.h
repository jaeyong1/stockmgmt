#ifndef	QCMAP_TOF_H
#define	QCMAP_TOF_H

/******************************************************************************
  @file    qcmap_tof.h
  @brief   The QCMAP TOF API

  DESCRIPTION

  INITIALIZATION AND SEQUENCING REQUIREMENTS

  ---------------------------------------------------------------------------
  Copyright (c) 2016 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/
#include "TOF_Definition.h"

#ifdef __cplusplus
extern "C" {
#endif
int  qcmap_connect_backhaul(tof_qcmap_msgr_ip_family_enum_v01 ip_family);
int  qcmap_disconnect_backhaul(void);
int  qcmap_get_data_call_list(tof_data_call_response* call_resp);
int  qcmap_call_end_reason(int32_t* reason_code);
void qcmap_get_auto_connect_from_preference(boolean* enable);
int  qcmap_set_auto_connect(boolean enable, boolean file_write);

int  qcmap_store_preference(int profile, tof_qcmap_msgr_ip_family_enum_v01 ip_family);
int  qcmap_restore_preference(void);

int  qcmap_check_and_enable_mobile_ap(void);
int  qcmap_set_wwan_policy(int profile);

int  qcmap_client_validate(void);
int  qcmap_client_init(void);
void qcmap_client_release(void);

#ifdef __cplusplus
}
#endif
#endif /* QCMAP_TOF_H */
