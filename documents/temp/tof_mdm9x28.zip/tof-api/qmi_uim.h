#ifndef QMI_UIM_H
#define QMI_UIM_H

/******************************************************************************
  @file    qmi_uim.h
  @brief   QMI UIM header

  $Id$

  DESCRIPTION

  INITIALIZATION AND SEQUENCING REQUIREMENTS

  ---------------------------------------------------------------------------
  Copyright (c) 2013 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/

#include "qmi_uim_srvc.h"

/*---------------------------------------------------------------------------
  COMMON STRUCTURES
---------------------------------------------------------------------------*/

typedef struct
{
  unsigned short     file_id;
  unsigned short     record;
  unsigned char      offset;
  unsigned short     data_len;
  unsigned char    data[512];
} uim_ef_data_type;

typedef struct
{
  RIL_PinState     pin1_state;
  unsigned char      pin1_num_retries;
  unsigned char      puk1_num_retries;
  RIL_PinState     pin2_state;
  unsigned char      pin2_num_retries;
  unsigned char      puk2_num_retries;
} Card_PinStatus;

/*===========================================================================
  FUNCTION
===========================================================================*/
extern boolean tof_qmi_uim_init();
extern bool tof_qmi_uim_srvc_init();
extern int tof_qmi_uim_srvc_release();
extern uint8 ril_request_get_sim_status(RIL_CardStatus_v6 *pcard_status);
extern uint8 ril_request_get_est_list(wmmdiag_get_est_rsp_type *est_list);
extern uint8 ril_request_get_ust_list(wmmdiag_get_ust_rsp_type *ust_list);
extern uint8 ril_request_get_fplmn_list(wmmdiag_get_fplmn_rsp_type *fplmn_list);
extern uint8 ril_request_get_plmnwact_list(wmmdiag_plmnwact_list_type *plmn_list);
extern uint8 ril_request_set_plmnwact_list(wmmdiag_plmnwact_list_type plmn_list, int count);
extern uint8 ril_request_get_oplmnwact_list(wmmdiag_plmnwact_list_type *plmn_list);
extern uint8 ril_request_get_hplmnwact_list(wmmdiag_plmnwact_list_type *plmn_list);
extern uint8 ril_request_get_acm_max(HKS_ACM_MAX_INFO_TYPE *acm_max);
extern uint8 ril_request_get_iccid(char* iccid);
extern uint8 ril_ota_request();
extern uint8 request_ota_mode(uint8* ota_mode);
extern uint8 get_uicc_lock(uint8* uicc_lock);
extern uint8 set_uicc_lock(uint8 uicc_lock);
extern uint8 uicc_power_down();
extern uint8 uicc_power_up();
extern uint8 uim_read_data(uim_ef_data_type *uim_data, uint8 type);
extern uint8 uim_write_data(uim_ef_data_type *uim_data, uint8 type);
extern uint8 ril_ota_need_registration(uint8* ota_need);
extern uint8 request_get_pin_status(Card_PinStatus *pin_status);
extern uint8 set_pin_protection(qmi_uim_set_pin_protection_params_type *params);
extern uint8 unbloock_pin(qmi_uim_unblock_pin_params_type *params);
extern uint8 get_rtre_config(uint16* rtre_value);
extern uint8 set_rtre_value(uint16 rtre_value);
extern uint8 get_bip_config(uint16* bip_value);
extern uint8 set_bip_value(uint16 bip_value);
extern uint8 get_vzwlpm_config(uint16* vzw_lpm);
extern uint8 set_vzwlpm_config(uint16 vzw_lpm);
extern uint8 ril_request_get_imsi_hex(uint8 *imsi);
extern uint8 ril_request_get_iccid_hex(uint8 *iccid);
extern uint8 ril_request_get_fplmn_hex(uint8 *fplmn);
extern uint8 ril_request_set_fplmn_hex(uint8 *fplmn);
void  wmm_sim_refresh_reset(void);
extern uint8 ril_request_register_refresh_all(uint8* aid);
extern uint8 verify_pin(qmi_uim_verify_pin_params_type *params);

#endif /* QMI_UIM_H */