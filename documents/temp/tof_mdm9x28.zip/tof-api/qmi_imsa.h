#ifndef QMI_IMSA_H
#define QMI_IMSA_H

/******************************************************************************
  @file    qmi_imsa.h
  @brief   QMI IMSA header

  $Id$

  DESCRIPTION

  INITIALIZATION AND SEQUENCING REQUIREMENTS

  ---------------------------------------------------------------------------
  Copyright (c) 2013 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/

#include "qmi_imsa_srvc.h"
#include "TOF_API.h"

/*===========================================================================
  FUNCTION
===========================================================================*/
extern bool qmi_imsa_srvc_init();
extern bool qmi_imsa_srvc_release();

extern uint8 ril_request_get_service_status_info(int request, RIL_Imsa_Service_Status_Info *service_status);
extern uint8 ril_request_get_ims_reg_status_info(RIL_Imsa_Reg_Status_Info *ims_status);

#if 0 //chad_temp
extern void qmi_imsa_acs_failure_503_error_code_ind(); //hongsg 20140813
#endif 

#endif /* QMI_IMSA_H */