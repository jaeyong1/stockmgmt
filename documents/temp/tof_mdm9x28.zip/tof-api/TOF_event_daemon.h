#ifndef	TOF_EVENT_DAEMON_H
#define	TOF_EVENT_DAEMON_H
/******************************************************************************
  @file    TOF_event_daemon.h
  @brief   lgit tof_api lib

  DESCRIPTION
  
  ---------------------------------------------------------------------------
  Copyright (c) 2016 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/
#include "TOF_API.h"

#ifdef __cplusplus
  extern "C" {
#endif


//Definition
typedef struct _LIST_ITEM
{
	struct _LIST_ITEM *Prev;
	struct _LIST_ITEM *Next;
} LIST_ITEM, *PLIST_ITEM;

typedef struct _LINKED_LIST_TAG
{
	PLIST_ITEM          Head;
	PLIST_ITEM          Tail;
	boolean thread_alive;
} LINKED_LIST;

typedef struct
{
    LIST_ITEM   link;
    uint32      size;    
    uint8       data[4096];
} EVENT_MSG;


//Function
void EventNotifyEnqueue(DWORD event, uint32 wParam, uint32 lParam);
#define qmi_notify_event(event, param1, param2) EventNotifyEnqueue(event, param1, param2)
#define wms_notify_event( event, param1, param2 )	EventNotifyEnqueue( event, param1, param2 )	//dsji_20160314 add

void StartEventNotifyThread(void);
void EndEventNotifyThread(void);



#ifdef __cplusplus
}
#endif

#endif

