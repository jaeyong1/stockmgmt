/******************************************************************************
  @file    qmi_imsa_srvc.c
  @brief   The QMI IMSA service layer.

  DESCRIPTION
  QMI IMSA service routines.  

  INITIALIZATION AND SEQUENCING REQUIREMENTS
  qmi_imsa_srvc_init_client() needs to be called before sending or receiving of any 
  IMS service messages

  ---------------------------------------------------------------------------
  Copyright (c) 2013 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/

#include <string.h>
#include "qmi_i.h"
#include "qmi_service.h"
#include "qmi_imsa_srvc.h"
#include "qmi_util.h"
//#include "qmi_io.h"
//#include "DeviceMonitor.h"
#include "TOF_event_daemon.h"
#include "wmmdiag_packet_common.h"

#include "TOF_Definition.h"
#include "Debug_string.h"


#define QMI_IMSA_STD_MSG_SIZE   QMI_MAX_STD_MSG_SIZE

/*Service Message Definition*/
/** @addtogroup imss_qmi_msg_ids
    @{
  */
#define QMI_IMSA_GET_SUPPORTED_MSGS_REQ_V01 0x001E
#define QMI_IMSA_GET_SUPPORTED_MSGS_RESP_V01 0x001E
#define QMI_IMSA_GET_SUPPORTED_FIELDS_REQ_V01 0x001F
#define QMI_IMSA_GET_SUPPORTED_FIELDS_RESP_V01 0x001F
#define QMI_IMSA_GET_REGISTRATION_STATUS_REQ_V01 0x0020
#define QMI_IMSA_GET_REGISTRATION_STATUS_RSP_V01 0x0020
#define QMI_IMSA_GET_SERVICE_STATUS_REQ_V01 0x0021
#define QMI_IMSA_GET_SERVICE_STATUS_RSP_V01 0x0021
#define QMI_IMSA_IND_REG_REQ_V01 0x0022
#define QMI_IMSA_IND_REG_RSP_V01 0x0022
#define QMI_IMSA_REGISTRATION_STATUS_IND_V01 0x0023
#define QMI_IMSA_SERVICE_STATUS_IND_V01 0x0024
#define QMI_IMSA_ACS_STATUS_IND_V01 0x0027
/**
    @}
  */

//Global Variable
static int imsa_service_initialized = FALSE;

/*===========================================================================
  FUNCTION  qmi_imsa_reg_status_ind
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with serving system info.  It
  is used both by the get serving system info cmd response as well as the
  serving system indication.   
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_imsa_reg_status_ind
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  imsa_0023_ind_s           *imsa_0023_ind  
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;  

  memset(imsa_0023_ind, 0, sizeof(imsa_0023_ind_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                                            &rx_buf_len,
                                            &type,
                                            &length,
                                            &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case IMSA_0023_IND_T01:
      {
        imsa_0023_ind->t01_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,imsa_0023_ind->t01.ims_registered);
      }
      break;

      case IMSA_0023_IND_T10:
      {
        imsa_0023_ind->t10_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,imsa_0023_ind->t10.ims_registration_failure_error_code);
      }
      break;      

      default:
        QMI_DEBUG_MSG_1 ("qmi_imsa_ind_reg_status: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================

FUNCTION  nas_serving_system_ind_process

===========================================================================*/
void imsa_reg_status_ind_process(imsa_0023_ind_s *imsa_0023_ind)
{
  // IMS Reg Status
  if (imsa_0023_ind->t01_valid)
  {
    MSG_HIGH("[IMS] IMS registration status = %d", imsa_0023_ind->t01.ims_registered, 0, 0);
  }

  // Reg fail code
  if (imsa_0023_ind->t10_valid)
  {
    MSG_HIGH("[IMS] IMS Reg fail code = %d", imsa_0023_ind->t10.ims_registration_failure_error_code, 0, 0);
  }  

}

/*===========================================================================
  FUNCTION  qmi_imsa_service_status_ind
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with serving system info.  It
  is used both by the get serving system info cmd response as well as the
  serving system indication.   
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_imsa_service_status_ind
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  imsa_0024_ind_s           *imsa_0024_ind  
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;  

  memset(imsa_0024_ind, 0, sizeof(imsa_0024_ind_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                                            &rx_buf_len,
                                            &type,
                                            &length,
                                            &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case IMSA_0024_IND_T10:
      {
        imsa_0024_ind->t10_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,imsa_0024_ind->t10.sms_service_status);
      }
      break;

      case IMSA_0024_IND_T11:
      {
        imsa_0024_ind->t11_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,imsa_0024_ind->t11.voip_service_status);

#if 0 //chad_temp
        //20150529 osk dial btn color change when HD Voice        
        CLGIT_LTE_CMDlg *pMain = (CLGIT_LTE_CMDlg *)::AfxGetApp()->GetMainWnd();
        if(imsa_0024_ind->t11.voip_service_status == 0)
        {
          m_btn_make_voice_call_color = RGB(240,240,240);
          pMain->GetDlgItem(IDC_BTN_MAKE_VOICE_CALL)->Invalidate();
        }
        else if(imsa_0024_ind->t11.voip_service_status == 2)
        {
          m_btn_make_voice_call_color = RGB(50,205,50);
          pMain->GetDlgItem(IDC_BTN_MAKE_VOICE_CALL)->Invalidate();
        }
          
        //end
#endif        
      }
      break;      

      default:
        QMI_DEBUG_MSG_1 ("qmi_imsa_ind_service_status: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================

FUNCTION  nas_serving_system_ind_process

===========================================================================*/
void imsa_service_status_ind_process(imsa_0024_ind_s *imsa_0024_ind)
{
  // VOIP Service Status
  if (imsa_0024_ind->t11_valid)
  {
    MSG_HIGH("[IMS] voip service status = %d", imsa_0024_ind->t11.voip_service_status, 0, 0);
  }

}


/*===========================================================================
  FUNCTION  qmi_imsa_acs_status_ind
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with serving system info.  It
  is used both by the get serving system info cmd response as well as the
  serving system indication.   
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_imsa_acs_status_ind
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  imsa_0027_ind_s           *imsa_0027_ind  
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;  

  memset(imsa_0027_ind, 0, sizeof(imsa_0027_ind_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                                            &rx_buf_len,
                                            &type,
                                            &length,
                                            &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case IMSA_0027_IND_T01:
      {
        imsa_0027_ind->t01_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,imsa_0027_ind->t01.acs_failure_status_code);
      }
      break;

      case IMSA_0027_IND_T10:
      {
        imsa_0027_ind->t10_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,imsa_0027_ind->t10.acs_failure_error_code);
      }
      break;      

      default:
        QMI_DEBUG_MSG_1 ("qmi_imsa_ind_acs_status: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}
void imsa_acs_status_ind_process(imsa_0027_ind_s *imsa_0027_ind)
{
  char tmp_buf[256] = {0};
  
  if (imsa_0027_ind->t01_valid)
  {
    MSG_HIGH("[IMS] IMS acs status = %d", imsa_0027_ind->t01.acs_failure_status_code, 0, 0);
  }

  if (imsa_0027_ind->t10_valid)
  {
    MSG_HIGH("[IMS] IMS acs fail code = %d", imsa_0027_ind->t10.acs_failure_error_code, 0, 0);

    if ( imsa_0027_ind->t10.acs_failure_error_code == 503)
    {
#if 0 //chad_temp      
      qmi_imsa_acs_failure_503_error_code_ind(); //hongsg 20140813
#else
      sprintf(tmp_buf, "IMS_ACS_FAILURE_503_ERROR_CODE\r\n");
      qmi_notify_event(TOF_EVENT_ACS_FAIL_IND, (uint32)NULL,  (uint32)tmp_buf); 
#endif      
    }
  }  
}

/*===========================================================================
  FUNCTION  qmi_imsa_srvc_indication_cb
===========================================================================*/
/*!
@brief 
  This is the callback function that will be called by the generic
  services layer to report asynchronous indications.  This function will
  process the indication TLV's and then call the user registered
  functions with the indication data.   
  
@return 
  None.

@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/

static void
qmi_imsa_srvc_indication_cb
(
  int                   user_handle,
  qmi_service_id_type   service_id,
  unsigned long         msg_id,
  void                                *user_ind_msg_hdlr,
  void                                *user_ind_msg_hdlr_user_data,
  unsigned char         *rx_msg_buf,
  int                   rx_msg_len
)
{
  qmi_imsa_indication_id_type      ind_id;
  qmi_imsa_indication_data_type    ind_data;
  qmi_imsa_indication_hdlr_type    user_ind_hdlr;

  /* Make sure that the user indication handler isn't NULL */
  if (user_ind_msg_hdlr == NULL)
  {
    return;
  }

  memset((void*)&ind_data, 0x0, sizeof(ind_data));

  /* Get properly cast pointer to user indication handler */
  /*lint -e{611} */
  user_ind_hdlr = (qmi_imsa_indication_hdlr_type) user_ind_msg_hdlr;

  switch (msg_id)
  {
    case QMI_IMSA_SERVICE_STATUS_IND_V01:
    {
      ind_id = QMI_IMSA_SRVC_SERVICE_STATUS_IND_V01;
      if (qmi_imsa_service_status_ind(rx_msg_buf,
                                          rx_msg_len,
                                          &ind_data.imsa_0024_ind) < 0)
      {
        QMI_ERR_MSG_0 ("qmi_imsa_srvc_indication_cb: Failure in imsa service status indication data\n ");
        return;
      }
      imsa_service_status_ind_process(&ind_data.imsa_0024_ind);        
    }
    break;

    case QMI_IMSA_REGISTRATION_STATUS_IND_V01:
    {
      ind_id = QMI_IMSA_SRVC_REGISTRATION_STATUS_IND_V01;
      if (qmi_imsa_reg_status_ind(rx_msg_buf,
                                          rx_msg_len,
                                          &ind_data.imsa_0023_ind) < 0)
      {
        QMI_ERR_MSG_0 ("qmi_imsa_srvc_indication_cb: Failure in imsa registration status indication data\n ");
        return;
      }
      imsa_reg_status_ind_process(&ind_data.imsa_0023_ind);        
    }
    break; 

    case QMI_IMSA_ACS_STATUS_IND_V01:
    {
      ind_id = QMI_IMSA_SRVC_ACS_STATUS_IND_V01;
      if (qmi_imsa_acs_status_ind(rx_msg_buf,
                                          rx_msg_len,
                                          &ind_data.imsa_0027_ind) < 0)
      {
        QMI_ERR_MSG_0 ("qmi_imsa_srvc_indication_cb: Failure in imsa acs status indication data\n ");
        return;
      }
      imsa_acs_status_ind_process(&ind_data.imsa_0027_ind);        
    }
    break; 


    default:
      {
        QMI_DEBUG_MSG_1 ("qmi_imsa_srvc_indication_cb: Unknown MsgId=%ld",msg_id);
        return;
      }
  }/*Switch*/


    /* Call user registered handler */
    user_ind_hdlr (user_handle,
                   service_id,
                   user_ind_msg_hdlr_user_data,
                   ind_id,
                   &ind_data);

}

/*===========================================================================
  FUNCTION  qmi_imsa_reg_ind_hdlr
===========================================================================*/
/*!
@brief 
  This function is a callback that will be called once during client
  initialization  
  
@return 
  None.

@note

  - Dependencies
    - None.

  - Side Effects
    - None.
*/    
/*=========================================================================*/
int qmi_imsa_reg_ind_hdlr (qmi_service_ind_rx_hdlr  user_ind_msg_hdlr)
{
  int  rc = QMI_NO_ERR;
  if (!imsa_service_initialized)
  {

    rc = qmi_service_set_srvc_functions (QMI_IMSA_SERVICE,
                                 user_ind_msg_hdlr);
    if (rc != QMI_NO_ERR)
    {
      printf("qmi_ims_srvc_init: set srvc functions returns err=%d\n",rc);
    }
    else
    {
      printf("qmi_ims_srvc_init: IMS successfully initialized\r\n");
      imsa_service_initialized = TRUE;
    }
  }
  else
  {
    printf("qmi_ims_srvc_init: Init failed, IMS already initialized\r\n");
  }
  return rc;
}


/*===========================================================================
  FUNCTION  qmi_imsa_srvc_init_client
===========================================================================*/
/*!
@brief 
  This function is called to initialize the IMS service.  This function
  must be called prior to calling any other IMS service functions.
  For the time being, the indication handler callback and user data
  should be set to NULL until this is implemented.  Also note that this
  function may be called multiple times to allow for multiple, independent
  clients.   
  
@return 
  0 if abort operation was sucessful, < 0 if not.  If return code is 
  QMI_INTERNAL_ERR, then the qmi_err_code will be valid and will 
  indicate which QMI error occurred.

@note

  - Dependencies
    - qmi_connection_init() must be called for the associated port first.

  - Side Effects
    - Talks to modem processor
*/    
/*=========================================================================*/
qmi_client_handle_type qmi_imsa_srvc_init_client
(
   const char                   *dev_id,
  qmi_imsa_indication_hdlr_type  user_ind_msg_hdlr,
  void                          *user_ind_msg_hdlr_user_data,
  int                           *qmi_err_code
)
{
  qmi_client_handle_type client_handle;
  qmi_connection_id_type conn_id;

  printf("qmi_imsa_srvc_init_client\r\n");  

  if ((conn_id = QMI_PLATFORM_DEV_NAME_TO_CONN_ID(dev_id)) == QMI_CONN_ID_INVALID)
  {
    printf("qmi_imsa_srvc_init_client: conn_id fail %x\r\n",conn_id);  
    return QMI_INTERNAL_ERR;
  }

  printf("qmi_imsa_srvc_init_client: conn_id %x\r\n",conn_id);

    /* Call common service layer initialization function */
    /*lint -e{611} */
    client_handle =  qmi_service_init (conn_id,
                                     QMI_IMSA_SERVICE,
                                     (void *) user_ind_msg_hdlr,
                                     user_ind_msg_hdlr_user_data,
                                     qmi_err_code);

    if(client_handle > 0)  
      qmi_imsa_reg_ind_hdlr(qmi_imsa_srvc_indication_cb);
    else 
    printf("qmi_imsa_srvc_init_client: client_handle  0x%x failed \r\n",client_handle);

  return client_handle;

} /* qmi_imsa_srvc_init_client */


/*===========================================================================
  FUNCTION  qmi_imsa_srvc_release_client
===========================================================================*/
/*!
@brief 
  This function is called to release a client created by the 
  qmi_ims_srvc_init_client() function.  This function should be called
  for any client created when terminating a client process, especially
  if the modem processor is not reset.  The modem side QMI server has 
  a limited number of clients that it will allocate, and if they are not
  released, we will run out.  
  
@return 
  0 if abort operation was sucessful, < 0 if not.  If return code is 
  QMI_INTERNAL_ERR, then the qmi_err_code will be valid and will 
  indicate which QMI error occurred.

@note

  - Dependencies
    - qmi_connection_init() must be called for the associated port first.

  - Side Effects
    - Talks to modem processor
*/    
/*=========================================================================*/

int 
qmi_imsa_srvc_release_client
(
  int      user_handle,
  int      *qmi_err_code
)
{
  int  rc = QMI_NO_ERR;
  
  rc = qmi_service_release (user_handle, qmi_err_code);

  if (imsa_service_initialized)
  {

    rc = qmi_service_set_srvc_functions (QMI_IMSA_SERVICE,NULL);
    if (rc != QMI_NO_ERR)
    {
      printf("qmi_imsa_srvc_release: set srvc functions returns err=%d\n",rc);
    }
    else
    {
      printf("qmi_imsa_srvc_release: IMS successfully released\r\n");
      imsa_service_initialized = FALSE;
    }
  }
  else
  {
    printf("qmi_imsa_srvc_release: Release failed, IMS not initialized\r\n");
  }
  
  return rc;
  
}

/*===========================================================================
  FUNCTION  qmi_imsa_indication_register
===========================================================================*/
/*!
@brief 
  Set the IMSA indication registration state for specified control point.
     
  
@return 

@note

  - Dependencies
    - qmi_imsa_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_imsa_indication_register
(
  int                                     client_handle,
  imsa_0022_req_s                  *imsa_0022_req,
  int                                    *qmi_err_code
)
{
  unsigned char     msg[QMI_IMSA_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;
 
  if(!imsa_0022_req)
  {
    return QMI_INTERNAL_ERR;
  }
  
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_IMSA_STD_MSG_SIZE);

  /* Write system selection preference TLV if appropriate */
  if(imsa_0022_req->t10_valid)
  {
    val_ptr = (unsigned char*)&imsa_0022_req->t10;
    tlv_length = sizeof(imsa_0022_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMSA_0022_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(imsa_0022_req->t11_valid)
  {
    val_ptr = (unsigned char*)&imsa_0022_req->t11;
    tlv_length = sizeof(imsa_0022_req->t11);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMSA_0022_REQ_T11,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(imsa_0022_req->t14_valid)
  {
    val_ptr = (unsigned char*)&imsa_0022_req->t14;
    tlv_length = sizeof(imsa_0022_req->t14);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMSA_0022_REQ_T14,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  /* Synchronously send message to modem processor */
  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_IMSA_SERVICE,
                                  QMI_IMSA_IND_REG_REQ_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_IMSA_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_IMSA_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
} /* qmi_imsa_indication_register */

int
qmi_imsa_get_service_status_info
(
  int                               client_handle,
  imsa_0021_rsp_s             *imsa_0021_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_IMSA_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!imsa_0021_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_IMSA_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_IMSA_SERVICE,
                                  QMI_IMSA_GET_SERVICE_STATUS_REQ_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_IMSA_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_IMSA_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_imsa_get_service_status (msg,msg_size, imsa_0021_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_ims_get_service_status: qmi_ims_get_service_status_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

int qmi_imsa_get_service_status
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  imsa_0021_rsp_s            *imsa_0021_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(imsa_0021_rsp, 0, sizeof(imsa_0021_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      // voip service status
      case IMSA_0021_RSP_T11:
      {
        imsa_0021_rsp->t11_valid = TRUE;
        READ_32_BIT_VAL (value_ptr, imsa_0021_rsp->t11.voip_service_status);
      }

      default:
        QMI_DEBUG_MSG_1 ("qmi_ims_get_service_status: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

int
qmi_imsa_get_reg_status_info
(
  int                               client_handle,
  imsa_0020_rsp_s             *imsa_0020_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_IMSA_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!imsa_0020_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_IMSA_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_IMSA_SERVICE,
                                  QMI_IMSA_GET_REGISTRATION_STATUS_REQ_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_IMSA_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_IMSA_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_imsa_get_reg_status (msg,msg_size, imsa_0020_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_ims_get_reg_status: qmi_ims_get_reg_status_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

int qmi_imsa_get_reg_status
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  imsa_0020_rsp_s            *imsa_0020_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(imsa_0020_rsp, 0, sizeof(imsa_0020_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      // ims registration status
      case IMSA_0020_RSP_T10:
      {
        imsa_0020_rsp->t10_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, imsa_0020_rsp->t10.ims_registered);
      }
    
      // ims registration status
      case IMSA_0020_RSP_T11:
      {
        imsa_0020_rsp->t11_valid = TRUE;
        READ_16_BIT_VAL (value_ptr, imsa_0020_rsp->t11.ims_registration_failure_error_code);
      }

      default:
        QMI_DEBUG_MSG_1 ("qmi_ims_get_reg_status: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

