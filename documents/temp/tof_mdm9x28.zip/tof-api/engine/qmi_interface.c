



#include "qmi/qmi_wms.h"
#include "qmi/qmi_voice.h"
#include "qmi/qmi_core.h"
#include "wms.h"
#include "voice.h"
#include "qmi_interface.h"



//**************************************************************
// private member
//**************************************************************
typedef struct
{
	qmi_service_id_type qmi_service_id;
	unsigned int 				qmi_request_message_id;
} qmi_request_messsage_id_info_s;

typedef struct
{
	qmi_request_messsage_id_info_s	qmi_request_message_id_info;
	DUBU_request_type_e DUBU_request_type;
} qmi_request_message_id_to_DUBU_request_type_s;

qmi_request_message_id_to_DUBU_request_type_s		m_qmi_request_message_id_to_DUBU_request_type_table[] =
{
	//sms
	{ { QMI_WMS_SERVICE, 			QMI_WMS_RAW_SEND_REQ_V01 }, 								DUBU_req_type_wms_send_sms },
	{ { QMI_WMS_SERVICE, 			QMI_WMS_DELETE_REQ_V01 },										DUBU_req_type_wms_delete_sms },
	{ { QMI_WMS_SERVICE, 			QMI_WMS_RAW_READ_REQ_V01 },									DUBU_req_type_wms_read_sms },				
	{ { QMI_WMS_SERVICE, 			QMI_WMS_LIST_MESSAGES_REQ_V01 },						DUBU_req_type_wms_list_sms },
	{ { QMI_WMS_SERVICE, 			QMI_WMS_GET_SMSC_ADDRESS_REQ_V01 }, 				DUBU_req_type_wms_get_smsc_address },
	{ { QMI_WMS_SERVICE, 			QMI_WMS_SET_SMSC_ADDRESS_REQ_V01 }, 				DUBU_req_type_wms_set_smsc_address },
	{ { QMI_WMS_SERVICE, 			QMI_WMS_GET_STORE_MAX_SIZE_REQ_V01 },				DUBU_req_type_wms_get_memory_status },
   { { QMI_WMS_SERVICE, 			QMI_WMS_RAW_SEND_REQ_V01 }, 								DUBU_req_type_wms_send_sms_pdu },
	//voice
	{ { QMI_VOICE_SERVICE, 		QMI_VOICE_DIAL_CALL_REQ_V02 },							DUBU_req_type_voice_dial_call }
};



typedef struct
{
	unsigned int qmi_service_id;
	unsigned int qmi_indication_message_id;
	DUBU_indication_type_e DUBU_indication_type;
} qmi_indication_message_id_to_DUBU_indication_type_s;

qmi_indication_message_id_to_DUBU_indication_type_s	 m_qmi_indication_message_id_to_DUBU_indication_type_table[] =
{
	//sms
	{ QMI_WMS_SERVICE, QMI_WMS_EVENT_REPORT_IND_V01, DUBU_ind_type_wms_new_sms },
	//voice
	{ QMI_VOICE_SERVICE, QMI_VOICE_ALL_CALL_STATUS_IND_V02, DUBU_ind_type_voice_all_call_status }
};



DUBU_interface_callback_s m_DUBU_qmi_callback;



//**************************************************************
// public member
//**************************************************************



//**************************************************************
// private function
//**************************************************************
//==============================================================
//
//==============================================================
const DUBU_request_type_e DUBU_qmi_get_DUBU_request_type( const unsigned int qmi_service_id, const unsigned int qmi_request_message_id )
{
	unsigned int i = 0;

	//
	for ( i = 0; i < sizeof( m_qmi_request_message_id_to_DUBU_request_type_table ) / sizeof( qmi_request_message_id_to_DUBU_request_type_s ); ++i )
	{
		if ( qmi_service_id == m_qmi_request_message_id_to_DUBU_request_type_table[ i ].qmi_request_message_id_info.qmi_service_id &&
					qmi_request_message_id == m_qmi_request_message_id_to_DUBU_request_type_table[ i ].qmi_request_message_id_info.qmi_request_message_id )
		{
			return m_qmi_request_message_id_to_DUBU_request_type_table[ i ].DUBU_request_type;
		}
	}

	log_error( "fail, qmi_service_id:[%d], qmi_request_message_id:[0x%08x]", qmi_service_id, qmi_request_message_id );

	return invalid_DUBU_request_type;
}

//==============================================================
//
//==============================================================
const qmi_request_messsage_id_info_s* const DUBU_qmi_get_qmi_request_message_id_info( DUBU_request_type_e DUBU_request_type )
{
	unsigned int i = 0;

	for ( i = 0; i < sizeof( m_qmi_request_message_id_to_DUBU_request_type_table ) / sizeof( qmi_request_message_id_to_DUBU_request_type_s ); ++i )
	{
		if ( DUBU_request_type == m_qmi_request_message_id_to_DUBU_request_type_table[ i ].DUBU_request_type )
			return &( m_qmi_request_message_id_to_DUBU_request_type_table[ i ].qmi_request_message_id_info );
	}

	log_error( "fail, DUBU_request_type:[%d]", DUBU_request_type );

	return NULL;
}

//==============================================================
//
//==============================================================
const DUBU_indication_type_e		DUBU_qmi_get_DUBU_indication_type( const unsigned int qmi_service_id, const unsigned int qmi_indication_msg_id )
{
	unsigned int i = 0;

	//
	for ( i = 0; i < sizeof( m_qmi_indication_message_id_to_DUBU_indication_type_table ) / sizeof( qmi_indication_message_id_to_DUBU_indication_type_s ); ++i )
	{
		if ( qmi_service_id == m_qmi_indication_message_id_to_DUBU_indication_type_table[ i ].qmi_service_id && 
					qmi_indication_msg_id == m_qmi_indication_message_id_to_DUBU_indication_type_table[ i ].qmi_indication_message_id )
			return m_qmi_indication_message_id_to_DUBU_indication_type_table[ i ].DUBU_indication_type;
	}
	
	log_error( "fail, qmi_service_id:[%d], qmi_indication_msg_id:[0x%08x]", qmi_service_id, qmi_indication_msg_id );

	return invalid_DUBU_indication_type;
}

//==============================================================
//
//==============================================================
const qmi_indication_message_id_to_DUBU_indication_type_s* const DUBU_qmi_get_qmi_indication_message_id( DUBU_indication_type_e DUBU_indication_type )
{
	unsigned int i = 0;

	for ( i = 0; i < sizeof( m_qmi_indication_message_id_to_DUBU_indication_type_table ) / sizeof( qmi_indication_message_id_to_DUBU_indication_type_s ); ++i )
	{
		if ( DUBU_indication_type == m_qmi_indication_message_id_to_DUBU_indication_type_table[ i ].DUBU_indication_type )
			return &( m_qmi_indication_message_id_to_DUBU_indication_type_table[ i ] );
	}

	log_error( "fail, DUBU_indication_type:[%d]", DUBU_indication_type );

	return NULL;
}
//==============================================================
//
//==============================================================
void DUBU_qmi_release( void )
{
	qmi_core_release();
	
	memset( &m_DUBU_qmi_callback, 0, sizeof(  m_DUBU_qmi_callback ) );
	
	log_med( "ok!" );
}

//==============================================================
//
//==============================================================
void qmi_indication_cb( const qmi_client_handle_type qmi_client_handle,
															  const qmi_service_id_type qmi_service_id,
															  const void* const user_data,
															  const unsigned int qmi_indication_message_id,
															  const void* const qmi_indication_message )
{
	DUBU_indication_type_e DUBU_indication_type = invalid_DUBU_indication_type;
	
	if ( NULL == qmi_indication_message )
	{
		log_error( "qmi_indication_message is null" );
		return;
	}

	DUBU_indication_type = DUBU_qmi_get_DUBU_indication_type( qmi_service_id, qmi_indication_message_id );

	if ( invalid_DUBU_indication_type == DUBU_indication_type )
	{
		log_error( "invalid DUBU_indication_type:[%d]", DUBU_indication_type );
		return;
	}
	
	log_med( "qmi_indication_message_id:[0x%08x]", qmi_indication_message_id );

	m_DUBU_qmi_callback.indication( DUBU_indication_type, qmi_indication_message );
}

//==============================================================
//
//==============================================================
int DUBU_qmi_init( const DUBU_interface_init_info_s* const DUBU_interface_init_info )
{
	if ( NULL == DUBU_interface_init_info->DUBU_interface_callback.response || NULL == DUBU_interface_init_info->DUBU_interface_callback.indication )
	{
		log_error( "invalid DUBU_interface_callback, response:[%d], indication:[%d]",
									DUBU_interface_init_info->DUBU_interface_callback.response,
									DUBU_interface_init_info->DUBU_interface_callback.indication );		
		return FALSE;
	}

  if ( FALSE == qmi_core_init( QMI_PORT_RMNET_0, qmi_indication_cb, NULL ) )
	{
		log_error( "qmi_core_init() fail" );
		return FALSE;
	}

	m_DUBU_qmi_callback = DUBU_interface_init_info->DUBU_interface_callback;

	log_med( "ok!" );
	
  return TRUE;
}

//==============================================================
//
//==============================================================
const void* const DUBU_qmi_create_qmi_request_message( const DUBU_request_type_e DUBU_request_type, const void* const DUBU_request_data )
{
	void* qmi_request_message = NULL;
	qmi_request_messsage_id_info_s* qmi_request_message_id_info = NULL;
	qmi_request_message_info_s* qmi_request_message_info = NULL; 

	//
	qmi_request_message_id_info = DUBU_qmi_get_qmi_request_message_id_info( DUBU_request_type );

	if ( NULL == qmi_request_message_id_info )
	{
		log_error( "qmi_request_message_id_info is null" );
		return NULL;
	}

	qmi_request_message_info = qmi_get_qmi_request_message_info( qmi_request_message_id_info->qmi_service_id, qmi_request_message_id_info->qmi_request_message_id );
	
	if ( NULL == qmi_request_message_info )
	{
		log_error( "qmi_request_message_info is null" );
		return NULL;
	}
	
	qmi_request_message = mem_alloc( qmi_request_message_info->qmi_request_message_size );
	
	if ( NULL == qmi_request_message )
	{
		log_error( "qmi_request_message allocation fail, DUBU_request_type:[%d], qmi_request_message_size:[%d]", DUBU_request_type, qmi_request_message_info->qmi_request_message_size );
		return NULL;
	}
	
	memset( qmi_request_message, 0, qmi_request_message_info->qmi_request_message_size );
	
	switch ( DUBU_request_type )
	{
	//sms
    case DUBU_req_type_wms_send_sms_pdu:
      {
			wms_raw_send_req_msg_v01* qmi_request_wms_send_sms = (wms_raw_send_req_msg_v01*)qmi_request_message;
			DUBU_request_wms_send_sms_pdu_s*	 DUBU_request_wms_send_sms = (DUBU_request_wms_send_sms_pdu_s*)DUBU_request_data;
			
			switch ( DUBU_request_wms_send_sms->raw_message_data.format )
			{
		  case WMS_FORMAT_CDMA:									qmi_request_wms_send_sms->raw_message_data.format = WMS_MESSAGE_FORMAT_CDMA_V01;				break;
		  case WMS_FORMAT_MWI:									qmi_request_wms_send_sms->raw_message_data.format = WMS_MESSAGE_FORMAT_MWI_V01;					break;
		  case WMS_FORMAT_GW_PP:								qmi_request_wms_send_sms->raw_message_data.format = WMS_MESSAGE_FORMAT_GW_PP_V01;				break;
		  case WMS_FORMAT_GW_CB:								qmi_request_wms_send_sms->raw_message_data.format = WMS_MESSAGE_FORMAT_GW_BC_V01;				break;
		  case WMS_FORMAT_ANALOG_CLI:
		  case WMS_FORMAT_ANALOG_VOICE_MAIL:
		  case WMS_FORMAT_ANALOG_SMS:
		  case WMS_FORMAT_ANALOG_AWISMS:
			default:
				{
					log_error( "invalid format:[%d]", DUBU_request_wms_send_sms->raw_message_data.format );

					mem_free( qmi_request_wms_send_sms );
					return NULL;
				}
				break;
			}

			memcpy( qmi_request_wms_send_sms->raw_message_data.raw_message, 
							DUBU_request_wms_send_sms->raw_message_data.data,
							DUBU_request_wms_send_sms->raw_message_data.len );
			
			qmi_request_wms_send_sms->raw_message_data.raw_message_len = DUBU_request_wms_send_sms->raw_message_data.len;
			
			qmi_request_wms_send_sms->force_on_dc_valid = FALSE;
			qmi_request_wms_send_sms->force_on_dc.force_on_dc = TRUE;
			qmi_request_wms_send_sms->force_on_dc.so = WMS_SO_AUTO_V01;

			qmi_request_wms_send_sms->follow_on_dc_valid = FALSE;
			qmi_request_wms_send_sms->follow_on_dc = WMS_FOLLOW_ON_DC_ON_V01;

			qmi_request_wms_send_sms->link_timer_valid = FALSE;
			qmi_request_wms_send_sms->link_timer = 4;

			qmi_request_wms_send_sms->sms_on_ims_valid = FALSE;
			qmi_request_wms_send_sms->sms_on_ims = TRUE;

			qmi_request_wms_send_sms->retry_message_valid = FALSE;
			qmi_request_wms_send_sms->retry_message = WMS_MESSAGE_IS_A_RETRY_V01;

			qmi_request_wms_send_sms->retry_message_id_valid = FALSE;
			qmi_request_wms_send_sms->retry_message_id = 4;

			qmi_request_wms_send_sms->link_enable_mode_valid = FALSE;
			qmi_request_wms_send_sms->link_enable_mode = TRUE;

		}
      break;
  
	case DUBU_req_type_wms_send_sms:
		{
			wms_raw_send_req_msg_v01* qmi_request_wms_send_sms = (wms_raw_send_req_msg_v01*)qmi_request_message;
			DUBU_request_wms_send_sms_s*	 DUBU_request_wms_send_sms = (DUBU_request_wms_send_sms_s*)DUBU_request_data;
			
			switch ( DUBU_request_wms_send_sms->raw_message_data.format )
			{
		  case WMS_FORMAT_CDMA:									qmi_request_wms_send_sms->raw_message_data.format = WMS_MESSAGE_FORMAT_CDMA_V01;				break;
		  case WMS_FORMAT_MWI:									qmi_request_wms_send_sms->raw_message_data.format = WMS_MESSAGE_FORMAT_MWI_V01;					break;
		  case WMS_FORMAT_GW_PP:								qmi_request_wms_send_sms->raw_message_data.format = WMS_MESSAGE_FORMAT_GW_PP_V01;				break;
		  case WMS_FORMAT_GW_CB:								qmi_request_wms_send_sms->raw_message_data.format = WMS_MESSAGE_FORMAT_GW_BC_V01;				break;
		  case WMS_FORMAT_ANALOG_CLI:
		  case WMS_FORMAT_ANALOG_VOICE_MAIL:
		  case WMS_FORMAT_ANALOG_SMS:
		  case WMS_FORMAT_ANALOG_AWISMS:
			default:
				{
					log_error( "invalid format:[%d]", DUBU_request_wms_send_sms->raw_message_data.format );

					mem_free( qmi_request_wms_send_sms );
					return NULL;
				}
				break;
			}


  			if ( WMS_MESSAGE_FORMAT_GW_PP_V01 == qmi_request_wms_send_sms->raw_message_data.format )
  			{
  				//entry data of raw_message_data is smsc data
  				//the 1'st octet of smsc data is smsc data length
  				//we don't use smsc data, so set it to 0
  				
  				unsigned char smsc_data_length = 0;
                unsigned int smsc_data_pdu_length = smsc_data_length + sizeof( smsc_data_length );

  				qmi_request_wms_send_sms->raw_message_data.raw_message[ 0 ] = smsc_data_length;

  				memcpy( &( qmi_request_wms_send_sms->raw_message_data.raw_message[ smsc_data_pdu_length ] ), 
  								DUBU_request_wms_send_sms->raw_message_data.data,
  								DUBU_request_wms_send_sms->raw_message_data.len );
  				
  				qmi_request_wms_send_sms->raw_message_data.raw_message_len = DUBU_request_wms_send_sms->raw_message_data.len + smsc_data_pdu_length;
  			}
  			else
  			{
  				memcpy( qmi_request_wms_send_sms->raw_message_data.raw_message, 
  								DUBU_request_wms_send_sms->raw_message_data.data,
  								DUBU_request_wms_send_sms->raw_message_data.len );
  				
  				qmi_request_wms_send_sms->raw_message_data.raw_message_len = DUBU_request_wms_send_sms->raw_message_data.len;
  			}

			
			qmi_request_wms_send_sms->force_on_dc_valid = FALSE;
			qmi_request_wms_send_sms->force_on_dc.force_on_dc = TRUE;
			qmi_request_wms_send_sms->force_on_dc.so = WMS_SO_AUTO_V01;

			qmi_request_wms_send_sms->follow_on_dc_valid = FALSE;
			qmi_request_wms_send_sms->follow_on_dc = WMS_FOLLOW_ON_DC_ON_V01;

			qmi_request_wms_send_sms->link_timer_valid = FALSE;
			qmi_request_wms_send_sms->link_timer = 4;

			qmi_request_wms_send_sms->sms_on_ims_valid = FALSE;
			qmi_request_wms_send_sms->sms_on_ims = TRUE;

			qmi_request_wms_send_sms->retry_message_valid = FALSE;
			qmi_request_wms_send_sms->retry_message = WMS_MESSAGE_IS_A_RETRY_V01;

			qmi_request_wms_send_sms->retry_message_id_valid = FALSE;
			qmi_request_wms_send_sms->retry_message_id = 4;

			qmi_request_wms_send_sms->link_enable_mode_valid = FALSE;
			qmi_request_wms_send_sms->link_enable_mode = TRUE;

		}
		break;
	
	case DUBU_req_type_wms_delete_sms:
		{
			wms_delete_req_msg_v01* qmi_request_wms_delete_sms = (wms_delete_req_msg_v01*)qmi_request_message;
			DUBU_request_wms_delete_sms_s*	 DUBU_request_wms_delete_sms = (DUBU_request_wms_delete_sms_s*)DUBU_request_data;
			
			qmi_request_wms_delete_sms->storage_type = WMS_STORAGE_TYPE_NV_V01;
			
			qmi_request_wms_delete_sms->index_valid = TRUE;
			qmi_request_wms_delete_sms->index = DUBU_request_wms_delete_sms->message_index;
			
			qmi_request_wms_delete_sms->tag_type_valid = FALSE;
			qmi_request_wms_delete_sms->tag_type = WMS_TAG_TYPE_MT_NOT_READ_V01;
			
			qmi_request_wms_delete_sms->message_mode_valid = TRUE;
			qmi_request_wms_delete_sms->message_mode = WMS_MESSAGE_MODE_GW_V01;
		}
		break;
	
	case DUBU_req_type_wms_read_sms:
		{
			wms_raw_read_req_msg_v01* qmi_request_wms_read_sms = (wms_raw_read_req_msg_v01*)qmi_request_message;
			DUBU_request_wms_read_sms_s*	 DUBU_request_wms_read_sms = (DUBU_request_wms_read_sms_s*)DUBU_request_data;
			
			qmi_request_wms_read_sms->message_memory_storage_identification.storage_type = WMS_STORAGE_TYPE_NV_V01;				
			qmi_request_wms_read_sms->message_memory_storage_identification.storage_index = DUBU_request_wms_read_sms->message_index;

			qmi_request_wms_read_sms->message_mode_valid = TRUE;
			qmi_request_wms_read_sms->message_mode = WMS_MESSAGE_MODE_GW_V01;

			qmi_request_wms_read_sms->sms_on_ims_valid = FALSE;
			qmi_request_wms_read_sms->sms_on_ims = 0;
		}
		break;
	
	case DUBU_req_type_wms_list_sms:
		{
			wms_list_messages_req_msg_v01* qmi_request_wms_list_sms = (wms_list_messages_req_msg_v01*)qmi_request_message;
			DUBU_request_wms_list_sms_s*	 DUBU_request_wms_list_sms = (DUBU_request_wms_list_sms_s*)DUBU_request_data;

			qmi_request_wms_list_sms->storage_type = WMS_STORAGE_TYPE_NV_V01;
			
			qmi_request_wms_list_sms->tag_type_valid = FALSE;
			qmi_request_wms_list_sms->tag_type = WMS_TAG_TYPE_MT_NOT_READ_V01;

			qmi_request_wms_list_sms->message_mode_valid = TRUE;
			qmi_request_wms_list_sms->message_mode = WMS_MESSAGE_MODE_GW_V01;
		}
		break;
	
	case DUBU_req_type_wms_get_smsc_address:
		{
			wms_get_smsc_address_req_msg_v01* qmi_request_wms_get_smsc_address = (wms_get_smsc_address_req_msg_v01*)qmi_request_message;
			DUBU_request_wms_get_smsc_address_s*	 DUBU_request_wms_get_smsc_address = (DUBU_request_wms_get_smsc_address_s*)DUBU_request_data;
			
			qmi_request_wms_get_smsc_address->index_valid = FALSE;
			qmi_request_wms_get_smsc_address->index = 0;
		}
		break;
	
	case DUBU_req_type_wms_set_smsc_address:
		{
			wms_set_smsc_address_req_msg_v01* qmi_request_wms_set_smsc_address = (wms_set_smsc_address_req_msg_v01*)qmi_request_message;
			DUBU_request_wms_set_smsc_address_s*	 DUBU_request_wms_set_smsc_address = (DUBU_request_wms_set_smsc_address_s*)DUBU_request_data;
			
			strcpy( qmi_request_wms_set_smsc_address->smsc_address_digits, DUBU_request_wms_set_smsc_address->smsc_address_digits );

			qmi_request_wms_set_smsc_address->smsc_address_type_valid = FALSE;
			memset( qmi_request_wms_set_smsc_address->smsc_address_type, 0, sizeof( qmi_request_wms_set_smsc_address->smsc_address_type ) );		
		}
		break;
	
	case DUBU_req_type_wms_get_memory_status:
		{
			wms_get_store_max_size_req_msg_v01* qmi_request_wms_get_store_max_size = (wms_get_store_max_size_req_msg_v01*)qmi_request_message;
			DUBU_request_wms_get_memory_status_s*		DUBU_request_wms_get_memory_status = (DUBU_request_wms_get_memory_status_s*)DUBU_request_data;
			
			qmi_request_wms_get_store_max_size->storage_type = WMS_STORAGE_TYPE_NV_V01;

			qmi_request_wms_get_store_max_size->message_mode_valid = TRUE;
			qmi_request_wms_get_store_max_size->message_mode = WMS_MESSAGE_MODE_GW_V01;
		}
		break;

	//voice
	case DUBU_req_type_voice_dial_call:
		{
			voice_dial_call_req_msg_v02* qmi_request_voice_dial_call = (voice_dial_call_req_msg_v02*)qmi_request_message;
			DUBU_request_voice_dial_call_s* DUBU_request_voice_dial_call = (DUBU_request_voice_dial_call_s*)DUBU_request_data;
			
			strcpy( qmi_request_voice_dial_call->calling_number, DUBU_request_voice_dial_call->number );
		}
		break;
	
	default:
		{
			log_error( "invalid DUBU_request_type:[%d]", DUBU_request_type );
			
			mem_free( qmi_request_message );
			return NULL;
		}
		break;
	}

	log_med( "ok!" );

	return qmi_request_message;
}

//==============================================================
//
//==============================================================
const void* const DUBU_qmi_request_sync( const DUBU_request_type_e DUBU_request_type, const void* const interface_request_data )
{
	void* qmi_request_message = interface_request_data;
	void* qmi_response_message = NULL;
	qmi_request_messsage_id_info_s* qmi_request_message_id_info = NULL;
	qmi_request_message_info_s* qmi_request_message_info = NULL; 

	//
	qmi_request_message_id_info = DUBU_qmi_get_qmi_request_message_id_info( DUBU_request_type );

	if ( NULL == qmi_request_message_id_info )
	{
		log_error( "qmi_request_message_id_info is null" );
		return NULL;
	}

	qmi_request_message_info = qmi_get_qmi_request_message_info( qmi_request_message_id_info->qmi_service_id, qmi_request_message_id_info->qmi_request_message_id );
	
	if ( NULL == qmi_request_message_info )
	{
		log_error( "qmi_request_message_info is null" );
		return NULL;
	}
	
	qmi_response_message = mem_alloc( qmi_request_message_info->qmi_response_message_size );
	
	if ( NULL == qmi_response_message )
	{
		log_error( "qmi_response_message allocation fail, DUBU_request_type:[%d], DUBU_response_data_size:[%d]", DUBU_request_type, qmi_request_message_info->qmi_response_message_size );
		return NULL;
	}

	memset( qmi_response_message, 0, qmi_request_message_info->qmi_response_message_size );
	
	if ( FALSE == qmi_core_request_sync( qmi_request_message_info->qmi_service_id, 
																					qmi_request_message_info->qmi_request_message_id, 
																					qmi_request_message, 
																					qmi_response_message ) )
	{
		log_error( "qmi_core_request_sync() fail" );
		
		mem_free( qmi_response_message );
		return NULL;
	}
	
	log_med( "ok!" );

	return qmi_response_message;
}

//==============================================================
//
//==============================================================
void qmi_async_callback( const qmi_client_handle_type const qmi_client_handle,
															const qmi_service_id_type qmi_service_id,
															const void* const user_data,
															const unsigned int qmi_response_message_id, 
															const void* const qmi_response_message )
{
	if ( NULL == qmi_response_message )
	{
		log_error( "qmi_response_message is null" );
		return;
	}
	
	log_med( "qmi_response_message_id:[0x%08x]", qmi_response_message_id );
	
	m_DUBU_qmi_callback.response( DUBU_qmi_get_DUBU_request_type( qmi_service_id, qmi_response_message_id ), qmi_response_message, user_data );
}

//==============================================================
//
//==============================================================
int DUBU_qmi_request_async( const DUBU_request_type_e DUBU_request_type, const void* const interface_request_data, const void* const user_data )
{
	void* qmi_request_message = interface_request_data;
	qmi_request_messsage_id_info_s* qmi_request_message_id_info = NULL;
	qmi_request_message_info_s* qmi_request_message_info = NULL; 

	qmi_request_message_id_info = DUBU_qmi_get_qmi_request_message_id_info( DUBU_request_type );

	if ( NULL == qmi_request_message_id_info )
	{
		log_error( "qmi_request_message_id_info is null" );
		return NULL;
	}

	qmi_request_message_info = qmi_get_qmi_request_message_info( qmi_request_message_id_info->qmi_service_id, qmi_request_message_id_info->qmi_request_message_id );
	
	if ( NULL == qmi_request_message_info )
	{
		log_error( "qmi_request_message_info is null" );
		return NULL;
	}
	
	if ( FALSE == qmi_core_request_async( qmi_request_message_info->qmi_service_id, 
																						qmi_request_message_info->qmi_request_message_id, 
																						qmi_request_message, 
																						qmi_async_callback, 
																						user_data ) )
	{
		log_error( "qmi_core_request_async() fail" );
		return FALSE;
	}
	
	log_med( "ok!" );
	
	return TRUE;
}

//==============================================================
//
//==============================================================
const void* const DUBU_qmi_create_DUBU_response_data( const DUBU_request_type_e DUBU_request_type, const void* const interface_response_data )
{
	void*	DUBU_response_data = NULL;
	
	DUBU_request_data_info_s* DUBU_request_data_info = DUBU_get_DUBU_request_data_info( DUBU_request_type );

	qmi_response_type_v01* 	qmi_response_message_base = NULL;
	DUBU_response_base_s* 	DUBU_response_base = NULL;

	//
	if ( NULL == DUBU_request_data_info )
	{
		log_error( "DUBU_request_data_info is null, DUBU_request_type:[%d]", DUBU_request_type );
		return NULL;
	}
	
	DUBU_response_data = mem_alloc( DUBU_request_data_info->DUBU_response_data_size );

	if ( NULL == DUBU_response_data )
	{
		log_error( "DUBU_response_data allocation fail, DUBU_request_type:[%d], DUBU_response_data_size:[%d]", DUBU_request_type, DUBU_request_data_info->DUBU_response_data_size );
		return NULL;
	}

	memset( DUBU_response_data, 0, DUBU_request_data_info->DUBU_response_data_size );
	
	qmi_response_message_base = (qmi_response_type_v01*)interface_response_data;
	DUBU_response_base = (DUBU_response_base_s*)DUBU_response_data;
	
	if ( QMI_RESULT_SUCCESS_V01 == qmi_response_message_base->result )
	{
		DUBU_response_base->DUBU_response_result = DUBU_response_result_success;
	}
	else
	{
		DUBU_response_base->DUBU_response_result = DUBU_response_result_fail;
		DUBU_response_base->error = qmi_response_message_base->error;
	}	

	switch ( DUBU_request_type )
	{
	//sms
	case DUBU_req_type_wms_send_sms:
		{
			wms_raw_send_resp_msg_v01* qmi_response_wms_send_sms = (wms_raw_send_resp_msg_v01*)interface_response_data;
			DUBU_response_wms_send_sms_s* DUBU_response_wms_send_sms = (DUBU_response_wms_send_sms_s*)DUBU_response_data;
			
			DUBU_response_wms_send_sms->message_id = qmi_response_wms_send_sms->message_id;

			if ( TRUE == qmi_response_wms_send_sms->cause_code_valid )
				DUBU_response_wms_send_sms->cause_code = qmi_response_wms_send_sms->cause_code;
			else
				DUBU_response_wms_send_sms->cause_code = WMS_INVALID_CAUSE_CODE;

			if ( TRUE == qmi_response_wms_send_sms->gw_cause_info_valid )
			{
				DUBU_response_wms_send_sms->gw_tp_cause = qmi_response_wms_send_sms->gw_cause_info.tp_cause;
				DUBU_response_wms_send_sms->gw_rp_cause = qmi_response_wms_send_sms->gw_cause_info.rp_cause;
			}
			else
			{
				DUBU_response_wms_send_sms->gw_tp_cause = WMS_INVALID_GW_TP_CAUSE;
				DUBU_response_wms_send_sms->gw_rp_cause = WMS_INVALID_GW_RP_CAUSE;
			}
		}
		break;

     case DUBU_req_type_wms_send_sms_pdu:
        {
			wms_raw_send_resp_msg_v01* qmi_response_wms_send_sms = (wms_raw_send_resp_msg_v01*)interface_response_data;
			DUBU_response_wms_send_sms_pdu_s* DUBU_response_wms_send_sms = (DUBU_response_wms_send_sms_pdu_s*)DUBU_response_data;
			
			DUBU_response_wms_send_sms->message_id = qmi_response_wms_send_sms->message_id;

			if ( TRUE == qmi_response_wms_send_sms->cause_code_valid )
				DUBU_response_wms_send_sms->cause_code = qmi_response_wms_send_sms->cause_code;
			else
				DUBU_response_wms_send_sms->cause_code = WMS_INVALID_CAUSE_CODE;

			if ( TRUE == qmi_response_wms_send_sms->gw_cause_info_valid )
			{
				DUBU_response_wms_send_sms->gw_tp_cause = qmi_response_wms_send_sms->gw_cause_info.tp_cause;
				DUBU_response_wms_send_sms->gw_rp_cause = qmi_response_wms_send_sms->gw_cause_info.rp_cause;
			}
			else
			{
				DUBU_response_wms_send_sms->gw_tp_cause = WMS_INVALID_GW_TP_CAUSE;
				DUBU_response_wms_send_sms->gw_rp_cause = WMS_INVALID_GW_RP_CAUSE;
			}
		}
        break;
  
	case DUBU_req_type_wms_delete_sms:
		{
		}
		break;
	
	case DUBU_req_type_wms_read_sms:
		{
			wms_raw_read_resp_msg_v01* qmi_response_wms_read_sms = (wms_raw_read_resp_msg_v01*)interface_response_data;
			DUBU_response_wms_read_sms_s* DUBU_response_wms_read_sms = (DUBU_response_wms_read_sms_s*)DUBU_response_data;
	
			if ( QMI_RESULT_SUCCESS_V01 == qmi_response_wms_read_sms->resp.result )
			{
				switch ( qmi_response_wms_read_sms->raw_message_data.format )
				{
			  case WMS_MESSAGE_FORMAT_CDMA_V01:			DUBU_response_wms_read_sms->raw_message_data.format = WMS_FORMAT_CDMA;		break;
			  case WMS_MESSAGE_FORMAT_GW_PP_V01:		DUBU_response_wms_read_sms->raw_message_data.format = WMS_FORMAT_GW_PP;		break; 
			  case WMS_MESSAGE_FORMAT_GW_BC_V01:		DUBU_response_wms_read_sms->raw_message_data.format = WMS_FORMAT_GW_CB;		break; 
			  case WMS_MESSAGE_FORMAT_MWI_V01:			DUBU_response_wms_read_sms->raw_message_data.format = WMS_FORMAT_MWI;			break;
				default:
					{
						log_error( "invalid format:[%d]", qmi_response_wms_read_sms->raw_message_data.format );

						mem_free( DUBU_response_data );
						return NULL;
					}
					break;
				}

				//DUBU_response_wms_data->raw_sms_data.tpdu_type = 

				if ( WMS_MESSAGE_FORMAT_GW_PP_V01 == qmi_response_wms_read_sms->raw_message_data.format )
				{
					//entry data of raw_message_data is smsc data
					//the 1'st octet of smsc data is smsc data length
					//we don't use smsc data, so check smsc data length and skip it
					unsigned char smsc_data_length = qmi_response_wms_read_sms->raw_message_data.data[ 0 ];
					unsigned int smsc_data_pdu_length = smsc_data_length + sizeof( smsc_data_length );

					memcpy( DUBU_response_wms_read_sms->raw_message_data.data, 
									( qmi_response_wms_read_sms->raw_message_data.data + smsc_data_pdu_length ),
									qmi_response_wms_read_sms->raw_message_data.data_len - smsc_data_pdu_length );

					DUBU_response_wms_read_sms->raw_message_data.len = qmi_response_wms_read_sms->raw_message_data.data_len - smsc_data_pdu_length;
				#ifdef FEATURE_DEBUG_LOG
					log_low( "remove smsc_data_pdu, smsc_data_pdu_length:[%d], DUBU_response_wms_data->raw_message_data.len:[%d]", 
																											smsc_data_pdu_length, DUBU_response_wms_read_sms->raw_message_data.len );
					log_binary_data( DUBU_response_wms_read_sms->raw_message_data.data, DUBU_response_wms_read_sms->raw_message_data.len );
				#endif
				}
			}
		}
		break;
	
	case DUBU_req_type_wms_list_sms:
		{
			wms_list_messages_resp_msg_v01* qmi_response_wms_list_sms = (wms_list_messages_resp_msg_v01*)interface_response_data;
		  DUBU_response_wms_list_sms_s* DUBU_response_wms_list_sms = (DUBU_response_wms_list_sms_s*)DUBU_response_data;
			
			if ( QMI_RESULT_SUCCESS_V01 == qmi_response_wms_list_sms->resp.result )
			{
				unsigned int i = 0;
			
				DUBU_response_wms_list_sms->message_info_num = qmi_response_wms_list_sms->message_tuple_len;
				
				for ( i = 0; i < qmi_response_wms_list_sms->message_tuple_len; ++i )
				{
					DUBU_response_wms_list_sms->message_info[ i ].message_index = qmi_response_wms_list_sms->message_tuple[ i ].message_index;
					DUBU_response_wms_list_sms->message_info[ i ].message_tag_type = qmi_response_wms_list_sms->message_tuple[ i ].tag_type;
				}		
			}
		}
		break;
	
	case DUBU_req_type_wms_get_smsc_address:
		{
			wms_get_smsc_address_resp_msg_v01* qmi_response_wms_get_smsc_address = (wms_get_smsc_address_resp_msg_v01*)interface_response_data;
		  DUBU_response_wms_get_smsc_address_s* DUBU_response_wms_smsc_address = (DUBU_response_wms_get_smsc_address_s*)DUBU_response_data;
			
			if ( QMI_RESULT_SUCCESS_V01 == qmi_response_wms_get_smsc_address->resp.result )
			{
				DUBU_response_wms_smsc_address->smsc_address_digits_length = qmi_response_wms_get_smsc_address->smsc_address.smsc_address_digits_len;
				memcpy( DUBU_response_wms_smsc_address->smsc_address_digits, qmi_response_wms_get_smsc_address->smsc_address.smsc_address_digits, qmi_response_wms_get_smsc_address->smsc_address.smsc_address_digits_len );
			}
		}
		break;
	
	case DUBU_req_type_wms_set_smsc_address:
		{
		}
		break;
	
	case DUBU_req_type_wms_get_memory_status:
		{
			wms_get_store_max_size_resp_msg_v01* qmi_response_wms_get_store_max_size = (wms_get_store_max_size_resp_msg_v01*)interface_response_data;
		  DUBU_response_wms_get_memory_status_s* DUBU_response_wms_get_memory_status = (DUBU_response_wms_list_sms_s*)DUBU_response_data;

			if ( QMI_RESULT_SUCCESS_V01 == qmi_response_wms_get_store_max_size->resp.result )
			{
				if ( TRUE == qmi_response_wms_get_store_max_size->free_slots_valid )
				{
					if ( qmi_response_wms_get_store_max_size->free_slots > 0 )
					{
						DUBU_response_wms_get_memory_status->memory_available = TRUE;
					}
					else
					{
						DUBU_response_wms_get_memory_status->memory_available = FALSE;
					}
				}
				else
				{
					DUBU_response_wms_get_memory_status->memory_available = FALSE;
				}
			}
		}
		break;

	//voice
	case DUBU_req_type_voice_dial_call:
		{
		}
		break;
	
	default:
		{
			log_error( "invalid DUBU_request_type:[%d]", DUBU_request_type );

			mem_free( DUBU_response_data );
			return NULL;
		}
		break;
	}

	log_med( "ok!" );

	return DUBU_response_data;
}

//==============================================================
//
//==============================================================
const void* const DUBU_qmi_indication_create_DUBU_indication_data( const DUBU_indication_type_e DUBU_indication_type, const void* const interface_indication_data )
{
	void* DUBU_indication_data = NULL;
	DUBU_indication_data_info_s* DUBU_indication_data_info = DUBU_get_DUBU_indication_data_info( DUBU_indication_type );

	if ( NULL == DUBU_indication_data_info )
	{
		log_error( "DUBU_indication_data_info is null, DUBU_indication_type:[%d]", DUBU_indication_type );
	}

	DUBU_indication_data = mem_alloc( DUBU_indication_data_info->DUBU_indication_data_size );

	if ( NULL == DUBU_indication_data )
	{
		log_error( "DUBU_indication_data allocation fail, DUBU_indication_type:[%d], DUBU_indication_data_size:[%d]", DUBU_indication_type, DUBU_indication_data_info->DUBU_indication_data_size );
		return NULL;
	}

	memset( DUBU_indication_data, 0, DUBU_indication_data_info->DUBU_indication_data_size );
	
	switch ( DUBU_indication_type )
	{
	case DUBU_ind_type_wms_new_sms:
		{
			wms_event_report_ind_msg_v01* qmi_indication_wms_response_new_sms = (wms_event_report_ind_msg_v01*)interface_indication_data;
			DUBU_indication_wms_new_sms_s* DUBU_indication_wms_new_sms = (DUBU_indication_wms_new_sms_s*)DUBU_indication_data;	
			
			DUBU_indication_wms_new_sms->message_index = qmi_indication_wms_response_new_sms->mt_message.storage_index;
		}
		break;

	case DUBU_ind_type_voice_all_call_status:
		{
		}
		break;
	
	default:
		{
			log_error( "invalid DUBU_indication_type:[%d]", DUBU_indication_type );

			mem_free( DUBU_indication_data );
			return NULL;
		}
		break;
	}

	log_med( "ok!" );

	return DUBU_indication_data;
}



//**************************************************************
// public function
//**************************************************************
//==============================================================
//
//==============================================================
void DUBU_qmi_export( DUBU_interface_s* DUBU_interface )
{
	DUBU_interface->init = DUBU_qmi_init;
	DUBU_interface->release = DUBU_qmi_release;
	DUBU_interface->request.create_interface_request_data = DUBU_qmi_create_qmi_request_message;
	DUBU_interface->request.request_sync = DUBU_qmi_request_sync;
	DUBU_interface->request.request_async = DUBU_qmi_request_async;
	DUBU_interface->request.create_DUBU_response_data = DUBU_qmi_create_DUBU_response_data;
	DUBU_interface->indication.create_DUBU_indication_data = DUBU_qmi_indication_create_DUBU_indication_data;
}




