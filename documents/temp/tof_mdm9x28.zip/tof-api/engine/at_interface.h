#ifndef AT_INTERFACE_H
#define AT_INTERFACE_H



#include "engine.h"



#ifdef __cplusplus
extern "C" {
#endif



//**************************************************************
// public function
//**************************************************************
void DUBU_at_export( DUBU_interface_s* DUBU_interface );



#ifdef __cplusplus
}
#endif



#endif
