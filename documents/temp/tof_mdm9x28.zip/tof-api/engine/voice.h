#ifndef VOICE_ENGINE_H
#define VOICE_ENGINE_H



#include "engine.h"



#ifdef __cplusplus
extern "C" {
#endif



//**************************************************************
// public member
//**************************************************************
#define VOICE_NUMBER_LEN_MAX				(81)
//
typedef struct
{
	unsigned char number[ VOICE_NUMBER_LEN_MAX ];
} DUBU_request_voice_dial_call_s;

typedef struct
{
	DUBU_response_base_s DUBU_response_base;
} DUBU_response_voice_dial_call_s;

//
typedef struct
{
} DUBU_indication_voice_all_call_status_s;




//**************************************************************
// public function
//**************************************************************



#ifdef __cplusplus
}
#endif



#endif

