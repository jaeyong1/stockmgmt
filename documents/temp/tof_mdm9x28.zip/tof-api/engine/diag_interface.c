



#include "diag_interface.h"



//**************************************************************
// private member
//**************************************************************



//**************************************************************
// public member
//**************************************************************



//**************************************************************
// private function
//**************************************************************
int DUBU_diag_init( const DUBU_interface_init_info_s* const DUBU_interface_init_info )
{
  return TRUE;
}

void DUBU_diag_release( void )
{
}

const void* const DUBU_diag_create_diag_request_message( const DUBU_request_type_e DUBU_request_type, const void* const DUBU_request_data )
{
	return NULL;
}

const void* const DUBU_diag_request_sync( const DUBU_request_type_e DUBU_request_type, const void* const interface_request_data )
{
	return NULL;
}

int 							DUBU_diag_request_async( const DUBU_request_type_e DUBU_request_type, const void* const interface_request_data, const void* const user_data )
{
	return TRUE;
}

const void* const DUBU_diag_create_DUBU_response_data( const DUBU_request_type_e DUBU_request_type, const void* const interface_response_data )
{
	return NULL;
}

const void* const DUBU_diag_indication_create_DUBU_indication_data( const DUBU_indication_type_e DUBU_indication_type, const void* const interface_indication_data )
{
	return NULL;
}



//**************************************************************
// public function
//**************************************************************
void DUBU_diag_export( DUBU_interface_s* DUBU_interface )
{
	DUBU_interface->init = DUBU_diag_init;
	DUBU_interface->release = DUBU_diag_release;
	DUBU_interface->request.create_interface_request_data = DUBU_diag_create_diag_request_message;
	DUBU_interface->request.request_sync = DUBU_diag_request_sync;
	DUBU_interface->request.request_async = DUBU_diag_request_async;
	DUBU_interface->request.create_DUBU_response_data = DUBU_diag_create_DUBU_response_data;
	DUBU_interface->indication.create_DUBU_indication_data = DUBU_diag_indication_create_DUBU_indication_data;
}




