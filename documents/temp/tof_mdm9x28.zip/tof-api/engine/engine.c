



#include "wms.h"
#include "voice.h"
#include "engine.h"



//**************************************************************
// private member
//**************************************************************
DUBU_request_data_info_s		m_DUBU_request_data_info_table[] =
{
	//sms
	{ DUBU_req_type_wms_send_sms, 					sizeof( DUBU_request_wms_send_sms_s ), 						sizeof( DUBU_response_wms_send_sms_s ), 						DUBU_cmd_request_wms_send_sms,						DUBU_cmd_response_wms_send_sms },
	{ DUBU_req_type_wms_delete_sms, 				sizeof( DUBU_request_wms_delete_sms_s ), 					sizeof( DUBU_response_wms_delete_sms_s ), 					DUBU_cmd_request_wms_delete_sms,					DUBU_cmd_response_wms_delete_sms },
	{ DUBU_req_type_wms_read_sms,						sizeof( DUBU_request_wms_read_sms_s ),						sizeof( DUBU_response_wms_read_sms_s ), 						DUBU_cmd_request_wms_read_sms,						DUBU_cmd_response_wms_read_sms },				
	{ DUBU_req_type_wms_list_sms,						sizeof( DUBU_request_wms_list_sms_s ),						sizeof( DUBU_response_wms_list_sms_s ), 						DUBU_cmd_request_wms_list_sms,						DUBU_cmd_response_wms_list_sms },
	{ DUBU_req_type_wms_get_smsc_address, 	sizeof( DUBU_request_wms_get_smsc_address_s ),		sizeof( DUBU_response_wms_get_smsc_address_s ), 		DUBU_cmd_request_wms_get_smsc_address,		DUBU_cmd_response_wms_get_smsc_address },
	{ DUBU_req_type_wms_set_smsc_address, 	sizeof( DUBU_request_wms_set_smsc_address_s ),		sizeof( DUBU_response_wms_set_smsc_address_s ), 		DUBU_cmd_request_wms_set_smsc_address,		DUBU_cmd_response_wms_set_smsc_address },
	{ DUBU_req_type_wms_get_memory_status,	sizeof( DUBU_request_wms_get_memory_status_s ), 	sizeof( DUBU_response_wms_get_memory_status_s ),		DUBU_cmd_request_wms_get_memory_status,		DUBU_cmd_response_wms_get_memory_status },
    { DUBU_req_type_wms_send_sms_pdu, 					sizeof( DUBU_request_wms_send_sms_pdu_s ), 						sizeof( DUBU_response_wms_send_sms_pdu_s ), 						DUBU_cmd_request_wms_send_sms_pdu,						DUBU_cmd_response_wms_send_sms_pdu },
	//voice	
	{ DUBU_req_type_voice_dial_call,				sizeof( DUBU_request_voice_dial_call_s ), 				sizeof( DUBU_response_voice_dial_call_s ),					DUBU_cmd_request_voice_dial_call,					DUBU_cmd_response_voice_dial_call }
};

DUBU_indication_data_info_s	m_DUBU_indication_data_info_table[] =
{
	//sms
	{ DUBU_ind_type_wms_new_sms, sizeof( DUBU_indication_wms_new_sms_s ), DUBU_cmd_ind_response_wms_new_sms },
	//voice
	{ DUBU_ind_type_voice_all_call_status, sizeof( DUBU_indication_voice_all_call_status_s ), DUBU_cmd_ind_response_voice_all_call_status }
};



DUBU_s			m_DUBU;



//**************************************************************
// public member
//**************************************************************



//**************************************************************
// private function
//**************************************************************
//==============================================================
//
//==============================================================
int	is_valid_DUBU_request_type( DUBU_request_type_e DUBU_request_type )
{
	if( NULL == DUBU_get_DUBU_request_data_info( DUBU_request_type ) )
	{
		log_error( "invalid DUBU_request_type:[%d]", DUBU_request_type );
		return FALSE;
	}
	
	return TRUE;
}

//==============================================================
//
//==============================================================
int	is_valid_DUBU_indication_type( DUBU_indication_type_e DUBU_indication_type )
{
	if ( NULL == DUBU_get_DUBU_indication_data_info( DUBU_indication_type ) )
	{
		log_error( "invalid DUBU_indication_type:[%d]", DUBU_indication_type );
		return FALSE;
	}

	return TRUE;
}

//==============================================================
//
//==============================================================
const	DUBU_request_type_e DUBU_get_DUBU_request_type( const DUBU_command_id_e DUBU_command_id )
{
	unsigned int i = 0;

	for ( i = 0; i < sizeof( m_DUBU_request_data_info_table ) / sizeof( DUBU_request_data_info_s ); ++i )
	{
		if ( DUBU_command_id == m_DUBU_request_data_info_table[ i ].request_DUBU_command_id || DUBU_command_id == m_DUBU_request_data_info_table[ i ].response_DUBU_command_id )
			return m_DUBU_request_data_info_table[ i ].DUBU_request_type;
	}

	return invalid_DUBU_request_type;
}

//==============================================================
//
//==============================================================
const DUBU_indication_type_e DUBU_get_DUBU_indication_type( const DUBU_command_id_e DUBU_command_id )
{
	unsigned int i;

	for ( i = 0; i < sizeof( m_DUBU_indication_data_info_table ) / sizeof( DUBU_indication_data_info_s ); ++i )
	{
		if ( DUBU_command_id == m_DUBU_indication_data_info_table[ i ].DUBU_indication_command_id )
			return m_DUBU_indication_data_info_table[ i ].DUBU_indication_type;
	}

	return invalid_DUBU_indication_type;
}

//==============================================================
//
//==============================================================
void DUBU_interface_callback_response( const DUBU_request_type_e DUBU_request_type, const void* const interface_response_data, const void* const user_data )
{
	void* DUBU_response_data = NULL;

	unsigned int		user_data_size = 0;

	DUBU_request_data_info_s* DUBU_request_data_info = NULL;

	unsigned char* 	DUBU_command_data = NULL;
	unsigned int		DUBU_command_data_size = 0;
	
	//
	if ( FALSE == is_valid_DUBU_request_type( DUBU_request_type ) || NULL == interface_response_data )
	{
		log_error( "invalid argument, DUBU_request_type:[%d], interface_response_data:[%d], user_data:[%d]", DUBU_request_type, interface_response_data, user_data );
		return FALSE;
	}
	
	DUBU_response_data = m_DUBU.DUBU_interface.request.create_DUBU_response_data( DUBU_request_type, interface_response_data );

	if ( NULL == DUBU_response_data )
	{
		log_error( "DUBU_response_data is null, DUBU_request_type:[%d]", DUBU_request_type );
		return;
	}
	
	user_data_size = sizeof( user_data );
	DUBU_request_data_info = DUBU_get_DUBU_request_data_info( DUBU_request_type );

	DUBU_command_data_size = DUBU_request_data_info->DUBU_response_data_size + user_data_size;
	DUBU_command_data = (unsigned char*)mem_alloc( DUBU_command_data_size );

	if ( NULL == DUBU_command_data )
	{
		mem_free( DUBU_response_data );
		
		log_error( "DUBU_command_data allocation fail, DUBU_request_type:[%d]", DUBU_request_type );
		return;
	}

	memcpy( DUBU_command_data, DUBU_response_data, DUBU_request_data_info->DUBU_response_data_size );
	memcpy( DUBU_command_data + DUBU_request_data_info->DUBU_response_data_size, &user_data, user_data_size );

	if ( invalid_queue_data_id == command_processor_command_request( DUBU_request_data_info->response_DUBU_command_id, DUBU_command_data, DUBU_command_data_size ) )
	{
		mem_free( DUBU_command_data );
		mem_free( DUBU_response_data );
	
		log_error( "command_processor_command_request() fail, DUBU_request_type:[%d], user_data_size:[%d], DUBU_req_data_size:[%d], DUBU_command_data_size:[%d]", 
										DUBU_request_type, user_data_size, DUBU_request_data_info->DUBU_request_data_size, DUBU_command_data_size );	
		return;
	}

	mem_free( DUBU_command_data );
	mem_free( DUBU_response_data );
	
	log_med( "ok! DUBU_request_type:[%d], user_data_size:[%d], DUBU_req_data_size:[%d], DUBU_command_data_size:[%d]", 
									DUBU_request_type, user_data_size, DUBU_request_data_info->DUBU_request_data_size, DUBU_command_data_size );	
}

//==============================================================
//
//==============================================================
void DUBU_interface_callback_indication( const DUBU_indication_type_e DUBU_indication_type, const void* const interface_indication_data )
{
	void* DUBU_indication_data = NULL;
	DUBU_indication_data_info_s* DUBU_indication_data_info = NULL;

	//
	if ( FALSE == is_valid_DUBU_indication_type( DUBU_indication_type ) || NULL == interface_indication_data )
	{
		log_error( "invalid argument, DUBU_indication_type:[%d], interface_indication_data:[%d]", DUBU_indication_type, interface_indication_data );
		return FALSE;
	}

	DUBU_indication_data = m_DUBU.DUBU_interface.indication.create_DUBU_indication_data( DUBU_indication_type, interface_indication_data );

	if ( NULL == DUBU_indication_data )
	{
		log_error( "DUBU_indication_data is null, DUBU_indication_type:[%d]", DUBU_indication_type );
		return;
	}
	
	DUBU_indication_data_info = DUBU_get_DUBU_indication_data_info( DUBU_indication_type );

	if ( invalid_queue_data_id == command_processor_command_request( DUBU_indication_data_info->DUBU_indication_command_id, DUBU_indication_data, DUBU_indication_data_info->DUBU_indication_data_size ) )
	{
		mem_free( DUBU_indication_data );

		log_error( "command_processor_command_request() fail, DUBU_indication_type:[%d], DUBU_ind_data_size:[%d]", DUBU_indication_type, DUBU_indication_data_info->DUBU_indication_data_size );
		return;
	}

	mem_free( DUBU_indication_data );	

	log_med( "ok! DUBU_indication_type:[%d], DUBU_ind_data_size:[%d]", DUBU_indication_type, DUBU_indication_data_info->DUBU_indication_data_size );
}

//==============================================================
//
//==============================================================
int DUBU_command_handler( const command_id_type DUBU_command_id, const queue_data_id_type data_id, const unsigned char* const data, const unsigned int data_size )
{
	log_med( "processing.... DUBU_command_id:[%d], data_id:[%d], data_size:[%d]", DUBU_command_id, data_id, data_size );

	if ( ( DUBU_command_id & DUBU_cmd_request_mask ) == DUBU_command_id )
	{
		int r = FALSE;
		
		DUBU_request_type_e					DUBU_request_type = invalid_DUBU_request_type;
		DUBU_request_data_info_s* 	DUBU_request_data_info = NULL;
		unsigned char* 							DUBU_request_data = NULL;

		void*					user_data = NULL;
		unsigned int 	user_data_size = 0;
		
		void* interface_request_data = NULL;

		//
		DUBU_request_type = DUBU_get_DUBU_request_type( DUBU_command_id );
		DUBU_request_data_info = DUBU_get_DUBU_request_data_info( DUBU_request_type );
		DUBU_request_data = data;

		user_data_size = sizeof( user_data );
		memcpy( &user_data, ( DUBU_request_data + DUBU_request_data_info->DUBU_request_data_size ), user_data_size );
		
		interface_request_data = m_DUBU.DUBU_interface.request.create_interface_request_data( DUBU_request_type, DUBU_request_data );

		if ( NULL == interface_request_data )
		{
			r = FALSE;
			
			log_error( "interface_request_data allocation fail" );
		}
		else
		{
			r = m_DUBU.DUBU_interface.request.request_async( DUBU_request_type, interface_request_data, user_data );
			
			mem_free( interface_request_data );
		}

		if ( TRUE == r )
		{
			log_med( "m_DUBU.DUBU_interface.request.request_async() ok! DUBU_command_id:[%d], DUBU_request_type:[%d], DUBU_request_data_size:[%d], user_data_size:[%d], DUBU_command_data_size:[%d]", 
															DUBU_command_id, DUBU_request_type, DUBU_request_data_info->DUBU_request_data_size, user_data_size, data_size );
		}
		else
		{
			unsigned char* 	DUBU_command_data = NULL;
			unsigned int		DUBU_command_data_size = 0;

			//
			DUBU_command_data_size = DUBU_request_data_info->DUBU_response_data_size + user_data_size;
			DUBU_command_data = (unsigned char*)mem_alloc( DUBU_command_data_size );
			
			if ( NULL == DUBU_command_data )
			{
				log_error( "DUBU_command_data allocation fail" );
			}
			else
			{
				memset( DUBU_command_data, 0, DUBU_command_data_size );
				
				( (DUBU_response_base_s*)DUBU_command_data )->DUBU_response_result = DUBU_response_result_fail;
				( (DUBU_response_base_s*)DUBU_command_data )->error = 0;
				
				memcpy( DUBU_command_data + DUBU_request_data_info->DUBU_response_data_size, &user_data, user_data_size );
				
				if ( invalid_queue_data_id == command_processor_command_request( DUBU_request_data_info->response_DUBU_command_id, DUBU_command_data, DUBU_command_data_size ) )
				{
					log_error( "command_processor_command_request() fail" );
				}
				
				mem_free( DUBU_command_data );
				
				log_error( "fail, response_DUBU_command_id:[%d], DUBU_command_data_size:[%d], user_data_size:[%d]", 
																		DUBU_request_data_info->response_DUBU_command_id, DUBU_command_data_size, user_data_size );
			}
		}
	}
	else
	if ( ( DUBU_command_id & DUBU_cmd_response_mask ) == DUBU_command_id )
	{
		DUBU_request_type_e					DUBU_request_type = invalid_DUBU_request_type;
		DUBU_request_data_info_s* 	DUBU_request_data_info = NULL;
		
		unsigned char*	user_data_DUBU_response_data = NULL;
		void* 					user_data = NULL;

		sync_object_index_type	sync_object_index = invalid_sync_object_index;

		//
		DUBU_request_type = DUBU_get_DUBU_request_type( DUBU_command_id );
		DUBU_request_data_info = DUBU_get_DUBU_request_data_info( DUBU_request_type );
		
		memcpy( &user_data, ( data + DUBU_request_data_info->DUBU_response_data_size ), sizeof( user_data ) );

		sync_object_index = user_data;

		if ( TRUE == sync_manager_get_enter_sync_object_user_data( sync_object_index, &user_data_DUBU_response_data ) )
		{
			void* DUBU_response_data = data;

			//
			memcpy( user_data_DUBU_response_data, DUBU_response_data, DUBU_request_data_info->DUBU_response_data_size );

			if ( NULL != m_DUBU.DUBU_info.DUBU_callback_response[ DUBU_get_DUBU_request_type( DUBU_command_id ) ] )
			{
				m_DUBU.DUBU_info.DUBU_callback_response[ DUBU_get_DUBU_request_type( DUBU_command_id ) ]( user_data_DUBU_response_data, user_data );
			}
			
			sync_manager_leave_sync( sync_object_index );
		}
		else
		{
			//
			log_error( "sync_manager_get_enter_sync_object_user_data() fail, sync_object_index:[%d]", sync_object_index );
		}
	}
	else
	if ( ( DUBU_command_id & DUBU_cmd_ind_mask ) == DUBU_command_id )
	{
		void* DUBU_indication_data = data;

		//
		if( NULL != m_DUBU.DUBU_info.DUBU_callback_indication[ DUBU_get_DUBU_indication_type( DUBU_command_id ) ] )
		{
			m_DUBU.DUBU_info.DUBU_callback_indication[ DUBU_get_DUBU_indication_type( DUBU_command_id ) ]( DUBU_indication_data );
		}
	}
	else
	{
		log_error( "invalid DUBU_command_id:[%d]", DUBU_command_id );
		return FALSE;
	}
	
	return TRUE;
}



//**************************************************************
// public function
//**************************************************************
//==============================================================
//
//==============================================================
int DUBU_init( const DUBU_info_s* const DUBU_info )
{
	DUBU_interface_init_info_s DUBU_interface_init_info;
	sync_manager_init_info_s sync_manager_init_info;

	memset( &DUBU_interface_init_info, 0, sizeof( DUBU_interface_init_info ) );
	memset( &m_DUBU, 0, sizeof( m_DUBU ) );

	//
	if ( FALSE == command_processor_init( DUBU_command_handler ) )
	{
		DUBU_release();

		log_error( "command_processor_init() fail" );
		return FALSE;
	}

	sync_manager_init_info.max_sync_object_num = sync_manager_default_max_sync_object_num;
	sync_manager_init_info.max_sync_timeout_millisecond = sync_manager_default_sync_timeout_millisecond;
	sync_manager_init_info.use_garbage_collection = TRUE;

	if ( FALSE == sync_manager_init( &sync_manager_init_info ) )
	{
		DUBU_release();

		log_error( "sync_manager_init()" );
		return FALSE;
	}

	switch( DUBU_info->DUBU_interface_type )
	{
	case DUBU_interface_type_qmi:		DUBU_qmi_export( &m_DUBU.DUBU_interface );			break;
	case DUBU_interface_type_at: 		DUBU_at_export( &m_DUBU.DUBU_interface );				break;
	case DUBU_interface_type_diag:	DUBU_diag_export( &m_DUBU.DUBU_interface );			break;
	default:
		{
			DUBU_release();				

			log_error( "fail, invalid DUBU_interface_type:[%d]", DUBU_info->DUBU_interface_type );
			return FALSE;
		}
		break;
	}

	m_DUBU.DUBU_info = *DUBU_info;
	
	m_DUBU.DUBU_interface_callback.response = DUBU_interface_callback_response;
	m_DUBU.DUBU_interface_callback.indication = DUBU_interface_callback_indication;
	
	DUBU_interface_init_info.DUBU_interface_callback = m_DUBU.DUBU_interface_callback;
	
	if( FALSE == m_DUBU.DUBU_interface.init( &DUBU_interface_init_info ) )
	{
		DUBU_release();		

		log_error( "m_DUBU.DUBU_interface.init() fail" );
		return FALSE;
	}

	log_med( "ok!" );

	return TRUE;
}

//==============================================================
//
//==============================================================
void DUBU_release( void )
{
	if ( NULL == m_DUBU.DUBU_interface.release )
	{
		log_error( "m_DUBU.DUBU_interface.release is null" );
	}
	else
	{
		m_DUBU.DUBU_interface.release();
	}
	
	sync_manager_release();

	command_processor_release();
	
	memset( &m_DUBU, 0, sizeof( m_DUBU ) );

	log_med( "ok!" );
}

//==============================================================
//
//==============================================================
int DUBU_request_sync( const DUBU_request_type_e DUBU_request_type, const void* const DUBU_request_data, void* DUBU_response_data )
{
	void* interface_request_data = NULL;
	void* interface_response_data = NULL;

	void* temp_DUBU_response_data = NULL;

	if ( FALSE == is_valid_DUBU_request_type( DUBU_request_type ) || NULL == DUBU_request_data || NULL == DUBU_response_data )
	{
		log_error( "invalid argument, DUBU_request_type:[%d], DUBU_request_data:[%d], DUBU_response_data:[%d]", DUBU_request_type, DUBU_request_data, DUBU_response_data );
		return FALSE;
	}
	
	interface_request_data = m_DUBU.DUBU_interface.request.create_interface_request_data( DUBU_request_type, DUBU_request_data );

	if ( NULL == interface_request_data )
	{
		log_error( "interface_request_data is null, DUBU_request_type:[%d]", DUBU_request_type );
		return FALSE;
	}

	interface_response_data = m_DUBU.DUBU_interface.request.request_sync( DUBU_request_type, interface_request_data );

	mem_free( interface_request_data );

	if ( NULL == interface_response_data )
	{
		log_error( "interface_response_data is null, DUBU_request_type:[%d]", DUBU_request_type );
		return FALSE;
	}

	temp_DUBU_response_data = m_DUBU.DUBU_interface.request.create_DUBU_response_data( DUBU_request_type, interface_response_data );

	mem_free( interface_response_data );

	if ( NULL == temp_DUBU_response_data )
	{
		log_error( "temp_DUBU_response_data is null, DUBU_request_type:[%d]", DUBU_request_type );
		return FALSE;
	}

	memcpy( DUBU_response_data, temp_DUBU_response_data, DUBU_get_DUBU_request_data_info( DUBU_request_type )->DUBU_response_data_size );

	mem_free( temp_DUBU_response_data );

	log_med( "ok! DUBU_request_type:[%d]", DUBU_request_type );

	return TRUE;
}

//==============================================================
//
//==============================================================
int DUBU_request_async( const DUBU_request_type_e DUBU_request_type, const void* const DUBU_request_data, const void* const user_data )
{
	unsigned 				user_data_size = 0;
	
	DUBU_request_data_info_s* DUBU_request_data_info = NULL;

	unsigned char* 	DUBU_command_data = NULL;
	unsigned int		DUBU_command_data_size = 0;

	//
	if ( FALSE == is_valid_DUBU_request_type( DUBU_request_type ) || NULL == DUBU_request_data )
	{
		log_error( "invalid argument, DUBU_request_type:[%d], DUBU_request_data:[0x%08x], user_data:[%d]", DUBU_request_type, DUBU_request_data, user_data );
		return FALSE;
	}

	user_data_size = sizeof( user_data );
	DUBU_request_data_info = DUBU_get_DUBU_request_data_info( DUBU_request_type );
	
	DUBU_command_data_size = DUBU_request_data_info->DUBU_request_data_size + user_data_size;
	DUBU_command_data = (unsigned char*)mem_alloc( DUBU_command_data_size );

	if ( NULL == DUBU_command_data )
	{
		log_error( "DUBU_command_data allocation fail, DUBU_request_type:[%d]", DUBU_request_type );
		return FALSE;
	}

	//DUBU_request_data(var byte) + user_data(4 byte)
	memcpy( DUBU_command_data, DUBU_request_data, DUBU_request_data_info->DUBU_request_data_size );
	memcpy( DUBU_command_data + DUBU_request_data_info->DUBU_request_data_size, &user_data, user_data_size );
	
	if ( invalid_queue_data_id == command_processor_command_request( DUBU_request_data_info->request_DUBU_command_id, DUBU_command_data, DUBU_command_data_size ) )
	{
		mem_free( DUBU_command_data );
	
		log_error( "command_processor_command_request() fail, DUBU_request_type:[%d], user_data_size:[%d], DUBU_req_data_size:[%d], DUBU_command_data_size:[%d]", 
										DUBU_request_type, user_data_size, DUBU_request_data_info->DUBU_request_data_size, DUBU_command_data_size );
		
		return FALSE;
	}
	
	mem_free( DUBU_command_data );
	
	log_med( "ok! DUBU_request_type:[%d], user_data_size:[%d], DUBU_req_data_size:[%d], DUBU_command_data_size:[%d]", 
									DUBU_request_type, user_data_size, DUBU_request_data_info->DUBU_request_data_size, DUBU_command_data_size );
	
	return TRUE;	
}

//==============================================================
//
//==============================================================
int DUBU_request( const DUBU_request_type_e DUBU_request_type, const void* const DUBU_request_data, void* DUBU_response_data )
{
	sync_object_index_type sync_object_index = invalid_sync_object_index;

	//
	if ( FALSE == is_valid_DUBU_request_type( DUBU_request_type ) || NULL == DUBU_request_data || NULL == DUBU_response_data )
	{
		log_error( "invalid argument, DUBU_request_type:[%d], DUBU_request_data:[%d], DUBU_response_data:[%d]", DUBU_request_type, DUBU_request_data, DUBU_response_data );
		return FALSE;
	}
	
	if ( FALSE == sync_manager_enter_sync( DUBU_response_data, &sync_object_index ) )
	{
		log_error( "sync_manager_enter_sync() fail, DUBU_request_type:[%d]", DUBU_request_type );
		return FALSE;
	}

	if ( FALSE == DUBU_request_async( DUBU_request_type, DUBU_request_data, sync_object_index ) )
	{
		sync_manager_leave_sync( sync_object_index );
		sync_manager_wait_sync( sync_object_index );

		log_error( "DUBU_request_async() fail, DUBU_request_type:[%d], sync_object_index:[%d]", DUBU_request_type, sync_object_index );
		return FALSE;
	}

	if ( FALSE == sync_manager_wait_sync( sync_object_index ) )
	{
		log_error( "sync_manager_wait_sync() fail, DUBU_request_type:[%d], sync_object_index:[%d]", DUBU_request_type, sync_object_index );
		return FALSE;
	}

	log_med( "ok! DUBU_request_type:[%d], sync_object_index:[%d]", DUBU_request_type, sync_object_index );

	return TRUE;
}

//==============================================================
//
//==============================================================
const DUBU_request_data_info_s* const 			DUBU_get_DUBU_request_data_info( const DUBU_request_type_e DUBU_request_type )
{
	unsigned int i;

	for ( i = 0; i < sizeof( m_DUBU_request_data_info_table ) / sizeof( DUBU_request_data_info_s ); ++i )
	{
		if ( DUBU_request_type == m_DUBU_request_data_info_table[ i ].DUBU_request_type )
			return &( m_DUBU_request_data_info_table[ i ] );
	}

	return NULL;
}

//==============================================================
//
//==============================================================
const DUBU_indication_data_info_s* const 	DUBU_get_DUBU_indication_data_info( const DUBU_indication_type_e DUBU_indication_type )
{
	unsigned int i;

	for ( i = 0; i < sizeof( m_DUBU_indication_data_info_table ) / sizeof( DUBU_indication_data_info_s ); ++i )
	{
		if ( DUBU_indication_type == m_DUBU_indication_data_info_table[ i ].DUBU_indication_type )
			return &( m_DUBU_indication_data_info_table[ i ] );
	}

	return NULL;
}




