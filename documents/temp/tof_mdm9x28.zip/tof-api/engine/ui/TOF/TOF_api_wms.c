



#include "../../../TOF_event_daemon.h"
#include "../../engine.h"
#include "../../wms.h"
#include "TOF_api_wms.h"



//**************************************************************
// private member
//**************************************************************



//**************************************************************
// public member
//**************************************************************



//**************************************************************
// private function
//**************************************************************
//==============================================================
//
//==============================================================
#define FEATURE_TOF_BOSCH_JAVA
#ifdef FEATURE_TOF_BOSCH_JAVA
int TOF_wms_request_encode_sms(const TOF_wms_request_encode_sms_s TOF_wms_request_data, unsigned char *response_data)
{
  unsigned char pdu_data[255] = {0,};
  wms_status_e_type 				wms_status = WMS_OK_S;
  wms_gw_submit_s_type			wms_gw_submit;
  wms_address_s_type     scAddr;
  wms_raw_ts_data_s_type     wms_raw_ts;

  unsigned char* pdu_ascii_ptr;
  int result = 0;

  pdu_ascii_ptr = response_data;

/*
  printf("[sms pdu] message_class = %d\r\n",TOF_wms_request_data.message_class);
  printf("[sms pdu] message_class_valid = %d\r\n",TOF_wms_request_data.message_class_valid);
  printf("[sms pdu] validity_period = %d\r\n",TOF_wms_request_data.validity_period);
  printf("[sms pdu] validity_period_valid = %d\r\n",TOF_wms_request_data.validity_period_valid);
  printf("[sms pdu] data_coding_scheme = %d\r\n",TOF_wms_request_data.data_coding_scheme);
  printf("[sms pdu] protocol_id = %d\r\n",TOF_wms_request_data.protocol_id);
  printf("[sms pdu] message_reference = %d\r\n",TOF_wms_request_data.message_reference);
  printf("[sms pdu] user_data_length = %d\r\n",TOF_wms_request_data.user_data_length);
  printf("[sms pdu] smsc = %s\r\n",TOF_wms_request_data.smsc);
  printf("[sms pdu] dest_num = %s\r\n",TOF_wms_request_data.dest_num);
  printf("[sms pdu] user_data = %s\r\n",TOF_wms_request_data.user_data);
*/

  if(response_data == NULL)
  {
    return FALSE;
  }

  result = wms_ts_encode_ascii_to_hex((char *)TOF_wms_request_data.user_data, pdu_data, TOF_wms_request_data.user_data_length);
  if(result == 4)
  {
    return FALSE;
  }

  memset( &wms_gw_submit, 0, sizeof( wms_gw_submit ) );
  memset( &wms_raw_ts, 0 ,sizeof(wms_raw_ts_data_s_type));
  memset( &scAddr, 0 , sizeof(wms_address_s_type));
  //
  wms_gw_submit.reject_duplicates = FALSE;
  //wms_gw_submit.reply_path_present
  wms_gw_submit.user_data_header_present = FALSE;
  wms_gw_submit.status_report_enabled = FALSE;
  wms_gw_submit.message_reference = TOF_wms_request_data.message_reference;

  wms_gw_submit.address.digit_mode = WMS_DIGIT_MODE_4_BIT;
  //wms_gw_submit.address.number_mode;	//CDMA only
  wms_gw_submit.address.number_type = WMS_NUMBER_UNKNOWN;
  wms_gw_submit.address.number_plan = WMS_NUMBER_PLAN_TELEPHONY;
  wms_gw_submit.address.number_of_digits = strlen( (const char*)( TOF_wms_request_data.dest_num) );
  wms_ts_ascii_to_bcd( TOF_wms_request_data.dest_num, wms_gw_submit.address.number_of_digits, wms_gw_submit.address.digits );

  wms_gw_submit.pid = TOF_wms_request_data.protocol_id;

  if(TOF_wms_request_data.message_class_valid == TRUE)
  {
    wms_gw_submit.dcs.msg_class = TOF_wms_request_data.message_class;
  }
  else
  {
    wms_gw_submit.dcs.msg_class = WMS_MESSAGE_CLASS_NONE;
  }
  
  wms_gw_submit.dcs.is_compressed = FALSE;
  wms_gw_submit.dcs.msg_waiting = WMS_GW_MSG_WAITING_NONE;
  wms_gw_submit.dcs.msg_waiting_active = 0;
  wms_gw_submit.dcs.msg_waiting_kind = WMS_GW_MSG_WAITING_OTHER;  

  if(TOF_wms_request_data.validity_period_valid == TRUE)
  {
    wms_gw_submit.validity.format = WMS_GW_VALIDITY_RELATIVE;
    wms_gw_submit.validity.u.time.day = TOF_wms_request_data.validity_period;
  }
  else
  {
    wms_gw_submit.validity.format = WMS_GW_VALIDITY_NONE;
  }

  wms_gw_submit.user_data.num_headers = 0;
  //wms_gw_submit.user_data.headers

  wms_gw_submit.user_data.sm_len = TOF_wms_request_data.user_data_length;//strlen( (const char*)( TOF_wms_request_data.user_data) );
  memcpy( wms_gw_submit.user_data.sm_data, pdu_data, wms_gw_submit.user_data.sm_len );

  wms_status = wms_ts_encode_submit( &wms_gw_submit, &(wms_raw_ts) );

  /* fill up SMSC */
  if(TOF_wms_request_data.smsc != NULL)
  {
    int sc_buf_len = strlen(TOF_wms_request_data.smsc);
    
    if(*(TOF_wms_request_data.smsc) == '+')
    {
      scAddr.number_type = WMS_NUMBER_INTERNATIONAL;
      scAddr.number_plan = WMS_NUMBER_PLAN_TELEPHONY;
      if(sc_buf_len <= WMS_GW_ADDRESS_MAX+1)
      {
          wms_ts_ascii_to_bcd((const unsigned char *)(TOF_wms_request_data.smsc+1), sc_buf_len-1, scAddr.digits);
          scAddr.number_of_digits = sc_buf_len -1;
      }
      else
      {
        memset((void *)&scAddr, 0x00, sizeof(wms_address_s_type));
      }
    }
    else
    {
      scAddr.number_type = WMS_NUMBER_UNKNOWN;
      scAddr.number_plan = WMS_NUMBER_PLAN_TELEPHONY;
      if(sc_buf_len <= WMS_GW_ADDRESS_MAX)
      {
        wms_ts_ascii_to_bcd((const unsigned char *)TOF_wms_request_data.smsc, sc_buf_len, scAddr.digits);
        scAddr.number_of_digits = sc_buf_len;
      }
      else
      {
        memset((void *)&scAddr, 0x00, sizeof(wms_address_s_type));
      }
    }
  }
  else
  {
    memset((void *)&scAddr, 0x00, sizeof(wms_address_s_type));
  }
  
  pdu_ascii_ptr = wms_ts_scaddr_to_string ( scAddr, pdu_ascii_ptr );
  wms_ts_encode_hex_to_ascii(wms_raw_ts.data ,pdu_ascii_ptr,wms_raw_ts.len);

//  printf("encode pdu = %s \r\n",response_data);

  return TRUE;
}

int TOF_wms_request_send_sms_pdu(const char *pdu_ascii)
{
  int result = 0;
  int length = strlen(pdu_ascii)/2;
  unsigned char sms_pdu_hex[255]={0,};
  DUBU_request_wms_send_sms_s 		DUBU_request_wms_data;
  DUBU_response_wms_send_sms_s		DUBU_response_wms_data;

  memset( &DUBU_request_wms_data, 0, sizeof( DUBU_request_wms_data ) );	
  memset( &DUBU_response_wms_data, 0, sizeof( DUBU_response_wms_data ) );

  result = wms_ts_encode_ascii_to_hex(pdu_ascii, sms_pdu_hex,length);

  DUBU_request_wms_data.raw_message_data.format = WMS_FORMAT_GW_PP;
  DUBU_request_wms_data.raw_message_data.tpdu_type = WMS_TPDU_SUBMIT;
  DUBU_request_wms_data.raw_message_data.len = length;
  memcpy( DUBU_request_wms_data.raw_message_data.data , sms_pdu_hex, length);

  if ( FALSE == DUBU_request( DUBU_req_type_wms_send_sms_pdu, &DUBU_request_wms_data, &DUBU_response_wms_data ) )
  {
    log_error( "DUBU_request(DUBU_req_type_wms_send_sms_pdu) fail" );
    return 100; /* Future define. IO_Connection failed.*/
  }

  if ( DUBU_response_result_fail == DUBU_response_wms_data.DUBU_response_base.DUBU_response_result )
  {
    result = DUBU_response_wms_data.gw_rp_cause;

    log_error( "DUBU_request() result fail, DUBU_response_wms_data.DUBU_response_base.error:[%d], DUBU_response_wms_data.gw_rp_cause:[%d]", DUBU_response_wms_data.DUBU_response_base.error, DUBU_response_wms_data.gw_rp_cause );
  }

  return result;  

}

int TOF_wms_request_read_sms_pdu( const int index, unsigned char* pdu)
{
	DUBU_request_wms_read_sms_s 		DUBU_request_wms_data;
	DUBU_response_wms_read_sms_s		DUBU_response_wms_data;
	wms_status_e_type					wms_status = WMS_OK_S;	
	wms_gw_deliver_s_type 		gw_deliver;
	unsigned long int 				raw_ts_len = 0;

	memset( &DUBU_request_wms_data, 0, sizeof( DUBU_request_wms_data ) );
	memset( &DUBU_response_wms_data, 0, sizeof( DUBU_response_wms_data ) );
	memset( &gw_deliver, 0, sizeof( gw_deliver ) );

	DUBU_request_wms_data.message_index = index;
	DUBU_request_wms_data.memory_store_type = wms_memory_store_type_nv;

	if ( FALSE == DUBU_request( DUBU_req_type_wms_read_sms, &DUBU_request_wms_data, &DUBU_response_wms_data ) )
	{
		log_error( "DUBU_request(DUBU_req_type_wms_read_sms) fail" );
		return FALSE;
	}

	if ( DUBU_response_result_fail == DUBU_response_wms_data.DUBU_response_base.DUBU_response_result )
	{
		log_error( "DUBU_request() result fail, DUBU_response_wms_data.DUBU_response_base.error:[%d]", DUBU_response_wms_data.DUBU_response_base.error );
		return FALSE;
	}
	
  wms_status = wms_ts_decode_deliver( &( DUBU_response_wms_data.raw_message_data ), &gw_deliver, &raw_ts_len );	

	if ( WMS_OK_S != wms_status )
	{
		log_error( "wms_ts_decode_deliver() fail, wms_status:[%d]", wms_status );
		return FALSE;
	}

  /*SMSC*/
  // fill up to 00
  *pdu = '0';
  *(pdu+1) = '0';

  wms_ts_encode_hex_to_ascii(DUBU_response_wms_data.raw_message_data.data ,pdu+2,DUBU_response_wms_data.raw_message_data.len);

	log_high( "read pdu ok!" );
	
	return TRUE;
}

#endif

int	TOF_wms_request_send_sms( const TOF_wms_request_send_sms_s* const TOF_wms_request_data, TOF_wms_response_send_sms_s* TOF_wms_response_data )
{
	DUBU_request_wms_send_sms_s 		DUBU_request_wms_data;
	DUBU_response_wms_send_sms_s		DUBU_response_wms_data;
	wms_status_e_type 				wms_status = WMS_OK_S;
	wms_gw_submit_s_type			wms_gw_submit;

	memset( TOF_wms_response_data, 0, sizeof( TOF_wms_response_send_sms_s ) );
	TOF_wms_response_data->cause_code = TOF_WMS_INVALID_CAUSE_CODE;
	memset( &DUBU_request_wms_data, 0, sizeof( DUBU_request_wms_data ) );	
	memset( &DUBU_response_wms_data, 0, sizeof( DUBU_response_wms_data ) );
	memset( &wms_gw_submit, 0, sizeof( wms_gw_submit ) );

	//
	wms_gw_submit.reject_duplicates = FALSE;
	//wms_gw_submit.reply_path_present
	wms_gw_submit.user_data_header_present = FALSE;
	wms_gw_submit.status_report_enabled = FALSE;
	//wms_gw_submit.message_reference

	wms_gw_submit.address.digit_mode = WMS_DIGIT_MODE_4_BIT;
	//wms_gw_submit.address.number_mode;	//CDMA only
	wms_gw_submit.address.number_type = WMS_NUMBER_UNKNOWN;
	wms_gw_submit.address.number_plan = WMS_NUMBER_PLAN_TELEPHONY;
	wms_gw_submit.address.number_of_digits = strlen( (const char*)( TOF_wms_request_data->destination_address ) );
	wms_ts_ascii_to_bcd( TOF_wms_request_data->destination_address, wms_gw_submit.address.number_of_digits, wms_gw_submit.address.digits );

	wms_gw_submit.pid = WMS_PID_DEFAULT;

	wms_gw_submit.dcs.msg_class = WMS_MESSAGE_CLASS_NONE;
	wms_gw_submit.dcs.is_compressed = FALSE;
	wms_gw_submit.dcs.msg_waiting = WMS_GW_MSG_WAITING_NONE;
	wms_gw_submit.dcs.msg_waiting_active = 0;
	wms_gw_submit.dcs.msg_waiting_kind = WMS_GW_MSG_WAITING_OTHER;
	
	if ( TRUE == check_ascii( (const char*)( TOF_wms_request_data->message ), strlen( (const char*)( TOF_wms_request_data->message ) ) ) )
	{
		wms_gw_submit.dcs.alphabet = WMS_GW_ALPHABET_7_BIT_DEFAULT;		
	}
	else
	{
		wms_gw_submit.dcs.alphabet = WMS_GW_ALPHABET_8_BIT;
	}	
	//wms_gw_submit.dcs.raw_dcs_data

	wms_gw_submit.validity.format = WMS_GW_VALIDITY_NONE;
	//wms_gw_submit.validity.time

	wms_gw_submit.user_data.num_headers = 0;
	//wms_gw_submit.user_data.headers

	wms_gw_submit.user_data.sm_len = strlen( (const char*)( TOF_wms_request_data->message ) );
	memcpy( wms_gw_submit.user_data.sm_data, TOF_wms_request_data->message, wms_gw_submit.user_data.sm_len );
#ifdef FEATURE_DEBUG_LOG
	log_low( "wms_gw_submit.reject_duplicates:[%d]", wms_gw_submit.reject_duplicates );
	log_low( "wms_gw_submit.user_data_header_present:[%d]", wms_gw_submit.user_data_header_present );
	log_low( "wms_gw_submit.status_report_enabled:[%d]", wms_gw_submit.status_report_enabled );
	log_low( "wms_gw_submit.address.digit_mode:[%d]", wms_gw_submit.address.digit_mode );
	log_low( "wms_gw_submit.address.number_type:[%d]", wms_gw_submit.address.number_type );
	log_low( "wms_gw_submit.address.number_plan:[%d]", wms_gw_submit.address.number_plan );
	log_low( "wms_gw_submit.address.number_of_digits:[%d]", wms_gw_submit.address.number_of_digits );
	log_low( "wms_gw_submit.pid:[0x%02x]", wms_gw_submit.pid );
	log_low( "wms_gw_submit.dcs.msg_class:[%d]", wms_gw_submit.dcs.msg_class );
	log_low( "wms_gw_submit.dcs.is_compressed:[%d]", wms_gw_submit.dcs.is_compressed );
	log_low( "wms_gw_submit.dcs.msg_waiting:[%d]", wms_gw_submit.dcs.msg_waiting );
	log_low( "wms_gw_submit.dcs.msg_waiting_active:[%d]", wms_gw_submit.dcs.msg_waiting_active );
	log_low( "wms_gw_submit.dcs.msg_waiting_kind:[%d]", wms_gw_submit.dcs.msg_waiting_kind );
	log_low( "wms_gw_submit.dcs.alphabet:[%d]", wms_gw_submit.dcs.alphabet );
	log_low( "wms_gw_submit.validity.format:[%d]", wms_gw_submit.validity.format );
	log_low( "wms_gw_submit.user_data.num_headers:[%d]", wms_gw_submit.user_data.num_headers );
	log_low( "wms_gw_submit.user_data.sm_len:[%d]", wms_gw_submit.user_data.sm_len );
	log_binary_data( wms_gw_submit.user_data.sm_data, wms_gw_submit.user_data.sm_len );
#endif
  wms_status = wms_ts_encode_submit( &wms_gw_submit, &( DUBU_request_wms_data.raw_message_data ) );
	DUBU_request_wms_data.raw_message_data.format = WMS_FORMAT_GW_PP;

	if ( WMS_OK_S != wms_status )
	{
		log_error( "wms_ts_encode_submit() fail, wms_status:[%d]", wms_status );
		return FALSE;
	}
#ifdef FEATURE_DEBUG_LOG
	log_low( "DUBU_request_wms_data.raw_message_data.format:[%d]", DUBU_request_wms_data.raw_message_data.format );
	log_low( "DUBU_request_wms_data.raw_message_data.tpdu_type:[%d]", DUBU_request_wms_data.raw_message_data.tpdu_type );
	log_low( "DUBU_request_wms_data.raw_message_data.len:[%d]", DUBU_request_wms_data.raw_message_data.len );
	log_binary_data( DUBU_request_wms_data.raw_message_data.data, DUBU_request_wms_data.raw_message_data.len );	
#endif
	if ( FALSE == DUBU_request( DUBU_req_type_wms_send_sms, &DUBU_request_wms_data, &DUBU_response_wms_data ) )
	{
		log_error( "DUBU_request(DUBU_req_type_wms_send_sms) fail" );
		return FALSE;
	}
	
	if ( DUBU_response_result_fail == DUBU_response_wms_data.DUBU_response_base.DUBU_response_result )
	{
		TOF_wms_response_data->cause_code = DUBU_response_wms_data.gw_rp_cause;
		
		log_error( "DUBU_request() result fail, DUBU_response_wms_data.DUBU_response_base.error:[%d], DUBU_response_wms_data.gw_rp_cause:[%d]", DUBU_response_wms_data.DUBU_response_base.error, DUBU_response_wms_data.gw_rp_cause );
		return FALSE;
	}
	
	TOF_wms_response_data->message_id = DUBU_response_wms_data.message_id;

	log_high( "ok!" );
	
	return TRUE;
}

//==============================================================
//
//==============================================================
int TOF_wms_request_delete_sms( const TOF_wms_request_delete_sms_s* const TOF_wms_request_data, TOF_wms_response_delete_sms_s* TOF_wms_response_data )
{
	DUBU_request_wms_delete_sms_s 		DUBU_request_wms_data;
	DUBU_response_wms_delete_sms_s 	DUBU_response_wms_data;
	
	memset( TOF_wms_response_data, 0, sizeof( TOF_wms_response_delete_sms_s ) );
	memset( &DUBU_request_wms_data, 0, sizeof( DUBU_request_wms_data ) );
	memset( &DUBU_response_wms_data, 0, sizeof( DUBU_response_wms_data ) );

	//
	DUBU_request_wms_data.message_index = TOF_wms_request_data->message_index;
	DUBU_request_wms_data.memory_store_type = wms_memory_store_type_nv;

	if ( FALSE == DUBU_request( DUBU_req_type_wms_delete_sms, &DUBU_request_wms_data, &DUBU_response_wms_data ) )
	{
		log_error( "DUBU_request(DUBU_req_type_wms_delete_sms) fail" );
		return FALSE;
	}

	if ( DUBU_response_result_fail == DUBU_response_wms_data.DUBU_response_base.DUBU_response_result )
	{
		log_error( "DUBU_request() result fail, DUBU_response_wms_data.DUBU_response_base.error:[%d]", DUBU_response_wms_data.DUBU_response_base.error );
		return FALSE;
	}	
	
	log_high( "ok!" );

	return TRUE;
}

//==============================================================
//
//==============================================================
int TOF_wms_request_read_sms( const TOF_wms_request_read_sms_s* const TOF_wms_request_data, TOF_wms_response_read_sms_s* TOF_wms_response_data )
{
	DUBU_request_wms_read_sms_s 		DUBU_request_wms_data;
	DUBU_response_wms_read_sms_s		DUBU_response_wms_data;
	wms_status_e_type					wms_status = WMS_OK_S;	
	wms_gw_deliver_s_type 		gw_deliver;
	unsigned long int 				raw_ts_len = 0;

	memset( TOF_wms_response_data, 0, sizeof( TOF_wms_response_read_sms_s ) );
	memset( &DUBU_request_wms_data, 0, sizeof( DUBU_request_wms_data ) );
	memset( &DUBU_response_wms_data, 0, sizeof( DUBU_response_wms_data ) );
	memset( &gw_deliver, 0, sizeof( gw_deliver ) );
	
	//
	DUBU_request_wms_data.message_index = TOF_wms_request_data->message_index;
	DUBU_request_wms_data.memory_store_type = wms_memory_store_type_nv;

	if ( FALSE == DUBU_request( DUBU_req_type_wms_read_sms, &DUBU_request_wms_data, &DUBU_response_wms_data ) )
	{
		log_error( "DUBU_request(DUBU_req_type_wms_read_sms) fail" );
		return FALSE;
	}

	if ( DUBU_response_result_fail == DUBU_response_wms_data.DUBU_response_base.DUBU_response_result )
	{
		log_error( "DUBU_request() result fail, DUBU_response_wms_data.DUBU_response_base.error:[%d]", DUBU_response_wms_data.DUBU_response_base.error );
		return FALSE;
	}
	
  wms_status = wms_ts_decode_deliver( &( DUBU_response_wms_data.raw_message_data ), &gw_deliver, &raw_ts_len );	

	if ( WMS_OK_S != wms_status )
	{
		log_error( "wms_ts_decode_deliver() fail, wms_status:[%d]", wms_status );
		return FALSE;
	}
#ifdef FEATURE_DEBUG_LOG
	log_low( "gw_deliver.more:[%d]", gw_deliver.more );
	log_low( "gw_deliver.reply_path_present:[%d]", gw_deliver.reply_path_present );
	log_low( "gw_deliver.user_data_header_present:[%d]", gw_deliver.user_data_header_present );
	log_low( "gw_deliver.status_report_enabled:[%d]", gw_deliver.status_report_enabled );
	log_low( "gw_deliver.address.number_of_digits:[%d]", gw_deliver.address.number_of_digits );
#endif
	if ( gw_deliver.address.number_of_digits > 0 )
	{
		wms_ts_bcd_to_ascii( gw_deliver.address.digits, gw_deliver.address.number_of_digits, TOF_wms_response_data->originating_address );
		TOF_wms_response_data->originating_address_length = strlen( (const char*)TOF_wms_response_data->originating_address );

		log_low( "gw_deliver.address.digits:[%d]", gw_deliver.address.digits );
		log_med( "TOF_wms_response_data->originating_address:[%s]", TOF_wms_response_data->originating_address );
	}
#ifdef FEATURE_DEBUG_LOG
	log_low( "gw_deliver.address.number_mode:[%d]", gw_deliver.address.number_mode );
	log_low( "gw_deliver.address.number_plan:[%d]", gw_deliver.address.number_plan );
	log_low( "gw_deliver.address.number_type:[%d]", gw_deliver.address.number_type );
	log_low( "gw_deliver.dcs.alphabet:[%d]", gw_deliver.dcs.alphabet );
	log_low( "gw_deliver.dcs.is_compressed:[%d]", gw_deliver.dcs.is_compressed );
	log_low( "gw_deliver.dcs.msg_class:[%d]", gw_deliver.dcs.msg_class );
	log_low( "gw_deliver.dcs.msg_waiting:[%d]", gw_deliver.dcs.msg_waiting );
	log_low( "gw_deliver.dcs.msg_waiting_active:[%d]", gw_deliver.dcs.msg_waiting_active );
	log_low( "gw_deliver.dcs.msg_waiting_kind:[%d]", gw_deliver.dcs.msg_waiting_kind );
	log_low( "gw_deliver.pid:[0x%02x]", gw_deliver.pid );
	log_low( "gw_deliver.user_data.num_headers:[%d]", gw_deliver.user_data.num_headers );
#endif
	wms_ts_bcd_to_int( gw_deliver.timestamp.year, &( TOF_wms_response_data->message_timestamp.year ) );
	wms_ts_bcd_to_int( gw_deliver.timestamp.month, &( TOF_wms_response_data->message_timestamp.month ) );
	wms_ts_bcd_to_int( gw_deliver.timestamp.day, &( TOF_wms_response_data->message_timestamp.day ) );
	wms_ts_bcd_to_int( gw_deliver.timestamp.hour, &( TOF_wms_response_data->message_timestamp.hour ) );
	wms_ts_bcd_to_int( gw_deliver.timestamp.minute, &( TOF_wms_response_data->message_timestamp.minute ) );
	wms_ts_bcd_to_int( gw_deliver.timestamp.second, &( TOF_wms_response_data->message_timestamp.second ) );
	wms_ts_bcd_to_int( gw_deliver.timestamp.timezone, &( TOF_wms_response_data->message_timestamp.timezone ) );

	log_med( "%02d/%02d/%02d - %02d:%02d:%02d timezone:[%d]", TOF_wms_response_data->message_timestamp.year,
																														TOF_wms_response_data->message_timestamp.month,
																														TOF_wms_response_data->message_timestamp.day,
																														TOF_wms_response_data->message_timestamp.hour,
																														TOF_wms_response_data->message_timestamp.minute,
																														TOF_wms_response_data->message_timestamp.second,
																														TOF_wms_response_data->message_timestamp.timezone );
#ifdef FEATURE_DEBUG_LOG
	log_low( "gw_deliver.user_data.sm_len:[%d]", gw_deliver.user_data.sm_len );
	log_binary_data( gw_deliver.user_data.sm_data, gw_deliver.user_data.sm_len );
#endif
	memcpy( TOF_wms_response_data->message, gw_deliver.user_data.sm_data, gw_deliver.user_data.sm_len );
	TOF_wms_response_data->message_length = gw_deliver.user_data.sm_len;					
#ifdef FEATURE_DEBUG_LOG
	log_low( "m_TOF_wms_rsp_read_sms.message_length:[%d]", TOF_wms_response_data->message_length );
	log_binary_data( TOF_wms_response_data->message, TOF_wms_response_data->message_length );
#endif
	log_high( "ok!" );
	
	return TRUE;
}

//==============================================================
//
//==============================================================
int TOF_wms_request_list_sms( const TOF_wms_request_list_sms_s* const TOF_wms_request_data, TOF_wms_response_list_sms_s* TOF_wms_response_data )
{	
	unsigned int i = 0;
	DUBU_request_wms_list_sms_s 		DUBU_request_wms_data;
	DUBU_response_wms_list_sms_s 	DUBU_response_wms_data;
	
	memset( TOF_wms_response_data, 0, sizeof( TOF_wms_response_list_sms_s ) );
	memset( &DUBU_request_wms_data, 0, sizeof( DUBU_request_wms_data ) );
	memset( &DUBU_response_wms_data, 0, sizeof( DUBU_response_wms_data ) );	

	//
	DUBU_request_wms_data.memory_store_type = wms_memory_store_type_nv;

	if ( FALSE == DUBU_request( DUBU_req_type_wms_list_sms, &DUBU_request_wms_data, &DUBU_response_wms_data ) )
	{
		log_error( "DUBU_request(DUBU_req_type_wms_list_sms) fail" );
		return FALSE;
	}
	
	if ( DUBU_response_result_fail == DUBU_response_wms_data.DUBU_response_base.DUBU_response_result )
	{
		log_error( "DUBU_request() result fail, DUBU_response_wms_data.DUBU_response_base.error:[%d]", DUBU_response_wms_data.DUBU_response_base.error );
		return FALSE;
	}
	
	TOF_wms_response_data->message_info_num = DUBU_response_wms_data.message_info_num;

	for ( i = 0; i < DUBU_response_wms_data.message_info_num; ++i )
	{
		TOF_wms_response_data->message_info_list[ i ].message_index = DUBU_response_wms_data.message_info[ i ].message_index;
		TOF_wms_response_data->message_info_list[ i ].message_tag_type = DUBU_response_wms_data.message_info[ i ].message_tag_type;
	}	
	
	log_high( "ok!" );
	
	return TRUE;
}

//==============================================================
//
//==============================================================
int TOF_wms_request_get_smsc_address( const TOF_wms_request_get_smsc_address_s* const TOF_wms_request_data, TOF_wms_response_get_smsc_address_s* TOF_wms_response_data )
{
	DUBU_request_wms_get_smsc_address_s 		DUBU_request_wms_data;
	DUBU_response_wms_get_smsc_address_s 	DUBU_response_wms_data;

	memset( TOF_wms_response_data, 0, sizeof( TOF_wms_response_get_smsc_address_s ) );
	memset( &DUBU_request_wms_data, 0, sizeof( DUBU_request_wms_data ) );	
	memset( &DUBU_response_wms_data, 0, sizeof( DUBU_response_wms_data ) );

	//	
	if ( FALSE == DUBU_request( DUBU_req_type_wms_get_smsc_address, &DUBU_request_wms_data, &DUBU_response_wms_data ) )
	{
		log_error( "DUBU_request(DUBU_req_type_wms_get_smsc_address) fail" );
		return FALSE;
	}
	
	if ( DUBU_response_result_fail == DUBU_response_wms_data.DUBU_response_base.DUBU_response_result )
	{
		log_error( "DUBU_request() result fail, DUBU_response_wms_data.DUBU_response_base.error:[%d]", DUBU_response_wms_data.DUBU_response_base.error );
		return FALSE;
	}

	TOF_wms_response_data->smsc_address_digits_length = DUBU_response_wms_data.smsc_address_digits_length;
	memcpy( TOF_wms_response_data->smsc_address_digits, DUBU_response_wms_data.smsc_address_digits, DUBU_response_wms_data.smsc_address_digits_length );	
	
	log_high( "ok!" );
	
	return TRUE;
}

//==============================================================
//
//==============================================================
int TOF_wms_request_set_smsc_address( const TOF_wms_request_set_smsc_address_s* const TOF_wms_request_data, TOF_wms_response_set_smsc_address_s* TOF_wms_response_data )
{
	DUBU_request_wms_set_smsc_address_s 		DUBU_request_wms_data;
	DUBU_response_wms_set_smsc_address_s 	DUBU_response_wms_data;

	memset( TOF_wms_response_data, 0, sizeof( TOF_wms_response_set_smsc_address_s ) );
	memset( &DUBU_request_wms_data, 0, sizeof( DUBU_request_wms_data ) );
	memset( &DUBU_response_wms_data, 0, sizeof( DUBU_response_wms_data ) );

	//
	DUBU_request_wms_data.smsc_address_digits = TOF_wms_request_data->smsc_address_digits;
	
	if ( FALSE == DUBU_request( DUBU_req_type_wms_set_smsc_address, &DUBU_request_wms_data, &DUBU_response_wms_data ) )
	{
		log_error( "DUBU_request(DUBU_req_type_wms_set_smsc_address) fail" );
		return FALSE;
	}
		
	if ( DUBU_response_result_fail == DUBU_response_wms_data.DUBU_response_base.DUBU_response_result )
	{
		log_error( "DUBU_request() result fail, DUBU_response_wms_data.DUBU_response_base.error:[%d]", DUBU_response_wms_data.DUBU_response_base.error );
		return FALSE;
	}

	log_high( "ok!" );
	
	return TRUE;
}

//==============================================================
//
//==============================================================
int TOF_wms_request_get_memory_status( const TOF_wms_request_get_memory_status_s* const TOF_wms_request_data, TOF_wms_response_get_memory_status_s* TOF_wms_response_data )
{
	DUBU_request_wms_get_memory_status_s 	DUBU_request_wms_data;
	DUBU_response_wms_get_memory_status_s 	DUBU_response_wms_data;

	memset( TOF_wms_response_data, 0, sizeof( TOF_wms_response_get_memory_status_s ) );
	memset( &DUBU_request_wms_data, 0, sizeof( DUBU_request_wms_data ) );
	memset( &DUBU_response_wms_data, 0, sizeof( DUBU_response_wms_data ) );

	//
	if ( FALSE == DUBU_request( DUBU_req_type_wms_get_memory_status, &DUBU_request_wms_data, &DUBU_response_wms_data ) )
	{
		log_error( "DUBU_request(DUBU_req_type_wms_get_memory_status) fail" );
		return FALSE;
	}

	if ( DUBU_response_result_fail == DUBU_response_wms_data.DUBU_response_base.DUBU_response_result )
	{
		log_error( "DUBU_request() result fail, DUBU_response_wms_data.DUBU_response_base.error:[%d]", DUBU_response_wms_data.DUBU_response_base.error );
		return FALSE;
	}
	
	TOF_wms_response_data->memory_available = DUBU_response_wms_data.memory_available;
	
	log_high( "ok!" );
	
	return TRUE;
}

//**************************************************************
// public function
//**************************************************************
//==============================================================
//
//==============================================================
void TOF_wms_response_cb_send_sms( const void* const DUBU_response_wms_data, const void* const user_data )
{
	log_high( "ok!" );
}

//==============================================================
//
//==============================================================
void TOF_wms_response_cb_delete_sms( const void* const DUBU_response_wms_data, const void* const user_data )
{
	log_high( "ok!" );
}

//==============================================================
//
//==============================================================
void TOF_wms_response_cb_read_sms( const void* const DUBU_response_wms_data, const void* const user_data )
{
	log_high( "ok!" );
}

//==============================================================
//
//==============================================================
void TOF_wms_response_cb_list_sms( const void* const DUBU_response_wms_data, const void* const user_data )
{
	log_high( "ok!" );
}

//==============================================================
//
//==============================================================
void TOF_wms_response_cb_get_smsc_address( const void* const DUBU_response_wms_data, const void* const user_data )
{
	log_high( "ok!" );
}

//==============================================================
//
//==============================================================
void TOF_wms_response_cb_set_smsc_address( const void* const DUBU_response_wms_data, const void* const user_data )
{
	log_high( "ok!" );
}

//==============================================================
//
//==============================================================
void TOF_wms_response_cb_get_memory_status( const void* const DUBU_response_wms_data, const void* const user_data )
{
	log_high( "ok!" );
}

void TOF_wms_response_cb_send_sms_pdu( const void* const DUBU_response_wms_data, const void* const user_data )
{
  log_high( "ok!");
}

//==============================================================
//
//==============================================================
void TOF_wms_indication_cb_new_sms( const void* const wms_ind )
{
	DUBU_indication_wms_new_sms_s* DUBU_indication_wms_new_sms = NULL;

	//
	DUBU_indication_wms_new_sms = (DUBU_indication_wms_new_sms_s*)wms_ind;
	//printf("new message arrived\r\n");	
	wms_notify_event( TOF_EVENT_IND_RESPONSE_NEW_SMS,  DUBU_indication_wms_new_sms->message_index, 0 );

	log_high( "ok! message_index:[%d]", DUBU_indication_wms_new_sms->message_index );	
}

//==============================================================
//
//==============================================================
int TOF_request_send_sms( const TOF_request_send_sms_s* const TOF_request_data, TOF_response_send_sms_s* TOF_response_data )
{
	return TOF_wms_request_send_sms( TOF_request_data, TOF_response_data );
}

int TOF_request_delete_sms( const TOF_request_delete_sms_s* const TOF_request_data, TOF_response_delete_sms_s* TOF_response_data )
{
	return TOF_wms_request_delete_sms( TOF_request_data, TOF_response_data );
}

int TOF_request_read_sms( const TOF_request_read_sms_s* const TOF_request_data, TOF_response_read_sms_s* TOF_response_data )
{
	return TOF_wms_request_read_sms( TOF_request_data, TOF_response_data );
}

int TOF_request_list_sms( const TOF_request_list_sms_s* const TOF_request_data, TOF_response_list_sms_s* TOF_response_data )
{
	return TOF_wms_request_list_sms( TOF_request_data, TOF_response_data );
}

int TOF_request_get_smsc_address( const TOF_request_get_smsc_address_s* const TOF_request_data, TOF_response_get_smsc_address_s* TOF_response_data )
{
	return TOF_wms_request_get_smsc_address( TOF_request_data, TOF_response_data );
}

int TOF_request_set_smsc_address( const TOF_request_set_smsc_address_s* const TOF_request_data, TOF_response_set_smsc_address_s* TOF_response_data )
{
	return TOF_wms_request_set_smsc_address( TOF_request_data, TOF_response_data );
}

int TOF_request_get_memory_status( const TOF_request_get_memory_status_s* const TOF_request_data, TOF_response_get_memory_status_s* TOF_response_data )
{
	return TOF_wms_request_get_memory_status( TOF_request_data, TOF_response_data );
}

int TOF_request_encode_sms(const TOF_wms_request_encode_sms_s TOF_request_data, unsigned char *TOF_response_data)
{
  return TOF_wms_request_encode_sms(TOF_request_data,TOF_response_data);
}

int TOF_request_send_sms_pdu(const char* pdu)
{
  return TOF_wms_request_send_sms_pdu(pdu);
}

int TOF_request_read_sms_pdu(const int index, unsigned char* pdu_ascii)
{
  return TOF_wms_request_read_sms_pdu(index,pdu_ascii);
}
