#ifndef TOF_H
#define TOF_H



#include "../../../TOF_Definition.h"



#ifdef __cplusplus
extern "C" {
#endif



//**************************************************************
// public member
//**************************************************************



//**************************************************************
// public function
//**************************************************************
int TOF_init( void );
void TOF_release( void );



#ifdef __cplusplus
}
#endif



#endif
