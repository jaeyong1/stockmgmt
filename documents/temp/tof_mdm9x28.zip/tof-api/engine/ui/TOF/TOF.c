



#include "../../../TOF_event_daemon.h"
#include "../../../TOF_log.h"
#include "../../engine.h"
#include "TOF_api_wms.h"
#include "TOF_api_voice.h"



//**************************************************************
// private member
//**************************************************************
typedef enum
{
	printf_color_type_yellow 	= 33,
	printf_color_type_blue			= 36,
	printf_color_type_white 		= 37,
	printf_color_type_red 			= 31,
	printf_color_type_purple 	= 35,
	printf_color_type_green			= 32
} printf_color_type_e;



//**************************************************************
// public member
//**************************************************************



//**************************************************************
// private function
//**************************************************************
//==============================================================
//
//==============================================================
void printf_color( const printf_color_type_e color, const char* const string )
{
	int i = 0;
	char color_string[ max_log_buffer_size ];
	int index = 0;
	const char* prefix = "[SMS] ";
	const char color_prefix[ 32 ];
	const char* color_postfix = "\x1b[0m";
	const char value_color_prefix[ 32 ];

	//
	sprintf( color_prefix, "\x1b[1;%dm", color );
	sprintf( value_color_prefix, "\x1b[1;%dm", printf_color_type_green );

	strcpy( &( color_string[ index ] ), color_prefix );
	index += strlen( color_prefix );
	
	strcpy( &( color_string[ index ] ), prefix );
	index += strlen( prefix );
	
	for ( i = 0; i < strlen( string ); ++i )
	{
		if ( '[' == string[ i ] )
		{
			strcpy( &( color_string[ index ] ), value_color_prefix );
			index += strlen( value_color_prefix );
		}

		color_string[ index++ ] = string[ i ];
		
		if ( ']' == string[ i ] )
		{
			strcpy( &( color_string[ index ] ), color_postfix );
			index += strlen( color_postfix );
			
			strcpy( &( color_string[ index ] ), color_prefix );
			index += strlen( color_prefix );
		}
	}
	
	strcpy( &( color_string[ index ] ), color_postfix );
	
 	MSG_LOW( "%s\n", color_string ,0,0);
}

//==============================================================
//
//==============================================================
void TOF_write_log_function_high( const char* string )
{
	printf_color( printf_color_type_yellow, string );
	//MSG_HIGH( "%s", string, 0, 0 );
}

//==============================================================
//
//==============================================================
void TOF_write_log_function_medium( const char* string )
{
	printf_color( printf_color_type_blue, string );
	//MSG_MED( "%s", string, 0, 0 );
}

//==============================================================
//
//==============================================================
void TOF_write_log_function_low( const char* string )
{
	printf_color( printf_color_type_white, string );
	//MSG_LOW( "%s", string, 0, 0 );
}

//==============================================================
//
//==============================================================
void TOF_write_log_function_error( const char* string )
{
	printf_color( printf_color_type_red, string );
	//MSG_ERROR( "%s", string, 0, 0 );
}

//==============================================================
//
//==============================================================
void TOF_write_log_function_fatal( const char* string )
{
	printf_color( printf_color_type_purple, string );
	//MSG_FATAL( "%s", string, 0, 0 );
}



//**************************************************************
// public function
//**************************************************************
//==============================================================
//
//==============================================================
int	TOF_init( void )
{
	write_log_function_list_s write_log_function_list;
	DUBU_info_s DUBU_info;

	memset( &write_log_function_list, 0, sizeof( write_log_function_list ) );
	memset( &DUBU_info, 0, sizeof( DUBU_info ) );

	//
	write_log_function_list.function[ log_type_high ] 	= TOF_write_log_function_high;
	write_log_function_list.function[ log_type_medium ] = TOF_write_log_function_medium;
	write_log_function_list.function[ log_type_low ] 		= TOF_write_log_function_low;
	write_log_function_list.function[ log_type_error ] 	= TOF_write_log_function_error;
	write_log_function_list.function[ log_type_fatal ] 	= TOF_write_log_function_fatal;

	log_init( &write_log_function_list );

	DUBU_info.DUBU_interface_type = DUBU_interface_type_qmi;

	//sms
	DUBU_info.DUBU_callback_response[ DUBU_req_type_wms_send_sms ] 					= TOF_wms_response_cb_send_sms;
	DUBU_info.DUBU_callback_response[ DUBU_req_type_wms_delete_sms ] 				= TOF_wms_response_cb_delete_sms;
	DUBU_info.DUBU_callback_response[ DUBU_req_type_wms_read_sms ] 					= TOF_wms_response_cb_read_sms;
	DUBU_info.DUBU_callback_response[ DUBU_req_type_wms_list_sms ] 					= TOF_wms_response_cb_list_sms;
	DUBU_info.DUBU_callback_response[ DUBU_req_type_wms_get_smsc_address ] 	= TOF_wms_response_cb_get_smsc_address;
	DUBU_info.DUBU_callback_response[ DUBU_req_type_wms_set_smsc_address ] 	= TOF_wms_response_cb_set_smsc_address;
	DUBU_info.DUBU_callback_response[ DUBU_req_type_wms_get_memory_status ] = TOF_wms_response_cb_get_memory_status;
  DUBU_info.DUBU_callback_response[ DUBU_req_type_wms_send_sms_pdu ] 					= TOF_wms_response_cb_send_sms_pdu;
	//voice
	DUBU_info.DUBU_callback_response[ DUBU_req_type_voice_dial_call ] = TOF_voice_response_cb_dial_call;

	//sms
	DUBU_info.DUBU_callback_indication[ DUBU_ind_type_wms_new_sms ] = TOF_wms_indication_cb_new_sms;
	//voice
	DUBU_info.DUBU_callback_indication[ DUBU_ind_type_voice_all_call_status ] = TOF_voice_indication_cb_all_call_status;
	
	if ( FALSE == DUBU_init( &DUBU_info ) )
	{
		TOF_release();
		
		log_error( "DUBU_init() fail" );
		return FALSE;
	}
 
	log_high( "ok!" );
	
	return TRUE;
}

//==============================================================
//
//==============================================================
void TOF_release( void )
{
	DUBU_release();

	log_high( "ok!" );
}




