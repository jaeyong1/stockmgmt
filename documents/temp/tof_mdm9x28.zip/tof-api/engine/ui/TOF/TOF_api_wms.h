#ifndef TOF_API_WMS_H
#define TOF_API_WMS_H



#include "../../../TOF_Definition.h"



#ifdef __cplusplus
extern "C" {
#endif



//**************************************************************
// public member
//**************************************************************



//**************************************************************
// public function
//**************************************************************
int TOF_request_send_sms( const TOF_request_send_sms_s* const TOF_request_data, TOF_response_send_sms_s* TOF_response_data );
int TOF_request_delete_sms( const TOF_request_delete_sms_s* const TOF_request_data, TOF_response_delete_sms_s* TOF_response_data );
int TOF_request_read_sms( const TOF_request_read_sms_s* const TOF_request_data, TOF_response_read_sms_s* TOF_response_data );
int TOF_request_list_sms( const TOF_request_list_sms_s* const TOF_request_data, TOF_response_list_sms_s* TOF_response_data );
int TOF_request_get_smsc_address( const TOF_request_get_smsc_address_s* const TOF_request_data, TOF_response_get_smsc_address_s* TOF_response_data );
int TOF_request_set_smsc_address( const TOF_request_set_smsc_address_s* const TOF_request_data, TOF_response_set_smsc_address_s* TOF_response_data );
int TOF_request_get_memory_status( const TOF_request_get_memory_status_s* const TOF_request_data, TOF_response_get_memory_status_s* TOF_response_data );
int TOF_request_encode_sms(const TOF_wms_request_encode_sms_s TOF_request_data, unsigned char *TOF_response_data);
int TOF_request_send_sms_pdu(const char* pdu);
int TOF_request_read_sms_pdu(const int index, unsigned char* pdu_ascii);

void TOF_wms_response_cb_send_sms( const void* const DUBU_response_wms_data, const void* const user_data );
void TOF_wms_response_cb_delete_sms( const void* const DUBU_response_wms_data, const void* const user_data );
void TOF_wms_response_cb_read_sms( const void* const DUBU_response_wms_data, const void* const user_data );
void TOF_wms_response_cb_list_sms( const void* const DUBU_response_wms_data, const void* const user_data );
void TOF_wms_response_cb_get_smsc_address( const void* const DUBU_response_wms_data, const void* const user_data );
void TOF_wms_response_cb_set_smsc_address( const void* const DUBU_response_wms_data, const void* const user_data );
void TOF_wms_response_cb_get_memory_status( const void* const DUBU_response_wms_data, const void* const user_data );
void TOF_wms_response_cb_send_sms_pdu( const void* const DUBU_response_wms_data, const void* const user_data );

void TOF_wms_indication_cb_new_sms( const void* const wms_ind );



#ifdef __cplusplus
}
#endif



#endif
