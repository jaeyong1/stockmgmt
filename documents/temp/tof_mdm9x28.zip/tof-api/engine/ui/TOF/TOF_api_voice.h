#ifndef TOF_API_VOICE_H
#define TOF_API_VOICE_H



#include "../../../TOF_Definition.h"



#ifdef __cplusplus
extern "C" {
#endif



//**************************************************************
// public member
//**************************************************************



//**************************************************************
// public function
//**************************************************************
int TOF_request_dial_call( const TOF_request_dial_call_s* const TOF_request_data, TOF_response_dial_call_s* TOF_response_data );

void TOF_voice_response_cb_dial_call( const void* const DUBU_response_voice_data, const void* const user_data );

void TOF_voice_indication_cb_all_call_status( const void* const voice_ind );

#ifdef __cplusplus
}
#endif



#endif
