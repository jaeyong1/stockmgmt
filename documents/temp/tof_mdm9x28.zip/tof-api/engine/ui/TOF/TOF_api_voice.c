



#include "../../../TOF_event_daemon.h"
#include "../../engine.h"
#include "../../voice.h"
#include "TOF_api_voice.h"



//**************************************************************
// private member
//**************************************************************



//**************************************************************
// public member
//**************************************************************



//**************************************************************
// private function
//**************************************************************
//==============================================================
//
//==============================================================
int TOF_voice_request_dial_call( const TOF_voice_request_dial_call_s* const TOF_voice_request_data, TOF_voice_response_dial_call_s* TOF_voice_response_data )
{
	DUBU_request_voice_dial_call_s		DUBU_request_voice_data;
	DUBU_response_voice_dial_call_s 	DUBU_response_voice_data;

	strcpy( DUBU_request_voice_data.number, TOF_voice_request_data->number );

	if ( FALSE == DUBU_request( DUBU_req_type_voice_dial_call, &DUBU_request_voice_data, &DUBU_response_voice_data ) )
	{
		log_error( "DUBU_request(DUBU_req_type_voice_dial_call) fail" );
		return FALSE;
	}
	
	if ( DUBU_response_result_fail == DUBU_response_voice_data.DUBU_response_base.DUBU_response_result )
	{
		log_error( "DUBU_request() result fail, DUBU_response_voice_data.DUBU_response_base.error:[%d]", DUBU_response_voice_data.DUBU_response_base.error );
		return FALSE;
	}
	
	log_high( "ok!" );
	
	return TRUE;
}

//==============================================================
//
//==============================================================
void TOF_voice_response_cb_dial_call( const void* const DUBU_response_voice_data, const void* const user_data )
{
	log_high( "ok!" );
}



//**************************************************************
// public function
//**************************************************************
//==============================================================
//
//==============================================================
void TOF_voice_indication_cb_all_call_status( const void* const voice_ind )
{
}

//==============================================================
//
//==============================================================
int TOF_request_dial_call( const TOF_request_dial_call_s* const TOF_request_data, TOF_response_dial_call_s* TOF_response_data )
{
	return TOF_voice_request_dial_call( TOF_request_data, TOF_response_data );
}




