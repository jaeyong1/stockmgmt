#ifndef QMI_WMS_H
#define QMI_WMS_H



#include "wireless_messaging_service_v01.h"
#include "qmi_core.h"



#ifdef __cplusplus
extern "C" {
#endif



//**************************************************************
// public member
//**************************************************************
//QMI_WMS_INDICATION_REGISTER_REQ_V01
#define WMSI_REQ_TLV_IND_REG_TRANSPORT_LAYER_INFO_EVENTS				(0x10)
#define WMSI_REQ_TLV_IND_REG_TRANSPORT_NW_REG_INFO_EVENTS  			(0x11)
#define WMSI_REQ_TLV_IND_REG_CALL_STATUS_INFO_EVENTS       			(0x12)
#define WMSI_REQ_TLV_IND_REG_SERVICE_READY_EVENTS     						(0x13)
#define WMSI_REQ_TLV_IND_REG_BROADCAST_CONFIG_EVENTS  						(0x14)
#define WMSI_REQ_TLV_IND_REG_TRANSPORT_LAYER_MWI_INFO_EVENTS		(0x15)
#define WMSI_REQ_TLV_IND_REG_SIM_READY_INFO_EVENTS  							(0x16)

typedef enum
{
	qmi_wms_ind_reg_mask_none																= 0x00000000,
	qmi_wms_ind_reg_mask_TRANSPORT_LAYER_INFO_EVENTS			= 0x00000001,
	qmi_wms_ind_reg_mask_TRANSPORT_NW_REG_INFO_EVENTS  		= 0x00000002,
	qmi_wms_ind_reg_mask_CALL_STATUS_INFO_EVENTS       		= 0x00000004,
	qmi_wms_ind_reg_mask_SERVICE_READY_EVENTS     					= 0x00000008,
	qmi_wms_ind_reg_mask_BROADCAST_CONFIG_EVENTS  					= 0x00000010,
	qmi_wms_ind_reg_mask_TRANSPORT_LAYER_MWI_INFO_EVENTS	= 0x00000020,
	qmi_wms_ind_reg_mask_SIM_READY_INFO_EVENTS  						= 0x00000040,
} qmi_wms_indication_register_mask_e;



//**************************************************************
// public function
//**************************************************************
int	qmi_wms_request_message_write_tlv( const int qmi_request_message_id, 
																						unsigned char** qmi_request_raw_message, 
																						int* const qmi_request_raw_message_size, 
																						const void* const qmi_request_message );

int	qmi_wms_response_message_read_tlv( const int qmi_response_message_id, 
																					const unsigned int qmi_response_message_field_type, 
																					const unsigned char* const qmi_response_message_field, 
																					const unsigned int qmi_response_message_field_size, 
																					void* qmi_response_message );

int qmi_wms_indication_message_read_tlv( const int qmi_indication_message_id, 
																							const unsigned int qmi_indication_message_field_type, 
																							const unsigned char* const qmi_indication_message_field, 
																							const unsigned int qmi_indication_message_field_size, 
																							void* qmi_indication_message );

int qmi_wms_on_init( void );



#ifdef __cplusplus
}
#endif



#endif
