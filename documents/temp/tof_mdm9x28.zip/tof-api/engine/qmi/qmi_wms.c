



#include "qmi_wms.h"



//**************************************************************
// private member
//**************************************************************
//==============================================================
// request TLV
//==============================================================
//QMI_WMS_SET_EVENT_REPORT_REQ_V01
#define WMSI_REQ_TLV_SET_EVENT_RPT_NEW_MT_MSG_INDICATOR					(0x10)
#define WMSI_REQ_TLV_SET_EVENT_RPT_MO_SMS_CALL_CONTROL_INFO			(0x11)
#define WMSI_REQ_TLV_SET_EVENT_RPT_MWI_MSG_INDICATOR							(0x12)

//QMI_WMS_RAW_SEND_REQ_V01
#define	WMSI_REQ_TLV_RAW_SEND_RAW_MSG_DATA												(0x01)
#define WMSI_REQ_TLV_RAW_SEND_FORCE_ON_DC													(0x10)
#define WMSI_REQ_TLV_RAW_SEND_FOLLOW_ON_DC												(0x11)
#define	WMSI_REQ_TLV_RAW_SEND_LINK_CONTROL												(0x12)
#define	WMSI_REQ_TLV_RAW_SEND_SMS_ON_IMS													(0x13)
#define	WMSI_REQ_TLV_RAW_SEND_RETRY_MSG														(0x14)
#define	WMSI_REQ_TLV_RAW_SEND_RETRY_MSG_ID												(0x15)
#define	WMSI_REQ_TLV_RAW_SEND_LINK_CONTROL_ENABLING_INFO				(0x16)

//QMI_WMS_DELETE_REQ_V01
#define WMSI_REQ_TLV_DELETE_MEMORY_STORAGE												(0x01)
#define WMSI_REQ_TLV_DELETE_MEMORY_INDEX													(0x10)
#define WMSI_REQ_TLV_DELETE_MSG_TAG																(0x11)
#define	WMSI_REQ_TLV_DELETE_MSG_MODE																(0x12)

//QMI_WMS_RAW_READ_REQ_V01
#define WMSI_REQ_TLV_RAW_READ_MSG_MEMORY_STORAGE_IDENTIFICATION		(0x01)
#define WMSI_REQ_TLV_RAW_READ_MSG_MODE																(0x10)
#define WMSI_REQ_TLV_RAW_READ_SMS_ON_IMS														(0x11)

//QMI_WMS_LIST_MESSAGES_REQ_V01
#define WMSI_REQ_TLV_LIST_MSG_REQUESTED_STORAGE								(0x01)
#define WMSI_REQ_TLV_LIST_MSG_REQUESTED_TAG										(0x10)
#define WMSI_REQ_TLV_LIST_MSG_MSG_MODE													(0x11)

//QMI_WMS_GET_SMSC_ADDRESS_REQ_V01

//QMI_WMS_SET_SMSC_ADDRESS_REQ_V01
#define WMSI_REQ_TLV_SET_SMSC_ADDRESS_SMSC_ADDRESS						(0x01)
#define	WMSI_REQ_TLV_SET_SMSC_ADDRESS_SMSC_ADDRESS_TYPE			(0x10)
#define	WMSI_REQ_TLV_SET_SMSC_ADDRESS_SMSC_ADDRESS_INDEX		(0x11)

//QMI_WMS_GET_MEMORY_STATUS_REQ_V01

//QMI_WMS_SET_ROUTES_REQ_V01
#define	WMSI_REQ_TLV_SET_ROUTES_ROUTE_LIST										(0x01)
#define	WMSI_REQ_TLV_SET_ROUTES_TRANSFER_STATUS_REPORT				(0x10)

//QMI_WMS_GET_STORE_MAX_SIZE_REQ_V01
#define WMSI_REQ_TLV_GET_STORE_MAX_SIZE_MEMORY_STORE					(0x01)
#define	WMSI_REQ_TLV_GET_STORE_MAX_SIZE_MESSAGE_MODE					(0x10)

//==============================================================
// response TLV
//==============================================================
//QMI_WMS_RAW_SEND_RESP_V01
#define WMSI_RSP_TLV_RAW_SEND_MSG_ID															(0x01)
#define WMSI_RSP_TLV_RAW_SEND_CAUSE_CODE												(0x10)
#define WMSI_RSP_TLV_RAW_SEND_ERROR_CLASS												(0x11)
#define WMSI_RSP_TLV_RAW_SEND_GW_CAUSE_INFO											(0x12)
#define WMSI_RSP_TLV_RAW_SEND_MSG_DELIVERY_FAIL_TYPE						(0x13)
#define WMSI_RSP_TLV_RAW_SEND_MSG_DELIVERY_FAIL_CAUSE					(0x14)
#define WMSI_RSP_TLV_RAW_SEND_CALL_CONTROL_MODIFICATION_INFO 	(0x15)

//QMI_WMS_DELETE_RESP_V01

//QMI_WMS_RAW_READ_RESP_V01
#define WMSI_RSP_TLV_RAW_READ_RAW_MSG_DATA		(0x01)

//QMI_WMS_LIST_MESSAGES_RESP_V01
#define WMSI_RSP_TLV_LIST_MSG_MSG_LIST					(0x01)

//QMI_WMS_GET_SMSC_ADDRESS_RESP_V01
#define WMSI_RSP_TLV_GET_SMSC_ADDRESS_SMSC_ADDRESS					(0x01)

//QMI_WMS_SET_SMSC_ADDRESS_RESP_V01

//QMI_WMS_GET_MEMORY_STATUS_RESP_V01
#define WMSI_RSP_TLV_GET_MEMORY_STATUS_MEMORY_STATUS_INFO (0x10)

//QMI_WMS_GET_STORE_MAX_SIZE_RESP_V01
#define	WMSI_RSP_TLV_GET_STORE_MAX_SIZE_MEMORY_STORE_SIZE	(0x01)
#define	WMSI_RSP_TLV_GET_STORE_MAX_SIZE_MEMORY_AVAILABLE	(0x10)

//==============================================================
// indication TLV
//==============================================================
//QMI_WMS_EVENT_REPORT_IND_V01
#define WMSI_IND_TLV_EVENT_RPT_MT_MSG										(0x10)
#define WMSI_IND_TLV_EVENT_RPT_TRANSFER_ROUTE_MT_MSG  	(0x11)
#define WMSI_IND_TLV_EVENT_RPT_MSG_MODE									(0x12)
#define WMSI_IND_TLV_EVENT_RPT_ETWS_MSG									(0x13)
#define WMSI_IND_TLV_EVENT_RPT_ETWS_PLMN_INFO						(0x14)
#define WMSI_IND_TLV_EVENT_RPT_SMSC_ADDR								(0x15)
#define WMSI_IND_TLV_EVENT_RPT_SMS_ON_IMS         			(0x16)
#define WMSI_IND_TLV_EVENT_RPT_CALL_CONTROL_RESULT			(0x17)



//**************************************************************
// public member
//**************************************************************



//**************************************************************
// private function
//**************************************************************
//==============================================================
//
//==============================================================
int qmi_wms_request_set_event_report( void )
{
	wms_set_event_report_req_msg_v01		wms_set_event_report_req_msg;
	wms_set_event_report_resp_msg_v01		wms_set_event_report_rsp_msg;

	memset( &wms_set_event_report_req_msg, 0, sizeof( wms_set_event_report_req_msg ) );
	memset( &wms_set_event_report_rsp_msg, 0, sizeof( wms_set_event_report_rsp_msg ) );

	//
  wms_set_event_report_req_msg.report_mt_message_valid = TRUE;
  wms_set_event_report_req_msg.report_mt_message = TRUE;

	if ( FALSE == qmi_core_request_sync( QMI_WMS_SERVICE, QMI_WMS_SET_EVENT_REPORT_REQ_V01, &wms_set_event_report_req_msg, &wms_set_event_report_rsp_msg ) )
	{
  	log_error( "qmi_core_request_sync() fail" );
    return FALSE;
	}

	log_med( "ok!" );

	return TRUE;
}

//==============================================================
//
//==============================================================
int	qmi_wms_request_set_routes( const wms_storage_type_enum_v01 wms_storage_type )
{
	wms_set_routes_req_msg_v01	qmi_wms_req;
	wms_set_routes_resp_msg_v01	qmi_wms_rsp;

	memset( &qmi_wms_req, 0, sizeof( qmi_wms_req ) );
	memset( &qmi_wms_rsp, 0, sizeof( qmi_wms_rsp ) );

	//
	qmi_wms_req.route_list_tuple_len = 1;
	qmi_wms_req.route_list_tuple[ 0 ].message_type = WMS_MESSAGE_TYPE_POINT_TO_POINT_V01;
	qmi_wms_req.route_list_tuple[ 0 ].message_class = WMS_MESSAGE_CLASS_NONE_V01;
	qmi_wms_req.route_list_tuple[ 0 ].route_storage = wms_storage_type;
	qmi_wms_req.route_list_tuple[ 0 ].receipt_action = WMS_STORE_AND_NOTIFY_V01;

	qmi_wms_req.transfer_ind_valid = TRUE;
	qmi_wms_req.transfer_ind = WMS_TRANSFER_IND_CLIENT_V01;
	
	if ( FALSE == qmi_core_request_sync( QMI_WMS_SERVICE, QMI_WMS_SET_ROUTES_REQ_V01, &qmi_wms_req, &qmi_wms_rsp ) )
	{
		log_error( "qmi_core_request_sync() fail" );
		return FALSE;
	}
	
	log_med( "ok!" );
	
	return TRUE;
}



//**************************************************************
// public function
//**************************************************************
//==============================================================
//
//==============================================================
int	qmi_wms_request_message_write_tlv( const int qmi_request_message_id, 
																						unsigned char** qmi_request_raw_message, 
																						int* const qmi_request_raw_message_size, 
																						const void* const qmi_request_message )
{
	unsigned int 		i = 0;
	
	unsigned char		temp_8bit 	= 0x00;
	unsigned short	temp_16bit 	= 0x0000;
	unsigned int		temp_32bit 	= 0x00000000;
  unsigned char		temp_var[ 1024 ];
	unsigned char*	temp_var_ptr = NULL;

	memset( temp_var, 0, sizeof( temp_var ) );

	log_med( "qmi_request_message_id:[0x%08x] write TLV", qmi_request_message_id );

	switch ( qmi_request_message_id )
	{
	case QMI_WMS_SET_EVENT_REPORT_REQ_V01:
		{
			wms_set_event_report_req_msg_v01* set_event_report_req = (wms_set_event_report_req_msg_v01*)qmi_request_message;

			if ( TRUE == set_event_report_req->report_mt_message_valid )
			{
				temp_8bit = set_event_report_req->report_mt_message;
				if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_SET_EVENT_RPT_NEW_MT_MSG_INDICATOR, sizeof( temp_8bit ), &temp_8bit ) < 0 ) return QMI_INTERNAL_ERR;
			}

			if ( TRUE == set_event_report_req->report_call_control_info_valid )
			{
				temp_8bit = set_event_report_req->report_call_control_info;
				if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_SET_EVENT_RPT_MO_SMS_CALL_CONTROL_INFO, sizeof( temp_8bit ), &temp_8bit ) < 0 ) return QMI_INTERNAL_ERR;
			}

			if ( TRUE == set_event_report_req->report_mwi_message_valid )
			{
				temp_8bit = set_event_report_req->report_mwi_message;
				if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_SET_EVENT_RPT_MWI_MSG_INDICATOR, sizeof( temp_8bit ), &temp_8bit ) < 0 ) return QMI_INTERNAL_ERR;
			}
		}
		break;
		
	case QMI_WMS_RAW_SEND_REQ_V01:
		{
			wms_raw_send_req_msg_v01* raw_send_req = (wms_raw_send_req_msg_v01*)qmi_request_message;

			temp_var_ptr = temp_var;
			
			WRITE_8_BIT_VAL( temp_var_ptr, raw_send_req->raw_message_data.format );
			WRITE_16_BIT_VAL( temp_var_ptr, raw_send_req->raw_message_data.raw_message_len );
			WRITE_VARIABLE_BIT_VALUE_AND_MOVE_DEST_POSITION( temp_var_ptr, raw_send_req->raw_message_data.raw_message, raw_send_req->raw_message_data.raw_message_len );

			if ( qmi_util_write_std_tlv( qmi_request_raw_message, 
																	qmi_request_raw_message_size,
																	WMSI_REQ_TLV_RAW_SEND_RAW_MSG_DATA, 
																	( temp_var_ptr - temp_var ),
																	temp_var ) < 0 )
			{
				return QMI_INTERNAL_ERR;
			}

			if ( TRUE == raw_send_req->force_on_dc_valid )
			{
				temp_var_ptr = temp_var;
				
				WRITE_8_BIT_VAL( temp_var_ptr, raw_send_req->force_on_dc.force_on_dc );
				WRITE_8_BIT_VAL( temp_var_ptr, raw_send_req->force_on_dc.so );
				
				if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_RAW_SEND_FORCE_ON_DC, ( temp_var_ptr - temp_var ), temp_var ) < 0 ) return QMI_INTERNAL_ERR;
			}

			if ( TRUE == raw_send_req->follow_on_dc_valid )
			{
				temp_8bit = raw_send_req->follow_on_dc;
				if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_RAW_SEND_FOLLOW_ON_DC, sizeof( temp_8bit ), &temp_8bit ) < 0 ) return QMI_INTERNAL_ERR;			
			}

			if ( TRUE == raw_send_req->link_timer_valid )
			{
				temp_8bit = raw_send_req->link_timer;
				if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_RAW_SEND_LINK_CONTROL, sizeof( temp_8bit ), &temp_8bit ) < 0 ) return QMI_INTERNAL_ERR;			
			}

			if ( TRUE == raw_send_req->sms_on_ims_valid )
			{
				temp_8bit = raw_send_req->sms_on_ims;
				if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_RAW_SEND_SMS_ON_IMS, sizeof( temp_8bit ), &temp_8bit ) < 0 ) return QMI_INTERNAL_ERR;			
			}

			if ( TRUE == raw_send_req->retry_message_valid )
			{
				temp_8bit = raw_send_req->retry_message;
				if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_RAW_SEND_RETRY_MSG, sizeof( temp_8bit ), &temp_8bit ) < 0 ) return QMI_INTERNAL_ERR;			
			}

			if ( TRUE == raw_send_req->retry_message_id_valid )
			{
				temp_32bit = raw_send_req->retry_message_id;
				if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_RAW_SEND_RETRY_MSG_ID, sizeof( temp_32bit ), &temp_32bit ) < 0 ) return QMI_INTERNAL_ERR;			
			}

			if ( TRUE == raw_send_req->link_enable_mode_valid )
			{
				temp_8bit = raw_send_req->link_enable_mode;
				if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_RAW_SEND_LINK_CONTROL_ENABLING_INFO, sizeof( temp_8bit ), &temp_8bit ) < 0 ) return QMI_INTERNAL_ERR;			
			}
		}
		break;

	case QMI_WMS_DELETE_REQ_V01:
		{
			wms_delete_req_msg_v01* delete_req = (wms_delete_req_msg_v01*)qmi_request_message;

			temp_8bit = delete_req->storage_type;
			if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_DELETE_MEMORY_STORAGE, sizeof( temp_8bit ), &temp_8bit ) < 0 ) return QMI_INTERNAL_ERR;

			if ( TRUE == delete_req->index_valid )
			{
				temp_32bit = delete_req->index;
				if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_DELETE_MEMORY_INDEX, sizeof( temp_32bit ), &temp_32bit ) < 0 ) return QMI_INTERNAL_ERR;
			}

			if ( TRUE == delete_req->tag_type_valid )
			{
				temp_8bit = delete_req->tag_type;
				if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_DELETE_MSG_TAG, sizeof( temp_8bit ), &temp_8bit ) < 0 ) return QMI_INTERNAL_ERR;
			}

			if ( TRUE == delete_req->message_mode_valid )
			{
				temp_8bit = delete_req->message_mode;
				if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_DELETE_MSG_MODE, sizeof( temp_8bit ), &temp_8bit ) < 0 ) return QMI_INTERNAL_ERR;
			}
		}
		break;

	case QMI_WMS_RAW_READ_REQ_V01:
		{
			wms_raw_read_req_msg_v01* raw_read_req = (wms_raw_read_req_msg_v01*)qmi_request_message;

			temp_var_ptr = temp_var;
			
			WRITE_8_BIT_VAL( temp_var_ptr, raw_read_req->message_memory_storage_identification.storage_type );
			WRITE_32_BIT_VAL( temp_var_ptr,raw_read_req->message_memory_storage_identification.storage_index );

			if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_RAW_READ_MSG_MEMORY_STORAGE_IDENTIFICATION, ( temp_var_ptr - temp_var ), temp_var ) < 0 ) return QMI_INTERNAL_ERR;

			if ( TRUE == raw_read_req->message_mode_valid )
			{
				temp_8bit = raw_read_req->message_mode;
				if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_RAW_READ_MSG_MODE, sizeof( temp_8bit ), &temp_8bit ) < 0 ) return QMI_INTERNAL_ERR;
			}

			if ( TRUE == raw_read_req->sms_on_ims_valid )
			{
				temp_8bit = raw_read_req->sms_on_ims;
				if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_RAW_READ_SMS_ON_IMS, sizeof( temp_8bit ), &temp_8bit ) < 0 ) return QMI_INTERNAL_ERR;
			}
		}
		break;

	case QMI_WMS_LIST_MESSAGES_REQ_V01:
		{
			wms_list_messages_req_msg_v01* list_messages_req = (wms_list_messages_req_msg_v01*)qmi_request_message;

			temp_8bit = list_messages_req->storage_type;
			if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_LIST_MSG_REQUESTED_STORAGE, sizeof( temp_8bit ), &temp_8bit ) < 0 ) return QMI_INTERNAL_ERR;

			if ( TRUE == list_messages_req->tag_type_valid )
			{
				temp_8bit = list_messages_req->tag_type;
				if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_LIST_MSG_REQUESTED_TAG, sizeof( temp_8bit ), &temp_8bit ) < 0 ) return QMI_INTERNAL_ERR;
			}

			if ( TRUE == list_messages_req->message_mode_valid )
			{
				temp_8bit = list_messages_req->message_mode;
				if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_LIST_MSG_MSG_MODE, sizeof( temp_8bit ), &temp_8bit ) < 0 ) return QMI_INTERNAL_ERR;
			}
		}
		break;

	case QMI_WMS_GET_SMSC_ADDRESS_REQ_V01:
		{
			wms_get_smsc_address_req_msg_v01* get_smsc_address_req = (wms_get_smsc_address_req_msg_v01*)qmi_request_message;
		}
		break;

	case QMI_WMS_SET_SMSC_ADDRESS_REQ_V01:
		{
			wms_set_smsc_address_req_msg_v01* set_smsc_address_req = (wms_set_smsc_address_req_msg_v01*)qmi_request_message;

			strcpy( (char*)temp_var, (const char*)( set_smsc_address_req->smsc_address_digits ) );
			temp_32bit = strlen( set_smsc_address_req->smsc_address_digits );
			temp_32bit++;	//count null character
			
			if ( qmi_util_write_std_tlv( qmi_request_raw_message, 
																	qmi_request_raw_message_size,
																	WMSI_REQ_TLV_SET_SMSC_ADDRESS_SMSC_ADDRESS, 
																	temp_32bit,
																	temp_var ) < 0 )
			{
				return QMI_INTERNAL_ERR;
			}

			if ( TRUE == set_smsc_address_req->smsc_address_type_valid )
			{
				strcpy( (char*)temp_var, (const char*)( set_smsc_address_req->smsc_address_type ) );
				temp_32bit = strlen( set_smsc_address_req->smsc_address_type );
				temp_32bit++;	//count null character

				if ( qmi_util_write_std_tlv( qmi_request_raw_message, 
																		qmi_request_raw_message_size,
																		WMSI_REQ_TLV_SET_SMSC_ADDRESS_SMSC_ADDRESS_TYPE, 
																		temp_32bit,
																		temp_var ) < 0 )
				{
					return QMI_INTERNAL_ERR;
				}
			}

			if ( TRUE == set_smsc_address_req->index_valid )
			{
				temp_8bit = set_smsc_address_req->index;
				if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_SET_SMSC_ADDRESS_SMSC_ADDRESS_INDEX, sizeof( temp_8bit ), &temp_8bit ) < 0 ) return QMI_INTERNAL_ERR;
			}
		}
		break;

	case QMI_WMS_GET_MEMORY_STATUS_REQ_V01:
		{
			wms_get_memory_status_req_msg_v01* get_memory_status_req = (wms_set_smsc_address_req_msg_v01*)qmi_request_message;
		}
		break;

	case QMI_WMS_SET_ROUTES_REQ_V01:
		{
			wms_set_routes_req_msg_v01* set_routes_req = (wms_set_routes_req_msg_v01*)qmi_request_message;

			temp_var_ptr = temp_var;
			
			WRITE_16_BIT_VAL( temp_var_ptr, set_routes_req->route_list_tuple_len );

			for ( i = 0; i < set_routes_req->route_list_tuple_len; ++i )
			{
				WRITE_8_BIT_VAL( temp_var_ptr, set_routes_req->route_list_tuple[ i ].message_type );
				WRITE_8_BIT_VAL( temp_var_ptr, set_routes_req->route_list_tuple[ i ].message_class );
				WRITE_8_BIT_VAL( temp_var_ptr, set_routes_req->route_list_tuple[ i ].route_storage );
				WRITE_8_BIT_VAL( temp_var_ptr, set_routes_req->route_list_tuple[ i ].receipt_action );
			}
			
			if ( qmi_util_write_std_tlv( qmi_request_raw_message, 
																	qmi_request_raw_message_size,
																	WMSI_REQ_TLV_SET_ROUTES_ROUTE_LIST, 
																	( temp_var_ptr - temp_var ),
																	temp_var ) < 0 )
			{
				return QMI_INTERNAL_ERR;
			}
			
			if ( TRUE == set_routes_req->transfer_ind_valid )
			{
				temp_8bit = set_routes_req->transfer_ind;
				if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_SET_ROUTES_TRANSFER_STATUS_REPORT, sizeof( temp_8bit ), &temp_8bit ) < 0 ) return QMI_INTERNAL_ERR;
			}
		}
		break;

	case QMI_WMS_GET_STORE_MAX_SIZE_REQ_V01:
		{
			wms_get_store_max_size_req_msg_v01* get_store_max_size_req = (wms_get_store_max_size_req_msg_v01*)qmi_request_message;

			temp_8bit = get_store_max_size_req->storage_type;
			if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_GET_STORE_MAX_SIZE_MEMORY_STORE, sizeof( temp_8bit ), &temp_8bit ) < 0 ) return QMI_INTERNAL_ERR;
			
			if ( TRUE == get_store_max_size_req->message_mode_valid )
			{
				temp_8bit = get_store_max_size_req->message_mode;
				if ( qmi_util_write_std_tlv( qmi_request_raw_message, qmi_request_raw_message_size, WMSI_REQ_TLV_GET_STORE_MAX_SIZE_MESSAGE_MODE, sizeof( temp_8bit ), &temp_8bit ) < 0 ) return QMI_INTERNAL_ERR;
			}
		}
		break;
		
	default:
		{
			log_error( "invalid qmi_request_message_id:[0x%08x]", qmi_request_message_id );
			return QMI_INTERNAL_ERR;
		}
		break;
	}

	return QMI_NO_ERR;
}

//==============================================================
//
//==============================================================
int	qmi_wms_response_message_read_tlv( const int qmi_response_message_id, 
																						const unsigned int qmi_response_message_field_type, 
																						const unsigned char* const qmi_response_message_field, 
																						const unsigned int qmi_response_message_field_size, 
																						void* qmi_response_message )
{
	unsigned int i = 0;
	unsigned char* message_field = qmi_response_message_field;
	
	log_med( "qmi_response_message_id:[0x%08x] read TLV, qmi_response_message_field_type:[0x%08x], qmi_response_message_field_size:[%d]", 
																	qmi_response_message_id, 
																	qmi_response_message_field_type,
																	qmi_response_message_field_size );
		
  switch( qmi_response_message_id )
	{
	case QMI_WMS_SET_EVENT_REPORT_REQ_V01:
		{
			wms_set_event_report_resp_msg_v01* set_event_report_rsp = (wms_set_event_report_resp_msg_v01*)qmi_response_message;
		}
		break;
		
	case QMI_WMS_RAW_SEND_REQ_V01:
		{
			wms_raw_send_resp_msg_v01* raw_send_rsp = (wms_raw_send_resp_msg_v01*)qmi_response_message;

			switch ( qmi_response_message_field_type )
			{
			case WMSI_RSP_TLV_RAW_SEND_MSG_ID:
				{
      		READ_16_BIT_VAL( message_field, raw_send_rsp->message_id );
				}
				break;
				
			case WMSI_RSP_TLV_RAW_SEND_CAUSE_CODE:
				{
					READ_16_BIT_VAL( message_field, raw_send_rsp->cause_code );
					raw_send_rsp->cause_code_valid = TRUE;
				}
				break;

			case WMSI_RSP_TLV_RAW_SEND_ERROR_CLASS:
				{
					READ_8_BIT_VAL( message_field, raw_send_rsp->error_class );
					raw_send_rsp->error_class_valid = TRUE;
				}
				break;

			case WMSI_RSP_TLV_RAW_SEND_GW_CAUSE_INFO:
				{
					READ_16_BIT_VAL( message_field, raw_send_rsp->gw_cause_info.rp_cause );
					READ_8_BIT_VAL( message_field, raw_send_rsp->gw_cause_info.tp_cause );
					raw_send_rsp->gw_cause_info_valid = TRUE;
				}
				break;

			case WMSI_RSP_TLV_RAW_SEND_MSG_DELIVERY_FAIL_TYPE:
				{
					READ_8_BIT_VAL( message_field, raw_send_rsp->message_delivery_failure_type );
					raw_send_rsp->message_delivery_failure_type_valid = TRUE;
				}
				break;

			case WMSI_RSP_TLV_RAW_SEND_MSG_DELIVERY_FAIL_CAUSE:
				{
					READ_8_BIT_VAL( message_field, raw_send_rsp->message_delivery_failure_cause );
					raw_send_rsp->message_delivery_failure_cause_valid = TRUE;
				}
				break;

			case WMSI_RSP_TLV_RAW_SEND_CALL_CONTROL_MODIFICATION_INFO:
				{
					READ_8_BIT_VAL( message_field, raw_send_rsp->call_control_modified_info.alpha_id_len );
					READ_VARIABLE_BIT_VALUE_AND_MOVE_SOURCE_POSITION( message_field, raw_send_rsp->call_control_modified_info.alpha_id, raw_send_rsp->call_control_modified_info.alpha_id_len );
					raw_send_rsp->call_control_modified_info_valid = TRUE;
				}
				break;
				
			default:
				break;
			}
		}
		break;

	case QMI_WMS_DELETE_REQ_V01:
		{
			wms_delete_resp_msg_v01* delete_rsp = (wms_delete_resp_msg_v01*)qmi_response_message;
		}
		break;

	case QMI_WMS_RAW_READ_REQ_V01:
		{
			wms_raw_read_resp_msg_v01* raw_read_rsp = (wms_raw_read_resp_msg_v01*)qmi_response_message;

			switch ( qmi_response_message_field_type )
			{
			case WMSI_RSP_TLV_RAW_READ_RAW_MSG_DATA:
				{
						READ_8_BIT_VAL( message_field, raw_read_rsp->raw_message_data.tag_type );
						READ_8_BIT_VAL( message_field, raw_read_rsp->raw_message_data.format );
						READ_16_BIT_VAL( message_field, raw_read_rsp->raw_message_data.data_len );
						READ_VARIABLE_BIT_VALUE_AND_MOVE_SOURCE_POSITION( message_field, raw_read_rsp->raw_message_data.data, raw_read_rsp->raw_message_data.data_len );

					#ifdef FEATURE_DEBUG_LOG
						log_low( "qmi_wms_raw_read_rsp->raw_message_data.data_len:[%d]",raw_read_rsp->raw_message_data.data_len );
						log_binary_data( raw_read_rsp->raw_message_data.data, raw_read_rsp->raw_message_data.data_len );
					#endif
				}
				break;
			}
		}
		break;

	case QMI_WMS_LIST_MESSAGES_REQ_V01:
		{
			wms_list_messages_resp_msg_v01* list_messages_rsp = (wms_list_messages_resp_msg_v01*)qmi_response_message;

			switch ( qmi_response_message_field_type )
			{
			case WMSI_RSP_TLV_LIST_MSG_MSG_LIST:
				{
      		READ_32_BIT_VAL( message_field, list_messages_rsp->message_tuple_len );

					for ( i = 0; i < list_messages_rsp->message_tuple_len; ++i )
					{
      			READ_32_BIT_VAL( message_field, list_messages_rsp->message_tuple[ i ].message_index );
      			READ_8_BIT_VAL( message_field, list_messages_rsp->message_tuple[ i ].tag_type );
					}
				}
				break;

			default:
				break;
			}
		}
		break;

	case QMI_WMS_GET_SMSC_ADDRESS_REQ_V01:
		{
			wms_get_smsc_address_resp_msg_v01* get_smsc_address_rsp = (wms_get_smsc_address_resp_msg_v01*)qmi_response_message;

			switch ( qmi_response_message_field_type )
			{
			case WMSI_RSP_TLV_GET_SMSC_ADDRESS_SMSC_ADDRESS:
				{
					READ_VARIABLE_BIT_VALUE_AND_MOVE_SOURCE_POSITION( message_field, get_smsc_address_rsp->smsc_address.smsc_address_type, sizeof( get_smsc_address_rsp->smsc_address.smsc_address_type ) );
    			READ_8_BIT_VAL( message_field, get_smsc_address_rsp->smsc_address.smsc_address_digits_len );
					READ_VARIABLE_BIT_VALUE_AND_MOVE_SOURCE_POSITION( message_field, get_smsc_address_rsp->smsc_address.smsc_address_digits, get_smsc_address_rsp->smsc_address.smsc_address_digits_len );
				}
				break;

			default:
				break;
			}
		}
		break;

	case QMI_WMS_SET_SMSC_ADDRESS_REQ_V01:
		{
			wms_set_smsc_address_resp_msg_v01* set_smsc_address_rsp = (wms_set_smsc_address_resp_msg_v01*)qmi_response_message;
		}
		break;

	case QMI_WMS_GET_MEMORY_STATUS_REQ_V01:
		{
			wms_get_memory_status_resp_msg_v01* get_memory_status_rsp = (wms_get_memory_status_resp_msg_v01*)qmi_response_message;

			switch ( qmi_response_message_field_type )
			{
			case WMSI_RSP_TLV_GET_MEMORY_STATUS_MEMORY_STATUS_INFO:
				{
					READ_8_BIT_VAL( message_field, get_memory_status_rsp->memory_available );
					get_memory_status_rsp->memory_available_valid = TRUE;
				}
				break;

			default:
				break;
			}
		}
		break;

	case QMI_WMS_SET_ROUTES_REQ_V01:
		{
			wms_set_routes_resp_msg_v01* set_routes_rsp = (wms_set_routes_resp_msg_v01*)qmi_response_message;
		}
		break;

	case QMI_WMS_GET_STORE_MAX_SIZE_REQ_V01:
		{
			wms_get_store_max_size_resp_msg_v01* get_store_max_size_rsp = (wms_get_store_max_size_resp_msg_v01*)qmi_response_message;

			switch ( qmi_response_message_field_type )
			{
			case WMSI_RSP_TLV_GET_STORE_MAX_SIZE_MEMORY_STORE_SIZE:
				{
					READ_32_BIT_VAL( message_field, get_store_max_size_rsp->mem_store_max_size );
				}
				break;

			case WMSI_RSP_TLV_GET_STORE_MAX_SIZE_MEMORY_AVAILABLE:
				{
					READ_32_BIT_VAL( message_field, get_store_max_size_rsp->free_slots );
					get_store_max_size_rsp->free_slots_valid = TRUE;
				}
				break;

			default:
				break;
			}
		}
		break;
		
	default:
		{
			log_error( "invalid qmi_response_message_id:[0x%08x]", qmi_response_message_id );
			return QMI_INTERNAL_ERR;
		}
		break;
	}    

	log_med( "ok! qmi_response_message_id:[0x%08x]", qmi_response_message_id );
	
  return QMI_NO_ERR;
}

//==============================================================
//
//==============================================================
int qmi_wms_indication_message_read_tlv( const int qmi_indication_message_id, 
																							const unsigned int qmi_indication_message_field_type, 
																							const unsigned char* const qmi_indication_message_field, 
																							const unsigned int qmi_indication_message_field_size, 
																							void* qmi_indication_message )
{
	unsigned char* message_field = qmi_indication_message_field;
	
	log_med( "qmi_indication_message_id:[0x%08x] read TLV, qmi_indication_message_field_type:[0x%08x], qmi_indication_message_field_size:[%d]", 
									qmi_indication_message_id, 
									qmi_indication_message_field_type,
									qmi_indication_message_field_size );

	switch ( qmi_indication_message_id )
	{
  case QMI_WMS_EVENT_REPORT_IND_V01:
		{
			wms_event_report_ind_msg_v01* event_report_ind_msg = (wms_event_report_ind_msg_v01*)qmi_indication_message;

			switch ( qmi_indication_message_field_type )
			{
			case WMSI_IND_TLV_EVENT_RPT_MT_MSG:
				{
      		READ_8_BIT_VAL( message_field, event_report_ind_msg->mt_message.storage_type );
					READ_32_BIT_VAL( message_field, event_report_ind_msg->mt_message.storage_index );
					event_report_ind_msg->mt_message_valid = TRUE;
				}
				break;
				
			case WMSI_IND_TLV_EVENT_RPT_TRANSFER_ROUTE_MT_MSG:
				{
      		READ_8_BIT_VAL( message_field, event_report_ind_msg->transfer_route_mt_message.ack_indicator );
      		READ_32_BIT_VAL( message_field, event_report_ind_msg->transfer_route_mt_message.transaction_id );
      		READ_8_BIT_VAL( message_field, event_report_ind_msg->transfer_route_mt_message.format );
      		READ_16_BIT_VAL( message_field, event_report_ind_msg->transfer_route_mt_message.data_len );
					READ_VARIABLE_BIT_VALUE_AND_MOVE_SOURCE_POSITION( message_field, event_report_ind_msg->transfer_route_mt_message.data, event_report_ind_msg->transfer_route_mt_message.data_len );
					event_report_ind_msg->transfer_route_mt_message_valid = TRUE;
				}
				break;
				
			case WMSI_IND_TLV_EVENT_RPT_MSG_MODE:
				{
      		READ_8_BIT_VAL( message_field, event_report_ind_msg->message_mode );
					event_report_ind_msg->message_mode_valid = TRUE;
				}
				break;
				
			case WMSI_IND_TLV_EVENT_RPT_ETWS_MSG:
				{
      		READ_8_BIT_VAL( message_field, event_report_ind_msg->etws_message.notification_type );
      		READ_16_BIT_VAL( message_field, event_report_ind_msg->etws_message.data_len );
					READ_VARIABLE_BIT_VALUE_AND_MOVE_SOURCE_POSITION( message_field, event_report_ind_msg->etws_message.data, event_report_ind_msg->etws_message.data_len );
					event_report_ind_msg->etws_message_valid = TRUE;
				}
				break;
				
			case WMSI_IND_TLV_EVENT_RPT_ETWS_PLMN_INFO:
				{
      		READ_16_BIT_VAL( message_field, event_report_ind_msg->etws_plmn_info.mobile_country_code );
      		READ_16_BIT_VAL( message_field, event_report_ind_msg->etws_plmn_info.mobile_network_code );
					event_report_ind_msg->etws_plmn_info_valid = TRUE;
				}
				break;
				
			case WMSI_IND_TLV_EVENT_RPT_SMSC_ADDR:
				{
      		READ_8_BIT_VAL( message_field, event_report_ind_msg->mt_message_smsc_address.data_len );
					READ_VARIABLE_BIT_VALUE_AND_MOVE_SOURCE_POSITION( message_field, event_report_ind_msg->mt_message_smsc_address.data, event_report_ind_msg->mt_message_smsc_address.data_len );
					event_report_ind_msg->mt_message_smsc_address_valid = TRUE;
				}
				break;
				
			case WMSI_IND_TLV_EVENT_RPT_SMS_ON_IMS:
				{
      		READ_8_BIT_VAL( message_field, event_report_ind_msg->sms_on_ims );
					event_report_ind_msg->sms_on_ims_valid = TRUE;
				}
				break;
				
			case WMSI_IND_TLV_EVENT_RPT_CALL_CONTROL_RESULT:
				{
      		READ_32_BIT_VAL( message_field, event_report_ind_msg->call_control_info.mo_control_type );
      		READ_8_BIT_VAL( message_field, event_report_ind_msg->call_control_info.alpha_id_len );
					READ_VARIABLE_BIT_VALUE_AND_MOVE_SOURCE_POSITION( message_field, event_report_ind_msg->call_control_info.alpha_id, event_report_ind_msg->call_control_info.alpha_id_len );
					event_report_ind_msg->call_control_info_valid = TRUE;
				}
				break;

			default:
				break;
			}
  	}
		break;
		
  case QMI_WMS_MEMORY_FULL_IND_V01:
		break;
		
  case QMI_WMS_MESSAGE_WAITING_IND_V01:
		break;
		
  case QMI_WMS_SMSC_ADDRESS_IND_V01:
		break;
		
  case QMI_WMS_TRANSPORT_LAYER_INFO_IND_V01:
		break;
		
  case QMI_WMS_TRANSPORT_NW_REG_INFO_IND_V01:
		break;
		
  case QMI_WMS_CALL_STATUS_IND_V01:
		break;
		
  case QMI_WMS_ASYNC_RAW_SEND_IND_V01:
		break;
		
	default:
		{
			log_error( "invalid qmi_indication_message_id, qmi_indication_message_id:[0x%08x]", qmi_indication_message_id );
			return QMI_INTERNAL_ERR;
		}
		break;
	}

	log_med( "ok! qmi_indication_message_id:[0x%08x]", qmi_indication_message_id );	

	return QMI_NO_ERR;
}



int qmi_wms_on_init( void )
{
	if ( FALSE == qmi_wms_request_set_event_report() )
	{
  	log_error( "qmi_wms_request_set_event_report() fail" );
		return FALSE;
	}

	if ( FALSE == qmi_wms_request_set_routes( WMS_STORAGE_TYPE_NV_V01 ) )
	{
  	log_error( "qmi_wms_request_set_routes() fail" );
		return FALSE;
	}

	log_med( "ok!" );
	return TRUE;
}




