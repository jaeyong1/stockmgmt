#ifndef QMI_VOICE_H
#define QMI_VOICE_H



#include "voice_service_v02.h"
#include "qmi_core.h"



#ifdef __cplusplus
extern "C" {
#endif



//**************************************************************
// public member
//**************************************************************
//QMI_VOICE_INDICATION_REGISTER_REQ_V02
#define VOICEI_REQ_TLV_IND_REG_DTMF_EVENTS																									(0x10)
#define VOICEI_REQ_TLV_IND_REG_VOICE_PRIVACY_EVENTS  																			(0x11)
#define VOICEI_REQ_TLV_IND_REG_SUPPLEMENTARY_SERVICE_NOTIFICATION_EVENTS								(0x12)
#define VOICEI_REQ_TLV_IND_REG_CALL_NOTIFICATION_EVENTS     																(0x13)
#define VOICEI_REQ_TLV_IND_REG_CALL_HANDOVER_EVENTS  																			(0x14)
#define VOICEI_REQ_TLV_IND_REG_SPEECH_CODEC_EVENTS																					(0x15)
#define VOICEI_REQ_TLV_IND_REG_USSD_NOTIFICATION_EVENTS																		(0x16)
#define VOICEI_REQ_TLV_IND_REG_SUPS_EVENTS																									(0x17)
#define VOICEI_REQ_TLV_IND_REG_MODIFICATION_EVENTS																					(0x18)
#define VOICEI_REQ_TLV_IND_REG_UUS_EVENTS																										(0x19)
#define VOICEI_REQ_TLV_IND_REG_AOC_EVENTS																										(0x1A)
#define VOICEI_REQ_TLV_IND_REG_CONFERENCE_EVENTS																						(0x1B)
#define VOICEI_REQ_TLV_IND_REG_EXTENDED_BURST_TYPE_INTERNATIONAL_INFORMATION_EVENTS 		(0x1C)

typedef enum
{
	qmi_voice_ind_reg_mask_none																													= 0x00000000,
	qmi_voice_ind_reg_mask_DTMF_EVENTS																									= 0x00000001,
	qmi_voice_ind_reg_mask_VOICE_PRIVACY_EVENTS  																			= 0x00000002,
	qmi_voice_ind_reg_mask_SUPPLEMENTARY_SERVICE_NOTIFICATION_EVENTS								= 0x00000004,
	qmi_voice_ind_reg_mask_CALL_NOTIFICATION_EVENTS     																= 0x00000008,
	qmi_voice_ind_reg_mask_CALL_HANDOVER_EVENTS  																			= 0x00000010,
	qmi_voice_ind_reg_mask_SPEECH_CODEC_EVENTS																					= 0x00000020,
	qmi_voice_ind_reg_mask_USSD_NOTIFICATION_EVENTS																		= 0x00000040,
	qmi_voice_ind_reg_mask_SUPS_EVENTS																									= 0x00000080,
	qmi_voice_ind_reg_mask_MODIFICATION_EVENTS																					= 0x00000100,
	qmi_voice_ind_reg_mask_UUS_EVENTS																										= 0x00000200,
	qmi_voice_ind_reg_mask_AOC_EVENTS																										= 0x00000400,
	qmi_voice_ind_reg_mask_CONFERENCE_EVENTS																						= 0x00000800,
	qmi_voice_ind_reg_mask_EXTENDED_BURST_TYPE_INTERNATIONAL_INFORMATION_EVENTS		= 0x00001000
} qmi_voice_indication_register_mask_e;



//**************************************************************
// public function
//**************************************************************
int	qmi_voice_request_message_write_tlv( const int qmi_request_message_id, 
																						unsigned char** qmi_request_raw_message, 
																						int* const qmi_request_raw_message_size, 
																						const void* const qmi_request_message );

int	qmi_voice_response_message_read_tlv( const int qmi_response_message_id, 
																					const unsigned int qmi_response_message_field_type, 
																					const unsigned char* const qmi_response_message_field, 
																					const unsigned int qmi_response_message_field_size, 
																					void* qmi_response_message );

int qmi_voice_indication_message_read_tlv( const int qmi_indication_message_id, 
																							const unsigned int qmi_indication_message_field_type, 
																							const unsigned char* const qmi_indication_message_field, 
																							const unsigned int qmi_indication_message_field_size, 
																							void* qmi_indication_message );

int qmi_voice_on_init( void );



#ifdef __cplusplus
}
#endif



#endif
