



#include "qmi_voice.h"



//**************************************************************
// private member
//**************************************************************
//==============================================================
// request TLV
//==============================================================
//QMI_VOICE_DIAL_CALL_REQ_V02
#define VOICEI_REQ_TLV_DIAL_CALL_CALLING_NUMBER																	(0x01)
#define VOICEI_REQ_TLV_DIAL_CALL_CALL_TYPE																			(0x10)
#define VOICEI_REQ_TLV_DIAL_CALL_CLIR_IN_TEMPORARY_MODE												(0x11)
#define VOICEI_REQ_TLV_DIAL_CALL_UUS																							(0x12)
#define VOICEI_REQ_TLV_DIAL_CALL_CUG																							(0x13)
#define VOICEI_REQ_TLV_DIAL_CALL_EMERGENCY_CATEGORY														(0x14)
#define VOICEI_REQ_TLV_DIAL_CALL_CALLED_PARTY_SUBADDRESS											(0x15)
#define VOICEI_REQ_TLV_DIAL_CALL_SERVICE_TYPE																		(0x16)
#define VOICEI_REQ_TLV_DIAL_CALL_SIP_URI_OVERFLOW															(0x17)
#define VOICEI_REQ_TLV_DIAL_CALL_AUDIO_ATTRIBUTE_FOR_VT_OR_VOIP_CALL					(0x18)
#define VOICEI_REQ_TLV_DIAL_CALL_VIDEO_ATTRIBUTE_FOR_VT_OR_VOIP_CALL					(0x19)
#define VOICEI_REQ_TLV_DIAL_CALL_PRESENTATION_INDICATOR_FOR_VT_OR_VOIP_CALL	(0x1A)

//==============================================================
// response TLV
//==============================================================
//QMI_VOICE_DIAL_CALL_RESP_V02
#define VOICEI_RSP_TLV_DIAL_CALL_CALL_ID																				(0x10)
#define VOICEI_RSP_TLV_DIAL_CALL_ALPHA_IDENTIFIER															(0x11)
#define VOICEI_RSP_TLV_DIAL_CALL_CALL_CONTROL_RESULT_TYPE											(0x12)
#define VOICEI_RSP_TLV_DIAL_CALL_CALL_CONTROL_SUPPLEMENTARY_SERVICE_TYPE		(0x13)
#define VOICEI_RSP_TLV_DIAL_CALL_END_REASON																			(0x14)

//==============================================================
// indication TLV
//==============================================================
//QMI_VOICE_ALL_CALL_STATUS_IND_V02



//**************************************************************
// public member
//**************************************************************



//**************************************************************
// private function
//**************************************************************



//**************************************************************
// public function
//**************************************************************
//==============================================================
//
//==============================================================
int	qmi_voice_request_message_write_tlv( const int qmi_request_message_id, 
																						unsigned char** qmi_request_raw_message, 
																						int* const qmi_request_raw_message_size, 
																						const void* const qmi_request_message )
{
	unsigned int 		i = 0;
	
	unsigned char		temp_8bit 	= 0x00;
	unsigned short	temp_16bit 	= 0x0000;
	unsigned int		temp_32bit 	= 0x00000000;
  unsigned char		temp_var[ 1024 ];
	unsigned char*	temp_var_ptr = NULL;

	memset( temp_var, 0, sizeof( temp_var ) );

	log_med( "qmi_request_message_id:[0x%08x] write TLV", qmi_request_message_id );

	switch ( qmi_request_message_id )
	{
	case QMI_VOICE_DIAL_CALL_REQ_V02:
		{
			voice_dial_call_req_msg_v02* dial_call_req = (voice_dial_call_req_msg_v02*)qmi_request_message;

			temp_var_ptr = temp_var;
			
			WRITE_VARIABLE_BIT_VALUE_AND_MOVE_DEST_POSITION( temp_var_ptr, dial_call_req->calling_number, strlen( dial_call_req->calling_number ) );

			if ( qmi_util_write_std_tlv( qmi_request_raw_message, 
																	qmi_request_raw_message_size,
																	VOICEI_REQ_TLV_DIAL_CALL_CALLING_NUMBER, 
																	( temp_var_ptr - temp_var ),
																	temp_var ) < 0 )
			{
				return QMI_INTERNAL_ERR;
			}
		}
		break;

	default:
		{
			log_error( "invalid qmi_request_message_id:[0x%08x]", qmi_request_message_id );
			return QMI_INTERNAL_ERR;
		}
		break;
	}

	return QMI_NO_ERR;
}

//==============================================================
//
//==============================================================
int	qmi_voice_response_message_read_tlv( const int qmi_response_message_id, 
																						const unsigned int qmi_response_message_field_type, 
																						const unsigned char* const qmi_response_message_field, 
																						const unsigned int qmi_response_message_field_size, 
																						void* qmi_response_message )
{
	unsigned int i = 0;
	unsigned char* message_field = qmi_response_message_field;
	
	log_med( "qmi_response_message_id:[0x%08x] read TLV, qmi_response_message_field_type:[0x%08x], qmi_response_message_field_size:[%d]", 
																	qmi_response_message_id, 
																	qmi_response_message_field_type,
																	qmi_response_message_field_size );
		
  switch( qmi_response_message_id )
	{
	case QMI_VOICE_DIAL_CALL_REQ_V02:
		{
			voice_dial_call_resp_msg_v02* dial_call_rsp = (voice_dial_call_resp_msg_v02*)qmi_response_message;

			switch ( qmi_response_message_field_type )
			{
			default:
				break;
			}
		}
		break;

	default:
		{
			log_error( "invalid qmi_response_message_id:[0x%08x]", qmi_response_message_id );
			return QMI_INTERNAL_ERR;
		}
		break;
	}    

	log_med( "ok! qmi_response_message_id:[0x%08x]", qmi_response_message_id );
	
  return QMI_NO_ERR;
}

//==============================================================
//
//==============================================================
int qmi_voice_indication_message_read_tlv( const int qmi_indication_message_id, 
																							const unsigned int qmi_indication_message_field_type, 
																							const unsigned char* const qmi_indication_message_field, 
																							const unsigned int qmi_indication_message_field_size, 
																							void* qmi_indication_message )
{
	unsigned char* message_field = qmi_indication_message_field;
	
	log_med( "qmi_indication_message_id:[0x%08x] read TLV, qmi_indication_message_field_type:[0x%08x], qmi_indication_message_field_size:[%d]", 
									qmi_indication_message_id, 
									qmi_indication_message_field_type,
									qmi_indication_message_field_size );

	switch ( qmi_indication_message_id )
	{
  case QMI_VOICE_ALL_CALL_STATUS_IND_V02:
		{
			voice_all_call_status_ind_msg_v02* all_call_status_ind_msg = (voice_all_call_status_ind_msg_v02*)qmi_indication_message;

			switch ( qmi_indication_message_field_type )
			{
			default:
				break;
			}
  	}
		break;
		
	default:
		{
			log_error( "invalid qmi_indication_message_id, qmi_indication_message_id:[0x%08x]", qmi_indication_message_id );
			return QMI_INTERNAL_ERR;
		}
		break;
	}

	log_med( "ok! qmi_indication_message_id:[0x%08x]", qmi_indication_message_id );	

	return QMI_NO_ERR;
}



//==============================================================
//
//==============================================================
int qmi_voice_on_init( void )
{
	log_med( "ok!" );
	
	return TRUE;
}








