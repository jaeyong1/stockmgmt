#include "qmi_wms.h"
#include "qmi_voice.h"
#include "qmi_core.h"



//**************************************************************
// private member
//**************************************************************
typedef struct
{
	qmi_service_id_type		qmi_service_id;
	unsigned int 					qmi_indication_register_mask;
	unsigned int 					qmi_indication_register_value;
} qmi_indication_register_mask_to_value_info_s;



typedef struct
{
	unsigned int 	qmi_request_message_id;
	unsigned int	qmi_indication_register_masks;
} qmi_indication_register_request_parameter_info_s;



typedef struct
{
	qmi_request_message_write_tlv_type_f		qmi_request_message_write_tlv;
	qmi_response_message_read_tlv_type_f		qmi_response_message_read_tlv;
	qmi_indication_message_read_tlv_type_f	qmi_indication_message_read_tlv;
} qmi_tlv_io_function_info_s;



typedef struct
{
	qmi_service_id_type			qmi_service_id;
	qmi_client_handle_type	qmi_client_handle;
	qmi_indication_register_request_parameter_info_s qmi_indication_register_request_parameter_info;
	qmi_tlv_io_function_info_s	qmi_tlv_io_function_info;
	qmi_on_init_type_f		qmi_on_init;
} qmi_service_info_s;



qmi_service_info_s m_qmi_service_info_table[] =
{
	//sms
	{ QMI_WMS_SERVICE, 
		QMI_INVALID_CLIENT_HANDLE, 
		{ QMI_WMS_INDICATION_REGISTER_REQ_V01, qmi_wms_ind_reg_mask_none }, 
		{ qmi_wms_request_message_write_tlv, qmi_wms_response_message_read_tlv, qmi_wms_indication_message_read_tlv },
		qmi_wms_on_init },
/*
	//voice
	{ QMI_VOICE_SERVICE, 
		QMI_INVALID_CLIENT_HANDLE, 
		{ QMI_VOICE_INDICATION_REGISTER_REQ_V02, qmi_voice_ind_reg_mask_CALL_NOTIFICATION_EVENTS }, 
		{ qmi_voice_request_message_write_tlv, qmi_voice_response_message_read_tlv, qmi_voice_indication_message_read_tlv },
		qmi_voice_on_init }
*/		
};



qmi_request_message_info_s		m_qmi_request_message_info_table[] =
{
	//sms
	{ QMI_WMS_SERVICE, QMI_WMS_RAW_SEND_REQ_V01, 						sizeof( wms_raw_send_req_msg_v01 ), 						sizeof( wms_raw_send_resp_msg_v01 ) },
	{ QMI_WMS_SERVICE, QMI_WMS_DELETE_REQ_V01, 							sizeof( wms_delete_req_msg_v01 ), 							sizeof( wms_delete_resp_msg_v01 ) },
	{ QMI_WMS_SERVICE, QMI_WMS_RAW_READ_REQ_V01,						sizeof( wms_raw_read_req_msg_v01 ),							sizeof( wms_raw_read_resp_msg_v01 ) },				
	{ QMI_WMS_SERVICE, QMI_WMS_LIST_MESSAGES_REQ_V01,				sizeof( wms_list_messages_req_msg_v01 ),				sizeof( wms_list_messages_resp_msg_v01 ) },
	{ QMI_WMS_SERVICE, QMI_WMS_GET_SMSC_ADDRESS_REQ_V01, 		sizeof( wms_get_smsc_address_req_msg_v01 ),			sizeof( wms_get_smsc_address_resp_msg_v01 ) },
	{ QMI_WMS_SERVICE, QMI_WMS_SET_SMSC_ADDRESS_REQ_V01, 		sizeof( wms_set_smsc_address_req_msg_v01 ),			sizeof( wms_set_smsc_address_resp_msg_v01 ) },
	{ QMI_WMS_SERVICE, QMI_WMS_GET_STORE_MAX_SIZE_REQ_V01,	sizeof( wms_get_store_max_size_req_msg_v01 ), 	sizeof( wms_get_store_max_size_resp_msg_v01 ) },
	{ QMI_WMS_SERVICE, QMI_WMS_GET_MEMORY_STATUS_REQ_V01,		sizeof( wms_get_memory_status_req_msg_v01 ), 		sizeof( wms_get_memory_status_resp_msg_v01 ) },
	{ QMI_WMS_SERVICE, QMI_WMS_SET_ROUTES_REQ_V01,					sizeof( wms_set_routes_req_msg_v01 ), 					sizeof( wms_set_routes_resp_msg_v01 ) },
	{ QMI_WMS_SERVICE, QMI_WMS_GET_STORE_MAX_SIZE_REQ_V01,	sizeof( wms_get_store_max_size_req_msg_v01 ), 	sizeof( wms_get_store_max_size_resp_msg_v01 ) },
	//voice
	{ QMI_VOICE_SERVICE, QMI_VOICE_DIAL_CALL_REQ_V02,				sizeof( voice_dial_call_req_msg_v02 ), 					sizeof( voice_dial_call_resp_msg_v02 ) }
};



qmi_indication_message_info_s	m_qmi_indication_message_info_table[] =
{
	//sms
	{ QMI_WMS_SERVICE, QMI_WMS_EVENT_REPORT_IND_V01,					sizeof( wms_event_report_ind_msg_v01 ) },
  { QMI_WMS_SERVICE, QMI_WMS_MEMORY_FULL_IND_V01,						sizeof( wms_memory_full_ind_msg_v01 ) },
  { QMI_WMS_SERVICE, QMI_WMS_MESSAGE_WAITING_IND_V01,				sizeof( wms_message_waiting_ind_msg_v01 ) },
  { QMI_WMS_SERVICE, QMI_WMS_SMSC_ADDRESS_IND_V01,					sizeof( wms_smsc_address_ind_msg_v01 ) },
  { QMI_WMS_SERVICE, QMI_WMS_TRANSPORT_LAYER_INFO_IND_V01,	sizeof( wms_transport_layer_info_ind_msg_v01 ) },
  { QMI_WMS_SERVICE, QMI_WMS_TRANSPORT_NW_REG_INFO_IND_V01,	sizeof( wms_transport_nw_reg_info_ind_msg_v01 ) },
  { QMI_WMS_SERVICE, QMI_WMS_CALL_STATUS_IND_V01,						sizeof( wms_call_status_ind_msg_v01 ) },
  { QMI_WMS_SERVICE, QMI_WMS_ASYNC_RAW_SEND_IND_V01,				sizeof( wms_async_raw_send_ind_msg_v01 ) },
	//voice
  { QMI_VOICE_SERVICE, QMI_VOICE_ALL_CALL_STATUS_IND_V02,		sizeof( voice_all_call_status_ind_msg_v02 ) }	
};



qmi_indication_register_mask_to_value_info_s m_qmi_indication_register_mask_to_value_info_table[] =
{
	//sms
	{ QMI_WMS_SERVICE, 		qmi_wms_ind_reg_mask_TRANSPORT_LAYER_INFO_EVENTS,			WMSI_REQ_TLV_IND_REG_TRANSPORT_LAYER_INFO_EVENTS },
	{ QMI_WMS_SERVICE, 		qmi_wms_ind_reg_mask_TRANSPORT_NW_REG_INFO_EVENTS,		WMSI_REQ_TLV_IND_REG_TRANSPORT_NW_REG_INFO_EVENTS },
	{ QMI_WMS_SERVICE, 		qmi_wms_ind_reg_mask_CALL_STATUS_INFO_EVENTS,					WMSI_REQ_TLV_IND_REG_CALL_STATUS_INFO_EVENTS },
	{ QMI_WMS_SERVICE, 		qmi_wms_ind_reg_mask_SERVICE_READY_EVENTS,						WMSI_REQ_TLV_IND_REG_SERVICE_READY_EVENTS },
	{ QMI_WMS_SERVICE, 		qmi_wms_ind_reg_mask_BROADCAST_CONFIG_EVENTS,					WMSI_REQ_TLV_IND_REG_BROADCAST_CONFIG_EVENTS },
	{ QMI_WMS_SERVICE, 		qmi_wms_ind_reg_mask_TRANSPORT_LAYER_MWI_INFO_EVENTS,	WMSI_REQ_TLV_IND_REG_TRANSPORT_LAYER_MWI_INFO_EVENTS },
	{ QMI_WMS_SERVICE, 		qmi_wms_ind_reg_mask_SIM_READY_INFO_EVENTS,						WMSI_REQ_TLV_IND_REG_SIM_READY_INFO_EVENTS },
	//voice
	{ QMI_VOICE_SERVICE, 	qmi_voice_ind_reg_mask_DTMF_EVENTS,																						VOICEI_REQ_TLV_IND_REG_DTMF_EVENTS },
	{ QMI_VOICE_SERVICE, 	qmi_voice_ind_reg_mask_VOICE_PRIVACY_EVENTS,																	VOICEI_REQ_TLV_IND_REG_VOICE_PRIVACY_EVENTS },
	{ QMI_VOICE_SERVICE, 	qmi_voice_ind_reg_mask_SUPPLEMENTARY_SERVICE_NOTIFICATION_EVENTS,							VOICEI_REQ_TLV_IND_REG_SUPPLEMENTARY_SERVICE_NOTIFICATION_EVENTS },
	{ QMI_VOICE_SERVICE, 	qmi_voice_ind_reg_mask_CALL_NOTIFICATION_EVENTS,															VOICEI_REQ_TLV_IND_REG_CALL_NOTIFICATION_EVENTS },
	{ QMI_VOICE_SERVICE, 	qmi_voice_ind_reg_mask_CALL_HANDOVER_EVENTS,																	VOICEI_REQ_TLV_IND_REG_CALL_HANDOVER_EVENTS },
	{ QMI_VOICE_SERVICE, 	qmi_voice_ind_reg_mask_SPEECH_CODEC_EVENTS,																		VOICEI_REQ_TLV_IND_REG_SPEECH_CODEC_EVENTS },
	{ QMI_VOICE_SERVICE, 	qmi_voice_ind_reg_mask_USSD_NOTIFICATION_EVENTS,															VOICEI_REQ_TLV_IND_REG_USSD_NOTIFICATION_EVENTS },
	{ QMI_VOICE_SERVICE, 	qmi_voice_ind_reg_mask_SUPS_EVENTS,																						VOICEI_REQ_TLV_IND_REG_SUPS_EVENTS },
	{ QMI_VOICE_SERVICE, 	qmi_voice_ind_reg_mask_MODIFICATION_EVENTS,																		VOICEI_REQ_TLV_IND_REG_MODIFICATION_EVENTS },
	{ QMI_VOICE_SERVICE, 	qmi_voice_ind_reg_mask_UUS_EVENTS,																						VOICEI_REQ_TLV_IND_REG_UUS_EVENTS },
	{ QMI_VOICE_SERVICE, 	qmi_voice_ind_reg_mask_AOC_EVENTS,																						VOICEI_REQ_TLV_IND_REG_AOC_EVENTS },
	{ QMI_VOICE_SERVICE, 	qmi_voice_ind_reg_mask_CONFERENCE_EVENTS,																			VOICEI_REQ_TLV_IND_REG_CONFERENCE_EVENTS },
	{ QMI_VOICE_SERVICE, 	qmi_voice_ind_reg_mask_EXTENDED_BURST_TYPE_INTERNATIONAL_INFORMATION_EVENTS,	VOICEI_REQ_TLV_IND_REG_EXTENDED_BURST_TYPE_INTERNATIONAL_INFORMATION_EVENTS }
};



//**************************************************************
// public member
//**************************************************************



//**************************************************************
// private function
//**************************************************************
//==============================================================
//
//==============================================================
const qmi_service_info_s* const qmi_get_qmi_service_info( qmi_service_id_type qmi_service_id )
{
	unsigned int i = 0;

	//
	for ( i = 0; i < sizeof( m_qmi_service_info_table ) / sizeof( qmi_service_info_s ); ++i )
	{
		if ( qmi_service_id == m_qmi_service_info_table[ i ].qmi_service_id )
		{
			return &( m_qmi_service_info_table[ i ] );
		}
	}

	log_error( "fail, qmi_service_id:[%d]", qmi_service_id );

	return NULL;
}

//==============================================================
//
//==============================================================
int qmi_service_dispatch_indication( 	const qmi_service_info_s* const qmi_service_info,
																					const unsigned int qmi_indication_message_id,
																					const unsigned char* const qmi_indication_raw_message, 
																					const int qmi_indication_raw_message_size,
																					void* qmi_indication_message )
{
  unsigned long  qmi_indication_message_field_type = 0;
  unsigned long  qmi_indication_message_field_size = 0;
  unsigned char* qmi_indication_message_field = NULL;

	int temp_qmi_indication_raw_message_size = qmi_indication_raw_message_size;

  while ( temp_qmi_indication_raw_message_size > 0 )
  {
    if ( qmi_util_read_std_tlv( &qmi_indication_raw_message,
                                &temp_qmi_indication_raw_message_size,
                                &qmi_indication_message_field_type,
                                &qmi_indication_message_field_size,
                                &qmi_indication_message_field ) >= 0 )
  	{
			if ( QMI_NO_ERR != qmi_service_info->qmi_tlv_io_function_info.qmi_indication_message_read_tlv( qmi_indication_message_id, 
																																																				qmi_indication_message_field_type, 
																																																				qmi_indication_message_field, 
																																																				qmi_indication_message_field_size, 
																																																				qmi_indication_message ) )
			{
				log_error( "qmi_service->service_info->qmi_indication_message_read_tlv() fail" );

				return FALSE;
			}
  	}
		else
    {
    	log_error( "qmi_util_read_std_tlv() fail, qmi_indication_message_id:[0x%08x]", qmi_indication_message_id );

			return FALSE;
    }
   }

	log_med( "ok!" );

	return TRUE;
}

//==============================================================
//
//==============================================================
void qmi_service_indication_callback( const qmi_client_handle_type qmi_client_handle,
																		const qmi_service_id_type qmi_service_id,
																		const unsigned int qmi_indication_message_id,
																		const qmi_indication_callback_type_f const user_qmi_indication_callback,
																		const void* const user_qmi_indication_callback_user_data,
																		const unsigned char* const qmi_indication_raw_message,
																		const int qmi_indication_raw_message_size )
{
	qmi_service_info_s* 	qmi_service_info = NULL;
	qmi_indication_message_info_s*		qmi_indication_message_info = NULL;
	void* qmi_indication_message = NULL;

	//
	log_med( "qmi_service_id:[%d], qmi_indication_message_id:[0x%08x], qmi_indication_raw_message_size:[%d]", qmi_service_id, qmi_indication_message_id, qmi_indication_raw_message_size );
	
	if ( QMI_INVALID_CLIENT_HANDLE == qmi_client_handle )
	{
		log_error( "invalid qmi_client_handle" );
		return;
	}

	qmi_service_info = qmi_get_qmi_service_info( qmi_service_id );

	if ( NULL == qmi_service_info )
	{
		log_error( "qmi_service_info is null, qmi_service_id:[%d]", qmi_service_id );
		return;
	}

	qmi_indication_message_info = qmi_get_qmi_indication_message_info( qmi_service_id, qmi_indication_message_id );

	if ( NULL == qmi_indication_message_info )
	{
		log_error( "qmi_indication_message_info is null, qmi_service_id:[%d], qmi_indication_message_id:[0x%08x]", qmi_service_id, qmi_indication_message_id );
		return;
	}

	qmi_indication_message = mem_alloc( qmi_indication_message_info->qmi_indication_message_size );

	if ( NULL == qmi_indication_message )
	{
		log_error( "qmi_indication_message allocation fail" );
		return;
	}

	memset( qmi_indication_message, 0, qmi_indication_message_info->qmi_indication_message_size );

	if ( FALSE == qmi_service_dispatch_indication( qmi_service_info,
																											qmi_indication_message_id, 
																											qmi_indication_raw_message, 
																											qmi_indication_raw_message_size, 
																											qmi_indication_message ) )
	{
		mem_free( qmi_indication_message );
		
		log_error( "qmi_indication_message_read_tlv() fail" );
		return;
	}

  user_qmi_indication_callback( qmi_client_handle, 
																		qmi_service_id, 
																		user_qmi_indication_callback_user_data, 
																		qmi_indication_message_id, 
																		qmi_indication_message );
	
	mem_free( qmi_indication_message );
}

//==============================================================
//
//==============================================================
int qmi_service_dispatch_response( 	const qmi_service_info_s* const qmi_service_info,
																				const int qmi_error_code,
																				const int qmi_service_error_code,
																				const unsigned int qmi_response_message_id,
																				const unsigned char* const qmi_response_raw_message, 
																				const int qmi_response_raw_message_size,
																				void* qmi_response_message )
{
  unsigned long  qmi_response_message_field_type = 0;
  unsigned long  qmi_response_message_field_size = 0;
  unsigned char* qmi_response_message_field = NULL;

	int temp_qmi_response_raw_message_size = qmi_response_raw_message_size;

  qmi_response_type_v01* qmi_response_message_base = (qmi_response_type_v01*)qmi_response_message;

  if ( QMI_SERVICE_ERR_NONE == qmi_service_error_code && QMI_NO_ERR == qmi_error_code )
  {
    qmi_response_message_base->result = (qmi_result_type_v01)QMI_RESULT_SUCCESS_V01;
  }
  else
  {
    qmi_response_message_base->result = (qmi_result_type_v01)QMI_RESULT_FAILURE_V01;
  }
  qmi_response_message_base->error = (qmi_error_type_v01)qmi_service_error_code;

	log_med( "qmi_response_message_id:[0x%08x], qmi_error_code:[%d], qmi_service_error_code:[%d], qmi_response_raw_message_size:[%d]", 
									qmi_response_message_id, qmi_error_code, qmi_service_error_code, qmi_response_raw_message_size );

  while ( temp_qmi_response_raw_message_size > 0 )
  {
    if ( qmi_util_read_std_tlv( &qmi_response_raw_message,
                                &temp_qmi_response_raw_message_size,
                                &qmi_response_message_field_type,
                                &qmi_response_message_field_size,
                                &qmi_response_message_field ) >= 0 )
  	{
			if ( QMI_NO_ERR != qmi_service_info->qmi_tlv_io_function_info.qmi_response_message_read_tlv( qmi_response_message_id, 
																																																		qmi_response_message_field_type, 
																																																		qmi_response_message_field, 
																																																		qmi_response_message_field_size, 
																																																		qmi_response_message ) )
			{
				log_error( "qmi_service->service_info->qmi_response_message_read_tlv() fail" );

				return FALSE;
			}
  	}
		else
    {
    	log_error( "qmi_util_read_std_tlv() fail, qmi_response_message_id:[0x%08x]", qmi_response_message_id );

			return FALSE;
    }
   }

	log_med( "ok!" );

	return TRUE;
}

//==============================================================
//
//==============================================================
void qmi_service_async_callback( const qmi_client_handle_type qmi_client_handle,
																			const qmi_service_id_type qmi_service_id,
																			const unsigned int qmi_response_message_id,
																			const int qmi_error_code,
																			const int qmi_service_error_code,
																			const unsigned char* const qmi_response_raw_message,
																			const int qmi_response_raw_message_size,
																			const void* const qmi_async_cb_data,
																			const qmi_async_callback_type_f const user_qmi_async_callback,
																			const void* const user_qmi_async_data )
{
	qmi_service_info_s* 	qmi_service_info = NULL;
	qmi_request_message_info_s*	qmi_request_message_info = NULL;
	void* qmi_response_message = NULL;

	//
	log_med( "qmi_service_id:[%d], qmi_response_message_id:[0x%08x], qmi_error_code:[%d], qmi_service_error_code:[%d], qmi_response_raw_message_size:[%d]",
							qmi_service_id, qmi_response_message_id, qmi_error_code, qmi_service_error_code, qmi_response_raw_message_size );

	if ( QMI_INVALID_CLIENT_HANDLE == qmi_client_handle )
	{
		log_error( "invalid qmi_client_handle" );
		return;
	}
	
	qmi_service_info = qmi_get_qmi_service_info( qmi_service_id );

	if ( NULL == qmi_service_info )
	{
		log_error( "qmi_service_info is null, qmi_service_id:[%d]", qmi_service_id );
		return;
	}
	
	qmi_request_message_info = qmi_get_qmi_request_message_info( qmi_service_id, qmi_response_message_id );

	if ( NULL == qmi_request_message_info )
	{
		log_error( "qmi_request_message_info is null, qmi_service_id:[%d], qmi_response_message_id:[0x%08x]", qmi_service_id, qmi_response_message_id );
		return;
	}
	
	qmi_response_message = mem_alloc( qmi_request_message_info->qmi_response_message_size );

	if ( NULL == qmi_response_message )
	{
		log_error( "qmi_response_message allocation fail" );
		return;
	}

	memset( qmi_response_message, 0, qmi_request_message_info->qmi_response_message_size );

	if ( FALSE == qmi_service_dispatch_response( qmi_service_info,
																										qmi_error_code,
																										qmi_service_error_code,
																										qmi_response_message_id, 
																										qmi_response_raw_message, 
																										qmi_response_raw_message_size, 
																										qmi_response_message ) )
	{
		mem_free( qmi_response_message );
		
		log_error( "qmi_service_dispatch_response() fail" );
		return;
	}

	user_qmi_async_callback( qmi_client_handle, 
															qmi_service_id, 
															user_qmi_async_data, 
															qmi_response_message_id, 
															qmi_response_message );

	mem_free( qmi_response_message );
}

//==============================================================
//
//==============================================================
qmi_client_handle_type qmi_service_internal_init( const char* const qmi_device_id,
																				const qmi_service_id_type qmi_service_id,
																				const qmi_indication_callback_type_f const user_qmi_indication_callback,
																				const void* const user_qmi_indication_callback_user_data,
																				int* qmi_service_error_code )
{
	int qmi_error_code = QMI_NO_ERR;
	*qmi_service_error_code = QMI_SERVICE_ERR_NONE;
	
	qmi_connection_id_type qmi_conn_id = QMI_CONN_ID_INVALID;
	
  qmi_client_handle_type qmi_client_handle = QMI_INVALID_CLIENT_HANDLE;

	//
	if ( NULL == qmi_device_id )
	{
		log_error( "device id is null" );
		return QMI_INVALID_CLIENT_HANDLE;
	}
	
	qmi_conn_id = QMI_PLATFORM_DEV_NAME_TO_CONN_ID( qmi_device_id );
	
	if ( QMI_CONN_ID_INVALID == qmi_device_id )
	{
		log_error( "can't get qmi connection id" );
		return QMI_INVALID_CLIENT_HANDLE;
	}
		
	qmi_client_handle = qmi_service_init( qmi_conn_id, 
																				qmi_service_id,
																				(void*)user_qmi_indication_callback,
																				user_qmi_indication_callback_user_data,
																				qmi_service_error_code );
	
	if ( QMI_INVALID_CLIENT_HANDLE == qmi_client_handle )
	{
		log_error( "qmi_service_init() fail, qmi_service_error_code:[%d]", *qmi_service_error_code );
		return QMI_INVALID_CLIENT_HANDLE;
	}

	qmi_error_code = qmi_service_set_srvc_functions( qmi_service_id, qmi_service_indication_callback );

	if ( QMI_NO_ERR != qmi_error_code )
	{
		int tmp_qmi_srvc_err_code = QMI_SERVICE_ERR_NONE;
		
		log_error( "qmi_service_set_srvc_functions() fail, qmi_error_code:[%d]", qmi_error_code );
		
		qmi_service_internal_release( qmi_client_handle, &tmp_qmi_srvc_err_code );
		return QMI_INVALID_CLIENT_HANDLE;
	}
	
	log_med( "ok! qmi_client_handle:[%d], qmi_service_id:[%d]", qmi_client_handle, qmi_service_id );
 
  return qmi_client_handle;
}

//==============================================================
//
//==============================================================
void qmi_service_internal_release( const qmi_client_handle_type qmi_client_handle, 
																			const qmi_service_id_type qmi_service_id,
																			int* qmi_service_error_code )
{
	int qmi_error_code = QMI_NO_ERR;
	*qmi_service_error_code = QMI_SERVICE_ERR_NONE;

	//
	if ( QMI_INVALID_CLIENT_HANDLE == qmi_client_handle )
	{
		log_error( "invalid qmi_client_handle" );
	}
	else
	{
		qmi_error_code = qmi_service_release( qmi_client_handle, qmi_service_error_code );
		
		if ( QMI_NO_ERR != qmi_error_code || QMI_SERVICE_ERR_NONE != *qmi_service_error_code )
		{
			log_error( "qmi_service_release() fail, qmi_error_code:[%d], qmi_service_error_code:[%d]", qmi_error_code, *qmi_service_error_code );
		}
		
		qmi_error_code = qmi_service_set_srvc_functions( qmi_service_id, NULL );

		if ( QMI_NO_ERR != qmi_error_code )
		{
			log_error( "qmi_service_set_srvc_functions() fail, qmi_error_code:[%d]", qmi_error_code );
		}	
	}
	
	log_med( "ok!, qmi_client_handle:[%d], qmi_service_id:[%d]", qmi_client_handle, qmi_service_id );
}

//==============================================================
//
//==============================================================
int qmi_service_indication_register( const qmi_client_handle_type qmi_client_handle,
																					const qmi_service_id_type qmi_service_id,
																					const unsigned int qmi_indication_register_mask,
																					int* qmi_service_error_code )
{
	unsigned int i = 0;
	
	unsigned int 		qmi_indication_register_value = 0;
	unsigned char 	qmi_ind_reg_true = TRUE;

  unsigned char   qmi_request_raw_message[ QMI_MAX_STD_MSG_SIZE ];
  int             qmi_request_raw_message_size = 0;	
	unsigned char*	temp_qmi_request_raw_message_ptr = NULL;	

	qmi_service_info_s* qmi_service_info = NULL;

	int qmi_error_code = QMI_NO_ERR;	
	*qmi_service_error_code = QMI_SERVICE_ERR_NONE;

	memset( qmi_request_raw_message, 0, sizeof( qmi_request_raw_message ) );

  temp_qmi_request_raw_message_ptr = QMI_SRVC_PDU_PTR( qmi_request_raw_message );
  qmi_request_raw_message_size = QMI_SRVC_PDU_SIZE( QMI_MAX_STD_MSG_SIZE );

	for ( i = 0; i < sizeof( m_qmi_indication_register_mask_to_value_info_table ) / sizeof( qmi_indication_register_mask_to_value_info_s ); ++i )
	{
		if ( qmi_service_id != m_qmi_indication_register_mask_to_value_info_table[ i ].qmi_service_id )
		{
			continue;
		}
		
		if ( qmi_indication_register_mask & m_qmi_indication_register_mask_to_value_info_table[ i ].qmi_indication_register_mask )
		{
			qmi_indication_register_value = m_qmi_indication_register_mask_to_value_info_table[ i ].qmi_indication_register_value;

			if ( qmi_util_write_std_tlv( &temp_qmi_request_raw_message_ptr, 
																	 &qmi_request_raw_message_size,
																	 qmi_indication_register_value,
																	 sizeof( qmi_ind_reg_true ),
																	 &qmi_ind_reg_true ) < 0 )
			{
				log_error( "qmi_util_write_std_tlv() fail, qmi_indication_register_value:[0x%08x], qmi_error_code:[%d]", qmi_indication_register_value, qmi_error_code );
				
				return QMI_INTERNAL_ERR;
			}
			
			log_med( "register indication ok! qmi_indication_register_value:[0x%08x]", qmi_indication_register_value );
		}
	}

	qmi_service_info = qmi_get_qmi_service_info( qmi_service_id );

	if ( NULL == qmi_service_info )
	{
		log_error( "qmi_service_info is null, qmi_service_id:[%d]", qmi_service_id );
		return QMI_INTERNAL_ERR;
	}

	qmi_error_code = qmi_service_send_msg_sync( qmi_client_handle,
																						qmi_service_id,
																						qmi_service_info->qmi_indication_register_request_parameter_info.qmi_request_message_id,
																						QMI_SRVC_PDU_PTR( qmi_request_raw_message ),
																						QMI_SRVC_PDU_SIZE( QMI_MAX_STD_MSG_SIZE ) - qmi_request_raw_message_size,
																						qmi_request_raw_message,                 
																						&qmi_request_raw_message_size,
																						QMI_MAX_STD_MSG_SIZE,
																						QMI_SYNC_MSG_DEFAULT_TIMEOUT,
																						qmi_service_error_code );

	if ( QMI_NO_ERR != qmi_error_code || QMI_SERVICE_ERR_NONE != *qmi_service_error_code )
	{
		log_error( "qmi_service_send_msg_sync() fail, qmi_error_code:[%d], qmi_service_error_code:[%d]", qmi_error_code, *qmi_service_error_code );
		return qmi_error_code;
	}

	log_med( "ok!, qmi_indication_register_mask:[0x%08x]", qmi_indication_register_mask );
	
	return QMI_NO_ERR;
}

//==============================================================
//
//==============================================================
int	qmi_service_request_sync( const qmi_client_handle_type qmi_client_handle,
																	const qmi_service_id_type qmi_service_id,
											  					const unsigned int qmi_request_message_id,
											  					const void* const qmi_request_message,
											 					 	void* qmi_response_message )
{
	int	qmi_error_code = QMI_NO_ERR;
	int	qmi_service_error_code = QMI_SERVICE_ERR_NONE;

	unsigned char		qmi_request_raw_message[ QMI_MAX_STD_MSG_SIZE ];
	int							qmi_request_raw_message_size = 0;
	unsigned char*	temp_qmi_request_raw_message_ptr = NULL;

	qmi_service_info_s* qmi_service_info = NULL;

	memset( qmi_request_raw_message, 0, sizeof( qmi_request_raw_message ) );

	//
	if ( NULL == qmi_request_message )
	{
		log_error( "qmi_request_message is null" );
		return QMI_INTERNAL_ERR;
	}

	if ( NULL == qmi_response_message )
	{
		log_error( "qmi_response_message is null" );
		return QMI_INTERNAL_ERR;
	}
	
	qmi_service_info = qmi_get_qmi_service_info( qmi_service_id );

	if ( NULL == qmi_service_info )
	{
		log_error( "qmi_service_info is null, qmi_service_id:[%d]", qmi_service_id );
		return QMI_INTERNAL_ERR;
	}

	temp_qmi_request_raw_message_ptr = QMI_SRVC_PDU_PTR( qmi_request_raw_message );
	qmi_request_raw_message_size	= QMI_SRVC_PDU_SIZE( QMI_MAX_STD_MSG_SIZE );

	if ( qmi_service_info->qmi_tlv_io_function_info.qmi_request_message_write_tlv( qmi_request_message_id, 
																																									&temp_qmi_request_raw_message_ptr, 
																																									&qmi_request_raw_message_size, 
																																									qmi_request_message ) < 0 )
	{
		log_error( "qmi_request_message_write_tlv() fail, qmi_request_message_id:[0x%08x], qmi_request_raw_message_size:[%d]", qmi_request_message_id, qmi_request_raw_message_size );
		return QMI_INTERNAL_ERR;
	}

	qmi_error_code = qmi_service_send_msg_sync( qmi_client_handle,
																						qmi_service_id,
																						qmi_request_message_id,
																						QMI_SRVC_PDU_PTR( qmi_request_raw_message ),
																						(int)QMI_SRVC_PDU_SIZE( QMI_MAX_STD_MSG_SIZE ) - qmi_request_raw_message_size,
																						qmi_request_raw_message,                 
																						&qmi_request_raw_message_size,
																						QMI_MAX_STD_MSG_SIZE,
																						QMI_SYNC_MSG_EXTENDED_TIMEOUT,
																						&qmi_service_error_code );

	if ( QMI_NO_ERR != qmi_error_code && QMI_SERVICE_ERR != qmi_error_code )
	{
		log_error( "qmi_service_send_msg_sync() fail, qmi_error_code:[%d]", qmi_error_code );
		return qmi_error_code;
	}

	if ( FALSE == qmi_service_dispatch_response( qmi_service_info,
																										qmi_error_code,
																										qmi_service_error_code,
																										qmi_request_message_id, 
																										qmi_request_raw_message, 
																										qmi_request_raw_message_size, 
																										qmi_response_message ) )																										
	{
		log_error( "qmi_service_dispatch_response() fail" );
		
		return QMI_INTERNAL_ERR;
	}
	
	return QMI_NO_ERR;
}

//==============================================================
//
//==============================================================
int	qmi_service_request_async( const qmi_client_handle_type qmi_client_handle,
																	const qmi_service_id_type qmi_service_id,
														  		const unsigned int qmi_request_message_id,
														 		 	const void* const qmi_request_message,
														  		const qmi_async_callback_type_f const user_qmi_async_callback,
														  		const void* const user_qmi_async_data )
{
	int	qmi_error_code = QMI_NO_ERR;
	
	unsigned char		qmi_request_raw_message[ QMI_MAX_STD_MSG_SIZE ];
	int							qmi_request_raw_message_size = 0;
	unsigned char*	temp_qmi_request_raw_message_ptr = NULL;

	qmi_service_info_s* qmi_service_info = NULL;
	
	memset( qmi_request_raw_message, 0, sizeof( qmi_request_raw_message ) );

	//
	if ( NULL == qmi_request_message )
	{
		log_error( "qmi_request_message is null" );
		return QMI_INTERNAL_ERR;
	}

	qmi_service_info = qmi_get_qmi_service_info( qmi_service_id );

	if ( NULL == qmi_service_info )
	{
		log_error( "qmi_service_info is null, qmi_service_id:[%d]", qmi_service_id );
		return QMI_INTERNAL_ERR;
	}
	
	temp_qmi_request_raw_message_ptr = QMI_SRVC_PDU_PTR( qmi_request_raw_message );
	qmi_request_raw_message_size	= QMI_SRVC_PDU_SIZE( QMI_MAX_STD_MSG_SIZE );

	if ( qmi_service_info->qmi_tlv_io_function_info.qmi_request_message_write_tlv( qmi_request_message_id, 
																																									&temp_qmi_request_raw_message_ptr, 
																																									&qmi_request_raw_message_size, 
																																									qmi_request_message ) < 0 )
	{
		log_error( "qmi_request_message_write_tlv() fail, qmi_request_message_id:[0x%08x], qmi_request_raw_message_size:[%d]", qmi_request_message_id, qmi_request_raw_message_size );
		return QMI_INTERNAL_ERR;
	}

	qmi_error_code = qmi_service_send_msg_async( qmi_client_handle,
																						qmi_service_id,
																						qmi_request_message_id,
																						QMI_SRVC_PDU_PTR( qmi_request_raw_message ),
																						(int)QMI_SRVC_PDU_SIZE( QMI_MAX_STD_MSG_SIZE ) - qmi_request_raw_message_size,
																						qmi_service_async_callback,
																						NULL,
																						(void *)user_qmi_async_callback,
																						user_qmi_async_data );

	//if ( QMI_NO_ERR != qmi_error_code )
	if ( qmi_error_code < 0 )
	{
		log_error( "qmi_service_send_msg_async() fail, qmi_error_code:[%d]", qmi_error_code );
		return qmi_error_code;
	}
	
	return QMI_NO_ERR;
}



//**************************************************************
// public function
//**************************************************************
//==============================================================
//
//==============================================================
const qmi_request_message_info_s* const qmi_get_qmi_request_message_info( qmi_service_id_type qmi_service_id, unsigned int qmi_request_message_id )
{
	unsigned int i = 0;	

	//
	for ( i = 0; i < sizeof( m_qmi_request_message_info_table ) / sizeof( qmi_request_message_info_s ); ++i )
	{
		if ( qmi_service_id == m_qmi_request_message_info_table[ i ].qmi_service_id &&
					qmi_request_message_id == m_qmi_request_message_info_table[ i ].qmi_request_message_id )
		{
			return &( m_qmi_request_message_info_table[ i ] );
		}
	}

	log_error( "fail, qmi_service_id:[%d], qmi_request_message_id:[0x%08x]", qmi_service_id, qmi_request_message_id );

	return NULL;
}

//==============================================================
//
//==============================================================
const qmi_indication_message_info_s* const qmi_get_qmi_indication_message_info( qmi_service_id_type qmi_service_id, unsigned int qmi_indication_message_id )
{
	unsigned int i = 0;

	//
	for ( i = 0; i < sizeof( m_qmi_indication_message_info_table ) / sizeof( qmi_indication_message_info_s ); ++i )
	{
		if ( qmi_service_id == m_qmi_indication_message_info_table[ i ].qmi_service_id && 
					qmi_indication_message_id == m_qmi_indication_message_info_table[ i ].qmi_indication_message_id )
		{
			return &( m_qmi_indication_message_info_table[ i ] );
		}
	}

	log_error( "fail, qmi_service_id:[%d], qmi_indication_message_id:[0x%08x]", qmi_service_id, qmi_indication_message_id );

	return NULL;
}

//==============================================================
//
//==============================================================
int qmi_core_init( const char* const qmi_device_id,
										const qmi_indication_callback_type_f const user_qmi_indication_callback,
										const void* const user_qmi_indication_callback_user_data )
{
	unsigned int i = 0;

	qmi_client_handle_type qmi_client_handle = QMI_INVALID_CLIENT_HANDLE;

	int qmi_service_error_code = QMI_SERVICE_ERR_NONE;
	int qmi_error_code = QMI_NO_ERR;
	
	//	
	for ( i = 0; i < sizeof( m_qmi_service_info_table ) / sizeof( qmi_service_info_s ); ++i )
	{
		qmi_client_handle = qmi_service_internal_init( qmi_device_id, 
																											m_qmi_service_info_table[ i ].qmi_service_id,
																											user_qmi_indication_callback,
																											user_qmi_indication_callback_user_data,
																											&qmi_service_error_code );

		if ( QMI_INVALID_CLIENT_HANDLE == qmi_client_handle )
		{
			log_error( "qmi_service_internal_init() fail, qmi_service_id:[%d], qmi_service_error_code:[%d]", m_qmi_service_info_table[ i ].qmi_service_id, qmi_service_error_code );

			qmi_core_release();
			return FALSE;
		}
		
		m_qmi_service_info_table[ i ].qmi_client_handle = qmi_client_handle;

		qmi_error_code = qmi_service_indication_register( m_qmi_service_info_table[ i ].qmi_client_handle,
																												m_qmi_service_info_table[ i ].qmi_service_id,
																												m_qmi_service_info_table[ i ].qmi_indication_register_request_parameter_info.qmi_indication_register_masks,
																												&qmi_service_error_code );

		if ( QMI_NO_ERR != qmi_error_code || QMI_SERVICE_ERR_NONE != qmi_service_error_code )
		{
			log_error( "qmi_service_indication_register() fail, qmi_service_id:[%d], ind_reg_mask:[0x%08x]", 
																	m_qmi_service_info_table[ i ].qmi_service_id, m_qmi_service_info_table[ i ].qmi_indication_register_request_parameter_info.qmi_indication_register_masks );
			
			qmi_core_release();
			return FALSE;
		}

		if ( FALSE == m_qmi_service_info_table[ i ].qmi_on_init() )
		{
			log_error( "qmi_on_init() fail, qmi_service_id:[%d]", m_qmi_service_info_table[ i ].qmi_service_id );
			
			qmi_core_release();
			return FALSE;
		}

		log_med( "qmi_service_init success, qmi_service_id:[%d]", m_qmi_service_info_table[ i ].qmi_service_id );
	}

	log_med( "ok!" );

	return TRUE;
}

//==============================================================
//
//==============================================================
void qmi_core_release( void )
{
	unsigned int i = 0;

	int qmi_service_error_code = QMI_SERVICE_ERR_NONE;
	
	//
	for ( i = 0; i < sizeof( m_qmi_service_info_table ) / sizeof( qmi_service_info_s ); ++i )
	{
		if ( QMI_INVALID_CLIENT_HANDLE != m_qmi_service_info_table[ i ].qmi_client_handle )
		{
			qmi_service_internal_release( m_qmi_service_info_table[ i ].qmi_client_handle, 
																			m_qmi_service_info_table[ i ].qmi_service_id,
																			&qmi_service_error_code );
		}

		m_qmi_service_info_table[ i ].qmi_client_handle = QMI_INVALID_CLIENT_HANDLE;
	}

	log_med( "ok!" );
}

//==============================================================
//
//==============================================================
int	qmi_core_request_sync( const qmi_service_id_type qmi_service_id, 
															const unsigned int qmi_request_message_id, 
															const void* const qmi_request_message, 
															void* qmi_response_message )
{
	qmi_service_info_s* qmi_service_info = qmi_get_qmi_service_info( qmi_service_id );

	if ( NULL == qmi_service_info )
	{
		log_error( "qmi_service_info is null, qmi_service_id:[%d]", qmi_service_id );
		return FALSE;
	}

	if ( QMI_NO_ERR != qmi_service_request_sync( qmi_service_info->qmi_client_handle,
																									qmi_service_id,
																									qmi_request_message_id,
																									qmi_request_message,
																									qmi_response_message ) )
	{
		log_error( "qmi_srvc_msg_request() fail" );
		return FALSE;
	}

	log_med( "ok!" );

	return TRUE;
}

//==============================================================
//
//==============================================================
int	qmi_core_request_async( const qmi_service_id_type qmi_service_id, 
																const unsigned int qmi_request_message_id,
																const void* const qmi_request_message,
																const qmi_async_callback_type_f const user_qmi_async_callback,
																const void* const user_qmi_async_data )
{
	qmi_service_info_s* qmi_service_info = qmi_get_qmi_service_info( qmi_service_id );

	if ( NULL == qmi_service_info )
	{
		log_error( "qmi_service_info is null, qmi_service_id:[%d]", qmi_service_id );
		return FALSE;
	}

	if ( QMI_NO_ERR != qmi_service_request_async( qmi_service_info->qmi_client_handle,
																									qmi_service_id,
																									qmi_request_message_id,
																									qmi_request_message,
																									user_qmi_async_callback,
																									user_qmi_async_data ) )
	{
		log_error( "qmi_srvc_msg_request() fail" );
		return FALSE;
	}

	log_med( "ok!" );

	return TRUE;
}

