#ifndef QMI_CORE_H
#define QMI_CORE_H



#include "../common.h"
#include "qmi.h"
#include "qmi_util.h"



#ifdef __cplusplus
extern "C" {
#endif



//**************************************************************
// public member
//**************************************************************
#define READ_VARIABLE_BIT_VALUE_AND_MOVE_SOURCE_POSITION( source, dest, length ) 									\
do { memcpy( (unsigned char*)dest, (unsigned char*)source, length ); source += length; } while ( 0 )	\
	
#define WRITE_VARIABLE_BIT_VALUE_AND_MOVE_DEST_POSITION( dest, source, length )											\
do { memcpy( (unsigned char*)dest, (unsigned char*)source, length ); dest += length; } while ( 0 )			\



typedef struct
{
	qmi_service_id_type		qmi_service_id;
	unsigned int 					qmi_request_message_id;
	unsigned int 					qmi_request_message_size;
	unsigned int 					qmi_response_message_size;
} qmi_request_message_info_s;

typedef struct
{
	qmi_service_id_type		qmi_service_id;
	unsigned int 					qmi_indication_message_id;
	unsigned int 					qmi_indication_message_size;
} qmi_indication_message_info_s;



typedef int (*qmi_request_message_write_tlv_type_f)( const int qmi_request_message_id, 
																														unsigned char** qmi_request_raw_message,
																														int* const qmi_request_raw_message_size, 
																														const void* const qmi_request_message );

typedef int (*qmi_response_message_read_tlv_type_f)( const int qmi_response_message_id, 
																														const unsigned int qmi_response_message_field_type,
																														const unsigned char* const qmi_response_message_field, 
																														const unsigned int qmi_response_message_field_size, 
																														void* qmi_response_message );

typedef int (*qmi_indication_message_read_tlv_type_f)( const int qmi_indication_message_id, 
																															const unsigned int qmi_indication_message_field_type,
																															const unsigned char* const qmi_indication_message_field, 
																															const unsigned int qmi_indication_message_field_size, 
																															void* qmi_indication_message );



typedef int (*qmi_on_init_type_f)( void );



typedef void (*qmi_async_callback_type_f)( const qmi_client_handle_type qmi_client_handle,
																								const qmi_service_id_type qmi_service_id,
																								const void* const user_data,
																								const unsigned int qmi_response_message_id, 
																								const void* const qmi_response_message );

typedef void (*qmi_indication_callback_type_f)( const qmi_client_handle_type qmi_client_handle,
																											const qmi_service_id_type qmi_service_id, 
																											const void* const user_data, 
																											const unsigned int qmi_indication_message_id,
																											const void* const qmi_indication_message );



//**************************************************************
// public function
//**************************************************************
int 	qmi_core_init( const char* const qmi_device_id,
												const qmi_indication_callback_type_f const user_qmi_indication_callback,
												const void* const user_qmi_indication_callback_user_data );

void	qmi_core_release( void );

int		qmi_core_request_sync( const qmi_service_id_type qmi_service_id, 
																	const unsigned int qmi_request_message_id, 
																	const void* const qmi_request_message, 
																	void* qmi_response_message );

int		qmi_core_request_async( const qmi_service_id_type qmi_service_id, 
																	const unsigned int qmi_request_message_id,
																	const void* const qmi_request_message,
																	const qmi_async_callback_type_f const user_qmi_async_callback,
																	const void* const user_qmi_async_data );

const qmi_request_message_info_s* 		const qmi_get_qmi_request_message_info( qmi_service_id_type qmi_service_id, unsigned int qmi_request_message_id );
const qmi_indication_message_info_s* 	const qmi_get_qmi_indication_message_info( qmi_service_id_type qmi_service_id, unsigned int qmi_indication_message_id );



#ifdef __cplusplus
}
#endif



#endif
