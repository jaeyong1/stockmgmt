#ifndef QMI_INTERFACE_H
#define QMI_INTERFACE_H



#include "engine.h"



#ifdef __cplusplus
extern "C" {
#endif



//**************************************************************
// public function
//**************************************************************
void DUBU_qmi_export( DUBU_interface_s* DUBU_interface );



#ifdef __cplusplus
}
#endif



#endif
