#ifndef DIAG_INTERFACE_H
#define DIAG_INTERFACE_H



#include "engine.h"



#ifdef __cplusplus
extern "C" {
#endif



//**************************************************************
// public function
//**************************************************************
void DUBU_diag_export( DUBU_interface_s* DUBU_interface );



#ifdef __cplusplus
}
#endif



#endif
