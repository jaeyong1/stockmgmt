#ifndef ENGINE_H
#define ENGINE_H



#include "common.h"



#ifdef __cplusplus
extern "C" {
#endif



//**************************************************************
// public member
//**************************************************************
typedef enum
{
	DUBU_response_result_success		= 1,
	DUBU_response_result_fail			= 0,
} DUBU_response_result_e;

typedef struct
{
	DUBU_response_result_e	DUBU_response_result;
	unsigned int						error;
} DUBU_response_base_s;



typedef enum
{
	//sms
	DUBU_req_type_wms_send_sms,
	DUBU_req_type_wms_delete_sms,
	DUBU_req_type_wms_read_sms,
	DUBU_req_type_wms_list_sms,
	DUBU_req_type_wms_get_smsc_address,
	DUBU_req_type_wms_set_smsc_address,
	DUBU_req_type_wms_get_memory_status,
	DUBU_req_type_wms_send_sms_pdu,
	//voice
	DUBU_req_type_voice_dial_call,
	DUBU_req_type_max
} DUBU_request_type_e;

#define invalid_DUBU_request_type 				( -1 )

typedef enum
{
	//sms
	DUBU_ind_type_wms_new_sms,
	//voice
	DUBU_ind_type_voice_all_call_status,
	DUBU_ind_type_max
} DUBU_indication_type_e;

#define	invalid_DUBU_indication_type			( -1 )



typedef const void* const 	(*DUBU_interface_request_create_interface_request_data_type_f)( const DUBU_request_type_e DUBU_request_type, const void* const DUBU_request_data );
typedef const void* const 	(*DUBU_interface_request_request_sync_type_f)( const DUBU_request_type_e DUBU_request_type, const void* const interface_request_data );
typedef int 								(*DUBU_interface_request_request_async_type_f)( const DUBU_request_type_e DUBU_request_type, const void* const interface_request_data, const void* const user_data );
typedef const void* const 	(*DUBU_interface_request_create_DUBU_response_data_type_f)( const DUBU_request_type_e DUBU_request_type, const void* const interface_response_data );

typedef struct
{
	DUBU_interface_request_create_interface_request_data_type_f		create_interface_request_data;
	DUBU_interface_request_request_sync_type_f										request_sync;
	DUBU_interface_request_request_async_type_f										request_async;
	DUBU_interface_request_create_DUBU_response_data_type_f				create_DUBU_response_data;
} DUBU_interface_request_s;



typedef void (*DUBU_interface_callback_response_type_f)( const DUBU_request_type_e DUBU_request_type, const void* const interface_response_data, const void* const user_data );
typedef void (*DUBU_interface_callback_indication_type_f)( const DUBU_indication_type_e DUBU_indication_type, const void* const interface_indication_data );

typedef struct
{
	DUBU_interface_callback_response_type_f 		response;
	DUBU_interface_callback_indication_type_f		indication;
} DUBU_interface_callback_s;



typedef const void* const (*DUBU_interface_indication_create_DUBU_indication_data_type_f)( const DUBU_indication_type_e DUBU_indication_type, const void* const interface_indication_data );

typedef struct
{
	DUBU_interface_indication_create_DUBU_indication_data_type_f		create_DUBU_indication_data;
} DUBU_interface_indication_s;



typedef struct
{
	DUBU_interface_callback_s		DUBU_interface_callback;
} DUBU_interface_init_info_s;

typedef 	const void* const 	(*DUBU_interface_init_type_f)( const DUBU_interface_init_info_s* const DUBU_interface_init_info );
typedef		void 								(*DUBU_interface_release_type_f)( void );

typedef struct
{
	DUBU_interface_init_type_f			init;
	DUBU_interface_release_type_f		release;
	DUBU_interface_request_s				request;
	DUBU_interface_indication_s			indication;
} DUBU_interface_s;



typedef enum
{
	DUBU_interface_type_qmi,
	DUBU_interface_type_at,
	DUBU_interface_type_diag
} DUBU_interface_type_e;

typedef void (*DUBU_callback_response_type_f)( const void* const DUBU_response_data, const void* const user_data );
typedef void (*DUBU_callback_indication_type_f)( const void* const DUBU_indication_data );

typedef struct
{
	DUBU_interface_type_e						DUBU_interface_type;
	DUBU_callback_response_type_f		DUBU_callback_response[ DUBU_req_type_max ];
	DUBU_callback_indication_type_f	DUBU_callback_indication[ DUBU_ind_type_max ];	
} DUBU_info_s;

typedef struct
{
	DUBU_info_s									DUBU_info;
	DUBU_interface_s 						DUBU_interface;
	DUBU_interface_callback_s		DUBU_interface_callback;
} DUBU_s;



#define			DUBU_cmd_request_mask						(0x000007FF)
#define			DUBU_cmd_response_mask					(0x00000FFF)
#define			DUBU_cmd_ind_mask								(0x0000FFFF)

typedef enum
{
	//request
	//sms
	DUBU_cmd_request_wms_send_sms 						= 0x00000000,	//from 0000
	DUBU_cmd_request_wms_delete_sms,
	DUBU_cmd_request_wms_read_sms,
	DUBU_cmd_request_wms_list_sms,
	DUBU_cmd_request_wms_get_smsc_address,
	DUBU_cmd_request_wms_set_smsc_address,
	DUBU_cmd_request_wms_get_memory_status,
	DUBU_cmd_request_wms_send_sms_pdu,
	//voice
	DUBU_cmd_request_voice_dial_call,

	//response
	//sms
	DUBU_cmd_response_wms_send_sms						= 0x00000800,	//from 2048
	DUBU_cmd_response_wms_delete_sms,
	DUBU_cmd_response_wms_read_sms,
	DUBU_cmd_response_wms_list_sms,
	DUBU_cmd_response_wms_get_smsc_address,
	DUBU_cmd_response_wms_set_smsc_address,
	DUBU_cmd_response_wms_get_memory_status,
	DUBU_cmd_response_wms_send_sms_pdu,
	//voice
	DUBU_cmd_response_voice_dial_call,

	//indication
	//sms
	DUBU_cmd_ind_response_wms_new_sms 			= 0x00001000,	//from 4096
	//voice
	DUBU_cmd_ind_response_voice_all_call_status,
	
	DUBU_cmd_max																= 0xFFFFFFFF
} DUBU_command_id_e;

typedef struct
{
	DUBU_request_type_e			DUBU_request_type;
	unsigned int						DUBU_request_data_size;
	unsigned int						DUBU_response_data_size;
	DUBU_command_id_e 			request_DUBU_command_id;
	DUBU_command_id_e				response_DUBU_command_id;
} DUBU_request_data_info_s;

typedef struct
{
	DUBU_indication_type_e		DUBU_indication_type;
	unsigned int							DUBU_indication_data_size;
	DUBU_command_id_e 				DUBU_indication_command_id;
} DUBU_indication_data_info_s;



//**************************************************************
// public function
//**************************************************************
int  DUBU_init( const DUBU_info_s* const DUBU_info );
void DUBU_release( void );

int  DUBU_request_sync( const DUBU_request_type_e DUBU_request_type, const void* const DUBU_request_data, void* DUBU_response_data );
int  DUBU_request_async( const DUBU_request_type_e DUBU_request_type, const void* const DUBU_request_data, const void* const user_data );
int  DUBU_request( const DUBU_request_type_e DUBU_request_type, const void* const DUBU_request_data, void* DUBU_response_data );

const DUBU_request_data_info_s* const 			DUBU_get_DUBU_request_data_info( const DUBU_request_type_e DUBU_request_type );
const DUBU_indication_data_info_s* const 		DUBU_get_DUBU_indication_data_info( const DUBU_indication_type_e DUBU_indication_type );



#ifdef __cplusplus
}
#endif



#endif

