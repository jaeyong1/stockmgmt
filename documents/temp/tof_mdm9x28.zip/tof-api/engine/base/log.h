#ifndef LOG_H
#define LOG_H



#include "type.h"



#ifdef __cplusplus
extern "C" {
#endif



//**************************************************************
// public member
//**************************************************************
#define FEATURE_DEBUG_LOG



#define 			max_log_buffer_size				( 1024 )
#define				max_log_func_name_len			( 64 )
#define				max_log_file_name_len			( 32 )



typedef void (*write_log_function_type)( const char* const string );

typedef enum
{
	log_type_high,
	log_type_medium,
	log_type_low,
	log_type_error,
	log_type_fatal,
	log_type_max,
} log_type_e;

typedef struct
{
	write_log_function_type 	function[ log_type_max ];
} write_log_function_list_s;



//**************************************************************
// public function
//**************************************************************
void	log_init( const write_log_function_list_s* const list );
void	log_release( void );

void	log_write( const log_type_e type, const char* file_name, unsigned int line_number, const char* const func_name, const char* const format, ... );

#define log_high( format, ... ) 		log_write( log_type_high, __FILE__, __LINE__, __func__, format, ##__VA_ARGS__ )
#define log_med( format, ... )			log_write( log_type_medium, __FILE__, __LINE__, __func__, format, ##__VA_ARGS__ )
#define log_low( format, ... ) 		log_write( log_type_low, __FILE__, __LINE__, __func__, format, ##__VA_ARGS__ )
#define log_error( format, ... ) 	log_write( log_type_error, __FILE__, __LINE__, __func__, format, ##__VA_ARGS__ )
#define log_fatal( format, ... ) 	log_write( log_type_fatal, __FILE__, __LINE__, __func__, format, ##__VA_ARGS__ )



#ifdef __cplusplus
}
#endif



#endif
