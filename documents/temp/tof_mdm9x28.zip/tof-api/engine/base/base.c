



#include <pthread.h>
#include "log.h"
#include "base.h"



//**************************************************************
// private member
//**************************************************************
pthread_mutex_t m_memory_mutex 	= PTHREAD_MUTEX_INITIALIZER;



int m_memory_alloc_count = 0;



//**************************************************************
// public function
//**************************************************************
//==============================================================
//
//==============================================================
void*	mem_alloc( unsigned int size )
{
	void* ptr = malloc( size );

	if ( NULL == ptr )
	{
		log_fatal( "################ null pointer fatal error ################" );
	}
	else
	{	
		pthread_mutex_lock( &m_memory_mutex );
		
		m_memory_alloc_count++;

		pthread_mutex_unlock( &m_memory_mutex );
	#ifdef FEATURE_DEBUG_LOG
		log_low( "--------> ptr:[0x%08x], count:[%d]", ptr, m_memory_alloc_count );
	#endif
	}

	return ptr;
}

//==============================================================
//
//==============================================================
void	mem_free( const void* const ptr )
{
	if ( NULL == ptr )
	{
		log_fatal( "################ null pointer fatal error ################" );
	}
	else
	{
		pthread_mutex_lock( &m_memory_mutex );
		
		m_memory_alloc_count--;
		
		pthread_mutex_unlock( &m_memory_mutex );
	#ifdef FEATURE_DEBUG_LOG
		log_low( "<-------- ptr:[0x%08x], count:[%d]", ptr, m_memory_alloc_count );
	#endif
		free( ptr );
	}	
}

//==============================================================
//
//==============================================================
void	log_binary_data( const unsigned char* data, unsigned int data_len )
{
	unsigned int i = 0;

	if ( NULL == data )
	{
		log_error( "data is null" );
		return;
	}

	log_med( "################ binary data ################" );

	for ( i = 0; i < data_len; ++i )
	{
		log_med( "index:[%08d], value:[0x%02x], character:[%c]", i, data[ i ], data[ i ] );
	}

	log_med( "################ binary data ################" );
}

//==============================================================
//
//==============================================================
int check_ascii( const char* str, unsigned int str_len )
{
	unsigned int i = 0;

	if ( NULL == str )
	{
		log_error( "str is null" );
		return FALSE;
	}

	for ( i = 0; i < str_len; ++i )
	{
		if ( 0x7F <= str[ i ] || 0x00 == str[ i ] )
		{
			return FALSE;
		}
	}

	return TRUE;
}

