#ifndef WMS_UTIL_H
#define WMS_UTIL_H



#include "type.h"



#ifdef __cplusplus
extern "C" {
#endif



//**************************************************************
// public member
//**************************************************************
//from qualcomm source
#ifndef MAX
#define MAX( a, b ) ( ((a)>(b)) ? (a) : (b) )
#endif

#ifndef MIN
#define MIN( a, b ) ( ((a)<(b)) ? (a) : (b) )
#endif

typedef uint32  wms_message_number_type;

enum { WMS_GW_ADDRESS_MAX         = 20  };
enum { WMS_MESSAGE_LIST_MAX     = 255 };

enum { WMS_MAX_LEN                = 255 };
enum { WMS_ADDRESS_MAX            = 48  };
enum { WMS_MAX_UD_HEADERS       = 7};
enum { WMS_UDH_MAX_SND_SIZE          = 128 };
enum { WMS_UDH_ANIM_NUM_BITMAPS  = 4 };
enum { WMS_UDH_LARGE_BITMAP_SIZE = 32 };
enum { WMS_UDH_SMALL_BITMAP_SIZE = 8 };
enum { WMS_UDH_LARGE_PIC_SIZE    = 128 };
enum { WMS_UDH_SMALL_PIC_SIZE    = 32  };
enum { WMS_UDH_VAR_PIC_SIZE      = 134 };
enum { WMS_UDH_OTHER_SIZE            = 226 };

#define WMS_UDH_EO_DATA_SEGMENT_MAX    131  

enum { WMS_SMS_UDL_MAX_7_BIT  = 160 }; /* as in the spec */
enum { WMS_SMS_UDL_MAX_8_BIT  = 140 }; /* as in the spec */

enum { WMS_ENHANCED_VP_OCTETS   = 7};

#define WMS_GW_USER_DATA_LEN_MAX 140

enum{ WMS_SP_EXTD_VIDEOMAIL_MSG_WAITING_TYPE = 0x07};

enum { WMS_UDH_OCTETS_PORT8                =2};
enum { WMS_UDH_OCTETS_PORT16               =4};
enum { WMS_UDH_OCTETS_CONCAT8              =3};
enum { WMS_UDH_OCTETS_SPECIAL_SM           =2};
enum { WMS_UDH_OCTETS_CONCAT16             =4};
enum { WMS_UDH_OCTETS_PRE_DEF              =2};
enum { WMS_UDH_OCTETS_TEXT_FORMATTING      =3};
enum { WMS_UDH_OCTETS_RFC822               =1};
enum { WMS_UDH_OCTETS_NAT_LANG_SS          =1};
enum { WMS_UDH_OCTETS_NAT_LANG_LS          =1};
enum { WMS_UDH_OCTETS_USER_PROMPT          =1};
enum { WMS_UDH_OCTETS_EO_HEADER            =7};

typedef enum
{
  WMS_OK_S                 = 0,    /**< Status is OK. */
  WMS_OUT_OF_RESOURCES_S,          /**< Out of resources. */
  WMS_TERMINAL_BLOCKED_S,          /**< Terminal is blocked. */
  WMS_TERMINAL_BUSY_S,             /**< Terminal is busy. */
  WMS_INVALID_TRANSACTION_ID_S,    /**< Invalid transaction ID. */
  WMS_INVALID_FORMAT_S,            /**< Invalid format. */
  WMS_GENERAL_ERROR_S,             /**< General error. */
  WMS_UNSUPPORTED_S,               /**< Unsupported. */ 
  WMS_NULL_PTR_S,                  /**< NULL pointer. */
  WMS_INVALID_CLIENT_ID_S,         /**< Invalid client ID. */          

  WMS_INVALID_PARM_SIZE_S   = 100, /**< CDMA only. */
  WMS_INVALID_USER_DATA_SIZE_S,    /**< CDMA only. */
  WMS_INVALID_PARM_VALUE_S,        /**< CDMA only. */
  WMS_MISSING_PARM_S,              /**< CDMA only. */
  WMS_NETWORK_NOT_READY_S,         /**< CDMA only. */
  WMS_PHONE_NOT_READY_S,           /**< CDMA only. */
  WMS_NOT_ALLOWED_IN_AMPS_S,       /**< CDMA only. */
  WMS_NETWORK_FAILURE_S,           /**< CDMA only. */
  WMS_ACCESS_TOO_LARGE_S,          /**< CDMA only. */
  WMS_DTC_TOO_LARGE_S,             /**< CDMA only. */
  WMS_ACCESS_BLOCK_S,              /**< CDMA only. */
  WMS_ESN_MISMATCH_S,              /**< JCDMA2 feature only. */
  WMS_MO_PREF_CHN_NOT_AVAIL_S,     /**< CDMA only. */
  WMS_MO_PREF_CHN_UNSUPPORTED_S,   /**< CDMA only. */

  WMS_INVALID_TPDU_TYPE_S  = 200,  /**< GSM/WCDMA only. */
  WMS_INVALID_VALIDITY_FORMAT_S,   /**< GSM/WCDMA only. */
  WMS_INVALID_CB_DATA_S,           /**< GSM/WCDMA only. */

/** @cond */
  WMS_MT_MSG_FAILED_S,     /* internal use */
/** @endcond */

  WMS_SIP_PERM_ERROR_S     = 300,  /**< SIP permanent error. */
  WMS_SIP_TEMP_ERROR_S,            /**< SIP temporary error. */

  /* WMSC, CS and RPC errors  */
  WMS_WMSC_ERROR_S         = 400,  /**< WMSC error. */
  WMS_CS_ERROR_S,                  /**< CS error. */
  WMS_RPC_ERROR_S,                 /**< RPC error. */

  /* Transport layer errors */
  WMS_TRANSPORT_NOT_READY_S = 500, /**< Transport is not ready. */
  WMS_TRANSPORT_NOT_ALLOWED_S,     /**< Transport is not allowed. */
  WMS_1X_AND_VOICE_NOT_ALLOWED_S,  /**< 1X and voice is not allowed. */
  WMS_IMS_NOT_ALLOWED_IN_SRLTE_S,  /**< 1X not allowed while in 1xSRLTE mode. */ 

/** @cond */
  WMS_STATUS_MAX,
  WMS_STATUS_MAX32 = 0x10000000  /* pad to 32 bit int */
/** @endcond */
} wms_status_e_type;

typedef enum
{
  WMS_FORMAT_CDMA         = 0,  /**< CDMA format, IS-95. */
  WMS_FORMAT_ANALOG_CLI,        /**< Analog calling line identification, IS-91. */
  WMS_FORMAT_ANALOG_VOICE_MAIL, /**< Analog voice mail, IS-91. */
  WMS_FORMAT_ANALOG_SMS,        /**< Analog SMS, IS-91. */
  WMS_FORMAT_ANALOG_AWISMS,     /**< Analog IS-95 alert with information SMS. */
  WMS_FORMAT_MWI,               /**< Message waiting indication as voice mail. */
  WMS_FORMAT_GW_PP,             /**< GSM/WCDMA point-to-point SMS. */
  WMS_FORMAT_GW_CB,             /**< GSM/WCDMA cell broadcast SMS. */
/** @cond */
  WMS_FORMAT_MAX,
  WMS_FORMAT_MAX32        = 0x10000000
/** @endcond */
} wms_format_e_type;

typedef enum
{
  WMS_TPDU_DELIVER = 0,          /**< Deliver message TPDU type; from SC to MS. */
  WMS_TPDU_DELIVER_REPORT_ACK,   /**< Report acknowledgment of delivery TPDU 
                                      type; from MS to SC. */
  WMS_TPDU_DELIVER_REPORT_ERROR, /**< Report error in delivery TPDU type; from 
                                      MS to SC. */
  WMS_TPDU_SUBMIT,               /**< From MS to SC. */
  WMS_TPDU_SUBMIT_REPORT_ACK,    /**< Report acknowledgment of submission TPDU 
                                      type; from SC to MS. */
  WMS_TPDU_SUBMIT_REPORT_ERROR,  /**< Report error in submission TPDU type; from 
                                      SC to MS. */
  WMS_TPDU_STATUS_REPORT,        /**< From SC to MS. */
  WMS_TPDU_COMMAND,              /**< From MS to SC. */
  WMS_TPDU_RESERVED,             /**< From SC to MS. */

/** @cond */
  WMS_TPDU_MAX,
  WMS_TPDU_NONE,
  WMS_TPDU_MAX32 = 0x10000000
/** @endcond */
} wms_gw_tpdu_type_e_type;

typedef enum
{
  WMS_DIGIT_MODE_4_BIT     = 0, /**< Four-bit DTMF digit codes. */
  WMS_DIGIT_MODE_8_BIT     = 1, /**< Eight-bit DTMF digit codes. */
/** @cond */
  WMS_DIGIT_MODE_MAX32     = 0x10000000
/** @endcond */
} wms_digit_mode_e_type;

typedef enum
{
  WMS_NUMBER_MODE_NONE_DATA_NETWORK      = 0, /**< Not a data network address. */
  WMS_NUMBER_MODE_DATA_NETWORK           = 1, /**< Data network address. */
/** @cond */
  WMS_NUMBER_MODE_DATA_NETWORK_MAX32     = 0x10000000
/** @endcond */
} wms_number_mode_e_type;

typedef enum
{
  WMS_NUMBER_UNKNOWN        = 0,  /**< Unknown. */
  WMS_NUMBER_INTERNATIONAL  = 1,  /**< International. */
  WMS_NUMBER_NATIONAL       = 2,  /**< National. */
  WMS_NUMBER_NETWORK        = 3,  /**< Network. */
  WMS_NUMBER_SUBSCRIBER     = 4,  /**< Subscriber. */
  WMS_NUMBER_ALPHANUMERIC   = 5,  /**< For GSM SMS, the address value is 
                                       GSM 7-bit characters. */
  WMS_NUMBER_ABBREVIATED    = 6,  /**< Abbreviated. */
  WMS_NUMBER_RESERVED_7     = 7,  /**< Reserved. */
  
  WMS_NUMBER_DATA_IP        = 1,  /**< Data IP. */
  WMS_NUMBER_INTERNET_EMAIL = 2,  /**< Internet email. @newpage */
/** @cond */ 
  WMS_NUMBER_MAX32        = 0x10000000
/** @endcond */
} wms_number_type_e_type;

typedef enum
{
  WMS_NUMBER_PLAN_UNKNOWN     = 0,  /**< Unknown. */
  WMS_NUMBER_PLAN_TELEPHONY   = 1,  /**< As defined in CCITT E.164 and E.163, 
                                         including the ISDN plan. */
  WMS_NUMBER_PLAN_RESERVED_2  = 2,  /**< Reserved. */
  WMS_NUMBER_PLAN_DATA        = 3,  /**< As defined in CCITT X.121. */
  WMS_NUMBER_PLAN_TELEX       = 4,  /**< As defined in CCITT F.69. */
  WMS_NUMBER_PLAN_RESERVED_5  = 5,  /**< Reserved. */
  WMS_NUMBER_PLAN_RESERVED_6  = 6,  /**< Reserved. */ 
  WMS_NUMBER_PLAN_RESERVED_7  = 7,  /**< Reserved. */
  WMS_NUMBER_PLAN_RESERVED_8  = 8,  /**< Reserved. */
  WMS_NUMBER_PLAN_PRIVATE     = 9,  /**< Private. */
  WMS_NUMBER_PLAN_RESERVED_10 = 10, /**< Reserved. */
  WMS_NUMBER_PLAN_RESERVED_11 = 11, /**< Reserved. */
  WMS_NUMBER_PLAN_RESERVED_12 = 12, /**< Reserved. */
  WMS_NUMBER_PLAN_RESERVED_13 = 13, /**< Reserved. */
  WMS_NUMBER_PLAN_RESERVED_14 = 14, /**< Reserved. */
  WMS_NUMBER_PLAN_RESERVED_15 = 15, /**< Reserved. */
/** @cond */
  WMS_NUMBER_PLAN_MAX32       = 0x10000000
/** @endcond */
} wms_number_plan_e_type;

typedef enum
{
  /* values from 0x00 to 0x1f are for SM-AL protocols */
  WMS_PID_DEFAULT           = 0x00, /**< SM-AL protocols: default value. */

  /* values from 0x20 to 0x3f are for telematic interworking */
  WMS_PID_IMPLICIT          = 0x20,
    /**< Telematic interworking: device type is specific to this SC, or it can 
         be concluded on the basis of the address. */
  WMS_PID_TELEX             = 0x21, /**< Telematic interworking. */
  WMS_PID_G3_FAX            = 0x22, /**< Telematic interworking: group 3 telefax. */
  WMS_PID_G4_FAX            = 0x23, /**< Telematic interworking: group 4 telefax. */
  WMS_PID_VOICE_PHONE       = 0x24, /**< Telematic interworking. */
  WMS_PID_ERMES             = 0x25, /**< Telematic interworking: European radio 
                                         messaging system. */
  WMS_PID_NAT_PAGING        = 0x26, /**< Telematic interworking: national paging 
                                         system (known to the SC). */
  WMS_PID_VIDEOTEX          = 0x27, /**< Telematic interworking: videotex (T.100 
                                         [20] /T.101 [21]). */
  WMS_PID_TELETEX_UNSPEC    = 0x28, /**< Telematic interworking. */
  WMS_PID_TELETEX_PSPDN     = 0x29, /**< Telematic interworking: packet-switched 
                                         packet data network. */
  WMS_PID_TELETEX_CSPDN     = 0x2a, /**< Telematic interworking: circuit-switched 
                                         packet data network.*/
  WMS_PID_TELETEX_PSTN      = 0x2b, /**< Telematic interworking: analog public 
                                         switched telephone network. */
  WMS_PID_TELETEX_ISDN      = 0x2c, /**< Telematic interworking: digital 
                                         integrated services digital network. */
  WMS_PID_UCI               = 0x2d, /**< Telematic interworking: Universal 
                                         computer interface, ETSI DE/PS 3 01 3.*/
  WMS_PID_RESERVED_0x2e     = 0x2e, /**< Telematic interworking. */
  WMS_PID_RESERVED_0x2f     = 0x2f, /**< Telematic interworking.*/
  WMS_PID_MSG_HANDLING      = 0x30, /**< Telematic interworking. */
  WMS_PID_X400              = 0x31, /**< Telematic interworking: any public X.400-
                                         based message handling system. */
  WMS_PID_INTERNET_EMAIL    = 0x32, /**< Telematic interworking. */
  WMS_PID_RESERVED_0x33     = 0x33, /**< Telematic interworking. */
  WMS_PID_RESERVED_0x34     = 0x34, /**< Telematic interworking. */
  WMS_PID_RESERVED_0x35     = 0x35, /**< Telematic interworking. */
  WMS_PID_RESERVED_0x36     = 0x36, /**< Telematic interworking. */
  WMS_PID_RESERVED_0x37     = 0x37, /**< Telematic interworking. */
  WMS_PID_SC_SPECIFIC_1     = 0x38, /**< Telematic interworking. */
  WMS_PID_SC_SPECIFIC_2     = 0x39, /**< Telematic interworking. */
  WMS_PID_SC_SPECIFIC_3     = 0x3a, /**< Telematic interworking. */
  WMS_PID_SC_SPECIFIC_4     = 0x3b, /**< Telematic interworking. */
  WMS_PID_SC_SPECIFIC_5     = 0x3c, /**< Telematic interworking. */
  WMS_PID_SC_SPECIFIC_6     = 0x3d, /**< Telematic interworking. */
  WMS_PID_SC_SPECIFIC_7     = 0x3e, /**< Telematic interworking. */
  WMS_PID_GSM_UMTS          = 0x3f, /**< Telematic interworking. */

  /* values from 0x40 to 0x7f: */
  WMS_PID_SM_TYPE_0         = 0x40, /**< Short message type. */
  WMS_PID_REPLACE_SM_1      = 0x41, /**< Replace short message type. */
  WMS_PID_REPLACE_SM_2      = 0x42, /**< Replace short message type. */
  WMS_PID_REPLACE_SM_3      = 0x43, /**< Replace short message type. */
  WMS_PID_REPLACE_SM_4      = 0x44, /**< Replace short message type. */
  WMS_PID_REPLACE_SM_5      = 0x45, /**< Replace short message type. */
  WMS_PID_REPLACE_SM_6      = 0x46, /**< Replace short message type. */
  WMS_PID_REPLACE_SM_7      = 0x47, /**< Replace short message type. */
  /* ... values reserved not listed ... */
  WMS_PID_EMS               = 0x5e, /**< Enhanced message service (Obsolete).*/
  WMS_PID_RETURN_CALL       = 0x5f, /**< Return call. */
  /* ... values reserved not listed ... */
  WMS_PID_ANSI136_R_DATA    = 0x7c, /**< ANSI-136 R-data. */
  WMS_PID_ME_DATA_DOWNLOAD  = 0x7d, /**< ME data download. */
  WMS_PID_ME_DEPERSONALIZE  = 0x7e, /**< ME depersonalize. */
  WMS_PID_SIM_DATA_DOWNLOAD = 0x7f, /**< SIM data download. */

/** @cond */
  WMS_PID_E_MAX32 = 0x10000000   /* pad to 32 bit int */
/** @endcond */

  /* values from 0x80 to 0xbf are reserved */
  /* values from 0xc0 to 0xff are for SC specific use */
} wms_pid_e_type;

typedef enum
{
  WMS_MESSAGE_CLASS_0 = 0, /**< Class 0. */
  WMS_MESSAGE_CLASS_1,     /**< Class 1. */
  WMS_MESSAGE_CLASS_2,     /**< Class 2. */
  WMS_MESSAGE_CLASS_3,     /**< Class 3. */
  WMS_MESSAGE_CLASS_NONE,  /**< No class. */
  WMS_MESSAGE_CLASS_CDMA,  /**< CDMA class. */
/** @cond */
  WMS_MESSAGE_CLASS_MAX,
  WMS_MESSAGE_CLASS_MAX32 = 0x10000000
/** @endcond */
} wms_message_class_e_type;

typedef enum
{
  WMS_GW_ALPHABET_7_BIT_DEFAULT, /**< GSM/WCDMA default. */
  WMS_GW_ALPHABET_8_BIT,         /**< 8-bit. */
  WMS_GW_ALPHABET_UCS2,          /**< Universal character set 16-bit variant. */
/** @cond */
  WMS_GW_ALPHABET_MAX32 = 0x10000000   /* pad to 32 bit int */
/** @endcond */
} wms_gw_alphabet_e_type;

typedef enum
{
  WMS_GW_MSG_WAITING_NONE,      /**< No messages waiting. */
  WMS_GW_MSG_WAITING_DISCARD,   /**< Discard message after updating indication. */
  WMS_GW_MSG_WAITING_STORE,     /**< Store message after updating indication. */
  WMS_GW_MSG_WAITING_NONE_1111, /**< Number of messages waiting. @newpage */
/** @cond */
  WMS_GW_MSG_WAITING_MAX32 = 0x10000000 /* pad to 32 bit int */
/** @endcond */
} wms_gw_msg_waiting_e_type;

typedef enum
{
  WMS_GW_MSG_WAITING_VOICEMAIL, /**< Voice mail. */
  WMS_GW_MSG_WAITING_FAX,       /**< FAX. */
  WMS_GW_MSG_WAITING_EMAIL,     /**< Email. */
  WMS_GW_MSG_WAITING_OTHER,     /**< Extended Message Type Waiting (equivalent to 
                                     Other in 3GPP TS 23.038). */
  WMS_GW_MSG_WAITING_VIDEOMAIL, /**< Video mail. */
  WMS_GW_MSG_WAITING_KIND_MAX,
/** @cond */
  WMS_GW_MSG_WAITING_KIND_MAX32 = 0x10000000   /* pad to 32 bit int */
/** @endcond */
} wms_gw_msg_waiting_kind_e_type;

typedef enum
{
  WMS_GW_VALIDITY_NONE = 0,     /**< No validity format. */
  WMS_GW_VALIDITY_RELATIVE = 2, /**< Relative. */
  WMS_GW_VALIDITY_ABSOLUTE = 3, /**< Absolute. */
  WMS_GW_VALIDITY_ENHANCED = 1, /**< Enhanced. */
/** @cond */
  WMS_GW_VALIDITY_MAX32 = 0x10000000   /* pad to 32 bit int */
/** @endcond */
} wms_gw_validity_format_e_type;

typedef enum
{
  WMS_ENHANCED_VP_NONE         = 0x00,     /**< None. */
  WMS_ENHANCED_VP_RELATIVE     = 0x01,     /**< Relative. */
  WMS_ENHANCED_VP_RELATIVE_INT = 0x02,     /**< Relative integer. */
  WMS_ENHANCED_VP_SEMI_OCTET   = 0x03,     /**< Semi-octet. */
  /** @cond */
  WMS_ENHANCED_VP_MAX32        = 0x10000000 
  /** @endcond */
}wms_enhanced_vp_format_e_type;

typedef enum
{
  WMS_UDH_CONCAT_8         = 0x00, /**< Concatenated short messages, 8-bit 
                                        reference number. */
  WMS_UDH_SPECIAL_SM,              /**< Special SMS message indication. */

  /* 02 - 03    Reserved */

  WMS_UDH_PORT_8           = 0x04, /**< Application port addressing scheme, 
                                        8-bit address. */
  WMS_UDH_PORT_16,                 /**< Application port addressing scheme, 
                                        16-bit address. */
  WMS_UDH_SMSC_CONTROL,            /**< SMSC control. */
  WMS_UDH_SOURCE,                  /**< Source. */
  WMS_UDH_CONCAT_16,               /**< Concatenated short message, 16-bit 
                                        reference number. */
  WMS_UDH_WCMP,                    /**< Wireless Control Message Protocol. */
  WMS_UDH_TEXT_FORMATING,          /**< Text formatting. */
  WMS_UDH_PRE_DEF_SOUND,           /**< Predefined sound. */
  WMS_UDH_USER_DEF_SOUND,          /**< User-defined sound. */
  WMS_UDH_PRE_DEF_ANIM,            /**< Predefined animation. */
  WMS_UDH_LARGE_ANIM,              /**< Large animation. */
  WMS_UDH_SMALL_ANIM,              /**< Small animation. */
  WMS_UDH_LARGE_PICTURE,           /**< Large picture. */
  WMS_UDH_SMALL_PICTURE,           /**< Small picture. */
  WMS_UDH_VAR_PICTURE,             /**< Variable-length picture. */

  WMS_UDH_USER_PROMPT      = 0x13, /**< User prompt. */
  WMS_UDH_EXTENDED_OBJECT  = 0x14, /**< Extended Object. */

  /* 15 - 1F    Reserved for future EMS */

  WMS_UDH_RFC822           = 0x20, /**< RFC 822 E-Mail Header. */

  WMS_UDH_NAT_LANG_SS      = 0x24, /**< National language single shift. */
  WMS_UDH_NAT_LANG_LS      = 0x25, /**< National language locking shift. */

  /*  21 - 23, 26 - 6F    Reserved for future use */
  /*  70 - 7f    Reserved for (U)SIM Toolkit Security Headers */
  /*  80 - 9F    SME to SME specific use */
  /*  A0 - BF    Reserved for future use */
  /*  C0 - DF    SC specific use */
  /*  E0 - FF    Reserved for future use */

  WMS_UDH_OTHER            = 0xFFFF, /**< For unsupported or proprietary headers. */

/** @cond */
  WMS_UDH_ID_MAX32 = 0x10000000   /* pad to 32 bit int */
/** @endcond */
} wms_udh_id_e_type;

typedef enum
{
  WMS_UDH_LEFT_ALIGNMENT = 0, /**< Left alignment. */
  WMS_UDH_CENTER_ALIGNMENT,   /**< Center alignment. */
  WMS_UDH_RIGHT_ALIGNMENT,    /**< Right alignment. */
  WMS_UDH_DEFAULT_ALIGNMENT,  /**< Language-dependent (default) alignment. */
  WMS_UDH_MAX_ALIGNMENT,      /**< Maximum alignment. */
/** @cond */
  WMS_UDH_ALIGNMENT_MAX32 = 0x10000000   /* pad to 32 bit int */
/** @endcond */
} wms_udh_alignment_e_type;

typedef enum
{
  WMS_UDH_FONT_NORMAL = 0, /**< Default font size. */
  WMS_UDH_FONT_LARGE,      /**< Large. */
  WMS_UDH_FONT_SMALL,      /**< Small. */
  WMS_UDH_FONT_RESERVED,   /**< Reserved. */
/** @cond */
  WMS_UDH_FONT_MAX,
  WMS_UDH_FONT_MAX32 = 0x10000000   /* pad to 32 bit int */
/** @endcond */
} wms_udh_font_size_e_type;

typedef enum
{
  WMS_UDH_TEXT_COLOR_BLACK          = 0x0, /**< Black. */
  WMS_UDH_TEXT_COLOR_DARK_GREY      = 0x1, /**< Dark grey. */
  WMS_UDH_TEXT_COLOR_DARK_RED       = 0x2, /**< Dark red. */
  WMS_UDH_TEXT_COLOR_DARK_YELLOW    = 0x3, /**< Dark yellow. */
  WMS_UDH_TEXT_COLOR_DARK_GREEN     = 0x4, /**< Dark green. */
  WMS_UDH_TEXT_COLOR_DARK_CYAN      = 0x5, /**< Dark cyan. */
  WMS_UDH_TEXT_COLOR_DARK_BLUE      = 0x6, /**< Dark blue. */
  WMS_UDH_TEXT_COLOR_DARK_MAGENTA   = 0x7, /**< Dark magenta. */
  WMS_UDH_TEXT_COLOR_GREY           = 0x8, /**< Grey. */
  WMS_UDH_TEXT_COLOR_WHITE          = 0x9, /**< White. */
  WMS_UDH_TEXT_COLOR_BRIGHT_RED     = 0xA, /**< Bright red. */
  WMS_UDH_TEXT_COLOR_BRIGHT_YELLOW  = 0xB, /**< Bright yellow. */
  WMS_UDH_TEXT_COLOR_BRIGHT_GREEN   = 0xC, /**< Bright green. */
  WMS_UDH_TEXT_COLOR_BRIGHT_CYAN    = 0xD, /**< Bright cyan. */
  WMS_UDH_TEXT_COLOR_BRIGHT_BLUE    = 0xE, /**< Bright blue. */
  WMS_UDH_TEXT_COLOR_BRIGHT_MAGENTA = 0xF, /**< Bright magenta. */
/** @cond */
  WMS_UDH_TEXT_COLOR_MAX32 = 0x10000000   /* pad to 32 bit int */
/** @endcond */
} wms_udh_text_color_e_type;

typedef enum
{
  WMS_UDH_EO_VCARD                   = 0x09, /**< vCard. */
  WMS_UDH_EO_VCALENDAR               = 0x0A, /**< vCalendar. */
/** @cond */
  WMS_UDH_EO_MAX32 = 0x10000000   /* pad to 32 bit int */
/** @endcond */
} wms_udh_eo_id_e_type;

typedef enum
{
  WMS_UDH_NAT_LANG_TURKISH          = 0x1, /**< Turkish. */
  WMS_UDH_NAT_LANG_SPANISH          = 0x2, /**< Spanish. */
  WMS_UDH_NAT_LANG_PORTUGUESE       = 0x3, /**< Portuguese. */
  /* 0x0    Reserved */
  /* 0x4 - 0xFF Reserved */
/** @cond */
  WMS_UDH_NAT_LANG_MAX32 = 0x10000000   /* pad to 32 bit int */
/** @endcond */
} wms_udh_nat_lang_id_e_type;



typedef struct wms_udh_eo_content_s
{
  uint8         length;
    /**< Extended Object length in number of octets (integer representation). */
  uint8         data[WMS_UDH_EO_DATA_SEGMENT_MAX];
    /**< Buffer to store data for vCard or vCalendar contents. */

    /* WMS_UDH_EO_VCARD: See http://www.imc.org/pdi/vcard-21.doc for payload.
     WMS_UDH_EO_VCALENDAR: See http://www.imc.org/pdi/vcal-10.doc.
     Or, Unsupported/proprietary extended objects. */

} wms_udh_eo_content_s_type;

typedef struct wms_udh_concat_8_s
{
  uint8       msg_ref;
    /**< Reference number for a particular concatenated short message. It is 
         constant for every short message that makes up a particular concatenated 
         short message. */
  uint8       total_sm;
    /**< Total number of short messages within the concatenated short message. 
         The value shall start at 1 and remain constant for every short message 
         that makes up the concatenated short message. If the value is zero, the 
         receiving entity shall ignore the entire Information Element. */
  uint8      seq_num;
    /**< Sequence number of a particular short message within the concatenated 
         short message. The value shall start at 1 and increment by one for every 
         short message sent within the concatenated short message. If the value 
         is zero or the value is greater than the value in octet 2, the receiving 
         entity shall ignore the entire Information Element. */
} wms_udh_concat_8_s_type;

typedef struct wms_udh_special_sm_s
{
  wms_gw_msg_waiting_e_type                  msg_waiting;
    /**< Waiting action. */
  wms_gw_msg_waiting_kind_e_type             msg_waiting_kind;
    /**< Type of message waiting. */
  uint8                                      message_count;
    /**< Number of messages waiting that are of the type specified in octet 1.*/

} wms_udh_special_sm_s_type;

typedef struct wms_udh_wap_8_s
{
  uint8  dest_port; /**< Receiving port (i.e., application) in the receiving 
                         device. */
  uint8  orig_port; /**< Sending port (i.e., application) in the sending 
                         device. */
} wms_udh_wap_8_s_type;

typedef struct wms_udh_wap_16_s
{
  uint16  dest_port; /**< Receiving port (i.e., application) in the receiving 
                          device. */
  uint16  orig_port; /**< Sending port (i.e., application) in the sending 
                          device. */
} wms_udh_wap_16_s_type;

typedef struct wms_udh_concat_16_s
{
  uint16      msg_ref;  /**< Concatenated short message reference number. */
  uint8       total_sm; /**< Maximum number of short messages in the 
                             concatenated short message. */
  uint8       seq_num;  /**< Sequence number of the current short message. */
} wms_udh_concat_16_s_type;

typedef struct wms_udh_text_formating_s
{
  uint8                     start_position;
    /**< Starting position of the text formatting. */
  uint8                     text_formatting_length; 
    /**< Gives the number of formatted characters or sets a default text 
         formatting. */
  wms_udh_alignment_e_type  alignment_type;
    /**< Indicated by bit 0 and bit 1 of the formatting mode octet. */
  wms_udh_font_size_e_type  font_size;
    /**< Indicated by bit 3 and bit 2 of the formatting mode octet. */
  boolean                   style_bold;
    /**< Indicated by bit 4 of the formatting mode octet. */
  boolean                   style_italic;
    /**< Indicated by bit 5 of the formatting mode octet. */
  boolean                   style_underlined;
    /**< Indicated by bit 6 of the formatting mode octet. */
  boolean                   style_strikethrough;
    /**< Indicated by bit 7 of the formatting mode octet. */
  boolean                   is_color_present;
    /**< If FALSE, ignores the following color information. */
  wms_udh_text_color_e_type text_color_foreground;
    /**< Defines the text foreground color. */
  wms_udh_text_color_e_type text_color_background;
    /**< Defines the text background color. @newpagetable */
} wms_udh_text_formating_s_type;

typedef struct wms_udh_pre_def_sound_s
{
  uint8       position;   /**< Number of characters from the beginning of the 
                               SM data after which the sound shall be played. */
  uint8       snd_number; /**< Sound number encoded as an integer value. */
} wms_udh_pre_def_sound_s_type;

typedef struct wms_udh_user_def_sound_s
{
  uint8       data_length;
    /**< Length of the user-defined sound. */
  uint8       position;
    /**< Indicates in the SM data the instant after which the sound shall be 
         played. */
  uint8       user_def_sound[WMS_UDH_MAX_SND_SIZE];
    /**< Number of the user-defined sound. */
} wms_udh_user_def_sound_s_type;

typedef struct wms_udh_pre_def_anim_s
{
  uint8       position;
    /**< Number of characters from the beginning of the SM data after which the 
         animation shall be displayed. */
  uint8       animation_number;
    /**< Animation number encoded as an integer. */
} wms_udh_pre_def_anim_s_type;

typedef struct wms_udh_large_anim_s
{
  uint8        position;
    /**< Number of characters from the beginning of the SM data after which the 
         animation shall be displayed. */
  uint8        data[WMS_UDH_ANIM_NUM_BITMAPS][WMS_UDH_LARGE_BITMAP_SIZE]; 
    /**< Data for the large animation. */
} wms_udh_large_anim_s_type;

typedef struct wms_udh_small_anim_s
{
  uint8         position;
    /**< Number of characters from the beginning of the SM data after which the 
         animation shall be displayed. */
  uint8         data[WMS_UDH_ANIM_NUM_BITMAPS][WMS_UDH_SMALL_BITMAP_SIZE];
    /**< Data for the small animation. */
} wms_udh_small_anim_s_type;

typedef struct wms_udh_large_picture_data_s
{
  uint8             position;
    /**< Number of characters from the beginning of the SM data after which the 
         picture shall be displayed. */
  uint8             data[WMS_UDH_LARGE_PIC_SIZE];
    /**< Data for the large picture. */
} wms_udh_large_picture_data_s_type;

typedef struct wms_udh_small_picture_data_s
{
  uint8               position;
    /**< Number of characters from the beginning of the SM data after which the 
         picture shall be displayed. */
  uint8               data[WMS_UDH_SMALL_PIC_SIZE];
    /**< Data for the small picture. */
} wms_udh_small_picture_data_s_type;

typedef struct wms_udh_var_picture_s
{
  uint8       position;
    /**< Number of characters from the beginning of the SM data after which the 
         picture shall be displayed. */
  uint8       width;
    /**< Horizontal dimension of the picture. Number of pixels in multiples of 8. */
  uint8       height;
    /**< Vertical dimension of the picture. Number of pixels in multiples of 8. */ 
  uint8       data[WMS_UDH_VAR_PIC_SIZE];
    /**< Data for the variable picture, line by line from top left to bottom right. */
} wms_udh_var_picture_s_type;

typedef struct wms_udh_user_prompt_s
{      
  uint8       number_of_objects;
    /**< Number of objects (all of the same kind) that follow this header and that 
         will be stitched together by the applications. Objects that can be 
         stitched are images (small, large, variable) and user-defined sounds. 
         Following are two examples.
         - Five small pictures are to be stitched together horizontally.
         - Six iMelody tones are to be connected with the intermediate iMelody 
           header and footer ignored. @tablebulletend 
    */
   } wms_udh_user_prompt_s_type;

typedef struct wms_udh_eo_s
{
  wms_udh_eo_content_s_type         content;
    /**< UDH Extended Object content information element; see 
         #wms_udh_eo_content_s for details. */
  boolean                           first_segment;
    /**< Indicates whether it is the first segment. */
  uint8                             reference;
    /**< Identify those Extended Object segments that are to be linked together. */
  uint16                            length;
    /**< Length of the entire Extended Object data. */                                
	uint8                             control;
    /**< Control data. */
  wms_udh_eo_id_e_type              type;
    /**< ID of the Extended Object. */
  uint16                            position;
    /**< Absolute position of the Extended Object in the entire text after 
         concatenation, starting from 1. */
} wms_udh_eo_s_type;

typedef struct wms_udh_rfc822_s
{
  uint8        header_length; 
    /**< Using 8-bit data, an integer representation of the number of octets 
         within (that fraction of) the RFC 822 E-Mail Header that is located at 
         the beginning of the data part of the current (segment of the 
         concatenated) SM. */
} wms_udh_rfc822_s_type;

typedef struct wms_udh_nat_lang_ss_s
{
  wms_udh_nat_lang_id_e_type nat_lang_id; /**< National language identifier. */
} wms_udh_nat_lang_ss_s_type;

typedef struct wms_udh_nat_lang_ls_s
{
  wms_udh_nat_lang_id_e_type nat_lang_id; /**< National language identifier. @newpagetable */
} wms_udh_nat_lang_ls_s_type;

typedef struct wms_udh_other_s
{
   wms_udh_id_e_type  header_id;
     /**< User Data Header ID, indicating the type of user data. */
   uint8              header_length;
     /**< Length of the user data header. */
   uint8              data[WMS_UDH_OTHER_SIZE];
     /**< User data. */
} wms_udh_other_s_type;

typedef struct wms_udh_s
{
  wms_udh_id_e_type               header_id;
    /**< User Data Header ID, indicating the type of user data. */

  /** Used by the #wms_udh_s structure.
  */
  union wms_udh_u 
  {
    wms_udh_concat_8_s_type             concat_8;
      /**< Concatenated short messages, 8-bit reference number; see 
           #wms_udh_concat_8_s for details. */
 /*~ CASE WMS_UDH_CONCAT_8 wms_udh_u.concat_8 */

    wms_udh_special_sm_s_type           special_sm;
      /**< Special SMS Message Indication; see #wms_udh_special_sm_s for 
           details. */
 /*~ CASE WMS_UDH_SPECIAL_SM wms_udh_u.special_sm */

    wms_udh_wap_8_s_type                wap_8;
      /**< Wireless application port addressing scheme, 8-bit address; 
           see #wms_udh_wap_8_s for details. */ 
 /*~ CASE WMS_UDH_PORT_8 wms_udh_u.wap_8 */

    wms_udh_wap_16_s_type               wap_16;
      /**< Wireless application port addressing scheme, 16-bit address; 
           see #wms_udh_wap_16_s for details. */
 /*~ CASE WMS_UDH_PORT_16 wms_udh_u.wap_16 */

    wms_udh_concat_16_s_type            concat_16;
      /**< Concatenated short message, 16-bit reference number; see 
           #wms_udh_concat_16_s for details. */
 /*~ CASE WMS_UDH_CONCAT_16 wms_udh_u.concat_16 */

    wms_udh_text_formating_s_type       text_formating;
      /**< Text formatting; see #wms_udh_text_formating_s for details. */
 /*~ CASE WMS_UDH_TEXT_FORMATING wms_udh_u.text_formating */

    wms_udh_pre_def_sound_s_type        pre_def_sound;
      /**< Predefined sound; see #wms_udh_pre_def_sound_s for details. */
 /*~ CASE WMS_UDH_PRE_DEF_SOUND wms_udh_u.pre_def_sound */

    wms_udh_user_def_sound_s_type       user_def_sound;
      /**< User-defined sound; see #wms_udh_user_def_sound_s for details. */
 /*~ CASE WMS_UDH_USER_DEF_SOUND wms_udh_u.user_def_sound */

    wms_udh_pre_def_anim_s_type         pre_def_anim;
      /**< Predefined animation; see #wms_udh_pre_def_anim_s for details. */
 /*~ CASE WMS_UDH_PRE_DEF_ANIM wms_udh_u.pre_def_anim */

    wms_udh_large_anim_s_type           large_anim;
      /**< Large animation; see #wms_udh_large_anim_s for details. */
 /*~ CASE WMS_UDH_LARGE_ANIM wms_udh_u.large_anim */

    wms_udh_small_anim_s_type           small_anim;
      /**< Small animation; see #wms_udh_small_anim_s for details. */
 /*~ CASE WMS_UDH_SMALL_ANIM wms_udh_u.small_anim */ 

    wms_udh_large_picture_data_s_type   large_picture;
      /**< Large picture; see #wms_udh_large_picture_data_s for details. */
 /*~ CASE WMS_UDH_LARGE_PICTURE wms_udh_u.large_picture */

    wms_udh_small_picture_data_s_type   small_picture;
      /**< Small picture; see #wms_udh_small_picture_data_s for details. */
 /*~ CASE WMS_UDH_SMALL_PICTURE wms_udh_u.small_picture */

    wms_udh_var_picture_s_type          var_picture;
      /**< Variable picture; see #wms_udh_var_picture_s for details. */
 /*~ CASE WMS_UDH_VAR_PICTURE wms_udh_u.var_picture */

    wms_udh_user_prompt_s_type          user_prompt;
      /**< User prompt indicator; see #wms_udh_user_prompt_s for details. */
 /*~ CASE WMS_UDH_USER_PROMPT wms_udh_u.user_prompt */

    wms_udh_eo_s_type                   eo;
      /**< Extended Object; see #wms_udh_eo_s for details. */
 /*~ CASE WMS_UDH_EXTENDED_OBJECT wms_udh_u.eo */

    wms_udh_rfc822_s_type               rfc822;
      /**< RFC 822 E-Mail Header; see #wms_udh_rfc822_s for details. */
 /*~ CASE WMS_UDH_RFC822 wms_udh_u.rfc822 */

    wms_udh_nat_lang_ss_s_type          nat_lang_ss;
      /**< National language single shift; see #wms_udh_nat_lang_ss_s for 
           details. */
 /*~ CASE WMS_UDH_NAT_LANG_SS wms_udh_u.nat_lang_ss */

    wms_udh_nat_lang_ls_s_type          nat_lang_ls;
      /**< National language locking shift; see #wms_udh_nat_lang_ls_s for 
           details. */ 
 /*~ CASE WMS_UDH_NAT_LANG_LS wms_udh_u.nat_lang_ls */

    wms_udh_other_s_type                other;
      /**< Other type of information element supported; see wms_udh_other_s 
           for details. @newpagetable */
 /*~ DEFAULT wms_udh_u.other */

  }u; /**< Used by the #wms_udh_s structure. */
  /*~ FIELD wms_udh_s.u DISC _OBJ_.header_id */
} wms_udh_s_type;

typedef struct
{
  uint8      year;     /**< 00 through 99. */
  uint8      month;    /**< 01 through 12. */
  uint8      day;      /**< 01 through 31. */
  uint8      hour;     /**< 00 through 23. */
  uint8      minute;   /**< 00 through 59. */
  uint8      second;   /**< 00 through 59. */
  sint7      timezone; /**< +/-, [-48,+48] number of 15 minutes; GSM/WCDMA only. */
} wms_timestamp_s_type;

typedef struct
{
  boolean                       with_extension;
  /**< Whether octet2 is an extension of octet1. */
  boolean                       single_shot;
  /**< Whether the SC is required to make up to one delivery attempt.  */
  uint8                         extension;
  /**< Extended functionality indicator. */
  wms_enhanced_vp_format_e_type vp_format;
  /**< Validity period format. */
  wms_timestamp_s_type          time;
  /**< Timestamp. @newpagetable */ 
} wms_enhanced_vp_s_type;

typedef struct wms_gw_dcs_s
{
  wms_message_class_e_type          msg_class;
    /**< Message class. */
  boolean                           is_compressed;  
    /**< Indicates whether the message is compressed. */
  wms_gw_alphabet_e_type            alphabet;
    /**< GSM/WCDMA-specific alphabet set. */  
  wms_gw_msg_waiting_e_type         msg_waiting;
    /**< Type of message waiting action. */
  boolean                           msg_waiting_active;
    /**< Indicates whether the message waiting is active. */
  wms_gw_msg_waiting_kind_e_type    msg_waiting_kind;
    /**< Type of message waiting (e.g., voice mail, email). */ 
  uint8                             raw_dcs_data;
    /**< Raw DCS byte. */
} wms_gw_dcs_s_type;

typedef struct wms_gw_validity_s
{
  wms_gw_validity_format_e_type  format; /**< Validity Period Format. */ 

  /** Used by the #wms_gw_validity_s structure.
  */
  union wms_gw_validity_u 
  {
    wms_timestamp_s_type    time;
      /**< Used by both absolute and relative formats. */
    /*~ IF (_DISC_ == WMS_GW_VALIDITY_RELATIVE || _DISC_ == WMS_GW_VALIDITY_ABSOLUTE) 
     wms_gw_validity_u.time */
      
    wms_enhanced_vp_s_type  enhanced_vp;
      /**< Enhanced validity period. */ 
    /*~ IF (_DISC_ == WMS_GW_VALIDITY_ENHANCED) wms_gw_validity_u.enhanced_vp */

    /*~ DEFAULT wms_gw_validity_u.void */
  } u; /**< Used by the #wms_gw_validity_s structure. */
  /*~ FIELD wms_gw_validity_s.u DISC _OBJ_.format */
} wms_gw_validity_s_type;

typedef struct wms_gw_user_data_s
{
  uint8                          num_headers;
    /**< Number of user data headers. */
  wms_udh_s_type                 headers[WMS_MAX_UD_HEADERS];
    /**< Types of user data headers; see #wms_udh_s for details. */
  uint16                         sm_len;
    /**< Length of short message. */
  uint8                          sm_data[WMS_MAX_LEN];
    /**< Short message data. */
} wms_gw_user_data_s_type;

typedef struct wms_raw_ts_data_s
{
  wms_format_e_type           format;    /**< Format of the message. */
  wms_gw_tpdu_type_e_type     tpdu_type;
    /**< Type of TPDU. Meaningful only if the format is a GSM/WCDMA message. */
  uint32                      len;
    /**< Length of the message. Meaningful only if the format is a GSM/WCDMA 
         message. */
  uint8                       data[ WMS_MAX_LEN ]; 
    /**< Data in the message. Meaningful only if the format is a GSM/WCDMA 
         message. */
} wms_raw_ts_data_s_type;

typedef struct wms_address_s
{
  wms_digit_mode_e_type          digit_mode;
    /**< Indicates 4 bit or 8 bit. */
  wms_number_mode_e_type         number_mode;
    /**< Used in CDMA only. It is meaningful only when digit_mode is 8 bit. */
  wms_number_type_e_type         number_type;
    /**< For a CDMA address, this is used only when digit_mode is 8 bit. \n 
         To specify an international address for CDMA, use the following 
         settings:
          - Digit_mode = 8-bit
          - Number_mode = NONE_DATA_NETWORK
          - Number_type = INTERNATIONAL
          - Number_plan = TELEPHONY
          - Number_of_digits = Number of digits
          - Digits = ASCII digits, e.g., 1, 2, 3, 4, and 5 @tablebulletend
    */

  wms_number_plan_e_type         number_plan;
    /**< For a CDMA address, this is used only when digit_mode is 8 bit. */
  uint8                          number_of_digits;
    /**< Number of bytes in the digits array. */
  uint8                          digits[ WMS_ADDRESS_MAX ];
    /**< Each byte in this array represents a 4-bit or 8-bit digit of address data.
         Each digit must be a valid standardized DTMF digit code:
      @verbatim
      Hex 4/8-bit             Hex 4/8-bit
      DTMF digit     ASCII    DTMF digit     ASCII
      -----------   -------   -----------   -------
       0x0/0x00     Invalid    0x8/0x08        8
       0x1/0x01        1       0x9/0x09        9
       0x2/0x02        2       0xA/0x0A        0
       0x3/0x03        3       0xB/0x0B        *
       0x4/0x04        4       0xC/0x0C        #
       0x5/0x05        5       0xD/0x0D     Invalid
       0x6/0x06        6       0xE/0x0E     Invalid
       0x7/0x07        7       0xF/0x0F     Invalid
      @endverbatim
    */
} wms_address_s_type;

typedef struct wms_gw_submit_s
{
  boolean                           reject_duplicates;
    /**< TP Reject Duplicates (TP-RD). */
  boolean                           reply_path_present;
    /**< TP Reply Path (TP-RP). */
  boolean                           user_data_header_present;
    /**< TP User Data Header Indicator (TP-UDHI). */
  boolean                           status_report_enabled;
    /**< TP Status Report Request (TP-SRR). */
  wms_message_number_type           message_reference;
    /**< TP Message Reference (TP-MR). */
  wms_address_s_type                address;
    /**< TP Destination Address (TP-DA); see #wms_address_s for details. */
  wms_pid_e_type                    pid;
    /**< TP Protocol Identifier (TP-PID). */
  wms_gw_dcs_s_type                 dcs;
    /**< TP Data Coding Scheme (TP-DCS); see #wms_gw_dcs_s for details. */
  wms_gw_validity_s_type            validity;
    /**< TP Validity Period Format (TP-VPF) and TP Validity Period (TP-VP);
         see #wms_gw_validity_s for details. */
  wms_gw_user_data_s_type           user_data;
    /**< TP User Data (TP-UD); see #wms_gw_user_data_s for details. */
} wms_gw_submit_s_type;

typedef struct wms_gw_deliver_s
{
  boolean                          more;
    /**< TP More Messages to Send (TP-MMS). */
  boolean                          reply_path_present;
    /**< TP Reply Path (TP-RP). */
  boolean                          user_data_header_present;
    /**< TP User Data Header Indicator (TP-UDHI). */
  boolean                          status_report_enabled;
    /**< TP Status Report Indication (TP-SRI). */
  wms_address_s_type               address;
    /**< TP Originating Address (TP-OA); see #wms_address_s for details. */
  wms_pid_e_type                   pid;
    /**< TP Protocol Identifier (TP-PID). */
  wms_gw_dcs_s_type                dcs;
    /**< TP Data Coding Scheme (TP-DCS); see #wms_gw_dcs_s for details. */
  wms_timestamp_s_type             timestamp;
    /**< TP Service Centre Time Stamp (TP-SCTS). */
  wms_gw_user_data_s_type          user_data;
    /**< TP User Data (TP-UD); see #wms_gw_user_data_s for details. @newpagetable */
} wms_gw_deliver_s_type;



//**************************************************************
// private member
//**************************************************************



//from qualcomm source
static inline size_t memscpy(void *dst, size_t dst_size, const void *src, size_t src_size)
{
  if (src_size > dst_size)
  {
    //src_size=dst_size;
  }  
  memcpy(dst,src,src_size);
  return src_size;
}



//**************************************************************
// public function
//**************************************************************
//from qualcomm source
void wms_ts_ascii_to_bcd
(
  const uint8     * ascii,
  uint8           len,
  uint8           * out
);

boolean wms_ts_bcd_to_int
(
  const uint8 bcd, /*IN*/
  uint8 *result    /*OUT*/
);

void wms_ts_bcd_to_ascii
(
  const uint8         * addr,
  uint8               len,
  uint8               * out
);

wms_status_e_type wms_ts_encode_submit
(
  const wms_gw_submit_s_type    *submit,
  wms_raw_ts_data_s_type        *raw_ts_data_ptr
);

wms_status_e_type wms_ts_decode_deliver
(
  const wms_raw_ts_data_s_type            * raw_ts_data_ptr,
  wms_gw_deliver_s_type                   * deliver,
  uint32                                  * nRawTsLen
);



//**************************************************************
// private function
//**************************************************************



//from qualcomm source
uint16 wms_ts_pack_gw_7_bit_chars
(
  const uint8     * in,
  uint16          in_len,      /* Number of 7-bit characters */
  uint16          shift,
  uint16          out_len_max, /* Number of 7-bit characters */
  uint8           * out
);

uint8 wms_ts_encode_address
(
  const wms_address_s_type    * addr,
  uint8                       * data
);

uint8 wms_ts_encode_dcs
(
  const wms_gw_dcs_s_type   *dcs,  /* IN */
  uint8                     *data  /* OUT */
);

uint8 wms_ts_encode_relative_time
(
  const wms_timestamp_s_type  *timestamp
);

uint8 wms_ts_encode_timestamp
(
  const wms_timestamp_s_type      *timestamp, /* IN */
  uint8                           *data     /* OUT */
);

uint8 wms_ts_encode_enhanced_vp
(
  const wms_enhanced_vp_s_type    *enhanced_vp, /* IN */
  uint8                           *data     /* OUT */
);

uint8 wms_ts_encode_gw_validity
(
  const wms_gw_validity_s_type      *validity,
  uint8                               *data
);

uint32 wms_ts_compute_gw_user_data_length
(
  const wms_gw_dcs_s_type         *dcs,
  const wms_gw_user_data_s_type   *user_data
);

uint8 wms_ts_encode_gw_user_data
(
  const wms_gw_dcs_s_type         *dcs,
  const wms_gw_user_data_s_type   *user_data,
  uint8                           *data
);

uint8 wms_ts_decode_address
(
  const uint8               * data,
  wms_address_s_type        * addr
);

uint8 wms_ts_decode_dcs
(
  const uint8           *data,
  wms_gw_dcs_s_type     *dcs
);

uint8 wms_ts_decode_timestamp
(
  const uint8             *data,
  wms_timestamp_s_type  *timestamp
);

uint8 wms_ts_decode_gw_user_data
(
  const wms_gw_dcs_s_type   *dcs,
  const uint8               len, // user data length
  const uint8               *data,
  const boolean             user_data_header_present,
  wms_gw_user_data_s_type   *user_data
);

/*static*/ int wms_ts_encode_udh_concat_8
(
  const wms_udh_s_type *const_header,
  uint8 *udh
);

/*static*/ int wms_ts_encode_udh_concat16
(
  const wms_udh_s_type *const_header,
  uint8 *udh
);

int wms_ts_encode_udh_special_sm
(
  const wms_udh_s_type *const_header,
  uint8 *udh
);

/*static*/ int wms_ts_encode_udh_port_8
(
  const wms_udh_s_type *const_header,
  uint8 *udh
);

/*static*/ int wms_ts_encode_udh_port16
(
  const wms_udh_s_type *const_header,
  uint8 *udh
);

int wms_ts_encode_udh_text_formatting
(
  const wms_udh_s_type *const_header,
  uint8 *udh
);

int wms_ts_encode_udh_pre_def_sound
(
  const wms_udh_s_type *const_header,
  uint8 *udh
);

int wms_ts_encode_udh_user_def_sound
(
  const wms_udh_s_type *const_header,
  uint8 *udh
);

int wms_ts_encode_udh_pre_def_anim
(
  const wms_udh_s_type *const_header,
  uint8 *udh
);

int wms_ts_encode_udh_large_anim
(
  const wms_udh_s_type *const_header,
  uint8 *udh
);

int wms_ts_encode_udh_small_anim
(
  const wms_udh_s_type *const_header,
  uint8 *udh
);

int wms_ts_encode_udh_large_picture
(
  const wms_udh_s_type *const_header,
  uint8 *udh
);

int wms_ts_encode_udh_small_picture
(
  const wms_udh_s_type *const_header,
  uint8 *udh
);

int wms_ts_encode_udh_var_picture
(
  const wms_udh_s_type *const_header,
  uint8 *udh
);

int wms_ts_encode_udh_user_prompt
(
  const wms_udh_s_type *const_header,
  uint8 *udh
);

int wms_ts_encode_udh_eo
(
  const wms_udh_s_type *const_header,
  uint8 *udh
);

int wms_ts_encode_udh_rfc822
(
  const wms_udh_s_type *const_header,
  uint8 *udh
);

int wms_ts_encode_udh_nat_lang_ss
(
  const wms_udh_s_type *const_header,
  uint8 *udh
);

int wms_ts_encode_udh_nat_lang_ls
(
  const wms_udh_s_type *const_header,
  uint8 *udh
);

int wms_ts_encode_udh_other
(
  const wms_udh_s_type *const_header,
  uint8 *udh
);

uint8 wms_ts_encode_evp_rel_time
(
  const wms_timestamp_s_type *vp,
  uint8                      *data
);

uint32 wms_ts_compute_user_data_header_length
(
  const uint8           num_headers,
  const wms_udh_s_type *headers
);

uint8 wms_ts_encode_address
(
  const wms_address_s_type    * addr,
  uint8                       * data
);

uint8 wms_ts_encode_user_data_header
(
  uint8                           num_headers, /* IN */
  const wms_udh_s_type            * headers,   /* IN */
  uint8                           *data        /* OUT */
);

uint8 wms_ts_get_udh_length
(
  const wms_udh_s_type                    *udh
);

wms_status_e_type wms_ts_encode_submit
(
  const wms_gw_submit_s_type    *submit,
  wms_raw_ts_data_s_type        *raw_ts_data_ptr
);

uint8 wms_ts_unpack_gw_7_bit_chars
(
  const uint8       * in,
  uint8             in_len,        /* Number of 7-bit characters */
  uint8             out_len_max,   /* Number of maximum 7-bit characters after unpacking */
  uint16            shift,
  uint8             * out
);

uint8 wms_ts_decode_user_data_header
(
  const uint8               len, /* user_data_length*/
  const uint8               *data, /* first byte of user data */
  uint8                     * num_headers_ptr, /* OUT */
  wms_udh_s_type            * udh_ptr          /* OUT */
);

/*static*/ uint8 wms_ts_decode_udh_concat_8
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr /* OUT */
);

/*static*/ uint8 wms_ts_decode_udh_concat16
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
);

/*static*/ uint8 wms_ts_decode_udh_special_sm
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
);

/*static*/ uint8 wms_ts_decode_udh_port_8
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
);

/*static*/ uint8 wms_ts_decode_udh_port16
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
);

/*static*/ uint8 wms_ts_decode_udh_text_formatting
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
);

/*static*/ uint8 wms_ts_decode_udh_pre_def_sound
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
);

/*static*/ uint8 wms_ts_decode_udh_user_def_sound
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
);

/*static*/ uint8 wms_ts_decode_udh_pre_def_anim
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
);

/*static*/ uint8 wms_ts_decode_udh_large_anim
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
);

/*static*/ uint8 wms_ts_decode_udh_small_anim
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
);

/*static*/ uint8 wms_ts_decode_udh_large_picture
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
);

/*static*/ uint8 wms_ts_decode_udh_small_picture
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
);

/*static*/ uint8 wms_ts_decode_udh_var_picture
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
);

/*static*/ uint8 wms_ts_decode_udh_user_prompt
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
);

/*static*/ uint8 wms_ts_decode_udh_eo
(
  const uint8 *udh,
  boolean     first_segment,
  wms_udh_s_type *header_ptr
);

/*static*/ uint8 wms_ts_decode_udh_rfc822
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
);

/*static*/ uint8 wms_ts_decode_udh_nat_lang_ss
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
);

/*static*/ uint8 wms_ts_decode_udh_nat_lang_ls
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
);

/*static*/ uint8 wms_ts_decode_udh_other
(
  const uint8* udh,
  wms_udh_s_type *header_ptr
);

/*static*/ boolean wms_ts_udh_decode_first_seg_check
(
  const uint8  len,                /* user_data_length*/
  const uint8  *data,              /* first byte of user data */
  boolean      *is_first_segment_ptr      /* OUT */
);



#ifdef __cplusplus
}
#endif



#endif
