



#include <pthread.h>
#include "queue.h"
#include "log.h"
#include "command_processor.h"



//**************************************************************
// private member
//**************************************************************
#define	command_processor_max_queue_size		( 1024 * 1024 )



typedef struct
{
	command_id_type command_id;
} command_header_type_s;



#define	FEATURE_COMMAND_PROCESSOR_SIGNAL_DRIVEN

#ifdef FEATURE_COMMAND_PROCESSOR_SIGNAL_DRIVEN
pthread_cond_t	m_command_processor_process_thread_cond 	= PTHREAD_COND_INITIALIZER;
pthread_mutex_t m_command_processor_process_thread_mutex = PTHREAD_MUTEX_INITIALIZER;
#endif

typedef enum
{
	command_processor_process_thread_state_start,
	command_processor_process_thread_state_stop
} command_processor_process_thread_state_e;

pthread_t m_command_processor_process_thread = (pthread_t)NULL;

command_processor_process_thread_state_e	m_command_processor_process_thread_state = command_processor_process_thread_state_stop;



command_processor_command_handler_type m_command_processor_command_handler = NULL;



//**************************************************************
// public member
//**************************************************************



//**************************************************************
// private function
//**************************************************************
//==============================================================
//
//==============================================================
void command_processor_process( void )
{
	int r = 0;

	queue_data_id_type queue_data_id = invalid_queue_data_id;
	unsigned char 			queue_data[ max_queue_data_size ];
	unsigned int 				queue_data_size = 0;

	command_header_type_s 	command_header;
	unsigned int 						command_header_size = sizeof( command_header );

	unsigned char*	data = NULL;
	unsigned int		data_size = 0;

	//memset( queue_data, 0, sizeof( queue_data ) );
	//memset( &command_header, 0, sizeof( command_header ) );

	log_med( "start thread ok!" );	
	
	m_command_processor_process_thread_state = command_processor_process_thread_state_start;
	
	while ( command_processor_process_thread_state_start == m_command_processor_process_thread_state )
	{
	#ifdef FEATURE_COMMAND_PROCESSOR_SIGNAL_DRIVEN
		pthread_mutex_lock( &m_command_processor_process_thread_mutex );

		r = pthread_cond_wait( &m_command_processor_process_thread_cond, &m_command_processor_process_thread_mutex );

		if ( 0 != r )
		{
			log_error( "pthread_cond_wait() fail, r:[%d]", r );
		}

		pthread_mutex_unlock( &m_command_processor_process_thread_mutex );
	#endif

		while ( TRUE == queue_pop( queue_data, &queue_data_size, &queue_data_id ) )
		{
			memcpy( &command_header, queue_data, command_header_size );

			data = queue_data + command_header_size;
			data_size = queue_data_size - command_header_size;
			
			if ( TRUE == m_command_processor_command_handler( command_header.command_id, queue_data_id, data, data_size ) )
			{
				log_med( "m_command_processor_command_handler() ok! command_id:[%d], command_header_size:[%d], data_size:[%d]", 
													command_header.command_id, command_header_size, data_size );
			}
			else
			{
				log_error( "m_command_processor_command_handler() fail" );
			}
		}
	}

	log_med( "stop thread ok!" );
	
	pthread_exit( NULL );
}

//==============================================================
//
//==============================================================
int command_processor_process_start( void )
{
	int r = 0;

	r = pthread_create( &m_command_processor_process_thread, NULL, command_processor_process, NULL );

	if ( 0 != r )
	{
		log_error( "fail, r:[%d]", r );
		return FALSE;
	}
#ifdef FEATURE_DEBUG_LOG
	log_med( "ok!" );
#endif
	return TRUE;
}

//==============================================================
//
//==============================================================
void command_processor_process_stop( void )
{
	int r = 0;
	int thread_status = 0;

	//
	if ( NULL == m_command_processor_process_thread )
	{
		log_error( "m_command_processor_process_thread is null" );
		return;
	}
	
	m_command_processor_process_thread_state = command_processor_process_thread_state_stop;
#ifdef FEATURE_COMMAND_PROCESSOR_SIGNAL_DRIVEN
	pthread_mutex_lock( &m_command_processor_process_thread_mutex );
  pthread_cond_signal( &m_command_processor_process_thread_cond );
	pthread_mutex_unlock( &m_command_processor_process_thread_mutex );
#endif
	r = pthread_join( m_command_processor_process_thread, (void**)&thread_status );

	if ( 0 != r )
	{
		log_error( "pthread_join() fail, m_command_processor_process_thread:[%d], r:[%d], thread_status:[%d]",
																			m_command_processor_process_thread, r, thread_status );
	}
	
	m_command_processor_process_thread = (pthread_t)NULL;

	log_med( "ok! thread destroyed r:[%d], thread_status:[%d]", r, thread_status );	
}



//**************************************************************
// public function
//**************************************************************
//==============================================================
//
//==============================================================
int command_processor_init( const command_processor_command_handler_type const command_handler )
{
	if ( NULL == command_handler )
	{
		log_error( "command_handler is null" );
		return FALSE;
	}
	
	if ( FALSE == queue_init( command_processor_max_queue_size ) )
	{
		command_processor_release();

		log_error( "queue_init() fail" );
		return FALSE;
	}

	if ( FALSE == command_processor_process_start() )
	{
		command_processor_release();

		log_error( "command_processor_process_start() fail" );
		return FALSE;
	}
	
	m_command_processor_command_handler = command_handler;

	log_med( "ok!" );
	
	return TRUE;
}

//==============================================================
//
//==============================================================
void command_processor_release( void )
{
	command_processor_process_stop();

	queue_release();

	m_command_processor_command_handler = NULL;

	log_med( "ok!" );
}

//==============================================================
//
//==============================================================
queue_data_id_type command_processor_command_request( const command_id_type command_id, const unsigned char* const data, const unsigned int data_size )
{
	queue_data_id_type queue_data_id = invalid_queue_data_id;
	unsigned char 			queue_data[ max_queue_data_size ];
	unsigned int 				queue_data_size = 0;
	
	command_header_type_s 	command_header;
	unsigned int						command_header_size = sizeof( command_header );

	//memset( queue_data, 0, sizeof( queue_data ) );
	//memset( &command_header, 0, sizeof( command_header ) );

	//
	if ( command_header_size + data_size > max_queue_data_size )
	{
		log_error( "fail, data_size is too big, command_header_size:[%d], data_size:[%d], max_queue_data_size:[%d]",
																							command_header_size, data_size, max_queue_data_size );
		return invalid_queue_data_id;
	}

	//command_header(4 byte) + data(var byte)
	command_header.command_id = command_id;

	memcpy( queue_data, &command_header, command_header_size );
	queue_data_size += command_header_size;
	
	memcpy( queue_data + queue_data_size, data, data_size );
	queue_data_size += data_size;

	if ( FALSE == queue_push( queue_data, queue_data_size, &queue_data_id ) )
	{
		log_error( "queue_push() fail, command_id:[%d], command_header_size:[%d], data_size:[%d]", command_id, command_header_size, data_size );
		return invalid_queue_data_id;
	}
#ifdef FEATURE_COMMAND_PROCESSOR_SIGNAL_DRIVEN
	pthread_mutex_lock( &m_command_processor_process_thread_mutex );
  pthread_cond_signal( &m_command_processor_process_thread_cond );
	pthread_mutex_unlock( &m_command_processor_process_thread_mutex );
#endif
	log_med( "ok! command_id:[%d], command_header_size:[%d], data_size:[%d]", command_id, command_header_size, data_size );

	return queue_data_id;
}



