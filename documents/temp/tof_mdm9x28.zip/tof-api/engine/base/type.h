#ifndef TYPE_H
#define TYPE_H



#include <comdef.h>



#ifdef __cplusplus
extern "C" {
#endif



//**************************************************************
// public member
//**************************************************************
#ifndef TRUE
#define		TRUE			( 1 )
#endif

#ifndef FALSE
#define		FALSE			( 0 )
#endif



//**************************************************************
// public function
//**************************************************************



#ifdef __cplusplus
}
#endif



#endif

