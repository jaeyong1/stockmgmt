



#include <pthread.h>
#include "log.h"
#include "queue.h"



//**************************************************************
// private member
//**************************************************************
typedef struct
{
	queue_data_id_type data_id;
	unsigned int data_size;
} queue_data_header_s;



pthread_mutex_t m_queue_mutex = PTHREAD_MUTEX_INITIALIZER;

unsigned char*	m_queue = NULL;

unsigned int 		m_head_index = 0;
unsigned int 		m_tail_index = 0;

unsigned int 		m_max_static_queue_size = 0;
unsigned int 		m_max_dynamic_queue_size = 0;

unsigned int 		m_queue_data_id = 0;



//**************************************************************
// public member
//**************************************************************



//**************************************************************
// private function
//**************************************************************
//==============================================================
//
//==============================================================
unsigned int	get_queue_size( void )
{
	unsigned int queue_size = 0;
	
	//pthread_mutex_lock( &m_queue_mutex );

	if ( m_tail_index >= m_head_index )
	{
		queue_size = m_tail_index - m_head_index;
	}
	else
	{
		queue_size = m_max_dynamic_queue_size - m_head_index + m_tail_index;
	}
	
	//pthread_mutex_unlock( &m_queue_mutex );

	return queue_size;
}

//==============================================================
//
//==============================================================
queue_data_id_type	generate_queue_data_id( void )
{
	queue_data_id_type queue_data_id = 0;
	
	//pthread_mutex_lock( &m_queue_mutex );

	queue_data_id = m_queue_data_id++;

	if ( m_queue_data_id >= max_queue_data_id )
	{
		m_queue_data_id = 0;
	}
	
	//pthread_mutex_unlock( &m_queue_mutex );
	
	return queue_data_id;
}

//==============================================================
//
//==============================================================
void	log_queue( void )
{
}



//**************************************************************
// public function
//**************************************************************
//==============================================================
//
//==============================================================
int	queue_init( const unsigned int max_queue_size )
{
	if ( max_queue_size < max_queue_data_size )
	{
		log_error( "max_queue_size:[%d] should be bigger than max_queue_data_size:[%d]", max_queue_size, max_queue_data_size );
		return FALSE;
	}
	
	pthread_mutex_lock( &m_queue_mutex );
	
	m_queue = (unsigned char*)mem_alloc( max_queue_size );

	if ( NULL == m_queue )
	{
		log_error( "m_queue allocation fail" );

		pthread_mutex_unlock( &m_queue_mutex );

		queue_release();
		return FALSE;
	}

	m_max_static_queue_size = max_queue_size;
	m_max_dynamic_queue_size = max_queue_size;

	m_head_index = 0;
	m_tail_index = 0;

	pthread_mutex_unlock( &m_queue_mutex );

	log_med( "ok!, max_queue_size:[%d]", max_queue_size );

	return TRUE;
}

//==============================================================
//
//==============================================================
void	queue_release( void )
{
	pthread_mutex_lock( &m_queue_mutex );
	
	if ( NULL != m_queue )
	{
		mem_free( m_queue );
		
		m_queue = NULL;
	}

	m_max_static_queue_size = 0;
	m_max_dynamic_queue_size = 0;
	
	m_head_index = 0;
	m_tail_index = 0;

	pthread_mutex_unlock( &m_queue_mutex );

	log_med( "ok!" );
}

//==============================================================
//
//==============================================================
int	queue_push( const unsigned char* const data, const unsigned int data_size, queue_data_id_type* data_id )
{
	queue_data_header_s		header;
	unsigned int					header_size = sizeof( header );
	unsigned push_data_size = data_size + header_size;

	memset( &header, 0, header_size );

	//
	if ( push_data_size > max_queue_data_size )
	{
		log_error( "over max_queue_data_size:[%d], push_data_size:[%d]", max_queue_data_size, push_data_size );
		return FALSE;
	}
	
	pthread_mutex_lock( &m_queue_mutex );

	if ( m_tail_index >= m_head_index )
	{
		if ( push_data_size > ( m_max_static_queue_size - m_tail_index ) )
		{
			if ( push_data_size >= m_head_index )
			{
				log_error( "queue overflow, push_data_size:[%d]", push_data_size );
				log_error( "queue_size:[%d], m_head_index:[%d], m_tail_index:[%d]", get_queue_size(), m_head_index, m_tail_index );
				
				pthread_mutex_unlock( &m_queue_mutex );
				return FALSE;
			}			
			m_max_dynamic_queue_size = m_tail_index;
			m_tail_index = 0;

			log_low( "push to beginning of queue, m_max_dynamic_queue_size:[%d]", m_max_dynamic_queue_size );
		}
		else
		{
		}
	}
	else
	{
		if ( push_data_size >= m_head_index - m_tail_index )
		{
			log_error( "queue overflow, push_data_size:[%d]", push_data_size );
			log_error( "queue_size:[%d], m_head_index:[%d], m_tail_index:[%d]", get_queue_size(), m_head_index, m_tail_index );
				
			pthread_mutex_unlock( &m_queue_mutex );
			return FALSE;
		}
	}

	*data_id = generate_queue_data_id();
	
	header.data_id = *data_id;
	header.data_size = data_size;

	memcpy( m_queue + m_tail_index, &header, header_size );
	m_tail_index += header_size;
	
	memcpy( m_queue + m_tail_index, data, data_size );
	m_tail_index += data_size;

	pthread_mutex_unlock( &m_queue_mutex );
#ifdef FEATURE_DEBUG_LOG
	log_low( "data_id:[%d], data_size:[%d], queue_size:[%d], m_head_index:[%d], m_tail_index:[%d]", 
							*data_id, data_size, get_queue_size(), m_head_index, m_tail_index );
#endif
	return TRUE;
}

//==============================================================
//
//==============================================================
int	queue_pop( unsigned char* data, unsigned int* data_size, queue_data_id_type* data_id )
{
	queue_data_header_s 	header;
	unsigned int					header_size = sizeof( header );

	//
	pthread_mutex_lock( &m_queue_mutex );

	if ( 0 == get_queue_size() )
	{
	#ifdef FEATURE_DEBUG_LOG
		log_low( "queue is empty" );
	#endif

		pthread_mutex_unlock( &m_queue_mutex );
		return FALSE;
	}

	if ( m_max_dynamic_queue_size == m_head_index )
	{
		log_low( "pop from beginning of queue, m_max_dynamic_queue_size:[%d] head_index:[%d]", m_max_dynamic_queue_size, m_head_index );
		
		m_head_index = 0;
	}

	memcpy( &header, m_queue + m_head_index, header_size );
	m_head_index += header_size;

	*data_id = header.data_id;
	*data_size = header.data_size;

	memcpy( data, m_queue + m_head_index, header.data_size );
	m_head_index += header.data_size;

	pthread_mutex_unlock( &m_queue_mutex );
#ifdef FEATURE_DEBUG_LOG
	log_low( "data_id:[%d], data_size:[%d], queue_size:[%d], m_head_index:[%d], m_tail_index:[%d]", 
							*data_id, *data_size, get_queue_size(), m_head_index, m_tail_index );
#endif
	return TRUE;
}




