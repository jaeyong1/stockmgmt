#ifndef COMMAND_PROCESSOR_H
#define COMMAND_PROCESSOR_H



#include "type.h"
#include "queue.h"



#ifdef __cplusplus
extern "C" {
#endif



//**************************************************************
// public member
//**************************************************************
typedef unsigned int		command_id_type;



typedef int (*command_processor_command_handler_type )( const command_id_type command_id, const queue_data_id_type data_id, const unsigned char* const data, const unsigned int data_size );



//**************************************************************
// public function
//**************************************************************
int command_processor_init( const command_processor_command_handler_type const command_handler );
void command_processor_release( void );

queue_data_id_type command_processor_command_request( const command_id_type command_id, const unsigned char* const data, const unsigned int data_size );



#ifdef __cplusplus
}
#endif



#endif

