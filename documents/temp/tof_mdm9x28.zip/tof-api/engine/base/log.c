



#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <pthread.h>
#include "log.h"



//**************************************************************
// private member
//**************************************************************
pthread_mutex_t m_log_mutex 	= PTHREAD_MUTEX_INITIALIZER;



write_log_function_list_s		m_write_log_function_list;



//**************************************************************
// public member
//**************************************************************



//**************************************************************
// private function
//**************************************************************



//**************************************************************
// public function
//**************************************************************
//==============================================================
//
//==============================================================
void	log_init( const write_log_function_list_s* const list )
{
	memset( &m_write_log_function_list, 0, sizeof( m_write_log_function_list ) );
	
	m_write_log_function_list = *list;
}

//==============================================================
//
//==============================================================
void	log_release( void )
{
	memset( &m_write_log_function_list, 0, sizeof( m_write_log_function_list ) );
}

//==============================================================
//
//==============================================================
void	log_write( const log_type_e type, const char* file_name, unsigned int line_number, const char* const func_name, const char* const format, ... )
{
	unsigned int i = 0;
	
	char log_string_buf[ max_log_buffer_size ];
	
	char 		arg_string_buf[ max_log_buffer_size ];
	va_list arg_ptr;

	char					func_name_buf[ max_log_func_name_len ];
	unsigned int 	func_name_len = 0;
	char*					func_name_postfix = "()";

	char					file_name_buf[ max_log_file_name_len ];
	unsigned int	file_name_len = 0;

	char 					space_char = ' ';
	
	//memset( arg_string_buf, 0, sizeof( arg_string_buf ) );
	//memset( log_string_buf, 0, sizeof( log_string_buf ) );

	//
	if ( type < log_type_high || type >= log_type_max )
	{
		return;
	}

	va_start( arg_ptr, format );
	vsprintf( arg_string_buf, format, arg_ptr );
	va_end( arg_ptr );
	
	pthread_mutex_lock( &m_log_mutex );

	func_name_len = strlen( func_name );

	if ( func_name_len < ( max_log_func_name_len + strlen( func_name_postfix ) ) )
	{
		strcpy( func_name_buf, func_name );
		strcat( func_name_buf, func_name_postfix );
	}
	else
	{
		memcpy( func_name_buf, func_name, max_log_func_name_len );
		func_name_buf[ max_log_func_name_len - 1 ] = NULL;
	}

	file_name_len = strlen( file_name );

	if ( file_name_len < max_log_file_name_len )
	{
		strcpy( file_name_buf, file_name );

		for ( i = file_name_len; i < max_log_file_name_len; ++i )
		{
			file_name_buf[ i ] = space_char;
		}
		
		file_name_buf[ max_log_file_name_len - 1 ] = NULL;
	}
	else
	{
		memcpy( file_name_buf, file_name, max_log_file_name_len );
		file_name_buf[ max_log_file_name_len - 1 ] = NULL;
	}
	
	sprintf( log_string_buf, "%s %08d    %s %s", file_name_buf, line_number, func_name_buf, arg_string_buf );

	pthread_mutex_unlock( &m_log_mutex );
	
	if ( NULL == m_write_log_function_list.function[ type ] )
	{
		return;
	}
	
	( m_write_log_function_list.function[ type ] )( log_string_buf );
}



