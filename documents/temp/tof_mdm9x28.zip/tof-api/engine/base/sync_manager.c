



#include <pthread.h>
#include "log.h"
#include "sync_manager.h"



//**************************************************************
// private member
//**************************************************************
typedef enum
{
	sync_obj_state_none,
	sync_obj_state_enter_sync,
	sync_obj_state_leave_sync,
	sync_obj_state_garbage,
	sync_obj_state_max
} sync_object_state_e;



#define			wait_sync_polling_time_unit_millisecond				( 10 )			// 10 msec



#define			millisecond_per_second											( 1000 )
#define			microsecond_per_millisecond								( 1000 )


#ifdef FEATURE_SYNC_MANAGER_TEST
#define			sync_object_alive_time_second							( 10 )					// 10 sec for test
#define			collect_garbage_polling_time_unit_second	( 1 )					// 1 sec for test
#else
#define			sync_object_alive_time_second							( 60 * 4 )			// 240 sec = 4 min
#define			collect_garbage_polling_time_unit_second	( 60 )					// 60 sec = 1 min
#endif



pthread_mutex_t m_sync_manager_mutex = PTHREAD_MUTEX_INITIALIZER;

typedef struct
{
	sync_object_index_type 	index;
	sync_object_state_e			state;
	void*										user_data;
	unsigned long						time_stamp_second;
} sync_object_s;

sync_object_s*	m_sync_object_list = NULL;



unsigned long	m_sync_manager_time_stamp_second = 0;



typedef enum
{
	sync_manager_process_thread_state_start,
	sync_manager_process_thread_state_stop
} sync_manager_process_thread_state_e;

pthread_t m_sync_manager_process_thread = (pthread_t)NULL;

sync_manager_process_thread_state_e	m_sync_manager_process_thread_state = sync_manager_process_thread_state_stop;



sync_manager_init_info_s	m_sync_manager_init_info;



//**************************************************************
// public member
//**************************************************************



//**************************************************************
// private function
//**************************************************************
//==============================================================
//
//==============================================================
int is_valid_sync_object( const sync_object_index_type sync_obj_index )
{
	if ( sync_obj_index >= m_sync_manager_init_info.max_sync_object_num )
	{
		log_error( "invalid sync_obj_index:[%d]", sync_obj_index );
		return FALSE;
	}
	
	return TRUE;
}

int sync_manager_set_sync_object_state( const sync_object_index_type sync_obj_index, const sync_object_state_e sync_obj_state )
{
	if ( FALSE == is_valid_sync_object( sync_obj_index ) )
	{
		log_error( "is_valid_sync_object() fail" );
		return FALSE;
	}
	
	m_sync_object_list[ sync_obj_index ].state = sync_obj_state;
}

//==============================================================
//
//==============================================================
void sync_manager_collect_garbage( void )
{
	unsigned int i = 0;
	unsigned long time_stamp_second = m_sync_manager_time_stamp_second;
	
	//
	log_med( "processing.... time_stamp_second:[%d]", time_stamp_second );
	
	pthread_mutex_lock( &m_sync_manager_mutex );
	
	for ( i = 0; i < m_sync_manager_init_info.max_sync_object_num; ++i )
	{
		if ( sync_obj_state_garbage == m_sync_object_list[ i ].state )
		{
			if ( ( time_stamp_second - m_sync_object_list[ i ].time_stamp_second ) > sync_object_alive_time_second )
			{
				log_fatal( "collect garbage sync_object, index:[%d], time_stamp_second:[%d], sync_object_time_stamp_second:[%d]",
																											m_sync_object_list[ i ].index, time_stamp_second, m_sync_object_list[ i ].time_stamp_second );
			
				sync_manager_init_sync_object( i );
			}
		}
	}

	pthread_mutex_unlock( &m_sync_manager_mutex );
}

//==============================================================
//
//==============================================================
void sync_manager_process( void )
{
	int r = 0;

	log_med( "start thread ok!" );	
	
	while ( sync_manager_process_thread_state_start == m_sync_manager_process_thread_state )
	{
		if ( 0 == ( m_sync_manager_time_stamp_second % collect_garbage_polling_time_unit_second ) )
		{
			sync_manager_collect_garbage();
		}

		usleep( microsecond_per_millisecond * millisecond_per_second );

		m_sync_manager_time_stamp_second++;
	}

	log_med( "stop thread ok!" );
	
	pthread_exit( NULL );
}

//==============================================================
//
//==============================================================
int sync_manager_process_start( void )
{
	int r = 0;

	//
	m_sync_manager_process_thread_state = sync_manager_process_thread_state_start;

	r = pthread_create( &m_sync_manager_process_thread, NULL, sync_manager_process, NULL );

	if ( 0 != r )
	{
		m_sync_manager_process_thread_state = sync_manager_process_thread_state_stop;
		
		log_error( "fail, r:[%d]", r );
		return FALSE;
	}
#ifdef FEATURE_DEBUG_LOG
	log_med( "ok!" );
#endif
	return TRUE;
}

//==============================================================
//
//==============================================================
void sync_manager_process_stop( void )
{
	int r = 0;
	int thread_status = 0;

	//
	if ( NULL == m_sync_manager_process_thread )
	{
		log_error( "m_sync_manager_process_thread is null" );
		return;
	}
	
	m_sync_manager_process_thread_state = sync_manager_process_thread_state_stop;
	
	r = pthread_join( m_sync_manager_process_thread, (void**)&thread_status );

	if ( 0 != r )
	{
		log_error( "pthread_join() fail, m_sync_manager_process_thread:[%d], r:[%d], thread_status:[%d]",
																			m_sync_manager_process_thread, r, thread_status );
	}
	
	m_sync_manager_process_thread = (pthread_t)NULL;

	log_med( "ok! thread destroyed r:[%d], thread_status:[%d]", r, thread_status );	
}

//==============================================================
//
//==============================================================
void	sync_manager_init_sync_object( const sync_object_index_type sync_obj_index )
{
	if ( FALSE == is_valid_sync_object( sync_obj_index ) )
	{
		log_error( "is_valid_sync_object() fail" );
		return;
	}

	//should be mutex locked before from here
	m_sync_object_list[ sync_obj_index ].index = sync_obj_index;
	sync_manager_set_sync_object_state( sync_obj_index, sync_obj_state_none );
	m_sync_object_list[ sync_obj_index ].user_data = NULL;
	m_sync_object_list[ sync_obj_index ].time_stamp_second = 0;
	//to here
}



//**************************************************************
// public function
//**************************************************************
//==============================================================
//
//==============================================================
int	sync_manager_init( const sync_manager_init_info_s* const init_info )
{
	unsigned int i = 0;

	//
	if ( 0 == init_info->max_sync_object_num )
	{
		log_error( "max_sync_object_num is 0" );
		return FALSE;
	}
	
	m_sync_manager_init_info = *init_info;
	
	pthread_mutex_lock( &m_sync_manager_mutex );
	
	m_sync_object_list = (sync_object_s*)mem_alloc( m_sync_manager_init_info.max_sync_object_num * sizeof( sync_object_s ) );

	if ( NULL == m_sync_object_list )
	{
		log_error( "m_sync_object_list allocation fail" );

		pthread_mutex_unlock( &m_sync_manager_mutex );

		sync_manager_release();
		return FALSE;
	}

	for ( i = 0; i < m_sync_manager_init_info.max_sync_object_num; ++i )
	{
		sync_manager_init_sync_object( i );
	}

	pthread_mutex_unlock( &m_sync_manager_mutex );

	if ( TRUE == init_info->use_garbage_collection )
	{
		if ( FALSE == sync_manager_process_start() )
		{
			log_error( "sync_manager_process_start() fail" );

			sync_manager_release();
			return FALSE;
		}
	}

	m_sync_manager_time_stamp_second = 0;

	log_med( "ok!" );

	return TRUE;
}

//==============================================================
//
//==============================================================
void sync_manager_release( void )
{
	sync_manager_process_stop();
	
	pthread_mutex_lock( &m_sync_manager_mutex );
	
	if ( NULL != m_sync_object_list )
	{
		mem_free( m_sync_object_list );
		
		m_sync_object_list = NULL;
	}

	pthread_mutex_unlock( &m_sync_manager_mutex );

	memset( &m_sync_manager_init_info, 0, sizeof( m_sync_manager_init_info ) );

	m_sync_manager_time_stamp_second = 0;

	log_med( "ok!" );
}

//==============================================================
//
//==============================================================
int	sync_manager_enter_sync( const void* const user_data, sync_object_index_type* sync_obj_index )
{
	unsigned int i = 0;

	//
	pthread_mutex_lock( &m_sync_manager_mutex );

	for ( i = 0; i < m_sync_manager_init_info.max_sync_object_num; ++i )
	{
		if ( sync_obj_state_none == m_sync_object_list[ i ].state )
		{
			sync_manager_set_sync_object_state( i, sync_obj_state_enter_sync );
			m_sync_object_list[ i ].user_data = user_data;
			m_sync_object_list[ i ].time_stamp_second = m_sync_manager_time_stamp_second;
			
			*sync_obj_index = m_sync_object_list[ i ].index;

			pthread_mutex_unlock( &m_sync_manager_mutex );

			log_med( "ok! sync_obj_index:[%d]", *sync_obj_index );
			return TRUE;
		}
	}
	
	pthread_mutex_unlock( &m_sync_manager_mutex );

	log_error( "fail" );

	return FALSE;
}

//==============================================================
//
//==============================================================
int	sync_manager_get_enter_sync_object_user_data( const sync_object_index_type sync_obj_index, void** user_data )
{
	unsigned int i = 0;

	//
	if ( FALSE == is_valid_sync_object( sync_obj_index ) )
	{
		log_error( "is_valid_sync_object() fail" );
		return FALSE;
	}
	
	pthread_mutex_lock( &m_sync_manager_mutex );

	if ( sync_obj_state_enter_sync == m_sync_object_list[ sync_obj_index ].state )
	{
		*user_data = m_sync_object_list[ sync_obj_index ].user_data;

		pthread_mutex_unlock( &m_sync_manager_mutex );

		log_med( "ok! sync_obj_index:[%d]", sync_obj_index );
		return TRUE;
	}

	pthread_mutex_unlock( &m_sync_manager_mutex );

	log_error( "fail, sync_obj_index:[%d]", sync_obj_index );

	return FALSE;
}

//==============================================================
//
//==============================================================
int	sync_manager_leave_sync( const sync_object_index_type sync_obj_index )
{
	unsigned int i = 0;

	//
	if ( FALSE == is_valid_sync_object( sync_obj_index ) )
	{
		log_error( "is_valid_sync_object() fail" );
		return FALSE;
	}
	
	pthread_mutex_lock( &m_sync_manager_mutex );

	if ( sync_obj_state_enter_sync == m_sync_object_list[ sync_obj_index ].state )
	{
		sync_manager_set_sync_object_state( sync_obj_index, sync_obj_state_leave_sync );
		
		pthread_mutex_unlock( &m_sync_manager_mutex );

		log_med( "ok! sync_obj_index:[%d]", sync_obj_index );
		return TRUE;
	}

	pthread_mutex_unlock( &m_sync_manager_mutex );

	log_error( "fail, sync_obj_index:[%d]", sync_obj_index );

	return FALSE;
}

//==============================================================
//
//==============================================================
int	sync_manager_wait_sync( const sync_object_index_type sync_obj_index )
{
	unsigned int max_polling_count = ( m_sync_manager_init_info.max_sync_timeout_millisecond / (unsigned long)wait_sync_polling_time_unit_millisecond );
	unsigned int count = 0;

	//
	if ( FALSE == is_valid_sync_object( sync_obj_index ) )
	{
		log_error( "is_valid_sync_object() fail" );
		return FALSE;
	}

	log_med( "wait.... max_polling_count:[%d]", max_polling_count );
	
	while ( count <= max_polling_count )
	{
		//pthread_mutex_lock( &m_sync_manager_mutex );	//move to below for performance

		if ( sync_obj_state_leave_sync == m_sync_object_list[ sync_obj_index ].state )
		{
			pthread_mutex_lock( &m_sync_manager_mutex );
			sync_manager_init_sync_object( sync_obj_index );			
			pthread_mutex_unlock( &m_sync_manager_mutex );
			
			log_med( "ok!" );
			return TRUE;
		}
		
		usleep( microsecond_per_millisecond * wait_sync_polling_time_unit_millisecond );

		count++;
	}

	pthread_mutex_lock( &m_sync_manager_mutex );
	sync_manager_set_sync_object_state( sync_obj_index, sync_obj_state_garbage );
	pthread_mutex_unlock( &m_sync_manager_mutex );
	
	log_fatal( "timeout fail, max_sync_timeout_millisecond:[%d], max_polling_count:[%d], wait_sync_polling_time_unit_millisecond:[%d]", 
												m_sync_manager_init_info.max_sync_timeout_millisecond, max_polling_count, wait_sync_polling_time_unit_millisecond );

	return FALSE;
}




