#ifndef BASE_H
#define BASE_H



#include "type.h"



#ifdef __cplusplus
extern "C" {
#endif



//**************************************************************
// public member
//**************************************************************



//**************************************************************
// public function
//**************************************************************
void*	mem_alloc( unsigned int size );
void	mem_free( const void* const ptr );

void log_binary_data( const unsigned char* data, unsigned int data_len );

int check_ascii( const char* str, unsigned int str_len );



#ifdef __cplusplus
}
#endif



#endif

