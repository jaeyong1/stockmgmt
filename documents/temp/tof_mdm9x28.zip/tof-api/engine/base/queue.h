#ifndef QUEUE_H
#define QUEUE_H



#include "type.h"



#ifdef __cplusplus
extern "C" {
#endif



//**************************************************************
// public member
//**************************************************************
#define				default_max_queue_size			( 1024 * 1024 )
#define				max_queue_data_size					( 1024 * 4 )



typedef unsigned int		queue_data_id_type;

#define				max_queue_data_id						( 0xFFFFFFFE )
#define				invalid_queue_data_id				( 0xFFFFFFFF )



//**************************************************************
// public function
//**************************************************************
int	queue_init( const unsigned int max_queue_size );
void	queue_release( void );
int	queue_push( const unsigned char* const data, const unsigned int data_size, queue_data_id_type* queue_data_id );
int	queue_pop( unsigned char* data, unsigned int* data_size, queue_data_id_type* queue_data_id );



#ifdef __cplusplus
}
#endif



#endif
