


#include "log.h"

#include "wms_util.h"



//**************************************************************
// private member
//**************************************************************



//**************************************************************
// public function
//**************************************************************
//from qualcomm source
void wms_ts_ascii_to_bcd
(
  const uint8     * ascii,
  uint8           len,
  uint8           * out
)
{
  uint8   i;

  for( i=0; i<len; i++ )
  {
    switch( ascii[i] )
    {
      case '*':
        out[i] = 0xA;
        break;
      case '#':
        out[i] = 0xB;
        break;
      default:
        out[i] = ascii[i] - '0';
        break;
    }
  }

  /* done */
  return;

} /* wms_ts_ascii_to_bcd() */



boolean wms_ts_bcd_to_int
(
  const uint8 bcd, /*IN*/
  uint8 *result    /*OUT*/
)
{
  if ( (bcd & 0x0F) > 9 || ((bcd & 0xF0) >> 4) > 9)
  {
   	//MSG_ERROR_0("Invalid BCD digit");
    log_error("Invalid BCD digit");
    *result = 0;
    return FALSE;
  }
  else
  {
    *result = ( (bcd & 0x0F) + (((bcd & 0xF0) >> 4) * 10) );
    return TRUE;
  }
}



void wms_ts_bcd_to_ascii
(
  const uint8         * addr,
  uint8               len,
  uint8               * out
)
{
  uint8   i;

  for( i=0; i<len; i++ )
  {
    uint8   digit; /* to store stripped digit */

    digit = addr[i] & 0x0F;

    switch( digit )
    {
      case 0xA:
        out[i] = '*';
        break;
      case 0xB:
        out[i] = '#';
        break;
      case 0xC:
      case 0xD:
      case 0xE:
        out[i] = (digit - 0xC) + 'a';
        break;
      case 0xF:
        /* Ignore it */
        out[i] = ' ';
        break;
      default:
        out[i] = digit + '0';
        break;
    }
  }

  /* done */
  return;

} /* wms_ts_bcd_to_ascii() */


int wms_ts_atoi
(
  unsigned int *val_arg_ptr,      /*  value returned  */
  const unsigned char *s,                        /*  points to string to eval  */
  unsigned int r                        /*  radix */
)
{
  int err_ret = 1; // ATOI_NO_ARG - 1
  unsigned char c;
  unsigned int val, val_lim, dig_lim;

  val = 0;
  val_lim = (unsigned int) (0xFFFFFFFF / r); // MAX_VAL_NUM_ITEM - 0xFFFFFFFF
  dig_lim = (unsigned int) (0xFFFFFFFF % r);

  while ( (c = *s++) != '\0')
  {
    if (c != ' ')
    {
      c = (unsigned char) ( ((c) >= 'a' && (c) <= 'z') ? ((c) - 0x20) : (c) );
      if (c >= '0' && c <= '9')
      {
        c -= '0';
      }
      else if (c >= 'A')
      {
        c -= 'A' - 10;
      }
      else
      {
        err_ret = 2;  /*  char code too small */ // ATOI_OUT_OF_RANGE - 2
        break;
      }

      if (c >= r || val > val_lim
          || (val == val_lim && c > dig_lim))
      {
        err_ret = 2;  /*  char code too large */
        break;
      }
      else
      {
        err_ret = 0;            /*  arg found: OK so far*/ // ATOI_OK - 0
        val = (unsigned int) (val * r + c);
      }
    }
    *val_arg_ptr =  val;
  }
  
  return err_ret;

} /*  dsatutil_atoi */

unsigned char * wms_ts_itoa
(
  unsigned int /* uint32*/ v,         /*  Value to convert to ASCII     */
  unsigned char *s,        /*  Pointer to string for result  */
  unsigned short   r          /*  Conversion radix              */
)
{
  unsigned char buf[33], c;
  int n;

  n = sizeof(buf) - 1;

  buf[n] = '\0';

  do
  {
    c = (unsigned char) (v % r);

    if (n <= 0)
    {
      break;
    }

    buf[--n] = (unsigned char) ( (c > 9) ? c + 'A' - 10 : c + '0');

  } while ( (v /= r) > 0);

  while ( (*s++ = buf[n++]) != 0)
      ;

  return (s-1);
} /*  dsatutil_itoa */

int wms_ts_encode_hex_to_ascii
(
  unsigned char * in_ptr,
  char * out_ptr,
  int len
)
{
  int i;

  if(in_ptr == NULL)
    return FALSE;

  if(len == 0)
    return FALSE;

  for( i = 0; i < len; i ++)
  {
    if(*(in_ptr+i) <16 )
      *out_ptr++ = '0';

    out_ptr = wms_ts_itoa((unsigned int) *(in_ptr+i), (unsigned char *)out_ptr,16);
  }
  *out_ptr = '\0';

  return TRUE;
}

int wms_ts_encode_ascii_to_hex
(
 char  * in_ptr,    /* Pointer to the Hex data (in ASCII format)    */ 
 unsigned char * out_ptr,   /* Pointer to the result buffer(converted data) */
 int     len        /* Length of the input data pointer (Hex data)  */
)
{
  unsigned char * s;
  unsigned char temp_buf[3];
  int i;
  unsigned int num_val;
  int result = 0; // success // DSAT_OK - 0

  s = (unsigned char *)in_ptr;

  len = len * 2;

  while(len > 0)
  {
    for (i=0; (i<2) && (*s != '\0'); i++)
    {
      temp_buf[i] = *s++;
    }
    temp_buf[i] = '\0';
    if ( wms_ts_atoi(&num_val, temp_buf, 16) != 0 ) // ATOI_OK - 0
    {
      /* We got a out of range value */
      result = -1;
    }
    *out_ptr++ = (unsigned char)num_val;
    len -= i;
  }

  return result;
} /* dsatetsismsi_encode_pdu */


unsigned char * wms_ts_scaddr_to_string
( 
 wms_address_s_type addr,  /* Address data structure   */
 unsigned char * res_ptr            /* pointer to result buffer */
)
{
  unsigned char  loop = 0;
  unsigned char  type_of_addr = 0;
  unsigned char  temp = 0;
  unsigned char  f_flag = 0;
  int len;

  f_flag =  addr.number_of_digits & 0x01;

  if ( f_flag )
  {
    /* we have a odd length */
    /* len = (x+1)/2 + 1    */
    if ( addr.number_of_digits != 0 )
    {
      len = ( (addr.number_of_digits + 1)/2 ) + 1;
    }
    else
    {
      len = 0;
    }
  }
  else
  {
    /* we have a even length */
    /* len = x/2 + 1        */
    if ( addr.number_of_digits != 0 )
    {
      len = ( addr.number_of_digits/2 ) + 1;
    }
    else
    {
      len = 0;
    }
  }

  if ( len < 16 )
  {
    /* single digit length. Pad it with a 0 */
    *res_ptr++ = '0';
  }

  res_ptr = wms_ts_itoa( (unsigned int) len, res_ptr, 16 );
  
  if ( addr.number_of_digits )
  {
    temp = (unsigned char )((unsigned int)addr.number_type & 0x07);
    type_of_addr = (unsigned char )((type_of_addr | temp ) << 4);
    temp = (unsigned char )((unsigned int)addr.number_plan & 0x07);
    type_of_addr = type_of_addr | temp ;
    type_of_addr = type_of_addr | 0x80;

    if ( type_of_addr < 16 )
    {
      *res_ptr++ = '0';
    }
    res_ptr = wms_ts_itoa((unsigned int) type_of_addr, res_ptr, 16);

    while( loop < addr.number_of_digits )
    {
      if ( ( loop == ( addr.number_of_digits - 1 ) ) && ( f_flag ) )
      {
        *res_ptr++ = 'F';
        res_ptr = wms_ts_itoa((unsigned int) addr.digits[loop], res_ptr, 16);
      }
      else
      {
        res_ptr = wms_ts_itoa((unsigned int) addr.digits[loop+1], res_ptr, 16);
        res_ptr = wms_ts_itoa((unsigned int) addr.digits[loop], res_ptr, 16);
      }
      loop = loop + 2;
    }
  }
  return res_ptr;
}/* dsatetsismsi_scaddr_to_string */


wms_status_e_type wms_ts_encode_submit
(
  const wms_gw_submit_s_type    *submit,
  wms_raw_ts_data_s_type        *raw_ts_data_ptr
)
{
  wms_status_e_type     st = WMS_OK_S;
  uint8                *data;
  uint8                 pos = 0, i;

  if( submit == NULL || raw_ts_data_ptr == NULL )
  {
    //MSG_ERROR_0("Null pointer");
    log_error("Null pointer");
    return WMS_NULL_PTR_S;
  }

  data = raw_ts_data_ptr->data;

  /* Setting Data to 0 */
  (void)memset(data, 0, WMS_MAX_LEN);

  /* TP-MTI, TP-RD, TP-VPF, TP-SRR, TP_UDHI, TP-RP:
  */
  data[pos] = 0x01; /* SUBMIT: bits 0, 1 */
  data[pos] |= submit->reject_duplicates ? 0x04 : 0; /* bit 2 */

  if ((int)submit->validity.format > 3 )
  {
    return st = WMS_INVALID_VALIDITY_FORMAT_S;
  }
  data[pos] |= (uint8)((uint32)submit->validity.format << 3);           /* bits 3, 4 */

  data[pos] |= submit->status_report_enabled ? 0x20 : 0;    /* bit 5 */
  data[pos] |= submit->user_data_header_present ? 0x40 : 0; /* bit 6 */
  data[pos] |= submit->reply_path_present ? 0x80 : 0;       /* bit 7 */
  pos ++;

  /* TP-MR
  */
  data[pos] = (uint8) submit->message_reference;
  pos ++;

  /* TP-DA
  */
  i = wms_ts_encode_address( & submit->address, & data[pos] );
  if( i==0 )
  {
    return WMS_INVALID_PARM_SIZE_S;
  }
  pos += i;


  /* TP-PID
  */
  data[pos] = (uint8)submit->pid;
  pos ++;

  /* TP-DCS
  */
  pos += wms_ts_encode_dcs( & submit->dcs, data+pos );

  /* TP-VP
  */
  pos += wms_ts_encode_gw_validity( & submit->validity, data+pos );

  /* TP-UDL
  */
  /*data[pos] =(uint8) submit->user_data.sm_len;
    pos ++;*/

  /*TP_UDL is filled in encode_gw_user_data function*/

  /* TP-UD
  */

  if (wms_ts_compute_gw_user_data_length( &submit->dcs, &submit->user_data) > WMS_SMS_UDL_MAX_8_BIT)
  {
    //MSG_ERROR_0("User Data Length has exceeded capacity");
    log_error("User Data Length has exceeded capacity");
    st = WMS_INVALID_USER_DATA_SIZE_S;
  }
  else
  {
    i = wms_ts_encode_gw_user_data( & submit->dcs,
                                    & submit->user_data,
                                      data+pos );
    pos += i;
  }

  raw_ts_data_ptr->tpdu_type  = WMS_TPDU_SUBMIT;
  raw_ts_data_ptr->len        = pos;

  return st;

} /* wms_ts_encode_submit() */



wms_status_e_type wms_ts_decode_deliver
(
  const wms_raw_ts_data_s_type            * raw_ts_data_ptr,
  wms_gw_deliver_s_type                   * deliver,
  uint32                                  * nRawTsLen
)
{
  wms_status_e_type     st = WMS_OK_S;
  uint32                pos = 0, i;
  const uint8           *data = raw_ts_data_ptr->data;

  /* TP-MTI, TP-MMS, TP-SRI, TP-UDHI, TP-RP
  */
  if (raw_ts_data_ptr == NULL || deliver == NULL)
  {
    //MSG_ERROR_0("null pointer in wms_ts_decode_deliver");
    log_error("null pointer in wms_ts_decode_deliver");
    return WMS_NULL_PTR_S;
  }
  /* check bit 0 and bit 1 for TP-MTI for deliver or Reserved type */
  else if ( ((data[pos] & 0x03) != 0x00) && ((data[pos] & 0x03) != 0x03) )
  {
    //MSG_ERROR_1("invalid tpdu type = %d in wms_ts_decode_deliver ", raw_ts_data_ptr->tpdu_type);
    log_error("invalid tpdu type = %d in wms_ts_decode_deliver ", raw_ts_data_ptr->tpdu_type);
    return WMS_INVALID_TPDU_TYPE_S;
  }
  else
  {
    deliver->more                     = (data[pos] & 0x04) ? FALSE : TRUE;
                                        /* bit 2 */
    /* bits 3, 4 are not used */
    deliver->status_report_enabled    = (data[pos] & 0x20) ? TRUE : FALSE;
                                        /* bit 5 */
    deliver->user_data_header_present = (data[pos] & 0x40) ? TRUE : FALSE;
                                        /* bit 6 */
    deliver->reply_path_present       = (data[pos] & 0x80) ? TRUE : FALSE;
                                        /* bit 7 */
    pos ++;

    /* TP-OA
    */
    i = wms_ts_decode_address( & data[pos], & deliver->address);
    if( i==0 )
    {
      //MSG_ERROR_0("invalid param size in wms_ts_decode_deliver");
      log_error("invalid param size in wms_ts_decode_deliver");
      return WMS_INVALID_PARM_SIZE_S;
    }
    pos += i;

    /* TP-PID
    */
    deliver->pid = (wms_pid_e_type) data[pos];
    pos ++;

    /* TP-DCS
    */
    pos += wms_ts_decode_dcs( data+pos, & deliver->dcs );

    if (deliver->dcs.msg_waiting_kind != WMS_GW_MSG_WAITING_VOICEMAIL)
    {
      if (deliver->pid == WMS_PID_RETURN_CALL)
      {
        deliver->dcs.msg_waiting        = WMS_GW_MSG_WAITING_STORE;
        deliver->dcs.msg_waiting_active = TRUE;
        deliver->dcs.msg_waiting_kind   = WMS_GW_MSG_WAITING_VOICEMAIL;
      }
    }

    /* TP-SCTS
    */
    i = wms_ts_decode_timestamp( data+pos, & deliver->timestamp );
    if ( i==0 )
    {
      //MSG_ERROR_0("invalid param value in wms_ts_decode_deliver");
      log_error("invalid param value in wms_ts_decode_deliver");
      return WMS_INVALID_PARM_VALUE_S;
    }
    pos += i;


    /* TP-UDL
    */
  //  deliver->user_data_len = data[pos];
    pos ++;

    /* TP-UD
    */
    i = wms_ts_decode_gw_user_data( & deliver->dcs,
                                         data[pos-1],
                                         data+pos,
                                         deliver->user_data_header_present,
                                       & deliver->user_data );

    if (i > WMS_SMS_UDL_MAX_8_BIT)
    {
      //MSG_ERROR_1("User Data Length has exceeded capacity: UDL = %d", i);
      log_error("User Data Length has exceeded capacity: UDL = %d", i);
      st = WMS_INVALID_USER_DATA_SIZE_S;
    }

    pos += i;

    if (NULL != nRawTsLen)
    {
      *nRawTsLen = pos;
    }

    return st;
  }
} /* wms_ts_decode_deliver() */



//**************************************************************
// private function
//**************************************************************



//from qualcomm source
uint8 wms_ts_get_udh_length
(
  const wms_udh_s_type                    *udh
)
{
  uint8 length = 0;
  if (udh != NULL)
  {
    switch(udh->header_id)
    {
      /* 0x00 */
      case WMS_UDH_CONCAT_8:
        /* Header ID Octet + Header Length Octet + Header Length */
        length = 1 + 1 + WMS_UDH_OCTETS_CONCAT8;
        break;

      /* 0x08 */
      case WMS_UDH_CONCAT_16:
        /* Header ID Octet + Header Length Octet + Header Length */
        length = 1 + 1 + WMS_UDH_OCTETS_CONCAT16;
        break;

      /* 0x01 */
      case WMS_UDH_SPECIAL_SM:
        /* Header ID Octet + Header Length Octet + Header Length */
        length = 1 + 1 + WMS_UDH_OCTETS_SPECIAL_SM;
        break;

      /* 0x02 - 0x03 Reserved */

      /* 0x04 */
      case WMS_UDH_PORT_8:
        /* Header ID Octet + Header Length Octet + Header Length */
        length = 1 + 1 + WMS_UDH_OCTETS_PORT8;
        break;

      /* 0x05 */
      case WMS_UDH_PORT_16:
        /* Header ID Octet + Header Length Octet + Header Length */
        length = 1 + 1 + WMS_UDH_OCTETS_PORT16;
        break;

      /* 0x06 */
      case WMS_UDH_SMSC_CONTROL:
        /* Header ID Octet + Header Length Octet + Header Length */
        length = 1 + 1 + udh->u.other.header_length;
        break;

      /* 0x07 */
      case WMS_UDH_SOURCE:
        /* Header ID Octet + Header Length Octet + Header Length */
        length = 1 + 1 + udh->u.other.header_length;
        break;

      /* 0x09 */
      case WMS_UDH_WCMP:
        /* Header ID Octet + Header Length Octet + Header Length */
        length = 1 + 1 + udh->u.other.header_length;
        break;

      /* 0x0A */
      case WMS_UDH_TEXT_FORMATING:
        /* Header ID Octet + Header Length Octet + Header Length */
        if(!udh->u.text_formating.is_color_present) {
          length = 1 + 1 + WMS_UDH_OCTETS_TEXT_FORMATTING;
        }
        else {
          /* Header ID Octet + Header Length Octet + Header Length + text color octet */
          length = 1 + 1 + WMS_UDH_OCTETS_TEXT_FORMATTING + 1;
        }
        break;

      /* 0x0B */
      case WMS_UDH_PRE_DEF_SOUND:
        /* Header ID Octet + Header Length Octet + Header Length */
        length = 1 + 1 + WMS_UDH_OCTETS_PRE_DEF;
        break;

      /* 0x0C */
      case WMS_UDH_USER_DEF_SOUND:
        /* Header ID Octet + Header Length Octet + Header Length + 1 (for position octet)*/
        length = 1 + 1 + udh->u.user_def_sound.data_length + 1;
        break;

      /* 0x0D */
      case WMS_UDH_PRE_DEF_ANIM:
        /* Header ID Octet + Header Length Octet + Header Length */
        length = 1 + 1 + WMS_UDH_OCTETS_PRE_DEF;
        break;

      /* 0x0E */
      case WMS_UDH_LARGE_ANIM:
        /* Header ID Octet + Header Length Octet + Header Length + 1 (for position octet)*/
        length = 1 + 1 + WMS_UDH_LARGE_BITMAP_SIZE * WMS_UDH_ANIM_NUM_BITMAPS + 1;
        break;

      /* 0x0F */
      case WMS_UDH_SMALL_ANIM:
        /* Header ID Octet + Header Length Octet + Header Length + 1 (for position octet)*/
        length = 1 + 1 + WMS_UDH_SMALL_BITMAP_SIZE * WMS_UDH_ANIM_NUM_BITMAPS + 1;
        break;

      /* 0x10 */
      case WMS_UDH_LARGE_PICTURE:
        /* Header ID Octet + Header Length Octet + Header Length + 1 (for position octet)*/
        length = 1 + 1 + WMS_UDH_LARGE_PIC_SIZE + 1;
        break;

      /* 0x11 */
      case WMS_UDH_SMALL_PICTURE:
        /* Header ID Octet + Header Length Octet + Header Length + 1 (for position octet)*/
        length = 1 + 1 + WMS_UDH_SMALL_PIC_SIZE + 1;
        break;

      /* 0x12 */
      case WMS_UDH_VAR_PICTURE:
        /* Header ID Octet + Header Length Octet + Header Length + 3 (for height, width and position octets)*/
        length = 1 + 1 + (uint8)(udh->u.var_picture.height * udh->u.var_picture.width/8) + 3;
        break;

      /* 0x13 - 0x1F Reserved for future EMS*/

      /* 0x20 */
      case WMS_UDH_RFC822:
        /* Header ID Octet + Header Length Octet + Header Length*/
        length = 1 + 1 + WMS_UDH_OCTETS_RFC822;
        break;

      /* 0x24 */
      case WMS_UDH_NAT_LANG_SS:
        /* Header ID Octet + Header Length Octet + Header Length*/
        length = 1 + 1 + WMS_UDH_OCTETS_NAT_LANG_SS;
        break;

      /* 0x25 */
      case WMS_UDH_NAT_LANG_LS:
        /* Header ID Octet + Header Length Octet + Header Length*/
        length = 1 + 1 + WMS_UDH_OCTETS_NAT_LANG_LS;
        break;

     /*  0x21 - 0x23 and 0x26 - 0x6F Reserved for future use*/
     /*  0x70 - 0x7f Reserved for (U)SIM Toolkit Security Headers */
     /*  0x80 - 0x9F SME to SME specific use*/
     /*  0xA0 - 0xBF Reserved for future use*/
     /*  0xC0 - 0xDF SC specific use*/
     /*  0xE0 - 0xFF Reserved for future use*/

      case WMS_UDH_USER_PROMPT:
        length = 1 + 1 + WMS_UDH_OCTETS_USER_PROMPT;
        break;

      case WMS_UDH_EXTENDED_OBJECT:
        length = 1 + 1 + udh->u.eo.content.length;
        if( udh->u.eo.first_segment == TRUE )
        {
          length += WMS_UDH_OCTETS_EO_HEADER;
        }
        break;

      default:
        /* Header ID Octet + Header Length Octet + Header Length */
        length = 1 + 1 + udh->u.other.header_length;
        break;

    }
  }
  return length;
}



uint32 wms_ts_compute_user_data_header_length
(
  const uint8           num_headers,
  const wms_udh_s_type *headers
)
{
  uint32 length = 0;
  uint32 i;

  if( headers == NULL )
  {
    //MSG_ERROR_0("Null pointer");
    log_error("Null pointer");
    return 0;
  }

  if (num_headers > 0)
  {
    length += 1; /* 1 byte for UDHL byte */

    /* User Data Headers Length */
    for ( i=0 ; i<num_headers && i<WMS_MAX_UD_HEADERS ; i++)
    {
      length += (uint32)wms_ts_get_udh_length(&headers[i]);
    }
  }

  return length;
}



uint8 wms_ts_encode_evp_rel_time
(
  const wms_timestamp_s_type *vp,
  uint8                      *data
)
{
  uint8 pos = 0, j;

  if (data == NULL || vp == NULL)
  {
    //MSG_ERROR_0("null pointer in wms_ts_encode_evp_rel_time");
    log_error("null pointer in wms_ts_encode_evp_rel_time");
    return 0;
  }

  /* hour check */
  if ( wms_ts_bcd_to_int(vp->hour, &j) )
  {
    if (j > 23)
    {
      //MSG_ERROR_1("Hour is invalid: %d", j);
      log_error("Hour is invalid: %d", j);
      return 0;
    }
  }
  else
  {
    return 0;
  }
  data[pos++] = ((vp->hour & 0x0F) << 4) + ((vp->hour & 0xF0) >> 4);

  /* minute check */
  if ( wms_ts_bcd_to_int(vp->minute, &j) )
  {
    if (j > 59)
    {
      //MSG_ERROR_1("Minute is invalid: %d", j);
      log_error("Minute is invalid: %d", j);
      return 0;
    }
  }
  else
  {
    return 0;
  }
  data[pos++] = ((vp->minute & 0x0F) << 4) + ((vp->minute & 0xF0) >> 4);

  /* second check */
  if ( wms_ts_bcd_to_int(vp->second, &j) )
  {
    if (j > 59)
    {
      //MSG_ERROR_1("Second is invalid: %d", j);
      log_error("Second is invalid: %d", j);
      return 0;
    }
  }
  else
  {
    return 0;
  }
  data[pos++] = ((vp->second & 0x0F) << 4) + ((vp->second & 0xF0) >> 4);

  return pos;
}/* wms_ts_encode_evp_rel_time */



uint8 wms_ts_encode_enhanced_vp
(
  const wms_enhanced_vp_s_type    *enhanced_vp, /* IN */
  uint8                           *data     /* OUT */
)
{
  uint8 pos = 0;
  uint8 i = 0;
  uint8 j = 0;

  if( NULL == enhanced_vp || NULL == data )
  {
    //MSG_ERROR_0("wms_ts_encode_enhanced_vp NULL pointer");
    log_error("wms_ts_encode_enhanced_vp NULL pointer");
    return 0;
  }
  memset(data, 0, WMS_ENHANCED_VP_OCTETS);

  data[pos]  = enhanced_vp->with_extension ? 0x80 : 0;
  data[pos] |= enhanced_vp->single_shot ? 0x40 : 0;
  data[pos] |= (uint8)((int)enhanced_vp->vp_format & 0x07);

  pos ++;

  if( TRUE == enhanced_vp->with_extension )
  {
    data[pos++] = enhanced_vp->extension;
  }
  switch( enhanced_vp->vp_format )
  {
    case WMS_ENHANCED_VP_NONE:
      break;

    case WMS_ENHANCED_VP_RELATIVE:
      data[pos] = wms_ts_encode_relative_time(&(enhanced_vp->time));
      pos++;
      break;

    case WMS_ENHANCED_VP_RELATIVE_INT:
      if( !wms_ts_bcd_to_int(enhanced_vp->time.minute, &j ))
      {
        //MSG_ERROR_0("Minute is invalid");
        log_error("Minute is invalid");
      }
      data[pos] = (uint8)(j * 60);
      if( !wms_ts_bcd_to_int(enhanced_vp->time.second, &j ))
      {
        //MSG_ERROR_0("Second is invalid");
        log_error("Second is invalid");
      }
      data[pos] += j;

      /* Validity period is relative in integer representation and the
        following octet contains the TP-VP value in the range 0 to 255
        representing 0 to 255 seconds. A TP-VP value of zero is
        undefined and reserved for future use.
        */
      pos++;
      break;

    case WMS_ENHANCED_VP_SEMI_OCTET:
      i = wms_ts_encode_evp_rel_time(&enhanced_vp->time, data+pos);
      if( i == 0 )
      {
        //MSG_ERROR_0("Error while encoding Enhanced VP relative time");
        log_error("Error while encoding Enhanced VP relative time");
      }
      pos += i;
      break;

    default:
      break;
  }

  return WMS_ENHANCED_VP_OCTETS;
}/* wms_ts_encode_enhanced_vp */



uint8 wms_ts_encode_timestamp
(
  const wms_timestamp_s_type      *timestamp, /* IN */
  uint8                           *data     /* OUT */
)
{
  sint7     i;
  uint8     pos = 0, j;

  if (data == NULL || timestamp == NULL)
  {
    //MSG_ERROR_0("null pointer in wms_ts_encode_timestamp");
    log_error("null pointer in wms_ts_encode_timestamp");
    return 0;
  }

  /* year check */
  if ( !wms_ts_bcd_to_int(timestamp->year, &j) )
  {
    return 0;
  }
  data[pos] = ((timestamp->year & 0x0F) << 4) + ((timestamp->year& 0xF0) >> 4);
  pos ++;

  /* month check */
  if ( wms_ts_bcd_to_int(timestamp->month, &j) )
  {
    if (j > 12 || j < 1)
    {
      //MSG_ERROR_1("Month is invalid: %d", j);
      log_error("Month is invalid: %d", j);
      return 0;
    }
  }
  else
  {
    return 0;
  }
  data[pos] = ((timestamp->month & 0x0F) << 4) + ((timestamp->month & 0xF0) >> 4);
  pos ++;

  /* day check */
  if ( wms_ts_bcd_to_int(timestamp->day, &j) )
  {
    if (j > 31 || j < 1)
    {
      //MSG_ERROR_1("Day is invalid: %d", j);
      log_error("Day is invalid: %d", j);
      return 0;
    }
  }
  else
  {
    return 0;
  }
  data[pos] = ((timestamp->day & 0x0F) << 4) + ((timestamp->day & 0xF0) >> 4);
  pos ++;

  /* hour check */
  if ( wms_ts_bcd_to_int(timestamp->hour, &j) )
  {
    if (j > 23)
    {
      //MSG_ERROR_1("Hour is invalid: %d", j);
      log_error("Hour is invalid: %d", j);
      return 0;
    }
  }
  else
  {
    return 0;
  }
  data[pos] = ((timestamp->hour & 0x0F) << 4) + ((timestamp->hour & 0xF0) >> 4);
  pos ++;

  /* minute check */
  if ( wms_ts_bcd_to_int(timestamp->minute, &j) )
  {
    if (j > 59)
    {
      //MSG_ERROR_1("Minute is invalid: %d", j);
      log_error("Minute is invalid: %d", j);
      return 0;
    }
  }
  else
  {
    return 0;
  }
  data[pos] = ((timestamp->minute & 0x0F) << 4) + ((timestamp->minute & 0xF0) >> 4);
  pos ++;

  /* second check */
  if ( wms_ts_bcd_to_int(timestamp->second, &j) )
  {
    if (j > 59)
    {
      //MSG_ERROR_1("Second is invalid: %d", j);
      log_error("Second is invalid: %d", j);
      return 0;
    }
  }
  else
  {
    return 0;
  }
  data[pos] = ((timestamp->second & 0x0F) << 4) + ((timestamp->second & 0xF0) >> 4);
  pos ++;

  /* timezone check */
  i = (sint7)timestamp->timezone;
  // Valid range of timezone is from -12 to +14 hours
  if (i > 56 || i < -48)
  {
    //MSG_ERROR_1("Timezone is out of bound: %d", (uint32) i);
    log_error("Timezone is out of bound: %d", (uint32) i);
    return 0;
  }

  if (i >= 0)
  {
    data[pos] = (uint8) (((uint8)( i % 10 )) << 4);
    data[pos] |= ( i / 10 );
  }
  else
  {
    i *= (-1);
    data[pos] = (uint8) (((uint8)( i % 10 )) << 4);
    data[pos] |= ( i / 10 );
    data[pos] |= 0x08;
  }
  pos ++;

  return pos;

} /* wms_ts_encode_timestamp() */



uint8 wms_ts_encode_relative_time
(
  const wms_timestamp_s_type  *timestamp
)
{
  uint32    i;
  uint8     v = 0, j;
  /* round up to the next time unit boundary*/

  if (timestamp != NULL)
  {
    //wms_ts_init();
    //qc_enter_crit_sect(&encode_decode_data_crit_sect);

    if ( !wms_ts_bcd_to_int(timestamp->year, &j) )
    {
    	//MSG_ERROR_1("Year is invalid: %d", j);
      log_error("Year is invalid: %d", j);
    }
    i = j * 365;

    if ( !wms_ts_bcd_to_int(timestamp->month, &j) )
    {
      //MSG_ERROR_1("Month is invalid: %d", j);
      log_error("Month is invalid: %d", j);
    }
    i = i + j * 30;

    if ( !wms_ts_bcd_to_int(timestamp->day, &j) )
    {
      //MSG_ERROR_1("Day is invalid: %d", j);
      log_error("Day is invalid: %d", j);
    }
    i += j;

    if( i > 30 )
    {
      /* 197 - 255: (TP-VP - 192) weeks */
      v = (uint8) ( (i+6) / 7 + 192 );
    }
    else if( i >= 1 )
    {
      /* 168 to 196: (TP-VP - 166 ) days */
      v = (uint8) ( i + 166 );
    }
    else
    {
      if ( !wms_ts_bcd_to_int(timestamp->day, &j) )
      {
        //MSG_ERROR_1("Day is invalid: %d", j);
        log_error("Day is invalid: %d", j);
      }
      i = j * 24 * 60;

      if ( !wms_ts_bcd_to_int(timestamp->hour, &j) )
      {
        //MSG_ERROR_1("Hour is invalid: %d", j);
        log_error("Hour is invalid: %d", j);
      }
      i = i + j * 60;

      if ( !wms_ts_bcd_to_int(timestamp->minute, &j) )
      {
        //MSG_ERROR_1("Minute is invalid: %d", j);
        log_error("Minute is invalid: %d", j);
      }
      i += j;

      if( i > 12 * 60 ) /* greater than 12 hours */
      {
        /* 144 - 167: 12 hours + ( (TP-VP - 143) * 30 minutes ) */
        v = (uint8) (((i - 12 * 60) + 29) / 30 + 143);
      }
      else
      {
        /* 0 - 143: (TP-VP + 1) * 5 minutes */
        v = (uint8) ( ( i + 4 ) / 5 - 1 );
      }
    }
    //qc_leave_crit_sect(&encode_decode_data_crit_sect);
  }
  else
  {
    //MSG_ERROR_0("null pointer in wms_ts_encode_relative_time");
    log_error("null pointer in wms_ts_encode_relative_time");
  }
  /* done */
  return v;

} /* wms_ts_encode_relative_time() */



uint8 wms_ts_encode_address
(
  const wms_address_s_type    * addr,
  uint8                       * data
)
{
  uint8   i, pos = 0;

  if( NULL == addr || NULL == data )
  {
    //MSG_ERROR_0("NULL pointer");
    log_error("NULL pointer");
    return 0;
  }

  /* Spec TS 23.040 Section 9.1.2.5 and 9.2.3.8 specify that the maximum length of the
     full address field (Address Length, Type of Address and Address Value) is 12 octets.
     The length of the destination address should be between 3 to 12 octets (20 semi-octets).
  */
  if( addr->number_of_digits > WMS_GW_ADDRESS_MAX )
  {
    //MSG_ERROR_1("Addr len too long: %d", addr->number_of_digits);
    log_error("Addr len too long: %d", addr->number_of_digits);
    return 0;
  }

  if (addr->number_type == WMS_NUMBER_ALPHANUMERIC )
  {
    data[pos] = (uint8)((addr->number_of_digits*7 + 3)/4);
  }
  else
  {
    /* Len field: */
    data[pos] = addr->number_of_digits;
  }
  pos ++;

  /* TON & NPI: */
  data[pos] = 0x80;
  data[pos] |= (uint8) ((uint8) addr->number_type << 4);
  data[pos] |= (uint8) addr->number_plan;
  pos ++;

  if (addr->number_type == WMS_NUMBER_ALPHANUMERIC )
  {
    /* Alphanumberic Number Type */
    pos += (uint8)wms_ts_pack_gw_7_bit_chars
              (
                addr->digits,
                addr->number_of_digits,
                0,
                WMS_GW_ADDRESS_MAX,
                &data[pos]
              );
  }
  else
  {
    /* the digits: */
    for( i=0; i<addr->number_of_digits; i++ )
    {
      /* pack two digits each time */
      data[pos]  = (uint8) (addr->digits[i++] & 0x0F);

      if( i == addr->number_of_digits )
      {
        data[pos] |= 0xF0;
      }
      else
      {
        data[pos] |= (uint8)(addr->digits[i] << 4);
      }
      pos ++;
    }
  }
  /* done */
  return pos;
} /* wms_ts_encode_address() */



uint8 wms_ts_encode_dcs
(
  const wms_gw_dcs_s_type   *dcs,  /* IN */
  uint8                     *data  /* OUT */
)
{
  uint8 pos = 0;
//#ifdef FEATURE_GWSMS
  //wms_ts_init();
  //qc_enter_crit_sect(&encode_decode_data_crit_sect);

  /* TP-DCS is defined in spec 3GPP TS 23.038, section 4. */
  if( dcs->msg_waiting == WMS_GW_MSG_WAITING_NONE )
  {
    /* Using the pattern 00xx xxxx */

    /* bit 5 */
    data[pos] = dcs->is_compressed ? 0x20 : 0;

    /* bit 4 */
    data[pos] |= (dcs->msg_class != WMS_MESSAGE_CLASS_NONE ) ? 0x10 : 0;

    /* bits 3-2 */
    data[pos] |= (uint8)((int)dcs->alphabet << 2);

    /* bits 1-0 */
    data[pos] |= (uint8)((int)dcs->msg_class & 0x03);
  }
  else if (dcs->msg_waiting == WMS_GW_MSG_WAITING_NONE_1111)
  {
    /* Using the pattern 1111 xxxx */

    data[pos] = 0xf0;

    /*bit 2*/
    if (dcs->alphabet == WMS_GW_ALPHABET_8_BIT)
      data[pos] |= 0x04;


    /* bits 1-0 */
    data[pos] |= (int)dcs->msg_class & 0x03;
  }
  else
  {
    /* bits 7-4 */
    if( dcs->msg_waiting == WMS_GW_MSG_WAITING_DISCARD )
    {
      data[pos] = 0xc0;
    }
    else if( dcs->msg_waiting == WMS_GW_MSG_WAITING_STORE &&
             dcs->alphabet    == WMS_GW_ALPHABET_7_BIT_DEFAULT )
    {
      data[pos] = 0xd0;
    }
    else
    {
      data[pos] = 0xe0;
    }

    /* bit 3 */
    data[pos] |= ( dcs->msg_waiting_active == TRUE ) ? 0x08 : 0;

    /* bit 2 is reserved, set to 0 */

    /* bits 1-0 */
    data[pos] |= (int)dcs->msg_waiting_kind & 0x03;
  }

  pos ++;

  //qc_leave_crit_sect(&encode_decode_data_crit_sect);
//#endif /* FEATURE_GWSMS */
  return pos;
} /* wms_ts_encode_dcs() */



uint8 wms_ts_encode_gw_validity
(
  const wms_gw_validity_s_type      *validity,
  uint8                               *data
)
{
  uint8 i, pos = 0;

  if( NULL == validity || NULL == data )
  {
    //MSG_ERROR_0("wms_gs_encode_gw_validity NULL pointer");
    log_error("wms_gs_encode_gw_validity NULL pointer");
    return 0;
  }
  switch( validity->format )
  {
    case WMS_GW_VALIDITY_NONE:
      break;

    case WMS_GW_VALIDITY_RELATIVE:
      data[pos] = wms_ts_encode_relative_time( & validity->u.time );
      pos ++;
      break;

    case WMS_GW_VALIDITY_ABSOLUTE:
      i = wms_ts_encode_timestamp( & validity->u.time, data+pos );
      if( i == 0 )
      {
        //MSG_ERROR_0("Error while Decoding Absolute Validity Timestamp");
        log_error("Error while Decoding Absolute Validity Timestamp");
      }
      pos += i;
      break;

    case WMS_GW_VALIDITY_ENHANCED:
      i = wms_ts_encode_enhanced_vp(& validity->u.enhanced_vp, data+pos);
      if(  i == 0 )
      {
        //MSG_ERROR_0("Error while Encoding Enhanced Validity Period");
        log_error("Error while Encoding Enhanced Validity Period");
      }
      pos += i;
      break;

    default:
      break;
  } /* switch */

  return pos;

} /* wms_ts_encode_gw_validity() */



uint32 wms_ts_compute_gw_user_data_length
(
  const wms_gw_dcs_s_type         *dcs,
  const wms_gw_user_data_s_type   *user_data
)
{
  uint32 length = 0;

  if( dcs == NULL || user_data == NULL )
  {
    //MSG_ERROR_0("Null pointer");
    log_error("Null pointer");
    return 0;
  }

  length += wms_ts_compute_user_data_header_length(user_data->num_headers, user_data->headers);

  if( dcs->alphabet == WMS_GW_ALPHABET_7_BIT_DEFAULT )
  {
    length += ((user_data->sm_len * 7) + 7)/8;
  }
  else
  {
    length += user_data->sm_len;
  }

  return length;

} /* wms_ts_compute_gw_user_data_length */



/*static*/ int wms_ts_encode_udh_concat_8
(
  const wms_udh_s_type *const_header,
  uint8 *udh
)
{
  int pos =0;

  if ( const_header->u.concat_8.total_sm == 0 ||
       const_header->u.concat_8.seq_num  == 0 ||
       const_header->u.concat_8.seq_num > const_header->u.concat_8.total_sm)

  {
    //MSG_ERROR_1("SMS UDH Header id %d Present with no Data", const_header->header_id);
    log_error("SMS UDH Header id %d Present with no Data", const_header->header_id);
    return 0;
  }


  udh[pos++] = (uint8) WMS_UDH_CONCAT_8;
  udh[pos++] = (uint8) WMS_UDH_OCTETS_CONCAT8;
  udh[pos++] = const_header->u.concat_8.msg_ref;
  udh[pos++] = const_header->u.concat_8.total_sm;
  udh[pos++] = const_header->u.concat_8.seq_num;

  return pos;
}/*wms_ts_encode_udh_concat_8*/



/*static*/ int wms_ts_encode_udh_concat16
(
  const wms_udh_s_type *const_header,
  uint8 *udh
)
{
  int pos=0;

  if (const_header->u.concat_16.total_sm == 0 ||
      const_header->u.concat_16.seq_num == 0 ||
      const_header->u.concat_16.seq_num > const_header->u.concat_16.total_sm)
  {
    //MSG_ERROR_1("SMS UDH Header id %d Present with no Data", const_header->header_id);
    log_error("SMS UDH Header id %d Present with no Data", const_header->header_id);
    return 0;
  }

  udh[pos++] = (uint8) WMS_UDH_CONCAT_16;
  udh[pos++] = (uint8) WMS_UDH_OCTETS_CONCAT16;
  udh[pos++] = (uint8)((const_header->u.concat_16.msg_ref & 0xFF00) >> 8);
  udh[pos++] = (uint8)(const_header->u.concat_16.msg_ref & 0x00FF);
  udh[pos++] = const_header->u.concat_16.total_sm;
  udh[pos++] = const_header->u.concat_16.seq_num;

  return pos;
}/*wms_ts_encode_udh_concat16*/



int wms_ts_encode_udh_special_sm
(
  const wms_udh_s_type *const_header,
  uint8 *udh
)
{
  int pos=0;
  udh[pos++] = (uint8) WMS_UDH_SPECIAL_SM;
  udh[pos++] = (uint8) WMS_UDH_OCTETS_SPECIAL_SM;

  /* store or discard the message */
  udh[pos] = (const_header->u.special_sm.msg_waiting == WMS_GW_MSG_WAITING_STORE) ? 0x80 : 0;
  if( const_header->u.special_sm.msg_waiting_kind == WMS_GW_MSG_WAITING_VIDEOMAIL )
  {
    udh[pos] |= WMS_SP_EXTD_VIDEOMAIL_MSG_WAITING_TYPE;
  }
  else
  {
    udh[pos] |= (uint8) const_header->u.special_sm.msg_waiting_kind;
  }
  pos++;
  udh[pos++] = const_header->u.special_sm.message_count;

  return pos;
}/*wms_ts_encode_udh_special_sm*/



/*static*/ int wms_ts_encode_udh_port_8
(
  const wms_udh_s_type *const_header,
  uint8 *udh
)
{
  int pos =0;

  udh[pos++] = (uint8) WMS_UDH_PORT_8;
  udh[pos++] = WMS_UDH_OCTETS_PORT8;
  udh[pos++] = const_header->u.wap_8.dest_port;
  udh[pos++] = const_header->u.wap_8.orig_port;

  return pos;
}/*wms_ts_encode_udh_port_8*/



/*static*/ int wms_ts_encode_udh_port16
(
  const wms_udh_s_type *const_header,
  uint8 *udh
)
{
  int pos =0;

  udh[pos++] = (uint8) WMS_UDH_PORT_16;
  udh[pos++] = (uint8) WMS_UDH_OCTETS_PORT16;
  udh[pos++] = (uint8)((const_header->u.wap_16.dest_port & 0xFF00) >> 8);
  udh[pos++] = (uint8)(const_header->u.wap_16.dest_port & 0x00FF);
  udh[pos++] = (uint8)((const_header->u.wap_16.orig_port & 0xFF00) >> 8);
  udh[pos++] = (uint8)(const_header->u.wap_16.orig_port & 0x00FF);

  return pos;

}/*wms_ts_encode_udh_port16*/



int wms_ts_encode_udh_text_formatting
(
  const wms_udh_s_type *const_header,
  uint8 *udh
)
{
  int pos=0;

  udh[pos++] = (uint8) WMS_UDH_TEXT_FORMATING;

  if(const_header->u.text_formating.is_color_present)
  {
    udh[pos++] = (uint8) WMS_UDH_OCTETS_TEXT_FORMATTING + 1;
  }
  else
  {
    udh[pos++] = (uint8) WMS_UDH_OCTETS_TEXT_FORMATTING;
  }

  udh[pos++] = const_header->u.text_formating.start_position;
  udh[pos++] = const_header->u.text_formating.text_formatting_length;
  udh[pos]   = (uint8) const_header->u.text_formating.alignment_type;
  /*bit 1 and  bit 0*/
  udh[pos]   = (uint8) (((uint8)const_header->u.text_formating.font_size <<2) | udh[pos]);
  /*bit 3 and  bit 2*/
  udh[pos]   = (uint8)(const_header->u.text_formating.style_bold <<4)         | udh[pos];
  /*bit 4 */
  udh[pos]   = (uint8)(const_header->u.text_formating.style_italic <<5)       | udh[pos];
  /*bit 5 */
  udh[pos]   = (uint8)(const_header->u.text_formating.style_underlined<<6)    | udh[pos];
  /*bit 6 */
  udh[pos]   = (uint8)(const_header->u.text_formating.style_strikethrough<<7) | udh[pos];
  pos++;
  /*bit 7 */

  if(const_header->u.text_formating.is_color_present)
  {
    udh[pos] = 0;
    udh[pos] = (uint8) (const_header->u.text_formating.text_color_foreground)| udh[pos];
    /* bit 0-3 */
    udh[pos] = (uint8) ((uint8) const_header->u.text_formating.text_color_background<<4 | udh[pos]);
    /* bit 4-7 */
    pos++;
  }



  return pos;
}/*wms_ts_encode_udh_text_formatting*/



int wms_ts_encode_udh_pre_def_sound
(
  const wms_udh_s_type *const_header,
  uint8 *udh
)
{
  int pos=0;

  udh[pos++] = (uint8) WMS_UDH_PRE_DEF_SOUND;
  udh[pos++] = (uint8) WMS_UDH_OCTETS_PRE_DEF;
  udh[pos++] = const_header->u.pre_def_sound.position;
  udh[pos++] = const_header->u.pre_def_sound.snd_number;

  return pos;
}/*wms_ts_encode_udh_pre_def_sound*/



int wms_ts_encode_udh_user_def_sound
(
  const wms_udh_s_type *const_header,
  uint8 *udh
)
{
  int pos=0, j;

  if (const_header->u.user_def_sound.data_length == 0)
  {
     //MSG_ERROR_1("SMS UDH Header id %d Present with no Data", const_header->header_id);
     log_error("SMS UDH Header id %d Present with no Data", const_header->header_id);
  }


  udh[pos++] = (uint8) WMS_UDH_USER_DEF_SOUND;
  udh[pos++] = const_header->u.user_def_sound.data_length+1;
  udh[pos++] = const_header->u.user_def_sound.position;

  for (j=0;j<const_header->u.user_def_sound.data_length && j < WMS_UDH_MAX_SND_SIZE;j++)
      udh[pos++] = const_header->u.user_def_sound.user_def_sound[j];

  return pos;
}/*wms_ts_encode_udh_user_def_sound*/



int wms_ts_encode_udh_pre_def_anim
(
  const wms_udh_s_type *const_header,
  uint8 *udh
)
{
  int pos=0;

  udh[pos++] = (uint8) WMS_UDH_PRE_DEF_ANIM;
  udh[pos++] = (uint8) WMS_UDH_OCTETS_PRE_DEF;
  udh[pos++] = const_header->u.pre_def_anim.position;
  udh[pos++] = const_header->u.pre_def_anim.animation_number;

  return pos;
}/*wms_ts_encode_udh_pre_def_anim*/



int wms_ts_encode_udh_large_anim
(
  const wms_udh_s_type *const_header,
  uint8 *udh
)
{
  int pos=0, j, k;

  udh[pos++] = (uint8) WMS_UDH_LARGE_ANIM;
  udh[pos++] = (uint8) WMS_UDH_LARGE_BITMAP_SIZE * (uint8) WMS_UDH_ANIM_NUM_BITMAPS  + 1;
  udh[pos++] = const_header->u.large_anim.position;

  for (j=0;j<WMS_UDH_ANIM_NUM_BITMAPS;j++)
    for (k=0;k<WMS_UDH_LARGE_BITMAP_SIZE;k++)
      udh[pos++] = const_header->u.large_anim.data[j][k];

  return pos;
}/*wms_ts_encode_udh_large_anim*/



int wms_ts_encode_udh_small_anim
(
  const wms_udh_s_type *const_header,
  uint8 *udh
)
{
  int pos=0, j, k;

  udh[pos++] = (uint8) WMS_UDH_SMALL_ANIM;
  udh[pos++] = (uint8) (WMS_UDH_SMALL_BITMAP_SIZE * WMS_UDH_ANIM_NUM_BITMAPS) + 1;
  udh[pos++] = const_header->u.small_anim.position;


  for (j=0;j<WMS_UDH_ANIM_NUM_BITMAPS;j++)
    for (k=0;k<WMS_UDH_SMALL_BITMAP_SIZE;k++)
      udh[pos++] = const_header->u.small_anim.data[j][k];

  return pos;
}/*wms_ts_encode_udh_small_anim*/



int wms_ts_encode_udh_large_picture
(
  const wms_udh_s_type *const_header,
  uint8 *udh
)
{
  int pos=0, j;

  udh[pos++] = (uint8) WMS_UDH_LARGE_PICTURE;
  udh[pos++] = (uint8) WMS_UDH_LARGE_PIC_SIZE +1;
  udh[pos++] = const_header->u.large_picture.position;

  for (j=0;j<WMS_UDH_LARGE_PIC_SIZE;j++)
    udh[pos++] = const_header->u.large_picture.data[j];

  return pos;
}/*wms_ts_encode_udh_large_picture*/



int wms_ts_encode_udh_small_picture
(
  const wms_udh_s_type *const_header,
  uint8 *udh
)
{
  int pos=0, j;

  udh[pos++] = (uint8) WMS_UDH_SMALL_PICTURE;
  udh[pos++] = (uint8) WMS_UDH_SMALL_PIC_SIZE +1;
  udh[pos++] = const_header->u.small_picture.position;

  for (j=0;j<WMS_UDH_SMALL_PIC_SIZE;j++)
    udh[pos++] = const_header->u.small_picture.data[j];

  return pos;
}/*wms_ts_encode_udh_small_picture*/



int wms_ts_encode_udh_var_picture
(
  const wms_udh_s_type *const_header,
  uint8 *udh
)
{
  int pos=0, j;

  udh[pos++] = (uint8) WMS_UDH_VAR_PICTURE;
  udh[pos++] = (uint8)((const_header->u.var_picture.height * const_header->u.var_picture.width/8) + 3);
  udh[pos++] = const_header->u.var_picture.position;
  udh[pos++] = const_header->u.var_picture.width/8;
  udh[pos++] = const_header->u.var_picture.height;

  for (j=0;j<(const_header->u.var_picture.height * const_header->u.var_picture.width/8);j++)
    udh[pos++] = const_header->u.var_picture.data[j];


  return pos;
}/*wms_ts_encode_udh_var_picture*/



int wms_ts_encode_udh_user_prompt
(
  const wms_udh_s_type *const_header,
  uint8 *udh
)
{
  int pos=0;

  udh[pos++] = (uint8) WMS_UDH_USER_PROMPT;
  udh[pos++] = (uint8) WMS_UDH_OCTETS_USER_PROMPT; /* only 1 byte for the udh data */
  udh[pos++] = const_header->u.user_prompt.number_of_objects;

  return pos;
} /* wms_ts_encode_udh_user_prompt() */



int wms_ts_encode_udh_eo
(
  const wms_udh_s_type *const_header,
  uint8 *udh
)
{
  int    pos = 0;
  uint8  udh_length;


  udh[pos++] = (uint8) WMS_UDH_EXTENDED_OBJECT;

  /* Pack UDH length */
  if( const_header->u.eo.first_segment == TRUE )
  {
    udh_length = WMS_UDH_OCTETS_EO_HEADER + const_header->u.eo.content.length;
  }
  else
  {
    udh_length = const_header->u.eo.content.length;
  }
  if( udh_length > WMS_UDH_EO_DATA_SEGMENT_MAX )
  {
    //MSG_ERROR_1("UDH EO data too long: %d", udh_length);
    log_error("UDH EO data too long: %d", udh_length);
    return 0;
  }

  udh[pos++] = udh_length;

  /* Pack EO header for the first segment */
  if( const_header->u.eo.first_segment == TRUE )
  {
    udh[pos++] = const_header->u.eo.reference;
    udh[pos++] = const_header->u.eo.length >> 8;
    udh[pos++] = const_header->u.eo.length & 0xFF;
    udh[pos++] = const_header->u.eo.control;
    udh[pos++] = (uint8) const_header->u.eo.type;
    udh[pos++] = const_header->u.eo.position >> 8;
    udh[pos++] = const_header->u.eo.position & 0xFF;
  }

  /* Pack content data */
  (void)memscpy( udh + pos,
                 const_header->u.eo.content.length,
                 const_header->u.eo.content.data,
                 const_header->u.eo.content.length );
  pos += const_header->u.eo.content.length;

  return pos;

} /* wms_ts_encode_udh_eo() */



int wms_ts_encode_udh_rfc822
(
  const wms_udh_s_type *const_header,
  uint8 *udh
)
{
  int pos=0;

  udh[pos++] = (uint8) WMS_UDH_RFC822;
  udh[pos++] = (uint8) WMS_UDH_OCTETS_RFC822;
  udh[pos++] = const_header->u.rfc822.header_length;

  return pos;
}/*wms_ts_encode_udh_rfc822*/



int wms_ts_encode_udh_nat_lang_ss
(
  const wms_udh_s_type *const_header,
  uint8 *udh
)
{
  int pos=0;

  udh[pos++] = (uint8) WMS_UDH_NAT_LANG_SS;
  udh[pos++] = (uint8) WMS_UDH_OCTETS_NAT_LANG_SS;
  udh[pos++] = (uint8) const_header->u.nat_lang_ss.nat_lang_id;

  return pos;
}/*wms_ts_encode_udh_nat_lang_ss*/



int wms_ts_encode_udh_nat_lang_ls
(
  const wms_udh_s_type *const_header,
  uint8 *udh
)
{
  int pos=0;

  udh[pos++] = (uint8) WMS_UDH_NAT_LANG_LS;
  udh[pos++] = (uint8) WMS_UDH_OCTETS_NAT_LANG_LS;
  udh[pos++] = (uint8) const_header->u.nat_lang_ls.nat_lang_id;

  return pos;
}/*wms_ts_encode_udh_nat_lang_ls*/



int wms_ts_encode_udh_other
(
  const wms_udh_s_type *const_header,
  uint8 *udh
)
{
  int i=0;
  int pos =0;

  udh[pos++] = (uint8) const_header->u.other.header_id;
  udh[pos++] = const_header->u.other.header_length;

  for(i = 0; i< const_header->u.other.header_length;i++)
  {
    udh[pos++] = const_header->u.other.data[i];
  }

  return pos;
}



uint8 wms_ts_encode_user_data_header
(
  uint8                           num_headers, /* IN */
  const wms_udh_s_type            * headers,   /* IN */
  uint8                           *data        /* OUT */
)
{
   int i;
   int pos = 0;

   if (num_headers == 0)
   {
     return 0;
   }

   pos++; /*Fill the user data header length later*/

   for (i=0;i<WMS_MAX_UD_HEADERS && i< num_headers;i++)
   {
     const wms_udh_s_type *udh_hdr_ptr = &headers[i];

     switch (udh_hdr_ptr->header_id)
     {
       case WMS_UDH_CONCAT_8:
         pos += wms_ts_encode_udh_concat_8(udh_hdr_ptr, data+pos);
         break;

       case WMS_UDH_CONCAT_16:
         pos += wms_ts_encode_udh_concat16(udh_hdr_ptr, data+pos);
         break;

       case WMS_UDH_SPECIAL_SM:
         pos += wms_ts_encode_udh_special_sm(udh_hdr_ptr, data+pos);
         break;

       case WMS_UDH_PORT_8:
         pos += wms_ts_encode_udh_port_8(udh_hdr_ptr, data+pos);
         break;

       case WMS_UDH_PORT_16:
         pos += wms_ts_encode_udh_port16(udh_hdr_ptr, data+pos);
         break;

       case WMS_UDH_TEXT_FORMATING:
         pos += wms_ts_encode_udh_text_formatting(udh_hdr_ptr, data+pos);
         break;


       case WMS_UDH_PRE_DEF_SOUND:
         pos += wms_ts_encode_udh_pre_def_sound(udh_hdr_ptr, data+pos);
         break;

       case WMS_UDH_USER_DEF_SOUND:
         pos += wms_ts_encode_udh_user_def_sound(udh_hdr_ptr, data+pos);
         break;

       case WMS_UDH_PRE_DEF_ANIM:
         pos += wms_ts_encode_udh_pre_def_anim(udh_hdr_ptr, data+pos);
         break;

       case WMS_UDH_LARGE_ANIM:
         pos += wms_ts_encode_udh_large_anim(udh_hdr_ptr, data+pos);
         break;

       case WMS_UDH_SMALL_ANIM:
         pos += wms_ts_encode_udh_small_anim(udh_hdr_ptr, data+pos);
         break;

       case WMS_UDH_LARGE_PICTURE:
         pos += wms_ts_encode_udh_large_picture(udh_hdr_ptr, data+pos);
         break;

       case WMS_UDH_SMALL_PICTURE:
         pos += wms_ts_encode_udh_small_picture(udh_hdr_ptr, data+pos);
         break;

       case WMS_UDH_VAR_PICTURE:
         pos += wms_ts_encode_udh_var_picture(udh_hdr_ptr, data+pos);
         break;

       case WMS_UDH_USER_PROMPT:
         pos += wms_ts_encode_udh_user_prompt(udh_hdr_ptr, data+pos);
         break;

       case WMS_UDH_EXTENDED_OBJECT:
         pos += wms_ts_encode_udh_eo(udh_hdr_ptr, data+pos);
         break;

       case WMS_UDH_RFC822:
         pos += wms_ts_encode_udh_rfc822(udh_hdr_ptr, data+pos);
         break;

       case WMS_UDH_NAT_LANG_SS:
         pos += wms_ts_encode_udh_nat_lang_ss(udh_hdr_ptr, data+pos);
         break;

       case WMS_UDH_NAT_LANG_LS:
         pos += wms_ts_encode_udh_nat_lang_ls(udh_hdr_ptr, data+pos);
         break;

       default:
         pos += wms_ts_encode_udh_other(udh_hdr_ptr, data+pos);

     }

   }
   data[0] = (uint8)(pos-1); /*User Data Header Length*/
   return ((uint8)(pos-1));

} /*wms_ts_encode_user_data_header*/



uint16 wms_ts_pack_gw_7_bit_chars
(
  const uint8     * in,
  uint16          in_len,      /* Number of 7-bit characters */
  uint16          shift,
  uint16          out_len_max, /* Number of 7-bit characters */
  uint8           * out
)
{
  uint16    i=0;
  uint16    pos = 0;

  if (in == NULL || out == NULL)
  {
    //MSG_ERROR_0("null pointer in wms_ts_pack_gw_7_bit_chars");
    log_error("null pointer in wms_ts_pack_gw_7_bit_chars");
    return 0;
  }
  /* pack the ASCII characters */
  shift %= 7;

  if (shift != 0)
  {
    /* Pack the upper bytes of the first character */
    out[pos] |= (uint8) ((uint32)in[i] << shift);
    shift = (7 - shift) + 1;
    if (shift == 7)
    {
      shift = 0;
      i++;
    }
    pos++;
  }

  for( ; pos < out_len_max && i < in_len;
       pos++, i++ )
  {
    /* pack the low bits */
    out[pos] = in[i] >> shift;

    if( i+1 < in_len )
    {
      /* pack the high bits using the low bits of the next character */
      out[pos] |= (uint8) ((uint32)in[i+1] << (7-shift));

      shift ++;

      if( shift == 7 )
      {
        shift = 0;
        i ++;
      }
    }
  }

  /* done */
  return pos;

} /* wms_ts_pack_gw_7_bit_chars() */



uint8 wms_ts_encode_gw_user_data
(
  const wms_gw_dcs_s_type         *dcs,
  const wms_gw_user_data_s_type   *user_data,
  uint8                           *data
)
{
  uint16 i, pos=0;
  uint8 fill_bits = 0;
  uint16 total_bits_occupied=0;

  uint8 user_data_header_length;
  uint16 user_data_length; /*User Data Length with the header*/

  if (WMS_MAX_LEN < user_data->sm_len)
  {
    //MSG_ERROR_0("Invalid user data");
    log_error("Invalid user data");
    return (uint8)pos;
  }

  data[pos] = (uint8)user_data->sm_len; /*User Data length*/
  pos++;
  if( dcs->alphabet == WMS_GW_ALPHABET_7_BIT_DEFAULT )
  {
    /* pack GSM default characters */
    if (user_data->num_headers > 0)
    {
      /* Check for Memory Corruption - data[WMS_MAX_LEN] */
      if (wms_ts_compute_user_data_header_length(user_data->num_headers, user_data->headers) <= WMS_SMS_UDL_MAX_8_BIT)
      {

        user_data_header_length = wms_ts_encode_user_data_header( user_data->num_headers,
                                              user_data->headers,
                                              data+pos);

        pos += user_data_header_length + 1;

        total_bits_occupied = (user_data_header_length + 1) * 8;
        fill_bits = (total_bits_occupied % 7);    /* fill_bits vary from 0 to 6 */

        if (fill_bits != 0)
        {
          fill_bits = 7 - fill_bits;
        }

        user_data_length = (uint16)((total_bits_occupied + fill_bits + (user_data->sm_len * 7)) / 7);

        data[0] = (uint8)user_data_length;   /* UDL */
        data[1] = user_data_header_length;   /* UDHL */
      }
      else
      {
        //MSG_ERROR_0("Encode User Data Header Exceeds Capacity - Skipping UDH");
        log_error("Encode User Data Header Exceeds Capacity - Skipping UDH");
      }
    }

    i = wms_ts_pack_gw_7_bit_chars( user_data->sm_data,
                                    user_data->sm_len,
                                    fill_bits,
                                   (uint16) (WMS_MAX_LEN - pos),
                                    & data[pos] );
    pos += i;
  }
  else
  {
    if (user_data->num_headers > 0)
    {
      /* Check for Memory Corruption - data[WMS_MAX_LEN] */
      if (wms_ts_compute_user_data_header_length(user_data->num_headers, user_data->headers) <= WMS_SMS_UDL_MAX_8_BIT)
      {
        user_data_header_length =
              wms_ts_encode_user_data_header(user_data->num_headers,
                                             user_data->headers,
                                             data+pos);

        /*TP-UDL is modified to actual user data + udhl */
        data[0] = (uint8)(user_data->sm_len + user_data_header_length +1);
        pos += user_data_header_length+1;
      }
      else
      {
        //MSG_ERROR_0("Encode User Data Header Exceeds Capacity - Skipping UDH");
        log_error("Encode User Data Header Exceeds Capacity - Skipping UDH");
      }
    }

    (void)memscpy( &data[pos],
                   user_data->sm_len,
                   user_data->sm_data,
                   user_data->sm_len );
    pos += user_data->sm_len;
  }

  return (uint8)pos;

} /* wms_ts_encode_gw_user_data() */



uint8 wms_ts_unpack_gw_7_bit_chars
(
  const uint8       * in,
  uint8             in_len,        /* Number of 7-bit characters */
  uint8             out_len_max,   /* Number of maximum 7-bit characters after unpacking */
  uint16            shift,
  uint8             * out
)
{
  int      i=0;
  uint16   pos=0;

  if (in == NULL || out == NULL)
  {
    //MSG_ERROR_0("null pointer in wms_ts_unpack_gw_7_bit_chars");
    log_error("null pointer in wms_ts_unpack_gw_7_bit_chars");
    return 0;
  }

  /*If the number of fill bits != 0, then it would cause an additional shift*/
  if (shift != 0)
   pos = pos+1;

  if (shift ==7)
  {
    out[0] = in[0] >> 1; /*7 fillbits*/
    shift =0;            /*First Byte is a special case*/
    i=1;
  }

  for( ;
       i < out_len_max && i< in_len;
       i++, pos++ )
  {
    out[i] = (uint8)( (uint32)in[pos] << shift ) & 0x7F;

    if( pos != 0 )
    {
      /* except the first byte, a character contains some bits
      ** from the previous byte.
      */
      out[i] |= in[pos-1] >> (8-shift);
    }

    shift ++;

    if( shift == 7 )
    {
      shift = 0;

      /* a possible extra complete character is available */
      i ++;
      if( i >= out_len_max )
      {
        //MSG_ERROR_0("Not enough output buffer for unpacking");
        log_error("Not enough output buffer for unpacking");
        break;
      }
      out[i] = in[pos] >> 1;
    }
  }

  return(uint8)(pos);

} /* wms_ts_unpack_gw_7_bit_chars() */



uint8 wms_ts_decode_address
(
  const uint8               * data,
  wms_address_s_type        * addr
)
{
  uint8   i, pos = 0;

  if( NULL == data || NULL == addr )
  {
    //MSG_ERROR_0("NULL pointer");
    log_error("NULL pointer");
    return 0;
  }

  /* Len field: number of digits */
  i = data[pos];

  if( i > WMS_GW_ADDRESS_MAX )
  {
    /* Address is too long */
    //MSG_ERROR_1("Addr len too long: %d", i);
    log_error("Addr len too long: %d", i);
    return 0;
  }

  addr->number_of_digits = i;

  pos ++;
  //Type-of-Address field
  /* Spec TS 23.040 Section 9.1.2.5 is 1 octet long and has the following format:
        Bit 7    : 1
		Bits 4-6 : Depict TON
		Bits 0-3 : Numbering plan
  */
  if (0 == (data[pos] & 0x80))
  {
     //MSG_ERROR_0("The most significant bit in Type-of-Address field is not 1");
     log_error("The most significant bit in Type-of-Address field is not 1");
     return 0;
  }

  /* TON & NPI: */
  addr->digit_mode  = WMS_DIGIT_MODE_4_BIT;
  addr->number_type = (wms_number_type_e_type) (( data[pos] & 0x70 ) >> 4);
  addr->number_plan = (wms_number_plan_e_type) (data[pos] & 0x0F);
  pos ++;

  if (addr->number_type == WMS_NUMBER_ALPHANUMERIC )
  {
    uint8 bytes_increment=0;
    /* Alphanumberic Number Type */
    addr->digit_mode = WMS_DIGIT_MODE_8_BIT;

    /* length = number of BCD digits */
    bytes_increment = (addr->number_of_digits+1)/2;

    addr->number_of_digits = (uint8)(addr->number_of_digits*4/7);

    (void)wms_ts_unpack_gw_7_bit_chars
           (
             &data[pos],
             addr->number_of_digits,
             WMS_GW_ADDRESS_MAX,
             0,
             addr->digits
            );

    pos += bytes_increment;
  }
  else
  {
    /* the digits: */
    for( i=0; i<addr->number_of_digits; i++ )
    {
      /* unpack two digits each time */
      addr->digits[i++] = data[pos] & 0x0F;
      addr->digits[i]   = ( data[pos] & 0xF0 ) >> 4;
      pos ++;
    }
  }
  return pos;
} /* wms_ts_decode_address() */



uint8 wms_ts_decode_dcs
(
  const uint8           *data,
  wms_gw_dcs_s_type     *dcs
)
{
  uint8 pos = 0;
//#ifdef FEATURE_GWSMS
  uint8 i;
  /* initialize the values */

  if (data == NULL || dcs == NULL)
  {
    //MSG_ERROR_0("null pointer in wms_ts_decode_dcs");
    log_error("null pointer in wms_ts_decode_dcs");
    return 0;
  }

  //wms_ts_init();
  //qc_enter_crit_sect(&encode_decode_data_crit_sect);

  /* TP-DCS is defined in spec 3GPP TS 23.038, section 4. */
  dcs->msg_class      = WMS_MESSAGE_CLASS_NONE;
  dcs->msg_waiting    = WMS_GW_MSG_WAITING_NONE;
  dcs->alphabet       = WMS_GW_ALPHABET_7_BIT_DEFAULT;
  dcs->is_compressed  = FALSE;
  dcs->msg_waiting_kind = WMS_GW_MSG_WAITING_VOICEMAIL;

  /* bits 7-6 */
  i = ( data[pos] & 0xC0 ) >> 6;
  switch( i )
  {
    case 0:
      /* pattern 00xx xxxx */
      dcs->is_compressed = data[pos] & 0x20;
      if( data[pos] & 0x10 )
      {
        dcs->msg_class = (wms_message_class_e_type) (data[pos] & 0x03);
      }
      else
      {
        /* no class information */
        dcs->msg_class = WMS_MESSAGE_CLASS_NONE;
      }
      dcs->alphabet = (wms_gw_alphabet_e_type) (( data[pos] & 0x0C ) >> 2);
      break;

    case 3:
      /* bits 5-4 */
      if( (data[pos] & 0x30) == 0x30 )
      {
        /* pattern 1111 xxxx */

        /* bit 3 is reserved */

        /* bit 2 */
        dcs->alphabet = (data[pos] & 0x04 ) ? WMS_GW_ALPHABET_8_BIT:
                            WMS_GW_ALPHABET_7_BIT_DEFAULT;

        /* bits 1-0 */
        dcs->msg_class = (wms_message_class_e_type) (data[pos] & 0x03);

        /* set remaining fields */
        dcs->is_compressed  = FALSE;
        dcs->msg_waiting    = WMS_GW_MSG_WAITING_NONE_1111;
      }
      else
      {
        /* Message waiting groups
        */
        dcs->is_compressed  = FALSE;
        dcs->msg_class          = WMS_MESSAGE_CLASS_NONE;

        /* bits 5-4 */
        if( (data[pos] & 0x30) == 0x00 )
        {
          dcs->msg_waiting  = WMS_GW_MSG_WAITING_DISCARD;
          dcs->alphabet     = WMS_GW_ALPHABET_7_BIT_DEFAULT;
        }
        else if( (data[pos] & 0x30) == 0x10 )
        {
          dcs->msg_waiting  = WMS_GW_MSG_WAITING_STORE;
          dcs->alphabet     = WMS_GW_ALPHABET_7_BIT_DEFAULT;
        }
        else
        {
          dcs->msg_waiting  = WMS_GW_MSG_WAITING_STORE;
          dcs->alphabet     = WMS_GW_ALPHABET_UCS2;
        }

        /* bit 3 */
        dcs->msg_waiting_active = ( data[pos] & 0x08 ) ? TRUE : FALSE;

        /* bit 2 is reserved */

        /* bits 1-0 */
        dcs->msg_waiting_kind = (wms_gw_msg_waiting_kind_e_type) (data[pos] & 0x03);
      }
      break;

    default:
      // reserved values
      //MSG_ERROR_1("Invalid DCS: %x", data[pos]);
      log_error("Invalid DCS: %x", data[pos]);
      dcs->alphabet       = WMS_GW_ALPHABET_7_BIT_DEFAULT;
      dcs->is_compressed  = FALSE;
      dcs->msg_waiting    = WMS_GW_MSG_WAITING_NONE;
      dcs->msg_class          = WMS_MESSAGE_CLASS_NONE;
      break;
  }

  if ( dcs->alphabet > WMS_GW_ALPHABET_UCS2 )
  {
    //dcs->alphabet = WMS_GW_ALPHABET_7_BIT_DEFAULT;
    dcs->alphabet = WMS_GW_ALPHABET_8_BIT;
  }

  dcs->raw_dcs_data = data[pos];

  pos ++;

  //qc_leave_crit_sect(&encode_decode_data_crit_sect);
//#endif /* FEATURE_GWSMS */
  return pos;

} /* wms_ts_decode_dcs() */



uint8 wms_ts_decode_timestamp
(
  const uint8             *data,
  wms_timestamp_s_type  *timestamp
)
{
  uint8 pos = 0, i, j;

  if (data == NULL || timestamp == NULL)
  {
    //MSG_ERROR_0("null pointer in wms_ts_decode_timestamp");
    log_error("null pointer in wms_ts_decode_timestamp");
    return 0;
  }

  /*year check*/

  /* in GW, swap the order of LSB, MSB */
  i = ((data[pos] & 0x0F) << 4) + ((data[pos] & 0xF0) >> 4);
  if ( !wms_ts_bcd_to_int(i, &j) )
  {
    //MSG_ERROR_1("Invalid BCD Digits in Encoded Timestamp Year : %d", data[pos]);
    log_error("Invalid BCD Digits in Encoded Timestamp Year : %d", data[pos]);
    i = 0;  /* Modifying it to a Good Value */
  }
  timestamp->year = i;
  pos ++;

  /*month check*/
  i = ((data[pos] & 0x0F) << 4) + ((data[pos] & 0xF0) >> 4);
  if ( wms_ts_bcd_to_int(i, &j) )
  {
    if (j > 12 || j < 1)
    {
      //MSG_ERROR_1("Month is invalid: %d", j);
      log_error("Month is invalid: %d", j);
      i = 1;  /* Modifying it to a Good Value */
    }
  }
  else
  {
    //MSG_ERROR_1("Invalid BCD Digits in Encoded Timestamp Month : %d", data[pos]);
    log_error("Invalid BCD Digits in Encoded Timestamp Month : %d", data[pos]);
    i = 1;  /* Modifying it to a Good Value */
  }
  timestamp->month = i;
  pos ++;

  /*day check*/
  i = ((data[pos] & 0x0F) << 4) + ((data[pos] & 0xF0) >> 4);
  if ( wms_ts_bcd_to_int(i, &j) )
  {
    if (j > 31 || j < 1)
    {
      //MSG_ERROR_1("Day is invalid: %d", j);
      log_error("Day is invalid: %d", j);
      i = 1;  /* Modifying it to a Good Value */
    }
  }
  else
  {
    //MSG_ERROR_1("Invalid BCD Digits in Encoded Timestamp Day : %d", data[pos]);
    log_error("Invalid BCD Digits in Encoded Timestamp Day : %d", data[pos]);
    i = 1;  /* Modifying it to a Good Value */
  }
  timestamp->day = i;
  pos ++;

  /*hour check*/
  i = ((data[pos] & 0x0F) << 4) + ((data[pos] & 0xF0) >> 4);
  if ( wms_ts_bcd_to_int(i, &j) )
  {
    if (j > 23)
    {
      //MSG_ERROR_1("Hour is too large: %d", j);
      log_error("Hour is too large: %d", j);
      i = 0;  /* Modifying it to a Good Value */
    }
  }
  else
  {
    //MSG_ERROR_1("Invalid BCD Digits in Encoded Timestamp Hour : %d", data[pos]);
    log_error("Invalid BCD Digits in Encoded Timestamp Hour : %d", data[pos]);
    i = 0;  /* Modifying it to a Good Value */
  }
  timestamp->hour = i;
  pos ++;

  /*minute check*/
  i = ((data[pos] & 0x0F) << 4) + ((data[pos] & 0xF0) >> 4);
  if ( wms_ts_bcd_to_int(i, &j) )
  {
    if (j > 59)
    {
      //MSG_ERROR_1("Minute is too large: %d", j);
      log_error("Minute is too large: %d", j);
      i = 0;  /* Modifying it to a Good Value */
    }
  }
  else
  {
    //MSG_ERROR_1("Invalid BCD Digits in Encoded Timestamp Minute : %d", data[pos]);
    log_error("Invalid BCD Digits in Encoded Timestamp Minute : %d", data[pos]);
    i = 0;  /* Modifying it to a Good Value */
  }
  timestamp->minute = i;
  pos ++;

  /*seconds check*/
  i = ((data[pos] & 0x0F) << 4) + ((data[pos] & 0xF0) >> 4);
  if ( wms_ts_bcd_to_int(i, &j) )
  {
    if (j > 59)
    {
      //MSG_ERROR_1("Second is too large: %d", i);
      log_error("Second is too large: %d", i);
      i = 0;  /* Modifying it to a Good Value */
    }
  }
  else
  {
    //MSG_ERROR_1("Invalid BCD Digits in Encoded Timestamp Second : %d", data[pos]);
    log_error("Invalid BCD Digits in Encoded Timestamp Second : %d", data[pos]);
    i = 0;  /* Modifying it to a Good Value */
  }
  timestamp->second = i;
  pos ++;

  /*timezone, special case where timestamp->timezone is an integer value*/
  if (data[pos] & 0x08)
  {
    timestamp->timezone = (data[pos] & 0x07) * 10 + ((data[pos] & 0xF0)>>4);
    timestamp->timezone *= (-1);
  }
  else
  {
    timestamp->timezone = (sint7)((data[pos] & 0x0F) * 10 + ((data[pos] & 0xF0) >> 4 ));
  }
  // Valid range of timezone is from -12 to +14 hours
  if (timestamp->timezone > 56 || timestamp->timezone < -48)
  {
    //MSG_ERROR_1("Timezone is out of bound: %d", timestamp->timezone);
    log_error("Timezone is out of bound: %d", timestamp->timezone);
    timestamp->timezone = 0;  /* Modifying it to a Good Value */
  }
  pos ++;

  return pos;

} /* wms_ts_decode_timestamp() */



uint8 wms_ts_decode_gw_user_data
(
  const wms_gw_dcs_s_type   *dcs,
  const uint8               len, // user data length
  const uint8               *data,
  const boolean             user_data_header_present,
  wms_gw_user_data_s_type   *user_data
)
{
  uint8 i, pos=0;
  uint8   fill_bits =0;
  uint8   user_data_length;
  uint8   user_data_header_length = 0; /* only the user data header length*/

  if (dcs == NULL || data == NULL || user_data == NULL)
  {
    //MSG_ERROR_0("null pointer in wms_ts_decode_gw_user_data");
    log_error("null pointer in wms_ts_decode_gw_user_data");
    return 0;
  }

  /* Defaulting to all zeroes */
  (void)memset(user_data, 0, sizeof(wms_gw_user_data_s_type));

  if (len == 0)
  {
    return 0;
  }

  if( dcs->alphabet == WMS_GW_ALPHABET_7_BIT_DEFAULT )
  {
    if (len > WMS_SMS_UDL_MAX_7_BIT)
    {
      //MSG_ERROR_0("user data length > max value for gw 7-bit alphabet");
      log_error("user data length > max value for gw 7-bit alphabet");
      return 0;
    }
    user_data_length = len;

    if(user_data_header_present)
    {
      user_data_header_length = wms_ts_decode_user_data_header( data[pos]+1, data+pos,
                                                                & user_data->num_headers, user_data->headers );

      if ( (1 + user_data_header_length) > (len * 7 / 8) )
      {
         //MSG_ERROR_0("user data header length >= total length");
         log_error("user data header length >= total length");
         return 0;
      }
    }
    /*len would be the number of septets*/
    if(user_data_header_length > 0)
    {
      /*The number of fill bits required to make a septet boundary*/
      fill_bits =( (len * 7) - ((user_data_header_length+1)*8) ) % 7;
      user_data_length = (uint8)(( (len * 7) - ((user_data_header_length+1)*8) ) / 7);
      pos = user_data_header_length + 1;

      if (fill_bits != 0)
      {
        fill_bits = 8 - fill_bits;
      }
    }

    i = wms_ts_unpack_gw_7_bit_chars
        (
          & data[pos],
          user_data_length,
          WMS_MAX_LEN,
          fill_bits,
          user_data->sm_data
        );
    user_data->sm_len = user_data_length;
  }
  else
  {
    if (len > WMS_SMS_UDL_MAX_8_BIT)
    {
      //MSG_ERROR_0("user data length > max value for 8-bit chararacters");
      log_error("user data length > max value for 8-bit chararacters");
      return 0;
    }
    user_data_length = len;

    if(user_data_header_present)
    {
       user_data_header_length = wms_ts_decode_user_data_header( data[pos]+1,
                                                                 data+pos,
                                                       & user_data->num_headers,
                                                       user_data->headers );
       if (user_data_header_length >= len)
       {
          //MSG_ERROR_0("user data header length >= total length");
          log_error("user data header length >= total length");
          return 0;
       }
       pos += user_data_header_length +1;
       user_data_length = len - (user_data_header_length + 1);
    }

    (void)memscpy( user_data->sm_data,
                   user_data_length,
                   data + pos,
                   user_data_length );
    user_data->sm_len = user_data_length;
    i = (uint8)user_data->sm_len;
  }

  pos += i;

  return pos;

} /* wms_ts_decode_gw_user_data() */



/*static*/ uint8 wms_ts_decode_udh_concat_8
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr /* OUT */
)
{
  uint8 pos=0;

  if (udh == NULL || header_ptr == NULL )
  {
    //MSG_ERROR_0("udh is NULL");
    log_error("udh is NULL");
    return 0;
  }

  if (udh[pos] != 3)  /*Length of information element*/
  {
    //MSG_ERROR_1("UDH Header Concat 8 Present with invalid data length = %d", udh[pos]);
    log_error("UDH Header Concat 8 Present with invalid data length = %d", udh[pos]);
    return 0; /*Return 0*/
  }


  /* if the maximum number of messages is 0     Or*/
  /* if the sequence number of the message is 0 Or*/
  /* if the sequence number of the current message is greater than the max messages*/
  if (udh[pos +2] == 0 ||
      udh[pos +3] == 0 ||
      udh[pos +3] > udh[pos +2])
  {
    //MSG_ERROR_0("UDH Header Contact 8 with out of bound max messages");
    log_error("UDH Header Contact 8 with out of bound max messages");
    return 0;
  }

  pos++;
  header_ptr->header_id          = WMS_UDH_CONCAT_8;
  header_ptr->u.concat_8.msg_ref = udh[pos++];
  header_ptr->u.concat_8.total_sm= udh[pos++];
  header_ptr->u.concat_8.seq_num = udh[pos++];

  return (udh[0] + 1);

}/*wms_ts_decode_udh_concat_8*/



/*static*/ uint8 wms_ts_decode_udh_concat16
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
)
{
  uint8 pos=0;

  if (udh == NULL || header_ptr == NULL )
  {
    //MSG_ERROR_0("udh is NULL");
    log_error("udh is NULL");
    return 0;
  }

  if(udh[pos] != 4) /*Length of information element*/
  {
    //MSG_ERROR_1("SMS UDH Header Concat16 Present with invalid data length = %d", udh[pos]);
    log_error("SMS UDH Header Concat16 Present with invalid data length = %d", udh[pos]);
    return 0;
  }

  /* if the maximum number of messages is 0     Or*/
  /* if the sequence number of the message is 0 Or*/
  /* if the sequence number of the current message is greater than the max messages*/
  if (udh[pos +3] == 0 ||
      udh[pos +4] == 0 ||
      udh[pos +4] > udh[pos +3])
    return 0;

  header_ptr->header_id           = WMS_UDH_CONCAT_16;
  pos++;
  header_ptr->u.concat_16.msg_ref = udh[pos++];
  header_ptr->u.concat_16.msg_ref = (uint16)(header_ptr->u.concat_16.msg_ref << 8) | udh[pos++];
  header_ptr->u.concat_16.total_sm= udh[pos++];
  header_ptr->u.concat_16.seq_num = udh[pos++];

  return (udh[0] + 1);
}/*wms_ts_decode_udh_concat16*/



/*static*/ uint8 wms_ts_decode_udh_special_sm
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
)
{
  uint8 pos=0;

  if (udh == NULL || header_ptr == NULL )
  {
    //MSG_ERROR_0("udh is NULL");
    log_error("udh is NULL");
    return 0;
  }

  if(udh[pos] != 2) /*Length of information element*/
  {
    //MSG_ERROR_1("SMS UDH Header Special SM Present with invalid data length = %d", udh[pos]);
    log_error("SMS UDH Header Special SM Present with invalid data length = %d", udh[pos]);
    return 0;
  }

  pos++;
  header_ptr->header_id                             = WMS_UDH_SPECIAL_SM;

  /* Bit 7 of octet 1 indicates if the message shall be stored or not.
     Bit 6..0 of octet 1 indicate which indicator is to be updated.
          000 0000 = Voice Message Waiting
          000 0001 = Fax Message Waiting
          000 0010 = Email Message Waiting
          000 0011 = Other Message Waiting
          000 0111 = Videomail Message Waiting (3GPP TS 23.040 Release 8 76 V8.5.0 (2009-06))
    Octet 2 represents the number of waiting messages
          The number can range from 0 to 255 with the value of 255 meaning
          that there are 255 or more messages waiting
  */

  header_ptr->u.special_sm.msg_waiting =  (wms_gw_msg_waiting_e_type) ((udh[pos] >> 7 == 0) ? WMS_GW_MSG_WAITING_DISCARD : WMS_GW_MSG_WAITING_STORE);

  /* Extended message - currently supports only videomail*/
  if( ( udh[pos] & WMS_SP_EXTD_VIDEOMAIL_MSG_WAITING_TYPE ) > 0 )
  {
    header_ptr->u.special_sm.msg_waiting_kind = WMS_GW_MSG_WAITING_VIDEOMAIL;
  }
  /* Not extended message*/
  else if( ( udh[pos] & 0x04 ) == 0 )
  {
    header_ptr->u.special_sm.msg_waiting_kind
                                   = (wms_gw_msg_waiting_kind_e_type) (udh[pos] & 0x03);
  }
  pos++;
  header_ptr->u.special_sm.message_count            = udh[pos++];

  return (udh[0] + 1);
}/*wms_ts_decode_udh_special_sm*/



/*static*/ uint8 wms_ts_decode_udh_port_8
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
)
{
  uint8 pos=0;

  if (udh == NULL || header_ptr == NULL )
  {
    //MSG_ERROR_0("udh is NULL");
    log_error("udh is NULL");
    return 0;
  }


  if (udh[pos] != 2)  /*Length of information element*/
  {
    //MSG_ERROR_1("UDH Header Port 8 Present with invalid data length = %d", udh[pos]);
    log_error("UDH Header Port 8 Present with invalid data length = %d", udh[pos]);
    return 0; /*Return 0*/
  }


  pos++;
  header_ptr->header_id          = WMS_UDH_PORT_8;
  header_ptr->u.wap_8.dest_port  = udh[pos++];
  header_ptr->u.wap_8.orig_port  = udh[pos++];

  return (udh[0] + 1);
}/*wms_ts_decode_udh_port_8*/



/*static*/ uint8 wms_ts_decode_udh_port16
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
)
{
  uint8 pos=0;

  if (udh == NULL || header_ptr == NULL )
  {
    //MSG_ERROR_0("udh is NULL");
    log_error("udh is NULL");
    return 0;
  }

  if(udh[pos] != 4) /*Length of information element*/
  {
    //MSG_ERROR_1("SMS UDH Header Port16 Present with invalid data length = %d", udh[pos]);
    log_error("SMS UDH Header Port16 Present with invalid data length = %d", udh[pos]);
    return 0;
  }

  header_ptr->header_id           = WMS_UDH_PORT_16;
  pos++;
  header_ptr->u.wap_16.dest_port = udh[pos++];
  header_ptr->u.wap_16.dest_port = (uint16)(header_ptr->u.wap_16.dest_port << 8) | udh[pos++];
  header_ptr->u.wap_16.orig_port = udh[pos++];
  header_ptr->u.wap_16.orig_port = (uint16)(header_ptr->u.wap_16.orig_port << 8) | udh[pos++];

  return (udh[0] + 1);
}/*wms_ts_decode_udh_port16*/



/*static*/ uint8 wms_ts_decode_udh_text_formatting
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
)
{
  uint8 pos=0;

  if (udh == NULL || header_ptr == NULL )
  {
    //MSG_ERROR_0("udh is NULL");
    log_error("udh is NULL");
    return 0;
  }

  if(udh[pos] != 3 && udh[pos] != 4) /*Length of information element*/
  {
    //MSG_ERROR_1("SMS UDH Header Text Formatting Present with invalid data length = %d", udh[pos]);
    log_error("SMS UDH Header Text Formatting Present with invalid data length = %d", udh[pos]);
    return 0;
  }

  if(udh[pos] == 4)
  {
    header_ptr->u.text_formating.is_color_present = TRUE;
  }
  else if (udh[pos] == 3)
  {
    header_ptr->u.text_formating.is_color_present = FALSE;
  }
  pos++;


  header_ptr->header_id                                 = WMS_UDH_TEXT_FORMATING;
  header_ptr->u.text_formating.start_position           = udh[pos++];
  header_ptr->u.text_formating.text_formatting_length   = udh[pos++];
  header_ptr->u.text_formating.alignment_type           = (wms_udh_alignment_e_type) (udh[pos] & 0x03 ); /*bit 0 and  bit 1*/
  header_ptr->u.text_formating.font_size                = (wms_udh_font_size_e_type) ((udh[pos] & 0x0c) >> 2); /*bit 3 and  bit 2*/

  header_ptr->u.text_formating.style_bold               = (udh[pos] & 0x10) >> 4; /*bit 4 */
  header_ptr->u.text_formating.style_italic             = (udh[pos] & 0x20) >> 5; /*bit 5 */
  header_ptr->u.text_formating.style_underlined         = (udh[pos] & 0x40) >> 6; /*bit 6 */
  header_ptr->u.text_formating.style_strikethrough      = (udh[pos] & 0x80) >> 7; /*bit 7 */
  pos++;

  if(header_ptr->u.text_formating.is_color_present)
  {
    header_ptr->u.text_formating.text_color_foreground   = (wms_udh_text_color_e_type) (udh[pos] & 0x0F);  /* bit 0-3 */
    header_ptr->u.text_formating.text_color_background   = (wms_udh_text_color_e_type) ((udh[pos] & 0xF0) >> 4);  /* bit 4-7 */
    pos++;
  }
  return (udh[0] + 1);
}/*wms_ts_decode_udh_text_formatting*/



/*static*/ uint8 wms_ts_decode_udh_pre_def_sound
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
)
{
  uint8 pos=0;

  if (udh == NULL || header_ptr == NULL )
  {
    //MSG_ERROR_0("udh is NULL");
    log_error("udh is NULL");
    return 0;
  }

  if(udh[pos] != 2) /*Length of information element*/
  {
    //MSG_ERROR_1("SMS UDH Header Pre Defined Sound Present with invalid data length = %d", udh[pos]);
    log_error("SMS UDH Header Pre Defined Sound Present with invalid data length = %d", udh[pos]);
    return 0;
  }

  pos++;
  header_ptr->header_id                                 = WMS_UDH_PRE_DEF_SOUND;
  header_ptr->u.pre_def_sound.position                  = udh[pos++];
  header_ptr->u.pre_def_sound.snd_number                = udh[pos++];

  return (udh[0] + 1);
}/*wms_ts_decode_udh_pre_def_sound*/



/*static*/ uint8 wms_ts_decode_udh_user_def_sound
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
)
{
  uint8 pos=0, j;

  if (udh == NULL || header_ptr == NULL )
  {
    //MSG_ERROR_0("udh is NULL");
    log_error("udh is NULL");
    return 0;
  }

  if(udh[pos] == 0) /*Length of information element*/
  {
    //MSG_ERROR_0("SMS UDH Header User Defined Sound Present with no Data");
    log_error("SMS UDH Header User Defined Sound Present with no Data");
    return 0;
  }

  header_ptr->header_id                                 = WMS_UDH_USER_DEF_SOUND;
  header_ptr->u.user_def_sound.data_length              = udh[pos++]-1;
  header_ptr->u.user_def_sound.position                 = udh[pos++];


  if (header_ptr->u.user_def_sound.data_length > WMS_UDH_MAX_SND_SIZE)
  {
    //MSG_ERROR_1("Max Size Exceed Header id %d ", header_ptr->header_id);
    log_error("Max Size Exceed Header id %d ", header_ptr->header_id);
    //data[pos] += data[pos]; /*Skip the bytes*/
    return 0;
  }

  //pos++;
  memset(header_ptr->u.user_def_sound.user_def_sound, 0xff, WMS_UDH_MAX_SND_SIZE);

  for (j = 0; j < header_ptr->u.user_def_sound.data_length; j++)
  {
    header_ptr->u.user_def_sound.user_def_sound[j]      = udh[pos++];
  }

  return pos;
}/*wms_ts_decode_udh_user_def_sound*/



/*static*/ uint8 wms_ts_decode_udh_pre_def_anim
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
)
{
  uint8 pos=0;

  if (udh == NULL || header_ptr == NULL )
  {
    //MSG_ERROR_0("udh is NULL");
    log_error("udh is NULL");
    return 0;
  }

  if(udh[pos] != 2) /*Length of information element*/
  {
    //MSG_ERROR_1("SMS UDH Header Pre Defined Animation Present with invalid data length = %d", udh[pos]);
    log_error("SMS UDH Header Pre Defined Animation Present with invalid data length = %d", udh[pos]);
    return 0;
  }

  pos++;
  header_ptr->header_id                                 = WMS_UDH_PRE_DEF_ANIM;
  header_ptr->u.pre_def_anim.position                   = udh[pos++];
  header_ptr->u.pre_def_anim.animation_number           = udh[pos++];

  return pos;
}/*wms_ts_decode_udh_pre_def_anim*/



/*static*/ uint8 wms_ts_decode_udh_large_anim
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
)
{
  uint8 pos=0, j, k;

  if (udh == NULL || header_ptr == NULL )
  {
    //MSG_ERROR_0("udh is NULL");
    log_error("udh is NULL");
    return 0;
  }

  if(udh[pos] != (WMS_UDH_ANIM_NUM_BITMAPS * WMS_UDH_LARGE_BITMAP_SIZE + 1) ) /*Length of information element*/
  {
    //MSG_ERROR_1("SMS UDH Header Large Defined Animation Present with invalid data length = %d", udh[pos]);
    log_error("SMS UDH Header Large Defined Animation Present with invalid data length = %d", udh[pos]);
    return 0;
  }

  header_ptr->header_id                             = WMS_UDH_LARGE_ANIM;
  pos++; /*Skip the Size*/
  header_ptr->u.large_anim.position                 = udh[pos++];

  for(j=0;j<WMS_UDH_ANIM_NUM_BITMAPS;j++)
    for (k=0;k<WMS_UDH_LARGE_BITMAP_SIZE; k++)
      header_ptr->u.large_anim.data[j][k] = udh[pos++];

  return pos;
}/*wms_ts_decode_udh_large_anim*/



/*static*/ uint8 wms_ts_decode_udh_small_anim
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
)
{
  uint8 pos=0, j, k;

  if (udh == NULL || header_ptr == NULL )
  {
    //MSG_ERROR_0("udh is NULL");
    log_error("udh is NULL");
    return 0;
  }

  if(udh[pos] != (WMS_UDH_ANIM_NUM_BITMAPS * WMS_UDH_SMALL_BITMAP_SIZE + 1) ) /*Length of information element*/
  {
    //MSG_ERROR_1("SMS UDH Header Large Defined Animation Present with invalid data length = ", udh[pos]);
    log_error("SMS UDH Header Large Defined Animation Present with invalid data length = ", udh[pos]);
    return 0;
  }

  header_ptr->header_id                             = WMS_UDH_SMALL_ANIM;

  pos++; /*Skip the Size*/
  header_ptr->u.small_anim.position                 = udh[pos++];

  for(j=0;j<WMS_UDH_ANIM_NUM_BITMAPS;j++)
    for (k=0;k<WMS_UDH_SMALL_BITMAP_SIZE; k++)
      header_ptr->u.small_anim.data[j][k] = udh[pos++];

  return pos;
}/*wms_ts_decode_udh_small_anim*/



/*static*/ uint8 wms_ts_decode_udh_large_picture
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
)
{
  uint8 pos=0, j;

  if (udh == NULL || header_ptr == NULL )
  {
    //MSG_ERROR_0("udh is NULL");
    log_error("udh is NULL");
    return 0;
  }

  if(udh[pos] != WMS_UDH_LARGE_PIC_SIZE + 1) /*Length of information element*/
  {
    //MSG_ERROR_1("SMS UDH Header Large Picture Present with invalid data length = %d", udh[pos]);
    log_error("SMS UDH Header Large Picture Present with invalid data length = %d", udh[pos]);
    return 0;
  }


  header_ptr->header_id                                 = WMS_UDH_LARGE_PICTURE;
  pos++; /*Skip the Size*/
  header_ptr->u.large_picture.position                  = udh[pos++];

  for(j=0;j<WMS_UDH_LARGE_PIC_SIZE;j++)
    header_ptr->u.large_picture.data[j]    = udh[pos++];

  return pos;
}/*wms_ts_decode_udh_large_picture*/



/*static*/ uint8 wms_ts_decode_udh_small_picture
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
)
{
  uint8 pos=0, j;

  if (udh == NULL || header_ptr == NULL )
  {
    //MSG_ERROR_0("udh is NULL");
    log_error("udh is NULL");
    return 0;
  }

  if(udh[pos] != WMS_UDH_SMALL_PIC_SIZE + 1) /*Length of information element*/
  {
    //MSG_ERROR_1("SMS UDH Header Small Picture Present with invalid data legnth = %d", udh[pos]);
    log_error("SMS UDH Header Small Picture Present with invalid data legnth = %d", udh[pos]);
    return 0;
  }

  header_ptr->header_id                                 = WMS_UDH_SMALL_PICTURE;
  pos++; /*Skip the size*/
  header_ptr->u.small_picture.position                  = udh[pos++];

  for(j=0;j<WMS_UDH_SMALL_PIC_SIZE;j++)
    header_ptr->u.small_picture.data[j]           = udh[pos++];

  return pos;
}/*wms_ts_decode_udh_small_picture*/



/*static*/ uint8 wms_ts_decode_udh_var_picture
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
)
{
  uint8 pos=0, j, pic_size;

  if (udh == NULL || header_ptr == NULL )
  {
    //MSG_ERROR_0("udh is NULL");
    log_error("udh is NULL");
    return 0;
  }

  if(udh[pos] > WMS_UDH_VAR_PIC_SIZE + 3) /*Length of information element*/
  {
    //MSG_ERROR_1("SMS UDH Header Var Picture Present with invalid data length = %d", udh[pos]);
    log_error("SMS UDH Header Var Picture Present with invalid data length = %d", udh[pos]);
    return 0;
  }

  if ( (udh[pos] - 3) != (udh[pos+2] * udh[pos+3]) )
  {
    //MSG_ERROR_0("SMS UDH Header Var Picture, pic size value mismatch with heigt and weight");
    log_error("SMS UDH Header Var Picture, pic size value mismatch with heigt and weight");
    return 0;
  }

  pic_size                                           = udh[pos++] -3;
  header_ptr->header_id                                 = WMS_UDH_VAR_PICTURE;
  header_ptr->u.var_picture.position                    = udh[pos++];
  if( udh[pos] * 8 < 256 )
  {
    header_ptr->u.var_picture.width                       = (uint8) (udh[pos++] * 8);
  }
  else
  {
    //MSG_ERROR_0("SMS UDH Header Var Picture, pic width is too large");
    log_error("SMS UDH Header Var Picture, pic width is too large");
    return 0;
  }

  header_ptr->u.var_picture.height                      = udh[pos++];

  for(j=0;j<pic_size && j<WMS_UDH_VAR_PIC_SIZE; j++)
    header_ptr->u.var_picture.data[j]             = udh[pos++];


  return pos;
}/*wms_ts_decode_udh_var_picture*/



/*static*/ uint8 wms_ts_decode_udh_user_prompt
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
)
{
  uint8 pos=0;

  if (udh == NULL || header_ptr == NULL )
  {
    //MSG_ERROR_0("udh is NULL");
    log_error("udh is NULL");
    return 0;
  }

  if(udh[pos] != 1) /*Length of information element*/
  {
    //MSG_ERROR_1("SMS UDH User Prompt present with invalid data length = %d", udh[pos]);
    log_error("SMS UDH User Prompt present with invalid data length = %d", udh[pos]);
    return 0;
  }

  pos ++; /* Skip udh length */

  header_ptr->header_id                                 = WMS_UDH_USER_PROMPT;
  header_ptr->u.user_prompt.number_of_objects           = udh[pos++];

  return (udh[0] + 1);

} /* wms_ts_decode_udh_user_prompt() */



/* Decoding UDH Extended Object
*/
/*static*/ uint8 wms_ts_decode_udh_eo
(
  const uint8 *udh,
  boolean     first_segment,
  wms_udh_s_type *header_ptr
)
{
  uint8 pos=0, udh_length;

  if (udh == NULL || header_ptr == NULL )
  {
    //MSG_ERROR_0("udh is NULL");
    log_error("udh is NULL");
    return 0;
  }

  if(udh[pos] == 0) /*Length of information element*/
  {
    //MSG_ERROR_0("SMS UDH Extended Object present with no Data");
    log_error("SMS UDH Extended Object present with no Data");
    return 0;
  }

  /* Get the length of this UDH */
  udh_length = udh[pos++];

  header_ptr->header_id                  = WMS_UDH_EXTENDED_OBJECT;
  header_ptr->u.eo.first_segment         = first_segment;

  if( first_segment == TRUE )
  {
    /* The following fields in the first segment occupy 7 bytes */
    if( udh_length < WMS_UDH_OCTETS_EO_HEADER || udh_length > WMS_UDH_EO_DATA_SEGMENT_MAX )
    {
      //MSG_ERROR_1(" SMS UDH Extended Object presents invalid UDHL:%d", udh_length);
      log_error(" SMS UDH Extended Object presents invalid UDHL:%d", udh_length);
      return 0;
    }

    header_ptr->u.eo.reference           = udh[pos++];
    header_ptr->u.eo.length              = udh[pos++] << 8;
    header_ptr->u.eo.length              |= udh[pos++];
    header_ptr->u.eo.control             = udh[pos++];
    header_ptr->u.eo.type                = (wms_udh_eo_id_e_type) udh[pos++];
    header_ptr->u.eo.position            = udh[pos++] << 8;
    header_ptr->u.eo.position            |= udh[pos++];
  }
  else /* first_segment  == FALSE */
  {
    if(udh_length > WMS_UDH_EO_DATA_SEGMENT_MAX)
    {
      //MSG_ERROR_1(" SMS UDH Extended Object presents invalid UDHL:%d", udh_length);
      log_error(" SMS UDH Extended Object presents invalid UDHL:%d", udh_length);
      return 0;
    }
  }
  /* Decode EO content */
  header_ptr->u.eo.content.length = (udh_length - pos) + 1;

  if( header_ptr->u.eo.content.length > 0 )
  {
    (void)memscpy( header_ptr->u.eo.content.data,
                   header_ptr->u.eo.content.length,
                   udh + pos,
                   header_ptr->u.eo.content.length );

    pos += header_ptr->u.eo.content.length;
  }

  return pos;

} /* wms_ts_decode_udh_eo() */



/*static*/ uint8 wms_ts_decode_udh_rfc822
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
)
{
  uint8 pos=0;

  if (udh == NULL || header_ptr == NULL )
  {
    //MSG_ERROR_0("udh is NULL");
    log_error("udh is NULL");
    return 0;
  }

  if(udh[pos] != 1) /*Length of information element*/
  {
    //MSG_ERROR_1("SMS UDH Header Rfc822 Present with invalid data length = %d", udh[pos]);
    log_error("SMS UDH Header Rfc822 Present with invalid data length = %d", udh[pos]);
    return 0;
  }

  pos++;
  header_ptr->header_id                                 = WMS_UDH_RFC822;
  header_ptr->u.rfc822.header_length                    = udh[pos++];

  return (udh[0] + 1);
}/*wms_ts_decode_udh_rfc822*/



/*static*/ uint8 wms_ts_decode_udh_nat_lang_ss
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
)
{
  uint8 pos=0;

  if (udh == NULL || header_ptr == NULL )
  {
    //MSG_ERROR_0("udh is NULL");
    log_error("udh is NULL");
    return 0;
  }

  if(udh[pos] != WMS_UDH_OCTETS_NAT_LANG_SS) /*Length of information element*/
  {
    //MSG_ERROR_1("SMS UDH National Lang Single Shift Present with invalid data length = %d", udh[pos]);
    log_error("SMS UDH National Lang Single Shift Present with invalid data length = %d", udh[pos]);
    return 0;
  }

  pos++;
  header_ptr->header_id                 = WMS_UDH_NAT_LANG_SS;
  /* Validate national language id */
  if (((uint8)WMS_UDH_NAT_LANG_TURKISH > udh[pos]) ||
      ((uint8)WMS_UDH_NAT_LANG_PORTUGUESE < udh[pos]))
  {
    //MSG_ERROR_1("SMS UDH National Lang Single Shift Present with invalid id = %d", udh[pos]);
    log_error("SMS UDH National Lang Single Shift Present with invalid id = %d", udh[pos]);
    return 0;
  }
  header_ptr->u.nat_lang_ss.nat_lang_id = (wms_udh_nat_lang_id_e_type)udh[pos++];

  return (udh[0] + 1);
}/*wms_ts_decode_udh_nat_lang_ss*/



/*static*/ uint8 wms_ts_decode_udh_nat_lang_ls
(
  const uint8 *udh,
  wms_udh_s_type *header_ptr
)
{
  uint8 pos=0;

  if (udh == NULL || header_ptr == NULL )
  {
    //MSG_ERROR_0("udh is NULL");
    log_error("udh is NULL");
    return 0;
  }

  if(udh[pos] != WMS_UDH_OCTETS_NAT_LANG_LS) /*Length of information element*/
  {
    //MSG_ERROR_1("SMS UDH National Lang Locking Shift Present with invalid data length = %d", udh[pos]);
    log_error("SMS UDH National Lang Locking Shift Present with invalid data length = %d", udh[pos]);
    return 0;
  }

  pos++;
  header_ptr->header_id                 = WMS_UDH_NAT_LANG_LS;
  /* Validate national language id */
  if (((uint8)WMS_UDH_NAT_LANG_TURKISH > udh[pos]) ||
      ((uint8)WMS_UDH_NAT_LANG_PORTUGUESE < udh[pos]))
  {
    //MSG_ERROR_1("SMS UDH National Lang Locking Shift Present with invalid id = %d", udh[pos]);
    log_error("SMS UDH National Lang Locking Shift Present with invalid id = %d", udh[pos]);
    return 0;
  }
  header_ptr->u.nat_lang_ls.nat_lang_id = (wms_udh_nat_lang_id_e_type)udh[pos++];

  return (udh[0] + 1);
}/*wms_ts_decode_udh_nat_lang_ls*/



/*static*/ uint8 wms_ts_decode_udh_other
(
  const uint8* udh,
  wms_udh_s_type *header_ptr
)
{
  uint8 pos=0, i=0;

  if (udh == NULL || header_ptr == NULL )
  {
    //MSG_ERROR_0("udh is NULL");
    log_error("udh is NULL");
    return 0;
  }

  if (udh[pos+1] > WMS_UDH_OTHER_SIZE)
  {
    //MSG_ERROR_0("SMS UDH Header Other data length exceeding 226");
    log_error("SMS UDH Header Other data length exceeding 226");
    return 0;
  }

  header_ptr->header_id                                 = (wms_udh_id_e_type) udh[pos];
  header_ptr->u.other.header_id                         = (wms_udh_id_e_type) udh[pos++];
  header_ptr->u.other.header_length                     = udh[pos++];

  for(i=0;i<header_ptr->u.other.header_length && i<WMS_UDH_OTHER_SIZE; i++)
  {
    header_ptr->u.other.data[i] = udh[pos++];
  }

  return (udh[1] + 1);
}



/*static*/ boolean wms_ts_udh_decode_first_seg_check
(
  const uint8  len,                /* user_data_length*/
  const uint8  *data,              /* first byte of user data */
  boolean      *is_first_segment_ptr      /* OUT */
)
{
  uint8 pos = 0;
  uint8 num_headers = 0;
  uint8 udhl = 0;
  uint8 iedl = 0;
  uint8 iei = 0;

  // Default to true - it might not have concat header present
  *is_first_segment_ptr = TRUE;

  if (data == NULL || data[pos] == 0 || len == 0 )
  {
    //MSG_ERROR_0("null in wms_ts_udh_decode_first_seg_check");
    log_error("null in wms_ts_udh_decode_first_seg_check");
    return FALSE;
  }

  // First byte is the UDH Length
  udhl = data[pos];

  if( (udhl+1) > MIN(len, WMS_GW_USER_DATA_LEN_MAX) )
  {
  /*
    MSG_ERROR_2( "Invalid UDHL %d (exceeds UD length %d)",
                 udhl + 1,
                 MIN(len, WMS_GW_USER_DATA_LEN_MAX) );
                 */
    log_error( "Invalid UDHL %d (exceeds UD length %d)",
                 udhl + 1,
                 MIN(len, WMS_GW_USER_DATA_LEN_MAX) );                 
    return FALSE;
  }
  // Move pos to first user data header
  pos++;

  while ((pos < udhl) && (num_headers < WMS_MAX_UD_HEADERS))
  {
      // First byte is UDH, next byte is length
      iei  = data[pos];
      iedl = data[pos+1];

      if( (pos + iedl + 2) > (udhl + 1) )
      {
        /* 1 (IEI) + 1 (IEDL) + IED */
				/*
        MSG_ERROR_3( "Invalid IEDL: pos(%d) + iedl(%d) + 2 > UDHL(%d) + 1",
                     pos,
                     iedl,
                     udhl );
                     */
        log_error( "Invalid IEDL: pos(%d) + iedl(%d) + 2 > UDHL(%d) + 1",
                     pos,
                     iedl,
                     udhl );
        return FALSE;
      }

      if ((uint8)WMS_UDH_CONCAT_16 == iei)
      {
          // For concat16 element, peek and see seq#
          // -------------------------------------------
          // || IEI | IEDL | Ref# | Ref# |Max# | Seq# ||
          // -------------------------------------------
          if ( (pos + 5 <= udhl) && (data[pos+5] != 1) )
          {
              //MSG_HIGH_0("WMS_UDH_CONCAT_16 not first segment");
              log_error("WMS_UDH_CONCAT_16 not first segment");
              *is_first_segment_ptr = FALSE;
              return TRUE;
          }
          else
          {
              return TRUE;
          }
      }
      // Not a concat header, so we dont care, skip over it's length
      else
      {
          num_headers++;
          pos += (2 + iedl); // IEI + IEDL + Actual Data Length
      }
  } // while

  return TRUE;
}



uint8 wms_ts_decode_user_data_header
(
  const uint8               len, /* user_data_length*/
  const uint8               *data, /* first byte of user data */
  uint8                     * num_headers_ptr, /* OUT */
  wms_udh_s_type            * udh_ptr          /* OUT */
)
{
  uint8 pos =0;
  uint8 header_length =0, num_headers=0;
  uint8 udhl;
  boolean    first_segment = TRUE; /* Used for Extended Object decoding */

  if (data == NULL || len == 0 || data[pos] == 0 || num_headers_ptr == NULL || udh_ptr == NULL )
  {
    //MSG_ERROR_0("null pointer in wms_ts_decode_user_data_header");
    log_error("null pointer in wms_ts_decode_user_data_header");
    return 0;
  }

  udhl = data[pos];

  if( (udhl+1) > MIN(len, WMS_GW_USER_DATA_LEN_MAX) )
  {
  /*
    MSG_ERROR_2( "Invalid UDHL %d (exceeds UD length %d)",
                 udhl + 1,
                 MIN(len, WMS_GW_USER_DATA_LEN_MAX) );
                 */
    log_error( "Invalid UDHL %d (exceeds UD length %d)",
                 udhl + 1,
                 MIN(len, WMS_GW_USER_DATA_LEN_MAX) );
    return FALSE;
  }

  pos++;

  while ((pos < udhl)&&(num_headers < WMS_MAX_UD_HEADERS))
  {

    header_length = 0;

    /*first byte - IEI*/
    /*second byte - IEDL */
    if( pos + 2 + data[pos + 1] > udhl + 1 )
    {
      return 0;
    }

    switch(data[pos])
    {
      case WMS_UDH_CONCAT_8:
        header_length = wms_ts_decode_udh_concat_8(data + pos + 1, &udh_ptr[num_headers]);
        break;

      case WMS_UDH_CONCAT_16:
        header_length = wms_ts_decode_udh_concat16(data + pos + 1, &udh_ptr[num_headers]);
        break;

      case WMS_UDH_SPECIAL_SM:
        header_length = wms_ts_decode_udh_special_sm(data + pos + 1, &udh_ptr[num_headers]);
        break;

      case WMS_UDH_PORT_8:
        header_length = wms_ts_decode_udh_port_8(data + pos + 1, &udh_ptr[num_headers]);
        break;

      case WMS_UDH_PORT_16:
        header_length = wms_ts_decode_udh_port16(data + pos + 1, &udh_ptr[num_headers]);
        break;

      case WMS_UDH_TEXT_FORMATING:
        header_length = wms_ts_decode_udh_text_formatting(data + pos + 1, &udh_ptr[num_headers]);
        break;

      case WMS_UDH_PRE_DEF_SOUND:
        header_length = wms_ts_decode_udh_pre_def_sound(data + pos + 1, &udh_ptr[num_headers]);
        break;

      case WMS_UDH_USER_DEF_SOUND:
        header_length = wms_ts_decode_udh_user_def_sound(data + pos + 1, &udh_ptr[num_headers]);
        break;

      case WMS_UDH_PRE_DEF_ANIM:
        header_length = wms_ts_decode_udh_pre_def_anim(data + pos + 1, &udh_ptr[num_headers]);
        break;

      case WMS_UDH_LARGE_ANIM:
        header_length = wms_ts_decode_udh_large_anim(data + pos + 1, &udh_ptr[num_headers]);
        break;

      case WMS_UDH_SMALL_ANIM:
        header_length = wms_ts_decode_udh_small_anim(data + pos + 1, &udh_ptr[num_headers]);
        break;

      case WMS_UDH_LARGE_PICTURE:
        header_length = wms_ts_decode_udh_large_picture(data + pos + 1, &udh_ptr[num_headers]);
        break;

      case WMS_UDH_SMALL_PICTURE:
        header_length = wms_ts_decode_udh_small_picture(data + pos + 1, &udh_ptr[num_headers]);
        break;

      case WMS_UDH_VAR_PICTURE:
        header_length = wms_ts_decode_udh_var_picture(data + pos + 1, &udh_ptr[num_headers]);
        break;

      case WMS_UDH_USER_PROMPT:
        header_length = wms_ts_decode_udh_user_prompt( data + pos + 1, &udh_ptr[num_headers]);
        break;

      case WMS_UDH_EXTENDED_OBJECT:
        if ( wms_ts_udh_decode_first_seg_check ( len, data, &first_segment ) == FALSE )
        {
          //MSG_ERROR_0("wms_ts_udh_decode_first_seg_check failed");
          log_error("wms_ts_udh_decode_first_seg_check failed");
          return 0;
        }
        header_length = wms_ts_decode_udh_eo( data + pos + 1, first_segment, &udh_ptr[num_headers]);
        break;

      case WMS_UDH_RFC822:
        header_length = wms_ts_decode_udh_rfc822(data + pos + 1, &udh_ptr[num_headers]);
        break;

      case WMS_UDH_NAT_LANG_SS:
        header_length = wms_ts_decode_udh_nat_lang_ss(data + pos + 1, &udh_ptr[num_headers]);
        break;

      case WMS_UDH_NAT_LANG_LS:
        header_length = wms_ts_decode_udh_nat_lang_ls(data + pos + 1, &udh_ptr[num_headers]);
        break;

      default:
        header_length = wms_ts_decode_udh_other(data + pos, &udh_ptr[num_headers]);
        break;
    } /* End of Switch */

    if(header_length != 0)
    {
      pos += header_length + 1;
      num_headers++;
    }
    else
    {
    /*
      MSG_ERROR_2( "Bad UDH: pos=%d, data[pos]=%d",
                   pos + 1,
                   data[pos + 1] );
                   */
      log_error( "Bad UDH: pos=%d, data[pos]=%d",
                   pos + 1,
                   data[pos + 1] );
      * num_headers_ptr = 0;
      return 0;  /* SHORT-RETURN */
    }
  } /* End of While loop */


  if (num_headers >= WMS_MAX_UD_HEADERS)
  {
    /* Num Headers has Exceeded Max */
    //MSG_ERROR_0("decode_udh: Num Headers has exceeded WMS_MAX_UD_HEADERS");
    log_error("decode_udh: Num Headers has exceeded WMS_MAX_UD_HEADERS");

    /* Placing the correct value */
    pos = udhl+1;
  }

  if (pos!= (udhl+1))
  {
    //MSG_ERROR_0("SMS UDH could not be decoded");
    log_error("SMS UDH could not be decoded");
    num_headers =0;
    udhl =0;
  }

  if (num_headers >0)
  {
    * num_headers_ptr = num_headers;
  }

  return udhl;
}




