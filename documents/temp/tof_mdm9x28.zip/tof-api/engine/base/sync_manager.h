#ifndef SYNC_MANAGER_H
#define SYNC_MANAGER_H



#include "type.h"



#ifdef __cplusplus
extern "C" {
#endif



//**************************************************************
// public member
//**************************************************************
//#define FEATURE_SYNC_MANAGER_TEST



#define				sync_manager_default_max_sync_object_num 					( 64 )


#ifdef FEATURE_SYNC_MANAGER_TEST
#define				sync_manager_default_sync_timeout_millisecond						( 200 )		// 200 msec for test
#else
#define				sync_manager_default_sync_timeout_millisecond						( 60 * 1000 )		// 60 sec 
#endif



typedef unsigned int sync_object_index_type;

#define				invalid_sync_object_index					( 0xFFFFFFFF )



typedef struct
{
	unsigned int max_sync_object_num;
	unsigned int max_sync_timeout_millisecond;
	int				 use_garbage_collection;
} sync_manager_init_info_s;



//**************************************************************
// public function
//**************************************************************
int	sync_manager_init( const sync_manager_init_info_s* const init_info );
void	sync_manager_release( void );

int	sync_manager_enter_sync( const void* const user_data, sync_object_index_type* sync_obj_index );
int	sync_manager_get_enter_sync_object_user_data( const sync_object_index_type sync_obj_index, void** user_data );
int	sync_manager_leave_sync( const sync_object_index_type sync_obj_index );
int	sync_manager_wait_sync( const sync_object_index_type sync_obj_index );



#ifdef __cplusplus
}
#endif



#endif
