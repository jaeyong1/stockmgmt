#ifndef WMS_ENGINE_H
#define WMS_ENGINE_H



#include "engine.h"



#ifdef __cplusplus
extern "C" {
#endif



//**************************************************************
// public member
//**************************************************************
#define WMS_INVALID_CAUSE_CODE								( 0xFFFF )
#define WMS_INVALID_GW_RP_CAUSE								( 0xFFFF )
#define WMS_INVALID_GW_TP_CAUSE								( 0xFF )



typedef enum
{
	wms_msg_tag_type_mt_read,
	wms_msg_tag_type_mt_not_read,
	wms_msg_tag_type_mo_sent,
	wms_msg_tag_type_mo_not_sent
} wms_msg_tag_type_e;



typedef enum
{
	wms_memory_store_type_none = -1,
	wms_memory_store_type_uim 	= 0,
	wms_memory_store_type_nv 	= 1,
	wms_memory_store_type_max
} wms_memory_store_type_e;



typedef enum
{
	wms_memory_status_not_available,
	wms_memory_status_available
} wms_memory_status_e;



typedef struct
{
	unsigned int 				message_index;
	wms_msg_tag_type_e message_tag_type;
} wms_message_info_s;



//
typedef struct
{
	wms_raw_ts_data_s_type raw_message_data;
} DUBU_request_wms_send_sms_s;

typedef struct
{
	wms_raw_ts_data_s_type raw_message_data;
} DUBU_request_wms_send_sms_pdu_s;

typedef struct
{
	DUBU_response_base_s DUBU_response_base;
	unsigned short 	message_id;
	unsigned short	cause_code;
	unsigned short	gw_rp_cause;
	unsigned char		gw_tp_cause;
} DUBU_response_wms_send_sms_s;

typedef struct
{
	DUBU_response_base_s DUBU_response_base;
	unsigned short 	message_id;
	unsigned short	cause_code;
	unsigned short	gw_rp_cause;
	unsigned char		gw_tp_cause;
} DUBU_response_wms_send_sms_pdu_s;

//
typedef struct
{
	unsigned int message_index;
	wms_memory_store_type_e memory_store_type;
} DUBU_request_wms_read_sms_s;

typedef struct
{
	DUBU_response_base_s DUBU_response_base;
	wms_raw_ts_data_s_type raw_message_data;
} DUBU_response_wms_read_sms_s;

//
typedef struct
{
	unsigned int message_index;
	wms_memory_store_type_e memory_store_type;
} DUBU_request_wms_delete_sms_s;

typedef struct
{
	DUBU_response_base_s DUBU_response_base;
} DUBU_response_wms_delete_sms_s;

//
typedef struct
{
	wms_memory_store_type_e memory_store_type;
} DUBU_request_wms_list_sms_s;

typedef struct
{
	DUBU_response_base_s DUBU_response_base;
	unsigned int				message_info_num;
	wms_message_info_s message_info[ WMS_MESSAGE_LIST_MAX ];
} DUBU_response_wms_list_sms_s;

//
typedef struct
{
} DUBU_request_wms_get_smsc_address_s;
typedef DUBU_request_wms_get_smsc_address_s		request_get_smsc_address_s;

typedef struct
{
	DUBU_response_base_s DUBU_response_base;
	unsigned int	smsc_address_digits_length;
	unsigned char smsc_address_digits[ WMS_GW_ADDRESS_MAX + 1 ];
} DUBU_response_wms_get_smsc_address_s;
typedef DUBU_response_wms_get_smsc_address_s	response_get_smsc_address_s;

//
typedef struct
{
	unsigned char* smsc_address_digits;
} DUBU_request_wms_set_smsc_address_s;
typedef DUBU_request_wms_set_smsc_address_s		request_set_smsc_address_s;

typedef struct
{
	DUBU_response_base_s DUBU_response_base;
} DUBU_response_wms_set_smsc_address_s;
typedef DUBU_response_wms_set_smsc_address_s	response_set_smsc_address_s;

//
typedef struct
{
} DUBU_request_wms_get_memory_status_s;
typedef DUBU_request_wms_get_memory_status_s		request_get_memory_status_s;

typedef struct
{
	DUBU_response_base_s DUBU_response_base;
	wms_memory_status_e memory_available;
} DUBU_response_wms_get_memory_status_s;
typedef DUBU_response_wms_get_memory_status_s		response_get_memory_status_s;

//
typedef struct
{
	unsigned int message_index;
} DUBU_indication_wms_new_sms_s;



//**************************************************************
// public function
//**************************************************************



#ifdef __cplusplus
}
#endif



#endif

