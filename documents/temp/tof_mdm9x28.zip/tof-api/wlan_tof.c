#include <stdio.h>
#include "wlan_tof.h"

void print_system_function_output(char* output,char* cmd)
{
	FILE *fp=NULL;
	int readSize=0;

	fp=popen(cmd,"r");
	if(!fp)
	{
		printf("error\n");
	}
	readSize = fread( (void*)output, sizeof(char), 256-1, fp );

	if( readSize == 0 )
	{
	    pclose(fp);
		return;
	}
	pclose(fp);
	output[readSize]='\0';

 }

bool unload_wifimodule()
{
	char* cmd = "rmmod wlan";
	char buffer[BUFFER_MAX_LENGTH]={NULL,};
		
	system(cmd);
	print_system_function_output(buffer,"ifconfig -a|grep wlan0");

	if(strstr(buffer,"wlan0")!=NULL)
	{
		printf("DEBUG\n");
		return FALSE;
	}

	return TRUE;
}

bool load_wifimodule()
{
	char* cmd = "insmod /usr/lib/modules/3.18.20/extra/wlan.ko mmcclock=100000000";
	char buffer[BUFFER_MAX_LENGTH]={NULL,};

	system(cmd);
	print_system_function_output(buffer,"ifconfig -a|grep wlan0");

	if(strstr(buffer,"wlan0")==NULL)
	{
		return FALSE;
	}

	return TRUE;


}


bool check_wifi_connection()
{

	FILE *fp=NULL;
	char buffer[BUFFER_MAX_LENGTH]={NULL,};
	int fail_cnt=0;
	int success_cnt=0;

	printf("Verifying wifi connection");
	while(1)
	{
		
		print_system_function_output(buffer,"iw wlan0 link");
		if(strstr(buffer,"Not connected."))
		{
			putchar('.');
			fail_cnt+=1;
			if(fail_cnt==15)
				return FALSE;
			sleep(1);
			fflush(stdout);
		}else
		{
			putchar('.');
			success_cnt+=1;
			if(success_cnt>3)
			{
				printf("\n");	
				break;
			}
			sleep(1);
			fflush(stdout);			

		}
	}
	printf("\n");	
	return TRUE;

}

int disconnect_wifi()
{
	char buffer[BUFFER_MAX_LENGTH]={NULL,};
	char PID[10]={NULL,};

	if(strstr(buffer,"Not connected."))
		return FALSE;
	
	print_system_function_output(PID,"pgrep wpa_supplicant");
	snprintf(buffer,sizeof(buffer),"kill -9 %s",PID);
	system(buffer);
	memset(buffer,0,BUFFER_MAX_LENGTH);
	print_system_function_output(PID,"pgrep dhcpcd");
	snprintf(buffer,sizeof(buffer),"kill -9 %s",PID);
	system(buffer);

	system("iw wlan0 disconnect");

	return TRUE;

}

int connect_wifi(char* ssid, char* pw, int encryption)
{
	char buffer[BUFFER_MAX_LENGTH]={NULL,};
	if(encryption < 0)
	{
		printf("Please set WiFi encryption in advance\n");		
		return FALSE;
	}

	printf("SSID:%s, PW:%s\n",ssid,( pw==NULL?"NONE":pw));  

	//Remove all of iptables rule chain to prevent kernel panic by redirecting iptables.
	system("iptables -F");
	system("iptables -t nat -F");
	system("iptables -t mangle -F");		
	system("iptables -X");		

	system("ifconfig wlan0 up");
	system("wpa_supplicant -Dnl80211 -iwlan0 -c/etc/wpa_supplicant.conf -B");

	system("wpa_cli -iwlan0 remove_network 0");
	system("wpa_cli -iwlan0 add_network 0");
	//SET SSID
	snprintf(buffer,sizeof(buffer),"wpa_cli -iwlan0 set_network 0 ssid '\"%s\"'",ssid);
	system(buffer); 			
	//buffer AE��aE�� 
	memset(buffer,0,BUFFER_MAX_LENGTH);
	//SET PW
	snprintf(buffer,sizeof(buffer),"wpa_cli -iwlan0 set_network 0 psk '\"%s\"'",pw);
	system(buffer);



	switch(encryption)
	{
		case OPEN:{
				system("wpa_cli -iwlan0 set_network 0 key_mgmt NONE");			
				break;
		}
		case WPA_TKIP:{
				system("wpa_cli -iwlan0 set_network 0 key_mgmt WPA-PSK");
				system("wpa_cli -iwlan0 set_network 0 pairwise TKIP");
				system("wpa_cli -iwlan0 set_network 0 group TKIP");
				system("wpa_cli -iwlan0 set_network 0 proto WPA");
				break;
		}
		case WPA_AES:{
				system("wpa_cli -iwlan0 set_network 0 key_mgmt WPA-PSK");
				system("wpa_cli -iwlan0 set_network 0 pairwise CCMP");
				system("wpa_cli -iwlan0 set_network 0 group CCMP");
				system("wpa_cli -iwlan0 set_network 0 proto WPA");
				break;
		}
		case WPA2_TKIP:{
			  system("wpa_cli -iwlan0 set_network 0 key_mgmt WPA-PSK");
				system("wpa_cli -iwlan0 set_network 0 pairwise TKIP");
				system("wpa_cli -iwlan0 set_network 0 group TKIP");
				system("wpa_cli -iwlan0 set_network 0 proto RSN");
				break;
		}
		case WPA2_AES:{
				system("wpa_cli -iwlan0 set_network 0 key_mgmt WPA-PSK");
				system("wpa_cli -iwlan0 set_network 0 pairwise CCMP");
				system("wpa_cli -iwlan0 set_network 0 group CCMP");
				system("wpa_cli -iwlan0 set_network 0 proto RSN");
				break;
		}
		case WPAWPA2_TKIPAESES:{
				system("wpa_cli -iwlan0 set_network 0 key_mgmt WPA-PSK");
				system("wpa_cli -iwlan0 set_network 0 pairwise CCMP TKIP");
				system("wpa_cli -iwlan0 set_network 0 group CCMP TKIP");
				system("wpa_cli -iwlan0 set_network 0 proto WPA RSN");
				break;
		}
		default:{
				printf("Please set valid parameter\n");		
				return FALSE; 															 
		}
	}
	
	system("wpa_cli -iwlan0 enable_network 0");  
	//assign IP from DHCP
	system("dhcpcd wlan0&");
	//NAT Setting

	if(!check_wifi_connection())
	{
		disconnect_wifi();
		return FALSE;	
	}

	system("iptables -A FORWARD -i bridge0 -j ACCEPT");
	system("iptables -A FORWARD -o bridge0 -j ACCEPT");
	system("iptables --table nat -A POSTROUTING --out-interface wlan0 -j MASQUERADE");
	//Refresh RNDIS0
	system("ifconfig rndis0 down");
	system("ifconfig rndis0 up");

	return TRUE;
}

