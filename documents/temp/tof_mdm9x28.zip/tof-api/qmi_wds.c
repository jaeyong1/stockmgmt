#include <string.h>
#include <netinet/in.h>
#include "qmi.h"
#include "qmi_wds.h"

qmi_client_handle_type g_wds_client_handle = QMI_INVALID_CLIENT_HANDLE;

boolean qmi_wds_indication_cb( int user_handle,
                               qmi_service_id_type service_id,
                               void* user_data,
                               qmi_wds_indication_id_type ind_id,
                               qmi_wds_indication_data_type* ind_data_ptr )

{
  return TRUE;
}

boolean tof_qmi_wds_init( void )
{
  int qmi_err_code = QMI_NO_ERR;
  
  if(g_wds_client_handle != QMI_INVALID_CLIENT_HANDLE)
  return RESULT_SUCCESS;
  
  /* Bring up WDS service */
  if ((g_wds_client_handle = qmi_wds_srvc_init_client (QMI_PORT_RMNET_0,
                                                       qmi_wds_indication_cb, // callback function. 
                                                       NULL, 
                                                       &qmi_err_code)) < 0)
  {
    MSG_ERROR("Unable to start WDS service wds_client_handle= %x, qmi_err_code=%x \n", g_wds_client_handle, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    MSG_HIGH("Opened WDS Client. wds_client_handle= %x \n", g_wds_client_handle, 0, 0);
  }
  
  return RESULT_SUCCESS;
}


boolean tof_qmi_wds_release()
{
  int r            = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;

  if ( INVALID_HANDLE_VALUE == g_wds_client_handle )
  {
    MSG_ERROR( "tof_qmi_wds_release invalid client handle, g_wds_client_handle:%d \n", g_wds_client_handle, 0, 0 );
    return RESULT_FAILURE;
  }
  
  r = qmi_wds_srvc_release_client( (int)g_wds_client_handle, &qmi_err_code );

  if ( QMI_NO_ERR != r || QMI_SERVICE_ERR_NONE != qmi_err_code )
  {
    MSG_ERROR( "tof_qmi_wds_release qmi_wds_srvc_release_client() fail, r:%d, qmi_err_code:%d \n", r, qmi_err_code, 0 );
    return RESULT_FAILURE;
  }

  g_wds_client_handle = INVALID_HANDLE_VALUE;

  MSG_HIGH("tof_qmi_wds_release wds_client_handle= %x \n", g_wds_client_handle, 0, 0);
  
  return RESULT_SUCCESS;
}

boolean	qmi_wds_get_profile_info( uint32 index, qmi_wds_profile_info_type* info )
{
  int r            = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;

  qmi_wds_profile_id_type       profile_id;  
  qmi_wds_profile_params_type   profile_params;

  memset( &profile_id, 0x0, sizeof( profile_id ) );
  memset( &profile_params, 0x0, sizeof( profile_params ) );

  profile_id.profile_index = index;
  profile_id.technology    = QMI_WDS_PROFILE_TECH_3GPP;

  r = qmi_wds_query_profile( (int)g_wds_client_handle, &profile_id, &profile_params, &qmi_err_code );

  if( QMI_NO_ERR != r || QMI_SERVICE_ERR_NONE != qmi_err_code )
  {
    MSG_ERROR( "[WDS] qmi_wds_query_profile() fail, r:%d, qmi_err_code:%d \n", r, qmi_err_code, 0 );
    return FALSE;
  }

  if((profile_params.umts_profile_params.param_mask & QMI_WDS_UMTS_PROFILE_PDP_TYPE_PARAM_MASK) &&
     (profile_params.umts_profile_params.param_mask & QMI_WDS_UMTS_PROFILE_APN_NAME_PARAM_MASK))
  {
    info->pdp_type = profile_params.umts_profile_params.pdp_type;
    strcpy( info->apn, profile_params.umts_profile_params.apn_name );
  }
  else
  {
    MSG_ERROR( "[WDS] Invalid parameter mask \n", 0, 0, 0);
    return FALSE;
  }

  return TRUE;
}


boolean qmi_wds_set_profile_info( uint32 index, uint64 param_mask, qmi_wds_profile_info_type* info )
{
  int r            = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;

  qmi_wds_profile_id_type       profile_id;  
  qmi_wds_profile_params_type   profile_params;

  memset( &profile_id, 0x0, sizeof( profile_id ) );
  memset( &profile_params, 0x0, sizeof( profile_params ) );

  profile_id.profile_index = index;
  profile_id.technology    = QMI_WDS_PROFILE_TECH_3GPP;

  profile_params.umts_profile_params.param_mask = param_mask;
  profile_params.umts_profile_params.pdp_type   = info->pdp_type;
  strcpy( profile_params.umts_profile_params.apn_name, info->apn );

  r = qmi_wds_modify_profile( (int)g_wds_client_handle, &profile_id, &profile_params, &qmi_err_code );
  
  if ( QMI_NO_ERR != r || QMI_SERVICE_ERR_NONE != qmi_err_code )
  {
    MSG_ERROR( "[WDS] qmi_wds_modify_profile() fail, r:%d, qmi_err_code:%d \n", r, qmi_err_code, 0 );
    return FALSE;
  }

  return TRUE;
}

boolean qmi_wds_add_profile_info( uint32 index )
{
  int r            = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  int i;

  qmi_wds_profile_id_type       profile_id;  
  qmi_wds_profile_params_type   profile_params;

  if(index > TOF_QMI_3GPP_PROFILE_LIST_MAX)
  {
    MSG_ERROR( "[WDS] Invalid profile index \n", 0, 0, 0);
    return FALSE;
  }

  memset( &profile_id, 0x0, sizeof( profile_id ) );
  memset( &profile_params, 0x0, sizeof( profile_params ) );

  profile_id.technology = QMI_WDS_PROFILE_TECH_3GPP;

  for(i = 0 ; i < TOF_QMI_3GPP_PROFILE_LIST_MAX ; i++)
  {
    r = qmi_wds_create_profile( (int)g_wds_client_handle, &profile_id, &profile_params, &qmi_err_code );

    if ( QMI_NO_ERR == r && QMI_SERVICE_ERR_NONE == qmi_err_code )
    {
      if( profile_id.profile_index >= index )
      {
        MSG_HIGH( "[WDS] qmi_wds_add_profile_info() index:%d\n", profile_id.profile_index, 0, 0 );
        return TRUE;
      }
    }
  }

  return FALSE;
}

qmi_wds_pdp_type qmi_wds_convert_pdp_type_qcmap_to_wds(tof_qcmap_msgr_ip_family_enum_v01 ip_family)
{
  qmi_wds_pdp_type pdp_type = QMI_WDS_PDP_TYPE_IPV4V6;
  
  switch(ip_family)
  {
    case TOF_QCMAP_MSGR_IP_FAMILY_V4_V01:
      pdp_type = QMI_WDS_PDP_TYPE_IP;
      break;
    case TOF_QCMAP_MSGR_IP_FAMILY_V6_V01:
      pdp_type = QMI_WDS_PDP_TYPE_IPV6;
      break;
    default:
      break;
  }

  return pdp_type;
}

tof_qcmap_msgr_ip_family_enum_v01 qmi_wds_convert_pdp_type_wds_to_qcmap(qmi_wds_pdp_type pdp_type)
{
  tof_qcmap_msgr_ip_family_enum_v01 ip_family = TOF_QCMAP_MSGR_IP_FAMILY_V4V6_V01;
  
  switch(pdp_type)
  {
    case QMI_WDS_PDP_TYPE_IP:
      ip_family = TOF_QCMAP_MSGR_IP_FAMILY_V4_V01;
      break;
    case QMI_WDS_PDP_TYPE_IPV6:
      ip_family = TOF_QCMAP_MSGR_IP_FAMILY_V6_V01;
      break;
    default:
      break;
  }

  return ip_family;
}

