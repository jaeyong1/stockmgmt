#ifndef WMMDIAG_PACKET_CDMA_H
#define WMMDIAG_PACKET_CDMA_H

/*===========================================================================

HEADER WMMDIAG_PACKET_CDMA

DESCRIPTION
  
===========================================================================*/


#include "wmmdiag_packet_common.h"


#pragma pack(1)
#define PACKED

/*===========================================================================
  Constant Define
===========================================================================*/

#define WMM_DIAG_CDMA_NV_ITEM_SIZE 128

#define WMM_DIAG_CDMA_NV_AKEY_SIZE 26

#define WMM_DIAG_CDMA_PR_LIST_BLOCK_SIZE 120   /* Size in bytes of the PR_LIST block */

#define WMM_DIAG_CDMA_NETWORK_NAME_LEN 32

#define WMM_DIAG_CDMA_REGISTRATION_STR_LEN  128

#define WMM_DIAG_CDMA_DBG_INFO_MAX_PSC 3

#define WMM_DIAG_CDMA_HMBASIC_VER_LEN 20

#define WMM_DIAG_CDMA_ESN_LEN 8

#define WMM_DIAG_CDMA_MEID_LEN 14

#define WMM_DIAG_CDMA_MIN2_LEN 3

#define WMM_DIAG_CDMA_MIN1_LEN 7

#define CDMA_MAX_NUMBER_OF_INFO_RECS  10  //jisim_110716 CDMA RIL �� define �� ���� �����ϰ� ������
#define  MAX_ALPHA_TAG_CHARS    64 
#define  LVCMM_MAX_NUMBER_CHARS        (81)  /*  max. 80bytes + 1byte 3GPP spec. 24.008(Rel 5) 10.5.4.7  called party BCD digits  */
/*===========================================================================
  Structure Define
===========================================================================*/
typedef PACKED struct
{
  uint16 psc; // Active SET
  int16 ecio; // ASET ECIO
} wmmdiag_cdma_dbg_info_psc;

typedef PACKED struct
{
  /* command parameters */
  uint16 reg_zone;
  uint16 packet_zone;
  uint8 bs_p_rev;
  uint8 p_rev_in_use;
  uint8 is_registered;
  uint8 ccs_supported;
  int32 uz_id;
  uint8 srch_win_n;
  int32 base_lat;
  int32 base_long;
  uint16 base_id;

  uint8 reject_srv_domain;
  uint8 reject_cause;

  uint8 active_status;
  uint8 service_option;
  uint8 slot_cycle_index;
  uint8 cdma_lock_mode;

  uint8 curr_nam;
  uint8 ps_data_suspend;
  uint8 packet_state;
  
  /* 1x related parameters */
  uint8 service_status;
  uint16 roam_status;
  uint16 sid;
  uint16 nid;
  uint16 mcc;
  uint8 imsi_11_12;
  uint16 active_band;
  uint16 active_channel;
  int16 rssi;
  int16 ecio;
  int16 tx_pwr;
  int16 tx_adj;
  wmmdiag_cdma_dbg_info_psc psc[WMM_DIAG_CDMA_DBG_INFO_MAX_PSC];
  uint16 frame_err_rate;

  /* Evdo related parameters */
  uint8 hdr_service_status;
  uint16 hdr_roam_status;
  uint16 hdr_sid;
  uint16 hdr_nid;
  uint16 hdr_mcc;
  uint8 hdr_imsi_11_12;
  uint16 hybrid_active_band;
  uint16 hybrid_active_channel;
  int16 hdr_rssi;
  int16 hdr_ecio;
  uint8 hdr_sinr;
  uint16 hdr_packet_err_rate;
  /* 20120229, add more items */
  uint16 serving_pn;
  uint8 prot_state;
  uint8 hdr_session_state;
  uint32 uati24;
  uint8  color_code;
  uint8 uati_subnet_mask;
  uint8 sector_color_code;
  uint32 attempts_count;
  uint32 success_count;
  uint32 failure_count;
  uint32 dl_rate;
  uint32 ul_rate;
  uint8 fcp_enabled;
  uint8 sector_id[16];

  /* command more... */
  uint8 rf_mode;
  uint8 ac_state;
  uint8 rat; //serving network type
} wmmdiag_cdma_dbg_info_type;

typedef PACKED struct
{
  uint16 year;
  uint16 month;
  uint16 day;
  uint16 day_of_week;  
  uint16 hour;
  uint16 minute;
  uint16 second;
} wmmdiag_cdma_time_info_type;

typedef PACKED struct
{
  uint8 protoc_ver[WMM_DIAG_CDMA_HMBASIC_VER_LEN+1];
  uint8 sw_ver[WMM_DIAG_CDMA_HMBASIC_VER_LEN+1];
  uint8 hw_ver[WMM_DIAG_CDMA_HMBASIC_VER_LEN+1];
  uint8 rf_cal_ver[WMM_DIAG_CDMA_HMBASIC_VER_LEN+1];
  uint8 model_name[WMM_DIAG_CDMA_HMBASIC_VER_LEN+1];
  uint8 current_nam;
  uint8 modem_number[WMM_DIAG_CDMA_HMBASIC_VER_LEN+1];
  uint32 min1; 
  uint16 min2;
  uint16 mcc;
  uint8 imsi_11_12;
  uint32 esn;
  qword meid;
  uint8 service_status;
  int16 rssi;
  int16 ecio;
  int16 hdr_rssi;
  int16 hdr_ecio;
  uint8 hdr_sinr;
  uint16 sid;
  uint16 nid;
  uint8 network_name[WMM_DIAG_CDMA_NETWORK_NAME_LEN+1];
  uint16 prl_version;
  uint8 debug_info[4]; //debug_info[0] : Exception Counter, debug_info[1] : Nand Memory Tpye, debug_info[2] : QMI support
} wmmdiag_cdma_device_info_type;

typedef PACKED struct
{
  uint8 service_status;
  uint16 roam_status;
  uint16 sid;
  uint16 nid;
  uint16 active_band;
  uint16 active_channel;
  uint16 hybrid_active_band;
  uint16 hybrid_active_channel;
} wmmdiag_cdma_service_status_info_type;

//jisim_110716
/* Ril.h�� RIL_CDMA_InfoRecName �� �迭�� ���ƾ� �Ѵ� !!  Names of the CDMA info records (C.S0005 section 3.7.5) */ 
typedef enum {
  CDMA_DISPLAY_INFO_REC,
  CDMA_CALLED_PARTY_NUMBER_INFO_REC,
  CDMA_CALLING_PARTY_NUMBER_INFO_REC,
  CDMA_CONNECTED_NUMBER_INFO_REC,
  CDMA_SIGNAL_INFO_REC,
  CDMA_REDIRECTING_NUMBER_INFO_REC,
  CDMA_LINE_CONTROL_INFO_REC,
  CDMA_EXTENDED_DISPLAY_INFO_REC,
  CDMA_T53_CLIR_INFO_REC,
  CDMA_T53_RELEASE_INFO_REC,
  CDMA_T53_AUDIO_CONTROL_INFO_REC
} CDMA_InfoRecName;

/* CDMA Signal Information Record as defined in C.S0005 section 3.7.5.5 */
typedef PACKED struct {
  boolean isPresent;    /* non-zero if signal information record is present */
  uint8 signalType;   /* as defined 3.7.5.5-1 *//**< Signal type - Tone Signal, ISDN Alerting or IS-54B Alerting */
  uint8 alertPitch;   /* as defined 3.7.5.5-2 */ /**< Alert pitch - Medium, High or Low */
  uint8 signal;       /* as defined 3.7.5.5-3, 3.7.5.5-4 or 3.7.5.5-5 */    /**< Indicate which Tone signals, ISDN Alerting or IS_54B Alerting */
} CDMA_SignalInfoRecord;  
 
typedef PACKED struct {  
  uint8           number_type;       /*  number type (international : 0x1)  */
  uint8           number_plan;    /*  number plan id. (ISDN/Telephony numbering : 0x1) */	
  uint8           num_len;        /*  number length  */
  uint8           num_buf[LVCMM_MAX_NUMBER_CHARS]; /*  num buffer  */
  uint8           pi;             /*  presentation indicator : 0x00(allowed), 0x01(restricted), 0x02(not available)  */
  uint8           si;             /*  screening indicator  */
}num_info_s_type;

typedef PACKED struct 
{
  uint8             buf[MAX_ALPHA_TAG_CHARS];
  uint8             len;
} cdma_alpha_s_type;

typedef PACKED struct 
{
    /* Line control parameters    */
  uint8   line_ctrl_polarity_included;      /* TRUE if polarity info included      */
  uint8   line_ctrl_toggle;      /* TRUE = toggle polarity      */
  uint8   line_ctrl_reverse;      /* TRUE = reverse polarity      ** FALSE = normal polarity      */
  uint8   line_ctrl_power_denial;      /* Power denial time      */
}line_ctrl_s_type;

typedef PACKED struct 
{  
  uint8                                info_count;      // info rec �� ����
  uint8       name[CDMA_MAX_NUMBER_OF_INFO_RECS];
  num_info_s_type              calling_party_num;  
 // num_info_s_type              redirect_party_num;  // ���� ä���� ������� �������̶� ���� 
  CDMA_SignalInfoRecord           signal;          
  num_info_s_type              called_party_num;  
  num_info_s_type              connected_party_num;  
  cdma_alpha_s_type           display_info;
  cdma_alpha_s_type           ext_display_info;
  line_ctrl_s_type               line_ctrl;
  } wmmdiag_CDMA_InfomationRecord_type;

//jisim_120814  
typedef PACKED struct
{
  uint8 cs_state;
  uint8 ps_state; 
  uint8   roam_indicator_value;
  uint16  sid;
  uint16  nid;
  uint16  base_id;
  int32   base_lat;
  int32   base_long;
  uint8   def_roam_ind;
  uint8   ccs;
  uint8   prl_ind; //whether the current system is in the PRL 
  uint8   current_act;
} wmmdiag_total_cdma_reg_state_info_type;

/*===========================================================================
  Type Define
===========================================================================*/



#pragma pack()


#endif /*WMMDIAG_PACKET_CDMA_H*/
