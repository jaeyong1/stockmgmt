#ifndef QMI_IMSA_SRVC_H
#define QMI_IMSA_SRVC_H

/******************************************************************************
  @file    qmi_imsa_srvc.h
  @brief   QMI message library IMSA service definitions

  DESCRIPTION
  This file contains common, external header file definitions for QMI
  interface library.

  INITIALIZATION AND SEQUENCING REQUIREMENTS
  qmi_imsa_srvc_init_client() must be called to create one or more clients
  qmi_imsa_srvc_release_client() must be called to delete each client when
  finished.

  $Header: //source/qcom/qct/modem/datacommon/qmimsglib/dev/work/inc/qmi_imsa_srvc.h#5 $
  $DateTime: 2009/07/15 10:38:12 $
  ---------------------------------------------------------------------------
  Copyright (c) 2013 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/

#include "qmi.h"
#include "wmmdiag_packet.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef QMI_IMSA_SERVICE
#define QMI_IMSA_SERVICE  0x21
#endif

#define IMSA_SETTINGS_STRING_LEN_MAX_V01 255

typedef enum
{
    REQUEST_VOIP_SERVICE_STATUS     = 0
} imsa_service_status_type;

/* Custom named TLV IDs*/

/** @addtogroup imss_qmi_enums
    @{
  */

/**
    @}
  */

/*---------------------------------------------------------------------------
 QMI_IMSA_GET_IMS_REG_STATUS_INFO
---------------------------------------------------------------------------*/
#define IMSA_0020_RSP_T10        (0x10)
#define IMSA_0020_RSP_T11        (0x11)

typedef struct
{
  struct imsa_0020_rsp_t10_s
  {
    boolean ims_registered;
  } t10;

  struct imsa_0020_rsp_t11_s
  {
    uint16 ims_registration_failure_error_code;
  } t11;

  boolean t10_valid;
  boolean t11_valid;
}imsa_0020_rsp_s;

/*---------------------------------------------------------------------------
 QMI_IMSA_GET_SERVICE_STATUS_INFO
---------------------------------------------------------------------------*/
#define IMSA_0021_RSP_T10        (0x10)
#define IMSA_0021_RSP_T11        (0x11)

typedef struct
{
  struct imsa_0021_rsp_t11_s
  {
    uint32 voip_service_status;
  } t11;

  boolean t11_valid;
}imsa_0021_rsp_s;

/*---------------------------------------------------------------------------
  QMI_IMSA_INDICATION_REGISTER
---------------------------------------------------------------------------*/
#define IMSA_0022_REQ_T10      (0x10)
#define IMSA_0022_REQ_T11      (0x11)
#define IMSA_0022_REQ_T14      (0x14)

typedef struct{
  struct imsa_0022_req_t10_s {
    uint8 reg_status_config;
  } t10;
  
  struct imsa_0022_req_t11_s {
    uint8 service_status_config;
  } t11;

  struct imsa_0022_req_t14_s {
    uint8 acs_status_config;
  } t14;

  boolean t10_valid;
  boolean t11_valid;
  boolean t14_valid;
}imsa_0022_req_s;

/*---------------------------------------------------------------------------
  QMI_IMSA_IMS_REG_STATUS_IND
---------------------------------------------------------------------------*/

#define IMSA_0023_IND_T01                      0x01
#define IMSA_0023_IND_T10                      0x10

typedef struct{
  struct imsa_0023_ind_t01_s {
    boolean ims_registered;
  } t01;
  
  struct imsa_0023_ind_t10_s {
    uint16 ims_registration_failure_error_code;
  } t10;
  
  boolean t01_valid;
  boolean t10_valid;
}imsa_0023_ind_s;

/*---------------------------------------------------------------------------
  QMI_IMSA_SERVICE_STATUS_IND
---------------------------------------------------------------------------*/

#define IMSA_0024_IND_T10                      0x10
#define IMSA_0024_IND_T11                      0x11

typedef struct{
  struct imsa_0024_ind_t10_s {
    uint32 sms_service_status;
  } t10;
  
  struct imsa_0024_ind_t11_s {
    uint32 voip_service_status;
  } t11;
  
  boolean t10_valid;
  boolean t11_valid;
}imsa_0024_ind_s;

/*---------------------------------------------------------------------------
  QMI_IMSA_ACS_STATUS_IND
---------------------------------------------------------------------------*/

#define IMSA_0027_IND_T01                      0x01
#define IMSA_0027_IND_T10                      0x10

typedef struct{
  struct imsa_0027_ind_t01_s {
    uint32 acs_failure_status_code;
  } t01;
  
  struct imsa_0027_ind_t10_s {
    uint16 acs_failure_error_code;
  } t10;
  
  boolean t01_valid;
  boolean t10_valid;
}imsa_0027_ind_s;

/* Distinguishes indication message types */

typedef enum
{
   QMI_IMSA_SRVC_SERVICE_STATUS_IND_V01,
   QMI_IMSA_SRVC_REGISTRATION_STATUS_IND_V01,
   QMI_IMSA_SRVC_ACS_STATUS_IND_V01
  /* To be filled in in future release */
} qmi_imsa_indication_id_type;

/* Async notification reporting structure */
typedef union
{
  imsa_0023_ind_s imsa_0023_ind;
  imsa_0024_ind_s imsa_0024_ind;
  imsa_0027_ind_s imsa_0027_ind;
} qmi_imsa_indication_data_type;


typedef void (*qmi_imsa_indication_hdlr_type)
( 
  int                           user_handle,
  qmi_service_id_type           service_id,
  void                          *user_data,
  qmi_imsa_indication_id_type    ind_id,
  qmi_imsa_indication_data_type  *ind_data
);

EXTERN HANDLE qmi_imsa_srvc_init_client
(
  const char                   *dev_id,
  qmi_imsa_indication_hdlr_type  user_ind_msg_hdlr,
  void                          *user_ind_msg_hdlr_user_data,
  int                           *qmi_err_code
);

EXTERN int 
qmi_imsa_srvc_release_client
(
  qmi_client_handle_type  client_handle,
  int                     *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_imsa_indication_register
===========================================================================*/
/*!
@brief 
  Set the IMSA indication registration state for specified control point.
     
  
@return 

@note

  - Dependencies
    - qmi_imsa_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_imsa_indication_register
(
  int                                     client_handle,
  imsa_0022_req_s                  *imsa_0022_req,
  int                                    *qmi_err_code
);

EXTERN int
qmi_imsa_get_service_status_info
(
  int                               client_handle,
  imsa_0021_rsp_s             *imsa_0021_rsp, 
  int                               *qmi_err_code
);

EXTERN int
qmi_imsa_get_service_status
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  imsa_0021_rsp_s            *imsa_0021_rsp
);

EXTERN int
qmi_imsa_get_reg_status_info
(
  int                               client_handle,
  imsa_0020_rsp_s             *imsa_0020_rsp, 
  int                               *qmi_err_code
);

EXTERN int
qmi_imsa_get_reg_status
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  imsa_0020_rsp_s            *imsa_0020_rsp
);

#ifdef __cplusplus
}
#endif

#endif /* QMI_IMSA_SRVC_H  */
