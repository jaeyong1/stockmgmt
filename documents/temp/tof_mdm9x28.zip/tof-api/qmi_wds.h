#ifndef QMI_WDS_H
#define QMI_WDS_H

#include "qmi_wds_srvc.h"
#include "wmmdiag_packet.h"
#include "TOF_API.h"

#define TOF_QMI_3GPP_PROFILE_LIST_MAX 16

typedef struct
{
  unsigned long    profile_num;
  char             apn[QMI_WDS_MAX_APN_STR_SIZE];
  qmi_wds_pdp_type pdp_type;
} qmi_wds_profile_info_type;

extern boolean qmi_wds_srvc_init( void );
extern boolean qmi_wds_srvc_release( void );

extern boolean qmi_wds_set_profile_info( uint32 index, uint64 param_mask, qmi_wds_profile_info_type* info );
extern boolean qmi_wds_get_profile_info( uint32 index, qmi_wds_profile_info_type* info );
extern boolean qmi_wds_add_profile_info( uint32 index );

extern qmi_wds_pdp_type qmi_wds_convert_pdp_type_qcmap_to_wds(tof_qcmap_msgr_ip_family_enum_v01 ip_family);
extern tof_qcmap_msgr_ip_family_enum_v01 qmi_wds_convert_pdp_type_wds_to_qcmap(qmi_wds_pdp_type pdp_type);
#endif
