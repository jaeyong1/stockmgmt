//dsji_20130204
//dsji_20130205
//dsji_20130617

/******************************************************************************
  @file    qmi_voice.h
  @brief   QMI VOICE header

  DESCRIPTION

  INITIALIZATION AND SEQUENCING REQUIREMENTS

  ---------------------------------------------------------------------------
  Copyright (c) 2013 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/
#ifndef QMI_VOICE_H
#define QMI_VOICE_H



#include "qmi_voice_srvc.h"
#include "TOF_API.h"
#include "TOF_log.h"

typedef enum
{
	GET_VOICE_CALL_STATE_MASK_ORIGINATING		= 1,
	GET_VOICE_CALL_STATE_MASK_INCOMING			= 2,
	GET_VOICE_CALL_STATE_MASK_CONVERSATION		= 4,
	GET_VOICE_CALL_STATE_MASK_CC_IN_PROGRESS	= 8,
	GET_VOICE_CALL_STATE_MASK_ALERTING			= 16,
	GET_VOICE_CALL_STATE_MASK_HOLD				= 32,
	GET_VOICE_CALL_STATE_MASK_WAITING			= 64,
	GET_VOICE_CALL_STATE_MASK_DISCONNECTING		= 128,
	GET_VOICE_CALL_STATE_MASK_END				= 256,
	GET_VOICE_CALL_STATE_MASK_SETUP				= 512
} get_voice_call_state_mask;

//dsji_20150121 add {
typedef enum
{
	VOICE_CALL_WAIT_FOR_EVENT_COMPLETE_TYPE_NONE= 0,
  VOICE_CALL_WAIT_FOR_EVENT_COMPLETE_TYPE_HANGUP,
  VOICE_CALL_WAIT_FOR_EVENT_COMPLETE_TYPE_MAX
} voice_call_wait_for_event_complete_type;
//dsji_20150121 add }

typedef struct {
  unsigned char num_of_calls;
}voice_basic_call_info_type;

extern voice_get_all_call_info_resp_msg_v02		g_voice_all_call_info;
extern voice_basic_call_info_type             g_voice_basic_call_info;

//dsji_20130620 modify {
//dsji_20130617 add {
extern voice_get_clir_resp_msg_v02		g_clir;
extern voice_get_clip_resp_msg_v02		g_clip;
extern voice_get_colp_resp_msg_v02		g_colp;
extern voice_get_colr_resp_msg_v02		g_colr;
extern voice_get_call_forwarding_resp_msg_v02	g_call_forward;
extern voice_get_call_waiting_resp_msg_v02		g_call_waiting;
//dsji_20130617 add }
//dsji_20130620 modify }
//dsji_20130620 add {
extern uint32 g_clir_n;
extern uint32 g_clip_n;
extern uint32 g_colp_n;
//dsji_20130620 add }
extern call_end_reason_enum_v02         g_voice_call_end_reason;
extern voice_speech_codec_enum_v02      g_voice_speech_codec;

void update_g_voice_all_call_info( voice_get_all_call_info_resp_msg_v02* call_info );
void update_g_voice_basic_call_info( voice_call_info2_type_v02* call_info );
void qmi_voice_make_incoming_call_ring(TOF_CDMA_SignalInfoRecord* info_rec); //RIL_UNSOL_CALL_RING

extern void		update_voice_all_call_status( voice_all_call_status_ind_msg_v02* voice_all_call_status );
extern uint8_t	get_voice_call_id( unsigned int voice_call_state_mask );
extern uint8_t	get_active_voice_call_id( void );
extern uint8_t	get_wait_or_background_voice_call_id( void );
//dsji_20141030 add {
extern unsigned int 				get_voice_call_current_num();
extern call_type_enum_v02		get_voice_call_call_type( uint8 call_id );
extern call_state_enum_v02	get_voice_call_call_state( uint8 call_id );
//dsji_20141030 add }

extern boolean	tof_qmi_voice_init( void );
extern boolean	tof_qmi_voice_release( void );

//RIL_REQUEST_GET_CURRENT_CALLS
extern bool	request_get_current_calls( void );
//RIL_REQUEST_DIAL
extern bool request_dial( TOF_Dial *tof_dial );
//RIL_REQUEST_HANGUP
extern bool request_hangup( uint8 call_id );
// RIL_REQUEST_HK_HANGUP_ALL
extern bool request_hangup_all_voice_call();
//RIL_REQUEST_HANGUP_WAITING_OR_BACKGROUND
extern bool request_hangup_waiting_or_background( void );
//RIL_REQUEST_HANGUP_FOREGROUND_RESUME_BACKGROUND
extern bool request_hangup_foreground_resume_background( void );
//RIL_REQUEST_SWITCH_WAITING_OR_HOLDING_AND_ACTIVE
extern bool request_switch_waiting_or_holding_and_active( void );
//RIL_REQUEST_LAST_CALL_FAIL_CAUSE
extern bool request_last_call_fail_cause( call_end_reason_enum_v02* cause );
//RIL_REQUEST_ANSWER
extern bool request_answer( void );
//RIL_REQUEST_DTMF_START
extern bool request_dtmf_start( char* key );
//RIL_REQUEST_DTMF_STOP
extern bool request_dtmf_stop( void );
//BKS_20131113 - start
extern bool request_cdma_burst_dtmf(char* dtmf_data);//BKS_20131127 modify

extern bool request_dtmf(char* dtmf_data);

//RIL_REQUEST_SET_CLIR
extern bool	request_set_clir( int n );
//RIL_REQUEST_GET_CLIR
extern bool request_get_clir( void );
//RIL_REQUEST_SET_CALL_WAITING
extern bool request_set_call_waiting( int32* data );
//RIL_REQUEST_QUERY_CALL_WAITING
extern bool request_query_call_waiting( int32 service_class );
//RIL_REQUEST_SET_CALL_FORWARD
extern bool	request_set_call_forward( TOF_CallForwardInfo* tof_call_forward_info );
//RIL_REQUEST_QUERY_CALL_FORWARD_STATUS
extern bool request_query_call_forward_status( TOF_CallForwardInfo* tof_call_forward_info );

//RIL_REQUEST_HK_SET_CLIP
extern bool	request_set_clip( int n );
//RIL_REQUEST_HK_GET_CLIP
extern bool	request_get_clip( void );
//RIL_REQUEST_HK_SET_COLP
extern bool request_set_colp( int n );
//RIL_REQUEST_HK_GET_COLP
extern bool request_get_colp( void );
//RIL_REQUEST_HK_GET_COLR
extern bool	request_get_colr( void );

//dsji_20130702 add {
//RIL_REQUEST_HK_USSD_TRANSMIT
extern bool	request_ussd_transmit( TOF_USSD_CONTEXT_INFO* tof_ussd_context_info, voice_orig_ussd_resp_msg_v02* rsp );
extern bool	request_ussd_answer( voice_answer_ussd_resp_msg_v02* rsp );	//dsji_20140402 add 
//dsji_20130702 add }

bool	request_manage_calls( sups_type_enum_v02 sups_type );

//chad_20160602 start >>>
extern boolean request_set_volte(boolean on_off);
extern uint8 request_get_volte(void);
//chad_20160602 end <<<

char*	get_call_state_string( call_state_enum_v02 call_state );
char*	get_direction_string( call_direction_enum_v02 direction );
char*	get_call_type_string( call_type_enum_v02 call_type );


extern void convert_phone_number(char before_number[], char after_number[]);
extern call_type_enum_v02 convert_call_state(call_direction_enum_v02 direction, 
                                             call_type_enum_v02 call_type, 
                                             call_state_enum_v02 call_state, 
                                             voice_speech_codec_enum_v02 call_codec);

extern char*	get_voice_call_end_reason_string( call_end_reason_enum_v02 voice_call_end_reason );

extern uint8 qmi_voice_request_query_preferred_voice_privacy_mode(int *privacy_reference); //RIL_REQUEST_CDMA_QUERY_PREFERRED_VOICE_PRIVACY_MODE
extern uint8 qmi_voice_request_set_preferred_voice_privacy_mode(int voice_privacy); //RIL_REQUEST_CDMA_SET_PREFERRED_VOICE_PRIVACY_MODE

//--> VOLTE_CALL_TYPE
extern uint8 qmi_voice_check_lte_service();
//<-- VOLTE_CALL_TYPE

/*=========================================================
	FUNCTION	: REQUEST_ECALL_DIAL [request_ecall_dial]

	DESCRIPTION

	DEPENDENCIES

	RETURN VALUES

	SIDE EFFECTS

	NOTES
		20160921	SH.Lee		Created.
=========================================================*/
bool	request_ecall_dial( int mode );
extern bool	request_ecall_set_msd(int mode, char* msd_data);

#endif
