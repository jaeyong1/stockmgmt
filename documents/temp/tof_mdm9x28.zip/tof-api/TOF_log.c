/*===========================================================================

MODULE
   LOG Print
 
DESCRIPTION
  
===========================================================================*/

/*===========================================================================
                        EDIT HISTORY FOR MODULE

when      who         what, where, why
----------------------------------------------------------------------------
160303    ygpark          create (refer to LGIT_RIL)
===========================================================================*/
#include <stdarg.h>
#include <pthread.h>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>

#include "TOF_Definition.h"
#include "TOF_log.h"

FILE *msg_log_fp = NULL;
pthread_mutex_t log_mutex;
pthread_mutex_t log_tbox_mutex; //ysgwak 20101118 add new tbox log

static boolean bLogPrint = FALSE;

#define PRINT_DEBUG_LOG
#if defined(PRINT_DEBUG_LOG)
#define LOGD printf
#endif

boolean GetLogPrintState()
{
  #ifdef PRINT_DEBUG_LOG
  //LOGD(" ##### GetLogPrintState bLogPrint: %d", bLogPrint);
  #endif

  return bLogPrint;
}

void SetLogPrint(boolean state)
{
  if(state)
    log_start();
  else
    log_end();
}

/*===========================================================================

FUNCTION log_start
 
DESCRIPTION
  
===========================================================================*/
void log_start(void)
{
// ysgwak 20130329  log start �� wmmdll00.log ���Ͽ� writing�ϵ��� ����
// * wmmdll00.log  ������ full ��Ȳ
// case 1) wmmdll01.log������ ���� �ϴ� ��� - wmmdll01.log������ wmmdll02.log ���Ϸ� copy�ϰ� wmmdll00.log ������ wmmdll01.log�� copy
// case 2) wmmdll01.log������ ���� ���� �ʴ� ��� - wmmdll00.log ������ wmmdll01.log�� copy
// wmmdll00.log "w+" open
  #ifdef PRINT_DEBUG_LOG
  LOGD(" ##### log_start : %s\r\n", LOG_FILE_PATH_00);
  #endif

  if(GetLogPrintState())
    return;

  if(0 != access(LOG_FILE_PATH, F_OK))
  {
  	LOGD("There is not %s , create now\r\n", LOG_FILE_PATH_00);
  	system(LOG_FILE_CREATE);
  }

  
  if((msg_log_fp=fopen(LOG_FILE_PATH_00, "a+"))==NULL)
  {
    LOGD(" ##### log_start log file create error !!! msg_log_fp: %p\r\n", msg_log_fp);
    return;
  }

  //swjo 20120807, ��� ��û���� WMM �α������� 0755 �������� ����
  chmod(LOG_FILE_PATH_00, 0755);

  bLogPrint = TRUE;

  pthread_mutex_init(&log_mutex, NULL);
  pthread_mutex_init(&log_tbox_mutex, NULL);   //ysgwak 20101118 add new tbox log 
}

/*===========================================================================

FUNCTION log_end
 
DESCRIPTION
  
===========================================================================*/
void log_end()
{
  if(GetLogPrintState() == FALSE)
    return;

  bLogPrint = FALSE;

	if(msg_log_fp)
		fclose(msg_log_fp);
	msg_log_fp = NULL;

	pthread_mutex_destroy(&log_mutex);
	pthread_mutex_destroy(&log_tbox_mutex);  //ysgwak 20101118 add new tbox log 
}

/*===========================================================================

FUNCTION get_time_stamp_str
 
DESCRIPTION
  
===========================================================================*/
char *get_time_stamp_str()
{
	static char time_stamp[25];
	long tm_msec = 0;
	struct timeval timeval;
	gettimeofday(&timeval, 0); // microsecond ����: gettimeofday(), Sec ����: time()
	struct tm* currentTime;
	currentTime = localtime( &timeval.tv_sec );
	tm_msec = timeval.tv_usec/1000;
		
	sprintf(time_stamp, "%04d-%02d-%02d %02d:%02d:%02d.%03d",
											currentTime->tm_year+1900,		
											currentTime->tm_mon+1,
											currentTime->tm_mday,
											currentTime->tm_hour,
											currentTime->tm_min,
											currentTime->tm_sec,
											(int)tm_msec);

	return time_stamp;
}


/*===========================================================================

FUNCTION log_print
 
DESCRIPTION
  
===========================================================================*/
int log_print(const char *file, int line, char *level_str, const char *fmt, ...)
{
  char buf[4096];
  char *pos = buf;
  size_t ret;
  va_list args;
  size_t idx;
  size_t len;
  long log_size = 0;

  if(GetLogPrintState()==FALSE || msg_log_fp==NULL)
  {
    pthread_mutex_unlock(&log_mutex);
    return 0;
  }  

  pthread_mutex_lock(&log_mutex);
  len = strlen(file);
  for(idx=len-1; idx >0; idx--)
  {
    if(file[idx] == '\\')
      break;
  }
	
  pos += sprintf(pos, "MSG %-12s %s  %20s  %05d  ",
                        level_str,
                        get_time_stamp_str(),
                        &file[0], line);

  va_start(args, fmt);
  vsprintf(pos, fmt, args);
  va_end(args);

  //Change 'LF' to SP
  len = strlen(buf);
  for(idx=0; idx<len; idx++)
  {
    if((buf[idx] == '\n') || (buf[idx] == '\r'))
      buf[idx] = ' ';
  }

  strcat(buf, "\r\n");

  #ifdef PRINT_DEBUG_LOG
  //printf("%s", buf);
  //log_color_print(buf);  
  #endif 

// ysgwak 20130329 log start �� wmmdll00.log ���Ͽ� writing�ϵ��� ����
// * wmmdll00.log  ������ full ��Ȳ
// case 1) wmmdll01.log������ ���� �ϴ� ��� - wmmdll01.log������ wmmdll02.log ���Ϸ� copy�ϰ� wmmdll00.log ������ wmmdll01.log�� copy
// case 2) wmmdll01.log������ ���� ���� �ʴ� ��� - wmmdll00.log ������ wmmdll01.log�� copy
// wmmdll00.log "w+"open
  log_size = ftell(msg_log_fp);
  if(log_size >= LOG_FILE_MAX_SIZE)
  {
    FILE *check_fp = NULL;
    char cmdstr[128] = {0,};    
    fclose(msg_log_fp);
    
    if((check_fp=fopen(LOG_FILE_PATH_01, "r")) == NULL)
    {
      rename(LOG_FILE_PATH_00, LOG_FILE_PATH_01);
      chmod(LOG_FILE_PATH_01, 0755);
    }
    else
    {
      fclose(check_fp);
      
      rename(LOG_FILE_PATH_01, LOG_FILE_PATH_02);
      rename(LOG_FILE_PATH_00, LOG_FILE_PATH_01);
      chmod(LOG_FILE_PATH_01, 0755);
      chmod(LOG_FILE_PATH_02, 0755);      
    }
    msg_log_fp = fopen(LOG_FILE_PATH_00, "w+");
    chmod(LOG_FILE_PATH_00, 0755);
  }
  else
  {
    FILE *check_fp = NULL;
    // LOG_FILE_PATH_00 �� ���� �� ���� ���� �ϴ� ��� �����
    if((check_fp=fopen(LOG_FILE_PATH_00, "r")) == NULL)
    {
      msg_log_fp = freopen(LOG_FILE_PATH_00, "w+", msg_log_fp);
      chmod(LOG_FILE_PATH_00, 0755);
    }

    fclose(check_fp);    
  }

  ret = fwrite(buf, 1, strlen(buf), msg_log_fp);
  #ifdef PRINT_DEBUG_LOG
  //LOGD(" ##### log_print fwrite ret: %d\r\n", ret);
  #endif

  fflush(msg_log_fp);
  //LOGD(" ##### log_print fwrite file ret: %d\r\n", ret);

  pthread_mutex_unlock(&log_mutex);

  return (int)ret;
}

#ifdef FEATURE_TOF_GPS
#define LOG_FILE_PATH_LOC  LOG_FILE_PATH"loc_test.log"
FILE *msg_loc_log_fp = NULL;

boolean loc_log_test(char *t_in_ptr,int t_size)
{
  size_t ret;

  if(0 != access(LOG_FILE_PATH, F_OK))
  {
    LOGD("There is not %s , create now\r\n", LOG_FILE_PATH_LOC);
    system(LOG_FILE_PATH_LOC);
  }
    
  if((msg_loc_log_fp=fopen(LOG_FILE_PATH_LOC, "a+"))==NULL)
  {
    printf(" ##### loc_log_test log file create error !!! msg_loc_log_fp: %p\r\n", msg_loc_log_fp);
    return FALSE;
  }

  chmod(LOG_FILE_PATH_LOC, 0755);

  ret = fwrite(t_in_ptr, 1, t_size, msg_loc_log_fp);
  #ifdef PRINT_DEBUG_LOG
  //LOGD(" ##### log_print fwrite ret: %d\r\n", ret);
  #endif
  printf("[GPS]loc_log_test() ret =%d \n",ret);
  fflush(msg_loc_log_fp);

  if(msg_loc_log_fp)
    fclose(msg_loc_log_fp);
  msg_loc_log_fp = NULL;

  return TRUE;
}
#endif /* FEATURE_TOF_GPS */


/*===========================================================================

FUNCTION log_color_print
 
DESCRIPTION
For only local Debugging.
The function outputs a log into the terminal.
The log includes a ansi escape code.
It shall use a ansi escape code decodable terminal.
Output method is shown below.

MSG Log/High  : ANSI_COLOR_YELLOW
MSG Log/Medium : ANSI_COLOR_MAGENTA
MSG Log/Low   : ANSI_COLOR_CYAN
MSG Log/Error : ANSI_COLOR_RED

preparation : ANSI_COLOR_GREEN, ANSI_COLOR_BLUE
  
===========================================================================*/

void log_color_print(char* log_ptr)
{

#define ANSI_COLOR_RED		 "\x1b[31;1m"
#define ANSI_COLOR_GREEN	 "\x1b[32;1m"
#define ANSI_COLOR_YELLOW  "\x1b[33;1m"
#define ANSI_COLOR_BLUE 	 "\x1b[34;1m"
#define ANSI_COLOR_MAGENTA "\x1b[35;1m"
#define ANSI_COLOR_CYAN 	 "\x1b[36;1m"
#define ANSI_COLOR_RESET	 "\x1b[0m"

if(strstr(log_ptr,"MSG Log/High")!= NULL)
{
	printf(ANSI_COLOR_YELLOW 		"%s" 		ANSI_COLOR_RESET ,log_ptr);
}
else if(strstr(log_ptr,"MSG Log/Medium")!= NULL)
{
	printf(ANSI_COLOR_MAGENTA 		"%s" 		ANSI_COLOR_RESET ,log_ptr);
}
else if(strstr(log_ptr,"MSG Log/Low")!= NULL)
{
	printf(ANSI_COLOR_CYAN 		"%s" 		ANSI_COLOR_RESET ,log_ptr);
}
else if(strstr(log_ptr,"MSG Log/Error")!= NULL)
{
	printf(ANSI_COLOR_RED 		"%s" 		ANSI_COLOR_RESET ,log_ptr);
}
else
{
	printf("%s",log_ptr);
}

/*Sample
printf(ANSI_COLOR_RED 		"This text is RED!" 		ANSI_COLOR_RESET "\n");
printf(ANSI_COLOR_GREEN 	"This text is GREEN!" 	ANSI_COLOR_RESET "\n");
printf(ANSI_COLOR_YELLOW	"This text is YELLOW!"	ANSI_COLOR_RESET "\n");
printf(ANSI_COLOR_BLUE		"This text is BLUE!"		ANSI_COLOR_RESET "\n");
printf(ANSI_COLOR_MAGENTA "This text is MAGENTA!" ANSI_COLOR_RESET "\n");
printf(ANSI_COLOR_CYAN		"This text is CYAN!"		ANSI_COLOR_RESET "\n");
*/

}

