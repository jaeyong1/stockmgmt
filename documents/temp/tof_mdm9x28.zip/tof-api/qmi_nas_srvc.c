/******************************************************************************
  @file    qmi_nas_srvc.c
  @brief   The QMI TOF API

  DESCRIPTION

  INITIALIZATION AND SEQUENCING REQUIREMENTS

  ---------------------------------------------------------------------------
  Copyright (c) 2016 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/
#include <string.h>

#include "qmi_i.h"
#include "qmi_service.h"
#include "qmi_util.h"
#include "qmi_nas.h"
#include "qmi_nas_srvc.h"
#include "TOF_event_daemon.h"
#include "wmmdiag_packet_common.h"

#include "TOF_Definition.h"
#include "Debug_string.h"


#define QMI_EAP_STD_MSG_SIZE                               QMI_MAX_STD_MSG_SIZE
#define QMI_NAS_STD_MSG_SIZE                               QMI_MAX_STD_MSG_SIZE
#define QMI_NAS_EVENT_REPORT_TLV_MAX_SIZE                  7 * sizeof(char)

#define NAS_CMN_EMERGENCY_MODE_OFF         0x00
#define NAS_CMN_EMERGENCY_MODE_ON          0x01

/*Indication message IDs*/
#define QMI_NAS_EVENT_REPORT_IND_MSG_ID                0x0002 
#define QMI_NAS_SERVING_SYSTEM_IND_MSG_ID              0x0024
#define QMI_NAS_SYSTEM_SELECTION_PREFERENCE_IND_MSG_ID 0x0034
#define QMI_NAS_NETWORK_TIME_IND_MSG_ID                0x004C
#define QMI_NAS_SYS_INFO_IND_MSG_ID                    0x004E
#define QMI_NAS_SIG_INFO_IND_MSG_ID                    0x0051
#define QMI_NAS_CURRENT_PLMN_NAME_IND_MSG_ID           0x0061
#define QMI_NAS_NETWORK_REJECT_IND_MSG_ID              0x0068

/*TLV IDs*/
#define QMI_NAS_SIGNAL_STRENGTH_IND_TLV_ID             0x10

/*Message Ids*/
#define QMI_NAS_EVENT_REPORT_MSG_ID                    0x0002    
#define QMI_NAS_INDICATION_REGISTER_MSG_ID             0x0003   
#define QMI_NAS_GET_SIGNAL_STRENGTH_MSG_ID             0x0020
#define QMI_NAS_INIT_PS_ATTACH_DETACH_MSG_ID           0x0023   
#define QMI_NAS_GET_SERVING_SYSTEM_MSG_ID              0x0024    
#define QMI_NAS_GET_HOME_NETWORK_MSG_ID                0x0025
#define QMI_NAS_SET_SYS_SEL_PREF                       0x0033
#define QMI_NAS_GET_SYS_SEL_PREF_MSG_ID                0x0034
#define QMI_NAS_GET_3GPP2_SUBSCRIPTION_INFO_MSG_ID     0x003E
//20170215 yjoh add for cell info
#define QMI_NAS_GET_CELL_LOCATION_INFO_INFO_MSG_ID     0x0043

#define QMI_NAS_GET_PLMN_NAME_REQ_MSG_ID               0x0044 //BKS_20131202
#define QMI_NAS_GET_SYS_INFO_MSG_ID                    0x004D
#define QMI_NAS_GET_SIG_INFO_MSG_ID                    0x004F
#define QMI_NAS_UPDATE_AKEY_EXT_MSG_ID                 0x005B
#define QMI_NAS_CONFIG_SIG_INFO2_MSG_ID                 0x006C

/*User Ids*/
#define QMI_NAS_GET_PROTOCOL_INFO_MSG_ID               0x5556
#define QMI_NAS_SET_PROTOCOL_INFO_MSG_ID               0x5557
#define QMI_NAS_GET_NETWORK_TIME_INFO_MSG_ID           0x5558
#define QMI_NAS_GET_CURRENT_PLMN_NAME_CACHE_MSG_ID     0x5559
#define QMI_NAS_GET_NETWORK_TYPE_MSG_ID                0x555A
#define QMI_NAS_SET_NETWORK_TYPE_MSG_ID                0x555B
#define QMI_NAS_GET_DEBUG_SCREEN_INFO_MSG_ID           0x555C
#define QMI_NAS_DELETE_STORED_CELL_MSG_ID           0x555D
#define QMI_NAS_GET_IMS_ENABLE_MSG_ID               0x555E
#define QMI_NAS_SET_IMS_ENABLE_MSG_ID               0x555F
#define QMI_NAS_GET_IMS_PDN_ENABLE_MSG_ID               0x5560
#define QMI_NAS_SET_IMS_PDN_ENABLE_MSG_ID               0x5561
#define QMI_NAS_GET_CDMA_DEBUG_SCREEN_INFO_MSG_ID      0x5562 //BKS_20131107
#define QMI_NAS_GET_IMS_TEST_MODE_MSG_ID               0x5563
#define QMI_NAS_SET_IMS_TEST_MODE_MSG_ID               0x5564
#define QMI_NAS_GET_IMS_USER_CONFIG_MSG_ID              0x5565
#define QMI_NAS_SET_IMS_USER_CONFIG_MSG_ID              0x5566
#define QMI_NAS_GET_IMS_RCS_AUTO_CONFIG_MSG_ID         0x556B
#define QMI_NAS_SET_IMS_RCS_AUTO_CONFIG_MSG_ID         0x556C
#define QMI_NAS_GET_IMS_DPL_PARAM_MSG_ID               0x556D
#define QMI_NAS_SET_IMS_DPL_PARAM_MSG_ID               0x556E
#define QMI_NAS_GET_IMS_QIPCALL_CONFIG_MSG_ID          0x556F //hongsg_20140729
#define QMI_NAS_SET_IMS_QIPCALL_CONFIG_MSG_ID          0x5570
#define QMI_NAS_GET_IMS_REG_CONFIG_MSG_ID              0x5571 
#define QMI_NAS_SET_IMS_REG_CONFIG_MSG_ID              0x5572
#define QMI_NAS_OTA_EVENT_LOG_SAVE_IND_MSG_ID          0x5573
#define QMI_NAS_GET_IMS_VOIP_CONFIG_MSG_ID              0x5574
#define QMI_NAS_SET_IMS_VOIP_CONFIG_MSG_ID              0x5575
#define QMI_NAS_GET_IMS_USER_AGENT_MSG_ID              0x557A //hongsg 20140821
#define QMI_NAS_SET_IMS_USER_AGENT_MSG_ID              0x557B
#define QMI_NAS_SET_NETWORK_MODE_MSG_ID                0x5580
#define QMI_NAS_GET_NETWORK_MODE_MSG_ID                0x5581


#define QMI_NAS_SET_SERVICE_DOMAIN_MSG_ID     			0x5601
#define QMI_NAS_GET_SERVICE_DOMAIN_MSG_ID           0x5602
#define QMI_NAS_SET_WCDMA_RRC_VERSION_MSG_ID        0x5603
#define QMI_NAS_GET_WCDMA_RRC_VERSION_MSG_ID      	0x5604
#define QMI_NAS_SET_WCDMA_SMS_MO_DOMAIN_MSG_ID     	0x5605
#define QMI_NAS_GET_WCDMA_SMS_MO_DOMAIN_MSG_ID     	0x5606
#define QMI_NAS_SET_ISR_ENABLE_MSG_ID               0x5607
#define QMI_NAS_GET_ISR_ENABLE_MSG_ID             	0x5608


// --> RIL_REQUEST_EVDO_REV
#define QMI_NAS_GET_EVDO_REV_MSG_ID                  0x7001
#define QMI_NAS_SET_EVDO_REV_MSG_ID                  0x7002
// <-- RIL_REQUEST_EVDO_REV

//RIL_REQUEST_HK_SET_CDMA_SYS_SEL_PREF//RIL_REQUEST_HK_GET_CDMA_SYS_SEL_PREF //BKS_20140307
#define QMI_NAS_SET_SYSTEM_SELECTION_MSG_ID 0x7003
#define QMI_NAS_GET_SYSTEM_SELECTION_MSG_ID 0x7004
//RIL_REQUEST_HK_SET_CDMA_SYS_SEL_PREF//RIL_REQUEST_HK_GET_CDMA_SYS_SEL_PREF
//--> RIL_REQUEST_APN_SETTING
#define QMI_NAS_SET_APN_INFO                           0x7005
#define QMI_NAS_GET_APN_INFO                           0x7006
//<--RIL_REQUEST_APN_SETTING

//--> RIL_REQUEST_EHRPD_IPV6
#define QMI_NAS_GET_EHRPD_IPV6_ENABLED_MSG_ID          0x7007
#define QMI_NAS_SET_EHRPD_IPV6_ENABLED_MSG_ID          0x7008
//<-- RIL_REQUEST_EHRPD_IPV6

// --> RIL_REQUEST_VZW_IMS_SETTING
#define QMI_NAS_GET_VZW_IMS_SETTING_MSG_ID                    0x7009
#define QMI_NAS_SET_VZW_IMS_SETTING_MSG_ID                    0x7010
// <-- RIL_REQUEST_VZW_IMS_SETTING

//--> RIL_REQUEST_T3402
#define QMI_NAS_GET_T3402_MSG_ID                       0x7011
#define QMI_NAS_SET_T3402_MSG_ID                       0x7012
//<-- RIL_REQUEST_T3402

//--> RIL_REQUEST_HK_USIM_ONCHIP
#define QMI_NAS_CLEAR_MRU_MSG_ID                       0x7017
//<-- RIL_REQUEST_HK_USIM_ONCHIP

//RIL_REQUEST_HK_GET_IMS_AUTH
#define QMI_NAS_GET_IMS_SIP_EXTENDED_CONFIG_MSG_ID              0x5567
//RIL_REQUEST_HK_SET_IMS_AUTH
#define QMI_NAS_SET_IMS_SIP_EXTENDED_CONFIG_MSG_ID              0x5568

#define QMI_NAS_SIGNAL_STRENGTH_IND_MSG_ID          0x701A

#define QMI_NAS_APN_CHANGED_IND_MSG_ID          0x701B

#define QMI_NAS_GET_DCMO_INFO                           0x701C
#define QMI_NAS_SET_DCMO_INFO                           0x701D

#define QMI_NAS_SET_VZW_OTADM_TESTMENU                           0x701F

#if  defined(FEATURE_LGIT_OTADM_FOTA_FUMO_VZW)
#define QMI_NAS_WAP_PUSH_TEST_MSG_ID               0x7030
#define QMI_NAS_WAP_PUSH_TEST_IND_MSG_ID           0x7031
#endif

#define QMI_NAS_SET_ECALL_ENABLE_MSG_ID               0x7034 //jaeyong1.park

#define QMI_NAS_ENABLE_ECALL_ONLY_MODE_MSG_ID               0x7035 //mwkim
#define QMI_NAS_SET_ECALL_NUMBER_MSG_ID               0x7036 //jaeyong1.park

#define QMI_NAS_GET_ECALL_ENABLE_MSG_ID               0x7040 //jaeyong1.park
#define QMI_NAS_GET_MODEM_VALUE_MSG_ID               0x7041 //jaeyong1.park

#define QMI_NAS_GET_ECALL_OPER_MODE_MSG_ID               0x7042 //mwkim

#define QMI_NAS_SIM_STATE_CHANGE_IND_MSG_ID				0x7043 // 20170220 mwkim

/*req resp tlv ids*/
#define QMI_NAS_PS_ATTACH_ACTION_TLV_ID                0x10


#define WRITE_8_BIT_SIGNED_VAL(dest,val) \
 do {*(char *)dest = (char) val; \
     dest = (char *)dest + 1;} while (0)

#ifdef FEATURE_LGIT_TIME
#else
extern boolean need_get_nitz_time;
#endif

static int nas_service_initialized = FALSE;
extern struct nas_cached_info_type nas_cached_info;

/*===========================================================================
  FUNCTION  qmi_nas_event_report_info_ind
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with serving system info.  It
  is used both by the get serving system info cmd response as well as the
  serving system indication.   
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_event_report_info_ind
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_0002_ind_s            *nas_0002_ind
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;  

  memset(nas_0002_ind, 0, sizeof(nas_0002_ind_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                                            &rx_buf_len,
                                            &type,
                                            &length,
                                            &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case NAS_0002_IND_T10:
      {
        nas_0002_ind->t10_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_0002_ind->t10.sig_strength);
        READ_8_BIT_VAL(value_ptr,nas_0002_ind->t10.radio_if);
      }
      break;

      // RF Band Information
      case NAS_0002_IND_T11:
      {
        nas_0002_ind->t11_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_0002_ind->t11.num_instances);
        for (i = 0; (i < nas_0002_ind->t11.num_instances) && (i < NAS_0002_IND_T11_MAX_RADIO_IFS); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_0002_ind->t11.rf_band[i].radio_if);
          READ_16_BIT_VAL(value_ptr,nas_0002_ind->t11.rf_band[i].active_band);
          READ_16_BIT_VAL(value_ptr,nas_0002_ind->t11.rf_band[i].active_channel);          
        } 
      }
      break;

      // Registration Reject Reason
      case NAS_0002_IND_T12:
      {
        nas_0002_ind->t12_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_0002_ind->t12.service_domain);
        READ_16_BIT_VAL(value_ptr,nas_0002_ind->t12.reject_cause);       
      }
      break;

      // RSSI Indicator
      case NAS_0002_IND_T13:
      {
        nas_0002_ind->t13_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_0002_ind->t13.rssi);
        READ_8_BIT_VAL(value_ptr,nas_0002_ind->t13.radio_if);    
      }
      break;

      // ECIO Indicator
      case NAS_0002_IND_T14:
      {
        nas_0002_ind->t14_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_0002_ind->t14.ecio);
        READ_8_BIT_VAL(value_ptr,nas_0002_ind->t14.radio_if); 
      }
      break;      

      // IO Indicator
      case NAS_0002_IND_T15:
      {
        nas_0002_ind->t15_valid = TRUE;
        READ_32_BIT_VAL(value_ptr,nas_0002_ind->t15.io);    
      }
      break;     

      // SINR Indicator
      case NAS_0002_IND_T16:
      {
        nas_0002_ind->t16_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_0002_ind->t16.sinr);
      }
      break;

      // Error Rate Indicator
      case NAS_0002_IND_T17:
      {
        nas_0002_ind->t17_valid = TRUE;
        READ_16_BIT_VAL(value_ptr,nas_0002_ind->t17.error_rate);
        READ_8_BIT_VAL(value_ptr,nas_0002_ind->t17.radio_if); 
      }
      break; 

      // RSRQ Indicator
      case NAS_0002_IND_T18:
      {
        nas_0002_ind->t18_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_0002_ind->t18.rsrq);
        READ_8_BIT_VAL(value_ptr,nas_0002_ind->t18.radio_if);       
      }
      break; 

      // ECIO Threshold
      case NAS_0002_IND_T19:
      {
        nas_0002_ind->t19_valid = TRUE;
        READ_16_BIT_VAL(value_ptr,nas_0002_ind->t19.lte_snr);
      }
      break;

      // SINR Threshold
      case NAS_0002_IND_T1A:
      {
        nas_0002_ind->t1A_valid = TRUE;
        READ_16_BIT_VAL(value_ptr,nas_0002_ind->t1A.lte_rsrp);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_event_report_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_serving_system_info_ind
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with serving system info.  It
  is used both by the get serving system info cmd response as well as the
  serving system indication.   
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_serving_system_info_ind
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_0024_ind_s           *nas_0024_ind  
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;  

  memset(nas_0024_ind, 0, sizeof(nas_0024_ind_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                                  &rx_buf_len,
                                  &type,
                                  &length,
                                  &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case NAS_0024_IND_T01:
      {
        nas_0024_ind->t01_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_0024_ind->t01.registration_state);
        READ_8_BIT_VAL(value_ptr,nas_0024_ind->t01.cs_attach_state);
        READ_8_BIT_VAL(value_ptr,nas_0024_ind->t01.ps_attach_state);
        READ_8_BIT_VAL(value_ptr,nas_0024_ind->t01.selected_network);
        READ_8_BIT_VAL(value_ptr,nas_0024_ind->t01.in_use_radio_if_list_num);

        for (i = 0; (i < nas_0024_ind->t01.in_use_radio_if_list_num) && (i < NAS_0024_IND_T01_RADIO_IF_MAX); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_0024_ind->t01.radio_if[i]);
        }
      }
      break;

      case NAS_0024_IND_T10:
      {
        nas_0024_ind->t10_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t10.roaming_indicator);
      }
      break;

      case NAS_0024_IND_T11:
      {
        nas_0024_ind->t11_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t11.data_capability_list_len);
        for (i = 0; (i < nas_0024_ind->t11.data_capability_list_len) && (i < NAS_0024_IND_T11_DATA_CAP_LIST_LEN_MAX); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_0024_ind->t11.data_capabilities[i]);
        }
      }
      break;      

      case NAS_0024_IND_T12:
      {
        nas_0024_ind->t12_valid = TRUE;        
        READ_16_BIT_VAL (value_ptr,nas_0024_ind->t12.mobile_country_code);
        READ_16_BIT_VAL (value_ptr,nas_0024_ind->t12.mobile_network_code);
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t12.network_description_length);

        if (nas_0024_ind->t12.network_description_length > 0)
        {
          int cpy_len = (nas_0024_ind->t12.network_description_length < NAS_0024_IND_T12_NET_DESC_LEN_MAX) 
                        ? nas_0024_ind->t12.network_description_length : (NAS_0024_IND_T12_NET_DESC_LEN_MAX - 1);
          memcpy (nas_0024_ind->t12.network_description, (void *)value_ptr, cpy_len);
          nas_0024_ind->t12.network_description[cpy_len] = '\0';
        }
        else
        {
          nas_0024_ind->t12.network_description[0] = '\0';
        }
      }
      break;

      case NAS_0024_IND_T13:
      {
        nas_0024_ind->t13_valid = TRUE;        
        READ_16_BIT_VAL (value_ptr,nas_0024_ind->t13.sid);
        READ_16_BIT_VAL (value_ptr,nas_0024_ind->t13.nid);
      }
      break;      

      case NAS_0024_IND_T14:
      {
        nas_0024_ind->t14_valid = TRUE;        
        READ_16_BIT_VAL (value_ptr,nas_0024_ind->t14.base_id);
        READ_32_BIT_VAL (value_ptr,nas_0024_ind->t14.base_lat);
        READ_32_BIT_VAL (value_ptr,nas_0024_ind->t14.base_long);        
      }
      break;     

      case NAS_0024_IND_T15:
      {
        nas_0024_ind->t15_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t15.num_instances);
        for (i = 0; (i < nas_0024_ind->t15.num_instances) && (i < NAS_0024_IND_T15_ROAM_IND_MAX); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_0024_ind->t15.roam_ind[i].radio_if);
          READ_8_BIT_VAL(value_ptr,nas_0024_ind->t15.roam_ind[i].roaming_indicator);          
        }  
      }
      break;      

      case NAS_0024_IND_T16:
      {
        nas_0024_ind->t16_valid = TRUE;        
        READ_16_BIT_VAL (value_ptr,nas_0024_ind->t16.def_roam_ind);
      }
      break; 

      case NAS_0024_IND_T17:
      {
        nas_0024_ind->t17_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t17.lp_sec);
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t17.ltm_offset);
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t17.daylt_savings);        
      }
      break; 

      case NAS_0024_IND_T18:
      {
        nas_0024_ind->t18_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t18.p_rev_in_use);
      }
      break;       

      case NAS_0024_IND_T19:
      {
        nas_0024_ind->t19_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t19.is_plmn_changed);
      }
      break;   

      case NAS_0024_IND_T1A:
      {
        nas_0024_ind->t1A_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t1A.time_zone);
      }
      break; 

      case NAS_0024_IND_T1B:
      {
        nas_0024_ind->t1B_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t1B.adj);
      }
      break;      

      case NAS_0024_IND_T1C:
      {
        nas_0024_ind->t1C_valid = TRUE;        
        READ_16_BIT_VAL (value_ptr,nas_0024_ind->t1C.year);
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t1C.month);
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t1C.day);
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t1C.hour);
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t1C.minute);  
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t1C.second);
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t1C.time_zone);         
      }
      break;   

      case NAS_0024_IND_T1D:
      {
        nas_0024_ind->t1D_valid = TRUE;        
        READ_16_BIT_VAL (value_ptr,nas_0024_ind->t1D.lac);
      }
      break;  

      case NAS_0024_IND_T1E:
      {
        nas_0024_ind->t1E_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,nas_0024_ind->t1E.cell_id);
      }
      break;  

      case NAS_0024_IND_T1F:
      {
        nas_0024_ind->t1F_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t1F.ccs);
      }
      break;   

      case NAS_0024_IND_T20:
      {
        nas_0024_ind->t20_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t20.prl_ind);
      }
      break;   

      case NAS_0024_IND_T21:
      {
        nas_0024_ind->t21_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t21.dtm_ind);
      }
      break;   

      case NAS_0024_IND_T22:
      {
        nas_0024_ind->t22_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t22.srv_status);
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t22.srv_capability);
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t22.hdr_srv_status);
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t22.hdr_hybrid);
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t22.is_sys_forbidden);        
      }
      break;     

      case NAS_0024_IND_T23:
      {
        nas_0024_ind->t23_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0024_ind->t23.mcc);
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t23.imsi_11_12);
      }
      break;       

      case NAS_0024_IND_T24:
      {
        nas_0024_ind->t24_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t24.hdr_personality);
      }
      break;

      case NAS_0024_IND_T25:
      {
        nas_0024_ind->t25_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0024_ind->t25.tac);
      }
      break; 

      case NAS_0024_IND_T26:
      {
        nas_0024_ind->t26_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,nas_0024_ind->t26.cs_bar_status);
        READ_32_BIT_VAL (value_ptr,nas_0024_ind->t26.ps_bar_status);        
      }
      break;        

      case NAS_0024_IND_T27:
      {
        nas_0024_ind->t27_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t27.srv_sys_no_change);
      }
      break; 

      case NAS_0024_IND_T28:
      {
        nas_0024_ind->t28_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0024_ind->t28.umts_psc);
      }
      break;    

      case NAS_0024_IND_T29:
      {
        nas_0024_ind->t29_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0024_ind->t29.mcc);
        READ_16_BIT_VAL (value_ptr,nas_0024_ind->t29.mnc); 
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t29.mnc_includes_pcs_digit);         
      }
      break; 

      case NAS_0024_IND_T2A:
      {
        nas_0024_ind->t2A_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0024_ind->t2A.hs_call_status);
      }
      break;      

      default:
        printf ("qmi_nas_ind_serving_system_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================

FUNCTION  nas_system_selection_preference_ind_process

===========================================================================*/
void nas_system_selection_preference_ind_process(nas_system_selection_preference_ind_msg_v01 *qmi_msg)
{
  int emergency_mode_entered = FALSE;
  int emergency_mode_left = FALSE;

  MSG_HIGH("nas_system_selection_preference_ind_process()", 0, 0, 0);

  if( qmi_msg->emergency_mode_valid )
  {
    emergency_mode_entered = (qmi_msg->emergency_mode == NAS_CMN_EMERGENCY_MODE_ON) ? TRUE : FALSE;
    emergency_mode_left    = (qmi_msg->emergency_mode == NAS_CMN_EMERGENCY_MODE_OFF) ? TRUE : FALSE;
  }

  //NAS_CACHE_LOCK();
  NAS_CACHE_STORE_TINY_ENTRY( nas_cached_info.emergency_mode, qmi_msg->emergency_mode );
  NAS_CACHE_STORE_TINY_ENTRY( nas_cached_info.mode_pref, qmi_msg->mode_pref );
  NAS_CACHE_STORE_TINY_ENTRY( nas_cached_info.band_pref, qmi_msg->band_pref );
  NAS_CACHE_STORE_TINY_ENTRY( nas_cached_info.prl_pref, qmi_msg->prl_pref );
  NAS_CACHE_STORE_TINY_ENTRY( nas_cached_info.roam_pref, qmi_msg->roam_pref );
  NAS_CACHE_STORE_TINY_ENTRY( nas_cached_info.lte_band_pref, qmi_msg->lte_band_pref );
  NAS_CACHE_STORE_TINY_ENTRY( nas_cached_info.net_sel_pref, qmi_msg->net_sel_pref );

  MSG_HIGH( ".. new mode pref valid %, value %d", (int)qmi_msg->mode_pref_valid, (int) qmi_msg->mode_pref, 0 );
  MSG_HIGH( ".. new net sel pref valid %, value %d", (int)qmi_msg->net_sel_pref_valid, (int) qmi_msg->net_sel_pref, 0 );
  MSG_HIGH( ".. new emergency mode valid %, value %d", (int)qmi_msg->emergency_mode_valid, (int) qmi_msg->emergency_mode, 0 );
  MSG_HIGH( ".. new prl pref valid %, value %d", (int)qmi_msg->prl_pref_valid, (int) qmi_msg->prl_pref, 0 );

  //NAS_CACHE_UNLOCK();

  if( emergency_mode_entered )
  {
    MSG_HIGH(".. EME CB set event, however relying on manual setting of eme cb, cur_mode %d",
              (int) qmi_ril_nwr_get_eme_cbm(), 0, 0 );
    qmi_ril_nwr_set_eme_cbm( QMI_RIL_EME_CBM_ACTIVE );
  }

  if( emergency_mode_left )
  {
    qmi_ril_nwr_set_eme_cbm( QMI_RIL_EME_CBM_NOT_ACTIVE );
  }
}

/*===========================================================================

  FUNCTION  qmi_nas_network_time_info_ind

===========================================================================*/
static int
qmi_nas_network_time_info_ind
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_004C_ind_s             *nas_004C_ind  
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;  

  memset(nas_004C_ind, 0, sizeof(nas_004C_ind_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case NAS_004C_IND_T01:
      {
        nas_004C_ind->t01_valid = TRUE;
        READ_16_BIT_VAL(value_ptr,nas_004C_ind->t01.year);
        READ_8_BIT_VAL(value_ptr,nas_004C_ind->t01.month);
        READ_8_BIT_VAL(value_ptr,nas_004C_ind->t01.day);
        READ_8_BIT_VAL(value_ptr,nas_004C_ind->t01.hour);
        READ_8_BIT_VAL(value_ptr,nas_004C_ind->t01.minute);
        READ_8_BIT_VAL(value_ptr,nas_004C_ind->t01.second);
        READ_8_BIT_VAL(value_ptr,nas_004C_ind->t01.day_of_week);
      }
      break;

      case NAS_004C_IND_T10:
      {
        nas_004C_ind->t10_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_004C_ind->t10.time_zone);
      }
      break;

      case NAS_004C_IND_T11:
      {
        nas_004C_ind->t11_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_004C_ind->t11.daylt_sav_adj);
      }
      break;

      case NAS_004C_IND_T12:
      {
        nas_004C_ind->t12_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_004C_ind->t12.radio_if);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_network_time_info_ind: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_system_info_ind
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with serving system info.  It
  is used both by the get serving system info cmd response as well as the
  serving system indication.   
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_system_info_ind
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_sys_info_ind_msg_v01          *nas_004E_ind
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;  

  memset(nas_004E_ind, 0, sizeof(nas_sys_info_ind_msg_v01));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case NAS_004E_IND_T10:
      {
        nas_004E_ind->cdma_srv_status_info_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_srv_status_info.srv_status);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_srv_status_info.is_pref_data_path);		
      }
      break;

      case NAS_004E_IND_T11:
      {
        nas_004E_ind->hdr_srv_status_info_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->hdr_srv_status_info.srv_status);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->hdr_srv_status_info.is_pref_data_path);        
      }
      break;      

      case NAS_004E_IND_T12:
      {
        nas_004E_ind->gsm_srv_status_info_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_srv_status_info.srv_status);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_srv_status_info.true_srv_status);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_srv_status_info.is_pref_data_path);   
      }
      break;

      case NAS_004E_IND_T13:
      {
        nas_004E_ind->wcdma_srv_status_info_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_srv_status_info.srv_status);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_srv_status_info.true_srv_status);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_srv_status_info.is_pref_data_path);  
      }
      break;      

      case NAS_004E_IND_T14:
      {
        nas_004E_ind->lte_srv_status_info_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->lte_srv_status_info.srv_status);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->lte_srv_status_info.true_srv_status);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->lte_srv_status_info.is_pref_data_path);         
      }
      break;  

      case NAS_004E_IND_T15:
      {
        nas_004E_ind->cdma_sys_info_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.common_sys_info.srv_domain_valid);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.common_sys_info.srv_domain);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.common_sys_info.srv_capability_valid);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.common_sys_info.srv_capability);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.common_sys_info.roam_status_valid);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.common_sys_info.roam_status);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.common_sys_info.is_sys_forbidden_valid);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.common_sys_info.is_sys_forbidden);	

        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.cdma_hdr_only_sys_info.is_sys_prl_match_valid);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.cdma_hdr_only_sys_info.is_sys_prl_match);

        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.cdma_specific_sys_info.p_rev_in_use_valid);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.cdma_specific_sys_info.p_rev_in_use);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.cdma_specific_sys_info.bs_p_rev_valid);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.cdma_specific_sys_info.bs_p_rev);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.cdma_specific_sys_info.ccs_supported_valid);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.cdma_specific_sys_info.ccs_supported);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.cdma_specific_sys_info.cdma_sys_id_valid);		
        READ_16_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.cdma_specific_sys_info.cdma_sys_id.sid);				
        READ_16_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.cdma_specific_sys_info.cdma_sys_id.nid);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.cdma_specific_sys_info.bs_info_valid);		
        READ_16_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.cdma_specific_sys_info.bs_info.base_id);				
        READ_32_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.cdma_specific_sys_info.bs_info.base_lat);
        READ_32_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.cdma_specific_sys_info.bs_info.base_long);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.cdma_specific_sys_info.packet_zone_valid);			
        READ_16_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.cdma_specific_sys_info.packet_zone);					
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info.cdma_specific_sys_info.network_id_valid);		
        
        for (i = 0; (i < 3); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_004E_ind->cdma_sys_info.cdma_specific_sys_info.network_id.mcc[i]);
//BKS_20131216 modify
        }
        for (i = 0; (i < 3); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_004E_ind->cdma_sys_info.cdma_specific_sys_info.network_id.mnc[i]);          
        }  
      }
      break;      

      case NAS_004E_IND_T16:
      {
        nas_004E_ind->hdr_sys_info_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->hdr_sys_info.common_sys_info.srv_domain_valid);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->hdr_sys_info.common_sys_info.srv_domain);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->hdr_sys_info.common_sys_info.srv_capability_valid);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->hdr_sys_info.common_sys_info.srv_capability);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->hdr_sys_info.common_sys_info.roam_status_valid);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->hdr_sys_info.common_sys_info.roam_status);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->hdr_sys_info.common_sys_info.is_sys_forbidden_valid);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->hdr_sys_info.common_sys_info.is_sys_forbidden);	

        READ_8_BIT_VAL (value_ptr,nas_004E_ind->hdr_sys_info.cdma_hdr_only_sys_info.is_sys_prl_match_valid);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->hdr_sys_info.cdma_hdr_only_sys_info.is_sys_prl_match);

        READ_8_BIT_VAL (value_ptr,nas_004E_ind->hdr_sys_info.hdr_specific_sys_info.hdr_personality_valid);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->hdr_sys_info.hdr_specific_sys_info.hdr_personality);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->hdr_sys_info.hdr_specific_sys_info.hdr_active_prot_valid);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->hdr_sys_info.hdr_specific_sys_info.hdr_active_prot);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->hdr_sys_info.hdr_specific_sys_info.is856_sys_id_valid);	
        
        for (i = 0; (i < NAS_IS_856_MAX_LEN); i++ )
        {
          READ_8_BIT_VAL (value_ptr,nas_004E_ind->hdr_sys_info.hdr_specific_sys_info.is856_sys_id[i]);        
        }  				
      }
      break; 

      case NAS_004E_IND_T17:
      {
        nas_004E_ind->gsm_sys_info_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info.common_sys_info.srv_domain_valid);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info.common_sys_info.srv_domain);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info.common_sys_info.srv_capability_valid);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info.common_sys_info.srv_capability);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info.common_sys_info.roam_status_valid);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info.common_sys_info.roam_status);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info.common_sys_info.is_sys_forbidden_valid);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info.common_sys_info.is_sys_forbidden);	       

        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info.threegpp_specific_sys_info.lac_valid);
        READ_16_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info.threegpp_specific_sys_info.lac);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info.threegpp_specific_sys_info.cell_id_valid);				
        READ_32_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info.threegpp_specific_sys_info.cell_id);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info.threegpp_specific_sys_info.reg_reject_info_valid);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info.threegpp_specific_sys_info.reg_reject_info.reject_srv_domain);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info.threegpp_specific_sys_info.reg_reject_info.rej_cause);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info.threegpp_specific_sys_info.network_id_valid);	
        
        for (i = 0; (i < 3); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_004E_ind->gsm_sys_info.threegpp_specific_sys_info.network_id.mcc[i]);
//BKS_20131216 modify
        }
        for (i = 0; (i < 3); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_004E_ind->gsm_sys_info.threegpp_specific_sys_info.network_id.mnc[i]);          
        } 		

        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info.gsm_specific_sys_info.egprs_supp_valid);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info.gsm_specific_sys_info.egprs_supp);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info.gsm_specific_sys_info.dtm_supp_valid);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info.gsm_specific_sys_info.dtm_supp);
      }
      break; 

      case NAS_004E_IND_T18:
      {
        nas_004E_ind->wcdma_sys_info_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.common_sys_info.srv_domain_valid);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.common_sys_info.srv_domain);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.common_sys_info.srv_capability_valid);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.common_sys_info.srv_capability);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.common_sys_info.roam_status_valid);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.common_sys_info.roam_status);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.common_sys_info.is_sys_forbidden_valid);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.common_sys_info.is_sys_forbidden);	

        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.threegpp_specific_sys_info.lac_valid);
        READ_16_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.threegpp_specific_sys_info.lac);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.threegpp_specific_sys_info.cell_id_valid);				
        READ_32_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.threegpp_specific_sys_info.cell_id);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.threegpp_specific_sys_info.reg_reject_info_valid);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.threegpp_specific_sys_info.reg_reject_info.reject_srv_domain);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.threegpp_specific_sys_info.reg_reject_info.rej_cause);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.threegpp_specific_sys_info.network_id_valid);	 
      
        for (i = 0; (i < 3); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_004E_ind->wcdma_sys_info.threegpp_specific_sys_info.network_id.mcc[i]);
//BKS_20131216 modify
        }
        for (i = 0; (i < 3); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_004E_ind->wcdma_sys_info.threegpp_specific_sys_info.network_id.mnc[i]);          
        } 				

        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.wcdma_specific_sys_info.hs_call_status_valid);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.wcdma_specific_sys_info.hs_call_status);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.wcdma_specific_sys_info.hs_ind_valid);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.wcdma_specific_sys_info.hs_ind);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.wcdma_specific_sys_info.psc_valid);				
        READ_16_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info.wcdma_specific_sys_info.psc);				
      }
      break;       

      case NAS_004E_IND_T19:
      {
        nas_004E_ind->lte_sys_info_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->lte_sys_info.common_sys_info.srv_domain_valid);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->lte_sys_info.common_sys_info.srv_domain);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->lte_sys_info.common_sys_info.srv_capability_valid);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->lte_sys_info.common_sys_info.srv_capability);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->lte_sys_info.common_sys_info.roam_status_valid);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->lte_sys_info.common_sys_info.roam_status);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->lte_sys_info.common_sys_info.is_sys_forbidden_valid);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->lte_sys_info.common_sys_info.is_sys_forbidden);	

        READ_8_BIT_VAL (value_ptr,nas_004E_ind->lte_sys_info.threegpp_specific_sys_info.lac_valid);
        READ_16_BIT_VAL (value_ptr,nas_004E_ind->lte_sys_info.threegpp_specific_sys_info.lac);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->lte_sys_info.threegpp_specific_sys_info.cell_id_valid);				
        READ_32_BIT_VAL (value_ptr,nas_004E_ind->lte_sys_info.threegpp_specific_sys_info.cell_id);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->lte_sys_info.threegpp_specific_sys_info.reg_reject_info_valid);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->lte_sys_info.threegpp_specific_sys_info.reg_reject_info.reject_srv_domain);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->lte_sys_info.threegpp_specific_sys_info.reg_reject_info.rej_cause);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->lte_sys_info.threegpp_specific_sys_info.network_id_valid);
        
        for (i = 0; (i < 3); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_004E_ind->lte_sys_info.threegpp_specific_sys_info.network_id.mcc[i]);
//BKS_20131216 modify
        }
        for (i = 0; (i < 3); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_004E_ind->lte_sys_info.threegpp_specific_sys_info.network_id.mnc[i]);          
        } 				

        READ_8_BIT_VAL (value_ptr,nas_004E_ind->lte_sys_info.lte_specific_sys_info.tac_valid);				
        READ_16_BIT_VAL (value_ptr,nas_004E_ind->lte_sys_info.lte_specific_sys_info.tac);
      }
      break;   

      case NAS_004E_IND_T1A:
      {
        nas_004E_ind->cdma_sys_info2_valid = TRUE;        
        READ_16_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info2.geo_sys_idx);
        READ_16_BIT_VAL (value_ptr,nas_004E_ind->cdma_sys_info2.reg_prd);		
      }
      break; 

      case NAS_004E_IND_T1B:
      {
        nas_004E_ind->hdr_sys_info2_valid = TRUE;        
        READ_16_BIT_VAL (value_ptr,nas_004E_ind->hdr_sys_info2.geo_sys_idx);
      }
      break;      

      case NAS_004E_IND_T1C:
      {
        nas_004E_ind->gsm_sys_info2_valid = TRUE;        
        READ_16_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info2.geo_sys_idx);
        READ_32_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info2.cell_broadcast_cap);         
      }
      break;   

      case NAS_004E_IND_T1D:
      {
        nas_004E_ind->wcdma_sys_info2_valid = TRUE;        
        READ_16_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info2.geo_sys_idx);
        READ_32_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info2.cell_broadcast_cap);
      }
      break;  

      case NAS_004E_IND_T1E:
      {
        nas_004E_ind->lte_sys_info2_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_004E_ind->lte_sys_info2.geo_sys_idx);
      }
      break;  

      case NAS_004E_IND_T1F:
      {
        nas_004E_ind->gsm_sys_info3_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info3.cs_bar_status);
        READ_32_BIT_VAL (value_ptr,nas_004E_ind->gsm_sys_info3.ps_bar_status);		
      }
      break;   

      case NAS_004E_IND_T20:
      {
        nas_004E_ind->wcdma_sys_info3_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info3.cs_bar_status);
        READ_32_BIT_VAL (value_ptr,nas_004E_ind->wcdma_sys_info3.ps_bar_status);
      }
      break;   

      case NAS_004E_IND_T21:
      {
        nas_004E_ind->voice_support_on_lte_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->voice_support_on_lte);
      }
      break;   

      case NAS_004E_IND_T22:
      {
        nas_004E_ind->gsm_cipher_domain_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_cipher_domain);
      }
      break;     

      case NAS_004E_IND_T23:
      {
        nas_004E_ind->wcdma_cipher_domain_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_cipher_domain);
      }
      break;       

      case NAS_004E_IND_T24:
      {
        nas_004E_ind->sys_info_no_change_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->sys_info_no_change);
      }
      break;

      case NAS_004E_IND_T25:
      {
        nas_004E_ind->tdscdma_srv_status_info_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_srv_status_info.srv_status);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_srv_status_info.true_srv_status);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_srv_status_info.is_pref_data_path);		
      }
      break; 

      case NAS_004E_IND_T26:
      {
        nas_004E_ind->tdscdma_sys_info_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.common_sys_info.srv_domain_valid);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.common_sys_info.srv_domain);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.common_sys_info.srv_capability_valid);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.common_sys_info.srv_capability);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.common_sys_info.roam_status_valid);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.common_sys_info.roam_status);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.common_sys_info.is_sys_forbidden_valid);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.common_sys_info.is_sys_forbidden);	

        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.threegpp_specific_sys_info.lac_valid);
        READ_16_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.threegpp_specific_sys_info.lac);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.threegpp_specific_sys_info.cell_id_valid);				
        READ_32_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.threegpp_specific_sys_info.cell_id);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.threegpp_specific_sys_info.reg_reject_info_valid);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.threegpp_specific_sys_info.reg_reject_info.reject_srv_domain);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.threegpp_specific_sys_info.reg_reject_info.rej_cause);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.threegpp_specific_sys_info.network_id_valid);	 
        
        for (i = 0; (i < 3); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_004E_ind->tdscdma_sys_info.threegpp_specific_sys_info.network_id.mcc[i]);
//BKS_20131216 modify
        }
        for (i = 0; (i < 3); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_004E_ind->tdscdma_sys_info.threegpp_specific_sys_info.network_id.mnc[i]);          
        } 			

        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.tdscdma_specific_sys_info.hs_call_status_valid);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.tdscdma_specific_sys_info.hs_call_status);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.tdscdma_specific_sys_info.hs_ind_valid);				
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.tdscdma_specific_sys_info.hs_ind);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.tdscdma_specific_sys_info.cell_parameter_id_valid);
        READ_16_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.tdscdma_specific_sys_info.cell_parameter_id);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.tdscdma_specific_sys_info.cell_broadcast_cap_valid);				
        READ_32_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.tdscdma_specific_sys_info.cell_broadcast_cap);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.tdscdma_specific_sys_info.cs_bar_status_valid);
        READ_32_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.tdscdma_specific_sys_info.cs_bar_status);		
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.tdscdma_specific_sys_info.ps_bar_status_valid);				
        READ_32_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.tdscdma_specific_sys_info.ps_bar_status);
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.tdscdma_specific_sys_info.cipher_domain_valid);						
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->tdscdma_sys_info.tdscdma_specific_sys_info.cipher_domain);						
      }
      break;        

      case NAS_004E_IND_T27:
      {
        nas_004E_ind->lte_embms_coverage_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->lte_embms_coverage);
      }
      break; 

      case NAS_004E_IND_T28:
      {
        nas_004E_ind->sim_rej_info_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,nas_004E_ind->sim_rej_info);
      }
      break;    

      case NAS_004E_IND_T29:
      {
        nas_004E_ind->wcdma_eutra_status_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_eutra_status);
      }
      break; 

      case NAS_004E_IND_T2A:
      {
        nas_004E_ind->lte_ims_voice_avail_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->lte_ims_voice_avail);
      }
      break; 

      case NAS_004E_IND_T2B:
      {
        nas_004E_ind->lte_voice_status_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,nas_004E_ind->lte_voice_status);
      }
      break; 

      case NAS_004E_IND_T2C:
      {
        nas_004E_ind->cdma_reg_zone_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_004E_ind->cdma_reg_zone);
      }
      break; 

      case NAS_004E_IND_T2D:
      {
        nas_004E_ind->gsm_rac_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->gsm_rac);
      }
      break; 

      case NAS_004E_IND_T2E:
      {
        nas_004E_ind->wcdma_rac_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_004E_ind->wcdma_rac);
      }
      break; 

      case NAS_004E_IND_T2F:
      {
        nas_004E_ind->cdma_mcc_resolved_via_sid_lookup_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_004E_ind->cdma_mcc_resolved_via_sid_lookup);
      }
      break;      

      default:
        //QMI_DEBUG_MSG_1 ("qmi_nas_ind_system_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================

FUNCTION  qmi_nas_sig_info_ind

===========================================================================*/
static int
qmi_nas_sig_info_ind
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_0051_ind_s				*nas_0051_ind  
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;  

  memset(nas_0051_ind, 0, sizeof(nas_0051_ind_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                                            &rx_buf_len,
                                            &type,
                                            &length,
                                            &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      // CDMA Signal Strength Info
      case NAS_0051_IND_T10:
      {  
        nas_0051_ind->t10_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_0051_ind->t10.rssi);
        READ_16_BIT_VAL(value_ptr,nas_0051_ind->t10.ecio);
      }
      break;

      // HDR Signal Strength Info
      case NAS_0051_IND_T11:
      {      
        nas_0051_ind->t11_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_0051_ind->t11.rssi);
        READ_16_BIT_VAL(value_ptr,nas_0051_ind->t11.ecio);
        READ_8_BIT_VAL(value_ptr,nas_0051_ind->t11.sinr);
        READ_32_BIT_VAL(value_ptr,nas_0051_ind->t11.io);
      }
      break;

      // GSM Signal Strength Info
      case NAS_0051_IND_T12:
      {      
        nas_0051_ind->t12_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_0051_ind->t12.gsm_sig_info);
      }
      break;

      // WCDMA Signal Strength Info
      case NAS_0051_IND_T13:
      {          
        nas_0051_ind->t13_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_0051_ind->t13.rssi);
        READ_16_BIT_VAL(value_ptr,nas_0051_ind->t13.ecio);
      }
      break;

      // LTE Signal Strength Info
      case NAS_0051_IND_T14:
      {          
        nas_0051_ind->t14_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_0051_ind->t14.rssi);
        READ_8_BIT_VAL(value_ptr,nas_0051_ind->t14.rsrq);
        READ_16_BIT_VAL(value_ptr,nas_0051_ind->t14.rsrp);
        READ_16_BIT_VAL(value_ptr,nas_0051_ind->t14.snr);
      }
      break;

      // TDSCDMA Signal Strength Info
      case NAS_0051_IND_T15:
      {
        nas_0051_ind->t15_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_0051_ind->t15.rscp);
      }
      break;

      // TDSCDMA Signal Strength Info Extended
      case NAS_0051_IND_T16:
      {
        nas_0051_ind->t16_valid = TRUE;
        READ_32_BIT_VAL(value_ptr,nas_0051_ind->t16.rssi);
        READ_32_BIT_VAL(value_ptr,nas_0051_ind->t16.rscp);
        READ_32_BIT_VAL(value_ptr,nas_0051_ind->t16.ecio);
        READ_32_BIT_VAL(value_ptr,nas_0051_ind->t16.sinr);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_sig_info_rsp : Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================

FUNCTION  qmi_nas_current_plmn_name_ind

===========================================================================*/
static int
qmi_nas_current_plmn_name_ind
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_0061_ind_s                    *nas_0061_ind  
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;  

  memset(nas_0061_ind, 0, sizeof(nas_0061_ind_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                                            &rx_buf_len,
                                            &type,
                                            &length,
                                            &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case NAS_0061_IND_T10:
      {  
        nas_0061_ind->t10_valid = TRUE;
        READ_16_BIT_VAL(value_ptr,nas_0061_ind->t10.mcc);
        READ_16_BIT_VAL(value_ptr,nas_0061_ind->t10.mnc);
        READ_8_BIT_VAL(value_ptr,nas_0061_ind->t10.mnc_includes_pcs_digit);
      }
      break;

      case NAS_0061_IND_T11:
      {
        int i = 0;
        nas_0061_ind->t11_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_0061_ind->t11.srv_prov_name_encoding);
        READ_8_BIT_VAL(value_ptr,nas_0061_ind->t11.srv_prov_name_len);
        for (i = 0; i < nas_0061_ind->t11.srv_prov_name_len; i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_0061_ind->t11.srv_prov_name_name[i]);
        } 	
      }
      break;

      case NAS_0061_IND_T12:
      {      
        int i = 0;
        nas_0061_ind->t12_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_0061_ind->t12.plmn_name_short_encoding);
        READ_8_BIT_VAL(value_ptr,nas_0061_ind->t12.plmn_name_short_ci);
        READ_8_BIT_VAL(value_ptr,nas_0061_ind->t12.plmn_name_short_spare_bits);
        READ_8_BIT_VAL(value_ptr,nas_0061_ind->t12.plmn_name_short_len);
        for (i = 0; i < nas_0061_ind->t12.plmn_name_short_len; i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_0061_ind->t12.plmn_name_short[i]);
        } 
      }
      break;

      case NAS_0061_IND_T13:
      {          
        int i = 0;
        nas_0061_ind->t13_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_0061_ind->t13.plmn_name_long_encoding);
        READ_8_BIT_VAL(value_ptr,nas_0061_ind->t13.plmn_name_long_ci);
        READ_8_BIT_VAL(value_ptr,nas_0061_ind->t13.plmn_name_long_spare_bits);
        READ_8_BIT_VAL(value_ptr,nas_0061_ind->t13.plmn_name_long_len);
        for (i = 0; i < nas_0061_ind->t13.plmn_name_long_len; i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_0061_ind->t13.plmn_name_long[i]);
        } 
      }
      break;

      case NAS_0061_IND_T14:
      {          
        nas_0061_ind->t14_valid = TRUE;
        READ_32_BIT_VAL(value_ptr,nas_0061_ind->t14.csg_id);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_current_plmn_name_ind : Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================

FUNCTION  qmi_nas_network_reject_ind

===========================================================================*/
static int
qmi_nas_network_reject_ind
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_0068_ind_s            *nas_0068_ind
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_0068_ind, 0, sizeof(nas_0068_ind_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                                            &rx_buf_len,
                                            &type,
                                            &length,
                                            &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      // Radio Interface
      case NAS_0068_IND_T01:
      {
        //nas_0068_rsp->t01_valid= TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0068_ind->t01.radio_if);
      }
      break;

      // Service Domain
      case NAS_0068_IND_T02:
      {
        //nas_0068_rsp->t02_valid= TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0068_ind->t02.reject_srv_domain);
      }
      break;

      // Registration Rejection Cause
      case NAS_0068_IND_T03:
      {
        //nas_0068_rsp->t02_valid= TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0068_ind->t03.rej_cause);
      }
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================

  FUNCTION  qmi_nas_ota_event_log_save_ind

===========================================================================*/
static int
qmi_nas_ota_event_log_save_ind
(
  unsigned char                    *rx_buf,
  int                               rx_buf_len,
  nas_5573_ind_s                   *nas_5573_ind
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;  

  memset(nas_5573_ind, 0x0, sizeof(nas_5573_ind_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case NAS_5573_IND_T01:
      {
        READ_8_BIT_VAL(value_ptr,nas_5573_ind->t01.message_len);
        for(i=0; i<nas_5573_ind->t01.message_len; i++)
        {
          READ_8_BIT_VAL(value_ptr,nas_5573_ind->t01.message[i]);
        }

        MSG_HIGH("[OTA] %s", nas_5573_ind->t01.message, 0, 0);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_network_time_info_ind: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================

  FUNCTION  qmi_nas_signal_strength_ind

===========================================================================*/
static int
qmi_nas_signal_strength_ind
(
  unsigned char                    *rx_buf,
  int                               rx_buf_len,
  nas_701A_ind_s            *nas_701A_ind
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;  

  memset(nas_701A_ind, 0x0, sizeof(nas_701A_ind_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case NAS_701A_IND_T01:
      {
        READ_8_BIT_VAL(value_ptr,nas_701A_ind->t01.message_len);
        READ_32_BIT_VAL(value_ptr,nas_701A_ind->t01.signal_strength.GW_SignalStrength.signalStrength);
        READ_32_BIT_VAL(value_ptr,nas_701A_ind->t01.signal_strength.GW_SignalStrength.bitErrorRate);
        READ_32_BIT_VAL(value_ptr,nas_701A_ind->t01.signal_strength.CDMA_SignalStrength.dbm);
        READ_32_BIT_VAL(value_ptr,nas_701A_ind->t01.signal_strength.CDMA_SignalStrength.ecio);
        READ_32_BIT_VAL(value_ptr,nas_701A_ind->t01.signal_strength.EVDO_SignalStrength.dbm);
        READ_32_BIT_VAL(value_ptr,nas_701A_ind->t01.signal_strength.EVDO_SignalStrength.ecio);
        READ_32_BIT_VAL(value_ptr,nas_701A_ind->t01.signal_strength.EVDO_SignalStrength.signalNoiseRatio);
        READ_32_BIT_VAL(value_ptr,nas_701A_ind->t01.signal_strength.LTE_SignalStrength.signalStrength);
        READ_32_BIT_VAL(value_ptr,nas_701A_ind->t01.signal_strength.LTE_SignalStrength.rsrp);
        READ_32_BIT_VAL(value_ptr,nas_701A_ind->t01.signal_strength.LTE_SignalStrength.rsrq);
        READ_32_BIT_VAL(value_ptr,nas_701A_ind->t01.signal_strength.LTE_SignalStrength.rssnr);
        READ_32_BIT_VAL(value_ptr,nas_701A_ind->t01.signal_strength.LTE_SignalStrength.cqi);
        nas_701A_ind->t01_valid = TRUE;

        READ_8_BIT_VAL(value_ptr,nas_701A_ind->t01.SignalStrength_Extension_valid);
        if(nas_701A_ind->t01.SignalStrength_Extension_valid)
        {
          READ_8_BIT_VAL(value_ptr,nas_701A_ind->t01.Service_Status.gw_srv_status);
          READ_8_BIT_VAL(value_ptr,nas_701A_ind->t01.Service_Status.cdma_srv_status);
          READ_8_BIT_VAL(value_ptr,nas_701A_ind->t01.Service_Status.hdr_srv_status);
          READ_8_BIT_VAL(value_ptr,nas_701A_ind->t01.Service_Status.lte_srv_status);
        }

/*
        MSG_HIGH_4("[Signal Strength] WCDMA RSSI = %d BER = %d", 
                                                          nas_701A_ind->t01.signal_strength.GW_SignalStrength.signalStrength, 
                                                          nas_701A_ind->t01.signal_strength.GW_SignalStrength.bitErrorRate, 0,0);

        MSG_HIGH_4("[Signal Strength] CDMA RSSI = %d ECIO = %d", 
                                                          nas_701A_ind->t01.signal_strength.CDMA_SignalStrength.dbm, 
                                                          nas_701A_ind->t01.signal_strength.CDMA_SignalStrength.ecio, 0,0);

        MSG_HIGH_4("[Signal Strength] EVDO RSSI = %d ECIO = %d SNR = %d", 
                                                          nas_701A_ind->t01.signal_strength.EVDO_SignalStrength.dbm, 
                                                          nas_701A_ind->t01.signal_strength.EVDO_SignalStrength.ecio, 
                                                          nas_701A_ind->t01.signal_strength.EVDO_SignalStrength.signalNoiseRatio, 0);
        
        MSG_HIGH_4("[Signal Strength] LTE RSSI = %d RSRP = %d RSRQ = %d SNR = %d", 
                                                          nas_701A_ind->t01.signal_strength.LTE_SignalStrength.signalStrength, 
                                                          nas_701A_ind->t01.signal_strength.LTE_SignalStrength.rsrp, 
                                                          nas_701A_ind->t01.signal_strength.LTE_SignalStrength.rsrq,
                                                          nas_701A_ind->t01.signal_strength.LTE_SignalStrength.rssnr);
 */                                                         
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_signal_strength_ind: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================

  FUNCTION  qmi_nas_apn_changed_ind

===========================================================================*/
static int
qmi_nas_apn_changed_ind
(
  unsigned char                    *rx_buf,
  int                               rx_buf_len,
  nas_701B_ind_s            *nas_701B_ind
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;

  memset(nas_701B_ind, 0x0, sizeof(nas_701B_ind_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case NAS_701B_IND_T01:
      {
        memcpy((char *)(nas_701B_ind->t01.apn),(char *)value_ptr,sizeof(nas_701B_ind->t01.apn));

        nas_701B_ind->t01_valid = TRUE;                                                     
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_apn_changed_ind: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================

  FUNCTION  qmi_nas_sim_state_ind

===========================================================================*/
static int
qmi_nas_sim_state_ind
(
  unsigned char                    *rx_buf,
  int                               rx_buf_len,
  nas_7043_ind_s            *nas_7043_ind
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;

  memset(nas_7043_ind, 0x0, sizeof(nas_7043_ind_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case NAS_7043_IND_T01:
      {
			  uint8  temp_8bit;
					
				READ_8_BIT_VAL (value_ptr, temp_8bit);
				nas_7043_ind->t01.sim_state = temp_8bit;

        nas_7043_ind->t01_valid = TRUE;                                                     
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_sim_state_ind: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

int qmi_nas_sim_state_value_sync(int lgit_sim_state_value)
{
	int bosch_sim_state_value = -1;

	switch(lgit_sim_state_value)
	{
		case 0 : // SYS_SIM_STATE_NOT_AVAILABLE
		{
			bosch_sim_state_value = 3;
		}
		break;

		case 1 : // SYS_SIM_STATE_AVAILABLE
		{
			bosch_sim_state_value = 0;
		}
		break;

		case 2 : // SYS_SIM_STATE_CS_INVALID
		{
			bosch_sim_state_value = 1;
		}
		break;

		case 3 : // SYS_SIM_STATE_PS_INVALID
		{
			bosch_sim_state_value = 4;
		}
		break;

		case 4 : // SYS_SIM_STATE_CS_PS_INVALID
		{
			bosch_sim_state_value = 2;
		}
		break;

		default : // SYS_SIM_STATE_NONE
		{
			bosch_sim_state_value = -1;
		}
	}

	return bosch_sim_state_value;
}


#if 0
/*===========================================================================

FUNCTION  nas_event_report_info_ind_process

===========================================================================*/
void nas_event_report_info_ind_process(nas_0002_ind_s *nas_0002_ind)
{
  int i=0, rssi=0;

  // Signal Strength
  if (nas_0002_ind->t10_valid)
  {
    MSG_HIGH("[NAS] sig_strength = %d radio_if = %d", nas_0002_ind->t10.sig_strength, nas_0002_ind->t10.radio_if, 0);
  }
/*
  // RF Band Information List
  if (nas_0002_ind->t11_valid)
  {
    for (i = 0; (i < nas_0002_ind->t11.num_instances) && (i < NAS_0002_IND_T11_MAX_RADIO_IFS); i++ )
    {
      MSG_HIGH("   rf_band[%d].radio_if = %d", i, nas_0002_ind->t11.rf_band[i].radio_if, 0);
      MSG_HIGH("   rf_band[%d].active_band = %d", i, nas_0002_ind->t11.rf_band[i].active_band, 0);
      MSG_HIGH("   rf_band[%d].active_channel = %d", i, nas_0002_ind->t11.rf_band[i].active_channel, 0);
    } 		
  }

  // Registration Reject Reason**
  if (nas_0002_ind->t12_valid)
  {
    MSG_HIGH("[NAS] service_domain = %d reject_cause = %d", nas_0002_ind->t12.service_domain, nas_0002_ind->t12.reject_cause, 0);
  }
*/
}
#endif

/*===========================================================================

FUNCTION  nas_serving_system_ind_process

===========================================================================*/
void nas_serving_system_ind_process(nas_0024_ind_s *nas_0024_ind)
{
  boolean is_update_state = FALSE, is_update_nitz_time = FALSE;
  int i=0, tmp_value = 0;
  char tmp_buf[256] = {0};

  // Roaming Indicator Value
  if (nas_0024_ind->t10_valid)
  {
    //printf("   roaming_indicator = %d", nas_0024_ind->t10.roaming_indicator);
  }
/*
  // Data Service Capability
  if (nas_0024_ind->t11_valid)
  {
    for (i = 0; (i < nas_0024_ind->t11.data_capability_list_len) && (i < NAS_0024_IND_T11_DATA_CAP_LIST_LEN_MAX); i++ )
    {
      printf("   data_capabilities[%d] = %d", i, nas_0024_ind->t11.data_capabilities[i]);
    }
  }
*/
  // Current PLMN
  if (nas_0024_ind->t12_valid)
  {
    //printf("[NAS] mcc = %d mnc = %d", nas_0024_ind->t12.mobile_country_code, nas_0024_ind->t12.mobile_network_code);
  }

  // CDMA System ID
  if (nas_0024_ind->t13_valid)
  {
    printf("[NAS] cdma sid = %d nid = %d\r\n", nas_0024_ind->t13.sid, nas_0024_ind->t13.nid);
  }

  // CDMA Base Station Information
  if (nas_0024_ind->t14_valid)
  {
    printf("[NAS] cdma base_id = %d base_lat = %d base_long = %d\r\n", nas_0024_ind->t14.base_id, 
                                                                     nas_0024_ind->t14.base_lat, 
                                                                     nas_0024_ind->t14.base_long);
  }
/*
  // Roaming Indicator List
  if (nas_0024_ind->t15_valid)
  {
    //printf("   num_instances = %d", nas_0024_ind->t15.num_instances);
    //printf("   radio_if = %d", nas_0024_ind.t15.radio_if);
    //printf("   roaming_indicator = %d", nas_0024_ind.t15.roaming_indicator);
  }
*/
  // Default Roaming Indicator
  if (nas_0024_ind->t16_valid)
  {
    printf("[NAS] def_roam_ind = %d\r\n", nas_0024_ind->t16.def_roam_ind);
    nas_cached_info.def_roam_ind_valid = TRUE;
    nas_cached_info.def_roam_ind = nas_0024_ind->t16.def_roam_ind;
  }

  // 3GGP2 Time Zone
  if (nas_0024_ind->t17_valid)
  {
    // �� �κ��� CDMA ���� �� �߰� �ʿ�
    //if(wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW)
   // {
   //   is_update_nitz_time = TRUE;
   // }
    printf("[NAS] 3GGP2 lp_sec = %d ltm_offset = %d daylt_savings = %d\r\n", nas_0024_ind->t17.lp_sec, 
                                                                           nas_0024_ind->t17.ltm_offset, 
                                                                           nas_0024_ind->t17.daylt_savings);
  }

  // CDMA P_Rev in Use
  if (nas_0024_ind->t18_valid)
  {
    printf("[NAS] cdma p_rev_in_use = %d\r\n", nas_0024_ind->t18.p_rev_in_use);
  }

  // 3GPP Network Daylight Saving Adjustment
  if (nas_0024_ind->t1B_valid)
  {
    is_update_nitz_time = TRUE;
    //printf("[NAS] 3GPP adj = %d", nas_0024_ind->t1B.adj);
  }

  // 3GPP Time Zone
  if (nas_0024_ind->t1A_valid)
  {
    //printf("[NAS] 3GPP time_zone = %d", nas_0024_ind->t1A.time_zone);
  }

  // 3GPP Universal Time and Local Time Zone
  if (nas_0024_ind->t1C_valid)
  {
    // CDMA�� �Ʒ�ó�� ó���Ǵ��� Ȯ�� �ʿ�
    is_update_nitz_time = TRUE;
    // jgkim 20130410 : ���⿡�� �������� �ð��� ��Ȯ���� �ʾ� ������� ����
    //printf("[NAS] date = %02d%02d%02d", nas_0024_ind->t1C.year-2000, nas_0024_ind->t1C.month, nas_0024_ind->t1C.day);
    //printf("[NAS] time = %02d%02d%02d", nas_0024_ind->t1C.hour, nas_0024_ind->t1C.minute, nas_0024_ind->t1C.second);
    //printf("[NAS] time_zone = %d", nas_0024_ind->t1C.time_zone);
  }

  // 3GPP LAC
  if (nas_0024_ind->t1D_valid)
  {
    registration_status.lac = (int) nas_0024_ind->t1D.lac;
    is_update_state = TRUE;

    //printf("[NAS] 3GPP lac = %x", registration_status.lac);
  }

  // 3GPP CELL ID
  if (nas_0024_ind->t1E_valid)
  {
    if((nas_0024_ind->t01.registration_state != WMM_ATTACH_STATE_ATTACHED) ||
       (nas_0024_ind->t1E.cell_id != -1))
    {
      registration_status.cell_id = (int) nas_0024_ind->t1E.cell_id;
      is_update_state = TRUE;

      //printf("[NAS] 3GPP cell_id = %x", registration_status.cell_id);
    } 
  }

  // 3GPP2 Concurrent Service Info
  if (nas_0024_ind->t1F_valid)
  {
    printf("[NAS] 3GPP2 ccs = %d\r\n", nas_0024_ind->t1F.ccs);
  }

  // 3GPP2 PRL Indicator
  if (nas_0024_ind->t20_valid)
  {
    printf("[NAS] 3GPP2 prl_ind = %d\r\n", nas_0024_ind->t20.prl_ind);
  }

  // Dual Transfer Mode Indication (GSM Only)
  if (nas_0024_ind->t21_valid)
  {
    printf("[NAS] gsm dtm_ind = %d\r\n", nas_0024_ind->t21.dtm_ind);
  }

  // Detailed Service Information
  if (nas_0024_ind->t22_valid)
  {
    registration_status.srv_status = nas_0024_ind->t22.srv_status;
    is_update_state = TRUE;
    nas_cached_info.hdr_hybrid = nas_0024_ind->t22.hdr_hybrid;

    //printf("   srv_status = %d (%s)", registration_status.srv_status, service_status_str(registration_status.srv_status), 0);
    //printf("   srv_capability = %d", nas_0024_ind->t22.srv_capability, 0, 0);
    //printf("   hdr_srv_status = %d", nas_0024_ind->t22.hdr_srv_status, 0, 0);
    //printf("   hdr_hybrid = %d", nas_0024_ind->t22.hdr_hybrid, 0, 0);
    printf("   is_sys_forbidden = %d\r\n", nas_0024_ind->t22.is_sys_forbidden);
  }

  // CDMA System Info
  if (nas_0024_ind->t23_valid)
  {
    printf("[NAS] cdma mcc = %d imsi_11_12 = %d\r\n", nas_0024_ind->t23.mcc, nas_0024_ind->t23.imsi_11_12);
  }

  // HDR Personality
  if (nas_0024_ind->t24_valid)
  {
    printf("[NAS] hdr_personality = %d\r\n", nas_0024_ind->t24.hdr_personality);
  }

  // TAC Information for LTE
  if (nas_0024_ind->t25_valid)
  {
    //printf("[NAS] lte tac = %d", nas_0024_ind->t25.tac);
  }
/*
  // Call Barring Status
  if (nas_0024_ind->t26_valid)
  {
    printf("   cs_bar_status = %d", nas_0024_ind->t26.cs_bar_status);
    printf("   ps_bar_status = %d", nas_0024_ind->t26.ps_bar_status);
  }

  // PLMN Change Status
  if (nas_0024_ind->t27_valid)
  {
    printf("   srv_sys_no_change = %d", nas_0024_ind->t27.srv_sys_no_change);
  }
*/
  // UMTS Primary Scrambling Code
  if (nas_0024_ind->t28_valid)
  {
   //printf("[NAS] umts_psc = %d", nas_0024_ind->t28.umts_psc);
  }

  // MNC PCS Digit Include Status
  if (nas_0024_ind->t29_valid)
  {
    //printf("[NAS] mcc = %d mnc = %d mnc_includes_pcs_digit = %d", nas_0024_ind->t29.mcc, 
    //                                                                nas_0024_ind->t29.mnc, 
    //                                                                nas_0024_ind->t29.mnc_includes_pcs_digit);
  }

  // HS Call Status
  if (nas_0024_ind->t2A_valid)
  {
    registration_status.hs_call_status = nas_0024_ind->t2A.hs_call_status;
    //printf("[NAS] hs_call_status = %d", registration_status.hs_call_status);
  }

  // 2015-01-29 reg_state�� denied�� �ø� ��� SET���� �ܸ��� ��ȣ�� �ʱ�ȭ ��
  // ������ Reject ���� �ʰ� �� ���ο��� Denied�� �ø��� ��� Searching ���·� ���� ��
  if((nas_0024_ind->t22.is_sys_forbidden == 1) && (nas_0024_ind->t01.registration_state == NET_REG_DENIED))
  {
    nas_0024_ind->t01.registration_state = NET_REG_SEARCHING;
    printf("[NAS] chnage the reg_state from NET_REG_DENIED to NET_REG_SEARCHING\r\n");
  }

  // get reject cause
  // move to wmm_state_check_timer()
  #if 0
  if(nas_0024_ind->t01.registration_state == NET_REG_DENIED)
  {
    if(registration_status.reject_cause == 0)
    {
      ril_request_get_sys_info();
    }
    printf("[NAS] reject_cause = %d", registration_status.reject_cause, reject_cause_string(registration_status.reject_cause));
  }
  else
  {
    registration_status.reject_cause = 0;
  }
	#endif

	if(nas_0024_ind->t01.registration_state != NET_REG_DENIED)
  {
    registration_status.reject_cause = 0;
  }

  if(registration_status.srv_status == SYS_SRV_STATUS_NO_SRV)
  {
    memset(&avg_rsrp, 0, sizeof(qmi_nas_avg_rf_data_type));
    memset(&registration_status, 0x0, sizeof(wmm_registartion_status_type));
  }
  else
  {
    // registration-status
    tmp_value =  get_registration_status(registration_status.srv_status, nas_0024_ind->t01.registration_state);
    if(registration_status.reg_status != tmp_value)
    {
      registration_status.reg_status = tmp_value;
      is_update_state = TRUE;
    }

    // gprs_registration-status
    tmp_value = (int) nas_0024_ind->t01.ps_attach_state;
    if(registration_status.gprs_status != tmp_value)
    {
      registration_status.gprs_status = tmp_value;
      is_update_state = TRUE;
    }

    // rat
    tmp_value = get_radio_access_technology(nas_0024_ind->t01.radio_if[0], registration_status.hs_call_status);
    if(registration_status.rat != tmp_value)
    {
      registration_status.rat = tmp_value;
      is_update_state = TRUE;
    }
  }

  // unsol network change
  if(is_update_state)
  {
    printf("[NAS] srv_status = %d registration_state = %s gprs_state = %s\r\n", registration_status.srv_status, 
                                                                              registration_status_str(registration_status.reg_status), 
                                                                              attach_status_str(registration_status.gprs_status));
    sprintf(tmp_buf, "[NAS] srv_status = %d registration_state = %s gprs_state = %s\r\n", registration_status.srv_status, 
                                                                              registration_status_str(registration_status.reg_status), 
                                                                              attach_status_str(registration_status.gprs_status));

    qmi_notify_event(TOF_EVENT_NETWORK_STATE_CHANGED, (uint32)NULL,  (uint32)tmp_buf); //just test code, Get modem_version success..
  }
}

static int
qmi_nas_system_selection_preference_ind
(
  unsigned char                                  *rx_buf,
  int                                            rx_buf_len,
  nas_system_selection_preference_ind_msg_v01    *qmi_msg
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;
  uint8  temp_8bit;
  uint16 temp_16bit;
  uint32 temp_32bit;
  uint64 temp_64bit;

  MSG_HIGH("qmi_nas_system_selection_preference_ind()", 0, 0, 0);

  memset(qmi_msg, 0, sizeof(nas_system_selection_preference_ind_msg_v01));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      /*  Emergency Mode */
      case NAS_0034_IND_T10:
      {
        qmi_msg->emergency_mode_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, qmi_msg->emergency_mode);
      }
      break;

      /*  Mode Preference */
      case NAS_0034_IND_T11:
      {
        qmi_msg->mode_pref_valid = TRUE;
        READ_16_BIT_VAL (value_ptr, temp_16bit);
        qmi_msg->mode_pref = (mode_pref_mask_type_v01)temp_16bit;
      }
      break;

      /*  Band Preference */
      case NAS_0034_IND_T12:
      {
        qmi_msg->band_pref_valid = TRUE;
        READ_64_BIT_VAL (value_ptr, temp_64bit);
        qmi_msg->band_pref = (nas_band_pref_mask_type_v01)temp_64bit;
      }
      break;

      /*  CDMA PRL Preference */
      case NAS_0034_IND_T13:
      {
        qmi_msg->prl_pref_valid = TRUE;
        READ_16_BIT_VAL (value_ptr, temp_16bit);
        qmi_msg->prl_pref = (nas_prl_pref_enum_v01)temp_16bit;
      }
      break;      

      /*  Roaming Preference */
      case NAS_0034_IND_T14:
      {
        qmi_msg->roam_pref_valid = TRUE;
        READ_16_BIT_VAL (value_ptr, temp_16bit);
        qmi_msg->roam_pref = (nas_roam_pref_enum_v01)temp_16bit;
      }
      break;     

      /*  LTE Band Preference */
      case NAS_0034_IND_T15:
      {
        qmi_msg->lte_band_pref_valid = TRUE;
        READ_64_BIT_VAL (value_ptr, temp_64bit);
        qmi_msg->lte_band_pref = (lte_band_pref_mask_type_v01)temp_64bit;
      }
      break;      

      /*  Network Selection Preference */
      case NAS_0034_IND_T16:
      {
        qmi_msg->net_sel_pref_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_msg->net_sel_pref = (nas_net_sel_pref_enum_v01)temp_8bit;
      }
      break; 

      /*  Service Domain Preference */
      case NAS_004E_IND_T18:
      {
        qmi_msg->srv_domain_pref_valid = TRUE;
        READ_32_BIT_VAL (value_ptr, temp_32bit);
        qmi_msg->srv_domain_pref = (nas_srv_domain_pref_enum_type_v01)temp_32bit;
      }
      break; 

      /*  GSM/WCDMA Acquisition Order Preference */
      case NAS_0034_IND_T19:
      {
        qmi_msg->gw_acq_order_pref_valid = TRUE;
        READ_32_BIT_VAL (value_ptr, temp_32bit);
        qmi_msg->gw_acq_order_pref = (nas_gw_acq_order_pref_enum_type_v01)temp_32bit;
      }
      break;       

      /*  TDSCDMA Band Preference */
      case NAS_0034_IND_T1A:
      {
        qmi_msg->tdscdma_band_pref_valid = TRUE;
        READ_64_BIT_VAL (value_ptr, temp_64bit);
        qmi_msg->tdscdma_band_pref = (nas_tdscdma_band_pref_mask_type_v01)temp_64bit;
      }
      break;   

      /*  Manual Network Selection PLMN */
      case NAS_0034_IND_T1B:
      {
        qmi_msg->manual_net_sel_plmn_valid = TRUE;
        READ_16_BIT_VAL (value_ptr, qmi_msg->manual_net_sel_plmn.mcc);
        READ_16_BIT_VAL (value_ptr, qmi_msg->manual_net_sel_plmn.mnc);
        READ_8_BIT_VAL (value_ptr, qmi_msg->manual_net_sel_plmn.mnc_includes_pcs_digit);
      }
      break; 

      /*  Acquisition Order Preference */
      case NAS_0034_IND_T1C:
      {
        qmi_msg->acq_order_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, qmi_msg->acq_order_len);
        for( i = 0 ; i < qmi_msg->acq_order_len ; i++)
        {
          READ_8_BIT_VAL (value_ptr, temp_8bit);
          qmi_msg->acq_order[i] = (nas_radio_if_enum_v01)temp_8bit;
        }
      }
      break;      

      /*  srv_reg_restriction */
      case NAS_0034_IND_T1D:
      {
        qmi_msg->srv_reg_restriction_valid = TRUE;
        READ_32_BIT_VAL (value_ptr, qmi_msg->srv_reg_restriction);
      }
      break;   

      /*  CSG PLMN info */
      case NAS_0034_IND_T1E:
      {
        qmi_msg->csg_plmn_info_valid = TRUE;
        READ_16_BIT_VAL (value_ptr, qmi_msg->mcc);
        READ_16_BIT_VAL (value_ptr, qmi_msg->mnc);
        READ_8_BIT_VAL (value_ptr, qmi_msg->mnc_includes_pcs_digit);
        READ_32_BIT_VAL (value_ptr, qmi_msg->csg_id);
        READ_8_BIT_VAL (value_ptr, qmi_msg->csg_radio_if);
      }
      break;  

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_system_selection_preference_ind: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================

FUNCTION  nas_network_time_info_ind_process

===========================================================================*/
void nas_network_time_info_ind_process(nas_004C_ind_s *nas_004C_ind)
{
  wmm_nitz_time_info_type nitz_time_info;
  memset(&nitz_time_info, 0x0, sizeof(wmm_nitz_time_info_type));

  // Universal Time
  if (nas_004C_ind->t01_valid)
  {
    nitz_time_info.year = nas_004C_ind->t01.year%100;   // year 2 digit
    nitz_time_info.month = nas_004C_ind->t01.month;
    nitz_time_info.day = nas_004C_ind->t01.day;
    nitz_time_info.hour = nas_004C_ind->t01.hour;
    nitz_time_info.minute = nas_004C_ind->t01.minute;
    nitz_time_info.second = nas_004C_ind->t01.second;
    nitz_time_info.day_of_week = nas_004C_ind->t01.day_of_week;
  }

  // Time Zone
  if (nas_004C_ind->t10_valid)
  {
    nitz_time_info.time_zone = nas_004C_ind->t10.time_zone;
  }

  // Daylight Saving Adjustment
  if (nas_004C_ind->t11_valid)
  {
    nitz_time_info.daylt_sav_adj = nas_004C_ind->t11.daylt_sav_adj;
  }

  // Radio Interface
  if (nas_004C_ind->t12_valid)
  {
  }
}

/*===========================================================================

FUNCTION  nas_sys_info_updated

===========================================================================*/
boolean nas_sys_info_updated(nas_sys_info_ind_msg_v01 *qmi_msg)
{
  boolean sys_info_updated = FALSE;

  if(NAS_CACHE_IS_ENTRY_VALID(nas_cached_info.lte_srv_status_info) == FALSE)
  {
    LOGD("[nas_sys_info_updated] lte srv status Invalid");
  }    
  else if( nas_cached_info.lte_srv_status_info->srv_status != qmi_msg->lte_srv_status_info.srv_status )
  {
    sys_info_updated = TRUE;
    LOGD("[nas_sys_info_updated] lte sys info update");
  }
    
  if(NAS_CACHE_IS_ENTRY_VALID(nas_cached_info.hdr_srv_status_info) == FALSE)
  {
    LOGD("[nas_sys_info_updated] hdr srv status Invalid");
  }
  else if( nas_cached_info.hdr_srv_status_info->srv_status != qmi_msg->hdr_srv_status_info.srv_status )
  {
    sys_info_updated = TRUE;
    LOGD("[nas_sys_info_updated] hdr sys info update");
  }
    
  if(NAS_CACHE_IS_ENTRY_VALID(nas_cached_info.cdma_srv_status_info) == FALSE)
  {
    LOGD("[nas_sys_info_updated] cdma srv status Invalid");
  }    
  else if( nas_cached_info.cdma_srv_status_info->srv_status != qmi_msg->cdma_srv_status_info.srv_status )
  {
    sys_info_updated = TRUE;
    LOGD("[nas_sys_info_updated] cdma sys info update");
  }

  return sys_info_updated;
}

/*===========================================================================

FUNCTION  nas_sys_info_ind_process

===========================================================================*/
#if 0
void nas_sys_info_ind_process(nas_004E_ind_s *nas_004E_ind)
{
  MSG_HIGH("(NAS) QMI_NAS_SYS_INFO_IND_MSG   (0x004E)", 0, 0, 0);

  // CDMA Service Status Info
  if (nas_004E_ind->t10_valid)
  {
    MSG_HIGH("   cdma srv_status = %d", nas_004E_ind->t10.srv_status, 0, 0);
    MSG_HIGH("   cdma is_pref_data_path = %d", nas_004E_ind->t10.is_pref_data_path, 0, 0);
  }
  // HDR Service Status Info
  if (nas_004E_ind->t11_valid)
  {
    MSG_HIGH("   hdr srv_status = %d", nas_004E_ind->t11.srv_status, 0, 0);
    MSG_HIGH("   hdr is_pref_data_path = %d", nas_004E_ind->t11.is_pref_data_path, 0, 0);
  }
  // GSM Service Status Info
  if (nas_004E_ind->t12_valid)
  {
    MSG_HIGH("   gsm srv_status = %d", nas_004E_ind->t12.srv_status, 0, 0);
    MSG_HIGH("   gsm true_srv_status = %d", nas_004E_ind->t12.true_srv_status, 0, 0);
    MSG_HIGH("   gsm is_pref_data_path = %d", nas_004E_ind->t12.is_pref_data_path, 0, 0);
  }
  // WCDMA Service Status Info
  if (nas_004E_ind->t13_valid)
  {
    MSG_HIGH("   wcdma srv_status = %d", nas_004E_ind->t13.srv_status, 0, 0);
    MSG_HIGH("   wcdma true_srv_status = %d", nas_004E_ind->t13.true_srv_status, 0, 0);
    MSG_HIGH("   wcdma is_pref_data_path = %d", nas_004E_ind->t13.is_pref_data_path, 0, 0);
  }
  // LTE Service Status Info
  if (nas_004E_ind->t14_valid)
  {
    MSG_HIGH("   lte srv_status = %d", nas_004E_ind->t14.srv_status, 0, 0);
    MSG_HIGH("   lte true_srv_status = %d", nas_004E_ind->t14.true_srv_status, 0, 0);
    MSG_HIGH("   lte is_pref_data_path = %d", nas_004E_ind->t14.is_pref_data_path, 0, 0);
  }
  // CDMA System Info
  if (nas_004E_ind->t15_valid)
  {
    MSG_HIGH("   cdma srv_domain_valid = %d", nas_004E_ind->t15.srv_domain_valid, 0, 0);
    MSG_HIGH("   cdma srv_domain = %d", nas_004E_ind->t15.srv_domain, 0, 0);
    // ���� ����
  }
  // HDR System Info
  if (nas_004E_ind->t16_valid)
  {
    MSG_HIGH("   hdr srv_domain_valid = %d", nas_004E_ind->t16.srv_domain_valid, 0, 0);
    MSG_HIGH("   hdr srv_domain = %d", nas_004E_ind->t16.srv_domain, 0, 0);
    // ���� ����
  }
  // GSM System Info
  if (nas_004E_ind->t17_valid)
  {
    MSG_HIGH("   gsm srv_domain_valid = %d", nas_004E_ind->t17.srv_domain_valid, 0, 0);
    MSG_HIGH("   gsm srv_domain = %d", nas_004E_ind->t17.srv_domain, 0, 0);
    // ���� ����
  }
  // WCDMA System Info
  if (nas_004E_ind->t18_valid)
  {
    MSG_HIGH("   wcdma srv_domain_valid = %d", nas_004E_ind->t18.srv_domain_valid, 0, 0);
    MSG_HIGH("   wcdma srv_domain = %d", nas_004E_ind->t18.srv_domain, 0, 0);
    MSG_HIGH("   wcdma srv_capability_valid = %d", nas_004E_ind->t18.srv_capability_valid, 0, 0);
    MSG_HIGH("   wcdma srv_capability = %d", nas_004E_ind->t18.srv_capability, 0, 0);
    MSG_HIGH("   wcdma lac = %x", nas_004E_ind->t18.lac, 0, 0);
    MSG_HIGH("   wcdma cell_id = %x", nas_004E_ind->t18.cell_id, 0, 0);
    if(nas_004E_ind->t18.reg_reject_info_valid)
    {
      MSG_HIGH("   wcdma reject_srv_domain = %d",		  nas_004E_ind->t18.reject_srv_domain, 0, 0);
      MSG_HIGH("   wcdma rej_cause = %d",				      nas_004E_ind->t18.rej_cause, 0, 0);
    }
    MSG_HIGH("   wcdma hs_call_status_valid = %d", nas_004E_ind->t18.hs_call_status_valid, 0, 0);
    MSG_HIGH("   wcdma hs_call_status = %d", nas_004E_ind->t18.hs_call_status, 0, 0);
    MSG_HIGH("   wcdma hs_ind_valid = %d", nas_004E_ind->t18.hs_ind_valid, 0, 0);
    MSG_HIGH("   wcdma hs_ind = %d", nas_004E_ind->t18.hs_ind, 0, 0);
    MSG_HIGH("   wcdma psc_valid = %d", nas_004E_ind->t18.psc_valid, 0, 0);
    MSG_HIGH("   wcdma psc = %d", nas_004E_ind->t18.psc, 0, 0);
  }
  // LTE System Info
  if (nas_004E_ind->t19_valid)
  {
    MSG_HIGH("   lte srv_domain_valid = %d", nas_004E_ind->t19.srv_domain_valid, 0, 0);
    MSG_HIGH("   lte srv_domain = %d", nas_004E_ind->t19.srv_domain, 0, 0);
    MSG_HIGH("   lte srv_capability_valid = %d", nas_004E_ind->t19.srv_capability_valid, 0, 0);
    MSG_HIGH("   lte srv_capability = %d", nas_004E_ind->t19.srv_capability, 0, 0);
    MSG_HIGH("   lte lac = %x", nas_004E_ind->t19.lac, 0, 0);
    MSG_HIGH("   lte cell_id = %x", nas_004E_ind->t19.cell_id, 0, 0);
    MSG_HIGH("   lte reg_reject_info_valid = %d", nas_004E_ind->t19.reg_reject_info_valid, 0, 0);
    MSG_HIGH("   lte reject_srv_domain = %d", nas_004E_ind->t19.reject_srv_domain, 0, 0);
    MSG_HIGH("   lte rej_cause = %d", nas_004E_ind->t19.rej_cause, 0, 0);
  }
}
#else
void nas_sys_info_ind_process(nas_sys_info_ind_msg_v01 *qmi_msg)
{
  boolean network_state_updated = FALSE;

  LOGD("(IND) QMI_NAS_SYS_INFO_IND_MSG   (0x004E)");

  if( TRUE == nas_sys_info_updated(qmi_msg) )
  {
    network_state_updated = TRUE;
  }
  LOGD("[nas_sys_info_ind_process] network_state_updated %d", network_state_updated);

  LOGD("[nas_sys_info_ind_process] CDMA srv valid %d, LTE srv valid %d", qmi_msg->cdma_srv_status_info_valid, qmi_msg->lte_srv_status_info_valid);

  //NAS_CACHE_LOCK();

  NAS_CACHE_STORE_ENTRY( nas_cached_info.cdma_srv_status_info, qmi_msg->cdma_srv_status_info, nas_3gpp2_srv_status_info_type_v01 );
  NAS_CACHE_STORE_ENTRY( nas_cached_info.hdr_srv_status_info, qmi_msg->hdr_srv_status_info, nas_3gpp2_srv_status_info_type_v01 );
  NAS_CACHE_STORE_ENTRY( nas_cached_info.lte_srv_status_info, qmi_msg->lte_srv_status_info, nas_3gpp_srv_status_info_type_v01 );
  NAS_CACHE_STORE_ENTRY( nas_cached_info.cdma_sys_info, qmi_msg->cdma_sys_info, nas_cdma_sys_info_type_v01 );
  NAS_CACHE_STORE_ENTRY( nas_cached_info.hdr_sys_info, qmi_msg->hdr_sys_info, nas_hdr_sys_info_type_v01 );
  NAS_CACHE_STORE_ENTRY( nas_cached_info.lte_sys_info, qmi_msg->lte_sys_info, nas_lte_sys_info_type_v01 );

  // TODO: NAS_CACHE_STORE_ENTRY( nas_cached_info.cdma_sys_info2, qmi_msg->cdma_sys_info2 );
  // TODO: NAS_CACHE_STORE_ENTRY( nas_cached_info.hdr_sys_info2, qmi_msg->hdr_sys_info2 );
  // TODO: NAS_CACHE_STORE_ENTRY( nas_cached_info.lte_sys_info2, qmi_msg->lte_sys_info2 );

  NAS_CACHE_STORE_TINY_ENTRY( nas_cached_info.voice_support_on_lte, qmi_msg->voice_support_on_lte );

  // TODO: NAS_CACHE_STORE_TINY_ENTRY_VAL( nas_cached_info.lte_embms_coverage, qmi_msg->lte_embms_coverage );
  //MSG_HIGH( ".. embms coverage valid %d, value %d", (int)qmi_msg->lte_embms_coverage_valid, (int) qmi_msg->lte_embms_coverage, 0);

  nas_cached_info.radio_tech = qmi_nas_query_avail_radio_tech(FALSE);
  LOGD("[nas_sys_info_ind_process] radio_tech %d", nas_cached_info.radio_tech);

  //NAS_CACHE_UNLOCK();    

  if (network_state_updated )
  {
    LOGD("[nas_sys_info_ind_process] RIL_UNSOL_RESPONSE_NETWORK_STATE_CHANGED");
    network_state_updated = FALSE;
//    Send_UnsolicitedResponse( RIL_UNSOL_RESPONSE_NETWORK_STATE_CHANGED, NULL, 0 );
  }
  else
  {
    LOGD( "[nas_sys_info_ind_process] sys info indication contents didn't change" );
  }
}
#endif

/*===========================================================================

FUNCTION  nas_sig_info_ind_process

===========================================================================*/
void nas_sig_info_ind_process(nas_0051_ind_s *nas_0051_ind)
{
  if((wmm_get_vendor_type() == WMM_VENDOR_B_CHN ))  //Bosch Project
  {
    // GSM Signal Strength Info
    if (nas_0051_ind->t12_valid)
    {
      tof_signal_strength.GSM_SignalStrength.signalStrength	= dsatetsime_gsm_convert_rssi(nas_0051_ind->t12.gsm_sig_info * (-1), 0);
      tof_signal_strength.GSM_SignalStrength.signalStrengt_dBm	= nas_0051_ind->t12.gsm_sig_info;
      
      MSG_HIGH("[BOSCH] GSM RSSI Level= %d, RSSI dBm = %d", tof_signal_strength.GW_SignalStrength.signalStrength, 
                                                                                        tof_signal_strength.GSM_SignalStrength.signalStrengt_dBm ,0);
    }
      
    // WCDMA Signal Strength Info
    if (nas_0051_ind->t13_valid)
    {
      tof_signal_strength.GW_SignalStrength.signalStrength	= nas_0051_ind->t13.rssi ;
      tof_signal_strength.GW_SignalStrength.bitErrorRate		= (nas_0051_ind->t13.ecio/2)*(-1);   // default value

      MSG_HIGH("[BOSCH] WCDMA Signal Strength = %d BER = %d", tof_signal_strength.GW_SignalStrength.signalStrength, 
                                                                                                                     tof_signal_strength.GW_SignalStrength.bitErrorRate, 0);
    }

    // LTE Signal Strength Info
    if (nas_0051_ind->t14_valid)
    {
      tof_signal_strength.LTE_SignalStrength.signalStrength = nas_0051_ind->t14.rssi;
      tof_signal_strength.LTE_SignalStrength.rsrq = nas_0051_ind->t14.rsrq;
      tof_signal_strength.LTE_SignalStrength.rsrp = nas_0051_ind->t14.rsrp;
      tof_signal_strength.LTE_SignalStrength.rssnr = nas_0051_ind->t14.snr;
      tof_signal_strength.LTE_SignalStrength.cqi = 0;  // [need_update] cqi??

      MSG_HIGH_4("[BOSCH] LTE RSSI=%d, RSRQ=%d, RSRP=%d, RSSNR=%d", tof_signal_strength.LTE_SignalStrength.signalStrength,
                                                                                                                      tof_signal_strength.LTE_SignalStrength.rsrq, 
                                                                                                                      tof_signal_strength.LTE_SignalStrength.rsrp,
                                                                                                                      tof_signal_strength.LTE_SignalStrength.rssnr);

    }

    // TD-SCDMA Signal Strength Info
    if (nas_0051_ind->t15_valid)
    {
      tof_signal_strength.TD_SCDMA_SignalStrength.rscp	= nas_0051_ind->t15.rscp ;
      
      MSG_HIGH("[BOSCH] TD-SCDMA RSCP = %d ", tof_signal_strength.TD_SCDMA_SignalStrength.rscp, 0, 0);
    }
  }
  else
  {
  // WCDMA Signal Strength Info
  if (nas_0051_ind->t13_valid)
  {
    tof_signal_strength.GW_SignalStrength.signalStrength	= dsatetsime_convert_rssi(nas_0051_ind->t13.rssi * (-1),DSAT_CSQ_MAX_SIGNAL);
    tof_signal_strength.GW_SignalStrength.bitErrorRate		= nas_0051_ind->t13.ecio;   // default value

    MSG_HIGH("[NAS] WCDMA Signal Strength = %d BER = %d", tof_signal_strength.GW_SignalStrength.signalStrength, 
                                                                                                                   tof_signal_strength.GW_SignalStrength.bitErrorRate, 0);
  }

  // LTE Signal Strength Info
  if (nas_0051_ind->t14_valid)
  {
    tof_signal_strength.LTE_SignalStrength.signalStrength = dsatetsime_convert_rssi(nas_0051_ind->t14.rssi * (-1),DSAT_CSQ_MAX_SIGNAL);
    tof_signal_strength.LTE_SignalStrength.rsrq = nas_0051_ind->t14.rsrq * (-1);
    tof_signal_strength.LTE_SignalStrength.rsrp = nas_0051_ind->t14.rsrp * (-1);
    tof_signal_strength.LTE_SignalStrength.rssnr = nas_0051_ind->t14.snr;
    tof_signal_strength.LTE_SignalStrength.cqi = 0;  // [need_update] cqi??

    MSG_HIGH_4("[NAS] LTE RSSI=%d, RSRQ=%d, RSRP=%d, RSSNR=%d", tof_signal_strength.LTE_SignalStrength.signalStrength,
                                                                                                                    tof_signal_strength.LTE_SignalStrength.rsrq, 
                                                                                                                    tof_signal_strength.LTE_SignalStrength.rsrp,
                                                                                                                    tof_signal_strength.LTE_SignalStrength.rssnr);

  }
  }
  
  qmi_notify_event(TOF_EVENT_SIGNAL_STRENGTH_CHANGED, (uint32)NULL,  (uint32)&tof_signal_strength);
}

/*===========================================================================

FUNCTION  nas_signal_strength_notify
- 1second sampling
- 5second average

===========================================================================*/
void nas_signal_strength_notify(nas_701A_ind_s *nas_701A_ind)
{
  //MSG_HIGH("(IND) NASI_CMD_VAL_IND_SIGNAL_STRENGTH_MSG_ID   (0x701A)", 0, 0, 0);

  if(nas_701A_ind->t01_valid)
  {
    tof_signal_strength.CDMA_SignalStrength.dbm = nas_701A_ind->t01.signal_strength.CDMA_SignalStrength.dbm * (-1);
    tof_signal_strength.CDMA_SignalStrength.ecio = nas_701A_ind->t01.signal_strength.CDMA_SignalStrength.ecio * 5;

    tof_signal_strength.EVDO_SignalStrength.dbm = nas_701A_ind->t01.signal_strength.EVDO_SignalStrength.dbm * (-1);
    tof_signal_strength.EVDO_SignalStrength.ecio = nas_701A_ind->t01.signal_strength.EVDO_SignalStrength.ecio * 5;
    tof_signal_strength.EVDO_SignalStrength.signalNoiseRatio = nas_701A_ind->t01.signal_strength.EVDO_SignalStrength.signalNoiseRatio;

    tof_signal_strength.GW_SignalStrength.signalStrength	= dsatetsime_convert_rssi(nas_701A_ind->t01.signal_strength.GW_SignalStrength.signalStrength * (-1),DSAT_CSQ_MAX_SIGNAL);
    tof_signal_strength.GW_SignalStrength.bitErrorRate		= 99;   // default value

    tof_signal_strength.LTE_SignalStrength.signalStrength = dsatetsime_convert_rssi(nas_701A_ind->t01.signal_strength.LTE_SignalStrength.signalStrength * (-1),DSAT_CSQ_MAX_SIGNAL);
    tof_signal_strength.LTE_SignalStrength.rsrp = nas_701A_ind->t01.signal_strength.LTE_SignalStrength.rsrp * (-1);
    tof_signal_strength.LTE_SignalStrength.rsrq = nas_701A_ind->t01.signal_strength.LTE_SignalStrength.rsrq * (-1);
    tof_signal_strength.LTE_SignalStrength.rssnr = nas_701A_ind->t01.signal_strength.LTE_SignalStrength.rssnr;
    tof_signal_strength.LTE_SignalStrength.cqi = 0;  // [need_update] cqi??
  }
}

/*===========================================================================

FUNCTION  nas_sig_info_ind_process

===========================================================================*/
void nas_current_plmn_name_ind_process(nas_0061_ind_s *nas_0061_ind)
{
  if (nas_0061_ind->t10_valid)
  {
    operator_status.mcc = nas_0061_ind->t10.mcc;
    operator_status.mnc = nas_0061_ind->t10.mnc;
    //MSG_HIGH("[NAS] mcc = %d mnc = %d mnc_includes_pcs_digit = %d", nas_0061_ind->t10.mcc, nas_0061_ind->t10.mnc, nas_0061_ind->t10.mnc_includes_pcs_digit);
//BKS_20131202
    if((wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ) || ( wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ))
    {
      nas_current_plmn_name_ind_msg_v01 plmn_name;
      plmn_name.plmn_id_valid = TRUE;
      plmn_name.plmn_id.mcc = nas_0061_ind->t10.mcc;
      plmn_name.plmn_id.mnc = nas_0061_ind->t10.mnc;
      plmn_name.plmn_id.mnc_includes_pcs_digit = nas_0061_ind->t10.mnc_includes_pcs_digit;
      NAS_CACHE_STORE_ENTRY( nas_cached_info.plmn_id,  plmn_name.plmn_id, nas_plmn_id_ext_type_v01);
    }
  }

  if (nas_0061_ind->t11_valid)
  {
    //MSG_HIGH("   srv_prov_name_encoding = %d srv_prov_name_len = %d", nas_0061_ind->t11.srv_prov_name_encoding, nas_0061_ind->t11.srv_prov_name_len, 0);
    //MSG_HIGH("   srv_prov_name_name = %s", nas_0061_ind->t11.srv_prov_name_name, 0, 0);
  }

  if (nas_0061_ind->t12_valid)
  {
    strcpy(operator_status.plmn_name_short, (char*)nas_0061_ind->t12.plmn_name_short);
    operator_status.initialized_plmn_name = TRUE;

    //MSG_HIGH("   plmn_name_short_encoding = %d plmn_name_short_ci = %d plmn_name_short_spare_bits = %d", nas_0061_ind->t12.plmn_name_short_encoding, nas_0061_ind->t12.plmn_name_short_ci, nas_0061_ind->t12.plmn_name_short_spare_bits);
    //MSG_HIGH("   plmn_name_short_len = %d plmn_name_short = %s", nas_0061_ind->t12.plmn_name_short_len, nas_0061_ind->t12.plmn_name_short, 0);
  }  

  if (nas_0061_ind->t13_valid)
  {
    strcpy(operator_status.plmn_name_long, (char*)nas_0061_ind->t13.plmn_name_long);
    //MSG_HIGH("   plmn_name_long_encoding = %d plmn_name_long_ci = %d plmn_name_long_spare_bits = %d", nas_0061_ind->t13.plmn_name_long_encoding, nas_0061_ind->t13.plmn_name_long_ci, nas_0061_ind->t13.plmn_name_long_spare_bits);
    //MSG_HIGH("[NAS] plmn_name_long_len = %d plmn_name_long = %s", nas_0061_ind->t13.plmn_name_long_len, nas_0061_ind->t13.plmn_name_long, 0);
  }

  if (nas_0061_ind->t14_valid)
  {
   // MSG_HIGH("   csg_id = %d", nas_0061_ind->t14.csg_id, 0, 0);
  } 
}

/*===========================================================================

FUNCTION  nas_network_reject_ind_process

===========================================================================*/
void nas_network_reject_ind_process(nas_0068_ind_s *nas_0068_ind)
{
  MSG_HIGH("(NAS) QMI_NAS_NETWORK_REJECT_IND_MSG_ID   (0x0068)", 0, 0, 0);
  MSG_HIGH("   radio_if = %d", nas_0068_ind->t01.radio_if, 0, 0);
  MSG_HIGH("   reject_srv_domain = %d", nas_0068_ind->t02.reject_srv_domain, 0, 0);
  MSG_HIGH("   rej_cause = %d", nas_0068_ind->t03.rej_cause, 0, 0);
}

/*===========================================================================
  FUNCTION  qmi_nas_srvc_indication_cb
===========================================================================*/
/*!
@brief 
  This is the callback function that will be called by the generic
  services layer to report asynchronous indications.  This function will
  process the indication TLV's and then call the user registered
  functions with the indication data.   
  
@return 
  None.

@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/

static void
qmi_nas_srvc_indication_cb
(
  int                   user_handle,
  qmi_service_id_type   service_id,
  unsigned long         msg_id,
  void                                *user_ind_msg_hdlr,
  void                                *user_ind_msg_hdlr_user_data,
  unsigned char         *rx_msg_buf,
  int                   rx_msg_len
)
{
  qmi_nas_indication_id_type      ind_id = QMI_NAS_SRVC_INVALID_IND_MSG;
  qmi_nas_indication_data_type    ind_data;
  qmi_nas_indication_hdlr_type    user_ind_hdlr;

  unsigned char tmp;
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;

  /* Make sure that the user indication handler isn't NULL */
  if (user_ind_msg_hdlr == NULL)
  {
    return;
  }

  /* isyoon 20161013 Removed at the request of Clarion */
  //printf ("qmi_nas_srvc_indication_cb::msg_id 0x%lx \r\n ",msg_id);
  MSG_HIGH("qmi_nas_srvc_indication_cb::msg_id 0x%lx", msg_id, 0, 0);
  
  switch (msg_id)
  {    
    case QMI_NAS_EVENT_REPORT_IND_MSG_ID:
    {
      ind_id = QMI_NAS_SRVC_EVENT_REPORT_IND_MSG;     
      MSG_HIGH("qmi_nas_srvc_indication_cb::QMI_NAS_EVENT_REPORT_IND_MSG_ID", 0, 0, 0);
    }
    break;

    case QMI_NAS_SERVING_SYSTEM_IND_MSG_ID:
    {
      ind_id = QMI_NAS_SRVC_SERVING_SYSTEM_IND_MSG;
      MSG_HIGH("qmi_nas_srvc_indication_cb::QMI_NAS_SRVC_SERVING_SYSTEM_IND_MSG", 0, 0, 0);

      if (qmi_nas_serving_system_info_ind (rx_msg_buf,
                                           rx_msg_len,
                                           &ind_data.nas_0024_ind) < 0)
      {
        MSG_HIGH("qmi_nas_srvc_indication_cb: Failure in get serving system IND data", 0, 0, 0);
        return;
      }
      nas_serving_system_ind_process(&ind_data.nas_0024_ind);
    }
    break;

    case QMI_NAS_SIG_INFO_IND_MSG_ID:
    {      
      ind_id = QMI_NAS_SIG_INFO_IND_MSG;
      if (qmi_nas_sig_info_ind(rx_msg_buf,
                               rx_msg_len,
                               &ind_data.nas_0051_ind) < 0)
      {
        MSG_HIGH("qmi_nas_srvc_indication_cb: Failure in signal info indication data", 0, 0, 0);
        return;
      }
      nas_sig_info_ind_process(&ind_data.nas_0051_ind);
    }
    break;

    case QMI_NAS_SIGNAL_STRENGTH_IND_MSG_ID:
    {
        MSG_HIGH("qmi_nas_srvc_indication_cb::QMI_NAS_SIGNAL_STRENGTH_IND_MSG_ID", 0, 0, 0);
        ind_id = QMI_NAS_SIGNAL_STRENGTH_IND_MSG;
     }
     break;

		case QMI_NAS_SIM_STATE_CHANGE_IND_MSG_ID:
		{
		  char tmp_buf[256] = {0,};
			int tof_sim_state = -1;
				
			MSG_HIGH("qmi_nas_srvc_indication_cb::QMI_NAS_SIM_STATE_CHANGE_IND_MSG_ID", 0, 0, 0);
			ind_id = QMI_NAS_SIM_STATE_CHANGE_IND_MSG_ID;
      if (qmi_nas_sim_state_ind(rx_msg_buf,
                               rx_msg_len,
                               &ind_data.nas_7043_ind) < 0)
      {
        MSG_HIGH("qmi_nas_srvc_indication_cb: Failure in signal info indication data", 0, 0, 0);
        return;
      }

			tof_sim_state = qmi_nas_sim_state_value_sync(ind_data.nas_7043_ind.t01.sim_state);
			
      sprintf(tmp_buf,"%d",tof_sim_state);
      QMI_DEBUG_MSG_1("QMI_NAS_SIM_STATE_CHANGE_IND_MSG_ID : sim_state : %d", tof_sim_state);
      EventNotifyEnqueue(TOF_EVENT_RESPONSE_NAS_SIM_STATE_CHANGED, tof_sim_state, NULL);
		}
		break;

    default:
      MSG_HIGH("qmi_nas_srvc_indication_cb::Invalid indication msg_id received %lx", msg_id, 0, 0);
    break;
  }/*Switch*/

  /* If we got a valid/supported indication, report it */
  if (ind_id != QMI_NAS_SRVC_INVALID_IND_MSG)
  {
    /* Get properly cast pointer to user indication handler */
    /*lint -e{611} */
    user_ind_hdlr = (qmi_nas_indication_hdlr_type) user_ind_msg_hdlr;

    /* Call user registered handler */
    user_ind_hdlr (user_handle,
                   service_id,
                   user_ind_msg_hdlr_user_data,
                   ind_id,
                   &ind_data);
  }
}


/*===========================================================================
  FUNCTION  qmi_nas_get_signal_strength_info
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with singal strength info.  It
  is used both by the get singal strength info cmd response
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_signal_strength_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_0020_rsp_s                    *nas_0020_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_0020_rsp, 0, sizeof(nas_0020_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    switch (type)
    {
      // response result
      case NAS_0020_RSP_T01:
      {
        nas_0020_rsp->t01_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_0020_rsp->t01.sig_strength);
        READ_8_BIT_VAL(value_ptr,nas_0020_rsp->t01.radio_if);
      }
      break;

      // Signal Strength
      case NAS_0020_RSP_T10:
      {
        nas_0020_rsp->t10_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0020_rsp->t10.num_instances);
        for (i = 0; (i < nas_0020_rsp->t10.num_instances) && (i < NAS_0020_RSP_T10_SIG_STR_MAX); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_0020_rsp->t10.instances[i].sig_strength);
          READ_8_BIT_VAL(value_ptr,nas_0020_rsp->t10.instances[i].radio_if);          
        }  
      }
      break;

      // RF Band Information List
      case NAS_0020_RSP_T11:
      {
        nas_0020_rsp->t11_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0020_rsp->t11.num_instances);
        for (i = 0; (i < nas_0020_rsp->t11.num_instances) && (i < NAS_0020_RSP_T11_RSSI_MAX); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_0020_rsp->t11.instances[i].rssi);
          READ_8_BIT_VAL(value_ptr,nas_0020_rsp->t11.instances[i].radio_if);  
        }        
      }
      break;      

      // Registration Reject Reason
      case NAS_0020_RSP_T12:
      {
        nas_0020_rsp->t12_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0020_rsp->t12.num_instances);
        for (i = 0; (i < nas_0020_rsp->t12.num_instances) && (i < NAS_0020_RSP_T12_ECIO_MAX); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_0020_rsp->t12.instances[i].ecio);
          READ_8_BIT_VAL(value_ptr,nas_0020_rsp->t12.instances[i].radio_if);  
        }        
      }
      break;

      // RSSI
      case NAS_0020_RSP_T13:
      {
        nas_0020_rsp->t13_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,nas_0020_rsp->t13.io);
      }
      break;      

      // ECIO
      case NAS_0020_RSP_T14:
      {
        nas_0020_rsp->t14_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0020_rsp->t14.sinr);       
      }
      break;     

      // IO
      case NAS_0020_RSP_T15:
      {
        nas_0020_rsp->t15_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0020_rsp->t15.num_instances);
        for (i = 0; (i < nas_0020_rsp->t15.num_instances) && (i < NAS_0020_RSP_T15_ERROR_RATE_MAX); i++ )
        {
          READ_16_BIT_VAL(value_ptr,nas_0020_rsp->t15.instances[i].error_rate);
          READ_8_BIT_VAL(value_ptr,nas_0020_rsp->t15.instances[i].radio_if);          
        }  
      }
      break;      

      // SINR*
      case NAS_0020_RSP_T16:
      {
        nas_0020_rsp->t16_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0020_rsp->t16.rsrq);
        READ_8_BIT_VAL (value_ptr,nas_0020_rsp->t16.radio_if);
      }
      break; 

      // Error Rate
      case NAS_0020_RSP_T17:
      {
        nas_0020_rsp->t17_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0020_rsp->t17.lte_snr);
      }
      break; 

      // RSRQ**
      case NAS_0020_RSP_T18:
      {
        nas_0020_rsp->t18_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0020_rsp->t18.lte_rsrp);
      }
      break;          

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_signal_strength_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_serving_system_info
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with serving system info.  It
  is used both by the get serving system info cmd response as well as the
  serving system indication.   
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_serving_system_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_0024_rsp_s                    *nas_0024_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_0024_rsp, 0, sizeof(nas_0024_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      // Serving System
      case NAS_0024_RSP_T01:
      {
        nas_0024_rsp->t01_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_0024_rsp->t01.registration_state);
        READ_8_BIT_VAL(value_ptr,nas_0024_rsp->t01.cs_attach_state);
        READ_8_BIT_VAL(value_ptr,nas_0024_rsp->t01.ps_attach_state);
        READ_8_BIT_VAL(value_ptr,nas_0024_rsp->t01.registered_network);
        READ_8_BIT_VAL(value_ptr,nas_0024_rsp->t01.in_use_radio_if_list_num);

        for (i = 0; (i < nas_0024_rsp->t01.in_use_radio_if_list_num) && (i < NAS_0024_RSP_T01_RADIO_IF_MAX); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_0024_rsp->t01.radio_if[i]);
        }
      }
      break;

      // Roaming Indicator Value
      case NAS_0024_RSP_T10:
      {
        nas_0024_rsp->t10_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t10.roaming_indicator);
      }
      break;

      // Data Service Capability
      case NAS_0024_RSP_T11:
      {
        nas_0024_rsp->t11_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t11.data_capability_list_len);
        for (i = 0; (i < nas_0024_rsp->t11.data_capability_list_len) && (i < NAS_0024_RSP_T11_DATA_CAP_LIST_LEN_MAX); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_0024_rsp->t11.data_capabilities[i]);
        }        
      }
      break;      

      // Current PLMN
      case NAS_0024_RSP_T12:
      {
        nas_0024_rsp->t12_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0024_rsp->t12.mobile_country_code);
        READ_16_BIT_VAL (value_ptr,nas_0024_rsp->t12.mobile_network_code);
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t12.network_description_length);

        if (nas_0024_rsp->t12.network_description_length > 0)
        {
          int cpy_len = (nas_0024_rsp->t12.network_description_length < NAS_0024_RSP_T12_NET_DESC_LEN_MAX) 
          ? nas_0024_rsp->t12.network_description_length : (NAS_0024_RSP_T12_NET_DESC_LEN_MAX - 1);
          memcpy (nas_0024_rsp->t12.network_description, (void *)value_ptr, cpy_len);
          nas_0024_rsp->t12.network_description[cpy_len] = '\0';
        }
        else
        {
          nas_0024_rsp->t12.network_description[0] = '\0';
        }
      }
      break;

      // CDMA System ID
      case NAS_0024_RSP_T13:
      {
        nas_0024_rsp->t13_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0024_rsp->t13.sid);
        READ_16_BIT_VAL (value_ptr,nas_0024_rsp->t13.nid);
      }
      break;      

      // CDMA Base Station Information
      case NAS_0024_RSP_T14:
      {
        nas_0024_rsp->t14_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0024_rsp->t14.base_id);
        READ_32_BIT_VAL (value_ptr,nas_0024_rsp->t14.base_lat);
        READ_32_BIT_VAL (value_ptr,nas_0024_rsp->t14.base_long);        
      }
      break;     

      // Roaming Indicator List
      case NAS_0024_RSP_T15:
      {
        nas_0024_rsp->t15_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t15.num_instances);
        for (i = 0; (i < nas_0024_rsp->t15.num_instances) && (i < NAS_0024_RSP_T15_ROAM_RSP_MAX); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_0024_rsp->t15.roam_ind[i].radio_if);
          READ_8_BIT_VAL(value_ptr,nas_0024_rsp->t15.roam_ind[i].roaming_indicator);          
        }  
      }
      break;      

      // Default Roaming Indicator
      case NAS_0024_RSP_T16:
      {
        nas_0024_rsp->t16_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0024_rsp->t16.def_roam_ind);
      }
      break; 

      // 3GGP2 Time Zone
      case NAS_0024_RSP_T17:
      {
        nas_0024_rsp->t17_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t17.lp_sec);
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t17.ltm_offset);
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t17.daylt_savings);        
      }
      break; 

      // CDMA P_Rev in Use
      case NAS_0024_RSP_T18:
      {
        nas_0024_rsp->t18_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t18.p_rev_in_use);
      }
      break;       

      // 3GPP Time Zone
      case NAS_0024_RSP_T1A:
      {
        nas_0024_rsp->t1A_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t1A.time_zone);
      }
      break; 

      // 3GPP Network Daylight Saving Adjustment
      case NAS_0024_RSP_T1B:
      {
        nas_0024_rsp->t1B_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t1B.adj);
      }
      break;      

      // 3GPP Location Area Code
      case NAS_0024_RSP_T1C:
      {
        nas_0024_rsp->t1C_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0024_rsp->t1C.lac);
      }
      break;   

      // 3GPP Cell ID
      case NAS_0024_RSP_T1D:
      {
        nas_0024_rsp->t1D_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,nas_0024_rsp->t1D.cell_id);
      }
      break;  

      // 3GPP2 Concurrent Service Info
      case NAS_0024_RSP_T1E:
      {
        nas_0024_rsp->t1E_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t1E.ccs);
      }
      break;   

      // 3GPP2 PRL Indicator
      case NAS_0024_RSP_T1F:
      {
        nas_0024_rsp->t1F_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t1F.prl_ind);
      }
      break;   

      // Dual Transfer Mode Indication (GSM Only)
      case NAS_0024_RSP_T20:
      {
        nas_0024_rsp->t20_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t20.dtm_ind);
      }
      break;   

      // Detailed Service Information
      case NAS_0024_RSP_T21:
      {
        nas_0024_rsp->t21_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t21.srv_status);
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t21.srv_capability);
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t21.hdr_srv_status);
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t21.hdr_hybrid);
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t21.is_sys_forbidden);        
      }
      break;     

      // CDMA System Info
      case NAS_0024_RSP_T22:
      {
        nas_0024_rsp->t22_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0024_rsp->t22.mcc);
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t22.imsi_11_12);
      }
      break;       

      // HDR Personality
      case NAS_0024_RSP_T23:
      {
        nas_0024_rsp->t23_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t23.hdr_personality);
      }
      break;

      // TAC Information for LTE
      case NAS_0024_RSP_T24:
      {
        nas_0024_rsp->t24_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0024_rsp->t24.tac);
      }
      break; 

      // Call Barring Status
      case NAS_0024_RSP_T25:
      {
        nas_0024_rsp->t25_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,nas_0024_rsp->t25.cs_bar_status);
        READ_32_BIT_VAL (value_ptr,nas_0024_rsp->t25.ps_bar_status);        
      }
      break;        

      // UMTS Primary Scrambling Code
      case NAS_0024_RSP_T26:
      {
        nas_0024_rsp->t26_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0024_rsp->t26.umts_psc);
      }
      break; 

      // MNC PCS Digit Include Status
      case NAS_0024_RSP_T27:
      {
        nas_0024_rsp->t27_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0024_rsp->t27.mcc);
        READ_16_BIT_VAL (value_ptr,nas_0024_rsp->t27.mnc); 
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t27.mnc_includes_pcs_digit);         
      }
      break; 

      // HS Call Status
      case NAS_0024_RSP_T28:
      {
        nas_0024_rsp->t28_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0024_rsp->t28.hs_call_status);
      }
      break;      

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_serving_system_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_operator_info
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with operator info.  It
  is used both by the get operator info cmd response
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_operator_info
(
  unsigned char                    *rx_buf,
  int                               rx_buf_len,
  nas_0025_rsp_s                   *nas_0025_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_0025_rsp, 0, sizeof(nas_0025_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      // Home Network
      case NAS_0025_RSP_T01:
      {
        nas_0025_rsp->t01_valid= TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0025_rsp->t01.mobile_country_code);
        READ_16_BIT_VAL (value_ptr,nas_0025_rsp->t01.mobile_network_code);
        READ_8_BIT_VAL (value_ptr,nas_0025_rsp->t01.network_description_length);

        for (i = 0; (i < nas_0025_rsp->t01.network_description_length) && (i < NAS_0025_RSP_T01_MAX_NETWORK_NAME_LEN); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_0025_rsp->t01.network_description[i]);
        }        
      }
      break;

      // Home System ID
      case NAS_0025_RSP_T10:
      {
        nas_0025_rsp->t10_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0025_rsp->t10.sid);
        READ_16_BIT_VAL (value_ptr,nas_0025_rsp->t10.nid);		  
      }
      break;


      case NAS_0025_RSP_T11:
      {
        nas_0025_rsp->t11_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0025_rsp->t11.mobile_country_code);
        READ_16_BIT_VAL (value_ptr,nas_0025_rsp->t11.mobile_network_code);
        READ_8_BIT_VAL (value_ptr,nas_0025_rsp->t11.network_description_display);
        READ_8_BIT_VAL (value_ptr,nas_0025_rsp->t11.network_description_encoding);	   
        READ_8_BIT_VAL (value_ptr,nas_0025_rsp->t11.network_description_length);

        for (i = 0; (i < nas_0025_rsp->t11.network_description_length) && (i < NAS_0025_RSP_T11_CDMA_SPN_MAX_NETWORK_NAME_LEN); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_0025_rsp->t11.network_description[i]);
        }  
      }
      break;      

      // 3GPP2 Home Network Ext
      case NAS_0025_RSP_T12:
      {
        nas_0025_rsp->t12_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0025_rsp->t12.is_3gpp_network);
        READ_8_BIT_VAL (value_ptr,nas_0025_rsp->t12.mnc_includes_pcs_digit);		  
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_operator_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_pref_network_info
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with preferred network info.  It
  is used both by the get preferred network info cmd response
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_pref_network_info
(
  unsigned char                    *rx_buf,
  int                               rx_buf_len,
  nas_0034_rsp_s                   *nas_0034_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_0034_rsp, 0, sizeof(nas_0034_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      // Emergency Mode
      case NAS_0034_RSP_T10:
      {
        nas_0034_rsp->t10_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0034_rsp->t10.emergency_mode);
      }
      break;

      // Mode Preference
      case NAS_0034_RSP_T11:
      {
        nas_0034_rsp->t11_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0034_rsp->t11.mode_pref);
      }
      break;      

      //Band Preference
      case NAS_0034_RSP_T12:
      {
        nas_0034_rsp->t12_valid = TRUE;
        READ_64_BIT_VAL (value_ptr,nas_0034_rsp->t12.band_pref);
      }
      break;

      // CDMA PRL Preference
      case NAS_0034_RSP_T13:
      {
        nas_0034_rsp->t13_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0034_rsp->t13.prl_pref);
      }
      break;      

      // Roaming Preference
      case NAS_0034_RSP_T14:
      {
        nas_0034_rsp->t14_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0034_rsp->t14.roam_pref);       
      }
      break;     

      // LTE Band Preference
      case NAS_0034_RSP_T15:
      {
        nas_0034_rsp->t15_valid = TRUE;
        READ_64_BIT_VAL (value_ptr,nas_0034_rsp->t15.lte_band_pref);
      }
      break;      

      // Network Selection Preference
      case NAS_0034_RSP_T16:
      {
        nas_0034_rsp->t16_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0034_rsp->t16.net_sel_mode_pref);
      }
      break; 

      // Service Domain Preference
      case NAS_0034_RSP_T18:
      {
        nas_0034_rsp->t18_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,nas_0034_rsp->t18.srv_domain_pref);
      }
      break;          

      // GSM/WCDMA Acquisition Order Preference
      case NAS_0034_RSP_T19:
      {
        nas_0034_rsp->t19_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,nas_0034_rsp->t19.gw_acq_order_pref);
      }
      break;  

      // TDSCDMA Band Preference
      case NAS_0034_RSP_T1A:
      {
        nas_0034_rsp->t1A_valid = TRUE;
        READ_64_BIT_VAL (value_ptr,nas_0034_rsp->t1A.tds_band_pref);
      }
      break;  

      // Manual Network Selection PLMN
      case NAS_0034_RSP_T1B:
      {
        nas_0034_rsp->t1B_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0034_rsp->t1B.mcc);
        READ_16_BIT_VAL (value_ptr,nas_0034_rsp->t1B.mnc);
        READ_8_BIT_VAL (value_ptr,nas_0034_rsp->t1B.mnc_includes_pcs_digit);
      }
      break;  

      // Acquisition Order Preference
      case NAS_0034_RSP_T1C:
      {
        nas_0034_rsp->t1C_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_0034_rsp->t1C.acq_order_len);
        for (i = 0; (i < nas_0034_rsp->t1C.acq_order_len) && (i < NAS_0034_ACQ_ORDER_LIST_MAX); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_0034_rsp->t1C.acq_order[i]);
        }  
      }
      break;  

      // Network Selection Registration Restriction Preference
      case NAS_0034_RSP_T1D:
      {
        nas_0034_rsp->t1D_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,nas_0034_rsp->t1D.srv_reg_restriction);
      }
      break;  

      // CSG ID
      case NAS_0034_RSP_T1E:
      {
        nas_0034_rsp->t1E_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_0034_rsp->t1E.mcc);
        READ_16_BIT_VAL (value_ptr,nas_0034_rsp->t1E.mnc);
        READ_8_BIT_VAL (value_ptr,nas_0034_rsp->t1E.mnc_includes_pcs_digit);	   
        READ_32_BIT_VAL (value_ptr,nas_0034_rsp->t1E.csg_id);
        READ_8_BIT_VAL (value_ptr,nas_0034_rsp->t1E.csg_radio_if);	   	   
      }
      break;  

      default:
        //QMI_DEBUG_MSG_1 ("qmi_nas_get_pref_network_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_pref_network_type_info
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with preferred network info.  It
  is used both by the get preferred network info cmd response
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_pref_network_type_info
(
  unsigned char                    *rx_buf,
  int                               rx_buf_len,
  nas_555A_rsp_s            *nas_555A_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_555A_rsp, 0, sizeof(nas_555A_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      // Mode Preference
      case NAS_555A_RSP_T10:
      {
        nas_555A_rsp->t10_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_555A_rsp->t10.pref_mode);
      }
      break;      

      // GSM/WCDMA Acquisition Order Preference
      case NAS_555A_RSP_T11:
      {
        nas_555A_rsp->t11_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,nas_555A_rsp->t11.gw_acq_order_pref);
      }
      break;  

      // LTE Band Preference
      case NAS_555A_RSP_T12:
      {
        nas_555A_rsp->t12_valid = TRUE;
        READ_64_BIT_VAL (value_ptr,nas_555A_rsp->t12.lte_band_pref);
      }
      break;      

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_pref_network_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_pref_network_type_info
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with preferred network info.  It
  is used both by the get preferred network info cmd response
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_pref_mode_type_info
(
  unsigned char                    *rx_buf,
  int                               rx_buf_len,
  nas_557D_rsp_s            *nas_557D_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_557D_rsp, 0, sizeof(nas_557D_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      // Mode Preference
      case NAS_557D_RSP_T10:
      {
        nas_557D_rsp->t10_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_557D_rsp->t10.pref_mode);
      }
      break;      

      // LTE Band Preference
      case NAS_557D_RSP_T11:
      {
        nas_557D_rsp->t11_valid = TRUE;
        READ_64_BIT_VAL (value_ptr,nas_557D_rsp->t11.lte_band_pref);
      }
      break;      

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_pref_mode_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_lte_protocol_info
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with lte protocol info.  It
  is used both by the get preferred network info cmd response
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_lte_protocol_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_5556_rsp_s            *nas_5556_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_5556_rsp, 0, sizeof(nas_5556_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      // Mode Preference
      case NAS_5556_RSP_T10:
      {
        nas_5556_rsp->t10_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_5556_rsp->t10.pref_mode);
      }
      break;

      // Service domain
      case NAS_5556_RSP_T11:
      {
        nas_5556_rsp->t11_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_5556_rsp->t11.service_domain_pref);
      }
      break;

      // Security mode
      case NAS_5556_RSP_T12:
      {
        nas_5556_rsp->t12_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_5556_rsp->t12.security);	  
        READ_8_BIT_VAL (value_ptr,nas_5556_rsp->t12.rrc_integrity_enabled);
        READ_8_BIT_VAL (value_ptr,nas_5556_rsp->t12.rrc_ciphering_enabled);		  
        READ_8_BIT_VAL (value_ptr,nas_5556_rsp->t12.rrc_fake_security_enabled);		  
      }
      break;

      // SMS Preference
      case NAS_5556_RSP_T13:
      {
        nas_5556_rsp->t13_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_5556_rsp->t13.sms_gw_bearer_pref);
      }
      break;     

      // IPV6 enabled
      case NAS_5556_RSP_T14:
      {
        nas_5556_rsp->t14_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_5556_rsp->t14.ipv6_enabled);
      }
      break;  		

      // ISR enabled
      case NAS_5556_RSP_T15:
      {
        nas_5556_rsp->t15_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_5556_rsp->t15.isr_enabled);
      }
      break;

      // WCDMA RRC VERSION
      case NAS_5556_RSP_T16:
      {
        nas_5556_rsp->t16_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_5556_rsp->t16.wcdma_rrc_version);
      }
      break;

      // wcdma dl freq
      case NAS_5556_RSP_T17:
      {
        nas_5556_rsp->t17_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_5556_rsp->t17.wcdma_dl_freq_enabled);
        READ_32_BIT_VAL (value_ptr,nas_5556_rsp->t17.wcdma_dl_freq);
        READ_32_BIT_VAL (value_ptr,nas_5556_rsp->t17.forced_freq);
      }
      break;

      case NAS_5556_RSP_T18:
      {
        nas_5556_rsp->t18_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_5556_rsp->t18.gcf_test_mode);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_lte_protocol_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

//20170215 yjoh add for cell info

#if 1//

static int
qmi_nas_get_location_cell_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_get_cell_location_info_resp_msg_v01            *nas_loc_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0, c=0, idx=0;

  memset(nas_loc_rsp, 0, sizeof(nas_loc_rsp));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      // TBD
      case NAS_0043_RSP_T10: //gsm
      {
        nas_loc_rsp->geran_info_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,nas_loc_rsp->geran_info.cell_id);

		 for (i = 0; i < 3; i++ )
       {
        	READ_8_BIT_VAL(value_ptr, nas_loc_rsp->geran_info.plmn[i]);
       }

        READ_16_BIT_VAL (value_ptr,nas_loc_rsp->geran_info.lac);
        READ_16_BIT_VAL (value_ptr,nas_loc_rsp->geran_info.arfcn);
        READ_8_BIT_VAL (value_ptr,nas_loc_rsp->geran_info.bsic);
		 READ_32_BIT_VAL (value_ptr,nas_loc_rsp->geran_info.timing_advance);
 		 READ_16_BIT_VAL (value_ptr,nas_loc_rsp->geran_info.rx_lev);
  		 READ_32_BIT_VAL (value_ptr,nas_loc_rsp->geran_info.nmr_cell_info_len);

		for ( c = 0; c < 5; ++c )
		{
			READ_32_BIT_VAL( value_ptr, nas_loc_rsp->geran_info.nmr_cell_info[c].nmr_cell_id );
			for (i = 0; i < 3; i++ )
	       {
	        	READ_8_BIT_VAL(value_ptr, nas_loc_rsp->geran_info.nmr_cell_info[c].nmr_plmn[i]);
			}
			READ_16_BIT_VAL( value_ptr, nas_loc_rsp->geran_info.nmr_cell_info[c].nmr_lac);
			READ_16_BIT_VAL( value_ptr, nas_loc_rsp->geran_info.nmr_cell_info[c].nmr_arfcn);
			READ_16_BIT_VAL( value_ptr, nas_loc_rsp->geran_info.nmr_cell_info[c].nmr_bsic);
			READ_16_BIT_VAL( value_ptr, nas_loc_rsp->geran_info.nmr_cell_info[c].nmr_rx_lev );
		}
      }
      break;

      case NAS_0043_RSP_T11://wcdma
      {
        nas_loc_rsp->umts_info_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_loc_rsp->umts_info.cell_id);

		 for (i = 0; i < 3; i++ )
       {
        	READ_8_BIT_VAL(value_ptr, nas_loc_rsp->umts_info.plmn[i]);
       }

        READ_16_BIT_VAL (value_ptr,nas_loc_rsp->umts_info.lac);
        READ_16_BIT_VAL (value_ptr,nas_loc_rsp->umts_info.uarfcn);
        READ_16_BIT_VAL (value_ptr,nas_loc_rsp->umts_info.psc);
		 READ_16_BIT_VAL (value_ptr,nas_loc_rsp->umts_info.rscp);
 		 READ_16_BIT_VAL (value_ptr,nas_loc_rsp->umts_info.ecio);
  		 READ_32_BIT_VAL (value_ptr,nas_loc_rsp->umts_info.umts_monitored_cell_len);

/*
		for ( c = 0; c <9; c++ )
		{
			READ_16_BIT_VAL( value_ptr, nas_loc_rsp->umts_info.umts_monitored_cell[c].umts_uarfcn );

			READ_16_BIT_VAL( value_ptr, nas_loc_rsp->umts_info.umts_monitored_cell[c].umts_psc);
			READ_16_BIT_VAL( value_ptr, nas_loc_rsp->umts_info.umts_monitored_cell[c].umts_rscp);
			READ_16_BIT_VAL( value_ptr, nas_loc_rsp->umts_info.umts_monitored_cell[c].umts_ecio);
		}
*/
      }
      break;

	  case NAS_0043_RSP_T13://lte
      {
        nas_loc_rsp->lte_intra_valid= TRUE;
        READ_8_BIT_VAL (value_ptr,nas_loc_rsp->lte_intra.ue_in_idle);

		 for (i = 0; i < 3; i++ )
       {
        	READ_8_BIT_VAL(value_ptr, nas_loc_rsp->lte_intra.plmn[i]);
       }

        READ_16_BIT_VAL (value_ptr,nas_loc_rsp->lte_intra.tac);
        READ_32_BIT_VAL (value_ptr,nas_loc_rsp->lte_intra.global_cell_id);
        READ_16_BIT_VAL (value_ptr,nas_loc_rsp->lte_intra.earfcn);
		 READ_16_BIT_VAL (value_ptr,nas_loc_rsp->lte_intra.serving_cell_id);
 		 READ_8_BIT_VAL (value_ptr,nas_loc_rsp->lte_intra.cell_resel_priority);
		 READ_8_BIT_VAL (value_ptr,nas_loc_rsp->lte_intra.s_non_intra_search);
		 READ_8_BIT_VAL (value_ptr,nas_loc_rsp->lte_intra.thresh_serving_low);
		 READ_8_BIT_VAL (value_ptr,nas_loc_rsp->lte_intra.s_intra_search);
		 
  		 READ_32_BIT_VAL (value_ptr,nas_loc_rsp->lte_intra.cells_len);

		for ( c = 0; c < 5; ++c )
		{
			READ_16_BIT_VAL( value_ptr, nas_loc_rsp->lte_intra.cells[c].pci);

			READ_16_BIT_VAL( value_ptr, nas_loc_rsp->lte_intra.cells[c].rsrq);
			READ_16_BIT_VAL( value_ptr, nas_loc_rsp->lte_intra.cells[c].rsrp);
			READ_16_BIT_VAL( value_ptr, nas_loc_rsp->lte_intra.cells[c].rssi);
			READ_16_BIT_VAL( value_ptr, nas_loc_rsp->lte_intra.cells[c].srxlev);
		}
      }
      break;
     // TBD

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_location_cell_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}
#endif

/*===========================================================================
  FUNCTION  qmi_nas_get_ecall_enable_info
===========================================================================*/
/*!
@brief 

@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
//jaeyong1.park  
static int 
qmi_nas_get_ecall_enable_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_ECALLEN_rsp_s            *nas_ECALLEN_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_ECALLEN_rsp, 0, sizeof(nas_ECALLEN_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {

      case NAS_ECALLEN_RSP_T10:
      {
        nas_ECALLEN_rsp->t10_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_ECALLEN_rsp->t10.ims_enabled);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_ecall_enable_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}



/*===========================================================================
  FUNCTION  qmi_nas_get_ecall_enable_info
===========================================================================*/
/*!
@brief 

@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
//jaeyong1.park  
static int 
qmi_nas_get_modem_returned_value
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_GETVAL_rsp_s            *nas_GETVAL_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_GETVAL_rsp, 0, sizeof(nas_GETVAL_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

	//print response data
	QMI_DEBUG_MSG_1 ("qmi_nas_get_modem_returned_value: getval cmd : %x\n",type);
	QMI_DEBUG_MSG_1 ("qmi_nas_get_modem_returned_value: getval length : %d\n",length);	
	
//        READ_8_BIT_VAL (value_ptr,nas_ECALLEN_rsp->t10.ims_enabled);
	memcpy(nas_GETVAL_rsp, value_ptr, sizeof(nas_GETVAL_rsp_s));

	QMI_DEBUG_MSG_1 ("qmi_nas_get_modem_returned_value: resp data : %s\n", &(nas_GETVAL_rsp->t1.pdata));


  } /* while */

  return QMI_NO_ERR;
}



/*===========================================================================
  FUNCTION  qmi_nas_get_ims_enable_info
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with ims enable info.  It
  is used both by the get imd enable info cmd response
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_ims_enable_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_555E_rsp_s            *nas_555E_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_555E_rsp, 0, sizeof(nas_555E_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {

      case NAS_555E_RSP_T10:
      {
        nas_555E_rsp->t10_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_555E_rsp->t10.ims_enabled);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_ims_enable_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_ecall_oper_mode
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with ims enable info.  It
  is used both by the get imd enable info cmd response
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_returned_ecall_oper_mode
(
  unsigned char                    *rx_buf,
  int                               rx_buf_len,
  nas_7042_rsp_s           				 *nas_7042_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;


  memset(nas_7042_rsp, 0, sizeof(nas_7042_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case NAS_7042_RSP_T1:
      {
        READ_8_BIT_VAL (value_ptr, nas_7042_rsp->t1.ecallmode_read);				
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_ims_enable_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_ims_pdn_enable_info
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with ims enable info.  It
  is used both by the get ims pdn enable info cmd response
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_ims_pdn_enable_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_5560_rsp_s            *nas_5560_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_5560_rsp, 0, sizeof(nas_5560_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {

      case NAS_5560_RSP_T10:
      {
        nas_5560_rsp->t10_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_5560_rsp->t10.ims_pdn_enabled);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_ims_pdn_enable_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_ims_user_config_info
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with ims pdn enable info.  It
  is used both by the get imd enable info cmd response
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_ims_user_config_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_5565_rsp_s            *nas_5565_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_5565_rsp, 0, sizeof(nas_5565_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {

      case NAS_5565_RSP_T10:
      {
        nas_5565_rsp->t10_valid = TRUE;
        memcpy(nas_5565_rsp->t10.regConfigUserName, value_ptr, length);
      }
      break;

      case NAS_5565_RSP_T11:
      {
        nas_5565_rsp->t11_valid = TRUE;
        memcpy(nas_5565_rsp->t11.regConfigPassword, value_ptr, length);
      }
      break;      

      case NAS_5565_RSP_T12:
      {
        nas_5565_rsp->t12_valid = TRUE;
        memcpy(nas_5565_rsp->t12.regConfigPrivateURI, value_ptr, length);
      }
      break;            

      case NAS_5565_RSP_T13:
      {
        nas_5565_rsp->t13_valid = TRUE;
        memcpy(nas_5565_rsp->t13.regConfigDomainName, value_ptr, length);
      }
      break;       

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_ims_user_config_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_ims_rcs_auto_config_info
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with ims pdn enable info.  It
  is used both by the get imd enable info cmd response
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_ims_rcs_auto_config_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_556B_rsp_s            *nas_556B_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_556B_rsp, 0, sizeof(nas_556B_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {

      case NAS_556B_RSP_T10:
      {
        nas_556B_rsp->t10_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_556B_rsp->t10.DisableAutoConfig);
      }
      break;

      case NAS_556B_RSP_T11:
      {
        nas_556B_rsp->t11_valid = TRUE;
        memcpy(nas_556B_rsp->t11.RCSConfigServerAddress, value_ptr, length);
      }
      break;      

      case NAS_556B_RSP_T12:
      {
        nas_556B_rsp->t12_valid = TRUE;
        memcpy(nas_556B_rsp->t12.RCSConfigServerPort, value_ptr, length);
      }
      break;  	  

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_ims_rcs_auto_config_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_ims_dpl_param_info
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with ims dpl param info.  It
  is used both by the get imd enable info cmd response
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_ims_dpl_param_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_556D_rsp_s            *nas_556D_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_556D_rsp, 0, sizeof(nas_556D_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {

      case NAS_556D_RSP_T10:
      {
        nas_556D_rsp->t10_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_556D_rsp->t10.IMSParamSrc);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_ims_dpl_param_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

//hongsg 20140729
/*===========================================================================
  FUNCTION  qmi_nas_get_ims_qipcall_config_info
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with ims reg config info.  It
  is used both by the get imd enable info cmd response
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_ims_qipcall_config_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_556F_rsp_s            *nas_556F_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_556F_rsp, 0, sizeof(nas_556F_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {

      case NAS_556F_RSP_T10:
      {
        nas_556F_rsp->t10_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_556F_rsp->t10.EnableRTCPforActiveVOIPCall);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_ims_qipcall_config_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_ims_reg_config_info
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with ims reg config info.  It
  is used both by the get imd enable info cmd response
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_ims_reg_config_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_5571_rsp_s            *nas_5571_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_5571_rsp, 0, sizeof(nas_5571_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case NAS_5571_RSP_T10:
      {
        nas_5571_rsp->t10_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_5571_rsp->t10.RegEventPacket);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_ims_reg_config_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_ims_voip_config_info
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with ims voip config info.  It
  is used both by the get imd enable info cmd response
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_ims_voip_config_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_5574_rsp_s            *nas_5574_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_5574_rsp, 0, sizeof(nas_5574_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {

      case NAS_5574_RSP_T10:
      {
        nas_5574_rsp->t10_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_5574_rsp->t10.voipConfigExpires);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_ims_voip_config_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

//hongsg 20140814
/*===========================================================================
  FUNCTION  qmi_nas_get_ims_user_agent_info
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with ims reg config info.  It
  is used both by the get imd enable info cmd response
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_ims_user_agent_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_557A_rsp_s            *nas_557A_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_557A_rsp, 0, sizeof(nas_557A_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {

      case NAS_557A_RSP_T10:
      {
        nas_557A_rsp->t10_valid = TRUE;
        memcpy(nas_557A_rsp->t10.UserAgent, value_ptr, length);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_ims_user_agent_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}


/*===========================================================================
  FUNCTION  qmi_nas_get_sys_info_rsp
===========================================================================*/
static int
qmi_nas_get_sys_info_rsp
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_004D_rsp_s                   *nas_004D_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_004D_rsp, 0, sizeof(nas_004D_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      // WCDMA System Info
      case NAS_004D_RSP_T18:
      {
        //nas_004D_ind->t18_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.srv_domain_valid);
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.srv_domain);		
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.srv_capability_valid);				
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.srv_capability);
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.roam_status_valid);		
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.roam_status);				
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.is_sys_forbidden_valid);
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.is_sys_forbidden);	

        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.lac_valid);
        READ_16_BIT_VAL (value_ptr,nas_004D_rsp->t18.lac);		
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.cell_id_valid);				
        READ_32_BIT_VAL (value_ptr,nas_004D_rsp->t18.cell_id);
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.reg_reject_info_valid);		
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.reject_srv_domain);				
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.rej_cause);
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.network_id_valid);	 
        
        for (i = 0; (i < 3); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_004D_rsp->t18.mcc[i]);
//BKS_20131216 modify
        }
        for (i = 0; (i < 3); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_004D_rsp->t18.mnc[i]);          
        } 				

        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.hs_call_status_valid);
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.hs_call_status);		
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.hs_ind_valid);				
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.hs_ind);		
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.psc_valid);				
        READ_16_BIT_VAL (value_ptr,nas_004D_rsp->t18.psc);	
      }
      break;

      // LTE System Info
      case NAS_004D_RSP_T19:
      {
        //nas_004D_ind->t19_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t19.srv_domain_valid);
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t19.srv_domain);		
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t19.srv_capability_valid);				
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t19.srv_capability);
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t19.roam_status_valid);		
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t19.roam_status);				
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t19.is_sys_forbidden_valid);
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t19.is_sys_forbidden);	

        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t19.lac_valid);
        READ_16_BIT_VAL (value_ptr,nas_004D_rsp->t19.lac);		
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t19.cell_id_valid);				
        READ_32_BIT_VAL (value_ptr,nas_004D_rsp->t19.cell_id);
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t19.reg_reject_info_valid);		
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t19.reject_srv_domain);				
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t19.rej_cause);
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t19.network_id_valid);	 
        for (i = 0; (i < 3); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_004D_rsp->t19.mcc[i]);
//BKS_20131216 modify
        }
        for (i = 0; (i < 3); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_004D_rsp->t19.mnc[i]);          
        } 				

        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t19.tac_valid);
        READ_16_BIT_VAL (value_ptr,nas_004D_rsp->t19.tac);	
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_operator_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_sig_info_rsp
===========================================================================*/
/*!
@brief 
  Queries information regarding the signal strength
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_sig_info_rsp
(
  unsigned char                    *rx_buf,
  int                               rx_buf_len,
  nas_004F_rsp_s                   *nas_004F_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_004F_rsp, 0, sizeof(nas_004F_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    switch (type)
    {
      // CDMA Signal Strength Info
      case NAS_004F_RSP_T10:
      {  
        nas_004F_rsp->t10_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_004F_rsp->t10.rssi);
        READ_16_BIT_VAL(value_ptr,nas_004F_rsp->t10.ecio);
      }
      break;

      // HDR Signal Strength Info
      case NAS_004F_RSP_T11:
      {      
        nas_004F_rsp->t11_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_004F_rsp->t11.rssi);
        READ_16_BIT_VAL(value_ptr,nas_004F_rsp->t11.ecio);
        READ_8_BIT_VAL(value_ptr,nas_004F_rsp->t11.sinr);
        READ_32_BIT_VAL(value_ptr,nas_004F_rsp->t11.io);
      }
      break;

      // GSM Signal Strength Info
      case NAS_004F_RSP_T12:
      {      
        nas_004F_rsp->t12_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_004F_rsp->t12.gsm_sig_info);
      }
      break;

      // WCDMA Signal Strength Info
      case NAS_004F_RSP_T13:
      {          
        nas_004F_rsp->t13_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_004F_rsp->t13.rssi);
        READ_16_BIT_VAL(value_ptr,nas_004F_rsp->t13.ecio);
      }
      break;

      // LTE Signal Strength Info
      case NAS_004F_RSP_T14:
      {          
        nas_004F_rsp->t14_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_004F_rsp->t14.rssi);
        READ_8_BIT_VAL(value_ptr,nas_004F_rsp->t14.rsrq);
        READ_16_BIT_VAL(value_ptr,nas_004F_rsp->t14.rsrp);
        READ_16_BIT_VAL(value_ptr,nas_004F_rsp->t14.snr);
      }
      break;

      // TDSCDMA Signal Strength Info
      case NAS_004F_RSP_T15:
      {
        nas_004F_rsp->t15_valid = TRUE;
        READ_8_BIT_VAL(value_ptr,nas_004F_rsp->t15.rscp);
      }
      break;

      // TDSCDMA Signal Strength Info Extended
      case NAS_004F_RSP_T16:
      {
        nas_004F_rsp->t16_valid = TRUE;
        READ_32_BIT_VAL(value_ptr,nas_004F_rsp->t16.rssi);
        READ_32_BIT_VAL(value_ptr,nas_004F_rsp->t16.rscp);
        READ_32_BIT_VAL(value_ptr,nas_004F_rsp->t16.ecio);
        READ_32_BIT_VAL(value_ptr,nas_004F_rsp->t16.sinr);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_sig_info_rsp : Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_network_time_info_rsp
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with lte protocol info.  It
  is used both by the get preferred network info cmd response
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_network_time_info_rsp
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_5558_rsp_s                    *nas_5558_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_5558_rsp, 0, sizeof(nas_5558_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
    &rx_buf_len,
    &type,
    &length,
    &value_ptr) < 0)
    {
    return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      // Universal Time
      case NAS_5558_RSP_T01:
      {
        nas_5558_rsp->t01_valid = TRUE;
        READ_16_BIT_VAL (value_ptr, nas_5558_rsp->t01.year);
        READ_8_BIT_VAL  (value_ptr, nas_5558_rsp->t01.month);
        READ_8_BIT_VAL  (value_ptr, nas_5558_rsp->t01.day);
        READ_8_BIT_VAL  (value_ptr, nas_5558_rsp->t01.hour);
        READ_8_BIT_VAL  (value_ptr, nas_5558_rsp->t01.minute);
        READ_8_BIT_VAL  (value_ptr, nas_5558_rsp->t01.second);
        READ_8_BIT_VAL  (value_ptr, nas_5558_rsp->t01.day_of_week);
      }
      break;

      // Time Zone
      case NAS_5558_RSP_T10:
      {
        nas_5558_rsp->t10_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, nas_5558_rsp->t10.time_zone);
      }
      break;

      // Daylight Saving Adjustment
      case NAS_5558_RSP_T11:
      {
        nas_5558_rsp->t11_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, nas_5558_rsp->t11.daylt_sav_adj);
      }
      break;

      // Radio Interface
      case NAS_5558_RSP_T12:
      {
        nas_5558_rsp->t12_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, nas_5558_rsp->t12.radio_if);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_network_time_info_rsp: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_current_plmn_name_cache_rsp
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with lte protocol info.  It
  is used both by the get preferred network info cmd response
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_current_plmn_name_cache_rsp
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_5559_rsp_s                    *nas_5559_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_5559_rsp, 0, sizeof(nas_5559_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv(&rx_buf, &rx_buf_len, &type, &length, &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case NAS_5559_RSP_T02:
      {
        nas_5559_rsp->t02_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_5559_rsp->t02.result_code);
        READ_16_BIT_VAL (value_ptr,nas_5559_rsp->t02.error_code);
      }
      break;

      case NAS_5559_RSP_T12:
      {
        int i = 0;
        nas_5559_rsp->t12_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, nas_5559_rsp->t12.plmn_name_short_encoding);
        READ_8_BIT_VAL (value_ptr, nas_5559_rsp->t12.plmn_name_short_ci);
        READ_8_BIT_VAL (value_ptr, nas_5559_rsp->t12.plmn_name_short_spare_bits);
        READ_8_BIT_VAL (value_ptr, nas_5559_rsp->t12.plmn_name_short_len);
        for(i=0; i<nas_5559_rsp->t12.plmn_name_short_len; i++)
        {
          READ_8_BIT_VAL (value_ptr, nas_5559_rsp->t12.plmn_name_short[i]);
        }
      }
      break;

      case NAS_5559_RSP_T13:
      {
        nas_5559_rsp->t13_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, nas_5559_rsp->t13.plmn_name_long_encoding);
        READ_8_BIT_VAL (value_ptr, nas_5559_rsp->t13.plmn_name_long_ci);
        READ_8_BIT_VAL (value_ptr, nas_5559_rsp->t13.plmn_name_long_spare_bits);
        READ_8_BIT_VAL (value_ptr, nas_5559_rsp->t13.plmn_name_long_len);
        for(i=0; i<nas_5559_rsp->t13.plmn_name_long_len; i++)
        {
          READ_8_BIT_VAL (value_ptr, nas_5559_rsp->t13.plmn_name_long[i]);
        }
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_current_plmn_name_cache_rsp: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_debug_screen_info_rsp
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with lte protocol info.  It
  is used both by the get preferred network info cmd response
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_debug_screen_info_rsp
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_555C_rsp_s             *nas_555C_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_555C_rsp, 0, sizeof(nas_555C_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
        &rx_buf_len,
        &type,
        &length,
        &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      // Universal Time
      case NAS_555C_RSP_T01:
      {
        nas_555C_rsp->t01_valid = TRUE;
        READ_16_BIT_VAL(value_ptr, nas_555C_rsp->t01.earfcn_dl);
        READ_16_BIT_VAL(value_ptr, nas_555C_rsp->t01.earfcn_ul);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.band_class);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.band_width);
        READ_16_BIT_VAL(value_ptr, nas_555C_rsp->t01.mnc);
        READ_16_BIT_VAL(value_ptr, nas_555C_rsp->t01.mcc);
        READ_16_BIT_VAL(value_ptr, nas_555C_rsp->t01.tac);
        READ_16_BIT_VAL(value_ptr, nas_555C_rsp->t01.pci);
        READ_32_BIT_VAL(value_ptr, nas_555C_rsp->t01.cell_id);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.esm_cause);
        READ_16_BIT_VAL(value_ptr, nas_555C_rsp->t01.drx);
        READ_16_BIT_VAL(value_ptr, nas_555C_rsp->t01.rsrp);
        READ_16_BIT_VAL(value_ptr, nas_555C_rsp->t01.rsrq);
        READ_16_BIT_VAL(value_ptr, nas_555C_rsp->t01.rssi);
        READ_16_BIT_VAL(value_ptr, nas_555C_rsp->t01.l2w);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.ri);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.cqi);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.srv_status);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.emm_status);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.sub_status);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.rrc_state);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.svc);
        READ_16_BIT_VAL(value_ptr, nas_555C_rsp->t01.sinr);
        READ_32_BIT_VAL(value_ptr, nas_555C_rsp->t01.tx_pwr);

        for (i = 0; i < 4; i++ )
        {
          READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.tmsi[i]);
        }

        for (i = 0; i < 4; i++ )
        {
          READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.pdn_addr[i]);
        }

        READ_16_BIT_VAL(value_ptr, nas_555C_rsp->t01.uarfcn_dl);
        READ_16_BIT_VAL(value_ptr, nas_555C_rsp->t01.uarfcn_ul);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.network_type);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.network_mode);
        READ_16_BIT_VAL(value_ptr, nas_555C_rsp->t01.lac);
        READ_16_BIT_VAL(value_ptr, nas_555C_rsp->t01.rac);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.mm_cause);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.mm_state);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.mm_substate);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.gmm_cause);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.gmm_state);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.gmm_substate);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.gmm_update_status);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.sm_cause);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.w_rrc_state);

        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.pmm_mode);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.pdp_state);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.sim_state);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.cm_call_state);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.mnc_includes_pcs_digit);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.oprt_mode);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.location_update_status);

        for (i = 0; i < 4; i++ )
        {
          READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.p_tmsi[i]);
        }

        for (i = 0; i < 4; i++ )
        {
          READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.pdp_addr[i]);
        }

        for (i = 0; i < 4; i++ )
        {
          READ_16_BIT_VAL(value_ptr, nas_555C_rsp->t01.nset_psc[i]);
        }

        for (i = 0; i < 4; i++ )
        {
          READ_16_BIT_VAL(value_ptr, nas_555C_rsp->t01.nset_rscp[i]);
        }

        for (i = 0; i < 4; i++ )
        { 
          READ_16_BIT_VAL(value_ptr, nas_555C_rsp->t01.nset_ecio[i]);
        }

        READ_16_BIT_VAL(value_ptr, nas_555C_rsp->t01.w2l);
        READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.bler);
        READ_16_BIT_VAL(value_ptr, nas_555C_rsp->t01.iference);

        READ_32_BIT_VAL(value_ptr, nas_555C_rsp->t01.rx_pwr);
        READ_32_BIT_VAL(value_ptr, nas_555C_rsp->t01.tx_adj);

        for (i = 0; i < 20; i++ )
        { 
          READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.imsi[i]);
        }

        for (i = 0; i < 20; i++ )
        { 
          READ_8_BIT_VAL(value_ptr, nas_555C_rsp->t01.msisdn[i]);
        }

		//dsji_20160929 add {
				//if ( wmm_get_vendor_type() == WMM_VENDOR_A_KOR )
			//	{
					{
						int n = 0;
						
						READ_32_BIT_VAL( value_ptr, nas_555C_rsp->t01.sib19_info.eutra_num );
						if ( nas_555C_rsp->t01.sib19_info.eutra_num > QMI_MAX_EUTRA_INFO_NUM )
						{
							nas_555C_rsp->t01.sib19_info.eutra_num = QMI_MAX_EUTRA_INFO_NUM;
						}

						for ( n = 0; n < QMI_MAX_EUTRA_INFO_NUM; ++n )
						{
							READ_32_BIT_VAL( value_ptr, nas_555C_rsp->t01.sib19_info.eutra_wtol[ n ] );
						}
					}

					{
						int f = 0;
						int c = 0;

						READ_8_BIT_VAL( value_ptr, nas_555C_rsp->t01.lte_inter_info.freq_num );
						if ( nas_555C_rsp->t01.lte_inter_info.freq_num > QMI_MAX_LTE_FREQ_INFO_NUM )
						{
							nas_555C_rsp->t01.lte_inter_info.freq_num = QMI_MAX_LTE_FREQ_INFO_NUM;
						}

						for ( f = 0; f < QMI_MAX_LTE_FREQ_INFO_NUM; ++f )
						{
							READ_32_BIT_VAL( value_ptr, nas_555C_rsp->t01.lte_inter_info.freq_info[ f ].earfcn );
							READ_8_BIT_VAL( value_ptr, nas_555C_rsp->t01.lte_inter_info.freq_info[ f ].cell_num );
							if ( nas_555C_rsp->t01.lte_inter_info.freq_info[ f ].cell_num > QMI_MAX_LTE_CELL_INFO_NUM )
							{
								nas_555C_rsp->t01.lte_inter_info.freq_info[ f ].cell_num = QMI_MAX_LTE_CELL_INFO_NUM;
							}

							for ( c = 0; c < QMI_MAX_LTE_CELL_INFO_NUM; ++c )
							{
								READ_16_BIT_VAL( value_ptr, nas_555C_rsp->t01.lte_inter_info.freq_info[ f ].cell_info[ c ].pci );
								READ_16_BIT_VAL( value_ptr, nas_555C_rsp->t01.lte_inter_info.freq_info[ f ].cell_info[ c ].rsrp );
								READ_16_BIT_VAL( value_ptr, nas_555C_rsp->t01.lte_inter_info.freq_info[ f ].cell_info[ c ].rsrq );
								READ_16_BIT_VAL( value_ptr, nas_555C_rsp->t01.lte_inter_info.freq_info[ f ].cell_info[ c ].rssi );
								READ_16_BIT_VAL( value_ptr, nas_555C_rsp->t01.lte_inter_info.freq_info[ f ].cell_info[ c ].sinr );
							}
						}

						READ_8_BIT_VAL( value_ptr, nas_555C_rsp->t01.lte_intra_info.cell_num );
						if ( nas_555C_rsp->t01.lte_intra_info.cell_num > QMI_MAX_LTE_CELL_INFO_NUM )
						{
							nas_555C_rsp->t01.lte_intra_info.cell_num = QMI_MAX_LTE_CELL_INFO_NUM;
						}

						for ( c = 0; c < QMI_MAX_LTE_CELL_INFO_NUM; ++c )
						{
							READ_16_BIT_VAL( value_ptr, nas_555C_rsp->t01.lte_intra_info.cell_info[ c ].pci );
							READ_16_BIT_VAL( value_ptr, nas_555C_rsp->t01.lte_intra_info.cell_info[ c ].rsrp );
							READ_16_BIT_VAL( value_ptr, nas_555C_rsp->t01.lte_intra_info.cell_info[ c ].rsrq );
							READ_16_BIT_VAL( value_ptr, nas_555C_rsp->t01.lte_intra_info.cell_info[ c ].rssi );
							READ_16_BIT_VAL( value_ptr, nas_555C_rsp->t01.lte_intra_info.cell_info[ c ].sinr );
						}
					}
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_debug_screen_info_rsp: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

//BKS_20131107 - start
//--> RIL_REQUEST_HK_GET_CDMA_DEBUG_INFO
/*===========================================================================
  FUNCTION  qmi_nas_request_hk_get_cdma_debug_info_rsp
===========================================================================*/
static int
qmi_nas_request_hk_get_cdma_debug_info_rsp
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_5562_rsp_s             *nas_5562_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_5562_rsp, 0, sizeof(nas_5562_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
        &rx_buf_len,
        &type,
        &length,
        &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      /* command parameters */
      case NAS_5562_RSP_T10:
      {
        nas_5562_rsp->t10_valid = TRUE;
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t10.reg_zone);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t10.packet_zone);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t10.bs_p_rev);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t10.p_rev_in_use);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t10.is_registered);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t10.ccs_supported);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t10.uz_id);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t10.srch_win_n);
        READ_32_BIT_VAL(value_ptr, nas_5562_rsp->t10.base_lat);
        READ_32_BIT_VAL(value_ptr, nas_5562_rsp->t10.base_long);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t10.base_id);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t10.reject_srv_domain);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t10.reject_cause);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t10.active_status);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t10.service_option);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t10.slot_cycle_index);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t10.cdma_lock_mode);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t10.curr_nam);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t10.ps_data_suspend);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t10.packet_state);
      }
      break;

      /* 1x related parameters */
      case NAS_5562_RSP_T11:
      {
        nas_5562_rsp->t11_valid = TRUE;
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t11.service_status);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t11.roam_status);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t11.sid);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t11.nid);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t11.mcc);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t11.imsi_11_12);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t11.active_band);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t11.active_channel);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t11.rssi);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t11.ecio);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t11.tx_pwr);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t11.tx_adj);
        for( i = 0 ; i < QMI_1X_PSC_SIZE ; i++)
        {
          READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t11.psc[i].psc);
          READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t11.psc[i].ecio);
        }
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t11.frame_err_rate);
      }
      break;

      /* 1x related parameters */
      case NAS_5562_RSP_T12:
      {
        nas_5562_rsp->t12_valid = TRUE;
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t12.hdr_service_status);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t12.hdr_roam_status);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t12.hdr_sid);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t12.hdr_nid);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t12.hdr_mcc);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t12.hdr_imsi_11_12);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t12.hybrid_active_band);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t12.hybrid_active_channel);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t12.hdr_rssi);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t12.hdr_ecio);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t12.hdr_sinr);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t12.hdr_packet_err_rate);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t12.serving_pn);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t12.prot_state);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t12.hdr_session_state);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t12.uati24);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t12.color_code);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t12.uati_subnet_mask);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t12.sector_color_code);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t12.attempts_count);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t12.success_count);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t12.failure_count);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t12.dl_rate);
        READ_16_BIT_VAL(value_ptr, nas_5562_rsp->t12.ul_rate);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t12.fcp_enabled);
        for( i = 0 ; i < QMI_HDR_SECTOR_ID_SIZE ; i++ )
        {
          READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t12.sector_id[i]);
        }
      }
      break;

      /* 1x related parameters */
      case NAS_5562_RSP_T13:
      {
        nas_5562_rsp->t13_valid = TRUE;
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t13.rf_mode);
        READ_8_BIT_VAL(value_ptr, nas_5562_rsp->t13.ac_state);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_request_hk_get_cdma_debug_info_rsp: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_reg_ind_hdlr
===========================================================================*/
/*!
@brief 
  This function is a callback that will be called once during client
  initialization  
  
@return 
  None.

@note

  - Dependencies
    - None.

  - Side Effects
    - None.
*/    
/*=========================================================================*/
int qmi_nas_reg_ind_hdlr (qmi_service_ind_rx_hdlr  user_ind_msg_hdlr)
{
  int  rc = QMI_NO_ERR;
  if (!nas_service_initialized)
  {

    rc = qmi_service_set_srvc_functions (QMI_NAS_SERVICE,
                                 user_ind_msg_hdlr);
    if (rc != QMI_NO_ERR)
    {
      printf("tof_qmi_nas_srvc_init: set srvc functions returns err=%d\n",rc);
    }
    else
    {
      printf("tof_qmi_nas_srvc_init: NAS successfully initialized\r\n");
      nas_service_initialized = TRUE;
    }
  }
  else
  {
    printf("tof_qmi_nas_srvc_init: Init failed, NAS already initialized\r\n");
  }
  return rc;
}

/*===========================================================================
  FUNCTION  tof_tof_qmi_nas_srvc_init_client
===========================================================================*/
/*!
@brief 
  This function is called to initialize the NAS service.  This function
  must be called prior to calling any other NAS service functions.
  For the time being, the indication handler callback and user data
  should be set to NULL until this is implemented.  Also note that this
  function may be called multiple times to allow for multiple, independent
  clients.   
  
@return 
  0 if abort operation was sucessful, < 0 if not.  If return code is 
  QMI_INTERNAL_ERR, then the qmi_err_code will be valid and will 
  indicate which QMI error occurred.

@note

  - Dependencies
    - qmi_connection_init() must be called for the associated port first.

  - Side Effects
    - Talks to modem processor
*/    
/*=========================================================================*/
qmi_client_handle_type
tof_tof_qmi_nas_srvc_init_client
(
   const char                   *dev_id,
  qmi_nas_indication_hdlr_type  user_ind_msg_hdlr,
  void                          *user_ind_msg_hdlr_user_data,
  int                           *qmi_err_code
)
{
  qmi_client_handle_type client_handle;
  qmi_connection_id_type conn_id;

  printf("tof_tof_qmi_nas_srvc_init_client\r\n");
  
  if ((conn_id = QMI_PLATFORM_DEV_NAME_TO_CONN_ID(dev_id)) == QMI_CONN_ID_INVALID)
  {
    printf("tof_tof_qmi_nas_srvc_init_client: conn_id fail %x\r\n",conn_id);
    return QMI_INTERNAL_ERR;
  }

  printf("tof_tof_qmi_nas_srvc_init_client: conn_id %x\r\n",conn_id);
  
   /* Call common service layer initialization function */
  /*lint -e{611} */
  client_handle =  qmi_service_init (conn_id,
                                   QMI_NAS_SERVICE,
                                   (void *) user_ind_msg_hdlr,
                                   user_ind_msg_hdlr_user_data,
                                   qmi_err_code);
 
 
  if(client_handle > 0)  
    qmi_nas_reg_ind_hdlr(qmi_nas_srvc_indication_cb);
  else 
    printf("tof_tof_qmi_nas_srvc_init_client: client_handle  0x%x failed \r\n",client_handle);


  return client_handle;
}

/*===========================================================================
  FUNCTION  tof_qmi_nas_srvc_release_client
===========================================================================*/
/*!
@brief 
  This function is called to release a client created by the 
  tof_qmi_nas_srvc_init_client() function.  This function should be called
  for any client created when terminating a client process, especially
  if the modem processor is not reset.  The modem side QMI server has 
  a limited number of clients that it will allocate, and if they are not
  released, we will run out.  
  
@return 
  0 if abort operation was sucessful, < 0 if not.  If return code is 
  QMI_INTERNAL_ERR, then the qmi_err_code will be valid and will 
  indicate which QMI error occurred.

@note

  - Dependencies
    - qmi_connection_init() must be called for the associated port first.

  - Side Effects
    - Talks to modem processor
*/    
/*=========================================================================*/

int 
tof_qmi_nas_srvc_release_client
(
  int      user_handle,
  int      *qmi_err_code
)
{
  int  rc = QMI_NO_ERR;
  
  rc = qmi_service_release (user_handle, qmi_err_code);

  if (nas_service_initialized)
  {

    rc = qmi_service_set_srvc_functions (QMI_NAS_SERVICE,NULL);
    if (rc != QMI_NO_ERR)
    {
      printf("tof_qmi_nas_srvc_release_client: set srvc functions returns err=%d\n",rc);
    }
    else
    {
      printf("tof_qmi_nas_srvc_release_client: NAS successfully released\r\n");
      nas_service_initialized = FALSE;
    }
  }
  else
  {
    printf("tof_qmi_nas_srvc_release_client: Release failed, NAS not initialized\r\n");
  }
  
  return rc;     
}

/*===========================================================================
  FUNCTION  qmi_nas_set_event_report_state
===========================================================================*/
/*!
@brief 
  Set the NAS event reporting state
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_event_report_state
(
  int                               client_handle,
  nas_0002_req_s                    *nas_0002_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_0002_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  /* Write system selection preference TLV if appropriate */ 
  if(nas_0002_req->t10_valid)
  {
    if (nas_0002_req->t10.num_signal_strength_thresholds > 5)
    {
      QMI_ERR_MSG_0 ("qmi_nas_set_event_report_state::Bad Input\n");
      return QMI_INTERNAL_ERR;
    }
  
    val_ptr = (unsigned char*)&nas_0002_req->t10;
    tlv_length = sizeof(nas_0002_req->t10.report_signal_strength) + sizeof(nas_0002_req->t10.num_signal_strength_thresholds) + sizeof(nas_0002_req->t10.report_signal_strength_threshold_list[0]) * nas_0002_req->t10.num_signal_strength_thresholds;
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0002_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }

  if(nas_0002_req->t11_valid)
  {
    val_ptr = (unsigned char*)&nas_0002_req->t11;
    tlv_length = sizeof(nas_0002_req->t11);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0002_REQ_T11,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_0002_req->t12_valid)
  {
    val_ptr = (unsigned char*)&nas_0002_req->t12;
    tlv_length = sizeof(nas_0002_req->t12);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0002_REQ_T12,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }    

  if(nas_0002_req->t13_valid)
  {
    val_ptr = (unsigned char*)&nas_0002_req->t13;
    tlv_length = sizeof(nas_0002_req->t13);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0002_REQ_T13,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }  

  if(nas_0002_req->t14_valid)
  {
    val_ptr = (unsigned char*)&nas_0002_req->t14;
    tlv_length = sizeof(nas_0002_req->t14);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0002_REQ_T14,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_0002_req->t15_valid)
  {
    val_ptr = (unsigned char*)&nas_0002_req->t15;
    tlv_length = sizeof(nas_0002_req->t15);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0002_REQ_T15,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_0002_req->t16_valid)
  {
    val_ptr = (unsigned char*)&nas_0002_req->t16;
    tlv_length = sizeof(nas_0002_req->t16);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0002_REQ_T16,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_0002_req->t17_valid)
  {
    val_ptr = (unsigned char*)&nas_0002_req->t17;
    tlv_length = sizeof(nas_0002_req->t17);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0002_REQ_T17,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_0002_req->t18_valid)
  {
    val_ptr = (unsigned char*)&nas_0002_req->t18;
    tlv_length = sizeof(nas_0002_req->t18);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0002_REQ_T18,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_0002_req->t19_valid)
  {
    if (nas_0002_req->t19.num_thresholds > 10)
    {
      QMI_ERR_MSG_0 ("qmi_nas_set_event_report_state::Bad Input\n");
      return QMI_INTERNAL_ERR;
    }
  
    val_ptr = (unsigned char*)&nas_0002_req->t19;
    tlv_length = sizeof(nas_0002_req->t19.report_ecio) + sizeof(nas_0002_req->t19.num_thresholds) +  sizeof(nas_0002_req->t19.threshold_list[0]) * nas_0002_req->t19.num_thresholds;
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0002_REQ_T19,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }  

  if(nas_0002_req->t1A_valid)
  {
    if (nas_0002_req->t1A.num_thresholds > 5)
    {
      QMI_ERR_MSG_0 ("qmi_nas_set_event_report_state::Bad Input\n");
      return QMI_INTERNAL_ERR;
    }
  
    val_ptr = (unsigned char*)&nas_0002_req->t1A;
    tlv_length = sizeof(nas_0002_req->t1A.report_sinr) + sizeof(nas_0002_req->t1A.num_thresholds) + sizeof(nas_0002_req->t1A.threshold_list[0]) * nas_0002_req->t1A.num_thresholds;
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0002_REQ_T1A,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_0002_req->t1B_valid)
  {
    val_ptr = (unsigned char*)&nas_0002_req->t1B;
    tlv_length = sizeof(nas_0002_req->t1B);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0002_REQ_T1B,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }   

  if(nas_0002_req->t1C_valid)
  {
    val_ptr = (unsigned char*)&nas_0002_req->t1C;
    tlv_length = sizeof(nas_0002_req->t1C);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0002_REQ_T1C,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }     

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_EVENT_REPORT_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}

/*===========================================================================
  FUNCTION  qmi_nas_config_sig_info2
===========================================================================*/
/*!
@brief 
  Sets the signal strength reporting thresholds.
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_config_sig_info2
(
  int                               client_handle,
  nas_006C_req_s             *nas_006C_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_006C_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  /* Write system selection preference TLV if appropriate */ 
    //CDMA
   if(nas_006C_req->t11_valid)
  {
    val_ptr = (unsigned char*)&nas_006C_req->t11;
    tlv_length = sizeof(nas_006C_req->t11);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_006C_REQ_T11,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }    

   if(nas_006C_req->t13_valid)
  {
    val_ptr = (unsigned char*)&nas_006C_req->t13;
    tlv_length = sizeof(nas_006C_req->t13);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_006C_REQ_T13,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }

  //HDR
   if(nas_006C_req->t15_valid)
  {
    val_ptr = (unsigned char*)&nas_006C_req->t15;
    tlv_length = sizeof(nas_006C_req->t15);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_006C_REQ_T15,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

   if(nas_006C_req->t17_valid)
  {
    val_ptr = (unsigned char*)&nas_006C_req->t17;
    tlv_length = sizeof(nas_006C_req->t17);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_006C_REQ_T17,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

   if(nas_006C_req->t19_valid)
  {
    val_ptr = (unsigned char*)&nas_006C_req->t19;
    tlv_length = sizeof(nas_006C_req->t19);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_006C_REQ_T19,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }

   //WCDMA
   if(nas_006C_req->t1F_valid)
  {
    val_ptr = (unsigned char*)&nas_006C_req->t1F;
    tlv_length = sizeof(nas_006C_req->t1F);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_006C_REQ_T1F,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

   if(nas_006C_req->t21_valid)
  {
    val_ptr = (unsigned char*)&nas_006C_req->t21;
    tlv_length = sizeof(nas_006C_req->t21);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_006C_REQ_T21,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  //LTE
   if(nas_006C_req->t23_valid)
  {
    val_ptr = (unsigned char*)&nas_006C_req->t23;
    tlv_length = sizeof(nas_006C_req->t23);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_006C_REQ_T23,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }  

    if(nas_006C_req->t25_valid)
  {
    val_ptr = (unsigned char*)&nas_006C_req->t25;
    tlv_length = sizeof(nas_006C_req->t25);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_006C_REQ_T25,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }  
    
  if(nas_006C_req->t27_valid)
  {
    val_ptr = (unsigned char*)&nas_006C_req->t27;
    tlv_length = sizeof(nas_006C_req->t27);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_006C_REQ_T27,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }  
  
  if(nas_006C_req->t29_valid)
  {
    val_ptr = (unsigned char*)&nas_006C_req->t29;
    tlv_length = sizeof(nas_006C_req->t29);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_006C_REQ_T29,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 
  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_CONFIG_SIG_INFO2_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}


/*===========================================================================
  FUNCTION  qmi_nas_set_network_sel_auto
===========================================================================*/
/*!
@brief 
    Sets the list of preferred network providers in the SIM/UIM to the list
    provided in the request
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_network_sel_auto
(
  int                               client_handle,
  nas_0033_req_s                    *nas_0033_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_0033_req)
  {
    return QMI_INTERNAL_ERR;
  }

  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(nas_0033_req->t11_valid)
  {
    val_ptr = (unsigned char*)&nas_0033_req->t11;
    tlv_length = sizeof(nas_0033_req->t11);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                              &msg_size,
                                              NAS_0033_REQ_T11,
                                              tlv_length,
                                              (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_0033_req->t12_valid)
  {
    val_ptr = (unsigned char*)&nas_0033_req->t12;
    tlv_length = sizeof(nas_0033_req->t12);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0033_REQ_T12,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_0033_req->t15_valid)
  {
    val_ptr = (unsigned char*)&nas_0033_req->t15;
    tlv_length = sizeof(nas_0033_req->t15);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0033_REQ_T15,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_0033_req->t16_valid)
  {
    val_ptr = (unsigned char*)&nas_0033_req->t16;
    tlv_length = sizeof(nas_0033_req->t16);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                              &msg_size,
                                              NAS_0033_REQ_T16,
                                              tlv_length,
                                              (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_0033_req->t19_valid)
  {
    val_ptr = (unsigned char*)&nas_0033_req->t19;
    tlv_length = sizeof(nas_0033_req->t19);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                              &msg_size,
                                              NAS_0033_REQ_T19,
                                              tlv_length,
                                              (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_0033_req->t1E_valid)
  {
    val_ptr = (unsigned char*)&nas_0033_req->t1E;
    tlv_length = sizeof(nas_0033_req->t1E);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0033_REQ_T1E,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                                          QMI_NAS_SERVICE,
                                                          QMI_NAS_SET_SYS_SEL_PREF,
                                                          QMI_SRVC_PDU_PTR(msg),
                                                          QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                                          msg,                 
                                                          &msg_size,
                                                          QMI_EAP_STD_MSG_SIZE,
                                                          QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                                          qmi_err_code);

  return rc;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_serving_system
===========================================================================*/
/*!
@brief 
  This message queries for information on the system that is currently 
  providing service.
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_get_serving_system
(
  int                               client_handle,
  nas_0024_rsp_s                    *nas_0024_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_0024_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_SERVING_SYSTEM_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {
    if (qmi_nas_get_serving_system_info (msg,msg_size,nas_0024_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_serving_system: qmi_nas_get_serving_system_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 
  }
  return rc;     
}

/*===========================================================================
  FUNCTION  qmi_nas_get_signal_strength
===========================================================================*/
/*!
@brief 
  Gives the current signal strength measured by the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_signal_strength
(
  int                               client_handle,
  nas_0020_rsp_s                    *nas_0020_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];  
  int               msg_size=0, rc=0;

  if(!nas_0020_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                                          QMI_NAS_SERVICE,
                                                          QMI_NAS_GET_SIGNAL_STRENGTH_MSG_ID,
                                                          QMI_SRVC_PDU_PTR(msg),
                                                          QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                                          msg,                 
                                                          &msg_size,
                                                          QMI_EAP_STD_MSG_SIZE,
                                                          QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                                          qmi_err_code);

  if (rc == QMI_NO_ERR)
  {
    if (qmi_nas_get_signal_strength_info (msg,msg_size,nas_0020_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_signal_strength: qmi_nas_get_signal_strength_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 
  }
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_sig_info
===========================================================================*/
/*!
@brief 
  Gives the current signal strength measured by the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_sig_info
(
  int                               client_handle,
  nas_004F_rsp_s                    *nas_004F_rsp, 
  int                               *qmi_err_code
)
{
  //unsigned char	msg[ QMI_MAX_STD_MSG_SIZE ];
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size=0, rc=0;

  if(!nas_004F_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                                          QMI_NAS_SERVICE,
                                                          QMI_NAS_GET_SIG_INFO_MSG_ID,
                                                          QMI_SRVC_PDU_PTR(msg),
                                                          QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                                          msg,                 
                                                          &msg_size,
                                                          QMI_EAP_STD_MSG_SIZE,
                                                          QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                                          qmi_err_code);

  if (rc == QMI_NO_ERR)
  {
    if (qmi_nas_get_sig_info_rsp (msg, msg_size, nas_004F_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_sig_info: qmi_nas_get_sig_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 
  }
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_preferred_network
===========================================================================*/
/*!
@brief 
  Get the different System Selection Preference of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_pref_network
(
  int                               client_handle,
  nas_0034_rsp_s                    *nas_0034_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_0034_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                                          QMI_NAS_SERVICE,
                                                          QMI_NAS_GET_SYS_SEL_PREF_MSG_ID,
                                                          QMI_SRVC_PDU_PTR(msg),
                                                          QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                                          msg,                 
                                                          &msg_size,
                                                          QMI_EAP_STD_MSG_SIZE,
                                                          QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                                          qmi_err_code);

  if (rc == QMI_NO_ERR)
  {
    if (qmi_nas_get_pref_network_info (msg,msg_size,nas_0034_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_pref_network: qmi_nas_get_pref_network_info returned error");
      rc = QMI_INTERNAL_ERR;
    }
  }
  return rc;     
}

/*===========================================================================
  FUNCTION  qmi_nas_get_preferred_network_type
===========================================================================*/
/*!
@brief 
  Get the different System Selection Preference of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_pref_network_type
(
  int                               client_handle,
  nas_555A_rsp_s             *nas_555A_rsp,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_555A_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                                          QMI_NAS_SERVICE,
                                                          QMI_NAS_GET_NETWORK_TYPE_MSG_ID,
                                                          QMI_SRVC_PDU_PTR(msg),
                                                          QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                                          msg,                 
                                                          &msg_size,
                                                          QMI_EAP_STD_MSG_SIZE,
                                                          QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                                          qmi_err_code);


  if (rc == QMI_NO_ERR)
  {
    if (qmi_nas_get_pref_network_type_info (msg,msg_size,nas_555A_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_pref_network: qmi_nas_get_pref_network_info returned error");
      rc = QMI_INTERNAL_ERR;
    }
  }

  return rc;     
}

uint16
get_mode_pref_to_ril
(
  uint16                               pref_net,
  uint32					gw_acq_order_pref,
  uint64          lte_band_pref
)
{
  if (pref_net == 9)
  	return PREF_NET_TYPE_CDMA_ONLY;
  else if (pref_net == 10)
  	return PREF_NET_TYPE_EVDO_ONLY;
  else if (pref_net == 19)
  	return PREF_NET_TYPE_CDMA_EVDO_AUTO;
  else if (pref_net == 13)
  	return PREF_NET_TYPE_GSM_ONLY;
  else if (pref_net == 14)
  	return PREF_NET_TYPE_WCDMA;
  else if (pref_net == 17)
  {
  	if (gw_acq_order_pref == 0x02)
		return PREF_NET_TYPE_GSM_WCDMA;
	else
   		return PREF_NET_TYPE_GSM_WCDMA_AUTO;
  }
  else if (pref_net == 52)
  	return PREF_NET_TYPE_GSM_WCDMA_CDMA_EVDO_AUTO;
  else if (pref_net == 30)
  {
    if (lte_band_pref == 4)
    	return PREF_NET_TYPE_LTE_1800;
    else if (lte_band_pref == 16)
       return PREF_NET_TYPE_LTE_850;
    else
  	return PREF_NET_TYPE_LTE_ONLY;
  }
  else if (pref_net == 36)
  	return PREF_NET_TYPE_LTE_CDMA_EVDO;
//W/L mode��  PREF_NET_TYPE_LTE_GSM_WCDMA�� ���ϵǰ� �ӽ÷� ���Ƶ�  else if (pref_net == 0x1C)
  else if (pref_net == 35)
	return PREF_NET_TYPE_LTE_GSM_WCDMA;
  else if (pref_net == 4)
  	return PREF_NET_TYPE_LTE_CMDA_EVDO_GSM_WCDMA;
  else
  	return PREF_NET_TYPE_MAX;

}

/*===========================================================================
  FUNCTION  qmi_nas_set_pref_network_type
===========================================================================*/
/*!
@brief 
    Sets the list of preferred network providers in the SIM/UIM to the list
    provided in the request
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_pref_network_type
(
  int                               client_handle,
  nas_555B_req_s             *nas_555B_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_555B_req)
  {
    return QMI_INTERNAL_ERR;
  }

  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(nas_555B_req->t10_valid)
  {
    val_ptr = (unsigned char*)&nas_555B_req->t10;
    tlv_length = sizeof(nas_555B_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                              &msg_size,
                                              NAS_555B_REQ_T10,
                                              tlv_length,
                                              (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_555B_req->t11_valid)
  {
    val_ptr = (unsigned char*)&nas_555B_req->t11;
    tlv_length = sizeof(nas_555B_req->t11);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                              &msg_size,
                                              NAS_555B_REQ_T11,
                                              tlv_length,
                                              (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_555B_req->t12_valid)
  {
    val_ptr = (unsigned char*)&nas_555B_req->t12;
    tlv_length = sizeof(nas_555B_req->t12);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                              &msg_size,
                                              NAS_555B_REQ_T12,
                                              tlv_length,
                                              (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                                          QMI_NAS_SERVICE,
                                                          QMI_NAS_SET_NETWORK_TYPE_MSG_ID,
                                                          QMI_SRVC_PDU_PTR(msg),
                                                          QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                                          msg,                 
                                                          &msg_size,
                                                          QMI_EAP_STD_MSG_SIZE,
                                                          QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                                          qmi_err_code);

  return rc;
}

uint16
set_mode_pref_to_ril
(
  uint16                               mode_pref
)
{

  uint16 value = 0;

  if ((mode_pref == PREF_NET_TYPE_GSM_WCDMA) ||(mode_pref == PREF_NET_TYPE_GSM_WCDMA_AUTO))
  {
  	value = 17;
  }
  else if (mode_pref == PREF_NET_TYPE_GSM_ONLY)
  {
  	value = 13;
  }
  else if (mode_pref == PREF_NET_TYPE_WCDMA)
  {
  	value = 14;
  }
  else if (mode_pref == PREF_NET_TYPE_CDMA_EVDO_AUTO)
  {
  	value = 19;
  }
  else if (mode_pref == PREF_NET_TYPE_CDMA_ONLY)
  {
  	value = 9;
  }
  else if (mode_pref == PREF_NET_TYPE_EVDO_ONLY)
  {
  	value = 10;
  }
  else if (mode_pref == PREF_NET_TYPE_GSM_WCDMA_CDMA_EVDO_AUTO)
  {
  	value = 52;
  }  
  else if (mode_pref == PREF_NET_TYPE_LTE_CDMA_EVDO)
  {
  	value = 36;
  }  
  else if (mode_pref == PREF_NET_TYPE_LTE_GSM_WCDMA)
  {
    value = 35;
  	//value = 0x1C;
  }  
  else if (mode_pref == PREF_NET_TYPE_LTE_CMDA_EVDO_GSM_WCDMA)
  {
  	value = 4;
  }    
  else if ((mode_pref == PREF_NET_TYPE_LTE_ONLY) ||(mode_pref == PREF_NET_TYPE_LTE_850) ||(mode_pref == PREF_NET_TYPE_LTE_1800))
  {
  	value = 30;
  }
  else
  	return value;
/*
  switch(mode_pref)
  {
    case PREF_NET_TYPE_GSM_WCDMA:
    case PREF_NET_TYPE_GSM_WCDMA_AUTO:
      value = 0x0C;
    break;

    case PREF_NET_TYPE_GSM_ONLY:
      value = 0x04;
    break;

    case PREF_NET_TYPE_WCDMA:
      value = 0x08;
    break;

    case PREF_NET_TYPE_CDMA_EVDO_AUTO:
      value = 0x03;      
    break;

    case PREF_NET_TYPE_CDMA_ONLY:
      value = 0x01;
    break;

    case PREF_NET_TYPE_EVDO_ONLY:
      value = 0x02;
    break;

    case PREF_NET_TYPE_GSM_WCDMA_CDMA_EVDO_AUTO:
      value = 0x0F;     
    break;

    case PREF_NET_TYPE_LTE_CDMA_EVDO:
      value = 0x13;
    break;
    
    case PREF_NET_TYPE_LTE_GSM_WCDMA:
      value = 0x18;
  	//value = 0x1C;
    break;
    
    case PREF_NET_TYPE_LTE_CMDA_EVDO_GSM_WCDMA:
      value = 0x1F;
    break;
    
    case PREF_NET_TYPE_LTE_ONLY:
      value = 0x10;
    break;

    default:
     break;
  }
  */
  return value;     
}

/*===========================================================================
  FUNCTION  qmi_nas_get_preferred_mode_type
===========================================================================*/
/*!
@brief 
  Get the different System Selection Preference of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_pref_mode_type
(
  int                               client_handle,
  nas_557D_rsp_s             *nas_557D_rsp,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_557D_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                                          QMI_NAS_SERVICE,
                                                          QMI_NAS_GET_NETWORK_MODE_MSG_ID,
                                                          QMI_SRVC_PDU_PTR(msg),
                                                          QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                                          msg,                 
                                                          &msg_size,
                                                          QMI_EAP_STD_MSG_SIZE,
                                                          QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                                          qmi_err_code);

  if (rc == QMI_NO_ERR)
  {
    if (qmi_nas_get_pref_mode_type_info (msg,msg_size,nas_557D_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_pref_mode: qmi_nas_get_pref_mode_info returned error");
      rc = QMI_INTERNAL_ERR;
    }
  }

  return rc;     
}


/*===========================================================================
  FUNCTION  qmi_nas_set_pref_mode_type
===========================================================================*/
/*!
@brief 
    Sets the list of preferred network providers in the SIM/UIM to the list
    provided in the request
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_pref_mode_type
(
  int                               client_handle,
  nas_557C_req_s             *nas_557C_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_557C_req)
  {
    return QMI_INTERNAL_ERR;
  }

  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(nas_557C_req->t10_valid)
  {
    val_ptr = (unsigned char*)&nas_557C_req->t10;
    tlv_length = sizeof(nas_557C_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                              &msg_size,
                                              NAS_557C_REQ_T10,
                                              tlv_length,
                                              (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_557C_req->t11_valid)
  {
    val_ptr = (unsigned char*)&nas_557C_req->t11;
    tlv_length = sizeof(nas_557C_req->t11);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                              &msg_size,
                                              NAS_557C_REQ_T11,
                                              tlv_length,
                                              (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                                          QMI_NAS_SERVICE,
                                                          QMI_NAS_SET_NETWORK_MODE_MSG_ID,
                                                          QMI_SRVC_PDU_PTR(msg),
                                                          QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                                          msg,                 
                                                          &msg_size,
                                                          QMI_EAP_STD_MSG_SIZE,
                                                          QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                                          qmi_err_code);

  return rc;
}


/*===========================================================================
  FUNCTION  qmi_nas_get_operator
===========================================================================*/
/*!
@brief 
  Returns a list of HOME network providers.
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_operator
(
  int                               client_handle,
  nas_0025_rsp_s                    *nas_0025_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_0025_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                                          QMI_NAS_SERVICE,
                                                          QMI_NAS_GET_HOME_NETWORK_MSG_ID,
                                                          QMI_SRVC_PDU_PTR(msg),
                                                          QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                                          msg,                 
                                                          &msg_size,
                                                          QMI_EAP_STD_MSG_SIZE,
                                                          QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                                          qmi_err_code);

  if (rc == QMI_NO_ERR)
  {
    if (qmi_nas_get_operator_info (msg,msg_size,nas_0025_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_pref_network: qmi_nas_get_pref_network_info returned error");
      rc = QMI_INTERNAL_ERR;
    }
  }
  return rc;
}


/*===========================================================================
  FUNCTION  qmi_nas_initiate_ps_attach_detach
===========================================================================*/
/*!
@brief 
  This function is used to initiate a PS domain attach or detach.
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Attach or Detach is initiated
*/    
/*=========================================================================*/
int
qmi_nas_initiate_ps_attach_detach
(
  int                         client_handle,
  qmi_nas_ps_attach_state     attach_detach,
  int                         *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc;

  /* Do a bit of error checking first */
  if((attach_detach != QMI_NAS_PS_ATTACH) &&
     (attach_detach != QMI_NAS_PS_DETACH))
      {
        return QMI_INTERNAL_ERR;
      }

  /*Prepare the Request Message*/
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);

  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);


  /* Add the attach/detach action TLV */
  if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                  &msg_size,
                                  QMI_NAS_PS_ATTACH_ACTION_TLV_ID,
                                  1,
                                  (void *)&attach_detach) < 0)
            {
    return QMI_INTERNAL_ERR;
  }


  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_INIT_PS_ATTACH_DETACH_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;     
}


 
/*===========================================================================
  FUNCTION  qmi_nas_indication_register
===========================================================================*/
/*!
@brief 
  Set the NAS indication registration state for specified control point.
     
  
@return 

@note

  - Dependencies
    - qmi_qos_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_indication_register
(
  int                                     client_handle,
  nas_0003_req_s                         *nas_0003_req,
  int                                    *qmi_err_code
)
{
  unsigned char     msg[QMI_NAS_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;
 
  if(!nas_0003_req)
  {
    return QMI_INTERNAL_ERR;
  }
  
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_NAS_STD_MSG_SIZE);

  /* Write system selection preference TLV if appropriate */
  if(nas_0003_req->t10_valid)
  {
    val_ptr = (unsigned char*)&nas_0003_req->t10;
    tlv_length = sizeof(nas_0003_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0003_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_0003_req->t12_valid)
  {
    val_ptr = (unsigned char*)&nas_0003_req->t12;
    tlv_length = sizeof(nas_0003_req->t12);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0003_REQ_T12,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_0003_req->t13_valid)
  {
    val_ptr = (unsigned char*)&nas_0003_req->t13;
    tlv_length = sizeof(nas_0003_req->t13);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0003_REQ_T13,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }    

  if(nas_0003_req->t14_valid)
  {
    val_ptr = (unsigned char*)&nas_0003_req->t14;
    tlv_length = sizeof(nas_0003_req->t14);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0003_REQ_T14,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_0003_req->t15_valid)
  {
    val_ptr = (unsigned char*)&nas_0003_req->t15;
    tlv_length = sizeof(nas_0003_req->t15);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0003_REQ_T15,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }

  if(nas_0003_req->t16_valid)
  {
    val_ptr = (unsigned char*)&nas_0003_req->t16;
    tlv_length = sizeof(nas_0003_req->t16);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0003_REQ_T16,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }    

  if(nas_0003_req->t17_valid)
  {
    val_ptr = (unsigned char*)&nas_0003_req->t17;
    tlv_length = sizeof(nas_0003_req->t17);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0003_REQ_T17,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }  

  if(nas_0003_req->t18_valid)
  {
    val_ptr = (unsigned char*)&nas_0003_req->t18;
    tlv_length = sizeof(nas_0003_req->t18);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0003_REQ_T18,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_0003_req->t19_valid)
  {
    val_ptr = (unsigned char*)&nas_0003_req->t19;
    tlv_length = sizeof(nas_0003_req->t19);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0003_REQ_T19,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }    

  if(nas_0003_req->t1A_valid)
  {
    val_ptr = (unsigned char*)&nas_0003_req->t1A;
    tlv_length = sizeof(nas_0003_req->t1A);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0003_REQ_T1A,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }    

  if(nas_0003_req->t1B_valid)
  {
    val_ptr = (unsigned char*)&nas_0003_req->t1B;
    tlv_length = sizeof(nas_0003_req->t1B);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0003_REQ_T1B,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_0003_req->t1C_valid)
  {
    val_ptr = (unsigned char*)&nas_0003_req->t1C;
    tlv_length = sizeof(nas_0003_req->t1C);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0003_REQ_T1C,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }  

  if(nas_0003_req->t1D_valid)
  {
    val_ptr = (unsigned char*)&nas_0003_req->t1D;
    tlv_length = sizeof(nas_0003_req->t1D);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0003_REQ_T1D,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }    

  if(nas_0003_req->t1E_valid)
  {
    val_ptr = (unsigned char*)&nas_0003_req->t1E;
    tlv_length = sizeof(nas_0003_req->t1E);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0003_REQ_T1E,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }

  if(nas_0003_req->t1F_valid)
  {
    val_ptr = (unsigned char*)&nas_0003_req->t1F;
    tlv_length = sizeof(nas_0003_req->t1F);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0003_REQ_T1F,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_0003_req->t20_valid)
  {
    val_ptr = (unsigned char*)&nas_0003_req->t20;
    tlv_length = sizeof(nas_0003_req->t20);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0003_REQ_T20,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }  

  if(nas_0003_req->t21_valid)
  {
    val_ptr = (unsigned char*)&nas_0003_req->t21;
    tlv_length = sizeof(nas_0003_req->t21);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0003_REQ_T21,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }

  if(nas_0003_req->t22_valid)
  {
    val_ptr = (unsigned char*)&nas_0003_req->t22;
    tlv_length = sizeof(nas_0003_req->t22);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0003_REQ_T22,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_0003_req->t23_valid)
  {
    val_ptr = (unsigned char*)&nas_0003_req->t23;
    tlv_length = sizeof(nas_0003_req->t23);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0003_REQ_T23,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }  

  if(nas_0003_req->t24_valid)
  {
    val_ptr = (unsigned char*)&nas_0003_req->t24;
    tlv_length = sizeof(nas_0003_req->t24);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0003_REQ_T24,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }   
  
  
  /* Synchronously send message to modem processor */
  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_INDICATION_REGISTER_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_NAS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_NAS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
} /* qmi_nas_indication_register */


/*===========================================================================
  FUNCTION  qmi_nas_get_sys_info
===========================================================================*/
/*!
@brief 
  Queries information regarding the system that currently provides service.
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_get_sys_info
(
  int                               client_handle,
  nas_004D_rsp_s                    *nas_004D_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_004D_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                                          QMI_NAS_SERVICE,
                                                          QMI_NAS_GET_SYS_INFO_MSG_ID,
                                                          QMI_SRVC_PDU_PTR(msg),
                                                          QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                                          msg,                 
                                                          &msg_size,
                                                          QMI_EAP_STD_MSG_SIZE,
                                                          QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                                          qmi_err_code);

  if (rc == QMI_NO_ERR)
  {
    if (qmi_nas_get_sys_info_rsp(msg,msg_size,nas_004D_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_serving_system: qmi_nas_get_serving_system_info returned error");
      rc = QMI_INTERNAL_ERR;
    }
  }

  return rc;     
}

/*===========================================================================
  FUNCTION  qmi_nas_config_sig_info_req
===========================================================================*/
/*!
@brief 
  Sets the signal strength reporting thresholds. (Deprecated)
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_config_sig_info_req
(
  int                               client_handle,
  nas_0050_req_s                    *nas_0050_req, 
  int                               *qmi_err_code
)
{
  unsigned char msg[QMI_EAP_STD_MSG_SIZE];
  unsigned char	*tmp_msg_ptr;
  int           msg_size=0, rc=0, tlv_length = 0;

  if(!nas_0050_req)
  {
    return QMI_INTERNAL_ERR;
  }

  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                                          QMI_NAS_SERVICE,
                                                          QMI_NAS_GET_SYS_INFO_MSG_ID,
                                                          QMI_SRVC_PDU_PTR(msg),
                                                          QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                                          msg,                 
                                                          &msg_size,
                                                          QMI_EAP_STD_MSG_SIZE,
                                                          QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                                          qmi_err_code);
  return rc;     
}

/*===========================================================================
  FUNCTION  qmi_nas_get_protocol_info
===========================================================================*/
/*!
@brief 
  Get the Protocol Information of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_protocol_info
(
  int                               client_handle,
  nas_5556_rsp_s             *nas_5556_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_5556_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_PROTOCOL_INFO_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);


  if (rc == QMI_NO_ERR)
  {

    if (qmi_nas_get_lte_protocol_info (msg,msg_size,nas_5556_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_pref_network: qmi_nas_get_protocol_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

/*===========================================================================
  FUNCTION  qmi_nas_set_protocol_info
===========================================================================*/
/*!
@brief 
    Sets the list of protocol information
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_protocol_info
(
  int                               client_handle,
  nas_5557_req_s             *nas_5557_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_5557_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(nas_5557_req->t10_valid)
  {
    val_ptr = (unsigned char*)&nas_5557_req->t10;
    tlv_length = sizeof(nas_5557_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_5557_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_5557_req->t11_valid)
  {
    val_ptr = (unsigned char*)&nas_5557_req->t11;
    tlv_length = sizeof(nas_5557_req->t11);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_5557_REQ_T11,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_5557_req->t12_valid)
  {
    val_ptr = (unsigned char*)&nas_5557_req->t12;
    tlv_length = sizeof(nas_5557_req->t12);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_5557_REQ_T12,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_5557_req->t13_valid)
  {
    val_ptr = (unsigned char*)&nas_5557_req->t13;
    tlv_length = sizeof(nas_5557_req->t13);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_5557_REQ_T13,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_5557_req->t14_valid)
  {
    val_ptr = (unsigned char*)&nas_5557_req->t14;
    tlv_length = sizeof(nas_5557_req->t14);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_5557_REQ_T14,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_5557_req->t15_valid)
  {
    val_ptr = (unsigned char*)&nas_5557_req->t15;
    tlv_length = sizeof(nas_5557_req->t15);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_5557_REQ_T15,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }

  if(nas_5557_req->t16_valid)
  {
    val_ptr = (unsigned char*)&nas_5557_req->t16;
    tlv_length = sizeof(nas_5557_req->t16);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_5557_REQ_T16,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }

  if(nas_5557_req->t17_valid)
  {
    val_ptr = (unsigned char*)&nas_5557_req->t17;
    tlv_length = sizeof(nas_5557_req->t17);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_5557_REQ_T17,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }

  if(nas_5557_req->t18_valid)
  {
    val_ptr = (unsigned char*)&nas_5557_req->t18;
    tlv_length = sizeof(nas_5557_req->t18);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_5557_REQ_T18,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }
  
  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_PROTOCOL_INFO_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}

//20170215 yjoh add for cell info
int
qmi_nas_get_cell_info
(
  int                              											 client_handle,
  nas_get_cell_location_info_resp_msg_v01 			*cell_info_rsp, 
  int                               											*qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!cell_info_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_CELL_LOCATION_INFO_INFO_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);


  if (rc == QMI_NO_ERR)
  {

    if (qmi_nas_get_location_cell_info (msg,msg_size,cell_info_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_pref_network: qmi_nas_get_protocol_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

/*===========================================================================
  FUNCTION  qmi_nas_get_ims_enable
===========================================================================*/
/*!
@brief 
  Get the IMS enable Information of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_ims_enable
(
  int                               client_handle,
  nas_555E_rsp_s             *nas_555E_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_555E_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_IMS_ENABLE_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_nas_get_ims_enable_info (msg,msg_size,nas_555E_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_ims_enable: qmi_nas_get_ims_enable_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}


/////===================
//// network  search functions
//// 
static void qmi_nas_netscan_async_cb( int					user_handle,
											  qmi_service_id_type   service_id,
											  void*					user_data );


void qmi_nas_rsp_read_tlv( int             qmi_err_code,
                                    int             msg_id,
                                    unsigned char*  msg,
                                    int             msg_size,
                                    void*           rsp );


typedef void (*qmi_nas_user_async_cb_type)( int					user_handle,
											  qmi_service_id_type   service_id,
											  void*					user_data );







void qmi_nas_rsp_read_tlv( int             qmi_err_code,
                                    int             msg_id,
                                    unsigned char*  msg,
                                    int             msg_size,
                                    void*           rsp )
{
	int i,j ;
	
	unsigned long type;
	unsigned long length;
	unsigned char *value;
	
	unsigned char temp_8bit;
	unsigned short temp_16bit;
	unsigned char temp_var[ 1024 ];

	int netinfo_desc_len=0;

	
	qmi_response_type_v01* qmi_rsp = (qmi_response_type_v01*)rsp;
	
	if ( QMI_SERVICE_ERR_NONE == qmi_err_code )
	{
	  qmi_rsp->result = (qmi_result_type_v01)QMI_RESULT_SUCCESS_V01;
	}
	else
	{
	  qmi_rsp->error  = (qmi_error_type_v01)qmi_err_code;
	  qmi_rsp->result = (qmi_result_type_v01)QMI_RESULT_FAILURE_V01;
	
	  return QMI_SERVICE_ERR;
	}
	
	while ( msg_size > 0 )
	  {
	    if ( qmi_util_read_std_tlv( &msg,
	                                &msg_size,
	                                &type,
	                                &length,
	                                &value ) < 0 )
	    {
	      return QMI_INTERNAL_ERR;
	    }

	    switch( msg_id )
	    {
	          case QMI_NAS_PERFORM_NETWORK_SCAN_REQ_MSG_V01:
		      {
			  	MSG_HIGH("qmi_nas_rsp_read_tlv() QMI_NAS_PERFORM_NETWORK_SCAN_REQ_MSG_V01 type:%d", type, 0, 0);
				nas_perform_network_scan_resp_msg_v01* nas_net_scan_rsp = (nas_perform_network_scan_resp_msg_v01*)rsp;
				switch(type)/*of QMI_NAS_PERFORM_NETWORK_SCAN_REQ_MSG_V01 */
				  {
					case 16: /*  3GPP Network Information** */
						MSG_HIGH("qmi_nas_rsp_read_tlv() QMI_NAS_PERFORM_NETWORK_SCAN_REQ_MSG_V01 - 3GPP Network Information", 0, 0, 0);
						nas_net_scan_rsp->nas_3gpp_network_info_valid = TRUE;
						READ_16_BIT_VAL( value, temp_16bit );		nas_net_scan_rsp->nas_3gpp_network_info_len = temp_16bit;
						for ( i = 0; i < (nas_net_scan_rsp->nas_3gpp_network_info_len); i++ )
						{
						  READ_16_BIT_VAL( value, temp_16bit );    nas_net_scan_rsp->nas_3gpp_network_info[ i ].mobile_country_code = temp_16bit;
						  READ_16_BIT_VAL( value, temp_16bit );    nas_net_scan_rsp->nas_3gpp_network_info[ i ].mobile_network_code = temp_16bit;					  
						  READ_8_BIT_VAL( value, temp_8bit );    nas_net_scan_rsp->nas_3gpp_network_info[ i ].network_status = temp_8bit;
						  READ_8_BIT_VAL( value, temp_8bit );	 netinfo_desc_len = temp_8bit;
						  for(j = 0; j<netinfo_desc_len ; j++)
						  {
						  	READ_8_BIT_VAL( value, temp_8bit ); 
							nas_net_scan_rsp->nas_3gpp_network_info[ i ].network_description[j] = temp_8bit;
						  }
						  MSG_HIGH("qmi_nas_rsp_read_tlv() result MCC %d MNC %d status %d", 
						  	nas_net_scan_rsp->nas_3gpp_network_info[ i ].mobile_country_code,
						  	nas_net_scan_rsp->nas_3gpp_network_info[ i ].mobile_network_code,
						  	nas_net_scan_rsp->nas_3gpp_network_info[ i ].network_status);						  
						  /*
						  printf(" [%d] result %d %d - status %d - %s\n", 
						    i, 
						  	nas_net_scan_rsp->nas_3gpp_network_info[ i ].mobile_country_code,
						  	nas_net_scan_rsp->nas_3gpp_network_info[ i ].mobile_network_code,
						  	nas_net_scan_rsp->nas_3gpp_network_info[ i ].network_status,
						  	 nas_net_scan_rsp->nas_3gpp_network_info[ i ].network_description
						  );
						  */
						}						
						break;
						
					case 17: /*  Network Radio Access Technology** */
						MSG_HIGH("qmi_nas_rsp_read_tlv() QMI_NAS_PERFORM_NETWORK_SCAN_REQ_MSG_V01 - Network Radio Access Technology", 0, 0, 0);						
						nas_net_scan_rsp->nas_network_radio_access_technology_valid = TRUE;
						READ_16_BIT_VAL( value, temp_16bit );		nas_net_scan_rsp->nas_network_radio_access_technology_len = temp_16bit;
						for ( i = 0; i < (nas_net_scan_rsp->nas_network_radio_access_technology_len); i++ )
						{
						  READ_16_BIT_VAL( value, temp_16bit );    nas_net_scan_rsp->nas_network_radio_access_technology[ i ].mcc = (uint16_t)temp_16bit;
						  READ_16_BIT_VAL( value, temp_16bit );    nas_net_scan_rsp->nas_network_radio_access_technology[ i ].mnc = (uint16_t)temp_16bit;
						  READ_8_BIT_VAL( value, temp_8bit );    nas_net_scan_rsp->nas_network_radio_access_technology[ i ].rat = (uint8_t)temp_8bit;
						   MSG_HIGH("qmi_nas_rsp_read_tlv() result MCC %d MNC %d rat %d", 
						   	nas_net_scan_rsp->nas_network_radio_access_technology[ i ].mcc,
						  	nas_net_scan_rsp->nas_network_radio_access_technology[ i ].mnc,
						  	nas_net_scan_rsp->nas_network_radio_access_technology[ i ].rat
						  	);	
						 /*
						  printf(" [%d] result %d %d - rat %d\n",
						  	i,
						  	nas_net_scan_rsp->nas_network_radio_access_technology[ i ].mcc,
						  	nas_net_scan_rsp->nas_network_radio_access_technology[ i ].mnc,
						  	nas_net_scan_rsp->nas_network_radio_access_technology[ i ].rat
						  	);						  
						  */
						}						
						break;
						
					case 18: /*  MNC PCS Digit Include Status */
						//printf("read 18 MNC PCS Digit Include Status \n");
						break;
						
					case 19: /*  Network Scan Result */
						MSG_HIGH("qmi_nas_rsp_read_tlv() QMI_NAS_PERFORM_NETWORK_SCAN_REQ_MSG_V01 - Network Scan Result", 0, 0, 0);
						nas_net_scan_rsp->scan_result_valid = TRUE;
						READ_8_BIT_VAL( value, temp_8bit );    	nas_net_scan_rsp->scan_result = temp_8bit;
						printf("[scan result] %d (0:SUCCESS, 1:ABORT, 2:REJ)\n", nas_net_scan_rsp->scan_result);
						MSG_HIGH("qmi_nas_rsp_read_tlv() scan result %d", nas_net_scan_rsp->scan_result, 0, 0 );						
						break;
						
					case 22: /*  Network Name Source */
						//printf("read 2 Network Name Source \n");
						break;	
						
				  }
		      }
		      break;
	    } //switch( msg_id )
	  }//while msg_size > 0
	  
  return QMI_NO_ERR;

}

static void	qmi_nas_srvc_async_cb( int                    user_handle,
									 qmi_service_id_type    service_id,
									 unsigned long          msg_id,
									 int                    rsp_rc,
									 int                    qmi_err_code,
									 unsigned char*			reply_msg_data,
									 int					reply_msg_size,
									 void*					srvc_async_cb_data,
									 void*					user_async_cb_fn,
									 void*					user_async_cb_data )
{
	void* rsp = NULL;
	MSG_HIGH("qmi_nas_srvc_async_cb()  msg_id %d(0x%x)", msg_id, msg_id, 0 );
	MSG_HIGH("qmi_nas_srvc_async_cb() qmi_err_code %d, reply_msg_size %d", qmi_err_code, reply_msg_size, 0);

	/* qmi response object*/
	nas_perform_network_scan_resp_msg_v01 nas_net_scan_rsp;

	memset( &nas_net_scan_rsp, 0x0, sizeof( nas_net_scan_rsp ) );	


	switch(msg_id)
	{
	  case QMI_NAS_PERFORM_NETWORK_SCAN_REQ_MSG_V01: 	rsp = &nas_net_scan_rsp;  break;
	  
	}//switch


	qmi_nas_rsp_read_tlv( qmi_err_code, msg_id, reply_msg_data, reply_msg_size, rsp );

	
	//after process .. send tof event with rsp
	switch(msg_id)
	{
	  case QMI_NAS_PERFORM_NETWORK_SCAN_REQ_MSG_V01: 
		qmi_nas_netscan_async_cb(user_handle, service_id, rsp);
		break;
	
	}//switch

}

static TOF_nas_available_networks tofnetinfo;

static void qmi_nas_netscan_async_cb( int					user_handle,
											  qmi_service_id_type   service_id,
											  void*					user_data )
{
	printf("qmi_nas_netscan_async_cb()\n");
	nas_perform_network_scan_resp_msg_v01* nas_net_scan_rsp = (nas_perform_network_scan_resp_msg_v01*)user_data;
	TOF_nas_available_networks tofnetinfo;
	int i;	

	//scan result
	if (nas_net_scan_rsp->scan_result_valid == TRUE)
	{
	   	tofnetinfo.scan_result = nas_net_scan_rsp->scan_result ;
	}

	if(nas_net_scan_rsp->nas_3gpp_network_info_valid == TRUE)
	{
		tofnetinfo.num_of_networks = nas_net_scan_rsp->nas_3gpp_network_info_len;
		
		for(i=0 ; i< nas_net_scan_rsp->nas_3gpp_network_info_len; i++)
		{
			tofnetinfo.networks[ i ].mobile_country_code  = nas_net_scan_rsp->nas_3gpp_network_info[i].mobile_country_code;
			tofnetinfo.networks[ i ].mobile_network_code  = nas_net_scan_rsp->nas_3gpp_network_info[i].mobile_network_code;
			tofnetinfo.networks[ i ].in_use_status = 
				nas_net_scan_rsp->nas_3gpp_network_info[i].network_status & 0x03;
			tofnetinfo.networks[ i ].roaming_status = 
				(nas_net_scan_rsp->nas_3gpp_network_info[i].network_status >> 2) & 0x03;
			tofnetinfo.networks[ i ].forbidden_status = 
				(nas_net_scan_rsp->nas_3gpp_network_info[i].network_status >> 4) & 0x03;			
			tofnetinfo.networks[ i ].preferred_status = 
				(nas_net_scan_rsp->nas_3gpp_network_info[i].network_status >> 6) & 0x03;
			
			strcpy(tofnetinfo.networks[ i ].network_description, nas_net_scan_rsp->nas_3gpp_network_info[i].network_description);
			tofnetinfo.networks[ i ].network_description[24] = '\0';//last word clear, if lost..

			if(nas_net_scan_rsp->nas_network_radio_access_technology_valid == TRUE)
			{
				tofnetinfo.networks[ i ].rat = nas_net_scan_rsp->nas_network_radio_access_technology[i].rat;
			}
		}//for			
	}//if

	EventNotifyEnqueue(TOF_EVENT_RESPONSE_ASYNC_NETWORK_SEARCH_FINISHED, 0, &tofnetinfo);
	
}

//static char user_datas_cb[1000] = {0,};

static int	qmi_nas_req_write_tlv( int				msg_id,
									 unsigned char**	msg,
									 int*				msg_size,
									 void*				req )
{
	unsigned char	temp_8bit;
	uint32_t temp_32bit;
	
	switch ( msg_id )
	{
		case QMI_NAS_PERFORM_NETWORK_SCAN_REQ_MSG_V01:
		{			 
			//printf("tlv write len:%d\n", sizeof( nas_perform_network_scan_req_msg_v01 ));
			if ( qmi_util_write_std_tlv( msg,
										 msg_size,
										 QMI_NAS_PERFORM_NETWORK_SCAN_REQ_MSG_V01,
										 sizeof( nas_perform_network_scan_req_msg_v01 ),
										 (void*)req ) < 0 )										 
			{
				MSG_HIGH("qmi_nas_req_write_tlv() tlv write FAILED!!!!!", 0, 0, 0);					
				return QMI_INTERNAL_ERR;
			}
		}
		break;
	}
  return QMI_NO_ERR;
}

int
	qmi_nas_query_available_networks
(
  int                               client_handle,
  int                               *qmi_err_code
)
{
  //printf("qmi_nas_query_available_networks()\n");
  MSG_HIGH("[NAS] qmi_nas_query_available_networks()", 0, 0, 0);
  qmi_client_error_type qmi_error		= QMI_NO_ERR;
  qmi_err_code = QMI_SERVICE_ERR_NONE;

  unsigned char   msg[ QMI_EAP_STD_MSG_SIZE ];
  int			  msg_size = 0;
  unsigned char*  tmp_msg_ptr;
	

  /*Prepare the Request Message*/
  tmp_msg_ptr = QMI_SRVC_PDU_PTR( msg );
  msg_size	  = QMI_SRVC_PDU_SIZE( QMI_EAP_STD_MSG_SIZE );


  //set scan param
  //qmi_nas_user_async_cb_type  user_cb = qmi_nas_netscan_async_cb;
  //void* user_data=NULL;  
  
  nas_perform_network_scan_req_msg_v01 req_data;
  memset(&req_data, 0, sizeof(req_data));
  req_data.network_type_valid = 1;
  req_data.network_type = 0x07; /*  GWL:0x07 */

  if ( qmi_nas_req_write_tlv( QMI_NAS_PERFORM_NETWORK_SCAN_REQ_MSG_V01, &tmp_msg_ptr, &msg_size, &req_data ) < 0 )
  {
	printf( "[NAS] qmi_nas_query_available_networks(), write tlv error:QMI_INTERNAL_ERR\n");
	MSG_HIGH("[NAS} qmi_nas_query_available_networks(),write tlv error:QMI_INTERNAL_ERR\n", 0, 0, 0);
	return QMI_INTERNAL_ERR;
  }
		

	qmi_error = qmi_service_send_msg_async( client_handle,
										QMI_NAS_SERVICE,
										QMI_NAS_PERFORM_NETWORK_SCAN_REQ_MSG_V01,
										QMI_SRVC_PDU_PTR( msg ),
										(int)QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
										qmi_nas_srvc_async_cb, /*called by modem*/
										NULL,
										/*(void *)user_cb*/ NULL,
										/*user_datas_cb*/ NULL);

	if ( qmi_error >= 0 ) //index returned when async message
	{		
	    printf("[NAS] qmi_nas_query_available_networks() QMI_NO_ERR\n");
		QMI_DEBUG_MSG_1("[NAS] qmi_nas_query_available_networks() QMI_NO_ERR\n",0);
		qmi_error = QMI_NO_ERR;
	}
	else
	{
	    printf("[jaeyong1.park] qmi_client_send_msg_async () is error return : %d\n", qmi_error);
		QMI_DEBUG_MSG_1("[jaeyong1.park] qmi_client_send_msg_async () is error return : %d", qmi_error);
	}
/*
#define QMI_NO_ERR                  0
#define QMI_INTERNAL_ERR            (-1)
#define QMI_SERVICE_ERR             (-2)
#define QMI_TIMEOUT_ERR             (-3)
#define QMI_EXTENDED_ERR            (-4)
#define QMI_PORT_NOT_OPEN_ERR       (-5)
#define QMI_MEMCOPY_ERROR           (-13)
#define QMI_INVALID_TXN             (-14)
#define QMI_CLIENT_ALLOC_FAILURE    (-15)
#define QMI_CLIENT_TRANSPORT_ERR    (-16)
#define QMI_CLIENT_PARAM_ERR        (-17)
#define QMI_CLIENT_INVALID_CLNT     (-18)
#define QMI_CLIENT_FW_NOT_UP        (-19)
#define QMI_CLIENT_INVALID_SIG      (-20)
#define QMI_XPORT_BUSY_ERR          (-21)
*/ 
  return qmi_error;
  
}



/*===========================================================================
  FUNCTION  qmi_nas_get_ecall_enable
===========================================================================*/
/*!
@brief 
  Get the Modem Setting Value
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
//jaeyong1.park
int
	qmi_nas_get_ecall_enable
(
  int                               client_handle,
  nas_ECALLEN_rsp_s             *nas_ECALLEN_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_ECALLEN_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  /// SET req number  jaeyong1.park [start]
  unsigned char *tmp_msg_ptr;
  int            tlv_length = 0;  
  unsigned char     *val_ptr;  

  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);


//  if(nas_ecallen_req->t1_valid)
//  {
    val_ptr = (unsigned char*)&nas_ECALLEN_rsp->t10;
    tlv_length = sizeof(nas_ECALLEN_rsp->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                GET_ECALL_ENABLE,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
//  } 

  /// SET req jaeyong1.park [end]

  //wait modem response
  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_ECALL_ENABLE_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);



	if (rc == QMI_NO_ERR)
	{

		if (qmi_nas_get_ecall_enable_info(msg,msg_size,nas_ECALLEN_rsp) < 0)
		{
		QMI_ERR_MSG_0 ("qmi_nas_get_ecall_enable_info: qmi_nas_get_ecall_enable_info returned error");
		rc = QMI_INTERNAL_ERR;
		} 

	}
 return rc;	  

}


/*===========================================================================
  FUNCTION  qmi_nas_get_ecall_enable
===========================================================================*/
/*!
@brief 
  Get the Modem Setting Value
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
//jaeyong1.park
int
	qmi_nas_get_modem_value
(
  int                               client_handle,
  nas_GETVAL_rsp_s             *nas_GETVAL_rsp,
  int                               *qmi_err_code,
  int getvalcmd
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_GETVAL_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  /// SET getval cmd number  jaeyong1.park [start]
  unsigned char *tmp_msg_ptr;
  int            tlv_length = 0;  
  unsigned char     *val_ptr;  

  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);

  val_ptr = (unsigned char*)&nas_GETVAL_rsp->t1;
  tlv_length = sizeof(nas_GETVAL_rsp->t1);
  
  //make message
  if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                getvalcmd, /* GETVAL_CMD, int  */
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

  //send & wait modem response
  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_MODEM_VALUE_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);



	//after modem response..
	if (rc == QMI_NO_ERR)
	{
		if (qmi_nas_get_modem_returned_value(msg,msg_size,nas_GETVAL_rsp) < 0)
		{
			QMI_ERR_MSG_0 ("qmi_nas_get_modem_value: qmi_nas_get_ecall_enable_info returned error");
			rc = QMI_INTERNAL_ERR;
		} 
	}	
	else
	{
		QMI_ERR_MSG_1 ("qmi_nas_get_modem_value: ERROR returned rc=%d", rc);
	}
 return rc;	  

}


/*===========================================================================
  FUNCTION  qmi_nas_set_ims_enable
===========================================================================*/
/*!
@brief 
    Sets the list of IMS enable information
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_ims_enable
(
  int                               client_handle,
  nas_555F_req_s             *nas_555F_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_555F_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(nas_555F_req->t10_valid)
  {
    val_ptr = (unsigned char*)&nas_555F_req->t10;
    tlv_length = sizeof(nas_555F_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_555F_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_IMS_ENABLE_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}

/*===========================================================================
  FUNCTION  qmi_nas_set_ecall_enable
===========================================================================*/
/*!
@brief 
    Set the value for ecall enable     
  
@return 

@author
 jaeyong1.park

 @note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int
qmi_nas_set_ecall_enable
(
  int                               client_handle,
  nas_ecallen_req_s             *nas_ecallen_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_ecallen_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(nas_ecallen_req->t1_valid)
  {
    val_ptr = (unsigned char*)&nas_ecallen_req->t1;
    tlv_length = sizeof(nas_ecallen_req->t1);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_ecallon_REQ_T1,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_ECALL_ENABLE_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}

// 2016-10-11 mwkim, InnoJIRA : AS045-673
/*===========================================================================
  FUNCTION  qmi_nas_enable_ecall_only_mode
===========================================================================*/
/*!
@brief 
    Change the value to enable eCall only mode     

@return 

@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int
qmi_nas_set_ecall_only_mode
(
  int                               client_handle,
  nas_ecallonly_en_req_s            *nas_ecallonly_en_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_ecallonly_en_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(nas_ecallonly_en_req->t1_valid)
  {
    val_ptr = (unsigned char*)&nas_ecallonly_en_req->t1;
    tlv_length = sizeof(nas_ecallonly_en_req->t1);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_ecallonly_en_REQ_T1,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_ENABLE_ECALL_ONLY_MODE_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}

// 2016-10-14 mwkim, InnoJIRA : AS045-671
/*===========================================================================
  FUNCTION  qmi_nas_read_ecall_oper_mode
===========================================================================*/
/*!
@brief 
    Read the value of eCall operation mode     
  
@return 

@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
int
qmi_nas_get_ecall_oper_mode
(
  int                             client_handle,
  nas_7042_rsp_s         				 *nas_7042_rsp,  
  int                            *qmi_err_code
)
{
	unsigned char 		msg[QMI_EAP_STD_MSG_SIZE];
	int 							msg_size, rc;
	
	if(!nas_7042_rsp)
	{
		return QMI_INTERNAL_ERR;
	}
	
	/*Prepare the Request Message*/
	msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_ECALL_OPER_MODE_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  (int)QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);
	
  if (rc == QMI_NO_ERR)
  {
    if (qmi_nas_get_returned_ecall_oper_mode (msg,msg_size,nas_7042_rsp) < 0)			
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_ims_enable: qmi_nas_get_ims_enable_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
	else
	{
		QMI_DEBUG_MSG_1("ERR CODE : %d", rc);
	}
	
  return rc;
	
}

/*===========================================================================
  FUNCTION  qmi_nas_set_ecall_number
===========================================================================*/
/*!
@brief 
    Set the value for ecall enable     
  
@return 

@author
 jaeyong1.park

 @note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/

int
qmi_nas_set_ecall_number
(
  int                               client_handle,
  nas_ecallnumber_req_s             *nas_ecallnumber_req,
  int                               *qmi_err_code
)
{
  MSG_HIGH_4 ("qmi_nas_set_ecall_number()",0,0,0,0);
		  

  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_ecallnumber_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  // Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  // message buffer
  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(nas_ecallnumber_req->t1_valid)
  {
    val_ptr = (unsigned char*)&nas_ecallnumber_req->t1;
    tlv_length = sizeof(nas_ecallnumber_req->t1);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_ecallnumber_REQ_T1,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_ECALL_NUMBER_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}



/*===========================================================================
  FUNCTION  qmi_nas_set_ecall_configfile
===========================================================================*/
/*!
@brief 
    Set the value for ecall config file
  
@return 

@author
 jaeyong1.park

 @note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/


int
	qmi_nas_set_ecall_configfile
(
  int                               client_handle,
  nas_ecallnumber_req_s             *nas_ecallconfig_req,
  int                               *qmi_err_code
)
{
  MSG_HIGH_4 ("qmi_nas_set_ecall_configfile()",0,0,0,0);
		  

  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_ecallconfig_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  // Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  // message buffer
  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  //t1
  if(nas_ecallconfig_req->t1_valid)
  {
    val_ptr = (unsigned char*)&nas_ecallconfig_req->t1;
    tlv_length = sizeof(nas_ecallconfig_req->t1);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_ecallnumber_REQ_T1,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  ///t2
	if(nas_ecallconfig_req->t2_valid)
	{
	  val_ptr = (unsigned char*)&nas_ecallconfig_req->t2;
	  tlv_length = sizeof(nas_ecallconfig_req->t2);
	  if (qmi_util_write_std_tlv (&tmp_msg_ptr,
								  &msg_size,
								  NAS_ecallconfig_REQ_T2,
								  tlv_length,
								  (void *)val_ptr) < 0)
	  {
		return QMI_INTERNAL_ERR;
	  }
	} 

  ///t3
	if(nas_ecallconfig_req->t3_valid)
	{
	  val_ptr = (unsigned char*)&nas_ecallconfig_req->t3;
	  tlv_length = sizeof(nas_ecallconfig_req->t3);
	  if (qmi_util_write_std_tlv (&tmp_msg_ptr,
								  &msg_size,
								  NAS_ecallconfig_REQ_T3,
								  tlv_length,
								  (void *)val_ptr) < 0)
	  {
		return QMI_INTERNAL_ERR;
	  }
	} 
	
	///t4
	  if(nas_ecallconfig_req->t4_valid)
	  {
		val_ptr = (unsigned char*)&nas_ecallconfig_req->t4;
		tlv_length = sizeof(nas_ecallconfig_req->t4);
		if (qmi_util_write_std_tlv (&tmp_msg_ptr,
									&msg_size,
									NAS_ecallconfig_REQ_T4,
									tlv_length,
									(void *)val_ptr) < 0)
		{
		  return QMI_INTERNAL_ERR;
		}
	  } 


  ///t5
	if(nas_ecallconfig_req->t5_valid)
	{
	  val_ptr = (unsigned char*)&nas_ecallconfig_req->t5;
	  tlv_length = sizeof(nas_ecallconfig_req->t5);
	  MSG_HIGH ("[jaeyong1] qmi_nas_set_ecall_configfile. reload %d \n",nas_ecallconfig_req->t5.numdata , 0, 0);	  

	  
	  if (qmi_util_write_std_tlv (&tmp_msg_ptr,
								  &msg_size,
								  NAS_ecallconfig_REQ_T5,
								  tlv_length,
								  (void *)val_ptr) < 0)
	  {
		return QMI_INTERNAL_ERR;
	  }
	} 


  ///t6
	if(nas_ecallconfig_req->t6_valid)
	{
	  val_ptr = (unsigned char*)&nas_ecallconfig_req->t6;
	  tlv_length = sizeof(nas_ecallconfig_req->t6);
	  if (qmi_util_write_std_tlv (&tmp_msg_ptr,
								  &msg_size,
								  NAS_ecallconfig_REQ_T6,
								  tlv_length,
								  (void *)val_ptr) < 0)
	  {
		return QMI_INTERNAL_ERR;
	  }
	} 

  QMI_ERR_MSG_0 ("[jaeyong1] before. send to qmi");


  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_ECALL_NUMBER_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}


/*===========================================================================
  FUNCTION  qmi_nas_get_ims_pdn_enable
===========================================================================*/
/*!
@brief 
  Get the IMS PDN enable Information of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_ims_pdn_enable
(
  int                               client_handle,
  nas_5560_rsp_s             *nas_5560_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_5560_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_IMS_PDN_ENABLE_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_nas_get_ims_pdn_enable_info (msg,msg_size,nas_5560_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_ims_pdn_enable: qmi_nas_get_ims_pdn_enable_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

/*===========================================================================
  FUNCTION  qmi_nas_set_ims_pdn_enable
===========================================================================*/
/*!
@brief 
    Sets the list of IMS PDN enable information
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_ims_pdn_enable
(
  int                               client_handle,
  nas_5561_req_s             *nas_5561_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_5561_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(nas_5561_req->t10_valid)
  {
    val_ptr = (unsigned char*)&nas_5561_req->t10;
    tlv_length = sizeof(nas_5561_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_5561_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_IMS_PDN_ENABLE_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_ims_param_config
===========================================================================*/
/*!
@brief 
  Get the IMS Param Config Information of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_ims_user_config
(
  int                               client_handle,
  nas_5565_rsp_s             *nas_5565_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_MAX_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_5565_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_MAX_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_IMS_USER_CONFIG_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_MAX_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_MAX_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_nas_get_ims_user_config_info (msg,msg_size,nas_5565_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_ims_user_config_info : qmi_nas_get_ims_user_config_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

/*===========================================================================
  FUNCTION  qmi_nas_set_ims_param_config
===========================================================================*/
/*!
@brief 
    Sets the list of IMS user Config information
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_ims_user_config
(
  int                               client_handle,
  nas_5566_req_s             *nas_5566_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_MAX_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_5566_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_MAX_MSG_SIZE);

  if(nas_5566_req->t10_valid)
  {
    val_ptr = (unsigned char*)&nas_5566_req->t10;
    if((wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ) || ( wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ))
    {
      tlv_length = sizeof(nas_5566_req->t10);
    }
    else
    {
      tlv_length = strlen((char *)nas_5566_req->t10.regConfigUserName);    
    }
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_5566_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_5566_req->t11_valid)
  {
    val_ptr = (unsigned char*)&nas_5566_req->t11;
    if((wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ) || ( wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ))
    {
      tlv_length = sizeof(nas_5566_req->t11);
    }
    else
    {
      tlv_length = strlen((char *)nas_5566_req->t11.regConfigPassword);    
    }
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_5566_REQ_T11,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }   

  if(nas_5566_req->t12_valid)
  {
    val_ptr = (unsigned char*)&nas_5566_req->t12;
    if((wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ) || ( wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ))
    {
      tlv_length = sizeof(nas_5566_req->t12);
    }
    else
    {
      tlv_length = strlen((char *)nas_5566_req->t12.regConfigPrivateURI);    
    }
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_5566_REQ_T12,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }   

  if(nas_5566_req->t13_valid)
  {
    val_ptr = (unsigned char*)&nas_5566_req->t13;
    if((wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ) || ( wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ))
    {
      tlv_length = sizeof(nas_5566_req->t13);
    }
    else
    {
      tlv_length = strlen((char *)nas_5566_req->t13.regConfigDomainName);    
    }
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_5566_REQ_T13,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }   

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_IMS_USER_CONFIG_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_MAX_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_MAX_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_ims_rcs_auto_config
===========================================================================*/
/*!
@brief 
  Get the IMS RCS Auto Config Information of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_ims_rcs_auto_config
(
  int                               client_handle,
  nas_556B_rsp_s             *nas_556B_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_556B_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_IMS_RCS_AUTO_CONFIG_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_nas_get_ims_rcs_auto_config_info (msg,msg_size,nas_556B_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_ims_rcs_auto_config_info : qmi_nas_get_ims_rcs_auto_config_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

/*===========================================================================
  FUNCTION  qmi_nas_set_ims_rcs_auto_config
===========================================================================*/
/*!
@brief 
    Sets the list of IMS RCS Auto Config information
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_ims_rcs_auto_config
(
  int                               client_handle,
  nas_556C_req_s             *nas_556C_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_556C_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(nas_556C_req->t10_valid)
  {
    val_ptr = (unsigned char*)&nas_556C_req->t10;
    tlv_length = sizeof(nas_556C_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_556C_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(nas_556C_req->t11_valid)
  {
    val_ptr = (unsigned char*)&nas_556C_req->t11;
    tlv_length = strlen((char *)nas_556C_req->t11.RCSConfigServerAddress);    
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_556C_REQ_T11,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }   

  if(nas_556C_req->t12_valid)
  {
    val_ptr = (unsigned char*)&nas_556C_req->t12;
    tlv_length = strlen((char *)nas_556C_req->t12.RCSConfigServerPort);    
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_556C_REQ_T12,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_IMS_RCS_AUTO_CONFIG_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_ims_dpl_param
===========================================================================*/
/*!
@brief 
  Get the IMS DPL Param Information of the device
     
@return 

@note

  - Dependencies
    - qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_ims_dpl_param
(
  int                               client_handle,
  nas_556D_rsp_s                    *nas_556D_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_556D_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_IMS_DPL_PARAM_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_nas_get_ims_dpl_param_info (msg,msg_size,nas_556D_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_ims_dpl_param_info : qmi_nas_get_ims_dpl_param_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

/*===========================================================================
  FUNCTION  qmi_nas_set_ims_dpl_param
===========================================================================*/
/*!
@brief 
    Sets the list of IMS DPL Param information
     
  
@return 

@note

  - Dependencies
    - qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_ims_dpl_param
(
  int                               client_handle,
  nas_556E_req_s                    *nas_556E_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_556E_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(nas_556E_req->t10_valid)
  {
    val_ptr = (unsigned char*)&nas_556E_req->t10;
    tlv_length = sizeof(nas_556E_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_556E_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_IMS_DPL_PARAM_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}

//hongsg 20140729
/*===========================================================================
  FUNCTION  qmi_nas_get_ims_qipcall_config
===========================================================================*/
/*!
@brief 
  Get the IMS QIPCALL Config Information of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_ims_qipcall_config
(
  int                               client_handle,
  nas_556F_rsp_s             *nas_556F_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_556F_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_IMS_QIPCALL_CONFIG_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_nas_get_ims_qipcall_config_info (msg,msg_size,nas_556F_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_ims_qipcall_config_info : qmi_nas_get_ims_qipcall_config_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

/*===========================================================================
  FUNCTION  qmi_nas_set_ims_qipcall_config
===========================================================================*/
/*!
@brief 
    Sets the list of IMS QIPCALL Config information
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_ims_qipcall_config
(
  int                               client_handle,
  nas_5570_req_s             *nas_5570_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_5570_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(nas_5570_req->t10_valid)
  {
    val_ptr = (unsigned char*)&nas_5570_req->t10;
    tlv_length = sizeof(nas_5570_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_5570_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_IMS_QIPCALL_CONFIG_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_ims_reg_config
===========================================================================*/
/*!
@brief 
  Get the IMS REG Config Information of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_ims_reg_config
(
  int                               client_handle,
  nas_5571_rsp_s             *nas_5571_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_5571_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_IMS_REG_CONFIG_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_nas_get_ims_reg_config_info (msg,msg_size,nas_5571_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_ims_reg_config_info : qmi_nas_get_ims_reg_config_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

/*===========================================================================
  FUNCTION  qmi_nas_set_ims_reg_config
===========================================================================*/
/*!
@brief 
    Sets the list of IMS Reg Config information
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_ims_reg_config
(
  int                               client_handle,
  nas_5572_req_s             *nas_5572_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_5572_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(nas_5572_req->t10_valid)
  {
    val_ptr = (unsigned char*)&nas_5572_req->t10;
    tlv_length = sizeof(nas_5572_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_5572_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_IMS_REG_CONFIG_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}


/*===========================================================================
  FUNCTION  qmi_nas_get_ims_voip_config
===========================================================================*/
/*!
@brief 
  Get the IMS VOIP Config Information of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_ims_voip_config
(
  int                               client_handle,
  nas_5574_rsp_s             *nas_5574_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_5574_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_IMS_VOIP_CONFIG_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_nas_get_ims_voip_config_info (msg,msg_size,nas_5574_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_ims_reg_config_info : qmi_nas_get_ims_voip_config_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

/*===========================================================================
  FUNCTION  qmi_nas_set_ims_voip_config
===========================================================================*/
/*!
@brief 
    Sets the list of IMS VOIP Config information
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_ims_voip_config
(
  int                               client_handle,
  nas_5575_req_s             *nas_5575_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_5575_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(nas_5575_req->t10_valid)
  {
    val_ptr = (unsigned char*)&nas_5575_req->t10;
    tlv_length = sizeof(nas_5575_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_5575_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_IMS_VOIP_CONFIG_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}


/*===========================================================================
  FUNCTION  qmi_nas_get_network_time_info
===========================================================================*/
/*!
@brief 
  Get the network time info
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_network_time_info
(
  int                               client_handle,
  nas_5558_rsp_s                    *nas_5558_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_5558_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_NETWORK_TIME_INFO_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_nas_get_network_time_info_rsp (msg, msg_size, nas_5558_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_network_time_info_process() returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

/*===========================================================================
  FUNCTION  qmi_nas_get_current_plmn_name_cache
===========================================================================*/
/*!
@brief 
  Get the cache plmn name info
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_current_plmn_name_cache
(
  int                               client_handle,
  nas_5559_rsp_s                    *nas_5559_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_5559_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_CURRENT_PLMN_NAME_CACHE_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {
    if (qmi_nas_get_current_plmn_name_cache_rsp (msg, msg_size, nas_5559_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_current_plmn_name_cache_rsp() returned error");
      rc = QMI_INTERNAL_ERR;
    } 
  }
  return rc;     
}

/*===========================================================================
  FUNCTION  qmi_nas_get_debug_screen_info
===========================================================================*/
/*!
@brief 
  Get the debug screen info
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_debug_screen_info
(
  int                               client_handle,
  nas_555C_rsp_s             *nas_555C_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_555C_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_DEBUG_SCREEN_INFO_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_nas_get_debug_screen_info_rsp (msg, msg_size, nas_555C_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_debug_screen_info_rsp() returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

//BKS_20131107 - start
/*===========================================================================
  FUNCTION  qmi_nas_request_hk_get_cdma_debug_info
===========================================================================*/
/*!
@brief 
  Get the cdma debug screen info
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_request_hk_get_cdma_debug_info
(
  int                               client_handle,
  nas_5562_rsp_s             *nas_5562_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_5562_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_CDMA_DEBUG_SCREEN_INFO_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_nas_request_hk_get_cdma_debug_info_rsp (msg, msg_size, nas_5562_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_request_hk_get_cdma_debug_info_rsp() returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}
//BKS_20131107 - end

/*===========================================================================
  FUNCTION  qmi_nas_delete_stored_cell
===========================================================================*/
/*!
@brief 
  Delete stored cell list information (WCDMA)
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_delete_stored_cell
(
  int                               client_handle,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_DELETE_STORED_CELL_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if(rc != QMI_NO_ERR || *qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[UIM]qmi_nas_delete_stored_cell!! rc: %d err_code : %d",rc,qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
    
  return rc;  
}

/*===========================================================================
  FUNCTION  qmi_nas_map_mode_pref_qmi_to_ril
===========================================================================*/
/*!
@brief 
  Map QMI mode pref to ril
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
uint16
qmi_nas_map_mode_pref_qmi_to_ril
(
  uint16 qmi_val,
  uint32 gw_acq_order_pref,
  uint64 lte_band_pref
)
{
  uint16 preferred_network_type = PREF_NET_TYPE_GSM_WCDMA;

  switch(qmi_val)
  {
    case QMI_NAS_RAT_MODE_PREF_CDMA:
      preferred_network_type = PREF_NET_TYPE_CDMA_ONLY;
      break;
    case QMI_NAS_RAT_MODE_PREF_HRPD:
      preferred_network_type = PREF_NET_TYPE_EVDO_ONLY;
      break;
    case QMI_NAS_RAT_MODE_PREF_CDMA_HRPD:
      preferred_network_type = PREF_NET_TYPE_CDMA_EVDO_AUTO;
      break;
    case QMI_NAS_RAT_MODE_PREF_GSM:
      preferred_network_type = PREF_NET_TYPE_GSM_ONLY;
      break;
    case QMI_NAS_RAT_MODE_PREF_UMTS:
      preferred_network_type = PREF_NET_TYPE_WCDMA;
      break;
    case QMI_NAS_RAT_MODE_PREF_GSM_UMTS:
      preferred_network_type = PREF_NET_TYPE_GSM_WCDMA_AUTO;
      if(gw_acq_order_pref == 0x02)
      {
        preferred_network_type = PREF_NET_TYPE_GSM_WCDMA;
      }
      break;
    case QMI_NAS_RAT_MODE_PREF_GSM_UMTS_CDMA_HRPD:
      preferred_network_type = PREF_NET_TYPE_GSM_WCDMA_CDMA_EVDO_AUTO;
      break;
    case QMI_NAS_RAT_MODE_PREF_LTE:
      preferred_network_type = PREF_NET_TYPE_LTE_ONLY;

      if(lte_band_pref == 4) //band3
        preferred_network_type = PREF_NET_TYPE_LTE_1800;
      else if(lte_band_pref == 16) //band5
        preferred_network_type = PREF_NET_TYPE_LTE_850;
      else if(lte_band_pref == 8) //band4
        preferred_network_type = PREF_NET_TYPE_LTE_BAND4;
      else if(lte_band_pref == 4096) //band13
        preferred_network_type = PREF_NET_TYPE_LTE_BAND13;
      break;      
    case QMI_NAS_RAT_MODE_PREF_CDMA_HRPD_LTE:
      preferred_network_type = PREF_NET_TYPE_LTE_CDMA_EVDO;
      break;
    //W/L mode��  PREF_NET_TYPE_LTE_GSM_WCDMA�� ���ϵǰ� �ӽ÷� ���Ƶ�  else if (pref_net == 0x1C)
    case QMI_NAS_RAT_MODE_PREF_GSM_UMTS_LTE:
      preferred_network_type = PREF_NET_TYPE_LTE_GSM_WCDMA;
      break;
    case QMI_NAS_RAT_MODE_PREF_GSM_UMTS_CDMA_HRPD_LTE:
      preferred_network_type = PREF_NET_TYPE_LTE_CMDA_EVDO_GSM_WCDMA;
      break;
    case QMI_NAS_RAT_MODE_PREF_UMTS_LTE:
      preferred_network_type = PREF_NET_TYPE_LTE_WCDMA;
      break;      
    default:
      preferred_network_type = PREF_NET_TYPE_GSM_WCDMA;
      break;
  }

  return preferred_network_type;
}

/*===========================================================================
  FUNCTION  qmi_nas_map_mode_pref_ril_to_qmi
===========================================================================*/
/*!
@brief 
  Map ril mode pref to QMI
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
uint16
qmi_nas_map_mode_pref_ril_to_qmi
(
  uint16 mode_pref
)
{
  uint16 qmi_val = 0;

  switch(mode_pref)
  {
    case PREF_NET_TYPE_GSM_WCDMA:
    case PREF_NET_TYPE_GSM_WCDMA_AUTO:
      qmi_val = QMI_NAS_RAT_MODE_PREF_GSM_UMTS;
      break;
    case PREF_NET_TYPE_GSM_ONLY:
      qmi_val = QMI_NAS_RAT_MODE_PREF_GSM;
      break;
    case PREF_NET_TYPE_WCDMA:
      qmi_val = QMI_NAS_RAT_MODE_PREF_UMTS;
      break;
    case PREF_NET_TYPE_CDMA_EVDO_AUTO:
      qmi_val = QMI_NAS_RAT_MODE_PREF_CDMA_HRPD;
      break;
    case PREF_NET_TYPE_CDMA_ONLY:
      qmi_val = QMI_NAS_RAT_MODE_PREF_CDMA;
      break;
    case PREF_NET_TYPE_EVDO_ONLY:
      qmi_val = QMI_NAS_RAT_MODE_PREF_HRPD;
      break;
    case PREF_NET_TYPE_GSM_WCDMA_CDMA_EVDO_AUTO:
      qmi_val = QMI_NAS_RAT_MODE_PREF_GSM_UMTS_CDMA_HRPD;
      break;
    case PREF_NET_TYPE_LTE_CDMA_EVDO:
      qmi_val = QMI_NAS_RAT_MODE_PREF_CDMA_HRPD_LTE;
      break;
    case PREF_NET_TYPE_LTE_GSM_WCDMA:
      qmi_val = QMI_NAS_RAT_MODE_PREF_GSM_UMTS_LTE;
      break;
    case PREF_NET_TYPE_LTE_CMDA_EVDO_GSM_WCDMA:
      qmi_val = QMI_NAS_RAT_MODE_PREF_GSM_UMTS_CDMA_HRPD_LTE;
      break;
    case PREF_NET_TYPE_LTE_ONLY:
    case PREF_NET_TYPE_LTE_850:
    case PREF_NET_TYPE_LTE_1800:
    case PREF_NET_TYPE_LTE_BAND4:
    case PREF_NET_TYPE_LTE_BAND13:
      qmi_val = QMI_NAS_RAT_MODE_PREF_LTE;
      break;
    default:
      qmi_val = QMI_NAS_RAT_MODE_PREF_CDMA_HRPD_LTE;
      break;  
  }

  return qmi_val;     
}

/*===========================================================================
  FUNCTION  qmi_nas_request_set_preferred_network_type
===========================================================================*/
/*!
@brief 
    Handles RIL_REQUEST_SET_PREFERRED_NETWORK_TYPE.
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_request_set_preferred_network_type
(
  int                   client_handle,
  nas_0033_req_s        *nas_0033_req,
  int                   *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;
  
  if(!nas_0033_req)
  {
    return QMI_INTERNAL_ERR;
  }
  
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  	  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);
  
  if(nas_0033_req->t11_valid)
  {
    val_ptr = (unsigned char*)&nas_0033_req->t11;
    tlv_length = sizeof(nas_0033_req->t11);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0033_REQ_T11,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }
  
  if(nas_0033_req->t15_valid)
  {
    val_ptr = (unsigned char*)&nas_0033_req->t15;
    tlv_length = sizeof(nas_0033_req->t15);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0033_REQ_T15,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 
  
  if(nas_0033_req->t19_valid)
  {
    val_ptr = (unsigned char*)&nas_0033_req->t19;
    tlv_length = sizeof(nas_0033_req->t19);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0033_REQ_T19,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 
  
  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_SYS_SEL_PREF,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);
  
  return rc;
}

//--> RIL_REQUEST_CDMA_SUBSCRIPTION
/*===========================================================================
  FUNCTION  qmi_nas_get_3gpp2_subscription_info_rsp
===========================================================================*/
/*!
@brief 
  Queries information regarding CDMA subscription information.
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int 
qmi_nas_get_3gpp2_subscription_info_rsp
(
  unsigned char*           rx_buf, 
  int                      rx_buf_len, 
  nas_003E_rsp_s*          nas_003E_rsp
)
{
  unsigned long     type;
  unsigned long     length;
  unsigned char*    value_ptr;
  int               i = 0;

  memset(nas_003E_rsp, 0, sizeof(nas_003E_rsp_s));

  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv(&rx_buf, &rx_buf_len, &type, &length, &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    switch (type)
    {
      case NAS_003E_RSP_NAM_NAME:
      {
        READ_8_BIT_VAL(value_ptr, nas_003E_rsp->t10.nam_name_len);

        for (i = 0; i < nas_003E_rsp->t10.nam_name_len; ++i)
        {
          READ_8_BIT_VAL(value_ptr, nas_003E_rsp->t10.nam_name[i]);
        }

        nas_003E_rsp->t10_valid = TRUE;

        break;
      }

      case NAS_003E_RSP_DIR_NUM:
      {
        READ_8_BIT_VAL(value_ptr, nas_003E_rsp->t11.dir_num_len);

        for (i = 0; i < nas_003E_rsp->t11.dir_num_len; ++i)
        {
          READ_8_BIT_VAL(value_ptr, nas_003E_rsp->t11.dir_num[i]);
        }

        nas_003E_rsp->t11_valid = TRUE;

        break;
      }

      case NAS_003E_RSP_SID_NID:
      {
        READ_8_BIT_VAL(value_ptr, nas_003E_rsp->t12.num_instances);

        for (i = 0; i < nas_003E_rsp->t12.num_instances; ++i)
        {
          READ_16_BIT_VAL(value_ptr, nas_003E_rsp->t12.sid_nid_list[i].sid);
          READ_16_BIT_VAL(value_ptr, nas_003E_rsp->t12.sid_nid_list[i].nid);
        }

        nas_003E_rsp->t12_valid = TRUE;

        break;
      }

      case NAS_003E_RSP_MIN_IMSI:
      {
        for (i = 0; i < NAS_003E_RSP_MCC_LEN; ++i)
        {
          READ_8_BIT_VAL(value_ptr, nas_003E_rsp->t13.mcc_m[i]);
        }

        for (i = 0; i < NAS_003E_RSP_11_12_LEN; ++i)
        {
          READ_8_BIT_VAL(value_ptr, nas_003E_rsp->t13.imsi_m_11_12[i]);
        }

        for (i = 0; i < NAS_003E_RSP_MIN1_LEN; ++i)
        {
          READ_8_BIT_VAL(value_ptr, nas_003E_rsp->t13.imsi_m_s1[i]);
        }

        for (i = 0; i < NAS_003E_RSP_MIN2_LEN; ++i)
        {
          READ_8_BIT_VAL(value_ptr, nas_003E_rsp->t13.imsi_m_s2[i]);
        }

        nas_003E_rsp->t13_valid = TRUE;

        break;
      }

      case NAS_003E_RSP_TRUE_IMSI:
      {
        for (i = 0; i < NAS_003E_RSP_MCC_LEN; ++i)
        {
          READ_8_BIT_VAL(value_ptr, nas_003E_rsp->t14.mcc_t[i]);
        }

        for (i = 0; i < NAS_003E_RSP_11_12_LEN; ++i)
        {
          READ_8_BIT_VAL(value_ptr, nas_003E_rsp->t14.imsi_t_11_12[i]);
        }

        for (i = 0; i < NAS_003E_RSP_MIN1_LEN; ++i)
        {
          READ_8_BIT_VAL(value_ptr, nas_003E_rsp->t14.imsi_t_s1[i]);
        }

        for (i = 0; i < NAS_003E_RSP_MIN2_LEN; ++i)
        {
          READ_8_BIT_VAL(value_ptr, nas_003E_rsp->t14.imsi_t_s2[i]);
        }

        READ_8_BIT_VAL(value_ptr, nas_003E_rsp->t14.imsi_t_addr_num);

        nas_003E_rsp->t14_valid = TRUE;

        break;
      }

      case NAS_003E_RSP_CDMA_CH:
      {
        READ_16_BIT_VAL(value_ptr, nas_003E_rsp->t15.pri_ch_a);

        READ_16_BIT_VAL(value_ptr, nas_003E_rsp->t15.pri_ch_b);

        READ_16_BIT_VAL(value_ptr, nas_003E_rsp->t15.sec_ch_a);

        READ_16_BIT_VAL(value_ptr, nas_003E_rsp->t15.sec_ch_b);

        nas_003E_rsp->t15_valid = TRUE;

        break;
      }

      case NAS_003E_RSP_MDN:
      {
        READ_8_BIT_VAL(value_ptr, nas_003E_rsp->t16.mdn_len);

        for (i = 0; i < nas_003E_rsp->t16.mdn_len; ++i)
        {
          READ_8_BIT_VAL(value_ptr, nas_003E_rsp->t16.mdn[i]);
        }

        nas_003E_rsp->t16_valid = TRUE;

        break;
      }

      case NAS_003E_RSP_PRL_VERSION:
      {
        READ_16_BIT_VAL(value_ptr, nas_003E_rsp->t80.prl_version);

        nas_003E_rsp->t80_valid = TRUE;

        break;
      }

      default:
      {
        QMI_DEBUG_MSG_1 ("qmi_nas_get_3gpp2_subscription_info_rsp(), Unknown TLV ID=%x\n", (unsigned) type);

        break;
      }
    }
  }

  return QMI_NO_ERR;
}

RIL_Errno qmi_nas_get_3gpp2_subscription_info
(
  int                        client_handle, 
  nas_003E_req_s*    nas_003E_req, 
  nas_003E_rsp_s*    nas_003E_rsp, 
  int*                       qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  unsigned char     *val_ptr;
  int               msg_size, rc,tlv_length = 0;
  RIL_Errno         res = RIL_E_GENERIC_FAILURE;

  if(nas_003E_req == NULL)
  {
    return RIL_E_GENERIC_FAILURE;
  }
  
  /* Prepare the request message */
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  val_ptr = (unsigned char*)&nas_003E_req->t01.nam;
  tlv_length = sizeof(nas_003E_req->t01.nam);

  if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                              &msg_size,
                              NAS_003E_REQ_NAM,
                              tlv_length,
                              (void *)val_ptr) < 0)
  {
    return RIL_E_GENERIC_FAILURE;
  }

  val_ptr = (unsigned char*)&nas_003E_req->t10.get_3gpp2_info_mask;
  tlv_length = sizeof(nas_003E_req->t10.get_3gpp2_info_mask);

  if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                              &msg_size,
                              NAS_003E_REQ_MASK,
                              tlv_length,
                              (void *)val_ptr) < 0)
  {
    return RIL_E_GENERIC_FAILURE;
  }
  
  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_3GPP2_SUBSCRIPTION_INFO_REQ_MSG_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {
    if (qmi_nas_get_3gpp2_subscription_info_rsp(msg, msg_size, nas_003E_rsp) < 0)
    {
      MSG_HIGH("qmi_nas_get_3gpp2_subscription_info: qmi_nas_get_3gpp2_subscription_info_rsp returned error", 0, 0, 0);
    }
    else
    {
      res = RIL_E_SUCCESS;
    }
  }

  return res; 
}
//<-- RIL_REQUEST_CDMA_SUBSCRIPTION

//--> RIL_REQUEST_REGISTRATION_STATE
/*===========================================================================
  FUNCTION  qmi_nas_get_sys_info_process_resp
===========================================================================*/
static int
qmi_nas_get_sys_info_process_resp
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_get_sys_info_resp_msg_v01     *qmi_response
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;
  unsigned char temp_8bit;

  memset(qmi_response, 0, sizeof(nas_get_sys_info_resp_msg_v01));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      // CDMA Service Status Info
      case NAS_004D_RSP_T10:
      {
        qmi_response->cdma_srv_status_info_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->cdma_srv_status_info.srv_status = (nas_service_status_enum_type_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, qmi_response->cdma_srv_status_info.is_pref_data_path);
      }
      break;

      // HDR Service Status Info
      case NAS_004D_RSP_T11:
      {
        qmi_response->hdr_srv_status_info_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->hdr_srv_status_info.srv_status = (nas_service_status_enum_type_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, qmi_response->hdr_srv_status_info.is_pref_data_path);
      }
      break;

      // GSM Service Status Info
      case NAS_004D_RSP_T12:
      {
        qmi_response->gsm_srv_status_info_valid = TRUE;
      }
      break;

      // WCDMA Service Status Info
      case NAS_004D_RSP_T13:
      {
        qmi_response->wcdma_srv_status_info_valid = TRUE;
      }
      break;

      // LTE Service Status Info
      case NAS_004D_RSP_T14:
      {
        qmi_response->lte_srv_status_info_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->lte_srv_status_info.srv_status = (nas_service_status_enum_type_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->lte_srv_status_info.true_srv_status = (nas_true_service_status_enum_type_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, qmi_response->lte_srv_status_info.is_pref_data_path);
      }
      break;

      // CDMA System Info
      case NAS_004D_RSP_T15:
      {
        qmi_response->cdma_sys_info_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.common_sys_info.srv_domain_valid);
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->cdma_sys_info.common_sys_info.srv_domain = (nas_service_domain_enum_type_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.common_sys_info.srv_capability_valid);
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->cdma_sys_info.common_sys_info.srv_capability = (nas_service_domain_enum_type_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.common_sys_info.roam_status_valid);
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->cdma_sys_info.common_sys_info.roam_status = (nas_roam_status_enum_type_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.common_sys_info.is_sys_forbidden_valid);
        READ_8_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.common_sys_info.is_sys_forbidden);
        READ_8_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.cdma_hdr_only_sys_info.is_sys_prl_match_valid);
        READ_8_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.cdma_hdr_only_sys_info.is_sys_prl_match);
        READ_8_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.cdma_specific_sys_info.p_rev_in_use_valid);
        READ_8_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.cdma_specific_sys_info.p_rev_in_use);
        READ_8_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.cdma_specific_sys_info.bs_p_rev_valid);
        READ_8_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.cdma_specific_sys_info.bs_p_rev);
        READ_8_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.cdma_specific_sys_info.ccs_supported_valid);
        READ_8_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.cdma_specific_sys_info.ccs_supported);
        READ_8_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.cdma_specific_sys_info.cdma_sys_id_valid);
        READ_16_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.cdma_specific_sys_info.cdma_sys_id.sid);
        READ_16_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.cdma_specific_sys_info.cdma_sys_id.nid);
        READ_8_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.cdma_specific_sys_info.bs_info_valid);
        READ_16_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.cdma_specific_sys_info.bs_info.base_id);
        READ_32_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.cdma_specific_sys_info.bs_info.base_lat);
        READ_32_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.cdma_specific_sys_info.bs_info.base_long);
        READ_8_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.cdma_specific_sys_info.packet_zone_valid);
        READ_16_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.cdma_specific_sys_info.packet_zone);
        READ_8_BIT_VAL (value_ptr, qmi_response->cdma_sys_info.cdma_specific_sys_info.network_id_valid);
        for (i = 0 ; i < NAS_MCC_MNC_MAX_V01 ; i++ )
        {
          READ_8_BIT_VAL(value_ptr, qmi_response->cdma_sys_info.cdma_specific_sys_info.network_id.mcc[i]);
//BKS_20131216 modify
        }
        for (i = 0 ; i < NAS_MCC_MNC_MAX_V01 ; i++ )
        {
          READ_8_BIT_VAL(value_ptr, qmi_response->cdma_sys_info.cdma_specific_sys_info.network_id.mnc[i]);
        }
      }
      break;

      // HDR System Info
      case NAS_004D_RSP_T16:
      {
        qmi_response->hdr_sys_info_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, qmi_response->hdr_sys_info.common_sys_info.srv_domain_valid);
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->hdr_sys_info.common_sys_info.srv_domain = (nas_service_domain_enum_type_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, qmi_response->hdr_sys_info.common_sys_info.srv_capability_valid);
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->hdr_sys_info.common_sys_info.srv_capability = (nas_service_domain_enum_type_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, qmi_response->hdr_sys_info.common_sys_info.roam_status_valid);
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->hdr_sys_info.common_sys_info.roam_status = (nas_roam_status_enum_type_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, qmi_response->hdr_sys_info.common_sys_info.is_sys_forbidden_valid);
        READ_8_BIT_VAL (value_ptr, qmi_response->hdr_sys_info.common_sys_info.is_sys_forbidden);
        READ_8_BIT_VAL (value_ptr, qmi_response->hdr_sys_info.cdma_hdr_only_sys_info.is_sys_prl_match_valid);
        READ_8_BIT_VAL (value_ptr, qmi_response->hdr_sys_info.cdma_hdr_only_sys_info.is_sys_prl_match);
        READ_8_BIT_VAL (value_ptr, qmi_response->hdr_sys_info.hdr_specific_sys_info.hdr_personality_valid);
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->hdr_sys_info.hdr_specific_sys_info.hdr_personality = (nas_hdr_personality_enum_type_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, qmi_response->hdr_sys_info.hdr_specific_sys_info.hdr_active_prot_valid);
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->hdr_sys_info.hdr_specific_sys_info.hdr_active_prot = (nas_hdr_active_prot_enum_type_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, qmi_response->hdr_sys_info.hdr_specific_sys_info.is856_sys_id_valid);
        for (i = 0 ; i < NAS_IS_856_MAX_LEN_V01 ; i++ )
        {
          READ_8_BIT_VAL (value_ptr, qmi_response->hdr_sys_info.hdr_specific_sys_info.is856_sys_id[i]);
        }
      }
      break;

      // GSM System Info
      case NAS_004D_RSP_T17:
      {
        qmi_response->gsm_sys_info_valid = TRUE;
      }
      break;

      // WCDMA System Info
      case NAS_004D_RSP_T18:
      {
#if 0
        //nas_004D_ind->t18_valid = TRUE;        
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.srv_domain_valid);
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.srv_domain);		
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.srv_capability_valid);				
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.srv_capability);
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.roam_status_valid);		
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.roam_status);				
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.is_sys_forbidden_valid);
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.is_sys_forbidden);	

        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.lac_valid);
        READ_16_BIT_VAL (value_ptr,nas_004D_rsp->t18.lac);		
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.cell_id_valid);				
        READ_32_BIT_VAL (value_ptr,nas_004D_rsp->t18.cell_id);
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.reg_reject_info_valid);		
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.reject_srv_domain);				
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.rej_cause);
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.network_id_valid);	 
        
        for (i = 0; (i < 3); i++ )
        {
          READ_8_BIT_VAL(value_ptr,nas_004D_rsp->t18.mcc[i]);
          READ_8_BIT_VAL(value_ptr,nas_004D_rsp->t18.mnc[i]);          
        } 				

        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.hs_call_status_valid);
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.hs_call_status);		
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.hs_ind_valid);				
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.hs_ind);		
        READ_8_BIT_VAL (value_ptr,nas_004D_rsp->t18.psc_valid);				
        READ_16_BIT_VAL (value_ptr,nas_004D_rsp->t18.psc);
#endif
      }
      break;

      // LTE System Info
      case NAS_004D_RSP_T19:
      {
        qmi_response->lte_sys_info_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, qmi_response->lte_sys_info.common_sys_info.srv_domain_valid);
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->lte_sys_info.common_sys_info.srv_domain = (nas_service_domain_enum_type_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, qmi_response->lte_sys_info.common_sys_info.srv_capability_valid);
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->lte_sys_info.common_sys_info.srv_capability = (nas_service_domain_enum_type_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, qmi_response->lte_sys_info.common_sys_info.roam_status_valid);		
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->lte_sys_info.common_sys_info.roam_status = (nas_roam_status_enum_type_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, qmi_response->lte_sys_info.common_sys_info.is_sys_forbidden_valid);
        READ_8_BIT_VAL (value_ptr, qmi_response->lte_sys_info.common_sys_info.is_sys_forbidden);
        READ_8_BIT_VAL (value_ptr, qmi_response->lte_sys_info.threegpp_specific_sys_info.lac_valid);
        READ_16_BIT_VAL (value_ptr, qmi_response->lte_sys_info.threegpp_specific_sys_info.lac);		
        READ_8_BIT_VAL (value_ptr, qmi_response->lte_sys_info.threegpp_specific_sys_info.cell_id_valid);				
        READ_32_BIT_VAL (value_ptr, qmi_response->lte_sys_info.threegpp_specific_sys_info.cell_id);
        READ_8_BIT_VAL (value_ptr, qmi_response->lte_sys_info.threegpp_specific_sys_info.reg_reject_info_valid);
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->lte_sys_info.threegpp_specific_sys_info.reg_reject_info.reject_srv_domain = (nas_service_domain_enum_type_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, qmi_response->lte_sys_info.threegpp_specific_sys_info.reg_reject_info.rej_cause);
        READ_8_BIT_VAL (value_ptr, qmi_response->lte_sys_info.threegpp_specific_sys_info.network_id_valid);	 
        for (i = 0 ; i < NAS_MCC_MNC_MAX_V01 ; i++ )
        {
          READ_8_BIT_VAL(value_ptr, qmi_response->lte_sys_info.threegpp_specific_sys_info.network_id.mcc[i]);
//BKS_20131216 modify
        }
        for (i = 0 ; i < NAS_MCC_MNC_MAX_V01 ; i++ )
        {
          READ_8_BIT_VAL(value_ptr, qmi_response->lte_sys_info.threegpp_specific_sys_info.network_id.mnc[i]);          
        } 				

        READ_8_BIT_VAL (value_ptr, qmi_response->lte_sys_info.lte_specific_sys_info.tac_valid);
        READ_16_BIT_VAL (value_ptr, qmi_response->lte_sys_info.lte_specific_sys_info.tac);	
      }
      break;

      // LTE Voice Support Sys Info
      case NAS_004D_RSP_T21:
      {
        qmi_response->voice_support_on_lte_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, qmi_response->voice_support_on_lte);
      }
      break;

      default:
        //QMI_DEBUG_MSG_1 ("qmi_nas_get_sys_info_process_resp: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_sys_info_process
===========================================================================*/
int
qmi_nas_get_sys_info_process
(
  int                               client_handle,
  nas_get_sys_info_resp_msg_v01     *qmi_response, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;
  
  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);
  
  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_SYS_INFO_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);
  
  if (rc == QMI_NO_ERR)
  {
    if (qmi_nas_get_sys_info_process_resp(msg, msg_size, qmi_response) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_sys_info_process: qmi_nas_get_sys_info_process_resp returned error");
      rc = QMI_INTERNAL_ERR;
    }
  }
  
  return rc;     
}
//<-- RIL_REQUEST_REGISTRATION_STATE

//BKS_20131202 //--> RIL_REQUEST_OPERATOR
/*===========================================================================
  FUNCTION  qmi_nas_get_plmn_name_resp
===========================================================================*/
static int
qmi_nas_get_plmn_name_resp
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_get_plmn_name_resp_msg_v01    *qmi_response
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int cnt = 0;
  unsigned char temp_8bit;

  memset(qmi_response, 0, sizeof(nas_get_plmn_name_resp_msg_v01));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case NAS_0044_RSP_T02:
      {
      }
      break;

      case NAS_0044_RSP_T10:
      {
        qmi_response->eons_plmn_name_3gpp_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->eons_plmn_name_3gpp.spn_enc = (nas_coding_scheme_enum_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, qmi_response->eons_plmn_name_3gpp.spn_len);
        for(cnt = 0 ; cnt < qmi_response->eons_plmn_name_3gpp.spn_len ; cnt++)
        {
          READ_8_BIT_VAL (value_ptr, qmi_response->eons_plmn_name_3gpp.spn[cnt]);
        }

        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->eons_plmn_name_3gpp.plmn_short_name_enc = (nas_coding_scheme_enum_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->eons_plmn_name_3gpp.plmn_short_name_ci = (nas_country_initials_add_enum_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->eons_plmn_name_3gpp.plmn_short_spare_bits = (nas_spare_bits_enum_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, qmi_response->eons_plmn_name_3gpp.plmn_short_name_len);
        for(cnt = 0 ; cnt < qmi_response->eons_plmn_name_3gpp.spn_len ; cnt++)
        {
          READ_8_BIT_VAL (value_ptr, qmi_response->eons_plmn_name_3gpp.plmn_short_name[cnt]);
        }

        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->eons_plmn_name_3gpp.plmn_long_name_enc = (nas_coding_scheme_enum_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->eons_plmn_name_3gpp.plmn_long_name_ci = (nas_country_initials_add_enum_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        qmi_response->eons_plmn_name_3gpp.plmn_long_spare_bits = (nas_spare_bits_enum_v01)temp_8bit;
        READ_8_BIT_VAL (value_ptr, qmi_response->eons_plmn_name_3gpp.plmn_long_name_len);
        for(cnt = 0 ; cnt < qmi_response->eons_plmn_name_3gpp.spn_len ; cnt++)
        {
          READ_8_BIT_VAL (value_ptr, qmi_response->eons_plmn_name_3gpp.plmn_long_name[cnt]);
        }
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_plmn_name_resp: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
} /* qmi_nas_get_plmn_name_resp */

/*===========================================================================
  FUNCTION  qmi_nas_get_plmn_name
===========================================================================*/
int
qmi_nas_get_plmn_name
(
  int                               client_handle,
  nas_get_plmn_name_req_msg_v01     *qmi_request,
  nas_get_plmn_name_resp_msg_v01    *qmi_response, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE], *tmp_msg_ptr;
  unsigned char     *val_ptr;
  int               msg_size, rc, tlv_length = 0;

  if(qmi_request == NULL)
  {
    return RIL_E_GENERIC_FAILURE;
  }
  
  /* Prepare the request message */
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  /* Construct Envelope TLV (mandatory) */
  val_ptr = (unsigned char*)&qmi_request->plmn;
  tlv_length = sizeof(qmi_request->plmn.mcc) + sizeof(qmi_request->plmn.mnc);

  if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                              &msg_size,
                              NAS_0044_REQ_T01,
                              tlv_length,
                              (void *)val_ptr) < 0)
  {
    return RIL_E_GENERIC_FAILURE;
  }
  
  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_PLMN_NAME_REQ_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);
  
  if (rc == QMI_NO_ERR)
  {
    if (qmi_nas_get_plmn_name_resp(msg, msg_size, qmi_response) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_plmn_name: qmi_nas_get_plmn_name_resp returned error");
      rc = QMI_INTERNAL_ERR;
    }
  }
  
  return rc;     
}/* qmi_nas_get_plmn_name */
//BKS_20131202 //<-- RIL_REQUEST_OPERATOR

//--> RIL_REQUEST_EXIT_EMERGENCY_CALLBACK_MODE
/*===========================================================================
  FUNCTION  qmi_nas_exit_emergency_callback_mode
===========================================================================*/
/*!
@brief 
    Exit Emergency Callback Mode
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_exit_emergency_callback_mode
(
  int                                             client_handle,
  nas_set_system_selection_preference_req_msg_v01 *qmi_request,
  int                                             *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(qmi_request == NULL)
  {
    return RIL_E_GENERIC_FAILURE;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if( qmi_request->emergency_mode_valid )
  {
    val_ptr = (unsigned char*)&qmi_request->emergency_mode;
    tlv_length = sizeof(qmi_request->emergency_mode);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_0033_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_SYS_SEL_PREF,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}
//<-- RIL_REQUEST_EXIT_EMERGENCY_CALLBACK_MODE

// --> RIL_REQUEST_EVDO_REV
/*===========================================================================
  FUNCTION  qmi_nas_get_evdo_rev_info
===========================================================================*/
static int
qmi_nas_get_evdo_rev_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_7001_rsp_s            *nas_7001_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_7001_rsp, 0, sizeof(nas_7001_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case NAS_7001_RSP_T10:
      {
        nas_7001_rsp->t10_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_7001_rsp->t10.evdo_rev);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_ims_pdn_enable_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_evdo_rev
===========================================================================*/
int qmi_nas_get_evdo_rev
(
  int                               client_handle,
  nas_7001_rsp_s             *nas_7001_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_7001_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_EVDO_REV_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_nas_get_evdo_rev_info(msg,msg_size,nas_7001_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_ims_pdn_enable: qmi_nas_get_ims_pdn_enable_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

/*===========================================================================
  FUNCTION  qmi_nas_set_evdo_rev
===========================================================================*/
int qmi_nas_set_evdo_rev
(
  int                               client_handle,
  nas_7002_req_s             *nas_7002_req, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_7002_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(nas_7002_req->t10_valid)
  {
    val_ptr = (unsigned char*)&nas_7002_req->t10;
    tlv_length = sizeof(nas_7002_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_7002_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_EVDO_REV_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}
// <-- RIL_REQUEST_EVDO_REV
//--> RIL_REQUEST_APN_SETTING
/*===========================================================================
  FUNCTION  qmi_nas_get_sdm_apn_iptype_resp
===========================================================================*/
static int
qmi_nas_get_sdm_apn_info_resp
(
	unsigned char 					*rx_buf,
	int								rx_buf_len,
	nas_7006_rsp_s 				  *qmi_response
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(qmi_response, 0, sizeof(nas_7006_rsp_s));
  
  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
	if (qmi_util_read_std_tlv (&rx_buf,
							   &rx_buf_len,
							   &type,
							   &length,
							   &value_ptr) < 0)
	{
	  return QMI_INTERNAL_ERR;
	}

	/* Now process TLV */
	switch (type)
	{
	  case NAS_7006_RSP_T11:
	  {
		READ_8_BIT_VAL (value_ptr,qmi_response->t11.classid);	
		MSG_HIGH ("qmi_nas_get_sdm_apn_info_resp::classid =%d\n",qmi_response->t11.classid, 0, 0);
		qmi_response->t11_valid = TRUE;
	  }
	  break;

	  case NAS_7006_RSP_T12:
	  {
       if (length > 0)
      	{   
      	 int cpy_len = (length < QMI_NAS_MAX_APN_STR_SIZE)                      
					? length : (QMI_NAS_MAX_APN_STR_SIZE - 1); 	 
		 memcpy (qmi_response->t12.apn_name, (void *)value_ptr, cpy_len);        
		 //qmi_response->t12.apn_name[cpy_len] = '\0';
		 MSG_HIGH ("qmi_nas_get_sdm_apn_info_resp::apn name =%s (%d)",qmi_response->t12.apn_name, cpy_len, 0);		 
      	}
	  else
	  	{
		 qmi_response->t12.apn_name[0] = '\0';	  	
	  	}
	
    	qmi_response->t12_valid = TRUE;
	  }
	  break; 
	  
	  case NAS_7006_RSP_T13:
	  {
        READ_8_BIT_VAL (value_ptr, qmi_response->t13.iptype);
		MSG_HIGH ("qmi_nas_get_sdm_apn_info_resp::iptype =%d\n",qmi_response->t13.iptype, 0, 0);
		qmi_response->t13_valid = TRUE;
	  }
	  break;

	  case NAS_7006_RSP_T14:
	  {
        READ_8_BIT_VAL (value_ptr, qmi_response->t14.enabled);
		MSG_HIGH ("qmi_nas_get_sdm_apn_info_resp::enabled =%d\n",qmi_response->t14.enabled, 0, 0);
		qmi_response->t14_valid = TRUE;
	  }
	  break;
	  
	  case NAS_7006_RSP_T15:
	  {
        READ_32_BIT_VAL (value_ptr, qmi_response->t15.inactivityT);
		MSG_HIGH ("qmi_nas_get_sdm_apn_info_resp::inactivityT =%d\n",qmi_response->t15.inactivityT, 0, 0);
		qmi_response->t15_valid = TRUE;
	  }  
	  break;

	  case NAS_7006_RSP_T16:
	  {
        READ_8_BIT_VAL (value_ptr, qmi_response->t16.bearer);
		MSG_HIGH ("qmi_nas_get_sdm_apn_info_resp::bearer =%d\n",qmi_response->t16.bearer, 0, 0);
		qmi_response->t13_valid = TRUE;
	  }
	  break;

	  case NAS_7006_RSP_T17:
	  {
        READ_16_BIT_VAL (value_ptr, qmi_response->t17.max_conn);
		MSG_HIGH ("qmi_nas_get_sdm_apn_info_resp::max_conn =%d\n",qmi_response->t17.max_conn, 0, 0);
		qmi_response->t14_valid = TRUE;
	  }
	  break;
	  
	  case NAS_7006_RSP_T18:
	  {
        READ_16_BIT_VAL (value_ptr, qmi_response->t18.max_conn_t);
		MSG_HIGH ("qmi_nas_get_sdm_apn_info_resp::max_conn_t =%d\n",qmi_response->t18.max_conn_t, 0, 0);
		qmi_response->t15_valid = TRUE;
	  }  
	  break;

	  case NAS_7006_RSP_T19:
	  {
        READ_16_BIT_VAL (value_ptr, qmi_response->t19.wait_time);
		MSG_HIGH ("qmi_nas_get_sdm_apn_info_resp::wait_time =%d\n",qmi_response->t19.wait_time, 0, 0);
		qmi_response->t13_valid = TRUE;
	  }
	  break;

	  default:
		MSG_HIGH ("qmi_nas_get_ims_pdn_enable_info: Unknown TLV ID=%d\n",(unsigned)type, 0, 0);
	  break;
	} /* switch */
  } /* while */

  return QMI_NO_ERR;
	
} 

/*===========================================================================
  FUNCTION  qmi_nas_get_sdm_apn_iptype
===========================================================================*/
int
qmi_nas_get_sdm_apn_info
(
  int								client_handle,	
  nas_7006_req_s 			*qmi_request, 
  nas_7006_rsp_s 			*qmi_response, 
  int								*qmi_err_code
)
{
	unsigned char	  msg[QMI_EAP_STD_MSG_SIZE], *tmp_msg_ptr;
	unsigned char	  *val_ptr;
	int 			  msg_size, rc, tlv_length = 0;
	
	if(qmi_request == NULL)
	{
	  return RIL_E_GENERIC_FAILURE;
	}
	
	/* Prepare the request message */
	tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
	msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);
	
	/* Construct Envelope TLV (mandatory) */
	val_ptr = (unsigned char*)&qmi_request->t10;
	tlv_length = sizeof(qmi_request->t10);
		
	if (qmi_util_write_std_tlv (&tmp_msg_ptr,
								&msg_size,
								NAS_7006_REQ_T10,
								tlv_length,
								(void *)val_ptr) < 0)
	{
	  return RIL_E_GENERIC_FAILURE;
	}

	/* Construct Envelope TLV (mandatory) */
	val_ptr = (unsigned char*)&qmi_request->t11;
	tlv_length = sizeof(qmi_request->t11);
		
	if (qmi_util_write_std_tlv (&tmp_msg_ptr,
								&msg_size,
								NAS_7006_REQ_T11,
								tlv_length,
								(void *)val_ptr) < 0)
	{
	  return RIL_E_GENERIC_FAILURE;
	}
  
	rc = qmi_service_send_msg_sync (client_handle,
									QMI_NAS_SERVICE,
									QMI_NAS_GET_APN_INFO,
									QMI_SRVC_PDU_PTR(msg),
									QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
									msg,				 
									&msg_size,
									QMI_EAP_STD_MSG_SIZE,
									QMI_SYNC_MSG_APN_INFO_TIMEOUT,
									qmi_err_code);

	if (rc == QMI_NO_ERR)
	{
	  if (qmi_nas_get_sdm_apn_info_resp(msg, msg_size, qmi_response) < 0)
	  {
		QMI_ERR_MSG_0 ("qmi_nas_get_plmn_name: qmi_nas_get_plmn_name_resp returned error");
		rc = QMI_INTERNAL_ERR;
	  }
	}
	
	return rc; 

}


/*===========================================================================
  FUNCTION  qmi_nas_set_sdm_apn_info
===========================================================================*/
/*!
@brief 
    Sets the list of protocol information
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_sdm_apn_info

(
  int                               client_handle,
  nas_7005_req_s             *qmi_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!qmi_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(qmi_req->t11_valid)
  {
    val_ptr = (unsigned char*)&qmi_req->t11;
    tlv_length = sizeof(qmi_req->t11);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_7005_RSQ_T11,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(qmi_req->t12_valid)
  {
    val_ptr = (unsigned char*)&qmi_req->t12;
    tlv_length = sizeof(qmi_req->t12);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_7005_RSQ_T12,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(qmi_req->t13_valid)
  {
    val_ptr = (unsigned char*)&qmi_req->t13;
    tlv_length = sizeof(qmi_req->t13);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_7005_RSQ_T13,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(qmi_req->t14_valid)
  {
    val_ptr = (unsigned char*)&qmi_req->t14;
    tlv_length = sizeof(qmi_req->t14);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_7005_RSQ_T14,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(qmi_req->t15_valid)
  {
    val_ptr = (unsigned char*)&qmi_req->t15;
    tlv_length = sizeof(qmi_req->t15);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_7005_RSQ_T15,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 
  
  if(qmi_req->t16_valid)
  {
    val_ptr = (unsigned char*)&qmi_req->t16;
    tlv_length = sizeof(qmi_req->t16);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_7005_RSQ_T16,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(qmi_req->t17_valid)
  {
    val_ptr = (unsigned char*)&qmi_req->t17;
    tlv_length = sizeof(qmi_req->t17);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_7005_RSQ_T17,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(qmi_req->t18_valid)
  {
    val_ptr = (unsigned char*)&qmi_req->t18;
    tlv_length = sizeof(qmi_req->t18);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_7005_RSQ_T18,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 
  
  if(qmi_req->t19_valid)
  {
    val_ptr = (unsigned char*)&qmi_req->t19;
    tlv_length = sizeof(qmi_req->t19);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_7005_RSQ_T19,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }  
  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_APN_INFO,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}
//<-- RIL_REQUEST_APN_SETTING

// --> RIL_REQUEST_VZW_IMS_SETTING
static int
qmi_nas_vzw_ims_setting_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_7009_rsp_s            *nas_7009_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_7009_rsp, 0, sizeof(nas_7009_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case NAS_7009_RSP_T10:
      {
        nas_7009_rsp->t10_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_7009_rsp->t10.ims_setting);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_ims_pdn_enable_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

uint8 qmi_nas_get_vzw_ims_setting
(
  int                               client_handle,
  nas_7009_rsp_s             *nas_7009_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_7009_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_VZW_IMS_SETTING_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if(rc == QMI_NO_ERR)
  {

    if(qmi_nas_vzw_ims_setting_info(msg,msg_size,nas_7009_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_ims_pdn_enable: qmi_nas_get_ims_pdn_enable_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

uint8 qmi_nas_set_vzw_ims_setting
(
  int                               client_handle,
  nas_7010_req_s             *nas_7010_req, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_7010_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(nas_7010_req->t10_valid)
  {
    val_ptr = (unsigned char*)&nas_7010_req->t10;
    tlv_length = sizeof(nas_7010_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_7010_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_VZW_IMS_SETTING_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}
// <-- RIL_REQUEST_VZW_IMS_SETTING

//--> RIL_REQUEST_EHRPD_IPV6
static int
qmi_nas_get_ehrpd_ipv6_enabled_info
(
  unsigned char                     *rx_buf,
  int                                rx_buf_len,
  nas_7007_rsp_s                    *qmi_response
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(qmi_response, 0, sizeof(nas_7007_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case NAS_7007_RSP_T10:
      {
        qmi_response->t10_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,qmi_response->t10.ipv6_enabled);
		    MSG_HIGH ("qmi_nas_get_ehrpd_ipv6_enabled_info::ipv6_enabled =%d\n",qmi_response->t10.ipv6_enabled, 0, 0);		
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_ehrpd_ipv6_enabled_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

uint8 qmi_nas_get_ehrpd_ipv6_enabled
(
  int                               client_handle,
  nas_7007_rsp_s                    *qmi_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!qmi_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_EHRPD_IPV6_ENABLED_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {
    if (qmi_nas_get_ehrpd_ipv6_enabled_info(msg,msg_size,qmi_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_ehrpd_ipv6_enabled: qmi_nas_get_sdm_apn_info_resp returned error");
      rc = QMI_INTERNAL_ERR;
    } 
  }
  return rc;     
}

uint8 qmi_nas_set_ehrpd_ipv6_enabled
(
  int                               client_handle,
  nas_7008_req_s                    *qmi_req, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!qmi_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(qmi_req->t10_valid)
  {
    val_ptr = (unsigned char*)&qmi_req->t10;
    tlv_length = sizeof(qmi_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_7008_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_EHRPD_IPV6_ENABLED_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}
//<-- RIL_REQUEST_EHRPD_IPV6
//--> RIL_REQUEST_T3402
static int
qmi_nas_get_t3402_info
(
  unsigned char                     *rx_buf,
  int                                rx_buf_len,
  nas_7011_rsp_s                    *qmi_response
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(qmi_response, 0, sizeof(nas_7011_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case NAS_7011_RSP_T10:
      {
        qmi_response->t10_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,qmi_response->t10.timer);
		    MSG_HIGH ("qmi_nas_get_t3402_info::t3402 =%d\n",qmi_response->t10.timer, 0, 0);		
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_t3402_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

uint8 qmi_nas_get_t3402
(
  int                               client_handle,
  nas_7011_rsp_s                    *qmi_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!qmi_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_T3402_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {
    if (qmi_nas_get_t3402_info(msg,msg_size,qmi_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_ehrpd_ipv6_enabled: qmi_nas_get_sdm_apn_info_resp returned error");
      rc = QMI_INTERNAL_ERR;
    } 
  }
  return rc;     
}

uint8 qmi_nas_set_t3402
(
  int                               client_handle,
  nas_7012_req_s                    *qmi_req, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!qmi_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(qmi_req->t10_valid)
  {
    val_ptr = (unsigned char*)&qmi_req->t10;
    tlv_length = sizeof(qmi_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_7012_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_T3402_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}
//<-- RIL_REQUEST_T3402

//--> RIL_REQUEST_HK_GET_IMS_AUTH
/*===========================================================================
  FUNCTION  qmi_nas_get_ims_sip_extended_config_info
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with ims pdn enable info.  It
  is used both by the get imd enable info cmd response
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_ims_sip_extended_config_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_5567_rsp_s            *nas_5567_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_5567_rsp, 0, sizeof(nas_5567_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {

      case NAS_5567_RSP_T10:
      {
        nas_5567_rsp->t10_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,nas_5567_rsp->t10.AuthScheme);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_nas_get_ims_user_config_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_ims_sip_extended_config
===========================================================================*/
/*!
@brief 
  Get the IMS Sip Extended Config Information of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_ims_sip_extended_config
(
  int                               client_handle,
  nas_5567_rsp_s             *nas_5567_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_5567_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_IMS_SIP_EXTENDED_CONFIG_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_nas_get_ims_sip_extended_config_info (msg,msg_size,nas_5567_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_ims_sip_extended_config_info : qmi_nas_get_ims_user_config_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}
//<-- RIL_REQUEST_HK_GET_IMS_AUTH

//--> RIL_REQUEST_HK_SET_IMS_AUTH
/*===========================================================================
  FUNCTION  qmi_nas_set_ims_sip_extended_config
===========================================================================*/
/*!
@brief 
    Sets the list of IMS Sip Extended Config information
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_ims_sip_extended_config
(
  int                               client_handle,
  nas_5568_req_s             *nas_5568_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_5568_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(nas_5568_req->t10_valid)
  {
    val_ptr = (unsigned char*)&nas_5568_req->t10;
    tlv_length = sizeof(nas_5568_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_5568_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_IMS_SIP_EXTENDED_CONFIG_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}
//<-- RIL_REQUEST_HK_SET_IMS_AUTH


//BKS_20140307 start
//-->RIL_REQUEST_HK_SET_CDMA_SYS_SEL_PREF
/*===========================================================================
  FUNCTION  qmi_nas_set_system_selection
===========================================================================*/
/*!
@brief 
    Sets the roaming preference
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_system_selection
(
  int                               client_handle,
  nas_7003_req_s*  nas_7003_req,
  int*                           qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;
  unsigned char     *val_ptr;

  if(!nas_7003_req)
  {
    return QMI_INTERNAL_ERR;
  }

  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);
  
  if(nas_7003_req->t10_valid == TRUE)
  {
    val_ptr = (unsigned char*)&nas_7003_req->t10;
    tlv_length = sizeof(nas_7003_req->t10);
	
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_7003_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }
  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_SYSTEM_SELECTION_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

 MSG_HIGH ("[qmi_nas_set_system_selection]: rc = %d qmi_err_code=%d",rc,qmi_err_code,0);

 return rc;
}
//<--RIL_REQUEST_HK_SET_CDMA_SYS_SEL_PREF

//-->RIL_REQUEST_HK_GET_CDMA_SYS_SEL_PREF
/*===========================================================================
  FUNCTION  qmi_nas_get_system_selection_info
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with ims pdn enable info.  It
  is used both by the get imd enable info cmd response
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_nas_get_system_selection_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_7004_rsp_s            *nas_7004_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_7004_rsp, 0, sizeof(nas_7004_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {

      case NAS_7004_RSP_T10:
      {
        nas_7004_rsp->t10_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_7004_rsp->t10.sys_sel);
      }
      break;

      default:
        MSG_HIGH ("qmi_nas_get_system_selection_info: Unknown TLV ID=%x\n",(unsigned)type,0,0);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_system_selection
===========================================================================*/

/*!
@brief 
  Get the IMS Test Mode Information of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_system_selection
(
  int                               client_handle,
  nas_7004_rsp_s             *nas_7004_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_7004_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_SYSTEM_SELECTION_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                 QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);


  if (rc == QMI_NO_ERR)
  {

    if (qmi_nas_get_system_selection_info(msg,msg_size,nas_7004_rsp) < 0)
    {
      MSG_HIGH ("[qmi_nas_get_system_selection]: Error!!! rc=%d ",rc,0,0);
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}
//<--RIL_REQUEST_HK_GET_CDMA_SYS_SEL_PREF

//BKS_20140307 end

//--> RIL_REQUEST_HK_USIM_ONCHIP
uint8 qmi_nas_clear_mru
(
  int                               client_handle,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_CLEAR_MRU_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  5,//QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}
// <-- RIL_REQUEST_HK_USIM_ONCHIP

/*===========================================================================
  FUNCTION  qmi_nas_get_sdm_dcmo_info_resp
===========================================================================*/
static int
qmi_nas_get_sdm_dcmo_info_resp
(
	unsigned char 					*rx_buf,
	int								rx_buf_len,
	nas_701C_rsp_s 				  *qmi_response
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(qmi_response, 0, sizeof(nas_701C_rsp_s));
  
  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
	if (qmi_util_read_std_tlv (&rx_buf,
							   &rx_buf_len,
							   &type,
							   &length,
							   &value_ptr) < 0)
	{
	  return QMI_INTERNAL_ERR;
	}

	/* Now process TLV */
	switch (type)
	{
	  case NAS_701CD_T10:
	  {
		READ_32_BIT_VAL (value_ptr,qmi_response->t10.qipcall_codec_mode_set);	
		qmi_response->t10_valid = TRUE;
	  }
	  break;

	  case NAS_701CD_T11:
	  {
		READ_32_BIT_VAL (value_ptr,qmi_response->t11.qipcall_codec_mode_set_amr_wb);	
		qmi_response->t11_valid = TRUE;
	  }
	  break;
    
	  case NAS_701CD_T12:
	  {
		READ_32_BIT_VAL (value_ptr,qmi_response->t12.Publish_timer);	
		qmi_response->t12_valid = TRUE;
	  }
	  break;
    
	  case NAS_701CD_T13:
	  {
		READ_32_BIT_VAL (value_ptr,qmi_response->t13.Publish_extended_timer);	
		qmi_response->t13_valid = TRUE;
	  }
	  break;

	  case NAS_701CD_T14:
	  {
		READ_32_BIT_VAL (value_ptr,qmi_response->t14.Capabilites_cache_expiration);	
		qmi_response->t14_valid = TRUE;
	  }
	  break;

	  case NAS_701CD_T15:
	  {
		READ_32_BIT_VAL (value_ptr,qmi_response->t15.Availability_cache_expiration);	
		qmi_response->t15_valid = TRUE;
	  }
	  break;

	  case NAS_701CD_T16:
	  {
		READ_32_BIT_VAL (value_ptr,qmi_response->t16.Capability_poll_interval);	
		qmi_response->t16_valid = TRUE;
	  }
	  break;

	  case NAS_701CD_T17:
	  {
		READ_32_BIT_VAL (value_ptr,qmi_response->t17.Source_throttle_publish_timer);	
		qmi_response->t17_valid = TRUE;
	  }
	  break;

	  case NAS_701CD_T18:
	  {
		READ_32_BIT_VAL (value_ptr,qmi_response->t18.Max_number_of_entries_in_request);	
		qmi_response->t18_valid = TRUE;
	  }
	  break;    

	  case NAS_701CD_T19:
	  {
		READ_32_BIT_VAL (value_ptr,qmi_response->t19.Capability_poll_list_subscription_expiry_timer);	
		qmi_response->t19_valid = TRUE;
	  }
	  break;    

	  case NAS_701CD_T1A:
	  {
		READ_8_BIT_VAL (value_ptr,qmi_response->t1A.Presence_gzip);	
		qmi_response->t1A_valid = TRUE;
	  }
	  break;    

	  case NAS_701CD_T1B:
	  {
		READ_16_BIT_VAL (value_ptr,qmi_response->t1B.voipConfigExpires);	
		qmi_response->t1B_valid = TRUE;
	  }
	  break;   

	  case NAS_701CD_T1C:
	  {
		READ_16_BIT_VAL (value_ptr,qmi_response->t1C.voipMinSessionExpires);	
		qmi_response->t1C_valid = TRUE;
	  }
	  break;       

	  case NAS_701CD_T1D:
	  {
		READ_16_BIT_VAL (value_ptr,qmi_response->t1D.Timer_VZW);	
		qmi_response->t1D_valid = TRUE;
	  }
	  break;   

	  case NAS_701CD_T1E:
	  {
		READ_16_BIT_VAL (value_ptr,qmi_response->t1E.Tdelay);	
		qmi_response->t1E_valid = TRUE;
	  }
	  break;    

	  case NAS_701CD_T1F:
	  {
		READ_8_BIT_VAL (value_ptr,qmi_response->t1F.voipSilentRedialEnabled);	
		qmi_response->t1F_valid = TRUE;
	  }
	  break;    
    
	  case NAS_701CD_T20:
  	  {
  		READ_8_BIT_VAL (value_ptr,qmi_response->t20.volte_disable);	
  		qmi_response->t20_valid = TRUE;
  	  }
  	  break;    

	  default:
	  break;
	} /* switch */
  } /* while */

  return QMI_NO_ERR;
} 

/*===========================================================================
  FUNCTION  qmi_nas_get_sdm_dcmo_info
===========================================================================*/
int
qmi_nas_get_sdm_dcmo_info
(
  int								client_handle,	
  nas_701C_rsp_s 			*qmi_response, 
  int								*qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!qmi_response)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_DCMO_INFO,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_nas_get_sdm_dcmo_info_resp(msg,msg_size,qmi_response) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_ims_pdn_enable: qmi_nas_get_ims_pdn_enable_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

/*===========================================================================
  FUNCTION  qmi_nas_set_sdm_dcmo_info
===========================================================================*/
int
qmi_nas_set_sdm_dcmo_info

(
  int                               client_handle,
  nas_701D_req_s             *qmi_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!qmi_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(qmi_req->t21_valid)
  {
    val_ptr = (unsigned char*)&qmi_req->t21;
    tlv_length = sizeof(qmi_req->t21);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_701CD_T21,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_DCMO_INFO,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_ims_test_mode_info
===========================================================================*/
static int qmi_nas_get_ims_test_mode_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_5563_rsp_s            *nas_5563_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(nas_5563_rsp, 0, sizeof(nas_5563_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case NAS_5563_RSP_T10:
      {
        nas_5563_rsp->t10_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,nas_5563_rsp->t10.ims_test_mode);
      }
      break;

      default:
        QMI_DEBUG_MSG_1("qmi_nas_get_ims_pdn_enable_info: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================
  FUNCTION  qmi_nas_get_ims_test_mode
===========================================================================*/
int qmi_nas_get_ims_test_mode
(
  int                               client_handle,
  nas_5563_rsp_s             *nas_5563_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nas_5563_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_IMS_TEST_MODE_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_nas_get_ims_test_mode_info(msg,msg_size,nas_5563_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_ims_test_mode: qmi_nas_get_ims_test_mode returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

/*===========================================================================
  FUNCTION  qmi_nas_set_ims_test_mode
===========================================================================*/
int qmi_nas_set_ims_test_mode
(
  int                               client_handle,
  nas_5564_req_s             *nas_5564_req, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_5564_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(nas_5564_req->t10_valid)
  {
    val_ptr = (unsigned char*)&nas_5564_req->t10;
    tlv_length = sizeof(nas_5564_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_5564_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_IMS_TEST_MODE_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}

//hongsg 20140821
/*===========================================================================
  FUNCTION  qmi_nas_get_ims_user_agent
===========================================================================*/
/*!
@brief 
  Get the IMS User Agent Information of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_ims_user_agent
(
  int                               client_handle,
  nas_557A_rsp_s             				*nas_557A_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[ QMI_MAX_MSG_SIZE ];
  int               msg_size, rc;

  if(!nas_557A_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_MAX_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_GET_IMS_USER_AGENT_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_MAX_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_MAX_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_nas_get_ims_user_agent_info (msg,msg_size,nas_557A_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_nas_get_ims_user_agent_info : qmi_nas_get_ims_user_agent_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

/*===========================================================================
  FUNCTION  qmi_nas_set_ims_user_agent
===========================================================================*/
/*!
@brief 
    Sets the IMS User Agent information
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_ims_user_agent
(
  int                               client_handle,
  nas_557B_req_s             				*nas_557B_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_MAX_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nas_557B_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_MAX_MSG_SIZE);

  if(nas_557B_req->t10_valid)
  {
    val_ptr = (unsigned char*)&nas_557B_req->t10;
    tlv_length = sizeof(nas_557B_req->t10.UserAgent);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_557B_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_IMS_USER_AGENT_MSG_ID,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_MAX_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_MAX_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}

#if  defined(FEATURE_LGIT_OTADM_FOTA_FUMO_VZW)
/*===========================================================================  
FUNCTION  qmi_nas_set_fota_wap_push_test
===========================================================================*/
int qmi_nas_set_fota_wap_push_test
(  
	int                               client_handle,   
	struct nas_7030_req_s             *nas_7030_req,   
	int                               *qmi_err_code
)
{  
	unsigned char     msg[QMI_EAP_STD_MSG_SIZE],		*tmp_msg_ptr;
	int               msg_size, rc,tlv_length = 0;   
	unsigned char     *val_ptr; 

	if(!nas_7030_req)  
	{   
		return QMI_INTERNAL_ERR;  
	}   

	/* Set tmp_msg_ptr to beginning of message-specific TLV portion of   
	** message buffer 
	*/    

    //MSG_HIGH("[FOTA] qmi_nas_set_fota_wap_push_test", 0, 0,0);
    //LOGD("[FOTA] qmi_nas_set_fota_wap_push_test");
  
	tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg); 
	msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);  
	if(nas_7030_req->t10_valid)  
	{    
		val_ptr = (unsigned char*)&nas_7030_req->t10;   
		tlv_length = sizeof(nas_7030_req->t10);    

		if (qmi_util_write_std_tlv (&tmp_msg_ptr,                               
									&msg_size,                                
									NAS_7030_REQ_T10,                                
									tlv_length,                                
									(void *)val_ptr) < 0)   
		{      
			return QMI_INTERNAL_ERR;    
		}  
	}   

	rc = qmi_service_send_msg_sync (client_handle,                                 
									QMI_NAS_SERVICE,                                  
									QMI_NAS_WAP_PUSH_TEST_MSG_ID,                                  
									QMI_SRVC_PDU_PTR(msg),                                  
									QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,                                 
									msg,                                                   
									&msg_size,                                  
									QMI_EAP_STD_MSG_SIZE,                                 
									QMI_SYNC_MSG_DEFAULT_TIMEOUT,                                 
									qmi_err_code);  

	return rc;

}
#endif

/*===========================================================================
  FUNCTION  qmi_nas_set_vzw_test_menu
===========================================================================*/
int
qmi_nas_set_vzw_test_menu
(
  int                               client_handle,
  struct nas_701F_req_s             *qmi_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_EAP_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!qmi_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE);

  if(qmi_req->t10_valid)
  {
    val_ptr = (unsigned char*)&qmi_req->t10;
    tlv_length = sizeof(qmi_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                NAS_701F_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_NAS_SERVICE,
                                  QMI_NAS_SET_VZW_OTADM_TESTMENU,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_EAP_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_EAP_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}
