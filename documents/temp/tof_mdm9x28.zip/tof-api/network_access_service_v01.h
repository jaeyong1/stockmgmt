#ifndef NAS_SERVICE_H
#define NAS_SERVICE_H
/**
  @file network_access_service_v01.h
  
  @brief This is the public header file which defines the nas service Data structures.

  This header file defines the types and structures that were defined in 
  nas. It contains the constant values defined, enums, structures,
  messages, and service message IDs (in that order) Structures that were 
  defined in the IDL as messages contain mandatory elements, optional 
  elements, a combination of mandatory and optional elements (mandatory 
  always come before optionals in the structure), or nothing (null message)
   
  An optional element in a message is preceded by a uint8_t value that must be
  set to true if the element is going to be included. When decoding a received
  message, the uint8_t values will be set to true or false by the decode
  routine, and should be checked before accessing the values that they
  correspond to. 
   
  Variable sized arrays are defined as static sized arrays with an unsigned
  integer (32 bit) preceding it that must be set to the number of elements
  in the array that are valid. For Example:
   
  uint32_t test_opaque_len;
  uint8_t test_opaque[16];
   
  If only 4 elements are added to test_opaque[] then test_opaque_len must be
  set to 4 before sending the message.  When decoding, the _len value is set 
  by the decode routine and should be checked so that the correct number of 
  elements in the array will be accessed. 

*/
/*====*====*====*====*====*====*====*====*====*====*====*====*====*====*====*
  Copyright (c) 2012 QUALCOMM Incorporated.  All Rights Reserved. 
 QUALCOMM Proprietary and Confidential.

  $Header: //source/qcom/qct/interfaces/qmi/nas/main/latest/api/network_access_service_v01.h#12 $
 *====*====*====*====*====*====*====*====*====*====*====*====*====*====*====*/
/*====*====*====*====*====*====*====*====*====*====*====*====*====*====*====* 
 *THIS IS AN AUTO GENERATED FILE. DO NOT ALTER IN ANY WAY 
 *====*====*====*====*====*====*====*====*====*====*====*====*====*====*====*/

/* This file was generated with Tool version 5.0
   It requires encode/decode library version 4 or later
   It was generated on: Fri Mar  2 2012
   From IDL File: network_access_service_v01.idl */

/** @defgroup nas_qmi_consts Constant values defined in the IDL */
/** @defgroup nas_qmi_msg_ids Constant values for QMI message IDs */
/** @defgroup nas_qmi_enums Enumerated types used in QMI messages */
/** @defgroup nas_qmi_messages Structures sent as QMI messages */
/** @defgroup nas_qmi_aggregates Aggregate types used in QMI messages */
/** @defgroup nas_qmi_accessor Accessor for QMI service object */
/** @defgroup nas_qmi_version Constant values for versioning information */

#include "common_v01.h"


#ifdef __cplusplus
extern "C" {
#endif

/** @addtogroup nas_qmi_version 
    @{ 
  */ 
/** Major Version Number of the IDL used to generate this file */
#define NAS_V01_IDL_MAJOR_VERS 0x01
/** Revision Number of the IDL used to generate this file */
#define NAS_V01_IDL_MINOR_VERS 0x19
/** Major Version Number of the qmi_idl_compiler used to generate this file */
#define NAS_V01_IDL_TOOL_VERS 0x05
/** Maximum Defined Message ID */
#define NAS_V01_MAX_MESSAGE_ID 0x006A;
/** 
    @} 
  */


/** @addtogroup nas_qmi_consts 
    @{ 
  */

/**  Constants used for various array max lengths */
#define NAS_SIG_STRENGTH_LIST_MAX_V01 2
#define NAS_SIG_STRENGTH_THRESHOLD_LIST_MAX_V01 5
#define NAS_ECIO_THRESHOLD_LIST_MAX_V01 10
#define NAS_SINR_THRESHOLD_LIST_MAX_V01 5
#define NAS_SPC_MAX_V01 6
#define NAS_MCC_MNC_MAX_V01 3
#define NAS_RSSI_LIST_MAX_V01 7
#define NAS_ECIO_LIST_MAX_V01 6
#define NAS_ERROR_RATE_LIST_MAX_V01 16
#define NAS_3GPP_NETWORK_INFO_LIST_MAX_V01 40
#define NAS_PCI_SCAN_LIST_MAX_V01 5
#define NAS_PCI_SCAN_MAX_NUM_PLMN_V01 6
#define NAS_3GPP_PREFERRED_NETWORKS_LIST_MAX_V01 85
#define NAS_STATIC_3GPP_PREFERRED_NETWORKS_LIST_MAX_V01 40
#define NAS_3GPP_FORBIDDEN_NETWORKS_LIST_MAX_V01 64
#define NAS_IS_856_MAX_LEN_V01 16
#define NAS_RF_BAND_INFO_LIST_MAX_V01 16
#define NAS_SO_LIST_MAX_V01 32
#define NAS_NETWORK_DESCRIPTION_MAX_V01 255
#define NAS_RADIO_IF_LIST_MAX_V01 255
#define NAS_DATA_CAPABILITIES_LIST_MAX_V01 10
#define NAS_ROAMING_INDICATOR_LIST_MAX_V01 2
#define NAS_ACQ_ORDER_LIST_MAX_V01 10
#define NAS_SERVICE_PROVIDER_NAME_MAX_V01 16
#define NAS_OPERATOR_PLMN_LIST_MAX_V01 255
#define NAS_PLMN_NETWORK_NAME_LIST_MAX_V01 64
#define NAS_LONG_NAME_MAX_V01 255
#define NAS_SHORT_NAME_MAX_V01 255
#define NAS_PLMN_NAME_MAX_V01 255
#define QMI_NAS_UATI_LENGTH_V01 16
#define QMI_NAS_REQUEST_SIG_INFO_RSSI_BIT_V01 0
#define QMI_NAS_REQUEST_SIG_INFO_ECIO_BIT_V01 1
#define QMI_NAS_REQUEST_SIG_INFO_IO_BIT_V01 2
#define QMI_NAS_REQUEST_SIG_INFO_SINR_BIT_V01 3
#define QMI_NAS_REQUEST_SIG_INFO_ERROR_RATE_BIT_V01 4
#define QMI_NAS_REQUEST_SIG_INFO_RSRQ_BIT_V01 5
#define QMI_NAS_RAT_UMTS_BIT_V01 15
#define QMI_NAS_RAT_LTE_BIT_V01 14
#define QMI_NAS_RAT_GSM_BIT_V01 7
#define QMI_NAS_RAT_GSM_COMPACT_BIT_V01 6
#define QMI_NAS_RAT_NOT_AVAILABLE_V01 0
#define QMI_NAS_PROTOCOL_SUBTYPE_2_PHYSICAL_LAYER_BIT_V01 0
#define QMI_NAS_PROTOCOL_SUBTYPE_CCMAC_BIT_V01 1
#define QMI_NAS_PROTOCOL_SUBTYPE_ACMAC_BIT_V01 2
#define QMI_NAS_PROTOCOL_SUBTYPE_FTCMAC_BIT_V01 3
#define QMI_NAS_PROTOCOL_SUBTYPE_3_RTCMAC_BIT_V01 4
#define QMI_NAS_PROTOCOL_SUBTYPE_1_RTCMAC_BIT_V01 5
#define QMI_NAS_PROTOCOL_SUBTYPE_IDLE_BIT_V01 6
#define QMI_NAS_PROTOCOL_SUBTYPE_GEN_MULTI_DISC_PORT_BIT_V01 7
#define QMI_NAS_BROADCAST_SUBTYPE_GENERIC_BIT_V01 0
#define QMI_NAS_APP_SUBTYPE_MULTIFLOW_BIT_V01 0
#define QMI_NAS_APP_SUBTYPE_ENHANCED_MULTIFLOW_BIT_V01 1
#define QMI_NAS_AKEY_LEN_V01 26
#define NAS_MAX_LTE_NGBR_WCDMA_NUM_FREQS_V01 2
#define NAS_MAX_LTE_NGBR_WCDMA_NUM_CELLS_V01 8
#define NAS_MAX_LTE_NGBR_GSM_NUM_FREQS_V01 2
#define NAS_MAX_LTE_NGBR_GSM_NUM_CELLS_V01 8
#define NAS_MAX_LTE_NGBR_NUM_FREQS_V01 3
#define NAS_MAX_LTE_NGBR_NUM_CELLS_V01 8
#define QMI_NAS_RAT_MODE_PREF_CDMA2000_1X_BIT_V01 0
#define QMI_NAS_RAT_MODE_PREF_CDMA2000_HRPD_BIT_V01 1
#define QMI_NAS_RAT_MODE_PREF_GSM_BIT_V01 2
#define QMI_NAS_RAT_MODE_PREF_UMTS_BIT_V01 3
#define QMI_NAS_RAT_MODE_PREF_LTE_BIT_V01 4
#define QMI_NAS_RAT_MODE_PREF_TDSCDMA_BIT_V01 5
#define QMI_NAS_DDTM_ACTION_SUPPRESS_L2ACK_BIT_V01 0
#define QMI_NAS_DDTM_ACTION_SUPPRESS_REG_BIT_V01 1
#define QMI_NAS_DDTM_ACTION_IGNORE_SO_PAGES_BIT_V01 2
#define QMI_NAS_DDTM_ACTION_SUPPRESS_MO_DBM_BIT_V01 3
#define QMI_NAS_NETWORK_IN_USE_STATUS_BITS_V01 0x03
#define QMI_NAS_NETWORK_IN_USE_STATUS_UNKNOWN_V01 0
#define QMI_NAS_NETWORK_IN_USE_STATUS_CURRENT_SERVING_V01 1
#define QMI_NAS_NETWORK_IN_USE_STATUS_AVAILABLE_V01 2
#define QMI_NAS_NETWORK_ROAMING_STATUS_BITS_V01 0x0C
#define QMI_NAS_NETWORK_ROAMING_STATUS_UNKNOWN_V01 0
#define QMI_NAS_NETWORK_ROAMING_STATUS_HOME_V01 1
#define QMI_NAS_NETWORK_ROAMING_STATUS_ROAM_V01 2
#define QMI_NAS_NETWORK_FORBIDDEN_STATUS_BITS_V01 0x30
#define QMI_NAS_NETWORK_FORBIDDEN_STATUS_UNKNOWN_V01 0
#define QMI_NAS_NETWORK_FORBIDDEN_STATUS_FORBIDDEN_V01 1
#define QMI_NAS_NETWORK_FORBIDDEN_STATUS_NOT_FORBIDDEN_V01 2
#define QMI_NAS_NETWORK_PREFERRED_STATUS_BITS_V01 0xC0
#define QMI_NAS_NETWORK_PREFERRED_STATUS_UNKNOWN_V01 0
#define QMI_NAS_NETWORK_PREFERRED_STATUS_PREFERRED_V01 1
#define QMI_NAS_NETWORK_PREFERRED_STATUS_NOT_PREFERRED_V01 2
#define QMI_NAS_SCM_EXT_IND_BIT_V01 0x80
#define QMI_NAS_SCM_EXT_IND_BAND_CLASS_1_POINT_4_V01 1
#define QMI_NAS_SCM_EXT_IND_OTHER_BAND_V01 0
#define QMI_NAS_SCM_MODE_BIT_V01 0x40
#define QMI_NAS_SCM_MODE_DUAL_V01 1
#define QMI_NAS_SCM_MODE_CDMA_ONLY_V01 0
#define QMI_NAS_SCM_SLOTTED_BIT_V01 0x20
#define QMI_NAS_SCM_MEID_CONFIGURED_BIT_V01 0x10
#define QMI_NAS_SCM_25_MHZ_BANDWIDTH_BIT_V01 0x08
#define QMI_NAS_SCM_TRANSMISSION_BIT_V01 0x04
#define QMI_NAS_SCM_TRANSMISSION_DISCONTINUOUS_V01 1
#define QMI_NAS_SCM_TRANSMISSION_CONTINUOUS_V01 0
#define QMI_NAS_SCM_POWER_CLASS_BIT_V01 0x03
#define QMI_NAS_SCM_POWER_CLASS_I_V01 0
#define QMI_NAS_SCM_POWER_CLASS_II_V01 1
#define QMI_NAS_SCM_POWER_CLASS_III_V01 2
#define QMI_NAS_SCM_POWER_CLASS_RESERVED_V01 3
#define NAS_MAX_NAM_NAME_LEN_V01 12
#define NAS_MAX_3GPP2_SUBS_INFO_DIR_NUM_LEN_V01 10
#define MDN_MAX_LEN_V01 15
#define NAS_MAX_3GPP2_HOME_SID_NID_NUM_V01 20
#define NAS_MCC_LEN_V01 3
#define NAS_IMSI_11_12_LEN_V01 2
#define NAS_IMSI_MIN1_LEN_V01 7
#define NAS_IMSI_MIN2_LEN_V01 3
#define NAS_PLMN_LEN_V01 3
#define NAS_NMR_MAX_NUM_V01 6
#define NAS_UMTS_MAX_MONITORED_CELL_SET_NUM_V01 24
#define NAS_UMTS_GERAN_MAX_NBR_CELL_SET_NUM_V01 8
#define NAS_SPN_LEN_MAX_V01 16
#define NAS_MAX_SVC_STAT_V01 10
#define NAS_MAX_SVC_DOMAIN_V01 10
#define NAS_MAX_SVC_CAPA_V01 10
#define NAS_MAX_REG_REJ_V01 10
#define NAS_MAX_ROAM_V01 10
#define NAS_MAX_FORBIDDEN_SYS_V01 10
#define NAS_MAX_SYS_ID_V01 10
#define NAS_MAX_LAC_V01 10
#define NAS_MAX_TAC_V01 10
#define NAS_MAX_CELL_INFO_V01 10
#define NAS_MAX_BS_LOC_V01 10
#define NAS_MAX_PKT_ZONE_V01 10
#define NAS_SIG_STR_THRESHOLD_LIST_MAX_V01 16
#define NAS_CDMA_POSITION_INFO_MAX_V01 10
#define NAS_TECHNOLOGY_PREF_BITMASK_3GPP2_V01 0x01
#define NAS_TECHNOLOGY_PREF_BITMASK_3GPP_V01 0x02
#define NAS_TECHNOLOGY_PREF_BITMASK_ANALOG_V01 0x04
#define NAS_TECHNOLOGY_PREF_BITMASK_DIGITAL_V01 0x08
#define NAS_TECHNOLOGY_PREF_BITMASK_HDR_V01 0x10
#define NAS_TECHNOLOGY_PREF_BITMASK_LTE_V01 0x20
#define NAS_CSG_NAME_MAX_LEN 48
#define NAS_CSG_NAME_MAX_V01 48


/**
    @}
  */

/*
 * nas_reset_req_msg is empty
 * typedef struct {
 * }nas_reset_req_msg_v01;
 */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Resets the NAS service state variables of the requesting
              control point.  */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_reset_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Aborts a previously issued QMI_NAS command. */
typedef struct {

  /* Mandatory */
  /*  TX_ID */
  uint16_t tx_id;
  /**<   Transaction ID of the request to be aborted.
   */
}nas_abort_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Aborts a previously issued QMI_NAS command. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_abort_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t report_signal_strength;
  /**<   Values: \n
       - 0 -- Do not report \n
       - 1 -- Report
   */

  uint32_t report_signal_strength_threshold_list_len;  /**< Must be set to # of elements in report_signal_strength_threshold_list */
  int8_t report_signal_strength_threshold_list[NAS_SIG_STRENGTH_THRESHOLD_LIST_MAX_V01];
  /**<   A sequence of thresholds delimiting signal strength Var bands. 
       Each threshold specifies the signal strength (in dBm) at which
       an event report indication, including the current signal
       strength, will be sent to the requesting control point. 
       Threshold is a signed 1 byte value. Valid values: -128 dBm
       to +127 dBm.
   */
}nas_signal_stregth_indicator_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t report_rssi;
  /**<   Values: \n
       - 0 -- Do not report \n
       - 1 -- Report
   */

  uint8_t rssi_delta;
  /**<   RSSI delta (in dBm) at which an event report indication,
       including the current RSSI, will be sent to the requesting
       control point. RSSI delta is an unsigned 1 byte value.
   */
}nas_rssi_indicator_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t report_ecio;
  /**<   Values: \n
       - 0 -- Do not report \n
       - 1 -- Report
   */

  uint8_t ecio_delta;
  /**<   ECIO delta at which an event report indication,
       ecio_delta including the current ECIO, will be sent to the
       requesting control point. ECIO delta is an unsigned 1 byte
       value that increments in negative 0.5 dBm, e.g., ecio_delta of
       2 means a change of -1 dBm.
   */
}nas_ecio_indicator_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t report_io;
  /**<   Values: \n
       - 0 -- Do not report \n
       - 1 -- Report
   */

  uint8_t io_delta;
  /**<   IO delta (in dBm) at which an event report indication,
       io_delta including the current IO, will be sent to the
       requesting control point. IO delta is an unsigned 1 byte value.
   */
}nas_io_indicator_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t report_sinr;
  /**<   Values: \n
       - 0 -- Do not report \n
       - 1 -- Report
   */

  uint8_t sinr_delta;
  /**<   SINR delta level at which an event report indication,
       sinr_delta including the current SINR, will be sent to the
       requesting control point. SINR delta level is an unsigned
       1 byte value.
   */
}nas_sinr_indicator_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t report_rsrq;
  /**<   Values: \n
       - 0 -- Do not report \n
       - 1 -- Report
   */

  uint8_t rsrq_delta;
  /**<   RSRQ delta level at which an event report indication, including the
      current RSRQ, will be sent to the requesting control point. 
      RSRQ delta level is an unsigned 1 byte value.
   */
}nas_rsrq_indicator_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t report_ecio;
  /**<   Values: \n
       - 0 -- Do not report \n
       - 1 -- Report
   */

  uint32_t threshold_list_len;  /**< Must be set to # of elements in threshold_list */
  int16_t threshold_list[NAS_ECIO_THRESHOLD_LIST_MAX_V01];
  /**<  
      A sequence of thresholds delimiting ECIO event reporting bands.
      Every time a new ECIO value crosses a threshold value, an event
      report indication message with the new ECIO value is sent to the
      requesting control point. For this field: \n

      - Each threshold value is a signed 2 byte value \n
      - Maximum number of threshold values is 10           \n
      - At least one value must be specified (if report_ecio is set)
    */
}nas_ecio_indicator_threshold_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t report_sinr;
  /**<   Values: \n
       - 0 -- Do not report \n
       - 1 -- Report
   */

  /*  sinr threshold list */
  uint32_t threshold_list_len;  /**< Must be set to # of elements in threshold_list */
  uint8_t threshold_list[NAS_SINR_THRESHOLD_LIST_MAX_V01];
  /**<  
   A sequence of thresholds delimiting SINR event reporting bands.
   Every time a new SINR value crosses a threshold value, an event
   report indication message with the new sinr value is sent to the
   requesting control point. For this field: \n

   - Each threshold value will be a unsigned 1 byte value \n
   - Maximum number of threshold values is 5              \n
   - At least one value must be specified (if report_sinr is set)
  */
}nas_sinr_indicator_threshold_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t report_lte_rsrp;
  /**<   Values: \n
       - 0 -- Do not report \n
       - 1 -- Report
   */

  uint8_t lte_rsrp_delta;
  /**<   LTE RSRP delta level at which an event report indication, including the
       current RSRP, will be sent to the requesting control point. LTE RSRP 
       delta level is an unsigned 1 byte value, representing the delta in dB.
   */
}nas_rsrp_indicator_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t report_lte_snr;
  /**<   Values: \n
       - 0 -- Do not report \n
       - 1 -- Report
   */

  uint8_t lte_snr_delta;
  /**<   LTE SNR delta level at which an event report indication, including the
       current SNR, will be sent to the requesting control point. LTE SNR delta 
       level is an unsigned 2 byte value, representing the delta in units 
       of 0.1 dB, e.g., lte_snr_delta of 3 means a change 0.3 dB.
   */
}nas_snr_indicator_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Sets the NAS state reporting conditions for the requesting
              control point. (Deprecated) */
typedef struct {

  /* Optional */
  /*  Signal Strength Indicator */
  uint8_t signal_strength_valid;  /**< Must be set to true if signal_strength is being passed */
  nas_signal_stregth_indicator_type_v01 signal_strength;

  /* Optional */
  /*  RF Band Information */
  uint8_t report_rf_band_info_valid;  /**< Must be set to true if report_rf_band_info is being passed */
  uint8_t report_rf_band_info;
  /**<   Values: \n
       - 0 -- Do not report \n
       - 1 -- Report
   */

  /* Optional */
  /*  Registration Reject Reason** */
  uint8_t report_reg_reject_valid;  /**< Must be set to true if report_reg_reject is being passed */
  uint8_t report_reg_reject;
  /**<   Values: \n
       - 0 -- Do not report \n
       - 1 -- Report
   */

  /* Optional */
  /*  RSSI Indicator */
  uint8_t rssi_indicator_valid;  /**< Must be set to true if rssi_indicator is being passed */
  nas_rssi_indicator_type_v01 rssi_indicator;

  /* Optional */
  /*  ECIO Indicator */
  uint8_t ecio_indicator_valid;  /**< Must be set to true if ecio_indicator is being passed */
  nas_ecio_indicator_type_v01 ecio_indicator;

  /* Optional */
  /*  IO Indicator* */
  uint8_t io_indicator_valid;  /**< Must be set to true if io_indicator is being passed */
  nas_io_indicator_type_v01 io_indicator;

  /* Optional */
  /*  SINR Indicator* */
  uint8_t sinr_indicator_valid;  /**< Must be set to true if sinr_indicator is being passed */
  nas_sinr_indicator_type_v01 sinr_indicator;

  /* Optional */
  /*  Error Rate Indicator */
  uint8_t report_error_rate_valid;  /**< Must be set to true if report_error_rate is being passed */
  uint8_t report_error_rate;
  /**<   Values: \n
       - 0 -- Do not report \n
       - 1 -- Report
   */

  /* Optional */
  /*  RSRQ Indicator* */
  uint8_t rsrq_indicator_valid;  /**< Must be set to true if rsrq_indicator is being passed */
  nas_rsrq_indicator_type_v01 rsrq_indicator;

  /* Optional */
  /*  ECIO Threshold */
  uint8_t ecio_threshold_indicator_valid;  /**< Must be set to true if ecio_threshold_indicator is being passed */
  nas_ecio_indicator_threshold_type_v01 ecio_threshold_indicator;

  /* Optional */
  /*  SINR Threshold */
  uint8_t sinr_threshold_indicator_valid;  /**< Must be set to true if sinr_threshold_indicator is being passed */
  nas_sinr_indicator_threshold_type_v01 sinr_threshold_indicator;

  /* Optional */
  /*  LTE SNR Delta */
  uint8_t lte_snr_delta_indicator_valid;  /**< Must be set to true if lte_snr_delta_indicator is being passed */
  nas_snr_indicator_type_v01 lte_snr_delta_indicator;

  /* Optional */
  /*  RSRP Delta */
  uint8_t lte_rsrp_delta_indicator_valid;  /**< Must be set to true if lte_rsrp_delta_indicator is being passed */
  nas_rsrp_indicator_type_v01 lte_rsrp_delta_indicator;
}nas_set_event_report_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Sets the NAS state reporting conditions for the requesting
              control point. (Deprecated) */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_set_event_report_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_RADIO_IF_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_RADIO_IF_NO_SVC_V01 = 0x00, 
  NAS_RADIO_IF_CDMA_1X_V01 = 0x01, 
  NAS_RADIO_IF_CDMA_1XEVDO_V01 = 0x02, 
  NAS_RADIO_IF_AMPS_V01 = 0x03, 
  NAS_RADIO_IF_GSM_V01 = 0x04, 
  NAS_RADIO_IF_UMTS_V01 = 0x05, 
  NAS_RADIO_IF_WLAN_V01 = 0x06, 
  NAS_RADIO_IF_GPS_V01 = 0x07, 
  NAS_RADIO_IF_LTE_V01 = 0x08, 
  NAS_RADIO_IF_TDSCDMA_V01 = 0x09, 
  NAS_RADIO_IF_NO_CHANGE_V01 = -1, 
  NAS_RADIO_IF_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_radio_if_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  int8_t sig_strength;
  /**<   Received signal strength in dBm:                           \n
       - For CDMA and UMTS, this indicates forward link pilot Ec \n
       - For GSM, this indicates received signal strength \n
       - For LTE, this indicates the total received wideband power observed by the UE
     */

  nas_radio_if_enum_v01 radio_if;
  /**<   Radio interface technology of the signal being measured. Values: \n
       -0x00 -- RADIO_IF_NO_SVC      -- None (no service) \n
       -0x01 -- RADIO_IF_CDMA_1X     -- cdma2000@latexonly\textsuperscript{\textregistered}@endlatexonly 1X \n
       -0x02 -- RADIO_IF_CDMA_1XEVDO -- cdma2000 HRPD (1xEV-DO)     \n 
       -0x03 -- RADIO_IF_AMPS        -- AMPS \n
       -0x04 -- RADIO_IF_GSM         -- GSM \n
       -0x05 -- RADIO_IF_UMTS        -- UMTS \n
       -0x08 -- RADIO_IF_LTE         -- LTE
   */
}nas_signal_strength_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_ACTIVE_BAND_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_ACTIVE_BAND_BC_0_V01 = 0, 
  NAS_ACTIVE_BAND_BC_1_V01 = 1, 
  NAS_ACTIVE_BAND_BC_3_V01 = 3, 
  NAS_ACTIVE_BAND_BC_4_V01 = 4, 
  NAS_ACTIVE_BAND_BC_5_V01 = 5, 
  NAS_ACTIVE_BAND_BC_6_V01 = 6, 
  NAS_ACTIVE_BAND_BC_7_V01 = 7, 
  NAS_ACTIVE_BAND_BC_8_V01 = 8, 
  NAS_ACTIVE_BAND_BC_9_V01 = 9, 
  NAS_ACTIVE_BAND_BC_10_V01 = 10, 
  NAS_ACTIVE_BAND_BC_11_V01 = 11, 
  NAS_ACTIVE_BAND_BC_12_V01 = 12, 
  NAS_ACTIVE_BAND_BC_13_V01 = 13, 
  NAS_ACTIVE_BAND_BC_14_V01 = 14, 
  NAS_ACTIVE_BAND_BC_15_V01 = 15, 
  NAS_ACTIVE_BAND_BC_16_V01 = 16, 
  NAS_ACTIVE_BAND_BC_17_V01 = 17, 
  NAS_ACTIVE_BAND_BC_18_V01 = 18, 
  NAS_ACTIVE_BAND_BC_19_V01 = 19, 
  NAS_ACTIVE_BAND_GSM_450_V01 = 40, 
  NAS_ACTIVE_BAND_GSM_480_V01 = 41, 
  NAS_ACTIVE_BAND_GSM_750_V01 = 42, 
  NAS_ACTIVE_BAND_GSM_850_V01 = 43, 
  NAS_ACTIVE_BAND_GSM_900_EXTENDED_V01 = 44, 
  NAS_ACTIVE_BAND_GSM_900_PRIMARY_V01 = 45, 
  NAS_ACTIVE_BAND_GSM_900_RAILWAYS_V01 = 46, 
  NAS_ACTIVE_BAND_GSM_1800_V01 = 47, 
  NAS_ACTIVE_BAND_GSM_1900_V01 = 48, 
  NAS_ACTIVE_BAND_WCDMA_2100_V01 = 80, 
  NAS_ACTIVE_BAND_WCDMA_PCS_1900_V01 = 81, 
  NAS_ACTIVE_BAND_WCDMA_DCS_1800_V01 = 82, 
  NAS_ACTIVE_BAND_WCDMA_1700_US_V01 = 83, 
  NAS_ACTIVE_BAND_WCDMA_850_V01 = 84, 
  NAS_ACTIVE_BAND_WCDMA_800_V01 = 85, 
  NAS_ACTIVE_BAND_WCDMA_2600_V01 = 86, 
  NAS_ACTIVE_BAND_WCDMA_900_V01 = 87, 
  NAS_ACTIVE_BAND_WCDMA_1700_JAPAN_V01 = 88, 
  NAS_ACTIVE_BAND_WCDMA_1500_JAPAN_V01 = 90, 
  NAS_ACTIVE_BAND_WCDMA_850_JAPAN_V01 = 91, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_1_V01 = 120, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_2_V01 = 121, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_3_V01 = 122, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_4_V01 = 123, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_5_V01 = 124, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_6_V01 = 125, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_7_V01 = 126, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_8_V01 = 127, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_9_V01 = 128, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_10_V01 = 129, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_11_V01 = 130, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_12_V01 = 131, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_13_V01 = 132, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_14_V01 = 133, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_17_V01 = 134, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_33_V01 = 135, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_34_V01 = 136, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_35_V01 = 137, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_36_V01 = 138, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_37_V01 = 139, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_38_V01 = 140, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_39_V01 = 141, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_40_V01 = 142, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_18_V01 = 143, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_19_V01 = 144, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_20_V01 = 145, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_21_V01 = 146, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_24_V01 = 147, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_25_V01 = 148, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_41_V01 = 149, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_42_V01 = 150, 
  NAS_ACTIVE_BAND_E_UTRA_OPERATING_BAND_43_V01 = 151, 
  NAS_ACTIVE_BAND_TDSCDMA_BAND_A_V01 = 200, 
  NAS_ACTIVE_BAND_TDSCDMA_BAND_B_V01 = 201, 
  NAS_ACTIVE_BAND_TDSCDMA_BAND_C_V01 = 202, 
  NAS_ACTIVE_BAND_TDSCDMA_BAND_D_V01 = 203, 
  NAS_ACTIVE_BAND_TDSCDMA_BAND_E_V01 = 204, 
  NAS_ACTIVE_BAND_TDSCDMA_BAND_F_V01 = 205, 
  NAS_ACTIVE_BAND_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_active_band_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  nas_radio_if_enum_v01 radio_if;
  /**<   Radio interface currently in use. Values:  \n
       - 0x01 -- cdma2000 1X             \n
       - 0x02 -- cdma2000 HRPD (1xEV-DO) \n
       - 0x03 -- AMPS \n
       - 0x04 -- GSM \n
       - 0x05 -- UMTS \n
       - 0x08 -- LTE \n
       - 0x09 -- TD-SCDMA
   */

  nas_active_band_enum_v01 active_band;
  /**<   Active band class (see Table @latexonly\ref{tbl:bandClass}@endlatexonly 
      for details). Values: \n
      - 00 to 39   -- CDMA band classes  \n
      - 40 to 79   -- GSM band classes   \n
      - 80 to 91   -- WCDMA band classes \n
      - 120 to 151 -- LTE band classes   \n
      - 200 to 205 -- TD-SCDMA band classes
   */

  uint16_t active_channel;
  /**<   Active channel. If the channel is not relevant to the
      technology, a value of 0 will be returned.
  */
}nas_rf_band_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_NETWORK_SERVICE_DOMAIN_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_CIRCUIT_SWITCHED_V01 = 0x01, 
  NAS_PACKET_SWITCHED_V01 = 0x02, 
  NAS_CIRCUIT_AND_PACKET_SWITCHED_V01 = 0x03, 
  NAS_NETWORK_SERVICE_DOMAIN_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_network_service_domain_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  nas_network_service_domain_enum_v01 service_domain;
  /**<   Network service domain that was rejected. Possible values: \n
       - 1 -- CIRCUIT_SWITCHED \n
       - 2 -- PACKET_SWITCHED \n
       - 3 -- CIRCUIT_AND_PACKET_SWITCHED
   */

  uint16_t reject_cause;
  /**<   Reject cause; see [S5, Sections 10.5.3.6 and 10.5.5.14] and 
       [S16, Section 9.9.3.9].
   */
}nas_registration_reject_reason_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t rssi;
  /**<   RSSI represented as a positive value; control points need to
       convert this to negative to get actual value in dBm: \n
       - For CDMA and UMTS, this indicates forward link pilot Ec \n
       - For GSM, this indicates received signal strength
   */

  nas_radio_if_enum_v01 radio_if;
  /**<   Radio interface technology of the signal being measured. Values:  \n
       -0x00 -- RADIO_IF_NO_SVC      -- None (no service) \n
       -0x01 -- RADIO_IF_CDMA_1X     -- cdma2000 1X             \n
       -0x02 -- RADIO_IF_CDMA_1XEVDO -- cdma2000 HRPD (1xEV-DO) \n
       -0x03 -- RADIO_IF_AMPS        -- AMPS \n
       -0x04 -- RADIO_IF_GSM         -- GSM \n
       -0x05 -- RADIO_IF_UMTS        -- UMTS \n
       -0x08 -- RADIO_IF_LTE         -- LTE
   */
}nas_rssi_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t ecio;
  /**<   ECIO value representing negative 0.5 dBm increments, i.e., 
       2 means -1 dBm (14 means -7 dBm, 63 means -31.5 dBm).
   */

  nas_radio_if_enum_v01 radio_if;
  /**<   Radio interface technology of the signal being measured. Values:  \n
       -0x00 -- RADIO_IF_NO_SVC      -- None (no service) \n
       -0x01 -- RADIO_IF_CDMA_1X     -- cdma2000 1X             \n
       -0x02 -- RADIO_IF_CDMA_1XEVDO -- cdma2000 HRPD (1xEV-DO) \n
       -0x03 -- RADIO_IF_AMPS        -- AMPS \n
       -0x04 -- RADIO_IF_GSM         -- GSM \n
       -0x05 -- RADIO_IF_UMTS        -- UMTS 
   */
}nas_ecio_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t error_rate;
  /**<   Error rate value corresponds to the RAT that is currently registered. \n
         For CDMA, the error rate reported is Frame Error Rate: \n
         - Valid error rate values between 1 and 10000 are returned to indicate 
            percentage, e.g., a value of 300 means the error rate is 3% \n
         - A value of 0xFFFF indicates that the error rate is unknown or 
            unavailable \n
         For HDR, the error rate reported is Packet Error Rate: \n
         - Valid error rate values between 1 and 10000 are returned to indicate 
            percentage, e.g., a value of 300 means the error rate is 3% \n
         - A value of 0xFFFF indicates that the error rate is unknown or 
            unavailable \n
         For GSM, the error rate reported is Bit Error Rate: \n
         - Valid values are 0, 100, 200, 300, 400, 500, 600, and 700 \n
         - The reported value divided by 100 gives the error rate as an RxQual 
            value as defined in [S13, Section 8.2.4],  e.g., a value of 300 
            represents an RxQual value of 3 \n
         - A value of 25500 indicates No Data \n
         For WCDMA, the error rate reported is Block Error Rate (BLER): \n
         - Valid values are 1 to 10000 \n
         - The reported value divided by 100 provides the error rate in 
            percentages, e.g., a value of 300 represents a BLER of 3% \n
         - A value of 0 indicates No Data
   */

  nas_radio_if_enum_v01 radio_if;
  /**<   Radio interface technology of the signal being measured. Values:  \n
       -0x00 -- RADIO_IF_NO_SVC      -- None (no service) \n
       -0x01 -- RADIO_IF_CDMA_1X     -- cdma2000 1X             \n
       -0x02 -- RADIO_IF_CDMA_1XEVDO -- cdma2000 HRPD (1xEV-DO) \n
       -0x03 -- RADIO_IF_AMPS        -- AMPS \n
       -0x04 -- RADIO_IF_GSM         -- GSM \n
       -0x05 -- RADIO_IF_UMTS        -- UMTS
   */
}nas_error_rate_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  int8_t rsrq;
  /**<   RSRQ value in dB (signed integer value).
       Range: -3 to -20 (-3 means -3 dB, -20 means -20 dB).
   */

  uint8_t radio_if;
  /**<   Radio interface technology of the signal being measured. Values: \n
       - 0x08 -- LTE
   */
}nas_rsrq_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_SINR_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_SINR_LEVEL_0_V01 = 0x00, 
  NAS_SINR_LEVEL_1_V01 = 0x01, 
  NAS_SINR_LEVEL_2_V01 = 0x02, 
  NAS_SINR_LEVEL_3_V01 = 0x03, 
  NAS_SINR_LEVEL_4_V01 = 0x04, 
  NAS_SINR_LEVEL_5_V01 = 0x05, 
  NAS_SINR_LEVEL_6_V01 = 0x06, 
  NAS_SINR_LEVEL_7_V01 = 0x07, 
  NAS_SINR_LEVEL_8_V01 = 0x08, 
  NAS_SINR_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_sinr_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Indication Message; Indicates the NAS state change. (Deprecated) */
typedef struct {

  /* Optional */
  /*  Signal Strength */
  uint8_t signal_strength_valid;  /**< Must be set to true if signal_strength is being passed */
  nas_signal_strength_type_v01 signal_strength;

  /* Optional */
  /*  RF Band Information List */
  uint8_t rf_band_info_list_valid;  /**< Must be set to true if rf_band_info_list is being passed */
  uint32_t rf_band_info_list_len;  /**< Must be set to # of elements in rf_band_info_list */
  nas_rf_band_info_type_v01 rf_band_info_list[NAS_RADIO_IF_LIST_MAX_V01];

  /* Optional */
  /*  Registration Reject Reason** */
  uint8_t registration_reject_reason_valid;  /**< Must be set to true if registration_reject_reason is being passed */
  nas_registration_reject_reason_type_v01 registration_reject_reason;

  /* Optional */
  /*  RSSI */
  uint8_t rssi_valid;  /**< Must be set to true if rssi is being passed */
  nas_rssi_type_v01 rssi;

  /* Optional */
  /*  ECIO */
  uint8_t ecio_valid;  /**< Must be set to true if ecio is being passed */
  nas_ecio_type_v01 ecio;

  /* Optional */
  /*  IO* */
  uint8_t io_valid;  /**< Must be set to true if io is being passed */
  int32_t io;
  /**<   Received IO in dBm. IO is only applicable for 1xEV-DO.
   */

  /* Optional */
  /*  SINR* */
  uint8_t sinr_valid;  /**< Must be set to true if sinr is being passed */
  nas_sinr_enum_v01 sinr;
  /**<   SINR level. SINR is only applicable for 1xEV-DO. 
       Valid levels are 0 to 8, where the maximum value for:        \n
       - 0x00 -- SINR_LEVEL_0 is -9 dB     \n
       - 0x01 -- SINR_LEVEL_1 is -6 dB     \n
       - 0x02 -- SINR_LEVEL_2 is -4.5 dB   \n
       - 0x03 -- SINR_LEVEL_3 is -3 dB     \n
       - 0x04 -- SINR_LEVEL_4 is -2 dB     \n
       - 0x05 -- SINR_LEVEL_5 is +1 dB     \n
       - 0x06 -- SINR_LEVEL_6 is +3 dB     \n
       - 0x07 -- SINR_LEVEL_7 is +6 dB     \n
       - 0x08 -- SINR_LEVEL_8 is +9 dB
   */

  /* Optional */
  /*  Error Rate */
  uint8_t error_rate_valid;  /**< Must be set to true if error_rate is being passed */
  nas_error_rate_type_v01 error_rate;

  /* Optional */
  /*  RSRQ** */
  uint8_t rsrq_valid;  /**< Must be set to true if rsrq is being passed */
  nas_rsrq_type_v01 rsrq;

  /* Optional */
  /*  LTE SNR */
  uint8_t snr_valid;  /**< Must be set to true if snr is being passed */
  int16_t snr;
  /**<   
     LTE SNR level as a scaled integer in units of 0.1 dB; 
     e.g., -16 dB has a value of -160 and 24.6 dB has a value of 246.
       */

  /* Optional */
  /*  LTE RSRP */
  uint8_t rsrp_valid;  /**< Must be set to true if rsrp is being passed */
  int16_t rsrp;
  /**<  
     Current LTE RSRP in dBm as measured by L1. 
     Range: -44 to -140 (-44 means -44 dBm, -140 means -140 dBm).
   */
}nas_event_report_ind_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t reg_network_reject;
  /**<   Controls the reporting of QMI_NAS_NETWORK_REJECT_IND. Values: \n
       - 0x00 -- Disable \n
       - 0x01 -- Enable
   */

  uint8_t suppress_sys_info;
  /**<   Controls the reporting of QMI_NAS_SYS_INFO_IND when only the reject_cause 
       field has changed. Values: \n
       - 0x00 -- Do not suppress \n
       - 0x01 -- Suppress
   */
}nas_reg_network_reject_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Sets the registration state for different
              QMI_NAS indications for the requesting control point.
              \label{idl:indicationRegister} */
typedef struct {

  /* Optional */
  /*  System Selection Preference */
  uint8_t reg_sys_sel_pref_valid;  /**< Must be set to true if reg_sys_sel_pref is being passed */
  uint8_t reg_sys_sel_pref;
  /**<   Values: \n
       - 0x00 -- Disable \n
       - 0x01 -- Enable
   */

  /* Optional */
  /*  DDTM Events */
  uint8_t reg_ddtm_events_valid;  /**< Must be set to true if reg_ddtm_events is being passed */
  uint8_t reg_ddtm_events;
  /**<   Values: \n
       - 0x00 -- Disable \n
       - 0x01 -- Enable
   */

  /* Optional */
  /*  Serving System Events */
  uint8_t req_serving_system_valid;  /**< Must be set to true if req_serving_system is being passed */
  uint8_t req_serving_system;
  /**<   Values: \n
       - 0x00 -- Disable \n
       - 0x01 -- Enable
   */

  /* Optional */
  /*  Dual Standby Preference */
  uint8_t dual_standby_pref_valid;  /**< Must be set to true if dual_standby_pref is being passed */
  uint8_t dual_standby_pref;
  /**<   Values: \n
       - 0x00 -- Disable \n
       - 0x01 -- Enable
   */

  /* Optional */
  /*  Subscription Info */
  uint8_t subscription_info_valid;  /**< Must be set to true if subscription_info is being passed */
  uint8_t subscription_info;
  /**<   Values: \n
       - 0x00 -- Disable \n
       - 0x01 -- Enable 
   */

  /* Optional */
  /*  Network Time */
  uint8_t reg_network_time_valid;  /**< Must be set to true if reg_network_time is being passed */
  uint8_t reg_network_time;
  /**<    Values: \n
       - 0x00 -- Disable \n
       - 0x01 -- Enable 
   */

  /* Optional */
  /*  Sys Info */
  uint8_t sys_info_valid;  /**< Must be set to true if sys_info is being passed */
  uint8_t sys_info;
  /**<    Values: \n
       - 0x00 -- Disable \n
       - 0x01 -- Enable 
   */

  /* Optional */
  /*  Signal Strength  */
  uint8_t sig_info_valid;  /**< Must be set to true if sig_info is being passed */
  uint8_t sig_info;
  /**<    Values: \n
       - 0x00 -- Disable \n
       - 0x01 -- Enable 
   */

  /* Optional */
  /*  Error Rate */
  uint8_t err_rate_valid;  /**< Must be set to true if err_rate is being passed */
  uint8_t err_rate;
  /**<    Values: \n
       - 0x00 -- Disable \n
       - 0x01 -- Enable 
   */

  /* Optional */
  /*  HDR New UATI Assigned  */
  uint8_t reg_hdr_uati_valid;  /**< Must be set to true if reg_hdr_uati is being passed */
  uint8_t reg_hdr_uati;
  /**<   Controls the reporting of QMI_NAS_HDR_UATI_UPDATE_IND. Values: \n
       - 0x00 -- Disable (default value) \n
       - 0x01 -- Enable 
   */

  /* Optional */
  /*  HDR Session Closed */
  uint8_t reg_hdr_session_close_valid;  /**< Must be set to true if reg_hdr_session_close is being passed */
  uint8_t reg_hdr_session_close;
  /**<   Controls the reporting of QMI_NAS_HDR_SESSION_CLOSE_IND. Values: \n  
       - 0x00 -- Disable (default value) \n
       - 0x01 -- Enable 
   */

  /* Optional */
  /*  Managed Roaming */
  uint8_t reg_managed_roaming_valid;  /**< Must be set to true if reg_managed_roaming is being passed */
  uint8_t reg_managed_roaming;
  /**<   Controls the reporting of QMI_NAS_MANAGED_ROAMING_IND. Values: \n
       - 0x00 -- Disable (default value) \n
       - 0x01 -- Enable
   */

  /* Optional */
  /*  Current PLMN Name */
  uint8_t reg_current_plmn_name_valid;  /**< Must be set to true if reg_current_plmn_name is being passed */
  uint8_t reg_current_plmn_name;
  /**<   Controls the reporting of QMI_NAS_CURRENT_PLMN_NAME_IND. Values: \n
       - 0x00 -- Disable (default value) \n
       - 0x01 -- Enable
   */

  /* Optional */
  /*  eMBMS Status */
  uint8_t reg_embms_status_valid;  /**< Must be set to true if reg_embms_status is being passed */
  uint8_t reg_embms_status;
  /**<   Controls the reporting of QMI_NAS_EMBMS_STATUS_IND. Values: \n
       - 0x00 -- Disable (default value) \n
       - 0x01 -- Enable
   */

  /* Optional */
  /*  RF Band Information */
  uint8_t reg_rf_band_info_valid;  /**< Must be set to true if reg_rf_band_info is being passed */
  uint8_t reg_rf_band_info;
  /**<   Controls the reporting of QMI_NAS_RF_BAND_INFO_IND. Values: \n
       - 0x00 -- Disable (default value) \n
       - 0x01 -- Enable
   */

  /* Optional */
  /*  Network Reject Information */
  uint8_t network_reject_valid;  /**< Must be set to true if network_reject is being passed */
  nas_reg_network_reject_v01 network_reject;

  /* Optional */
  /*  Operator name data  */
  uint8_t reg_operator_name_data_valid;  /**< Must be set to true if reg_operator_name_data is being passed */
  uint8_t reg_operator_name_data;
  /**<   Controls the reporting of QMI_NAS_OPERATOR_NAME_DATA_IND. Values: \n
       - 0x00 -- Disable \n
       - 0x01 -- Enable (default value) 
   */

  /* Optional */
  /*  CSP PLMN mode bit */
  uint8_t reg_csp_plmn_mode_bit_valid;  /**< Must be set to true if reg_csp_plmn_mode_bit is being passed */
  uint8_t reg_csp_plmn_mode_bit;
  /**<   Controls the reporting of QMI_NAS_CSP_PLMN_MODE_BIT_IND. Values: \n
       - 0x00 -- Disable\n
       - 0x01 -- Enable (default value) 
   */

  /* Optional */
  /*  RTRE configuration */
  uint8_t reg_rtre_cfg_valid;  /**< Must be set to true if reg_rtre_cfg is being passed */
  uint8_t reg_rtre_cfg;
  /**<   Controls reporting of QMI_NAS_RTRE_CONFIG_IND 
       - 0x00 - Disable (default value)
       - 0x01 - Enable
    */

#ifdef FEATURE_P_VZW_CS_AUTH_REJ_DISPLAY
  /* Optional */
  /*  Lock Until Power-Cycled Order */
  uint8_t reg_lock_mode_valid;  /**< Must be set to true if reg_lock_mode is being passed */
  uint8_t reg_lock_mode;
  /**<   Controls reporting of QMI_NAS_LOCK_MODE_IND
       - 0x00 - DISABLE (default value)
       - 0x01 - ENABLE
   */

  /* Optional */
  /*  Maintenance Required Order */
  uint8_t reg_maint_request_valid;  /**< Must be set to true if reg_maint_request is being passed */
  uint8_t reg_maint_request;
  /**<   Controls reporting of QMI_NAS_MAINT_REQ_IND
       - 0x00 - DISABLE (default value)
       - 0x01 - ENABLE
   */
#endif /* FEATURE_P_VZW_CS_AUTH_REJ_DISPLAY */
}nas_indication_register_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Sets the registration state for different
              QMI_NAS indications for the requesting control point.
              \label{idl:indicationRegister} */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_indication_register_resp_msg_v01;  /* Message */
/**
    @}
  */

typedef uint16_t nas_get_sig_str_req_mask_type_v01;
#define QMI_NAS_REQUEST_SIG_INFO_RSSI_MASK_V01 ((nas_get_sig_str_req_mask_type_v01)0x01)
#define QMI_NAS_REQUEST_SIG_INFO_ECIO_MASk_V01 ((nas_get_sig_str_req_mask_type_v01)0x02)
#define QMI_NAS_REQUEST_SIG_INFO_IO_MASK_V01 ((nas_get_sig_str_req_mask_type_v01)0x04)
#define QMI_NAS_REQUEST_SIG_INFO_SINR_MASK_V01 ((nas_get_sig_str_req_mask_type_v01)0x08)
#define QMI_NAS_REQUEST_SIG_INFO_ERROR_RATE_MASK_V01 ((nas_get_sig_str_req_mask_type_v01)0x10)
#define QMI_NAS_REQUEST_SIG_INFO_RSRQ_MASK_V01 ((nas_get_sig_str_req_mask_type_v01)0x20)
#define QMI_NAS_REQUEST_SIG_INFO_LTE_SNR_MASK_V01 ((nas_get_sig_str_req_mask_type_v01)0x40)
#define QMI_NAS_REQUEST_SIG_INFO_LTE_RSRP_MASK_V01 ((nas_get_sig_str_req_mask_type_v01)0x80)
/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Queries the current signal strength as measured by the device.
              (Deprecated) */
typedef struct {

  /* Optional */
  /*  Request Mask */
  uint8_t request_mask_valid;  /**< Must be set to true if request_mask is being passed */
  nas_get_sig_str_req_mask_type_v01 request_mask;
  /**<   Request additional signal information for: \n
       Bit 0 (0x01) -- QMI_NAS_REQUEST_SIG_INFO_ RSSI_MASK; values: \n
       - 0 -- Do not request additional information for RSSI \n
       - 1 -- Request additional information for RSSI

       Bit 1 (0x02) -- QMI_NAS_REQUEST_SIG_INFO_ ECIO_MASK; values: \n
       - 0 -- Do not request additional information for ECIO \n
       - 1 -- Request additional information for ECIO

       Bit 2 (0x04) -- QMI_NAS_REQUEST_SIG_INFO_ IO_MASK; values: \n
       - 0 -- Do not request additional information for IO \n
       - 1 -- Request additional information for IO

       Bit 3 (0x08) -- QMI_NAS_REQUEST_SIG_INFO_ SINR_MASK; values: \n
       - 0 -- Do not request additional information for SINR \n
       - 1 -- Request additional information for SINR
   
       Bit 4 (0x10) -- QMI_NAS_REQUEST_SIG_INFO_ ERROR_RATE_MASK; values: \n
       - 0 -- Do not request additional information for Error Rate \n
       - 1 -- Request additional information for Error Rate

       Bit 5 (0x20) -- QMI_NAS_REQUEST_SIG_INFO_ RSRQ_MASK; values: \n
       - 0 -- Do not request additional information for RSRQ \n
       - 1 -- Request additional information for RSRQ

       Bit 6 (0x40) -- QMI_NAS_REQUEST_SIG_INFO_ LTE_SNR_MASK; values: \n
       - 0 -- Do not request additional information for LTE SNR \n
       - 1 -- Request additional information for LTE SNR 

       Bit 7 (0x80) -- QMI_NAS_REQUEST_SIG_INFO_ LTE_RSRP_MASK; values: \n
       - 0 -- Do not request additional information for LTE RSRP \n
       - 1 -- Request additional information for LTE RSRP 
   */
}nas_get_signal_strength_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  int8_t sig_strength;
  /**<   Received signal strength in dBm:                             \n
       - For CDMA and UMTS, this indicates forward link pilot Ec   \n
       - For GSM, this indicates received signal strength
   */

  nas_radio_if_enum_v01 radio_if;
  /**<   Radio interface technology of the signal being measured. Values: \n
       -0x01 -- RADIO_IF_CDMA_1X         -- cdma2000 1X                 \n
       -0x02 -- RADIO_IF_CDMA_1XEVDO     -- cdma2000 HRPD (1xEV-DO)
   */
}nas_signal_strength_list_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Queries the current signal strength as measured by the device.
              (Deprecated) */
typedef struct {

  /* Mandatory */
  /*  Signal Strength */
  nas_signal_strength_type_v01 signal_strength;

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type. Contains the following data members:
     - qmi_result_type -- QMI_RESULT_SUCCESS or QMI_RESULT_FAILURE \n
     - qmi_error_type  -- Error code. Possible error code values are described in
                          the error codes section of each message definition.
    */

  /* Optional */
  /*  Signal Strength List */
  uint8_t signal_strength_list_valid;  /**< Must be set to true if signal_strength_list is being passed */
  uint32_t signal_strength_list_len;  /**< Must be set to # of elements in signal_strength_list */
  nas_signal_strength_list_type_v01 signal_strength_list[NAS_SIG_STRENGTH_LIST_MAX_V01];

  /* Optional */
  /*  RSSI List */
  uint8_t rssi_valid;  /**< Must be set to true if rssi is being passed */
  uint32_t rssi_len;  /**< Must be set to # of elements in rssi */
  nas_rssi_type_v01 rssi[NAS_RSSI_LIST_MAX_V01];

  /* Optional */
  /*  ECIO List */
  uint8_t ecio_valid;  /**< Must be set to true if ecio is being passed */
  uint32_t ecio_len;  /**< Must be set to # of elements in ecio */
  nas_ecio_type_v01 ecio[NAS_ECIO_LIST_MAX_V01];

  /* Optional */
  /*  IO */
  uint8_t io_valid;  /**< Must be set to true if io is being passed */
  uint32_t io;
  /**<   Received IO in dBm. IO is only applicable for 1xEV-DO.
   */

  /* Optional */
  /*  SINR */
  uint8_t sinr_valid;  /**< Must be set to true if sinr is being passed */
  nas_sinr_enum_v01 sinr;
  /**<   SINR level. SINR is only applicable for 1xEV-DO.
       Valid levels are 0 to 8, where the maximum value for:        \n
       - 0x00 -- SINR_LEVEL_0 is -9 dB     \n
       - 0x01 -- SINR_LEVEL_1 is -6 dB     \n
       - 0x02 -- SINR_LEVEL_2 is -4.5 dB   \n
       - 0x03 -- SINR_LEVEL_3 is -3 dB     \n
       - 0x04 -- SINR_LEVEL_4 is -2 dB     \n
       - 0x05 -- SINR_LEVEL_5 is +1 dB     \n
       - 0x06 -- SINR_LEVEL_6 is +3 dB     \n
       - 0x07 -- SINR_LEVEL_7 is +6 dB     \n
       - 0x08 -- SINR_LEVEL_8 is +9 dB
   */

  /* Optional */
  /*  Error Rate List */
  uint8_t error_rate_valid;  /**< Must be set to true if error_rate is being passed */
  uint32_t error_rate_len;  /**< Must be set to # of elements in error_rate */
  nas_error_rate_type_v01 error_rate[NAS_ERROR_RATE_LIST_MAX_V01];

  /* Optional */
  /*  RSRQ */
  uint8_t rsrq_valid;  /**< Must be set to true if rsrq is being passed */
  nas_rsrq_type_v01 rsrq;

  /* Optional */
  /*  LTE SNR */
  uint8_t snr_valid;  /**< Must be set to true if snr is being passed */
  int16_t snr;
  /**<   LTE SNR level as a scaled integer in units of 0.1 dB; 
       e.g., -16 dB has a value of -160 and 24.6 dB has a value of 246.
       LTE SNR is included only when the current serving system is LTE.
       */

  /* Optional */
  /*  LTE RSRP */
  uint8_t lte_rsrp_valid;  /**< Must be set to true if lte_rsrp is being passed */
  int16_t lte_rsrp;
  /**<   Current LTE RSRP in dBm as measured by L1. 
       Range: -44 to -140 (-44 means -44 dBm, -140 means -140 dBm).
       LTE RSRP is included only if the current serving system is LTE.
     */
}nas_get_signal_strength_resp_msg_v01;  /* Message */
/**
    @}
  */

typedef uint8_t nas_network_type_mask_type_v01;
#define NAS_NETWORK_TYPE_GSM_ONLY_V01 ((nas_network_type_mask_type_v01)0x01)
#define NAS_NETWORK_TYPE_WCDMA_ONLY_V01 ((nas_network_type_mask_type_v01)0x02)
#define NAS_NETWORK_TYPE_LTE_ONLY_V01 ((nas_network_type_mask_type_v01)0x04)
#define NAS_NETWORK_TYPE_TDSCDMA_ONLY_V01 ((nas_network_type_mask_type_v01)0x08)

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t mobile_country_code;
  /**<   A 16-bit integer representation of MCC. Range: 0 to 999.
   */

  uint16_t mobile_network_code;
  /**<   A 16-bit integer representation of MNC. Range: 0 to 999.
   */

  uint8_t network_status;
  /**<   Status of the network identified by MCC and MNC preceding it.
       The status is encoded in a bitmapped value as follows: \n
       Bits 0-1 -- QMI_NAS_NETWORK_IN_USE_STATUS_ BITS    -- In-use status       \n
       - 0 -- QMI_NAS_NETWORK_IN_USE_STATUS_ UNKNOWN          -- Unknown         \n
       - 1 -- QMI_NAS_NETWORK_IN_USE_STATUS_ CURRENT_SERVING  -- Current serving \n
       - 2 -- QMI_NAS_NETWORK_IN_USE_STATUS_ AVAILABLE        -- Available
       
       Bits 2-3 -- QMI_NAS_NETWORK_ROAMING_ STATUS_BITS   -- Roaming status      \n
       - 0 -- QMI_NAS_NETWORK_ROAMING_STATUS_ UNKNOWN         -- Unknown         \n
       - 1 -- QMI_NAS_NETWORK_ROAMING_STATUS_ HOME            -- Home            \n
       - 2 -- QMI_NAS_NETWORK_ROAMING_STATUS_ ROAM            -- Roam

       Bits 4-5 -- QMI_NAS_NETWORK_FORBIDDEN_ STATUS_BITS -- Forbidden status    \n
       - 0 -- QMI_NAS_NETWORK_FORBIDDEN_STATUS_ UNKNOWN       -- Unknown         \n
       - 1 -- QMI_NAS_NETWORK_FORBIDDEN_STATUS_ FORBIDDEN     -- Forbidden       \n
       - 2 -- QMI_NAS_NETWORK_FORBIDDEN_STATUS_ NOT_FORBIDDEN -- Not forbidden

       Bits 6-7 -- QMI_NAS_NETWORK_PREFERRED_ STATUS_BITS -- Preferred status    \n
       - 0 -- QMI_NAS_NETWORK_PREFERRED_STATUS_ UNKNOWN       -- Unknown         \n
       - 1 -- QMI_NAS_NETWORK_PREFERRED_STATUS_ PREFERRED     -- Preferred       \n
       - 2 -- QMI_NAS_NETWORK_PREFERRED_STATUS_ NOT_PREFERRED -- Not preferred
   */

  char network_description[NAS_NETWORK_DESCRIPTION_MAX_V01 + 1];
  /**<   An optional string containing the network name or description.
   */
}nas_3gpp_network_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t mcc;
  /**<   A 16-bit integer representation of MCC. Range: 0 to 999.
   */

  uint16_t mnc;
  /**<   A 16-bit integer representation of MNC. Range: 0 to 999.
   */

  uint8_t rat;
  /**<   Radio access technology. Values: \n
       - 0x04 -- GERAN \n
       - 0x05 -- UMTS \n
       - 0x08 -- LTE \n
       - 0x09 -- TD-SCDMA 
   */
}nas_network_radio_access_technology_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t mcc;
  /**<   A 16-bit integer representation of MCC. Range: 0 to 999.
   */

  uint16_t mnc;
  /**<   A 16-bit integer representation of MNC. Range: 0 to 999.
   */

  /*  MNC PCS digit include status */
  uint8_t mnc_includes_pcs_digit;
  /**<   This field is used to interpret the length of the corresponding
       MNC reported in the TLVs (in this table) with an mnc or 
       mobile_network_code field. Values: \n

       - TRUE  -- MNC is a three-digit value; e.g., a reported value of 
                  90 corresponds to an MNC value of 090  \n
       - FALSE -- MNC is a two-digit value; e.g., a reported value of 
                  90 corresponds to an MNC value of 90
   */
}nas_mnc_pcs_digit_include_status_type_v01;  /* Type */
/**
    @}
  */


/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t mobile_country_code;
  /**<   A 16-bit integer representation of MCC. Range: 0 to 999.
   */

  uint16_t mobile_network_code;
  /**<   A 16-bit integer representation of MNC. Range: 0 to 999.
   */

  nas_radio_if_enum_v01 radio_access_technology;
  /**<   Radio access technology for which to register. Values: \n
        -0x04 -- RADIO_IF_GSM -- GSM \n
        -0x05 -- RADIO_IF_UMTS -- UMTS \n 
        -0x08 -- RADIO_IF_LTE -- LTE \n
        -  -1 -- RADIO_IF_NO_CHANGE -- No change in the mode preference
   */
}nas_manual_network_register_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_REGISTER_ACTION_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_AUTO_REGISTER_V01 = 0x01, 
  NAS_MANUAL_REGISTER_V01 = 0x02, 
  NAS_REGISTER_ACTION_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_register_action_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_CHANGE_DURATION_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_POWER_CYCLE_V01 = 0x00, 
  NAS_PERMANENT_V01 = 0x01, 
  NAS_CHANGE_DURATION_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_change_duration_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Initiates a network registration. (Deprecated) */
typedef struct {

  /* Mandatory */
  /*  Register Action */
  nas_register_action_enum_v01 register_action;
  /**<    Specifies one of the following actions: \n
        - 0x01 -- NAS_AUTO_REGISTER -- Device registers according
          to its provisioning; optional TLVs supplied with the command
          are ignored \n
        - 0x02 -- NAS_MANUAL_REGISTER -- Device registers to a specified
          network; the optional Manual Network Register Information TLV must also
          be included for the command to process successfully;
          supported only for 3GPP
   */

  /* Optional */
  /*  Manual Network Register Information** */
  uint8_t manual_network_register_info_valid;  /**< Must be set to true if manual_network_register_info is being passed */
  nas_manual_network_register_info_type_v01 manual_network_register_info;

  /* Optional */
  /*  Change Duration** */
  uint8_t change_duration_valid;  /**< Must be set to true if change_duration is being passed */
  nas_change_duration_enum_v01 change_duration;
  /**<    Duration of the change. Values: \n
        - 0x00 -- Power cycle -- Remains active until the next device power cycle \n
        - 0x01 -- Permanent -- Remains active through power cycles until changed by the client \n
        Note: The device will use "0x00 -- Power cycle" as the default value 
              if the TLV is omitted.
   */

  /* Optional */
  /*  MNC PCS Digit Include Status */
  uint8_t mnc_includes_pcs_digit_valid;  /**< Must be set to true if mnc_includes_pcs_digit is being passed */
  uint8_t mnc_includes_pcs_digit;
  /**<    This TLV applies to the MNC field of the manual_network_register_info 
        data structure. Values: \n
        - True  -- MNC is a three-digit value \n
        - False -- MNC is a two-digit value

        If this TLV is not included in the case of a manual register option, 
        the value of the MNC value specified in manual_network_register_info 
        is interpreted as follows: \n
        - If the MNC value is less than 100, the MNC value provided is 
          interpreted as a two-digit value. \n
        - If the MNC value is greater than or equal to 100, the MNC value 
          provided is interpreted as a three-digit value.
   */
}nas_initiate_network_register_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Initiates a network registration. (Deprecated) */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_initiate_network_register_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_PS_ATTACH_ACTION_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_PS_ACTION_ATTACH_V01 = 0x01, 
  NAS_PS_ACTION_DETACH_V01 = 0x02, 
  NAS_PS_ATTACH_ACTION_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_ps_attach_action_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Initiates a domain attach or detach action. (Deprecated) */
typedef struct {

  /* Optional */
  /*  PS Attach Action** */
  uint8_t ps_attach_action_valid;  /**< Must be set to true if ps_attach_action is being passed */
  nas_ps_attach_action_enum_v01 ps_attach_action;
  /**<   Initiates a packet domain attach or detach action. Values: \n
       - 0x01 -- PS_ACTION_ATTACH -- Initiates an immediate packet domain attach action \n
       - 0x02 -- PS_ACTION_DETACH -- Initiates an immediate packet domain detach action 
   */
}nas_initiate_attach_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Initiates a domain attach or detach action. (Deprecated) */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_initiate_attach_resp_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_serving_system_req_msg is empty
 * typedef struct {
 * }nas_get_serving_system_req_msg_v01;
 */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_REGISTRATION_STATE_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_NOT_REGISTERED_V01 = 0x00, 
  NAS_REGISTERED_V01 = 0x01, 
  NAS_NOT_REGISTERED_SEARCHING_V01 = 0x02, 
  NAS_REGISTRATION_DENIED_V01 = 0x03, 
  NAS_REGISTRATION_UNKNOWN_V01 = 0x04, 
  NAS_REGISTRATION_STATE_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_registration_state_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_CS_ATTACH_STATE_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_CS_UNKNOWN_V01 = 0x00, 
  NAS_CS_ATTACHED_V01 = 0x01, 
  NAS_CS_DETACHED_V01 = 0x02, 
  NAS_CS_ATTACH_STATE_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_cs_attach_state_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_PS_ATTACH_STATE_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_PS_UNKNOWN_V01 = 0x00, 
  NAS_PS_ATTACHED_V01 = 0x01, 
  NAS_PS_DETACHED_V01 = 0x02, 
  NAS_PS_ATTACH_STATE_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_ps_attach_state_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_SELECTED_NETWORK_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_SELECTED_NETWORK_UNKNOWN_V01 = 0x00, 
  NAS_SELECTED_NETWORK_3GPP2_V01 = 0x01, 
  NAS_SELECTED_NETWORK_3GPP_V01 = 0x02, 
  NAS_SELECTED_NETWORK_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_selected_network_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  nas_registration_state_enum_v01 registration_state;
  /**<   Registration state of the mobile. Values: \n
       - 0x00 -- NOT_REGISTERED           -- Not registered; mobile is not currently 
                                          searching for a new network to provide 
                                          service \n
       - 0x01 -- REGISTERED               -- Registered with a network \n
       - 0x02 -- NOT_REGISTERED_SEARCHING -- Not registered, but mobile is currently 
                                          searching for a new network to provide 
                                          service \n
       - 0x03 -- REGISTRATION_DENIED      -- Registration denied by the visible 
                                          network \n
       - 0x04 -- REGISTRATION_UNKNOWN     -- Registration state is unknown
   */

  nas_cs_attach_state_enum_v01 cs_attach_state;
  /**<   Circuit-switched domain attach state of the mobile. Values: \n
       - 0x00 -- CS_UNKNOWN  -- Unknown or not applicable \n
       - 0x01 -- CS_ATTACHED -- Attached \n
       - 0x02 -- CS_DETACHED -- Detached
   */

  nas_ps_attach_state_enum_v01 ps_attach_state;
  /**<   Packet-switched domain attach state of the mobile. Values: \n
       - 0x00 -- PS_UNKNOWN  -- Unknown or not applicable \n
       - 0x01 -- PS_ATTACHED -- Attached \n
       - 0x02 -- PS_DETACHED -- Detached
   */

  nas_selected_network_enum_v01 selected_network;
  /**<   Type of selected radio access network. Values: \n
       - 0x00 -- SELECTED_NETWORK_UNKNOWN -- Unknown \n
       - 0x01 -- SELECTED_NETWORK_3GPP2   -- 3GPP2 network \n
       - 0x02 -- SELECTED_NETWORK_3GPP    -- 3GPP network
   */

  uint32_t radio_if_len;  /**< Must be set to # of elements in radio_if */
  nas_radio_if_enum_v01 radio_if[NAS_RADIO_IF_LIST_MAX_V01];
  /**<   Radio interface currently in use. Values: \n
       -0x00 -- RADIO_IF_NO_SVC      -- None (no service) \n
       -0x01 -- RADIO_IF_CDMA_1X     -- cdma2000 1X             \n
       -0x02 -- RADIO_IF_CDMA_1XEVDO -- cdma2000 HRPD (1xEV-DO) \n
       -0x03 -- RADIO_IF_AMPS        -- AMPS \n
       -0x04 -- RADIO_IF_GSM         -- GSM \n
       -0x05 -- RADIO_IF_UMTS        -- UMTS \n
       -0x08 -- RADIO_IF_LTE         -- LTE 
   */
}nas_serving_system_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t mobile_country_code;
  /**<   A 16-bit integer representation of MCC. Range: 0 to 999. */

  uint16_t mobile_network_code;
  /**<   A 16-bit integer representation of MNC. Range: 0 to 999. */

  char network_description[NAS_NETWORK_DESCRIPTION_MAX_V01 + 1];
  /**<   An optional string containing the network name or description. */
}nas_plmn_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t sid;
  /**<   System ID.  */

  uint16_t nid;
  /**<   Network ID. */
}nas_cdma_system_id_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t base_id;
  /**<   Base station identification number. */

  int32_t base_lat;
  /**<   
    Base station latitude in units of 0.25 sec, expressed as a two's
    complement signed number with positive numbers signifying North
    latitudes.
   */

  int32_t base_long;
  /**<   
    Base station longitude in units of 0.25 sec, expressed as a two's
    complement signed number with positive numbers signifying East
    longitude.
   */
}nas_cdma_base_station_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_ROAMING_INDICATOR_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_ROAMING_IND_ON_V01 = 0x00, 
  NAS_ROAMING_IND_OFF_V01 = 0x01, 
  NAS_ROAMING_IND_FLASHING_V01 = 0x02, 
  NAS_ROAMING_INDICATOR_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_roaming_indicator_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  nas_radio_if_enum_v01 radio_if;
  /**<   Radio interface currently in use. Values: \n
       -0x01 -- RADIO_IF_CDMA_1X     -- cdma2000 1X             \n
       -0x02 -- RADIO_IF_CDMA_1XEVDO -- cdma2000 HRPD (1xEV-DO) \n
       -0x03 -- RADIO_IF_AMPS        -- AMPS \n
       -0x04 -- RADIO_IF_GSM         -- GSM \n
       -0x05 -- RADIO_IF_UMTS        -- UMTS \n
       -0x08 -- RADIO_IF_LTE         -- LTE
   */

  nas_roaming_indicator_enum_v01 roaming_indicator;
  /**<   
    Roaming indicator. Values: \n
    -0x00 -- ROAMING_IND_ON                       -- Roaming \n
    -0x01 -- ROAMING_IND_OFF                      -- Home

    Values from 2 onward are applicable only for 3GPP2. See [S4] for
    the meanings of these values.
   */
}nas_roaming_indicator_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t lp_sec;
  /**<   Number of leap seconds since the start of CDMA system time.
   */

  int8_t ltm_offset;
  /**<    Offset of local time from system time in units of 30 min. The value in
        this field conveys the offset as an 8-bit two's complement number.
   */

  uint8_t daylt_savings;
  /**<   Daylight saving indicator. Values: \n
       - 0x00 -- OFF (daylight saving not in effect) \n
       - 0x01 -- ON (daylight saving in effect)
   */
}nas_3gpp_time_zone_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_DATA_CAPABILITES_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_DATA_CAPABILITIES_GPRS_V01 = 0x01, 
  NAS_DATA_CAPABILITIES_EDGE_V01 = 0x02, 
  NAS_DATA_CAPABILITIES_HSDPA_V01 = 0x03, 
  NAS_DATA_CAPABILITIES_HSUPA_V01 = 0x04, 
  NAS_DATA_CAPABILITIES_WCDMA_V01 = 0x05, 
  NAS_DATA_CAPABILITIES_CDMA_V01 = 0x06, 
  NAS_DATA_CAPABILITIES_EVDO_REV_O_V01 = 0x07, 
  NAS_DATA_CAPABILITIES_EVDO_REV_A_V01 = 0x08, 
  NAS_DATA_CAPABILITIES_GSM_V01 = 0x09, 
  NAS_DATA_CAPABILITIES_EVDO_REV_B_V01 = 0x0A, 
  NAS_DATA_CAPABILITIES_LTE_V01 = 0x0B, 
  NAS_DATA_CAPABILITIES_HSDPA_PLUS_V01 = 0x0C, 
  NAS_DATA_CAPABILITIES_DC_HSDPA_PLUS_V01 = 0x0D, 
  NAS_DATA_CAPABILITES_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_data_capabilites_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t srv_status;
  /**<   Service status. Values: \n
       - 0x00 -- No service \n
       - 0x01 -- Limited service \n
       - 0x02 -- Service available \n
       - 0x03 -- Limited regional service \n
       - 0x04 -- MS in power save or deep sleep
   */

  uint8_t srv_capability;
  /**<   System's service capability. Values: \n
      - 0x00 -- No service \n
      - 0x01 -- Circuit-switched only \n
      - 0x02 -- Packet-switched only \n
      - 0x03 -- Circuit-switched and-packet switched \n
      - 0x04 -- MS found the right system but not yet registered/attached 
   */

  uint8_t hdr_srv_status;
  /**<   HDR service status. Values: \n
      - 0x00 -- No service \n
      - 0x01 -- Limited service \n
      - 0x02 -- Service available \n
      - 0x03 -- Limited regional service \n
      - 0x04 -- MS in power save or deep sleep
   */

  uint8_t hdr_hybrid;
  /**<   HDR hybrid information. Values: \n
      - 0x00 -- System is not hybrid \n
      - 0x01 -- System is hybrid
   */

  uint8_t is_sys_forbidden;
  /**<   Forbidden system information. Values: \n
      - 0x00 -- System is not a forbidden system \n
      - 0x01 -- System is a forbidden system
   */
}nas_ss_detailed_service_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  MCC */
  uint16_t mcc;
  /**<   Mobile country code. 
   */

  /*  imsi_11_12 */
  uint8_t imsi_11_12;
  /**<   IMSI_11_12. 
   */
}nas_cdma_system_id_ext_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_HDR_PERSONALITY_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_HDR_PERSONALITY_UNKNOWN_V01 = 0x00, 
  NAS_HDR_PERSONALITY_HRPD_V01 = 0x01, 
  NAS_HDR_PERSONALITY_EHRPD_V01 = 0x02, 
  NAS_HDR_PERSONALITY_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_hdr_personality_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_CELL_ACCESS_STATUS_E_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_CELL_ACCESS_NORMAL_ONLY_V01 = 0x00, /**<  Cell access allowed for normal calls only   */
  NAS_CELL_ACCESS_EMERGENCY_ONLY_V01 = 0x01, /**<  Cell access allowed for emergency calls only   */
  NAS_CELL_ACCESS_NO_CALLS_V01 = 0x02, /**<  Cell access not allowed for any call type   */
  NAS_CELL_ACCESS_ALL_CALLS_V01 = 0x03, /**<  Cell access allowed for all call types  
 Cell access type unknown   */
  NAS_CELL_ACCESS_UNKNOWN_V01 = -1, 
  NAS_CELL_ACCESS_STATUS_E_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_cell_access_status_e_type_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  nas_cell_access_status_e_type_v01 cs_bar_status;
  /**<  
     Call barring status for circuit-switched calls. Values: \n
    - 0x00 -- NAS_CELL_ACCESS_NORMAL_ONLY    -- Cell access is allowed for normal calls only \n
    - 0x01 -- NAS_CELL_ACCESS_EMERGENCY_ONLY -- Cell access is allowed for emergency calls only \n
    - 0x02 -- NAS_CELL_ACCESS_NO_CALLS       -- Cell access is not allowed for any call type \n
    - 0x03 -- NAS_CELL_ACCESS_ALL_CALLS      -- Cell access is allowed for all call types \n
    -   -1 -- NAS_CELL_ACCESS_UNKNOWN        -- Cell access type is unknown
   */

  nas_cell_access_status_e_type_v01 ps_bar_status;
  /**<  
     Call barring status for packet-switched calls. Values: \n
    - 0x00 -- NAS_CELL_ACCESS_NORMAL_ONLY    -- Cell access is allowed for normal calls only \n
    - 0x01 -- NAS_CELL_ACCESS_EMERGENCY_ONLY -- Cell access is allowed for emergency calls only \n
    - 0x02 -- NAS_CELL_ACCESS_NO_CALLS       -- Cell access is not allowed for any call type \n
    - 0x03 -- NAS_CELL_ACCESS_ALL_CALLS      -- Cell access is allowed for all call types \n
    -   -1 -- NAS_CELL_ACCESS_UNKNOWN        -- Cell access type is unknown
    */
}nas_gw_sys_info3_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_HS_SUPPORT_ENUM_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  SYS_HS_IND_HSDPA_HSUPA_UNSUPP_CELL_V01 = 0x00, 
  SYS_HS_IND_HSDPA_SUPP_CELL_V01 = 0x01, 
  SYS_HS_IND_HSUPA_SUPP_CELL_V01 = 0x02, 
  SYS_HS_IND_HSDPA_HSUPA_SUPP_CELL_V01 = 0x03, 
  SYS_HS_IND_HSDPAPLUS_SUPP_CELL_V01 = 0x04, 
  SYS_HS_IND_HSDPAPLUS_HSUPA_SUPP_CELL_V01 = 0x05, 
  SYS_HS_IND_DC_HSDPAPLUS_SUPP_CELL_V01 = 0x06, 
  SYS_HS_IND_DC_HSDPAPLUS_HSUPA_SUPP_CELL_V01 = 0x07, 
  SYS_HS_IND_HSDPAPLUS_64QAM_HSUPA_SUPP_CELL_V01 = 0x08, 
  SYS_HS_IND_HSDPAPLUS_64QAM_SUPP_CELL_V01 = 0x09, 
  NAS_HS_SUPPORT_ENUM_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_hs_support_enum_type_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Queries information regarding the system that currently 
              provides service. (Deprecated) */
typedef struct {

  /* Mandatory */
  /*  Serving System */
  nas_serving_system_type_v01 serving_system;

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type. Contains the following data members:
     - qmi_result_type -- QMI_RESULT_SUCCESS or QMI_RESULT_FAILURE \n
     - qmi_error_type  -- Error code. Possible error code values are described in
                          the error codes section of each message definition.
   */

  /* Optional */
  /*  Roaming Indicator Value */
  uint8_t roaming_indicator_valid;  /**< Must be set to true if roaming_indicator is being passed */
  nas_roaming_indicator_enum_v01 roaming_indicator;
  /**<   
    Roaming indicator. Values: \n
    -0x00 -- ROAMING_IND_ON                       -- Roaming \n
    -0x01 -- ROAMING_IND_OFF                      -- Home    \n
    -0x02 and above -- Operator-defined values
   */

  /* Optional */
  /*  Data Service Capability */
  uint8_t data_capabilities_valid;  /**< Must be set to true if data_capabilities is being passed */
  uint32_t data_capabilities_len;  /**< Must be set to # of elements in data_capabilities */
  nas_data_capabilites_enum_v01 data_capabilities[NAS_DATA_CAPABILITIES_LIST_MAX_V01];
  /**<   List of data capabilities (each is 1 byte) of the current
       serving system. Possible values: \n
       -0x01 -- DATA_CAPABILITIES_GPRS       -- GPRS \n
       -0x02 -- DATA_CAPABILITIES_EDGE       -- EDGE \n
       -0x03 -- DATA_CAPABILITIES_HSDPA      -- HSDPA \n
       -0x04 -- DATA_CAPABILITIES_HSUPA      -- HSUPA \n
       -0x05 -- DATA_CAPABILITIES_WCDMA      -- WCDMA \n
       -0x06 -- DATA_CAPABILITIES_CDMA       -- CDMA \n
       -0x07 -- DATA_CAPABILITIES_EVDO_REV_O -- EV-DO REV 0  \n
       -0x08 -- DATA_CAPABILITIES_EVDO_REV_A -- EV-DO REV A  \n
       -0x09 -- DATA_CAPABILITIES_GSM        -- GSM          \n
       -0x0A -- DATA_CAPABILITIES_EVDO_REV_B -- EV-DO REV B  \n
       -0x0B -- DATA_CAPABILITIES_LTE        -- LTE          \n
       -0x0C -- DATA_CAPABILITIES_HSDPA_PLUS -- HSDPA+       \n
       -0x0D -- DATA_CAPABILITIES_DC_HSDPA_PLUS -- DC-HSDPA+
   */

  /* Optional */
  /*  Current PLMN */
  uint8_t current_plmn_valid;  /**< Must be set to true if current_plmn is being passed */
  nas_plmn_type_v01 current_plmn;

  /* Optional */
  /*  CDMA System ID */
  uint8_t cdma_system_id_valid;  /**< Must be set to true if cdma_system_id is being passed */
  nas_cdma_system_id_type_v01 cdma_system_id;

  /* Optional */
  /*  CDMA Base Station Information */
  uint8_t cdma_base_station_info_valid;  /**< Must be set to true if cdma_base_station_info is being passed */
  nas_cdma_base_station_info_type_v01 cdma_base_station_info;

  /* Optional */
  /*  Roaming Indicator List */
  uint8_t roaming_indicator_list_valid;  /**< Must be set to true if roaming_indicator_list is being passed */
  uint32_t roaming_indicator_list_len;  /**< Must be set to # of elements in roaming_indicator_list */
  nas_roaming_indicator_type_v01 roaming_indicator_list[NAS_ROAMING_INDICATOR_LIST_MAX_V01];

  /* Optional */
  /*  Default Roaming Indicator */
  uint8_t def_roam_ind_valid;  /**< Must be set to true if def_roam_ind is being passed */
  nas_roaming_indicator_enum_v01 def_roam_ind;
  /**<   
    Roaming indicator. Values: \n
    -0x00 -- ROAMING_IND_ON                       -- Roaming \n
    -0x01 -- ROAMING_IND_OFF                      -- Home

    Values from 2 onward are applicable only for 3GPP2. See [S4] for
    the meanings of these values.
   */

  /* Optional */
  /*  3GGP2 Time Zone */
  uint8_t nas_3gpp_time_zone_valid;  /**< Must be set to true if nas_3gpp_time_zone is being passed */
  nas_3gpp_time_zone_type_v01 nas_3gpp_time_zone;

  /* Optional */
  /*  CDMA P_Rev in Use */
  uint8_t p_rev_in_use_valid;  /**< Must be set to true if p_rev_in_use is being passed */
  uint8_t p_rev_in_use;
  /**<    P_Rev that is currently in use. */

  /* Optional */
  /*  3GPP Time Zone */
  uint8_t time_zone_valid;  /**< Must be set to true if time_zone is being passed */
  int8_t time_zone;
  /**<   Offset from Universal time, i.e., difference between local
       time and Universal time, in increments of 15 min (signed value).
   */

  /* Optional */
  /*   3GPP Network Daylight Saving Adjustment */
  uint8_t adj_valid;  /**< Must be set to true if adj is being passed */
  uint8_t adj;
  /**<   3GPP network daylight saving adjustment. Values: \n
       - 0x00 -- No adjustment for Daylight Saving Time \n
       - 0x01 -- 1 hr adjustment for Daylight Saving Time \n
       - 0x02 -- 2 hr adjustment for Daylight Saving Time
   */

  /* Optional */
  /*  3GPP Location Area Code */
  uint8_t lac_valid;  /**< Must be set to true if lac is being passed */
  uint16_t lac;
  /**<   Location area code.
   */

  /* Optional */
  /*  3GPP Cell ID */
  uint8_t cell_id_valid;  /**< Must be set to true if cell_id is being passed */
  uint32_t cell_id;
  /**<   3GPP cell ID.
   */

  /* Optional */
  /*  3GPP2 Concurrent Service Info */
  uint8_t ccs_valid;  /**< Must be set to true if ccs is being passed */
  uint8_t ccs;
  /**<   3GPP2 concurrent service information. Values: \n
        - 0x00 -- Concurrent service not available \n
        - 0x01 -- Concurrent service available
   */

  /* Optional */
  /*  3GPP2 PRL Indicator */
  uint8_t prl_ind_valid;  /**< Must be set to true if prl_ind is being passed */
  uint8_t prl_ind;
  /**<   3GPP2 PRL indicator. Values: \n
       - 0x00 -- System not in PRL \n
       - 0x01 -- System is in PRL
   */

  /* Optional */
  /*  Dual Transfer Mode Indication (GSM Only) */
  uint8_t dtm_ind_valid;  /**< Must be set to true if dtm_ind is being passed */
  uint8_t dtm_ind;
  /**<   Dual Transfer mode indication. Values: \n
      - 0x00 -- DTM not supported \n
      - 0x01 -- DTM supported 
   */

  /* Optional */
  /*  Detailed Service Information */
  uint8_t detailed_service_info_valid;  /**< Must be set to true if detailed_service_info is being passed */
  nas_ss_detailed_service_info_type_v01 detailed_service_info;

  /* Optional */
  /*  CDMA System Info */
  uint8_t cdma_system_id_ext_valid;  /**< Must be set to true if cdma_system_id_ext is being passed */
  nas_cdma_system_id_ext_type_v01 cdma_system_id_ext;

  /* Optional */
  /*  HDR Personality */
  uint8_t hdr_personality_valid;  /**< Must be set to true if hdr_personality is being passed */
  nas_hdr_personality_enum_v01 hdr_personality;
  /**<   HDR personality information. Values: \n
      - 0x00 -- Unknown \n
      - 0x01 -- HRPD \n
      - 0x02 -- eHRPD
   */

  /* Optional */
  /*  TAC Information for LTE */
  uint8_t tac_valid;  /**< Must be set to true if tac is being passed */
  uint16_t tac;
  /**<   Tracking area code information for LTE.
   */

  /* Optional */
  /*  Call Barring Status */
  uint8_t call_barring_status_valid;  /**< Must be set to true if call_barring_status is being passed */
  nas_gw_sys_info3_type_v01 call_barring_status;

  /* Optional */
  /*  UMTS Primary Scrambling Code */
  uint8_t umts_psc_valid;  /**< Must be set to true if umts_psc is being passed */
  uint16_t umts_psc;
  /**<   Primary scrambling code.
   */

  /* Optional */
  /*  MNC PCS Digit Include Status */
  uint8_t mnc_includes_pcs_digit_valid;  /**< Must be set to true if mnc_includes_pcs_digit is being passed */
  nas_mnc_pcs_digit_include_status_type_v01 mnc_includes_pcs_digit;

  /* Optional */
  /*  HS Call Status */
  uint8_t hs_call_status_valid;  /**< Must be set to true if hs_call_status is being passed */
  nas_hs_support_enum_type_v01 hs_call_status;
  /**<  
      Call status on high speed (only applicable for WCDMA). Values: \n
      - 0x00 -- SYS_HS_IND_HSDPA_HSUPA_UNSUPP_ CELL   -- HSDPA and HSUPA are unsupported \n
      - 0x01 -- SYS_HS_IND_HSDPA_SUPP_CELL            -- HSDPA is supported \n
      - 0x02 -- SYS_HS_IND_HSUPA_SUPP_CELL            -- HSUPA is supported \n
      - 0x03 -- SYS_HS_IND_HSDPA_HSUPA_SUPP_CELL      -- HSDPA and HSUPA are supported \n
      - 0x04 -- SYS_HS_IND_HSDPAPLUS_SUPP_CELL        -- HSDPA+ is supported \n
      - 0x05 -- SYS_HS_IND_HSDPAPLUS_HSUPA_SUPP_ CELL -- HSDPA+ and HSUPA are supported \n
      - 0x06 -- SYS_HS_IND_DC_HSDPAPLUS_SUPP_CELL     -- Dual-cell HSDPA+ is supported \n
      - 0x07 -- SYS_HS_IND_DC_HSDPAPLUS_HSUPA_ SUPP_CELL    -- Dual-cell HSDPA+ and HSUPA are supported \n 
      - 0x08 -- SYS_HS_IND_HSDPAPLUS_64QAM_HSUPA_ SUPP_CELL -- Dual-cell HSDPA+, 64 QAM, and HSUPA are supported \n
      - 0x09 -- SYS_HS_IND_HSDPAPLUS_64QAM_SUPP_CELL -- Dual-cell HSDPA+ and 64 QAM are supported
     */
}nas_get_serving_system_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t year;
  /**<   Year. */

  uint8_t month;
  /**<   Month. */

  uint8_t day;
  /**<   Day. */

  uint8_t hour;
  /**<   Hour. */

  uint8_t minute;
  /**<   Minute. */

  uint8_t second;
  /**<   Second. */

  int8_t time_zone;
  /**<   Offset from Universal time, i.e., difference between local time
       and Universal time, in increments of 15 min (signed value).
   */
}nas_universal_time_and_local_time_zone_3gpp_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Indication Message; Indicates a change in the current serving system registration
              state and/or radio technology. (Deprecated) */
typedef struct {

  /* Mandatory */
  /*  Serving System */
  nas_serving_system_type_v01 serving_system;

  /* Optional */
  /*  Roaming Indicator Value */
  uint8_t roaming_indicator_valid;  /**< Must be set to true if roaming_indicator is being passed */
  nas_roaming_indicator_enum_v01 roaming_indicator;
  /**<   
    Roaming indicator. Values: \n
    - 0x00 -- ROAMING_IND_ON       -- Roaming   \n
    - 0x01 -- ROAMING_IND_OFF      -- Home      \n
    - 0x02 -- ROAMING_IND_FLASHING -- Flashing  \n
    - 0x03 and above -- Operator-defined values
   */

  /* Optional */
  /*  Data Service Capability */
  uint8_t data_capabilities_valid;  /**< Must be set to true if data_capabilities is being passed */
  uint32_t data_capabilities_len;  /**< Must be set to # of elements in data_capabilities */
  nas_data_capabilites_enum_v01 data_capabilities[NAS_DATA_CAPABILITIES_LIST_MAX_V01];
  /**<   List of data capabilities (each is 1 byte) of the current
       serving system. Possible values: \n
       -0x01 -- DATA_CAPABILITIES_GPRS       -- GPRS \n
       -0x02 -- DATA_CAPABILITIES_EDGE       -- EDGE \n
       -0x03 -- DATA_CAPABILITIES_HSDPA      -- HSDPA \n
       -0x04 -- DATA_CAPABILITIES_HSUPA      -- HSUPA \n
       -0x05 -- DATA_CAPABILITIES_WCDMA      -- WCDMA \n
       -0x06 -- DATA_CAPABILITIES_CDMA       -- CDMA \n
       -0x07 -- DATA_CAPABILITIES_EVDO_REV_O -- EV-DO REV 0  \n
       -0x08 -- DATA_CAPABILITIES_EVDO_REV_A -- EV-DO REV A  \n
       -0x09 -- DATA_CAPABILITIES_GSM        -- GSM          \n
       -0x0A -- DATA_CAPABILITIES_EVDO_REV_B -- EV-DO REV B  \n
       -0x0B -- DATA_CAPABILITIES_LTE        -- LTE          \n
       -0x0C -- DATA_CAPABILITIES_HSDPA_PLUS -- HSDPA+       \n
       -0x0D -- DATA_CAPABILITIES_DC_HSDPA_PLUS -- DC-HSDPA+
   */

  /* Optional */
  /*  Current PLMN */
  uint8_t current_plmn_valid;  /**< Must be set to true if current_plmn is being passed */
  nas_plmn_type_v01 current_plmn;

  /* Optional */
  /*  CDMA System ID */
  uint8_t cdma_system_id_valid;  /**< Must be set to true if cdma_system_id is being passed */
  nas_cdma_system_id_type_v01 cdma_system_id;

  /* Optional */
  /*  CDMA Base Station Information */
  uint8_t cdma_base_station_info_valid;  /**< Must be set to true if cdma_base_station_info is being passed */
  nas_cdma_base_station_info_type_v01 cdma_base_station_info;

  /* Optional */
  /*  Roaming Indicator List */
  uint8_t roaming_indicator_list_valid;  /**< Must be set to true if roaming_indicator_list is being passed */
  uint32_t roaming_indicator_list_len;  /**< Must be set to # of elements in roaming_indicator_list */
  nas_roaming_indicator_type_v01 roaming_indicator_list[NAS_ROAMING_INDICATOR_LIST_MAX_V01];

  /* Optional */
  /*  Default Roaming Indicator */
  uint8_t def_roam_ind_valid;  /**< Must be set to true if def_roam_ind is being passed */
  nas_roaming_indicator_enum_v01 def_roam_ind;
  /**<   
    Roaming indicator. Values: \n
    -0x00 -- ROAMING_IND_ON                       -- Roaming \n
    -0x01 -- ROAMING_IND_OFF                      -- Home

    Values from 2 onward are applicable only for 3GPP2. See [S4] for
    the meanings of these values.
   */

  /* Optional */
  /*  3GGP2 Time Zone */
  uint8_t nas_3gpp_time_zone_valid;  /**< Must be set to true if nas_3gpp_time_zone is being passed */
  nas_3gpp_time_zone_type_v01 nas_3gpp_time_zone;

  /* Optional */
  /*  CDMA P_Rev in Use */
  uint8_t p_rev_in_use_valid;  /**< Must be set to true if p_rev_in_use is being passed */
  uint8_t p_rev_in_use;
  /**<   P_Rev that is currently in use.
   */

  /* Optional */
  /*  3GPP PLMN Name Flag */
  uint8_t plmn_description_changed_valid;  /**< Must be set to true if plmn_description_changed is being passed */
  uint8_t plmn_description_changed;
  /**<  
       Flag indicating that the 3GPP EONS network description changed. Values: \n
       -0x01 -- PLMN name changed
   */

  /* Optional */
  /*  3GPP Time Zone */
  uint8_t time_zone_valid;  /**< Must be set to true if time_zone is being passed */
  int8_t time_zone;
  /**<   Offset from Universal time, i.e., difference between local
       time and Universal time, in increments of 15 min (signed value).
   */

  /* Optional */
  /*   3GPP Network Daylight Saving Adjustment */
  uint8_t adj_valid;  /**< Must be set to true if adj is being passed */
  uint8_t adj;
  /**<   3GPP network daylight saving adjustment. Values: \n
       - 0x00 -- No adjustment for Daylight Saving Time \n
       - 0x01 -- 1 hr adjustment for Daylight Saving Time \n
       - 0x02 -- 2 hr adjustment for Daylight Saving Time
   */

  /* Optional */
  /*  3GPP Universal Time and Local Time Zone */
  uint8_t universal_time_and_local_time_3gpp_zone_valid;  /**< Must be set to true if universal_time_and_local_time_3gpp_zone is being passed */
  nas_universal_time_and_local_time_zone_3gpp_type_v01 universal_time_and_local_time_3gpp_zone;

  /* Optional */
  /*  3GPP Location Area Code */
  uint8_t lac_valid;  /**< Must be set to true if lac is being passed */
  uint16_t lac;
  /**<   Location area code.
   */

  /* Optional */
  /*  3GPP Cell ID */
  uint8_t cell_id_valid;  /**< Must be set to true if cell_id is being passed */
  uint32_t cell_id;
  /**<   3GPP cell ID.
   */

  /* Optional */
  /*  3GPP2 Concurrent Service Info */
  uint8_t ccs_valid;  /**< Must be set to true if ccs is being passed */
  uint8_t ccs;
  /**<   3GPP2 concurrent service information. Values: \n
        - 0x00 -- Concurrent service not available \n
        - 0x01 -- Concurrent service available
   */

  /* Optional */
  /*  3GPP2 PRL Indicator */
  uint8_t prl_ind_valid;  /**< Must be set to true if prl_ind is being passed */
  uint8_t prl_ind;
  /**<   3GPP2 PRL indicator. Values: \n
       - 0x00 -- System not in PRL \n
       - 0x01 -- System is in PRL
   */

  /* Optional */
  /*  Dual Transfer Mode Indication (GSM Only) */
  uint8_t dtm_ind_valid;  /**< Must be set to true if dtm_ind is being passed */
  uint8_t dtm_ind;
  /**<   Dual Transfer mode indication. Values: \n
      - 0x00 -- DTM not supported \n
      - 0x01 -- DTM supported 
   */

  /* Optional */
  /*  Detailed Service Information */
  uint8_t detailed_service_info_valid;  /**< Must be set to true if detailed_service_info is being passed */
  nas_ss_detailed_service_info_type_v01 detailed_service_info;

  /* Optional */
  /*  CDMA System Info Ext */
  uint8_t cdma_system_id_ext_valid;  /**< Must be set to true if cdma_system_id_ext is being passed */
  nas_cdma_system_id_ext_type_v01 cdma_system_id_ext;

  /* Optional */
  /*  HDR Personality */
  uint8_t hdr_personality_valid;  /**< Must be set to true if hdr_personality is being passed */
  nas_hdr_personality_enum_v01 hdr_personality;
  /**<   HDR personality information. Values: \n
      - 0x00 -- Unknown \n
      - 0x01 -- HRPD \n
      - 0x02 -- eHRPD
   */

  /* Optional */
  /*  TAC Information for LTE */
  uint8_t tac_valid;  /**< Must be set to true if tac is being passed */
  uint16_t tac;
  /**<   Tracking area code information for LTE.
   */

  /* Optional */
  /*  Call Barring Status */
  uint8_t call_barring_status_valid;  /**< Must be set to true if call_barring_status is being passed */
  nas_gw_sys_info3_type_v01 call_barring_status;

  /* Optional */
  /*  PLMN Change Status */
  uint8_t srv_sys_no_change_valid;  /**< Must be set to true if srv_sys_no_change is being passed */
  uint8_t srv_sys_no_change;
  /**<   Flag used to notify clients that a request to select a network ended 
      with no change in the PLMN. Values: \n
      - 0x01 -- No change in serving system information
   */

  /* Optional */
  /*  UMTS Primary Scrambling Code */
  uint8_t umts_psc_valid;  /**< Must be set to true if umts_psc is being passed */
  uint16_t umts_psc;
  /**<   Primary scrambling code.
   */

  /* Optional */
  /*  MNC PCS Digit Include Status */
  uint8_t mnc_includes_pcs_digit_valid;  /**< Must be set to true if mnc_includes_pcs_digit is being passed */
  nas_mnc_pcs_digit_include_status_type_v01 mnc_includes_pcs_digit;

  /* Optional */
  /*  HS Call Status */
  uint8_t hs_call_status_valid;  /**< Must be set to true if hs_call_status is being passed */
  nas_hs_support_enum_type_v01 hs_call_status;
  /**<  
      Call status on high speed (only applicable for WCDMA). Values: \n
      - 0x00 -- SYS_HS_IND_HSDPA_HSUPA_UNSUPP_ CELL   -- HSDPA and HSUPA are unsupported \n
      - 0x01 -- SYS_HS_IND_HSDPA_SUPP_CELL            -- HSDPA is supported \n
      - 0x02 -- SYS_HS_IND_HSUPA_SUPP_CELL            -- HSUPA is supported \n
      - 0x03 -- SYS_HS_IND_HSDPA_HSUPA_SUPP_CELL      -- HSDPA and HSUPA are supported \n
      - 0x04 -- SYS_HS_IND_HSDPAPLUS_SUPP_CELL        -- HSDPA+ is supported \n
      - 0x05 -- SYS_HS_IND_HSDPAPLUS_HSUPA_SUPP_ CELL -- HSDPA+ and HSUPA are supported \n
      - 0x06 -- SYS_HS_IND_DC_HSDPAPLUS_SUPP_CELL     -- Dual-cell HSDPA+ is supported \n
      - 0x07 -- SYS_HS_IND_DC_HSDPAPLUS_HSUPA_ SUPP_CELL    -- Dual-cell HSDPA+ and HSUPA are supported \n 
      - 0x08 -- SYS_HS_IND_HSDPAPLUS_64QAM_HSUPA_ SUPP_CELL -- Dual-cell HSDPA+, 64 QAM, and HSUPA are supported \n
      - 0x09 -- SYS_HS_IND_HSDPAPLUS_64QAM_SUPP_CELL -- Dual-cell HSDPA+ and 64 QAM are supported
     */
}nas_serving_system_ind_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_home_network_req_msg is empty
 * typedef struct {
 * }nas_get_home_network_req_msg_v01;
 */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_NETWORK_DESC_DISPLAY_ENUM_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_NETWORK_DESC_DISP_FALSE_V01 = 0x00, 
  NAS_NETWORK_DESC_DISP_TRUE_V01 = 0x01, 
  NAS_NETWORK_DESC_DISP_UNKOWN_V01 = 0xFF, 
  NAS_NETWORK_DESC_DISP_UNKNOWN_V01 = 0xFF, 
  NAS_NETWORK_DESC_DISPLAY_ENUM_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_network_desc_display_enum_type_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_NETWORK_DESC_ENCODING_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_NETWORK_DESC_ENCODING_OCTECT_UNSPECIFIED_V01 = 0x00, 
  NAS_NETWORK_DESC_ENCODING_7_BIT_ASCII_V01 = 0x02, 
  NAS_NETWORK_DESC_ENCODING_UNICODE_V01 = 0x04, 
  NAS_NETWORK_DESC_ENCODING_GSM_7_BIT_DEFAULT_V01 = 0x09, 
  NAS_NETWORK_DESC_ENCODING_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_network_desc_encoding_type_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  MCC */
  uint16_t mcc;
  /**<   A 16-bit integer representation of MCC. Range: 0 to 999.
   */

  /*  MNC */
  uint16_t mnc;
  /**<   A 16-bit integer representation of MNC. Range: 0 to 999.
   */
}nas_plmn_id_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  MCC and MNC */
  nas_plmn_id_type_v01 mcc_mnc;

  /*  Network name display status */
  nas_network_desc_display_enum_type_v01 network_desc_display;
  /**<   
      Whether the network name is to be conditionally displayed: \n
      - 0x00 -- Do not display \n
      - 0x01 -- Display \n
      - 0xFF -- Unknown \n
      Note: This value is ignored if the network_description_len
            is zero.
   */

  /*  Network description encoding */
  nas_network_desc_encoding_type_v01 network_desc_encoding;
  /**<   Encoding of the network description. 
      See [S4, Table 9.1.1 ] for list of all defined values. 
      Common (but not all) values include: \n
      - 0x00 -- Octet, unspecified \n
      - 0x02 -- 7-bit ASCII \n
      - 0x04 -- Unicode (see [S10]) \n
      - 0x09 -- GSM 7-bit default (refer to [S8]) \n
      Note: This value is ignored if the network_description_len
            is zero. If the encoding type is not recognized the 
            network_description is ignored.
    */

  /*  Network description 
 Length of network description string that follows. 
      If the network name is unknown or not included, the length
      is 0.
   */
  uint32_t network_desc_len;  /**< Must be set to # of elements in network_desc */
  uint8_t network_desc[NAS_NETWORK_DESCRIPTION_MAX_V01];
  /**<   Length of network description string that follows. 
       If the network name is unknown or not included, the length
       is 0.
   */
}nas_3gpp2_home_network_ext_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Retrieves information about the home network of the device. */
typedef struct {

  /* Mandatory */
  /*  Home Network */
  nas_plmn_type_v01 home_network;

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type. 
 Standard response type. Contains the following data members:
     - qmi_result_type -- QMI_RESULT_SUCCESS or QMI_RESULT_FAILURE \n
     - qmi_error_type  -- Error code. Possible error code values are described in
                          the error codes section of each message definition.
   */

  /* Optional */
  /*  Home System ID */
  uint8_t home_system_id_valid;  /**< Must be set to true if home_system_id is being passed */
  nas_cdma_system_id_type_v01 home_system_id;

  /* Optional */
  /*  3GPP2 Home Network Ext */
  uint8_t nas_3gpp2_home_network_ext_valid;  /**< Must be set to true if nas_3gpp2_home_network_ext is being passed */
  nas_3gpp2_home_network_ext_type_v01 nas_3gpp2_home_network_ext;
}nas_get_home_network_resp_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_preferred_networks_req_msg is empty
 * typedef struct {
 * }nas_get_preferred_networks_req_msg_v01;
 */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t mobile_country_code;
  /**<   A 16-bit integer representation of MCC. Range: 0 to 999.
   */

  uint16_t mobile_network_code;
  /**<   A 16-bit integer representation of MNC. Range: 0 to 999.
   */

  uint16_t radio_access_technology;
  /**<    RAT as a bitmask (bit count begins from zero). Values: \n
        - Bit 15 -- UMTS \n
        - Bit 14 -- LTE \n
        - Bit 7 -- GSM \n
        - Bit 6 -- GSM compact \n
        - All bits set to 0 -- No access technology is available from the device
   */
}nas_3gpp_preferred_networks_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Queries the list of preferred networks from the device. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */

  /* Optional */
  /*  3GPP Preferred Networks** */
  uint8_t nas_3gpp_preferred_networks_valid;  /**< Must be set to true if nas_3gpp_preferred_networks is being passed */
  uint32_t nas_3gpp_preferred_networks_len;  /**< Must be set to # of elements in nas_3gpp_preferred_networks */
  nas_3gpp_preferred_networks_type_v01 nas_3gpp_preferred_networks[NAS_3GPP_PREFERRED_NETWORKS_LIST_MAX_V01];

  /* Optional */
  /*  Static 3GPP Preferred Networks** */
  uint8_t static_3gpp_preferred_networks_valid;  /**< Must be set to true if static_3gpp_preferred_networks is being passed */
  uint32_t static_3gpp_preferred_networks_len;  /**< Must be set to # of elements in static_3gpp_preferred_networks */
  nas_3gpp_preferred_networks_type_v01 static_3gpp_preferred_networks[NAS_STATIC_3GPP_PREFERRED_NETWORKS_LIST_MAX_V01];
}nas_get_preferred_networks_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Writes the specified list of preferred networks to the device. */
typedef struct {

  /* Optional */
  /*  3GPP Preferred Networks** */
  uint8_t nas_3gpp_preferred_networks_valid;  /**< Must be set to true if nas_3gpp_preferred_networks is being passed */
  uint32_t nas_3gpp_preferred_networks_len;  /**< Must be set to # of elements in nas_3gpp_preferred_networks */
  nas_3gpp_preferred_networks_type_v01 nas_3gpp_preferred_networks[NAS_3GPP_PREFERRED_NETWORKS_LIST_MAX_V01];
}nas_set_preferred_networks_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Writes the specified list of preferred networks to the device. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_set_preferred_networks_resp_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_forbidden_networks_req_msg is empty
 * typedef struct {
 * }nas_get_forbidden_networks_req_msg_v01;
 */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t mobile_country_code;
  /**<   A 16-bit integer representation of MCC. Range: 0 to 999.
   */

  uint16_t mobile_network_code;
  /**<   A 16-bit integer representation of MNC. Range: 0 to 999.
   */
}nas_3gpp_forbidden_networks_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Queries the list of forbidden networks from the device. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */

  /* Optional */
  /*  3GPP Forbidden Networks** */
  uint8_t nas_3gpp_forbidden_networks_valid;  /**< Must be set to true if nas_3gpp_forbidden_networks is being passed */
  uint32_t nas_3gpp_forbidden_networks_len;  /**< Must be set to # of elements in nas_3gpp_forbidden_networks */
  nas_3gpp_forbidden_networks_type_v01 nas_3gpp_forbidden_networks[NAS_3GPP_FORBIDDEN_NETWORKS_LIST_MAX_V01];
}nas_get_forbidden_networks_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Writes the specified list of forbidden networks to the device. */
typedef struct {

  /* Optional */
  /*  3GPP Forbidden Networks** */
  uint8_t nas_3gpp_forbidden_networks_valid;  /**< Must be set to true if nas_3gpp_forbidden_networks is being passed */
  uint32_t nas_3gpp_forbidden_networks_len;  /**< Must be set to # of elements in nas_3gpp_forbidden_networks */
  nas_3gpp_forbidden_networks_type_v01 nas_3gpp_forbidden_networks[NAS_3GPP_FORBIDDEN_NETWORKS_LIST_MAX_V01];
}nas_set_forbidden_networks_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Writes the specified list of forbidden networks to the device. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_set_forbidden_networks_resp_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_accolc_req_msg is empty
 * typedef struct {
 * }nas_get_accolc_req_msg_v01;
 */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Queries the Access Overload Class (ACCOLC) of the device. */
typedef struct {

  /* Mandatory */
  /*  Access Overload Class */
  uint8_t accolc;
  /**<   An 8-bit integer representation of the ACCOLC. 
       Range: 0 to 15 (0x00 to 0x0F).
   */

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_get_accolc_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  char spc[NAS_SPC_MAX_V01];
  /**<   Service programming code in ASCII format (digits 0 to 9 only). */

  uint8_t accolc;
  /**<   An 8-bit integer representation of the ACCOLC. 
       Range: 0 to 15 (0x00 to 0x0F).
   */
}nas_accolc_set_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Sets the ACCOLC of the device. */
typedef struct {

  /* Mandatory */
  /*  Access Overload Class */
  nas_accolc_set_type_v01 accolc_set;
}nas_set_accolc_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Sets the ACCOLC of the device. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_set_accolc_resp_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_device_config_req_msg is empty
 * typedef struct {
 * }nas_get_device_config_req_msg_v01;
 */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t reg_home_sid;
  /**<   Register on home system. Values: \n
       - 0x00 -- Disable \n
       - 0x01 -- Enable
   */

  uint8_t reg_foreign_sid;
  /**<   Register on foreign system. Values: \n
       - 0x00 -- Disable \n
       - 0x01 -- Enable
   */

  uint8_t reg_foreign_nid;
  /**<   Register on foreign network. Values: \n
       - 0x00 -- Disable \n
       - 0x01 -- Enable
   */
}nas_registration_parameters_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t state;
  /**<   HDR custom configuration for session control protocol. Values: \n
       - 0x00 -- Disable \n
       - 0x01 -- Enable; enable may only be specified if Force HDR Revision 
                 is set to Disable
   */

  uint32_t protocol_mask;
  /**<   Protocol subtype bitmask. Values: \n
       - Bit 0 -- Subtype 2 physical layer \n
       - Bit 1 -- Enhanced CCMAC \n
       - Bit 2 -- Enhanced ACMAC \n
       - Bit 3 -- Enhanced FTCMAC \n
       - Bit 4 -- Subtype 3 RTCMAC \n
       - Bit 5 -- Subtype 1 RTCMAC \n
       - Bit 6 -- Enhanced idle \n
       - Bit 7 -- Generic multimode-capable disc port \n
       All unlisted bits are reserved for future use and are ignored.
   */

  uint32_t broadcast_mask;
  /**<   Broadcast subtype bitmask. Values: \n
       - Bit 0 -- Generic broadcast enabled \n
       All unlisted bits are reserved for future use and are ignored.
   */

  uint32_t application_mask;
  /**<   Application subtype bitmask. Values: \n
       - Bit 0 -- SN multiflow packet application \n
       - Bit 1 -- SN enhanced multiflow packet application \n
       All unlisted bits are reserved for future use and are ignored.
   */
}nas_hdr_scp_config_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_ROAM_CONFIG_PREF_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_ROAM_CONFIG_PREF_AUTO_V01 = 0x00, 
  NAS_ROAM_CONFIG_PREF_HOME_ONLY_V01 = 0x01, 
  NAS_ROAM_CONFIG_PREF_ROAM_ONLY_V01 = 0x02, 
  NAS_ROAM_CONFIG_PREF_HOME_AND_AFFILIATE_V01 = 0x03, 
  NAS_ROAM_CONFIG_PREF_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_roam_config_pref_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_FORCE_HDRSCP_CONFIG_AT_ENUM_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_HDR_REV0_PROTOCOLS_ONLY_V01 = 0x00, 
  NAS_HDR_REVA_PROTOCOLS_MFPA_V01 = 0x01, 
  NAS_HDR_REVA_PROTOCOLS_MFPA_EMPA_V01 = 0x02, 
  NAS_HDR_REVB_PROTOCOLS_MMPA_V01 = 0x03, 
  NAS_HDR_REVA_PROTOCOLS_EHRPD_V01 = 0x04, 
  NAS_HDR_REVB_PROTOCOLS_EHRPD_V01 = 0x05, 
  NAS_FORCE_HDRSCP_CONFIG_AT_ENUM_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_force_hdrscp_config_at_enum_type_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Queries the network-related configuration setting of the 
              device. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type. 
 Standard response type. Contains the following data members:
     - qmi_result_type -- QMI_RESULT_SUCCESS or QMI_RESULT_FAILURE \n
     - qmi_error_type  -- Error code. Possible error code values are described in
                          the error codes section of each message definition.
   */

  /* Optional */
  /*  Slot Cycle Index* */
  uint8_t sci_valid;  /**< Must be set to true if sci is being passed */
  uint8_t sci;
  /**<   Slot cycle index (see [S4, Section 6.6.2.1]).
   */

  /* Optional */
  /*  Station Class Mark* */
  uint8_t scm_valid;  /**< Must be set to true if scm is being passed */
  uint8_t scm;
  /**<   Station class mark (see [S4, Section 6.3.3]).
   */

  /* Optional */
  /*  Registration Parameters* */
  uint8_t registration_parameters_valid;  /**< Must be set to true if registration_parameters is being passed */
  nas_registration_parameters_type_v01 registration_parameters;

  /* Optional */
  /*  Force HDR Revision* */
  uint8_t force_rev0_valid;  /**< Must be set to true if force_rev0 is being passed */
  uint8_t force_rev0;
  /**<   Force Rev0. Values: \n
       - 0x00 -- Disabled \n
       - 0x01 -- Enabled \n
    Note: This TLV is now DISCONTINUED, and is present here as a
          placeholder only for existing clients referencing this TLV.
   */

  /* Optional */
  /*  HDR SCP Custom Config* */
  uint8_t hdr_scp_config_valid;  /**< Must be set to true if hdr_scp_config is being passed */
  nas_hdr_scp_config_type_v01 hdr_scp_config;
  /**<   \n
    Note: This TLV is now DISCONTINUED, and is present here as a
          placeholder only for existing clients referencing this TLV.
   */

  /* Optional */
  /*  Roam Preference* */
  uint8_t roam_pref_valid;  /**< Must be set to true if roam_pref is being passed */
  nas_roam_config_pref_enum_v01 roam_pref;
  /**<   Roaming preference. Values: \n
       - 0x00 -- ROAM_CONFIG_PREF_AUTO               -- Acquire systems regardless of roaming status \n
       - 0x01 -- ROAM_CONFIG_PREF_HOME_ONLY          -- Acquire home systems only \n
       - 0x02 -- ROAM_CONFIG_PREF_ROAM_ONLY          -- Acquire nonhome systems only \n
       - 0x03 -- ROAM_CONFIG_PREF_HOME_AND_AFFILIATE -- Acquire home and affiliated roaming systems only
   */

  /* Optional */
  /*  Force HDR SCP AT Config */
  uint8_t force_hdrscp_config_at_valid;  /**< Must be set to true if force_hdrscp_config_at is being passed */
  nas_force_hdrscp_config_at_enum_type_v01 force_hdrscp_config_at;
  /**<   
      Values: \n
        -0x00 -- HDR Rev0 Protocols only  \n
        -0x01 -- HDR RevA Protocols with MFPA \n
        -0x02 -- HDR RevA Protocols with MFPA and EMPA \n
        -0x03 -- HDR RevB Protocols with MMPA \n
        -0x04 -- HDR RevA Protocols with eHRPD \n
        -0x05 -- HDR RevB Protocols with eHRPD
   */
}nas_get_device_config_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Sets network-related configuration settings of the device. */
typedef struct {

  /* Optional */
  /*  Service Programming Code* */
  uint8_t spc_valid;  /**< Must be set to true if spc is being passed */
  char spc[NAS_SPC_MAX_V01];
  /**<   Service programming code in ASCII format (digits 0 to 9 only).
   */

  /* Optional */
  /*  Force HDR Revision* */
  uint8_t force_hdr_rev0_valid;  /**< Must be set to true if force_hdr_rev0 is being passed */
  uint8_t force_hdr_rev0;
  /**<   Force Rev0. Values: \n
    - 0x00 -- Disable \n
    - 0x01 -- Enable; enable may only be specified if HDR SCP Custom Config
              state is set to Disable \n
    Note: This TLV is now DISCONTINUED, and is present here as a
          placeholder only for existing clients referencing this TLV.
   */

  /* Optional */
  /*  HDR SCP Custom Config* */
  uint8_t hdr_scp_config_valid;  /**< Must be set to true if hdr_scp_config is being passed */
  nas_hdr_scp_config_type_v01 hdr_scp_config;
  /**<   \n
    Note: This TLV is now DISCONTINUED, and is present here as a
          placeholder only for existing clients referencing this TLV.
   */

  /* Optional */
  /*  Roam Preference* */
  uint8_t roam_pref_valid;  /**< Must be set to true if roam_pref is being passed */
  nas_roam_config_pref_enum_v01 roam_pref;
  /**<   Roaming preference. Values: \n
       - 0x00 -- ROAM_CONFIG_PREF_AUTO               -- Acquire systems regardless of roaming status \n
       - 0x01 -- ROAM_CONFIG_PREF_HOME_ONLY          -- Acquire home systems only \n
       - 0x02 -- ROAM_CONFIG_PREF_ROAM_ONLY          -- Acquire nonhome systems only \n
       - 0x03 -- ROAM_CONFIG_PREF_HOME_AND_AFFILIATE -- Acquire home and affiliated roaming systems only
   */
}nas_set_device_config_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Sets network-related configuration settings of the device. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_set_device_config_resp_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_rf_band_info_req_msg is empty
 * typedef struct {
 * }nas_get_rf_band_info_req_msg_v01;
 */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Queries radio band/channel information regarding the
              system currently providing service.  */
typedef struct {

  /* Mandatory */
  /*  RF Band Information List */
  uint32_t rf_band_info_list_len;  /**< Must be set to # of elements in rf_band_info_list */
  nas_rf_band_info_type_v01 rf_band_info_list[NAS_RF_BAND_INFO_LIST_MAX_V01];

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_get_rf_band_info_resp_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_an_aaa_status_req_msg is empty
 * typedef struct {
 * }nas_get_an_aaa_status_req_msg_v01;
 */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_AN_AAA_STATUS_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_AAA_STATUS_FAILED_V01 = 0x00, 
  NAS_AAA_STATUS_SUCCESS_V01 = 0x01, 
  NAS_AAA_STATUS_NO_REQUEST_V01 = 0x02, 
  NAS_AN_AAA_STATUS_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_an_aaa_status_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Queries the status of the last AN-AAA authentication
              request for the current 1xEV-DO session. */
typedef struct {

  /* Mandatory */
  /*  AN-AAA Authentication Status */
  nas_an_aaa_status_enum_v01 an_aaa_status;
  /**<   Status of the last AN-AAA authentication request, if any, for
       the current 1xEV-DO session. Values: \n
       - 0 -- AAA_STATUS_FAILED     -- Authentication failed \n
       - 1 -- AAA_STATUS_SUCCESS    -- Authentication success \n
       - 2 -- AAA_STATUS_NO_REQUEST -- No authentication requested 
   */

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_get_an_aaa_status_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_PRL_PREF_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_PRL_PREF_A_SIDE_ONLY_V01 = 0x0001, 
  NAS_PRL_PREF_B_SIDE_ONLY_V01 = 0x0002, 
  NAS_PRL_PREF_ANY_V01 = 0x3FFF, 
  NAS_PRL_PREF_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_prl_pref_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_ROAM_PREF_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_ROAMING_PREF_OFF_V01 = 0x01, 
  NAS_ROAMING_PREF_NOT_OFF_V01 = 0x02, 
  NAS_ROAMING_PREF_NOT_FLASING_V01 = 0x03, 
  NAS_ROAMING_PREF_ANY_V01 = 0xFF, 
  NAS_ROAM_PREF_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_roam_pref_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_NET_SEL_PREF_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_NET_SEL_PREF_AUTOMATIC_V01 = 0x00, 
  NAS_NET_SEL_PREF_MANUAL_V01 = 0x01, 
  NAS_NET_SEL_PREF_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_net_sel_pref_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_SRV_DOMAIN_PREF_ENUM_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  QMI_SRV_DOMAIN_PREF_CS_ONLY_V01 = 0x00, 
  QMI_SRV_DOMAIN_PREF_PS_ONLY_V01 = 0x01, 
  QMI_SRV_DOMAIN_PREF_CS_PS_V01 = 0x02, 
  QMI_SRV_DOMAIN_PREF_PS_ATTACH_V01 = 0x03, 
  QMI_SRV_DOMAIN_PREF_PS_DETACH_V01 = 0x04, 
  NAS_SRV_DOMAIN_PREF_ENUM_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_srv_domain_pref_enum_type_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_GW_ACQ_ORDER_PREF_ENUM_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_GW_ACQ_ORDER_PREF_AUTOMATIC_V01 = 0x00, 
  NAS_GW_ACQ_ORDER_PREF_GSM_WCDMA_V01 = 0x01, 
  NAS_GW_ACQ_ORDER_PREF_WCDMA_GSM_V01 = 0x02, 
  NAS_GW_ACQ_ORDER_PREF_ENUM_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_gw_acq_order_pref_enum_type_v01;
/**
    @}
  */

typedef uint64_t nas_tdscdma_band_pref_mask_type_v01;
#define NAS_TDSCDMA_BAND_A_V01 ((nas_tdscdma_band_pref_mask_type_v01)0x01)
#define NAS_TDSCDMA_BAND_B_V01 ((nas_tdscdma_band_pref_mask_type_v01)0x02)
#define NAS_TDSCDMA_BAND_C_V01 ((nas_tdscdma_band_pref_mask_type_v01)0x04)
#define NAS_TDSCDMA_BAND_D_V01 ((nas_tdscdma_band_pref_mask_type_v01)0x08)
#define NAS_TDSCDMA_BAND_E_V01 ((nas_tdscdma_band_pref_mask_type_v01)0x10)
#define NAS_TDSCDMA_BAND_F_V01 ((nas_tdscdma_band_pref_mask_type_v01)0x20)
/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  nas_net_sel_pref_enum_v01 net_sel_pref;
  /**<   Specifies one of the following actions: \n
       - 0x00 -- NAS_NET_SEL_PREF_AUTOMATIC -- Device registers according to its 
                                               provisioning; mcc and mnc fields 
                                               of this TLV are ignored \n
       - 0x01 -- NAS_NET_SEL_PREF_MANUAL -- Device registers to specified network; 
                                        mcc and mnc fields must also contain 
                                        valid values  \n
       All other values are reserved.
   */

  uint16_t mcc;
  /**<   A 16-bit integer representation of MCC. Range: 0 to 999.
   */

  uint16_t mnc;
  /**<   A 16-bit integer representation of MNC. Range: 0 to 999.
   */
}nas_net_sel_pref_type_v01;  /* Type */
/**
    @}
  */

typedef uint64_t nas_band_pref_mask_type_v01;
#define QMI_NAS_BAND_CLASS_0_A_SYSTEM_V01 ((nas_band_pref_mask_type_v01)0x000000000000001)
#define QMI_NAS_BAND_CLASS_0_B_AB_GSM850_V01 ((nas_band_pref_mask_type_v01)0x000000000000002)
#define QMI_NAS_BAND_CLASS_1_ALL_BLOCKS_V01 ((nas_band_pref_mask_type_v01)0x000000000000004)
#define QMI_NAS_BAND_CLASS_2_PLACEHOLDER_V01 ((nas_band_pref_mask_type_v01)0x000000000000008)
#define QMI_NAS_BAND_CLASS_3_A_SYSTEM_V01 ((nas_band_pref_mask_type_v01)0x000000000000010)
#define QMI_NAS_BAND_CLASS_4_ALL_BLOCKS_V01 ((nas_band_pref_mask_type_v01)0x000000000000020)
#define QMI_NAS_BAND_CLASS_5_ALL_BLOCKS_V01 ((nas_band_pref_mask_type_v01)0x000000000000040)
#define QMI_NAS_GSM_DCS_1800_BAND_V01 ((nas_band_pref_mask_type_v01)0x000000000000080)
#define QMI_NAS_E_GSM_900_BAND_V01 ((nas_band_pref_mask_type_v01)0x000000000000100)
#define QMI_NAS_P_GSM_900_BAND_V01 ((nas_band_pref_mask_type_v01)0x000000000000200)
#define QMI_NAS_BAND_CLASS_6_V01 ((nas_band_pref_mask_type_v01)0x000000000000400)
#define QMI_NAS_BAND_CLASS_7_V01 ((nas_band_pref_mask_type_v01)0x000000000000800)
#define QMI_NAS_BAND_CLASS_8_V01 ((nas_band_pref_mask_type_v01)0x000000000001000)
#define QMI_NAS_BAND_CLASS_9_V01 ((nas_band_pref_mask_type_v01)0x000000000002000)
#define QMI_NAS_BAND_CLASS_10_V01 ((nas_band_pref_mask_type_v01)0x000000000004000)
#define QMI_NAS_BAND_CLASS_11_V01 ((nas_band_pref_mask_type_v01)0x000000000008000)
#define QMI_NAS_GSM_BAND_450_V01 ((nas_band_pref_mask_type_v01)0x000000000010000)
#define QMI_NAS_GSM_BAND_480_V01 ((nas_band_pref_mask_type_v01)0x000000000020000)
#define QMI_NAS_GSM_BAND_750_V01 ((nas_band_pref_mask_type_v01)0x000000000040000)
#define QMI_NAS_GSM_BAND_850_V01 ((nas_band_pref_mask_type_v01)0x000000000080000)
#define QMI_NAS_GSM_BAND_RAILWAYS_900_BAND_V01 ((nas_band_pref_mask_type_v01)0x000000000100000)
#define QMI_NAS_GSM_BAND_PCS_1900_BAND_V01 ((nas_band_pref_mask_type_v01)0x000000000200000)
#define QMI_NAS_WCDMA_EU_J_CH_IMT_2100_BAND_V01 ((nas_band_pref_mask_type_v01)0x000000000400000)
#define QMI_NAS_WCDMA_US_PCS_1900_BAND_V01 ((nas_band_pref_mask_type_v01)0x000000000800000)
#define QMI_NAS_EU_CH_DCS_1800_BAND_V01 ((nas_band_pref_mask_type_v01)0x000000001000000)
#define QMI_NAS_WCDMA_US_1700_BAND_V01 ((nas_band_pref_mask_type_v01)0x000000002000000)
#define QMI_NAS_WCDMA_US_850_BAND_V01 ((nas_band_pref_mask_type_v01)0x000000004000000)
#define QMI_NAS_WCDMA_JAPAN_800_BAND_V01 ((nas_band_pref_mask_type_v01)0x000000008000000)
#define QMI_NAS_BAND_CLASS_12_V01 ((nas_band_pref_mask_type_v01)0x000000010000000)
#define QMI_NAS_BAND_CLASS_14_V01 ((nas_band_pref_mask_type_v01)0x000000020000000)
#define QMI_NAS_RESERVED_V01 ((nas_band_pref_mask_type_v01)0x000000040000000)
#define QMI_NAS_BAND_CLASS_15_V01 ((nas_band_pref_mask_type_v01)0x000000080000000)
#define QMI_NAS_WCDMA_EU_2600_BAND_V01 ((nas_band_pref_mask_type_v01)0x001000000000000)
#define QMI_NAS_WCDMA_EU_J_900_BAND_V01 ((nas_band_pref_mask_type_v01)0x002000000000000)
#define QMI_NAS_WCDMA_J_1700_BAND_V01 ((nas_band_pref_mask_type_v01)0x004000000000000)
#define QMI_NAS_BAND_CLASS_16_V01 ((nas_band_pref_mask_type_v01)0x100000000000000)
#define QMI_NAS_BAND_CLASS_17_V01 ((nas_band_pref_mask_type_v01)0x200000000000000)
#define QMI_NAS_BAND_CLASS_18_V01 ((nas_band_pref_mask_type_v01)0x400000000000000)
#define QMI_NAS_BAND_CLASS_19_V01 ((nas_band_pref_mask_type_v01)0x800000000000000)
typedef uint64_t lte_band_pref_mask_type_v01;
#define E_UTRA_OPERATING_BAND_1_V01 ((lte_band_pref_mask_type_v01)0x000000000000001)
#define E_UTRA_OPERATING_BAND_2_V01 ((lte_band_pref_mask_type_v01)0x000000000000002)
#define E_UTRA_OPERATING_BAND_3_V01 ((lte_band_pref_mask_type_v01)0x000000000000004)
#define E_UTRA_OPERATING_BAND_4_V01 ((lte_band_pref_mask_type_v01)0x000000000000008)
#define E_UTRA_OPERATING_BAND_5_V01 ((lte_band_pref_mask_type_v01)0x000000000000010)
#define E_UTRA_OPERATING_BAND_6_V01 ((lte_band_pref_mask_type_v01)0x000000000000020)
#define E_UTRA_OPERATING_BAND_7_V01 ((lte_band_pref_mask_type_v01)0x000000000000040)
#define E_UTRA_OPERATING_BAND_8_V01 ((lte_band_pref_mask_type_v01)0x000000000000080)
#define E_UTRA_OPERATING_BAND_9_V01 ((lte_band_pref_mask_type_v01)0x000000000000100)
#define E_UTRA_OPERATING_BAND_10_V01 ((lte_band_pref_mask_type_v01)0x000000000000200)
#define E_UTRA_OPERATING_BAND_11_V01 ((lte_band_pref_mask_type_v01)0x000000000000400)
#define E_UTRA_OPERATING_BAND_12_V01 ((lte_band_pref_mask_type_v01)0x000000000000800)
#define E_UTRA_OPERATING_BAND_13_V01 ((lte_band_pref_mask_type_v01)0x000000000001000)
#define E_UTRA_OPERATING_BAND_14_V01 ((lte_band_pref_mask_type_v01)0x000000000002000)
#define E_UTRA_OPERATING_BAND_17_V01 ((lte_band_pref_mask_type_v01)0x000000000010000)
#define E_UTRA_OPERATING_BAND_18_V01 ((lte_band_pref_mask_type_v01)0x000000000020000)
#define E_UTRA_OPERATING_BAND_19_V01 ((lte_band_pref_mask_type_v01)0x000000000040000)
#define E_UTRA_OPERATING_BAND_20_V01 ((lte_band_pref_mask_type_v01)0x000000000080000)
#define E_UTRA_OPERATING_BAND_21_V01 ((lte_band_pref_mask_type_v01)0x000000000100000)
#define E_UTRA_OPERATING_BAND_24_V01 ((lte_band_pref_mask_type_v01)0x000000000800000)
#define E_UTRA_OPERATING_BAND_25_V01 ((lte_band_pref_mask_type_v01)0x000000001000000)
#define E_UTRA_OPERATING_BAND_33_V01 ((lte_band_pref_mask_type_v01)0x000000100000000)
#define E_UTRA_OPERATING_BAND_34_V01 ((lte_band_pref_mask_type_v01)0x000000200000000)
#define E_UTRA_OPERATING_BAND_35_V01 ((lte_band_pref_mask_type_v01)0x000000400000000)
#define E_UTRA_OPERATING_BAND_36_V01 ((lte_band_pref_mask_type_v01)0x000000800000000)
#define E_UTRA_OPERATING_BAND_37_V01 ((lte_band_pref_mask_type_v01)0x000001000000000)
#define E_UTRA_OPERATING_BAND_38_V01 ((lte_band_pref_mask_type_v01)0x000002000000000)
#define E_UTRA_OPERATING_BAND_39_V01 ((lte_band_pref_mask_type_v01)0x000004000000000)
#define E_UTRA_OPERATING_BAND_40_V01 ((lte_band_pref_mask_type_v01)0x000008000000000)
#define E_UTRA_OPERATING_BAND_41_V01 ((lte_band_pref_mask_type_v01)0x000010000000000)
#define E_UTRA_OPERATING_BAND_42_V01 ((lte_band_pref_mask_type_v01)0x000020000000000)
#define E_UTRA_OPERATING_BAND_43_V01 ((lte_band_pref_mask_type_v01)0x000040000000000)
typedef uint16_t mode_pref_mask_type_v01;
#define QMI_NAS_RAT_MODE_PREF_CDMA2000_1X_V01 ((mode_pref_mask_type_v01)0x01)
#define QMI_NAS_RAT_MODE_PREF_CDMA2000_HRPD_V01 ((mode_pref_mask_type_v01)0x02)
#define QMI_NAS_RAT_MODE_PREF_GSM_V01 ((mode_pref_mask_type_v01)0x04)
#define QMI_NAS_RAT_MODE_PREF_UMTS_V01 ((mode_pref_mask_type_v01)0x08)
#define QMI_NAS_RAT_MODE_PREF_LTE_V01 ((mode_pref_mask_type_v01)0x10)
#define QMI_NAS_RAT_MODE_PREF_TDSCDMA_V01 ((mode_pref_mask_type_v01)0x20)
/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Sets the different system selection preferences of the device.
              \label{idl:setSysSelPref} */
typedef struct {

  /* Optional */
  /*  Emergency Mode */
  uint8_t emergency_mode_valid;  /**< Must be set to true if emergency_mode is being passed */
  uint8_t emergency_mode;
  /**<   Values: \n
       - 0x00 -- OFF (normal) \n
       - 0x01 -- ON (emergency)
   */

  /* Optional */
  /*  Mode Preference */
  uint8_t mode_pref_valid;  /**< Must be set to true if mode_pref is being passed */
  mode_pref_mask_type_v01 mode_pref;
  /**<   Bitmask representing the radio technology mode preference to be set. 
       Values: \n
       - Bit 0 (0x01) -- QMI_NAS_RAT_MODE_PREF_ CDMA2000_1X   -- cdma2000 1X             \n
       - Bit 1 (0x02) -- QMI_NAS_RAT_MODE_PREF_ CDMA2000_HRPD -- cdma2000 HRPD (1xEV-DO) \n
       - Bit 2 (0x04) -- QMI_NAS_RAT_MODE_PREF_GSM            -- GSM \n
       - Bit 3 (0x08) -- QMI_NAS_RAT_MODE_PREF_UMTS           -- UMTS \n
       - Bit 4 (0x10) -- QMI_NAS_RAT_MODE_PREF_LTE            -- LTE \n
       - Bit 5 (0x20) -- QMI_NAS_RAT_MODE_PREF_ TDSCDMA       -- TD-SCDMA \n
       All unlisted bits are reserved for future use and the service point
       will ignore them if used.
   */

  /* Optional */
  /*  Band Preference */
  uint8_t band_pref_valid;  /**< Must be set to true if band_pref is being passed */
  nas_band_pref_mask_type_v01 band_pref;
  /**<   Bitmask representing the band preference to be set.  
       See Table @latexonly\ref{tbl:bandPreference}@endlatexonly 
       for details.   
   */

  /* Optional */
  /*  CDMA PRL Preference */
  uint8_t prl_pref_valid;  /**< Must be set to true if prl_pref is being passed */
  nas_prl_pref_enum_v01 prl_pref;
  /**<   PRL preference to be set for band class 0 (BC0) prl_pref. Values: \n
       - 0x0001 -- PRL_PREF_A_SIDE_ONLY -- Acquire available system only on the A side \n
       - 0x0002 -- PRL_PREF_B_SIDE_ONLY -- Acquire available system only on the B side \n
       - 0x3FFF -- PRL_PREF_ANY         -- Acquire any available systems
   */

  /* Optional */
  /*  Roaming Preference */
  uint8_t roam_pref_valid;  /**< Must be set to true if roam_pref is being passed */
  nas_roam_pref_enum_v01 roam_pref;
  /**<   Roaming preference to be set. Values: \n
       - 0x01 -- ROAMING_PREF_OFF         -- Acquire only systems for which the roaming indicator is off \n
       - 0x02 -- ROAMING_PREF_NOT_OFF     -- Acquire a system as long as its roaming indicator is not off \n
       - 0x03 -- ROAMING_PREF_NOT_FLASING -- Acquire only systems for which the roaming indicator is off or solid on, i.e., not flashing; CDMA only \n
       - 0xFF -- ROAMING_PREF_ANY         -- Acquire systems, regardless of their roaming indicator
   */

  /* Optional */
  /*  LTE Band Preference */
  uint8_t lte_band_pref_valid;  /**< Must be set to true if lte_band_pref is being passed */
  lte_band_pref_mask_type_v01 lte_band_pref;
  /**<   Bitmask representing the LTE band preference to be set. 
       See Table @latexonly\ref{tbl:lteBandPreference}@endlatexonly 
       for details.  
           */

  /* Optional */
  /*  Network Selection Preference */
  uint8_t net_sel_pref_valid;  /**< Must be set to true if net_sel_pref is being passed */
  nas_net_sel_pref_type_v01 net_sel_pref;

  /* Optional */
  /*  Change Duration */
  uint8_t change_duration_valid;  /**< Must be set to true if change_duration is being passed */
  nas_change_duration_enum_v01 change_duration;
  /**<    Duration of the change. Values: \n
        - 0x00 -- Power cycle -- Remains active until the next device power cycle \n
        - 0x01 -- Permanent -- Remains active through power cycles until changed by the client \n
        Note: The device will use "0x01 -- Permanent" as the default value 
              if the TLV is omitted.
   */

  /* Optional */
  /*  Service Domain */
  uint8_t srv_domain_pref_valid;  /**< Must be set to true if srv_domain_pref is being passed */
  nas_srv_domain_pref_enum_type_v01 srv_domain_pref;
  /**<    Service domain preference. Values: \n
       - 0x00  -- QMI_SRV_DOMAIN_PREF_CS_ONLY -- Circuit-switched only \n
       - 0x01  -- QMI_SRV_DOMAIN_PREF_PS_ONLY -- Packet-switched only  \n
       - 0x02  -- QMI_SRV_DOMAIN_PREF_CS_PS   -- Circuit-switched and packet-switched \n
       - 0x03  -- QMI_SRV_DOMAIN_PREF_PS_ATTACH -- Packet-switched attach \n
       - 0x04  -- QMI_SRV_DOMAIN_PREF_PS_DETACH -- Packet-switched detach
   */

  /* Optional */
  /*  GSM/WCDMA Acquisition Order */
  uint8_t gw_acq_order_pref_valid;  /**< Must be set to true if gw_acq_order_pref is being passed */
  nas_gw_acq_order_pref_enum_type_v01 gw_acq_order_pref;
  /**<    GSM/WCDMA acquisition order preference. Values: \n
       - 0x00 -- NAS_GW_ACQ_ORDER_PREF_AUTOMATIC -- Automatic \n
       - 0x01 -- NAS_GW_ACQ_ORDER_PREF_GSM_ WCDMA -- GSM then WCDMA \n
       - 0x02 -- NAS_GW_ACQ_ORDER_PREF_WCDMA_ GSM -- WCDMA then GSM
     */

  /* Optional */
  /* MNC PCS Digit Include Status */
  uint8_t mnc_includes_pcs_digit_valid;  /**< Must be set to true if mnc_includes_pcs_digit is being passed */
  uint8_t mnc_includes_pcs_digit;
  /**<   This field is used to interpret the length of the corresponding
       MNC reported in the Network Selection Preference TLV (0x16). Values: \n

       - TRUE  -- MNC is a three-digit value; e.g., a reported value of 
                  90 corresponds to an MNC value of 090  \n
       - FALSE -- MNC is a two-digit value; e.g., a reported value of 
                  90 corresponds to an MNC value of 90
     */

  /* Optional */
  /*  TDSCDMA Band Preference */
  uint8_t tdscdma_band_pref_valid;  /**< Must be set to true if tdscdma_band_pref is being passed */
  nas_tdscdma_band_pref_mask_type_v01 tdscdma_band_pref;
  /**<   Bitmask representing the TD-SCDMA band preference to be set. Values: \n
       - 0x01 -- NAS_TDSCDMA_BAND_A  -- TD-SCDMA \n Band A \n
       - 0x02 -- NAS_TDSCDMA_BAND_B  -- TD-SCDMA \n Band B \n
       - 0x04 -- NAS_TDSCDMA_BAND_C  -- TD-SCDMA \n Band C \n
       - 0x08 -- NAS_TDSCDMA_BAND_D  -- TD-SCDMA \n Band D \n
       - 0x10 -- NAS_TDSCDMA_BAND_E  -- TD-SCDMA \n Band E \n
       - 0x20 -- NAS_TDSCDMA_BAND_F  -- TD-SCDMA \n Band F \n
       All other bits are reserved.
   */

  /* Optional */
  /*  Acquisition Order Preference */
  uint8_t acq_order_valid;  /**< Must be set to true if acq_order is being passed */
  uint32_t acq_order_len;  /**< Must be set to # of elements in acq_order */
  nas_radio_if_enum_v01 acq_order[NAS_ACQ_ORDER_LIST_MAX_V01];
  /**<   Acquisition order preference to be set. Values: \n
    - 0x01 -- NAS_RADIO_IF_CDMA_1X     -- cdma2000 1X             \n
    - 0x02 -- NAS_RADIO_IF_CDMA_1XEVDO -- cdma2000 HRPD (1xEV-DO) \n
    - 0x04 -- NAS_RADIO_IF_GSM         -- GSM \n
    - 0x05 -- NAS_RADIO_IF_UMTS        -- UMTS \n
    - 0x08 -- NAS_RADIO_IF_LTE         -- LTE \n
    - 0x09 -- NAS_RADIO_IF_TDSCDMA     -- TD-SCDMA
   */
}nas_set_system_selection_preference_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Sets the different system selection preferences of the device.
              \label{idl:setSysSelPref} */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_set_system_selection_preference_resp_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_system_selection_preference_req_msg is empty
 * typedef struct {
 * }nas_get_system_selection_preference_req_msg_v01;
 */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Queries the different system selection preferences of the 
              device.
              \label{idl:getSysSelPref} */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */

  /* Optional */
  /*  Emergency Mode */
  uint8_t emergency_mode_valid;  /**< Must be set to true if emergency_mode is being passed */
  uint8_t emergency_mode;
  /**<   Values: \n
       - 0x00 -- OFF (normal) \n
       - 0x01 -- ON (emergency)
   */

  /* Optional */
  /*  Mode Preference */
  uint8_t mode_pref_valid;  /**< Must be set to true if mode_pref is being passed */
  mode_pref_mask_type_v01 mode_pref;
  /**<   Bitmask representing the radio technology mode preference to be set. 
       Values: \n
       - Bit 0 (0x01) -- QMI_NAS_RAT_MODE_PREF_ CDMA2000_1X   -- cdma2000 1X             \n
       - Bit 1 (0x02) -- QMI_NAS_RAT_MODE_PREF_ CDMA2000_HRPD -- cdma2000 HRPD (1xEV-DO) \n
       - Bit 2 (0x04) -- QMI_NAS_RAT_MODE_PREF_GSM            -- GSM \n
       - Bit 3 (0x08) -- QMI_NAS_RAT_MODE_PREF_UMTS           -- UMTS \n
       - Bit 4 (0x10) -- QMI_NAS_RAT_MODE_PREF_LTE            -- LTE \n
       - Bit 5 (0x20) -- QMI_NAS_RAT_MODE_PREF_ TDSCDMA       -- TD-SCDMA \n
       All unlisted bits are reserved for future use and the service point
       will ignore them if used.
   */

  /* Optional */
  /*  Band Preference */
  uint8_t band_pref_valid;  /**< Must be set to true if band_pref is being passed */
  nas_band_pref_mask_type_v01 band_pref;
  /**<   Bitmask representing the band preference to be set. 
       See Table @latexonly\ref{tbl:bandPreference}@endlatexonly 
       for details.   
     */

  /* Optional */
  /*  CDMA PRL Preference */
  uint8_t prl_pref_valid;  /**< Must be set to true if prl_pref is being passed */
  nas_prl_pref_enum_v01 prl_pref;
  /**<   PRL preference to be set for band class 0 (BC0) prl_pref. Values: \n
       - 0x0001 -- PRL_PREF_A_SIDE_ONLY -- Acquire available system only on the A side \n
       - 0x0002 -- PRL_PREF_B_SIDE_ONLY -- Acquire available system only on the B side \n
       - 0x3FFF -- PRL_PREF_ANY         -- Acquire any available systems
   */

  /* Optional */
  /*  Roaming Preference */
  uint8_t roam_pref_valid;  /**< Must be set to true if roam_pref is being passed */
  nas_roam_pref_enum_v01 roam_pref;
  /**<   Roaming preference to be set. Values: \n
       - 0x01 -- ROAMING_PREF_OFF         -- Acquire only systems for which the roaming indicator is off \n
       - 0x02 -- ROAMING_PREF_NOT_OFF     -- Acquire a system as long as its roaming indicator is not off \n
       - 0x03 -- ROAMING_PREF_NOT_FLASING -- Acquire only systems for which the roaming indicator is off or solid on, i.e., not flashing; CDMA only \n
       - 0xFF -- ROAMING_PREF_ANY         -- Acquire systems, regardless of their roaming indicator
   */

  /* Optional */
  /*  LTE Band Preference */
  uint8_t band_pref_ext_valid;  /**< Must be set to true if band_pref_ext is being passed */
  uint64_t band_pref_ext;
  /**<   Bitmask representing the LTE band preference to be set. Values: \n
         - Bit 0  -- E-UTRA Operating Band 1 \n
         - Bit 1  -- E-UTRA Operating Band 2 \n
         - Bit 2  -- E-UTRA Operating Band 3 \n
         - Bit 3  -- E-UTRA Operating Band 4 \n
         - Bit 4  -- E-UTRA Operating Band 5 \n
         - Bit 5  -- E-UTRA Operating Band 6 \n
         - Bit 6  -- E-UTRA Operating Band 7 \n
         - Bit 7  -- E-UTRA Operating Band 8 \n
         - Bit 8  -- E-UTRA Operating Band 9 \n
         - Bit 9  -- E-UTRA Operating Band 10 \n
         - Bit 10 -- E-UTRA Operating Band 11 \n
         - Bit 11 -- E-UTRA Operating Band 12 \n
         - Bit 12 -- E-UTRA Operating Band 13 \n
         - Bit 13 -- E-UTRA Operating Band 14 \n
         - Bit 16 -- E-UTRA Operating Band 17 \n
         - Bit 17 -- E-UTRA Operating Band 18 \n
         - Bit 18 -- E-UTRA Operating Band 19 \n
         - Bit 19 -- E-UTRA Operating Band 20 \n
         - Bit 20 -- E-UTRA Operating Band 21 \n
         - Bit 23 -- E-UTRA Operating Band 24 \n
         - Bit 24 -- E-UTRA Operating Band 25 \n
         - Bit 32 -- E-UTRA Operating Band 33 \n
         - Bit 33 -- E-UTRA Operating Band 34 \n
         - Bit 34 -- E-UTRA Operating Band 35 \n
         - Bit 35 -- E-UTRA Operating Band 36 \n
         - Bit 36 -- E-UTRA Operating Band 37 \n
         - Bit 37 -- E-UTRA Operating Band 38 \n
         - Bit 38 -- E-UTRA Operating Band 39 \n
         - Bit 39 -- E-UTRA Operating Band 40 \n
         - Bit 40 -- E-UTRA Operating Band 41 \n
         - Bit 41 -- E-UTRA Operating Band 42 \n
         - Bit 42 -- E-UTRA Operating Band 43 \n
         All other bits are reserved.
   */

  /* Optional */
  /*  Network Selection Preference */
  uint8_t net_sel_pref_valid;  /**< Must be set to true if net_sel_pref is being passed */
  nas_net_sel_pref_enum_v01 net_sel_pref;
  /**<   Network selection preference. Values: \n
       - 0x00 -- Automatic network selection \n
       - 0x01 -- Manual network selection
   */

  /* Optional */
  /*  Service Domain Preference */
  uint8_t srv_domain_pref_valid;  /**< Must be set to true if srv_domain_pref is being passed */
  nas_srv_domain_pref_enum_type_v01 srv_domain_pref;
  /**<   Service domain preference. Values: \n
       - 0x00  -- QMI_SRV_DOMAIN_PREF_CS_ONLY -- Circuit-switched only \n
       - 0x01  -- QMI_SRV_DOMAIN_PREF_PS_ONLY -- Packet-switched only  \n
       - 0x02  -- QMI_SRV_DOMAIN_PREF_CS_PS   -- Circuit-switched and packet-switched \n
       - 0x03  -- QMI_SRV_DOMAIN_PREF_PS_ATTACH -- Packet-switched attach \n
       - 0x04  -- QMI_SRV_DOMAIN_PREF_PS_DETACH -- Packet-switched detach
   */

  /* Optional */
  /*  GSM/WCDMA Acquisition Order Preference */
  uint8_t gw_acq_order_pref_valid;  /**< Must be set to true if gw_acq_order_pref is being passed */
  nas_gw_acq_order_pref_enum_type_v01 gw_acq_order_pref;
  /**<   GSM/WCDMA acquisition order preference. Values: \n
       - 0x00 -- NAS_GW_ACQ_ORDER_PREF_AUTOMATIC -- Automatic \n
       - 0x01 -- NAS_GW_ACQ_ORDER_PREF_GSM_ WCDMA -- GSM then WCDMA \n
       - 0x02 -- NAS_GW_ACQ_ORDER_PREF_WCDMA_ GSM -- WCDMA then GSM
     */

  /* Optional */
  /*  TDSCDMA Band Preference */
  uint8_t tdscdma_band_pref_valid;  /**< Must be set to true if tdscdma_band_pref is being passed */
  nas_tdscdma_band_pref_mask_type_v01 tdscdma_band_pref;
  /**<   Bitmask representing the TD-SCDMA band preference to be set. Values: \n
       - 0x01 -- NAS_TDSCDMA_BAND_A  -- TD-SCDMA \n Band A \n
       - 0x02 -- NAS_TDSCDMA_BAND_B  -- TD-SCDMA \n Band B \n
       - 0x04 -- NAS_TDSCDMA_BAND_C  -- TD-SCDMA \n Band C \n
       - 0x08 -- NAS_TDSCDMA_BAND_D  -- TD-SCDMA \n Band D \n
       - 0x10 -- NAS_TDSCDMA_BAND_E  -- TD-SCDMA \n Band E \n
       - 0x20 -- NAS_TDSCDMA_BAND_F  -- TD-SCDMA \n Band F \n
       All other bits are reserved.
   */

  /* Optional */
  /*  Manual Network Selection PLMN */
  uint8_t manual_net_sel_plmn_valid;  /**< Must be set to true if manual_net_sel_plmn is being passed */
  nas_mnc_pcs_digit_include_status_type_v01 manual_net_sel_plmn;

  /* Optional */
  /*  Acquisition Order Preference */
  uint8_t acq_order_valid;  /**< Must be set to true if acq_order is being passed */
  uint32_t acq_order_len;  /**< Must be set to # of elements in acq_order */
  nas_radio_if_enum_v01 acq_order[NAS_ACQ_ORDER_LIST_MAX_V01];
  /**<   Acquisition order preference to be set. Values: \n
    - 0x01 -- NAS_RADIO_IF_CDMA_1X     -- cdma2000 1X             \n
    - 0x02 -- NAS_RADIO_IF_CDMA_1XEVDO -- cdma2000 HRPD (1xEV-DO) \n
    - 0x04 -- NAS_RADIO_IF_GSM         -- GSM \n
    - 0x05 -- NAS_RADIO_IF_UMTS        -- UMTS \n
    - 0x08 -- NAS_RADIO_IF_LTE         -- LTE \n
    - 0x09 -- NAS_RADIO_IF_TDSCDMA     -- TD-SCDMA
   */
}nas_get_system_selection_preference_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Indication Message; Queries the different system selection preferences of the 
              device.
              \label{idl:getSysSelPref} */
typedef struct {

  /* Optional */
  /*  Emergency Mode */
  uint8_t emergency_mode_valid;  /**< Must be set to true if emergency_mode is being passed */
  uint8_t emergency_mode;
  /**<   Values: \n
       - 0x00 -- OFF (normal) \n
       - 0x01 -- ON (emergency)
   */

  /* Optional */
  /*  Mode Preference */
  uint8_t mode_pref_valid;  /**< Must be set to true if mode_pref is being passed */
  mode_pref_mask_type_v01 mode_pref;
  /**<   Bitmask representing the radio technology mode preference to be set. 
       Values: \n
       - Bit 0 (0x01) -- QMI_NAS_RAT_MODE_PREF_ CDMA2000_1X   -- cdma2000 1X \n
       - Bit 1 (0x02) -- QMI_NAS_RAT_MODE_PREF_ CDMA2000_HRPD -- cdma2000 HRPD (1xEV-DO) \n
       - Bit 2 (0x04) -- QMI_NAS_RAT_MODE_PREF_GSM            -- GSM \n
       - Bit 3 (0x08) -- QMI_NAS_RAT_MODE_PREF_UMTS           -- UMTS \n
       - Bit 4 (0x10) -- QMI_NAS_RAT_MODE_PREF_LTE            -- LTE \n
       - Bit 5 (0x20) -- QMI_NAS_RAT_MODE_PREF_ TDSCDMA       -- TD-SCDMA \n
       All unlisted bits are reserved for future use.
   */

  /* Optional */
  /*  Band Preference */
  uint8_t band_pref_valid;  /**< Must be set to true if band_pref is being passed */
  nas_band_pref_mask_type_v01 band_pref;
  /**<   Bitmask representing the band preference to be set. 
       See Table @latexonly\ref{tbl:bandPreference}@endlatexonly 
       for details.   
   */

  /* Optional */
  /*  CDMA PRL Preference */
  uint8_t prl_pref_valid;  /**< Must be set to true if prl_pref is being passed */
  nas_prl_pref_enum_v01 prl_pref;
  /**<   PRL preference to be set for band class 0 (BC0) prl_pref. Values: \n
       - 0x0001 -- PRL_PREF_A_SIDE_ONLY -- Acquire available system only on the A side \n
       - 0x0002 -- PRL_PREF_B_SIDE_ONLY -- Acquire available system only on the B side \n
       - 0x3FFF -- PRL_PREF_ANY         -- Acquire any available systems
   */

  /* Optional */
  /*  Roaming Preference */
  uint8_t roam_pref_valid;  /**< Must be set to true if roam_pref is being passed */
  nas_roam_pref_enum_v01 roam_pref;
  /**<   Roaming preference to be set. Values: \n
       - 0x01 -- ROAMING_PREF_OFF         -- Acquire only systems for which the roaming indicator is off \n
       - 0x02 -- ROAMING_PREF_NOT_OFF     -- Acquire a system as long as its roaming indicator is not off \n
       - 0x03 -- ROAMING_PREF_NOT_FLASING -- Acquire only systems for which the roaming indicator is off or solid on, i.e., not flashing; CDMA only \n
       - 0xFF -- ROAMING_PREF_ANY         -- Acquire systems, regardless of their roaming indicator
   */

  /* Optional */
  /*  LTE Band Preference */
  uint8_t lte_band_pref_valid;  /**< Must be set to true if lte_band_pref is being passed */
  lte_band_pref_mask_type_v01 lte_band_pref;
  /**<   Bitmask representing the LTE band preference to be set. 
       See Table @latexonly\ref{tbl:lteBandPreference}@endlatexonly 
       for details.  
   */

  /* Optional */
  /*  Network Selection Preference */
  uint8_t net_sel_pref_valid;  /**< Must be set to true if net_sel_pref is being passed */
  nas_net_sel_pref_enum_v01 net_sel_pref;
  /**<   Network selection preference. Values: \n
       - 0x00 -- Automatic network selection \n
       - 0x01 -- Manual network selection
   */

  /* Optional */
  /*  Service Domain Preference */
  uint8_t srv_domain_pref_valid;  /**< Must be set to true if srv_domain_pref is being passed */
  nas_srv_domain_pref_enum_type_v01 srv_domain_pref;
  /**<   Service domain preference. Values: \n
       - 0x00  -- QMI_SRV_DOMAIN_PREF_CS_ONLY -- Circuit-switched only \n
       - 0x01  -- QMI_SRV_DOMAIN_PREF_PS_ONLY -- Packet-switched only  \n
       - 0x02  -- QMI_SRV_DOMAIN_PREF_CS_PS   -- Circuit-switched and packet-switched \n
       - 0x03  -- QMI_SRV_DOMAIN_PREF_PS_ATTACH -- Packet-switched attach \n
       - 0x04  -- QMI_SRV_DOMAIN_PREF_PS_DETACH -- Packet-switched detach
   */

  /* Optional */
  /*  GSM/WCDMA Acquisition Order Preference */
  uint8_t gw_acq_order_pref_valid;  /**< Must be set to true if gw_acq_order_pref is being passed */
  nas_gw_acq_order_pref_enum_type_v01 gw_acq_order_pref;
  /**<   GSM/WCDMA acquisition order preference. Values: \n
       - 0x00 -- NAS_GW_ACQ_ORDER_PREF_AUTOMATIC -- Automatic \n
       - 0x01 -- NAS_GW_ACQ_ORDER_PREF_GSM_ WCDMA -- GSM then WCDMA \n
       - 0x02 -- NAS_GW_ACQ_ORDER_PREF_WCDMA_ GSM -- WCDMA then GSM
     */

  /* Optional */
  /*  TDSCDMA Band Preference */
  uint8_t tdscdma_band_pref_valid;  /**< Must be set to true if tdscdma_band_pref is being passed */
  nas_tdscdma_band_pref_mask_type_v01 tdscdma_band_pref;
  /**<   Bitmask representing the TD-SCDMA band preference to be set. Values: \n
       - 0x01 -- NAS_TDSCDMA_BAND_A  -- TD-SCDMA \n Band A \n
       - 0x02 -- NAS_TDSCDMA_BAND_B  -- TD-SCDMA \n Band B \n
       - 0x04 -- NAS_TDSCDMA_BAND_C  -- TD-SCDMA \n Band C \n
       - 0x08 -- NAS_TDSCDMA_BAND_D  -- TD-SCDMA \n Band D \n
       - 0x10 -- NAS_TDSCDMA_BAND_E  -- TD-SCDMA \n Band E \n
       - 0x20 -- NAS_TDSCDMA_BAND_F  -- TD-SCDMA \n Band F \n
       All other bits are reserved.
   */

  /* Optional */
  /*  Manual Network Selection PLMN */
  uint8_t manual_net_sel_plmn_valid;  /**< Must be set to true if manual_net_sel_plmn is being passed */
  nas_mnc_pcs_digit_include_status_type_v01 manual_net_sel_plmn;

  /* Optional */
  /*  Acquisition Order Preference */
  uint8_t acq_order_valid;  /**< Must be set to true if acq_order is being passed */
  uint32_t acq_order_len;  /**< Must be set to # of elements in acq_order */
  nas_radio_if_enum_v01 acq_order[NAS_ACQ_ORDER_LIST_MAX_V01];
  /**<   Acquisition order preference to be set. Values: \n
    - 0x01 -- NAS_RADIO_IF_CDMA_1X     -- cdma2000 1X             \n
    - 0x02 -- NAS_RADIO_IF_CDMA_1XEVDO -- cdma2000 HRPD (1xEV-DO) \n
    - 0x04 -- NAS_RADIO_IF_GSM         -- GSM \n
    - 0x05 -- NAS_RADIO_IF_UMTS        -- UMTS \n
    - 0x08 -- NAS_RADIO_IF_LTE         -- LTE \n
    - 0x09 -- NAS_RADIO_IF_TDSCDMA     -- TD-SCDMA
   */

  /* Optional */
  /*  srv_reg_restriction */
  uint8_t srv_reg_restriction_valid;  /**< Must be set to true if srv_reg_restriction is being passed */
  uint32_t srv_reg_restriction;

  /* Optional */
  /*  CSG PLMN info */
  uint8_t csg_plmn_info_valid;  /**< Must be set to true if csg_radio_if is being passed */
  uint16_t mcc;
  uint16_t mnc;
  uint8_t mnc_includes_pcs_digit;
  uint32_t csg_id;
  uint8_t csg_radio_if;
}nas_system_selection_preference_ind_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_DDTM_PREF_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_DDTM_PREF_OFF_V01 = 0x00, 
  NAS_DDTM_PREF_ON_V01 = 0x01, 
  NAS_DDTM_PREF_NO_CHANGE_V01 = 0x02, 
  NAS_DDTM_PREF_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_ddtm_pref_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_SO_LIST_ACTION_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_SO_LIST_ACTION_ADD_V01 = 0x00, 
  NAS_SO_LIST_ACTION_REPLACE_V01 = 0x01, 
  NAS_SO_LIST_ACTION_DELETE_V01 = 0x02, 
  NAS_SO_LIST_ACTION_NO_CHANGE_V01 = 0x03, 
  NAS_SO_LIST_ACTION_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_so_list_action_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  nas_ddtm_pref_enum_v01 ddtm_pref;
  /**<   DDTM preference setting. Values: \n
       - 0x00 -- DDTM_PREF_OFF       -- Disable DDTM \n
       - 0x01 -- DDTM_PREF_ON        -- Enable DDTM \n
       - 0x02 -- DDTM_PREF_NO_CHANGE -- Do not change DDTM preference
   */

  uint16_t ddtm_action;
  /**<   Bitmask (with each bit specifying action) representing what
       combined DDTM actions should take place. Values: \n
       - Bit 0 -- QMI_NAS_DDTM_ACTION_SUPPRESS_ L2ACK_BIT  -- Do not send L2 ACK on 1X \n
       - Bit 1 -- QMI_NAS_DDTM_ACTION_SUPPRESS_ REG_BIT    -- Suppress 1X registrations \n
       - Bit 2 -- QMI_NAS_DDTM_ACTION_IGNORE_SO_ PAGES_BIT -- Ignore 1X pages with specified service options \n
       - Bit 3 -- QMI_NAS_DDTM_ACTION_SUPPRESS_ MO_DBM_BIT -- Block MO SMS and DBM

  To enable all masks, a value of 0x3FFF must be sent in this field.
   */

  nas_so_list_action_enum_v01 so_list_action;
  /**<   Action to be taken with the specified SO list in the SO field. Values: \n
       - 0x00 -- SO_LIST_ACTION_ADD       -- Add the specified SOs to the current DDTM SO list \n
       - 0x01 -- SO_LIST_ACTION_REPLACE   -- Replace the current DDTM SO list \n
       - 0x02 -- SO_LIST_ACTION_DELETE    -- Delete the specified SOs from the DDTM SO list \n
       - 0x03 -- SO_LIST_ACTION_NO_CHANGE -- No change in the DDTM SO list
   */

  uint32_t so_len;  /**< Must be set to # of elements in so */
  uint16_t so[NAS_SO_LIST_MAX_V01];
  /**<   Service option for which SO pages are ignored
       when DDTM status is ON. See [S4, Table 3.1-1] for standard SO
       number assignments. To ignore all SO pages, a value of 0xFFFF
       must be specified.
   */
}nas_ddtm_preference_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Sets the Data Dedicated Transmission Mode (DDTM) preference 
              for the device. */
typedef struct {

  /* Mandatory */
  /*  DDTM Preference */
  nas_ddtm_preference_type_v01 ddtm_preference;
}nas_set_ddtm_preference_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Sets the Data Dedicated Transmission Mode (DDTM) preference 
              for the device. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_set_ddtm_preference_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_CURR_DDTM_STATUS_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_CURRENT_DDTM_STATUS_DISABLED_V01 = 0x00, 
  NAS_CURRENT_DDTM_STATUS_ENABLED_V01 = 0x01, 
  NAS_CURR_DDTM_STATUS_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_curr_ddtm_status_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  nas_curr_ddtm_status_enum_v01 curr_ddtm_status;
  /**<   Current DDTM status. Values: \n
       - 0x00 -- CURRENT_DDTM_STATUS_DISABLED \n
       - 0x01 -- CURRENT_DDTM_STATUS_ENABLED
   */

  nas_ddtm_pref_enum_v01 ddtm_pref;
  /**<   DDTM preference setting. Values: \n
       - 0x00 -- DDTM_PREF_OFF       -- Disable DDTM \n
       - 0x01 -- DDTM_PREF_ON        -- Enable DDTM
   */

  uint16_t ddtm_action;
  /**<   Bitmask (with each bit specifying action) representing what
       combined DDTM actions should take place. Values: \n
       - Bit 0 -- QMI_NAS_DDTM_ACTION_SUPPRESS_ L2ACK_BIT  -- Do not send L2 ACK on 1X \n
       - Bit 1 -- QMI_NAS_DDTM_ACTION_SUPPRESS_ REG_BIT    -- Suppress 1X registrations \n
       - Bit 2 -- QMI_NAS_DDTM_ACTION_IGNORE_SO_ PAGES_BIT -- Ignore 1X pages with specified service options \n
       - Bit 3 -- QMI_NAS_DDTM_ACTION_SUPPRESS_ MO_DBM_BIT -- Block MO SMS and DBM \n
       To enable all masks, a value of 0x3FFF must be sent in this field
   */

  nas_so_list_action_enum_v01 so_list_action;
  /**<   Action to be taken with the specified SO list in the SO field. Values: \n
       - 0x00 -- SO_LIST_ACTION_ADD       -- Add the specified SOs to the current DDTM SO list \n
       - 0x01 -- SO_LIST_ACTION_REPLACE   -- Replace the current DDTM SO list \n
       - 0x02 -- SO_LIST_ACTION_DELETE    -- Delete the specified SOs from the DDTM SO list \n
       - 0x03 -- SO_LIST_ACTION_NO_CHANGE -- No change in the DDTM SO list
   */

  uint32_t so_len;  /**< Must be set to # of elements in so */
  uint16_t so[NAS_SO_LIST_MAX_V01];
  /**<   Service option for which SO pages are ignored
       when DDTM status is ON. See [S4, Table 3.1-1] for standard SO
       number assignments. To ignore all SO pages, a value of 0xFFFF
       must be specified.
   */
}nas_ddtm_settings_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Indication Message; Provides the DDTM status of the device. */
typedef struct {

  /* Mandatory */
  /*  DDTM Settings */
  nas_ddtm_settings_type_v01 ddtm_settings;
}nas_ddtm_ind_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_operator_name_data_req_msg is empty
 * typedef struct {
 * }nas_get_operator_name_data_req_msg_v01;
 */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t display_cond;
  /**<   Display condition */

  uint32_t spn_len;  /**< Must be set to # of elements in spn */
  uint8_t spn[NAS_SERVICE_PROVIDER_NAME_MAX_V01];
  /**<    Service provider name string must use: \n
        - The SMS default 7-bit coded alphabet as defined in [S8] with 
          bit 8 set to 9 \n
        - One UCS2 code option defined in [S9, Annex B]
   */
}nas_service_provider_name_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  char mcc[NAS_MCC_MNC_MAX_V01];
  /**<   MCC in ASCII string (a value of D in any of the digits is to be used
       to indicate a "wild" value for that corresponding digit).
   */

  char mnc[NAS_MCC_MNC_MAX_V01];
  /**<   MNC in ASCII string (a value of D in any of the digits is to be used
       to indicate a "wild" value for that corresponding digit; digit 3 in MNC
       is optional and when not present, will be set as ASCII F).
   */

  uint16_t lac1;
  /**<   Location area code 1. */

  uint16_t lac2;
  /**<   Location area code 2. */

  uint8_t pnn_rec_id;
  /**<   PLMN network name record identifier. */
}nas_operator_plmn_list_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_CODING_SCHEME_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_CODING_SCHEME_CELL_BROADCAST_GSM_V01 = 0x00, 
  NAS_CODING_SCHEME_UCS2_V01 = 0x01, 
  NAS_CODING_SCHEME_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_coding_scheme_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_COUNTRY_INITIALS_ADD_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_COUNTRY_INITIALS_DO_NOT_ADD_V01 = 0x00, 
  NAS_COUNTRY_INITIALS_ADD_V01 = 0x01, 
  NAS_COUNTRY_INITIALS_UNSPEFICIED_V01 = 0xFF, 
  NAS_COUNTRY_INITIALS_ADD_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_country_initials_add_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_SPARE_BITS_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_SPARE_BITS_8_V01 = 0x01, 
  NAS_SPARE_BITS_7_TO_8_V01 = 0x02, 
  NAS_SPARE_BITS_6_TO_8_V01 = 0x03, 
  NAS_SPARE_BITS_5_TO_8_V01 = 0x04, 
  NAS_SPARE_BITS_4_TO_8_V01 = 0x05, 
  NAS_SPARE_BITS_3_TO_8_V01 = 0x06, 
  NAS_SPARE_BITS_2_TO_8_V01 = 0x07, 
  NAS_SPARE_BITS_UNKNOWN_V01 = 0x00, 
  NAS_SPARE_BITS_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_spare_bits_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  nas_coding_scheme_enum_v01 coding_scheme;
  /**<   Coding scheme. Values: \n
       - 0x00 -- NAS_CODING_SCHEME_CELL_ BROADCAST_GSM -- Cell broadcast data 
                 coding scheme, GSM default alphabet, language unspecified; 
                                                  defined in [S8] \n
       - 0x01 -- NAS_CODING_SCHEME_UCS2 -- UCS2 (16 bit) [S10]
   */

  nas_country_initials_add_enum_v01 ci;
  /**<   Country's intials. Values: \n
       - 0x00 -- COUNTRY_INITIALS_DO_NOT_ADD -- MS does not add the letters 
                 for the country's initials to the text string \n
       - 0x01 -- COUNTRY_INITIALS_ADD -- MS adds the letters for the 
                 country's initials and a separator, e.g., a space, to the text 
                 string
   */

  nas_spare_bits_enum_v01 long_name_spare_bits;
  /**<   Values: \n
       - 0x01 -- SPARE_BITS_8       -- Bit 8 is spare and set to 0 in octet n                       \n
       - 0x02 -- SPARE_BITS_7_TO_8  -- Bits 7 and 8 are spare and set to 0 in octet n               \n
       - 0x03 -- SPARE_BITS_6_TO_8  -- Bits 6 to 8 (inclusive) are spare and set to 0 in octet n    \n
       - 0x04 -- SPARE_BITS_5_TO_8  -- Bits 5 to 8 (inclusive) are spare and set to 0 in octet n    \n
       - 0x05 -- SPARE_BITS_4_TO_8  -- Bits 4 to 8 (inclusive) are spare and set to 0 in octet n    \n
       - 0x06 -- SPARE_BITS_3_TO_8  -- Bits 3 to 8 (inclusive) are spare and set to 0 in octet n    \n
       - 0x07 -- SPARE_BITS_2_TO_8  -- Bits 2 to 8 (inclusive) are spare and set to 0 in octet n    \n
       - 0x00 -- SPARE_BITS_UNKNOWN -- Carries no information about the number of spare bits in octet n
   */

  nas_spare_bits_enum_v01 short_name_spare_bits;
  /**<   Values: \n
       - 0x01 -- SPARE_BITS_8       -- Bit 8 is spare and set to 0 in octet n                       \n
       - 0x02 -- SPARE_BITS_7_TO_8  -- Bits 7 and 8 are spare and set to 0 in octet n               \n
       - 0x03 -- SPARE_BITS_6_TO_8  -- Bits 6 to 8 (inclusive) are spare and set to 0 in octet n    \n
       - 0x04 -- SPARE_BITS_5_TO_8  -- Bits 5 to 8 (inclusive) are spare and set to 0 in octet n    \n
       - 0x05 -- SPARE_BITS_4_TO_8  -- Bits 4 to 8 (inclusive) are spare and set to 0 in octet n    \n
       - 0x06 -- SPARE_BITS_3_TO_8  -- Bits 3 to 8 (inclusive) are spare and set to 0 in octet n    \n
       - 0x07 -- SPARE_BITS_2_TO_8  -- Bits 2 to 8 (inclusive) are spare and set to 0 in octet n    \n
       - 0x00 -- SPARE_BITS_UNKNOWN -- Carries no information about the number of spare bits in octet n
   */

  uint32_t long_name_len;  /**< Must be set to # of elements in long_name */
  uint8_t long_name[NAS_LONG_NAME_MAX_V01];
  /**<   Long name string in coding_scheme. */

  uint32_t short_name_len;  /**< Must be set to # of elements in short_name */
  uint8_t short_name[NAS_SHORT_NAME_MAX_V01];
  /**<   Short name string in coding_scheme. */
}nas_plmn_network_name_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Retrieves operator name data from multiple sources. (deprecated) */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type. 
 Standard response type. Contains the following data members:
     - qmi_result_type -- QMI_RESULT_SUCCESS or QMI_RESULT_FAILURE \n
     - qmi_error_type  -- Error code. Possible error code values are described in
                          the error codes section of each message definition.
    */

  /* Optional */
  /*  Service Provider Name (see [S7, Section 4.2.12]) */
  uint8_t service_provider_name_valid;  /**< Must be set to true if service_provider_name is being passed */
  nas_service_provider_name_type_v01 service_provider_name;

  /* Optional */
  /*  Operator PLMN List (see [S7, Section 4.2.59]) */
  uint8_t operator_plmn_list_valid;  /**< Must be set to true if operator_plmn_list is being passed */
  uint32_t operator_plmn_list_len;  /**< Must be set to # of elements in operator_plmn_list */
  nas_operator_plmn_list_type_v01 operator_plmn_list[NAS_OPERATOR_PLMN_LIST_MAX_V01];

  /* Optional */
  /*  PLMN Network Name (see [S5, Section 10.5.3.5a]) */
  uint8_t plmn_network_name_valid;  /**< Must be set to true if plmn_network_name is being passed */
  uint32_t plmn_network_name_len;  /**< Must be set to # of elements in plmn_network_name */
  nas_plmn_network_name_type_v01 plmn_network_name[NAS_PLMN_NETWORK_NAME_LIST_MAX_V01];

  /* Optional */
  /*  Operator Name String (see [S11 Section B.4.1.2]) */
  uint8_t plmn_name_valid;  /**< Must be set to true if plmn_name is being passed */
  char plmn_name[NAS_PLMN_NAME_MAX_V01 + 1];
  /**<   PLMN name must be coded in a default 7-bit alphabet with b8 set to 0. */

  /* Optional */
  /*  NITZ Information */
  uint8_t nitz_information_valid;  /**< Must be set to true if nitz_information is being passed */
  nas_plmn_network_name_type_v01 nitz_information;
}nas_get_operator_name_data_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Indication Message; Indicates a change in operator name data, which is obtained 
              from multiple sources. (deprecated) */
typedef struct {

  /* Optional */
  /*  Service Provider Name (see [S7, Section 4.2.12]) */
  uint8_t service_provider_name_valid;  /**< Must be set to true if service_provider_name is being passed */
  nas_service_provider_name_type_v01 service_provider_name;

  /* Optional */
  /*  Operator PLMN List (see [S7, Section 4.2.59]) */
  uint8_t operator_plmn_list_valid;  /**< Must be set to true if operator_plmn_list is being passed */
  uint32_t operator_plmn_list_len;  /**< Must be set to # of elements in operator_plmn_list */
  nas_operator_plmn_list_type_v01 operator_plmn_list[NAS_OPERATOR_PLMN_LIST_MAX_V01];

  /* Optional */
  /*  PLMN Network Name (see [S5, Section 10.5.3.5a]) */
  uint8_t plmn_network_name_valid;  /**< Must be set to true if plmn_network_name is being passed */
  uint32_t plmn_network_name_len;  /**< Must be set to # of elements in plmn_network_name */
  nas_plmn_network_name_type_v01 plmn_network_name[NAS_PLMN_NETWORK_NAME_LIST_MAX_V01];

  /* Optional */
  /*  Operator Name String (see [S11, Section B.4.1.2]) */
  uint8_t plmn_name_valid;  /**< Must be set to true if plmn_name is being passed */
  char plmn_name[NAS_PLMN_NAME_MAX_V01 + 1];
  /**<   PLMN name must be coded in a default 7-bit alphabet with b8 set to 0 */

  /* Optional */
  /*  NITZ Information */
  uint8_t nitz_information_valid;  /**< Must be set to true if nitz_information is being passed */
  nas_plmn_network_name_type_v01 nitz_information;
}nas_operator_name_data_ind_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_csp_plmn_mode_bit_req_msg is empty
 * typedef struct {
 * }nas_get_csp_plmn_mode_bit_req_msg_v01;
 */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_PLMN_MODE_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_PLMN_MODE_DO_NOT_RESTRICT_V01 = 0x00, 
  NAS_PLMN_MODE_RESTRICT_V01 = 0x01, 
  NAS_PLMN_MODE_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_plmn_mode_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Retrieves the PLMN MODE bit data from the Customer Service 
              Profile (CSP). */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */

  /* Optional */
  /*  PLMN Mode (see [S11, Section 4.7.1]) */
  uint8_t plmn_mode_valid;  /**< Must be set to true if plmn_mode is being passed */
  nas_plmn_mode_enum_v01 plmn_mode;
  /**<   Values: \n
       - 0x00 -- PLMN_MODE_DO_NOT_RESTRICT -- Do not restrict menu options for manual PLMN selection \n
       - 0x01 -- PLMN_MODE_RESTRICT        -- Restrict menu options for manual PLMN selection
   */
}nas_get_csp_plmn_mode_bit_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Indication Message; Provides any change in the PLMN MODE bit in the CSP. */
typedef struct {

  /* Optional */
  /*  PLMN Mode (see [S11, Section 4.7.1]) */
  uint8_t plmn_mode_valid;  /**< Must be set to true if plmn_mode is being passed */
  nas_plmn_mode_enum_v01 plmn_mode;
  /**<   Values: \n
       - 0x00 -- PLMN_MODE_DO_NOT_RESTRICT -- Do not restrict menu options for manual PLMN selection \n
       - 0x01 -- PLMN_MODE_RESTRICT        -- Restrict menu options for manual PLMN selection
   */
}nas_csp_plmn_mode_bit_ind_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Updates the A-KEY. (Discontinued) */
typedef struct {

  /* Mandatory */
  /*  AKEY */
  uint8_t akey[26];
  /**<   AKEY value + checksum value in ASCII (first 20 bytes are the AKEY value,
       last 6 bytes are the checksum).
   */
}nas_update_akey_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Updates the A-KEY. (Discontinued) */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_update_akey_resp_msg_v01;  /* Message */
/**
    @}
  */

typedef uint32_t get_3gpp2_info_mask_enum_type_v01;
#define QMI_NAS_GET_3GPP2_SUBS_INFO_NAM_NAME_V01 ((get_3gpp2_info_mask_enum_type_v01)0x01)
#define QMI_NAS_GET_3GPP2_SUBS_INFO_DIR_NUM_V01 ((get_3gpp2_info_mask_enum_type_v01)0x02)
#define QMI_NAS_GET_3GPP2_SUBS_INFO_HOME_SID_IND_V01 ((get_3gpp2_info_mask_enum_type_v01)0x04)
#define QMI_NAS_GET_3GPP2_SUBS_INFO_MIN_BASED_IMSI_V01 ((get_3gpp2_info_mask_enum_type_v01)0x08)
#define QMI_NAS_GET_3GPP2_SUBS_INFO_TRUE_IMSI_V01 ((get_3gpp2_info_mask_enum_type_v01)0x10)
#define QMI_NAS_GET_3GPP2_SUBS_INFO_CDMA_CHANNEL_V01 ((get_3gpp2_info_mask_enum_type_v01)0x20)
#define QMI_NAS_GET_3GPP2_SUBS_INFO_MDN_V01 ((get_3gpp2_info_mask_enum_type_v01)0x40)
/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Retrieves 3GPP2 subscription-related information. */
typedef struct {

  /* Mandatory */
  /*  NAM ID */
  uint8_t nam_id;
  /**<   NAM ID of the information to be retrieved. The index starts from 0. 
       A nam_id of 0xFF is used to retrieve information of current NAM.
   */

  /* Optional */
  /*  Get 3GPP2 Info Bitmask */
  uint8_t get_3gpp2_info_mask_valid;  /**< Must be set to true if get_3gpp2_info_mask is being passed */
  get_3gpp2_info_mask_enum_type_v01 get_3gpp2_info_mask;
  /**<   Bitmasks included in this field decide which optional TLVs are to be 
       included in the response message. If this TLV is not included, all 
       available information is sent as part of the response message. \n \vspace{-.12in}

       The bitmask enum value, bitmask enum member name, and TLV that is 
       included are: \n

       - 0x01 -- QMI_NAS_GET_3GPP2_SUBS_INFO_ NAM_NAME       -- Nam Name \n
       - 0x02 -- QMI_NAS_GET_3GPP2_SUBS_INFO_ DIR_NUM        -- Directory Number \n
       - 0x04 -- QMI_NAS_GET_3GPP2_SUBS_INFO_ HOME_SID_IND   -- Home SID/NID \n
       - 0x08 -- QMI_NAS_GET_3GPP2_SUBS_INFO_ MIN_BASED_IMSI -- Min-based IMSI \n
       - 0x10 -- QMI_NAS_GET_3GPP2_SUBS_INFO_ TRUE_IMSI      -- True IMSI \n
       - 0x20 -- QMI_NAS_GET_3GPP2_SUBS_INFO_ CDMA_CHANNEL   -- CDMA Channel \n
       - 0x40 -- QMI_NAS_GET_3GPP2_SUBS_INFO_MDN             -- Mobile Directory Number

     All other bits are reserved for future use.
     */
}nas_get_3gpp2_subscription_info_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t sid;
  /**<   System ID.  */

  uint16_t nid;
  /**<   Network ID.  */
}nas_3gpp2_home_sid_nid_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  MCC_M */
  char mcc_m[NAS_MCC_LEN_V01];
  /**<   ASCII character representation of MCC_M; 
       example: 000, 123, etc.
   */

  /*  IMSI_M_11_12 */
  char imsi_m_11_12[NAS_IMSI_11_12_LEN_V01];
  /**<   ASCII character representation of IMSI_M_11_12 value;
       example: 00, 01, etc.
   */

  /*  IMSI_M_S1 */
  char imsi_m_s1[NAS_IMSI_MIN1_LEN_V01];
  /**<   ASCII character representation of IMSI_M_S1 value;
       example: 0123456.
   */

  /*  IMSI_M_S2 */
  char imsi_m_s2[NAS_IMSI_MIN2_LEN_V01];
  /**<   ASCII character representation of IMSI_M_S2 value;
       example: 012.
   */
}nas_3gpp2_min_based_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  MCC_T */
  char mcc_t[NAS_MCC_LEN_V01];
  /**<   ASCII character representation of MCC_T;
       example: 000, 123, etc.
   */

  /*  IMSI_T_11_12 */
  char imsi_t_11_12[NAS_IMSI_11_12_LEN_V01];
  /**<   ASCII character representation of IMSI_T_11_12 value;
       example: 00, 01, etc.
   */

  /*  IMSI_T_S1 */
  char imsi_t_s1[NAS_IMSI_MIN1_LEN_V01];
  /**<   ASCII character representation of IMSI_T_S1 value;
       example: 0123456.
   */

  /*  IMSI_T_S2 */
  char imsi_t_s2[NAS_IMSI_MIN2_LEN_V01];
  /**<   ASCII character representation of IMSI_T_S2 value;
       example: 012.
   */

  /*  IMSI_T_ADDR_NUM */
  uint8_t imsi_t_addr_num;
  /**<   Value of IMSI_T_ADDR_NUM.
   */
}nas_3gpp2_true_imsi_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t pri_ch_a;
  /**<   A Channel number for the primary carrier.  */

  uint16_t pri_ch_b;
  /**<   B Channel number for the primary carrier.  */

  uint16_t sec_ch_a;
  /**<   A Channel number for the secondary carrier.  */

  uint16_t sec_ch_b;
  /**<   B Channel number for the secondary carrier.  */
}nas_cdma_channel_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Retrieves 3GPP2 subscription-related information. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */

  /* Optional */
  /*  NAM Name (information retrieved from NV_NAME_NAM_I) */
  uint8_t nam_name_valid;  /**< Must be set to true if nam_name is being passed */
  uint32_t nam_name_len;  /**< Must be set to # of elements in nam_name */
  char nam_name[NAS_MAX_NAM_NAME_LEN_V01];
  /**<   Name information in ASCII. The maximum length of nam_name is 12.
   */

  /* Optional */
  /*  Directory Number (information retrieved from NV_DIR_NUMBER_I) */
  uint8_t dir_num_valid;  /**< Must be set to true if dir_num is being passed */
  uint32_t dir_num_len;  /**< Must be set to # of elements in dir_num */
  char dir_num[NAS_MAX_3GPP2_SUBS_INFO_DIR_NUM_LEN_V01];
  /**<   Directory number in ASCII characters.
   */

  /* Optional */
  /*  Home SID/NID (information retrieved from NV_HOME_SID_NID_I) */
  uint8_t cdma_sys_id_valid;  /**< Must be set to true if cdma_sys_id is being passed */
  uint32_t cdma_sys_id_len;  /**< Must be set to # of elements in cdma_sys_id */
  nas_3gpp2_home_sid_nid_info_type_v01 cdma_sys_id[NAS_MAX_3GPP2_HOME_SID_NID_NUM_V01];

  /* Optional */
  /*  MIN-based IMSI (information retrieved from NV_IMSI_MCC_I, NV_IMSI_11_12_I, NV_MIN1_I, and NV_MIN2_I) */
  uint8_t min_based_info_valid;  /**< Must be set to true if min_based_info is being passed */
  nas_3gpp2_min_based_info_type_v01 min_based_info;

  /* Optional */
  /*  True IMSI (information retrieved from NV_IMSI_T_MCC_I, NV_IMSI_T_11_12_I, NV_IMSI_T_S1_I, NV_IMSI_T_S2_I, and NV_IMSI_T_ADDR_NUM_I) */
  uint8_t true_imsi_valid;  /**< Must be set to true if true_imsi is being passed */
  nas_3gpp2_true_imsi_info_type_v01 true_imsi;

  /* Optional */
  /*  CDMA Channel (information retrieved from NV_PCDMACH_I and NV_SCDMACH_I) */
  uint8_t cdma_channel_info_valid;  /**< Must be set to true if cdma_channel_info is being passed */
  nas_cdma_channel_info_type_v01 cdma_channel_info;

  /* Optional */
  /*  Mobile Directory Number (information retrieved from NV_DIR_NUMBER_PCS_I) */
  uint8_t mdn_valid;  /**< Must be set to true if mdn is being passed */
  uint32_t mdn_len;  /**< Must be set to # of elements in mdn */
  char mdn[MDN_MAX_LEN_V01];
  /**<   Mobile directory number represented in ASCII format with a maximum 
       length of 15 characters. Valid values for individual characters in the 
       MDN are digits 0 through 9, and special characters * and #.
   */
}nas_get_3gpp2_subscription_info_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Writes 3GPP2 subscription-related information. */
typedef struct {

  /* Mandatory */
  /*  NAM ID */
  uint8_t nam_id;
  /**<   NAM ID of the information to be written. The index starts from 0. 
       A nam_id of 0xFF is used to write information to current NAM.
   */

  /* Optional */
  /*  Directory Number (information written to NV_DIR_NUMBER_I) */
  uint8_t dir_num_valid;  /**< Must be set to true if dir_num is being passed */
  uint32_t dir_num_len;  /**< Must be set to # of elements in dir_num */
  char dir_num[NAS_MAX_3GPP2_SUBS_INFO_DIR_NUM_LEN_V01];
  /**<   Directory number in ASCII characters.
   */

  /* Optional */
  /*  Home SID/NID (information written to NV_HOME_SID_NID_I) */
  uint8_t cdma_sys_id_valid;  /**< Must be set to true if cdma_sys_id is being passed */
  uint32_t cdma_sys_id_len;  /**< Must be set to # of elements in cdma_sys_id */
  nas_3gpp2_home_sid_nid_info_type_v01 cdma_sys_id[NAS_MAX_3GPP2_HOME_SID_NID_NUM_V01];

  /* Optional */
  /*  MIN-based IMSI (information written to NV_IMSI_MCC_I, NV_IMSI_11_12_I, NV_MIN1_I, and NV_MIN2_I) */
  uint8_t min_based_info_valid;  /**< Must be set to true if min_based_info is being passed */
  nas_3gpp2_min_based_info_type_v01 min_based_info;

  /* Optional */
  /*  True IMSI (information written to NV_IMSI_T_MCC_I, NV_IMSI_T_11_12_I, NV_IMSI_T_S1_I, NV_IMSI_T_S2_I, and NV_IMSI_T_ADDR_NUM_I) */
  uint8_t true_imsi_valid;  /**< Must be set to true if true_imsi is being passed */
  nas_3gpp2_true_imsi_info_type_v01 true_imsi;

  /* Optional */
  /*  CDMA Channel (information written to NV_PCDMACH_I and NV_SCDMACH_I) */
  uint8_t cdma_channel_info_valid;  /**< Must be set to true if cdma_channel_info is being passed */
  nas_cdma_channel_info_type_v01 cdma_channel_info;

  /* Optional */
  /*  NAM Name (information written to NV_NAME_NAM_I) */
  uint8_t nam_name_valid;  /**< Must be set to true if nam_name is being passed */
  uint32_t nam_name_len;  /**< Must be set to # of elements in nam_name */
  char nam_name[NAS_MAX_NAM_NAME_LEN_V01];
  /**<   Name information in ASCII. The maximum length of nam_name is 12.
   */

  /* Optional */
  /*  Mobile Directory Number (information written to NV_DIR_NUMBER_PCS_I) */
  uint8_t mdn_valid;  /**< Must be set to true if mdn is being passed */
  uint32_t mdn_len;  /**< Must be set to # of elements in mdn */
  char mdn[MDN_MAX_LEN_V01];
  /**<   Mobile directory number represented in ASCII format with a maximum 
       length of 15 characters. Valid values for individual characters in the 
       MDN are digits 0 through 9, and special characters * and #.
   */
}nas_set_3gpp2_subscription_info_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Writes 3GPP2 subscription-related information. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_set_3gpp2_subscription_info_resp_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_mob_cai_rev_req is empty
 * typedef struct {
 * }nas_get_mob_cai_rev_req_v01;
 */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Retrieves Mobile CAI revision information. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */

  /* Optional */
  /*  CAI revision (information retrieved from NV_MOB_CAI_REV_I) */
  uint8_t cai_rev_valid;  /**< Must be set to true if cai_rev is being passed */
  uint8_t cai_rev;
  /**<   CAI revision. Values: \n
       - 0x01 -- P_REV_JSTD008 \n
       - 0x03 -- P_REV_IS95A \n
       - 0x04 -- P_REV_IS95B \n
       - 0x06 -- P_REV_IS2000 \n
       - 0x07 -- P_REV_IS2000_REL_A    \n
       - 0x08 -- P_REV_IS2000_REL_B    \n
       - 0x09 -- P_REV_IS2000_REL_C    \n
       - 0x0A -- P_REV_IS2000_REL_C_MI \n
       - 0x0B -- P_REV_IS2000_REL_D
   */
}nas_get_mob_cai_rev_resp_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_rtre_config_req is empty
 * typedef struct {
 * }nas_get_rtre_config_req_v01;
 */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_RTRE_CFG_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_RTRE_CFG_RUIM_ONLY_V01 = 0x01, 
  NAS_RTRE_CFG_INTERNAL_SETTINGS_ONLY_V01 = 0x02, 
  NAS_RTRE_CFG_RUIM_IF_AVAIL_V01 = 0x03, 
  NAS_RTRE_CFG_GSM_ON_1X_V01 = 0x04, 
  NAS_RTRE_CFG_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_rtre_cfg_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Retrieves current RTRE configuration information. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */

  /* Optional */
  /*  Current RTRE Configuration */
  uint8_t rtre_cfg_valid;  /**< Must be set to true if rtre_cfg is being passed */
  nas_rtre_cfg_enum_v01 rtre_cfg;
  /**<   Values: \n
       -0x01 -- R-UIM only \n
       -0x02 -- Internal settings only \n
       -0x04 -- GSM on 1X
   */

  /* Optional */
  /*  RTRE Configuration Preference */
  uint8_t rtre_cfg_pref_valid;  /**< Must be set to true if rtre_cfg_pref is being passed */
  nas_rtre_cfg_enum_v01 rtre_cfg_pref;
  /**<   Values: \n
       -0x01 -- R-UIM only \n
       -0x02 -- Internal settings only \n
       -0x03 -- Use R-UIM if available \n
       -0x04 -- GSM on 1X
   */
}nas_get_rtre_config_resp_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Sets RTRE configuration preference. */
typedef struct {

  /* Mandatory */
  /*  RTRE Configuration */
  nas_rtre_cfg_enum_v01 rtre_cfg_pref;
  /**<   Values: \n
       -0x01 -- R-UIM only \n
       -0x02 -- Internal settings only \n
       -0x03 -- Use R-UIM if available \n
       -0x04 -- GSM on 1X (deprecated; will be converted to "Internal settings only" when used)
   */
}nas_set_rtre_config_req_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Sets RTRE configuration preference. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_set_rtre_config_resp_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_cell_location_info_req_msg is empty
 * typedef struct {
 * }nas_get_cell_location_info_req_msg_v01;
 */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Cell id */
  uint32_t nmr_cell_id;
  /**<   Cell ID (0xFFFFFFFF indicates cell ID information is not present).
   */

  /*  PLMN */
  char nmr_plmn[NAS_PLMN_LEN_V01];
  /**<   MCC/MNC information coded as octet 3, 4, and 5 in [S5, Section 10.5.1.3].
       (This field is ignored when nmr_cell_id is not present.)
   */

  /*  LAC */
  uint16_t nmr_lac;
  /**<   Location area code. (This field is ignored when nmr_cell_id is not present.)
   */

  /*  ARFCN */
  uint16_t nmr_arfcn;
  /**<   Absolute RF channel number.
   */

  /*  BSIC */
  uint8_t nmr_bsic;
  /**<   Base station identity code.
   */

  /*  Rx Lev */
  uint16_t nmr_rx_lev;
  /**<   Cell Rx measurement. Values range between 0 and 63, which is 
       mapped to a measured signal level: \n

       - Rxlev 0 is a signal strength less than -110 dBm \n
       - Rxlev 1 is -110 dBm to -109 dBm    \n
       - Rxlev 2 is -109 dBm to -108 dBm    \n
       - ...                                \n
       - Rxlev 62 is -49 dBm to -48 dBm     \n
       - Rxlev 63 is greater than -48 dBm
   */
}nas_nmr_cell_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Cell id */
  uint32_t cell_id;
  /**<   Cell ID (0xFFFFFFFF indicates cell ID information is not present).
   */

  /*  PLMN */
  char plmn[NAS_PLMN_LEN_V01];
  /**<   MCC/MNC information coded as octet 3, 4, and 5 in [S5, Section 10.5.1.3].
       (This field is ignored when cell_id is not present.)
   */

  /*  LAC */
  uint16_t lac;
  /**<   Location area code. (This field is ignored when cell_id not present.)
   */

  /*  ARFCN */
  uint16_t arfcn;
  /**<   Absolute RF channel number.
   */

  /*  BSIC */
  uint8_t bsic;
  /**<   Base station identity code.
   */

  /*  Timing Advance */
  uint32_t timing_advance;
  /**<   Measured delay (in bit periods; 1 bit period = 48/13 microsecond) of 
       access burst transmission on RACH or PRACH to the expected signal from 
       an MS at zero distance under static channel conditions.
   */

  /*  Rx Lev */
  uint16_t rx_lev;
  /**<   Serving cell Rx measurement. Values range between 0 and 63, which is 
       mapped to a measured signal level: \n

       - Rxlev 0 is a signal strength less than -110 dBm \n
       - Rxlev 1 is -110 dBm to -109 dBm    \n
       - Rxlev 2 is -109 dBm to -108 dBm    \n
       - ...                               \n
       - Rxlev 62 is -49 dBm to -48 dBm     \n
       - Rxlev 63 is greater than -48 dBm
   */

  /*  Neighbor cell information  */
  uint32_t nmr_cell_info_len;  /**< Must be set to # of elements in nmr_cell_info */
  nas_nmr_cell_info_type_v01 nmr_cell_info[NAS_NMR_MAX_NUM_V01];
  /**<   Contains information only if neighbors are present; 
       includes: \n
       - nmr_cell_id \n
       - nmr_plmn \n
       - nmr_lac \n
       - nmr_arfcn \n
       - nmr_bsic \n
       - nmr_rx_lev
   */
}nas_geran_cell_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  UARFCN */
  uint16_t umts_uarfcn;
  /**<   UTRA absolute RF channel number.
   */

  /*  PSC */
  uint16_t umts_psc;
  /**<   Primary scrambling code.
   */

  /*  RSCP */
  int16_t umts_rscp;
  /**<   Received signal code power.
   */

  /*  Ec/Io */
  int16_t umts_ecio;
  /**<   ECIO.
   */
}nas_umts_monitored_cell_set_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  UARFCN */
  uint16_t geran_arfcn;
  /**<   Absolute RF channel number.
   */

  /*  BSIC NCC */
  uint8_t geran_bsic_ncc;
  /**<   Base station identity code network color code
       (0xFF indicates information is not present).
   */

  /*  BSIC BCC */
  uint8_t geran_bsic_bcc;
  /**<   Base station identity code base station color code
       (0xFF indicates information is not present).
   */

  /*  GERAN RSSI */
  int16_t geran_rssi;
  /**<   Received signal strength indicator.
   */
}nas_umts_geran_nbr_cell_set_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Cell id */
  uint16_t cell_id;
  /**<   Cell ID (0xFFFFFFFF indicates cell ID information is not present).
   */

  /*  PLMN */
  char plmn[NAS_PLMN_LEN_V01];
  /**<   MCC/MNC information coded as octet 3, 4, and 5 in [S5, Section 10.5.1.3]. 
       (This field is ignored when cell_id is not present.)
   */

  /*  LAC */
  uint16_t lac;
  /**<   Location area code. (This field is ignored when cell_id is not present.)
   */

  /*  UARFCN */
  uint16_t uarfcn;
  /**<   UTRA absolute RF channel number.
   */

  /*  PSC */
  uint16_t psc;
  /**<   Primary scrambling code.
   */

  /*  RSCP */
  int16_t rscp;
  /**<   Received signal code power. 
   */

  /*  Ec/Io */
  int16_t ecio;
  /**<   ECIO. 
   */

  /*  UMTS Monitored Cell info set */
  uint32_t umts_monitored_cell_len;  /**< Must be set to # of elements in umts_monitored_cell */
  nas_umts_monitored_cell_set_info_type_v01 umts_monitored_cell[NAS_UMTS_MAX_MONITORED_CELL_SET_NUM_V01];

  /*  GERAN Neighbor cell info set */
  uint32_t umts_geran_nbr_cell_len;  /**< Must be set to # of elements in umts_geran_nbr_cell */
  nas_umts_geran_nbr_cell_set_info_type_v01 umts_geran_nbr_cell[NAS_UMTS_GERAN_MAX_NBR_CELL_SET_NUM_V01];
}nas_umts_cell_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t sid;
  /**<   System ID.  */

  uint16_t nid;
  /**<   Network ID.  */

  uint16_t base_id;
  /**<   Base station ID.  */

  uint16_t refpn;
  /**<   Reference PN.  */

  uint32_t base_lat;
  /**<   Latitude of the current base station in units of 0.25 sec.  */

  uint32_t base_long;
  /**<   Longitude of the current base station in units of 0.25 sec.  */
}nas_cdma_cell_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t pci;
  /**<   Physical cell ID. Range: 0 to 503.  */

  int16_t rsrq;
  /**<   Current RSRQ in 1/10 dB as measured by L1.  
    Range: -200 to -30 (e.g., -200 means -20.0 dB).  */

  int16_t rsrp;
  /**<   Current RSRP in 1/10 dBm as measured by L1. 
    Range: -1400 to -440 (e.g., -440 means -44.0 dBm).  */

  int16_t rssi;
  /**<   Current RSSI in 1/10 dBm as measured by L1.
    Range: -1200 to 0 (e.g., -440 means -44.0 dBm).  */

  int16_t srxlev;
  /**<   Cell selection Rx level (Srxlev) value. Range: -128 to 128. 
    (This field is only valid when ue_in_idle is TRUE.)  */
}nas_lte_ngbr_cell_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t ue_in_idle;
  /**<   TRUE if the UE is in Idle mode; otherwise FALSE.  */

  uint8_t plmn[NAS_PLMN_LEN_V01];
  /**<   PLMN ID coded as octet 3, 4, and 5 in [S5, Section 10.5.1.3].  */

  uint16_t tac;
  /**<   Tracking area code.  */

  uint32_t global_cell_id;
  /**<   Global cell ID in the system information block.  */

  uint16_t earfcn;
  /**<   E-UTRA absolute radio frequency channel number of the serving cell. 
     Range: 0 to 65535.  */

  uint16_t serving_cell_id;
  /**<   LTE serving cell ID. Range: 0 to 503. This is the cell ID of the 
    serving cell and can be found in the cell list.  */

  uint8_t cell_resel_priority;
  /**<   Priority for serving frequency. Range: 0 to 7. (This field is only 
    valid when ue_in_idle is TRUE.)  */

  uint8_t s_non_intra_search;
  /**<   S non-intra search threshold to control non-intrafrequency searches. 
    Range: 0 to 31. (This field is only valid when ue_in_idle is TRUE.)  */

  uint8_t thresh_serving_low;
  /**<   Serving cell low threshold. Range: 0 to 31. (This field is only 
    valid when ue_in_idle is TRUE.)  */

  uint8_t s_intra_search;
  /**<   S intra search threshold. Range: 0 to 31. The current cell 
    measurement must fall below this threshold to consider intrafrequency 
    for reselection. (This field is only valid when ue_in_idle is TRUE.)  */

  uint32_t cells_len;  /**< Must be set to # of elements in cells */
  nas_lte_ngbr_cell_type_v01 cells[NAS_MAX_LTE_NGBR_NUM_CELLS_V01];
}nas_lte_intra_freq_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t earfcn;
  /**<   E-UTRA absolute radio frequency channel number. Range: 0 to 65535.  */

  uint8_t threshX_low;
  /**<   Cell Srxlev low threshold. Range: 0 to 31.  
    When the serving cell does not exceed thresh_serving_low, 
    the value of an evaluated cell must be smaller than this value to be 
    considered for reselection.  */

  uint8_t threshX_high;
  /**<   Cell Srxlev high threshold. Range: 0 to 31. 
    When the serving cell exceeds thresh_serving_low, 
    the value of an evaluated cell must be greater than this value to be 
    considered for reselection.  */

  uint8_t cell_resel_priority;
  /**<   Cell reselection priority. Range: 0 to 7. (This field is only valid 
    when ue_in_idle is TRUE.)  */

  uint32_t cells_len;  /**< Must be set to # of elements in cells */
  nas_lte_ngbr_cell_type_v01 cells[NAS_MAX_LTE_NGBR_NUM_CELLS_V01];
}nas_lte_inter_freq_freqs_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t ue_in_idle;
  /**<   TRUE if the UE is in Idle mode; otherwise FALSE.  */

  uint32_t freqs_len;  /**< Must be set to # of elements in freqs */
  nas_lte_inter_freq_freqs_type_v01 freqs[NAS_MAX_LTE_NGBR_NUM_FREQS_V01];
}nas_lte_inter_freq_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t arfcn;
  /**<   GSM frequency being reported. Range: 0 to 1023.  */

  uint8_t band_1900;
  /**<   Band indicator for the GSM ARFCN (this field is only valid if arfcn 
    is in the overlapping region). If TRUE and the cell is in the overlapping 
    region, the ARFCN is on the 1900 band. If FALSE, it is on the 1800 band.  */

  uint8_t cell_id_valid;
  /**<   Flag indicating whether the base station identity code ID is valid.  */

  uint8_t bsic_id;
  /**<   Base station identity code ID, including base station color code and
    network color code. The lower 6 bits can be set to any value.  */

  int16_t rssi;
  /**<   Measured RSSI value in 1/10 dB. 
    Range: -2000 to 0  (e.g., -800 means -80.0 dB).  */

  int16_t srxlev;
  /**<   Cell selection Rx level (Srxlev) value. Range: -128 to 128. 
    (This field is only valid when ue_in_idle is TRUE.)  */
}nas_lte_ngbr_gsm_cell_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t cell_resel_priority;
  /**<   Priority of this frequency group. Range: 0 to 7. (This field is only 
    valid when ue_in_idle is TRUE.)  */

  uint8_t thresh_gsm_high;
  /**<   Reselection threshold for high priority layers. Range: 0 to 31. 
    (This field is only valid when ue_in_idle is TRUE.)  */

  uint8_t thresh_gsm_low;
  /**<   Reselection threshold for low priority layers. Range: 0 to 31. 
    (This field is only valid when ue_in_idle is TRUE.)  */

  uint8_t ncc_permitted;
  /**<    Bitmask specifying whether a neighbor with a specific network color
    code is to be reported. Range: 0 to 255. Bit n set to 1 means a neighbor 
    with NCC n must be included in the report. This flag is synonymous with a
    blacklist in other RATs. (This field is only valid when ue_in_idle is
    TRUE.)  */

  uint32_t cells_len;  /**< Must be set to # of elements in cells */
  nas_lte_ngbr_gsm_cell_type_v01 cells[NAS_MAX_LTE_NGBR_GSM_NUM_CELLS_V01];
}nas_lte_ngbr_gsm_freq_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t ue_in_idle;
  /**<   TRUE if the UE is in Idle mode; otherwise FALSE.  */

  uint32_t freqs_len;  /**< Must be set to # of elements in freqs */
  nas_lte_ngbr_gsm_freq_type_v01 freqs[NAS_MAX_LTE_NGBR_GSM_NUM_FREQS_V01];
}nas_lte_ngbr_gsm_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t psc;
  /**<   Primary scrambling code. Range: 0 to 511.  */

  int16_t cpich_rscp;
  /**<   Absolute power level (in 1/10 dBm) of the common pilot channel as 
    received by the UE. Range: -1200 to -250 (e.g., -250 means -25.0 dBm). 
    Defined in [S14].  */

  int16_t cpich_ecno;
  /**<   CPICH Ec/No; ratio (in 1/10 dB) of the received energy per PN chip for 
    the CPICH to the total received power spectral density at the UE antenna 
    connector. Range: -500 to 0 (e.g., -25 means -2.5 dB). Defined in [S14].  */

  int16_t srxlev;
  /**<   Cell selection Rx level (Srxlev) value. Range: -128 to 128. 
    (This field is only valid when ue_in_idle is TRUE.)  */
}nas_lte_ngbr_wcdma_cell_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t uarfcn;
  /**<   WCDMA layer frequency. Range: 0 to 16383.  */

  uint8_t cell_resel_priority;
  /**<   Cell reselection priority. Range: 0 to 7. (This field is only 
    valid when ue_in_idle is TRUE.)  */

  uint16_t thresh_Xhigh;
  /**<   Reselection low threshold. Range: 0 to 31. (This field is only 
    valid when ue_in_idle is TRUE.)  */

  uint16_t thresh_Xlow;
  /**<   Reselection high threshold. Range: 0 to 31. (This field is only 
    valid when ue_in_idle is TRUE.)  */

  uint32_t cells_len;  /**< Must be set to # of elements in cells */
  nas_lte_ngbr_wcdma_cell_type_v01 cells[NAS_MAX_LTE_NGBR_WCDMA_NUM_CELLS_V01];
}nas_lte_ngbr_wcdma_freq_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t ue_in_idle;
  /**<   TRUE if the UE is in Idle mode; otherwise FALSE.  */

  uint32_t freqs_len;  /**< Must be set to # of elements in freqs */
  nas_lte_ngbr_wcdma_freq_type_v01 freqs[NAS_MAX_LTE_NGBR_WCDMA_NUM_FREQS_V01];
}nas_lte_ngbr_wcdma_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Retrieves cell location-related information. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */

  /* Optional */
  /*  GERAN Info */
  uint8_t geran_info_valid;  /**< Must be set to true if geran_info is being passed */
  nas_geran_cell_info_type_v01 geran_info;

  /* Optional */
  /*  UMTS Info */
  uint8_t umts_info_valid;  /**< Must be set to true if umts_info is being passed */
  nas_umts_cell_info_type_v01 umts_info;

  /* Optional */
  /*  CDMA Info */
  uint8_t cdma_info_valid;  /**< Must be set to true if cdma_info is being passed */
  nas_cdma_cell_info_type_v01 cdma_info;

  /* Optional */
  /*  LTE Info - Intrafrequency */
  uint8_t lte_intra_valid;  /**< Must be set to true if lte_intra is being passed */
  nas_lte_intra_freq_type_v01 lte_intra;

  /* Optional */
  /*  LTE Info - Interfrequency */
  uint8_t lte_inter_valid;  /**< Must be set to true if lte_inter is being passed */
  nas_lte_inter_freq_type_v01 lte_inter;

  /* Optional */
  /*  LTE Info - Neighboring GSM */
  uint8_t lte_gsm_valid;  /**< Must be set to true if lte_gsm is being passed */
  nas_lte_ngbr_gsm_type_v01 lte_gsm;

  /* Optional */
  /*  LTE Info - Neighboring WCDMA */
  uint8_t lte_wcdma_valid;  /**< Must be set to true if lte_wcdma is being passed */
  nas_lte_ngbr_wcdma_type_v01 lte_wcdma;

  /* Optional */
  /*  UMTS Cell ID */
  uint8_t umts_cell_id_valid;  /**< Must be set to true if umts_cell_id is being passed */
  uint32_t umts_cell_id;
  /**<   Cell ID (0xFFFFFFFF indicates cell ID information is not present).
   */
}nas_get_cell_location_info_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Queries the operator name for a specified network. */
typedef struct {

  /* Mandatory */
  /*  PLMN  */
  nas_plmn_id_type_v01 plmn;
}nas_get_plmn_name_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  SPN coding scheme */
  nas_coding_scheme_enum_v01 spn_enc;
  /**<  
        Coding scheme for the service provider name. Values: \n
        -0x00 -- NAS_CODING_SCHEME_CELL_ BROADCAST_GSM -- SMS default 7-bit coded 
                 alphabet as defined in [S8] with bit 8 set to 0 \n
        -0x01 -- NAS_CODING_SCHEME_UCS2 -- UCS2 (16 bit, little-endian) [S8] \n
        Note: This value is ignored if spn_len is zero.
   */

  /*  SPN */
  uint32_t spn_len;  /**< Must be set to # of elements in spn */
  char spn[NAS_SPN_LEN_MAX_V01];
  /**<  
     Service provider name string.
   */

  /*  PLMN short name encoding scheme */
  nas_coding_scheme_enum_v01 plmn_short_name_enc;
  /**<  
        Coding scheme for plmn_short_name. Values: \n
        -0x00 -- NAS_CODING_SCHEME_CELL_ BROADCAST_GSM -- SMS default 7-bit coded 
                 alphabet as defined in [S8] with bit 8 set to 0 \n
        -0x01 -- NAS_CODING_SCHEME_UCS2 -- UCS2 (16 bit, little-endian) [S8] \n
        Note: This value is ignored if plmn_short_name_len is zero.
   */

  /*  PLMN short name country initial include status */
  nas_country_initials_add_enum_v01 plmn_short_name_ci;
  /**<  
        Indicates whether the country initials are to be added to the 
        plmn_short_name. Values: \n
        -0x00 -- Do not add the letters for the country's initials to the name \n
        -0x01 -- Add the country's initials and a text string to the name \n
        -0xFF -- Not specified \n
        Note: This value is ignored if plmn_short_name_len is zero.
   */

  /*  PLMN short spare bits */
  nas_spare_bits_enum_v01 plmn_short_spare_bits;
  /**<   Values: \n
       -0x01 -- Bit 8 is spare and set to 0 in octet n                       \n
       -0x02 -- Bits 7 and 8 are spare and set to 0 in octet n               \n
       -0x03 -- Bits 6 to 8 (inclusive) are spare and set to 0 in octet n    \n
       -0x04 -- Bits 5 to 8 (inclusive) are spare and set to 0 in octet n    \n
       -0x05 -- Bits 4 to 8 (inclusive) are spare and set to 0 in octet n    \n
       -0x06 -- Bits 3 to 8 (inclusive) are spare and set to 0 in octet n    \n
       -0x07 -- Bits 2 to 8 (inclusive) are spare and set to 0 in octet n    \n
       -0x00 -- Carries no information about the number of spare bits in octet n    \n
       Note: This value is ignored if plmn_short_name_len is zero.
   */

  /*  PLMN short name */
  uint32_t plmn_short_name_len;  /**< Must be set to # of elements in plmn_short_name */
  char plmn_short_name[NAS_PLMN_NAME_MAX_V01];
  /**<   PLMN short name. If no short name is available for the specified PLMN ID, 
       MCC and MNC values are included in ASCII format with the MCC followed
       by the MNC within double quotes. For example, for an MCC of 123 and an 
       MNC of 678, the ASCII string "123678" is returned when the short name 
       is not available.  
   */

  /*  PLMN long name encoding scheme */
  nas_coding_scheme_enum_v01 plmn_long_name_enc;
  /**<  
        Coding scheme for plmn_long_name. Values: \n
        -0x00 -- NAS_CODING_SCHEME_CELL_ BROADCAST_GSM -- SMS default 7-bit coded 
                 alphabet as defined in [S8] with bit 8 set to 0 \n
        -0x01 -- NAS_CODING_SCHEME_UCS2 -- UCS2 (16 bit, little-endian) [S8] \n
        Note: This value is ignored if plmn_long_name_len is zero.
   */

  /*  PLMN long name country initial include status */
  nas_country_initials_add_enum_v01 plmn_long_name_ci;
  /**<  
        Indicates whether the country initials are to be added to the 
        plmn_long_name. Values: \n
        -0x00 -- Do not add the letters for the country's initials to the name \n
        -0x01 -- Add the country's initials and a text string to the name \n
        -0xFF -- Not specified \n
        Note: This value is ignored if plmn_long_name_len is zero.
   */

  /*  PLMN long spare bits  */
  nas_spare_bits_enum_v01 plmn_long_spare_bits;
  /**<   Values: \n
       -0x01 -- Bit 8 is spare and set to 0 in octet n                       \n
       -0x02 -- Bits 7 and 8 are spare and set to 0 in octet n               \n
       -0x03 -- Bits 6 to 8 (inclusive) are spare and set to 0 in octet n    \n
       -0x04 -- Bits 5 to 8 (inclusive) are spare and set to 0 in octet n    \n
       -0x05 -- Bits 4 to 8 (inclusive) are spare and set to 0 in octet n    \n
       -0x06 -- Bits 3 to 8 (inclusive) are spare and set to 0 in octet n    \n
       -0x07 -- Bits 2 to 8 (inclusive) are spare and set to 0 in octet n    \n
       -0x00 -- Carries no information about the number of spare bits in octet n    \n
       Note: This value is ignored if plmn_long_name_len is zero.
   */

  uint32_t plmn_long_name_len;  /**< Must be set to # of elements in plmn_long_name */
  char plmn_long_name[NAS_PLMN_NAME_MAX_V01];
  /**<   PLMN long name. If no long name is available for the specified PLMN ID, 
       MCC and MNC values are included in ASCII format with the MCC followed
       by the MNC within double quotes. For example, for an MCC of 123 and an 
       MNC of 678, the ASCII string "123678" is returned when the long name 
       is not available.  
   */
}nas_3gpp_eons_plmn_name_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Queries the operator name for a specified network. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */

  /* Optional */
  /*  3GPP EONS PLMN Name  */
  uint8_t eons_plmn_name_3gpp_valid;  /**< Must be set to true if eons_plmn_name_3gpp is being passed */
  nas_3gpp_eons_plmn_name_type_v01 eons_plmn_name_3gpp;
}nas_get_plmn_name_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_SUBS_TYPE_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_PRIMARY_SUBSCRIPTION_V01 = 0x00, 
  NAS_SECONDARY_SUBSCRIPTION_V01 = 0x01, 
  NAS_SUBS_TYPE_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_subs_type_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Binds the current control point to a specific subscription.  */
typedef struct {

  /* Mandatory */
  /*  Subscription Type */
  nas_subs_type_enum_v01 subs_type;
  /**<   Values: \n
       -0x00 -- Primary subscription \n
       -0x01 -- Secondary subscription

   */
}nas_bind_subscription_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Binds the current control point to a specific subscription.  */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_bind_subscription_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_STANDBY_PREF_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_SINGLE_STANDBY_V01 = 0x01, 
  NAS_DUAL_STANDBY_WITH_TUNE_AWAY_V01 = 0x02, 
  NAS_DUAL_STANDBY_WITHOUT_TUNE_AWAY_V01 = 0x04, 
  NAS_AUTOMATIC_WITH_TUNE_AWAY_V01 = 0x05, 
  NAS_AUTOMATIC_WITHOUT_TUNE_AWAY_V01 = 0x06, 
  NAS_STANDBY_PREF_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_standby_pref_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Configures dual standby preference. */
typedef struct {

  /* Optional */
  /*  Standby Preference */
  uint8_t standby_pref_valid;  /**< Must be set to true if standby_pref is being passed */
  nas_standby_pref_enum_v01 standby_pref;
  /**<  
        Values: \n
        -0x05 -- Automatic mode with tune away where applicable \n
        -0x06 -- Automatic mode without tune away \n
        All other values are reserved.
   */

  /* Optional */
  /*  Priority Subs */
  uint8_t priority_subs_valid;  /**< Must be set to true if priority_subs is being passed */
  nas_subs_type_enum_v01 priority_subs;
  /**<  
        Subscription to give priority when listening to the paging channel during
        dual standby. Values: \n
        -0x00 -- Primary subscription \n
        -0x01 -- Secondary subscription \n
        All other values are reserved.

   */

  /* Optional */
  /*  Default Data Subs */
  uint8_t default_data_subs_valid;  /**< Must be set to true if default_data_subs is being passed */
  nas_subs_type_enum_v01 default_data_subs;
  /**<  
        Default data subscription. Values: \n
        -0x00 -- Primary subscription \n
        -0x01 -- Secondary subscription \n
        All other values are reserved.
   */
}nas_set_dual_standby_pref_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Configures dual standby preference. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_set_dual_standby_pref_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Standby preference */
  nas_standby_pref_enum_v01 standby_pref;
  /**<   Values: \n
       -0x01 -- Single standby \n
       -0x02 -- Dual standby with tune away \n
       -0x04 -- Dual standby without tune away \n
       -0x05 -- Automatic mode with tune away where applicable \n
       -0x06 -- Automatic mode without tune away \n
       All other values are reserved.
   */

  /*  Priority subs */
  nas_subs_type_enum_v01 priority_subs;
  /**<  
        Subscription to give priority when listening to the paging channel during
        dual standby. Values: \n
        -0x00 -- Primary subscription \n
        -0x01 -- Secondary subscription \n
        All other values are reserved.

   */

  /*  Active subs */
  nas_subs_type_enum_v01 active_subs;
  /**<  
        Subscription to enable when "standby_pref is 0x01 -- Single standby". 
        Values: \n
        -0x00 -- Primary subscription \n
        -0x01 -- Secondary subscription \n
        All other values are reserved.

   */

  /*  Default data subs */
  nas_subs_type_enum_v01 default_data_subs;
  /**<  
        Default data subscription. Values: \n
        -0x00 -- Primary subscription \n
        -0x01 -- Secondary subscription \n
        All other values are reserved.

   */
}nas_standby_pref_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Indication Message; Informs the control point of any changes in dual standby
             subscription. */
typedef struct {

  /* Optional */
  /*  Standby Preference */
  uint8_t standby_pref_valid;  /**< Must be set to true if standby_pref is being passed */
  nas_standby_pref_type_v01 standby_pref;
}nas_dual_standby_pref_ind_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_IS_PRIORITY_SUBS_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_PRIORITY_SUBSCRIPTION_FALSE_V01 = 0x00, 
  NAS_PRIORITY_SUBSCRIPTION_TRUE_V01 = 0x01, 
  NAS_IS_PRIORITY_SUBS_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_is_priority_subs_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_ACTIVE_SUBS_INFO_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_SUBSCRIPTION_NOT_ACTIVE_V01 = 0x00, 
  NAS_SUBSCRIPTION_ACTIVE_V01 = 0x01, 
  NAS_ACTIVE_SUBS_INFO_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_active_subs_info_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Indication Message; Indicates any change in the subscription information. */
typedef struct {

  /* Optional */
  /*  Priority Subscription Info */
  uint8_t is_priority_subs_valid;  /**< Must be set to true if is_priority_subs is being passed */
  nas_is_priority_subs_enum_v01 is_priority_subs;
  /**<  
      Information on whether the subscription is a priority subscription 
      in cases of dual standby. Values: \n
      -0x00 -- Not a priority subscription \n
      -0x01 -- Priority subscription
  */

  /* Optional */
  /*  Active Subscription Info */
  uint8_t is_active_valid;  /**< Must be set to true if is_active is being passed */
  nas_active_subs_info_enum_v01 is_active;
  /**<  
      Information on whether the subscription is active. Values: \n
      -0x00 -- Not active \n
      -0x01 -- Active
  */

  /* Optional */
  /*  Default Data Subscription Info */
  uint8_t is_default_data_subs_valid;  /**< Must be set to true if is_default_data_subs is being passed */
  uint8_t is_default_data_subs;
  /**<  
      Information on whether the subscription is the default data
      subscription in cases of dual standby. Values: \n
      -0x00 -- Not a default data subscription \n
      -0x01 -- Default data subscription
  */
}nas_subscription_info_ind_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_mode_pref_req_msg is empty
 * typedef struct {
 * }nas_get_mode_pref_req_msg_v01;
 */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Retrieves the mode preference. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */

  /* Optional */
  /*  Mode Preference for idx0 */
  uint8_t idx0_mode_pref_valid;  /**< Must be set to true if idx0_mode_pref is being passed */
  mode_pref_mask_type_v01 idx0_mode_pref;
  /**<   Bitmask representing the radio technology mode preference set in
      NV (idx0). Values: \n
       - Bit 0 (0x01) -- QMI_NAS_RAT_MODE_PREF_ CDMA2000_1X   -- cdma2000 1X             \n
       - Bit 1 (0x02) -- QMI_NAS_RAT_MODE_PREF_ CDMA2000_HRPD -- cdma2000 HRPD (1xEV-DO) \n
       - Bit 2 (0x04) -- QMI_NAS_RAT_MODE_PREF_GSM            -- GSM \n
       - Bit 3 (0x08) -- QMI_NAS_RAT_MODE_PREF_UMTS           -- UMTS \n
       - Bit 4 (0x10) -- QMI_NAS_RAT_MODE_PREF_LTE            -- LTE \n
       - Bit 5 (0x20) -- QMI_NAS_RAT_MODE_PREF_ TDSCDMA       -- TD-SCDMA
   */

  /* Optional */
  /*  Mode Preference for idx1 */
  uint8_t idx1_mode_pref_valid;  /**< Must be set to true if idx1_mode_pref is being passed */
  mode_pref_mask_type_v01 idx1_mode_pref;
  /**<   Bitmask representing the radio technology mode preference set in 
      NV (idx1). Values: \n
       - Bit 0 (0x01) -- QMI_NAS_RAT_MODE_PREF_ CDMA2000_1X   -- cdma2000 1X             \n
       - Bit 1 (0x02) -- QMI_NAS_RAT_MODE_PREF_ CDMA2000_HRPD -- cdma2000 HRPD (1xEV-DO) \n
       - Bit 2 (0x04) -- QMI_NAS_RAT_MODE_PREF_GSM            -- GSM \n
       - Bit 3 (0x08) -- QMI_NAS_RAT_MODE_PREF_UMTS           -- UMTS \n
       - Bit 4 (0x10) -- QMI_NAS_RAT_MODE_PREF_LTE            -- LTE \n
       - Bit 5 (0x20) -- QMI_NAS_RAT_MODE_PREF_ TDSCDMA       -- TD-SCDMA
  */
}nas_get_mode_pref_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_ACTIVE_TECHNOLOGY_DURATION_ENUM_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_ACTIVE_TECHNOLOGY_DURATION_PERMANENT_V01 = 0x00, 
  NAS_ACTIVE_TECHNOLOGY_DURATION_PWR_CYCLE_V01 = 0x01, 
  NAS_ACTIVE_TECHNOLOGY_DURATION_1C_ENC_PC_V01 = 0x02, 
  NAS_ACTIVE_TECHNOLOGY_DURATION_1C_TUENC_ST_PC_V01 = 0x03, 
  NAS_ACTIVE_TECHNOLOGY_DURATION_1C_TUENC_INTERNAL1_V01 = 0x04, 
  NAS_ACTIVE_TECHNOLOGY_DURATION_1C_TUENC_INTERNAL2_V01 = 0x05, 
  NAS_ACTIVE_TECHNOLOGY_DURATION_1C_TUENC_INTERNAL3_V01 = 0x06, 
  NAS_ACTIVE_TECHNOLOGY_DURATION_ENUM_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_active_technology_duration_enum_type_v01;
/**
    @}
  */

typedef uint16_t nas_persistent_technology_pref_mask_type_v01;
#define NAS_PERSISTENT_TECH_PREF_3GPP2_V01 ((nas_persistent_technology_pref_mask_type_v01)0x01)
#define NAS_PERSISTENT_TECH_PREF_3GPP_V01 ((nas_persistent_technology_pref_mask_type_v01)0x02)
#define NAS_PERSISTENT_TECH_PREF_ANALOG_V01 ((nas_persistent_technology_pref_mask_type_v01)0x04)
#define NAS_PERSISTENT_TECH_PREF_DIGITAL_V01 ((nas_persistent_technology_pref_mask_type_v01)0x08)
#define NAS_PERSISTENT_TECH_PREF_HDR_V01 ((nas_persistent_technology_pref_mask_type_v01)0x10)
#define NAS_PERSISTENT_TECH_PREF_LTE_V01 ((nas_persistent_technology_pref_mask_type_v01)0x20)
/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Technology preference */
  nas_persistent_technology_pref_mask_type_v01 technology_pref;
  /**<  
        Bitmask representing the radio technology preference set. 
        No bits set indicates to the device to automatically
        determine the technology to use. Values: \n
        - Bit 0 -- Technology is 3GPP2 \n
        - Bit 1 -- Technology is 3GPP

        Any combination of the following may be returned: \n
        - Bit 2 -- Analog -- AMPS if 3GPP2, GSM if 3GPP \n
        - Bit 3 -- Digital -- CDMA if 3GPP2, WCDMA if 3GPP \n
        - Bit 4 -- HDR \n
        - Bit 5 -- LTE \n
        - Bits 6 to 15 -- Reserved

        Note: Bits 0 and 1 are exclusive; only one may be set at a time.
              All unlisted bits are reserved for future use and will be ignored.
   */

  /*  Duration */
  nas_active_technology_duration_enum_type_v01 duration;
  /**<  
      Preference duration. Values: \n
      -0x00 -- Permanent   -- Preference is used permanently \n
      -0x01 -- Power cycle -- Preference is used until the next device power cycle
   */
}nas_technology_pref_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Sets the technology preference. (Deprecated) */
typedef struct {

  /* Mandatory */
  /*  Technology Preference */
  nas_technology_pref_type_v01 technology_pref;
}nas_set_technology_preference_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Sets the technology preference. (Deprecated) */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_set_technology_preference_resp_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_technology_preference_req_type is empty
 * typedef struct {
 * }nas_get_technology_preference_req_type_v01;
 */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Technology preference */
  nas_persistent_technology_pref_mask_type_v01 technology_pref;
  /**<  
        Bitmask representing the radio technology preference set. 
        No bits set indicates to the device to automatically
        determine the technology to use. Values: \n
        - Bit 0 -- Technology is 3GPP2 \n
        - Bit 1 -- Technology is 3GPP

        Any combination of the following may be returned: \n
        - Bit 2 -- Analog -- AMPS if 3GPP2, GSM if 3GPP \n
        - Bit 3 -- Digital -- CDMA if 3GPP2, WCDMA if 3GPP \n
        - Bit 4 -- HDR \n
        - Bit 5 -- LTE \n
        - Bits 6 to 15 -- Reserved

        Note: Bits 0 and 1 are exclusive; only one may be set at a time.
              All unlisted bits are reserved for future use and will be ignored.
   */

  /*  Duration */
  nas_active_technology_duration_enum_type_v01 duration;
  /**<  
      Duration of the active preference. Values: \n
      -0x00 -- Permanent -- Preference is used permanently \n
      -0x01 -- Power cycle -- Preference is used until the next device power cycle \n
      -0x02 -- 1 call -- Until the end of the next call or a power cycle \n
      -0x03 -- 1 call or time -- Until the end of the next call, a specified time, 
                                 or a power cycle \n
      -0x04-0x06 -- Internal 1 call -- Until the end of the next call 

   */
}nas_active_technology_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Retrieves the technology preference. (Deprecated) */
typedef struct {

  /* Mandatory */
  /*  Active Technology Preference */
  nas_active_technology_type_v01 active_technology_pref;

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */

  /* Optional */
  /*  Persistent Technology Preference */
  uint8_t persistent_technology_pref_valid;  /**< Must be set to true if persistent_technology_pref is being passed */
  nas_persistent_technology_pref_mask_type_v01 persistent_technology_pref;
  /**<    Bitmask representing the radio technology preference set. 
        No bits set indicates to the device to automatically
        determine the technology to use. Values: \n
        - Bit 0 -- Technology is 3GPP2 \n
        - Bit 1 -- Technology is 3GPP

        Any combination of the following may be returned: \n
        - Bit 2 -- Analog -- AMPS if 3GPP2, GSM if 3GPP \n
        - Bit 3 -- Digital -- CDMA if 3GPP2, WCDMA if 3GPP \n
        - Bit 4 -- HDR \n
        - Bit 5 -- LTE \n
        - Bits 6 to 15 -- Reserved

        Note: Bits 0 and 1 are exclusive; only one may be set at a time.
              All unlisted bits are reserved for future use and will be ignored.       
     */
}nas_get_technology_preference_resp_type_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_network_system_preference_req is empty
 * typedef struct {
 * }nas_get_network_system_preference_req_v01;
 */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NETWORK_SYS_PREF_ENUM_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_NETWORK_SYSTEM_PREFERENCE_AUTOMATIC_V01 = 0x00, 
  NAS_NETWORK_SYSTEM_PREFERENCE_AUTO_A_V01 = 0x01, 
  NAS_NETWORK_SYSTEM_PREFERENCE_AUTO_B_V01 = 0x02, 
  NETWORK_SYS_PREF_ENUM_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}network_sys_pref_enum_type_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Retrieves the network system preference. */
typedef struct {

  /* Mandatory */
  /*  System Preference */
  network_sys_pref_enum_type_v01 system_pref;
  /**<  
      Duration of the active preference. Values: \n
      -0x00 -- Automatic \n
      -0x01 -- Auto A \n
      -0x02 -- Auto B
   */

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_get_network_system_preference_resp_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Year */
  uint16_t year;
  /**<   Year.
   */

  /*  Month */
  uint8_t month;
  /**<   Month. 1 is January and 12 is December.
   */

  /*  Day */
  uint8_t day;
  /**<   Day. Range: 1 to 31.
   */

  /*  Hour */
  uint8_t hour;
  /**<   Hour. Range: 0 to 59.
   */

  /*  Minute */
  uint8_t minute;
  /**<   Minute. Range: 0 to 59.
   */

  /*  Second */
  uint8_t second;
  /**<   Second. Range: 0 to 59.
   */

  /*  Day of the week */
  uint8_t day_of_week;
  /**<   Day of the week. 0 is Monday and 6 is Sunday
   */
}nas_julian_time_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Indication Message; Indicates a time change reported by the network. */
typedef struct {

  /* Mandatory */
  /*  Universal Time */
  nas_julian_time_type_v01 universal_time;

  /* Optional */
  /*  Time Zone */
  uint8_t time_zone_valid;  /**< Must be set to true if time_zone is being passed */
  int8_t time_zone;
  /**<   Offset from Universal time, i.e., the difference between local time
       and Universal time, in increments of 15 min (signed value).
   */

  /* Optional */
  /*  Daylight Saving Adjustment */
  uint8_t daylt_sav_adj_valid;  /**< Must be set to true if daylt_sav_adj is being passed */
  uint8_t daylt_sav_adj;
  /**<   Daylight saving adjustment in hr. Possible values: 0, 1, and 2.
   */

  /* Optional */
  /*  Radio Interface */
  uint8_t radio_if_valid;  /**< Must be set to true if radio_if is being passed */
  nas_radio_if_enum_v01 radio_if;
  /**<  
    Radio interface from which to get the information. Values: \n
    - 0x01 -- NAS_RADIO_IF_CDMA_1X     -- cdma2000 1X \n
    - 0x02 -- NAS_RADIO_IF_CDMA_1XEVDO -- cdma2000 HRPD (1xEV-DO) \n
    - 0x04 -- NAS_RADIO_IF_GSM         -- GSM \n
    - 0x05 -- NAS_RADIO_IF_UMTS        -- UMTS \n
    - 0x08 -- NAS_RADIO_IF_LTE         -- LTE \n
    - 0x09 -- NAS_RADIO_IF_TDSCDMA     -- TD-SCDMA
    */
}nas_network_time_ind_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_sys_info_req_msg is empty
 * typedef struct {
 * }nas_get_sys_info_req_msg_v01;
 */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_CUR_IDLE_DIGITAL_MODE_ENUM_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_SYS_MODE_NO_SRV_V01 = 0x00, 
  NAS_SYS_MODE_AMPS_V01 = 0x01, 
  NAS_SYS_MODE_CDMA_V01 = 0x02, 
  NAS_SYS_MODE_GSM_V01 = 0x03, 
  NAS_SYS_MODE_HDR_V01 = 0x04, 
  NAS_SYS_MODE_WCDMA_V01 = 0x05, 
  NAS_SYS_MODE_GPS_V01 = 0x06, 
  NAS_SYS_MODE_GW_V01 = 0x07, 
  NAS_SYS_MODE_WLAN_V01 = 0x08, 
  NAS_SYS_MODE_LTE_V01 = 0x09, 
  NAS_SYS_MODE_GWL_V01 = 0x0A, 
  NAS_CUR_IDLE_DIGITAL_MODE_ENUM_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_cur_idle_digital_mode_enum_type_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_SERVICE_STATUS_ENUM_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_SYS_SRV_STATUS_NO_SRV_V01 = 0, 
  NAS_SYS_SRV_STATUS_LIMITED_V01 = 1, 
  NAS_SYS_SRV_STATUS_SRV_V01 = 2, 
  NAS_SYS_SRV_STATUS_LIMITED_REGIONAL_V01 = 3, 
  NAS_SYS_SRV_STATUS_PWR_SAVE_V01 = 4, 
  NAS_SERVICE_STATUS_ENUM_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_service_status_enum_type_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_TRUE_SERVICE_STATUS_ENUM_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  SYS_SRV_STATUS_NO_SRV_V01 = 0, 
  SYS_SRV_STATUS_LIMITED_V01 = 1, 
  SYS_SRV_STATUS_SRV_V01 = 2, 
  SYS_SRV_STATUS_LIMITED_REGIONAL_V01 = 3, 
  SYS_SRV_STATUS_PWR_SAVE_V01 = 4, 
  NAS_TRUE_SERVICE_STATUS_ENUM_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_true_service_status_enum_type_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_SERVICE_DOMAIN_ENUM_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  SYS_SRV_DOMAIN_NO_SRV_V01 = 0, 
  SYS_SRV_DOMAIN_CS_ONLY_V01 = 1, 
  SYS_SRV_DOMAIN_PS_ONLY_V01 = 2, 
  SYS_SRV_DOMAIN_CS_PS_V01 = 3, 
  SYS_SRV_DOMAIN_CAMPED_V01 = 4, 
  NAS_SERVICE_DOMAIN_ENUM_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_service_domain_enum_type_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_HDR_PERSONALITY_ENUM_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_SYS_PERSONALITY_NONE_V01 = 0x00, 
  NAS_SYS_PERSONALITY_HRPD_V01 = 0x02, 
  NAS_SYS_PERSONALITY_EHRPD_V01 = 0x03, 
  NAS_HDR_PERSONALITY_ENUM_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_hdr_personality_enum_type_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_HDR_ACTIVE_PROT_ENUM_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_SYS_ACTIVE_PROT_NONE_V01 = 0x00, 
  NAS_SYS_ACTIVE_PROT_HDR_REL0_V01 = 0x02, 
  NAS_SYS_ACTIVE_PROT_HDR_RELA_V01 = 0x03, 
  NAS_SYS_ACTIVE_PROT_HDR_RELB_V01 = 0x04, 
  NAS_HDR_ACTIVE_PROT_ENUM_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_hdr_active_prot_enum_type_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_ROAM_STATUS_ENUM_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_SYS_ROAM_STATUS_OFF_V01 = 0x00, 
  NAS_SYS_ROAM_STATUS_ON_V01 = 0x01, 
  NAS_SYS_ROAM_STATUS_BLINK_V01 = 0x02, 
  NAS_SYS_ROAM_STATUS_OUT_OF_NEIGHBORHOOD_V01 = 0x03, 
  NAS_SYS_ROAM_STATUS_OUT_OF_BLDG_V01 = 0x04, 
  NAS_SYS_ROAM_STATUS_PREF_SYS_V01 = 0x05, 
  NAS_SYS_ROAM_STATUS_AVAIL_SYS_V01 = 0x06, 
  NAS_SYS_ROAM_STATUS_ALLIANCE_PARTNER_V01 = 0x07, 
  NAS_SYS_ROAM_STATUS_PREMIUM_PARTNER_V01 = 0x08, 
  NAS_SYS_ROAM_STATUS_FULL_SVC_V01 = 0x09, 
  NAS_SYS_ROAM_STATUS_PARTIAL_SVC_V01 = 0x0A, 
  NAS_SYS_ROAM_STATUS_BANNER_ON_V01 = 0x0B, 
  NAS_SYS_ROAM_STATUS_BANNER_OFF_V01 = 0x0C, 
  NAS_ROAM_STATUS_ENUM_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_roam_status_enum_type_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_EUTRA_CELL_STATUS_ENUM_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_EUTRA_CELL_PRESENT_V01 = 0x00, 
  NAS_EUTRA_CELL_NOT_PRESENT_V01 = 0x01, 
  NAS_EUTRA_CELL_PRESENCE_UNKNOWN_V01 = 0x02, 
  NAS_EUTRA_CELL_DETECTION_UNSUPPORTED_V01 = 0x03, 
  NAS_EUTRA_CELL_STATUS_ENUM_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_eutra_cell_status_enum_type_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Service Domain */
  nas_service_domain_enum_type_v01 reject_srv_domain;
  /**<  
      Type of service domain in which the registration is rejected. Values: \n
      - 0x00 -- SYS_SRV_DOMAIN_NO_SRV  -- No service \n
      - 0x01 -- SYS_SRV_DOMAIN_CS_ONLY -- Circuit-switched only \n
      - 0x02 -- SYS_SRV_DOMAIN_PS_ONLY -- Packet-switched only \n
      - 0x03 -- SYS_SRV_DOMAIN_CS_PS   -- Circuit-switched and packet-switched \n
      - 0x04 -- SYS_SRV_DOMAIN_CAMPED  -- Camped
       */

  /*  Registration Rejection Cause */
  uint8_t rej_cause;
  /**<  
      Reject cause values sent are specified in 
      [S5, Sections 10.5.3.6 and 10.5.5.14] and [S16, Section 9.9.3.9].
   */
}nas_reg_reject_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Service Status of the System */
  nas_service_status_enum_type_v01 srv_status;
  /**<   
       Service status of the system. Values: \n
       - 0x00 -- SYS_SRV_STATUS_NO_SRV  -- No service \n
       - 0x01 -- SYS_SRV_STATUS_LIMITED -- Limited service \n
       - 0x02 -- SYS_SRV_STATUS_SRV     -- Service \n
       - 0x03 -- SYS_SRV_STATUS_LIMITED_REGIONAL -- Limited regional service \n
       - 0x04 -- SYS_SRV_STATUS_PWR_SAVE         -- Power save
   */

  /*  Is this RAT the preferred data path */
  uint8_t is_pref_data_path;
  /**<  
       Whether the RAT is the preferred data path: \n
       - 0x00 -- Not preferred \n
       - 0x01 -- Preferred
   */
}nas_3gpp2_srv_status_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Service Status of the System */
  nas_service_status_enum_type_v01 srv_status;
  /**<   
       Service status of the system. Values: \n
       - 0x00 -- SYS_SRV_STATUS_NO_SRV  -- No service \n
       - 0x01 -- SYS_SRV_STATUS_LIMITED -- Limited service \n
       - 0x02 -- SYS_SRV_STATUS_SRV     -- Service \n
       - 0x03 -- SYS_SRV_STATUS_LIMITED_REGIONAL -- Limited regional service \n
       - 0x04 -- SYS_SRV_STATUS_PWR_SAVE         -- Power save
   */

  /*  True Service Status of the System (not applicable to CDMA/HDR) */
  nas_true_service_status_enum_type_v01 true_srv_status;
  /**<  
      True service status of the system (not applicable to CDMA/HDR). Values: \n
      - 0x00 -- SYS_SRV_STATUS_NO_SRV  -- No service \n
      - 0x01 -- SYS_SRV_STATUS_LIMITED -- Limited service \n
      - 0x02 -- SYS_SRV_STATUS_SRV     -- Service \n
      - 0x03 -- SYS_SRV_STATUS_LIMITED_REGIONAL -- Limited regional service \n
      - 0x04 -- SYS_SRV_STATUS_PWR_SAVE         -- Power save
   */

  /*  Is this RAT the Preferred Data Path */
  uint8_t is_pref_data_path;
  /**<  
       Whether the RAT is the preferred data path: \n
       - 0x00 -- Not preferred \n
       - 0x01 -- Preferred
     */
}nas_3gpp_srv_status_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_CELL_BROADCAST_CAP_ENUM_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_CELL_BROADCAST_CAP_UNKNOWN_V01 = 0x00, /**<  CB capability information not known.  */
  NAS_CELL_BROADCAST_CAP_OFF_V01 = 0x01, /**<  CB capability OFF    
 CB capability ON     */
  NAS_CELL_BROADCAST_CAP_ON_V01 = 0x02, 
  NAS_CELL_BROADCAST_CAP_ENUM_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_cell_broadcast_cap_enum_type_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  MCC */
  char mcc[NAS_MCC_MNC_MAX_V01];
  /**<  
    MCC digits in ASCII characters.
   */

  /*  MNC */
  char mnc[NAS_MCC_MNC_MAX_V01];
  /**<  
      MNC digits in ASCII characters. For this field: \n
      - Unused byte is set to 0xFF   \n
      - In the case of two-digit MNC values, the third (unused) digit 
        is set to 0xFF. For example, 15 (a two-digit MNC) is reported 
        using the byte stream 0x31 0x35 0xFF.
   */
}nas_common_network_id_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Is the Service Domain Valid */
  uint8_t srv_domain_valid;
  /**<   
      Indicates whether the service domain is valid; boolean value.
   */

  /*  Service Domain */
  nas_service_domain_enum_type_v01 srv_domain;
  /**<  
      Service domain registered on the system. Values:  \n
      - 0x00 -- SYS_SRV_DOMAIN_NO_SRV  -- No service \n
      - 0x01 -- SYS_SRV_DOMAIN_CS_ONLY -- Circuit-switched only \n
      - 0x02 -- SYS_SRV_DOMAIN_PS_ONLY -- Packet-switched only \n
      - 0x03 -- SYS_SRV_DOMAIN_CS_PS   -- Circuit-switched and packet-switched \n
      - 0x04 -- SYS_SRV_DOMAIN_CAMPED  -- Camped
       */

  /*  Is the Service Capability Valid */
  uint8_t srv_capability_valid;
  /**<   
      Indicates whether the service capability is valid; boolean value. 
   */

  /*  Service Capability */
  nas_service_domain_enum_type_v01 srv_capability;
  /**<  
      Current system's service capability. Values: \n
      - 0x00 -- SYS_SRV_DOMAIN_NO_SRV  -- No service \n
      - 0x01 -- SYS_SRV_DOMAIN_CS_ONLY -- Circuit-switched only \n
      - 0x02 -- SYS_SRV_DOMAIN_PS_ONLY -- Packet-switched only \n
      - 0x03 -- SYS_SRV_DOMAIN_CS_PS   -- Circuit-switched and packet-switched \n
      - 0x04 -- SYS_SRV_DOMAIN_CAMPED  -- Camped
         */

  /*  Is the Roaming Status Valid */
  uint8_t roam_status_valid;
  /**<   
      Indicates whether the roaming status is valid; boolean value. 
   */

  /*  Current Roaming Status */
  nas_roam_status_enum_type_v01 roam_status;
  /**<  
      Current roaming status. Values: \n
      - 0x00 -- SYS_ROAM_STATUS_OFF   -- Off \n
      - 0x01 -- SYS_ROAM_STATUS_ON    -- On  \n
      - 0x02 -- SYS_ROAM_STATUS_BLINK -- Blinking \n
      - 0x03 -- SYS_ROAM_STATUS_OUT_OF_ NEIGHBORHOOD -- Out of the neighborhood \n
      - 0x04 -- SYS_ROAM_STATUS_OUT_OF_BLDG          -- Out of the building \n
      - 0x05 -- SYS_ROAM_STATUS_PREF_SYS         -- Preferred system \n
      - 0x06 -- SYS_ROAM_STATUS_AVAIL_SYS        -- Available system \n
      - 0x07 -- SYS_ROAM_STATUS_ALLIANCE_PARTNER -- Alliance partner \n
      - 0x08 -- SYS_ROAM_STATUS_PREMIUM_PARTNER  -- Premium partner \n
      - 0x09 -- SYS_ROAM_STATUS_FULL_SVC         -- Full service \n
      - 0x0A -- SYS_ROAM_STATUS_PARTIAL_SVC      -- Partial service \n
      - 0x0B -- SYS_ROAM_STATUS_BANNER_ON        -- Banner is on \n
      - 0x0C -- SYS_ROAM_STATUS_BANNER_OFF       -- Banner is off \n
        Remainder of the values are per [S4].

        Values from 0x02 onward are only applicable for 3GPP2.
   */

  /*  Is the Forbidden System Valid */
  uint8_t is_sys_forbidden_valid;
  /**<   
      Indicates whether the forbidden system is valid; boolean value. 
   */

  /*  Indicates Whether the System is Forbidden */
  uint8_t is_sys_forbidden;
  /**<   
      Whether the system is forbidden: \n
      - 0x00 -- Not forbidden \n
      - 0x01 -- Forbidden
   */
}nas_common_sys_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Is the P_Rev in Use Valid */
  uint8_t p_rev_in_use_valid;
  /**<   
      Indicates whether the P_Rev in use is valid; boolean value, 
   */

  /*  P_Rev in Use */
  uint8_t p_rev_in_use;
  /**<  
     The lesser of the base station P_Rev and mobile P_Rev 
     (only applicable for CDMA),
   */

  /*  Is the Base Station P_Rev Valid */
  uint8_t bs_p_rev_valid;
  /**<   
      Indicates whether the base station P_Rev is valid; boolean value, 
   */

  /*  bs_p_rev  */
  uint8_t bs_p_rev;
  /**<  
    Base station P_Rev (only applicable for CDMA).
   */

  /*  Is the Supported CCS Valid */
  uint8_t ccs_supported_valid;
  /**<   
      Indicates whether the supported concurrent service is valid; boolean value. 
   */

  /*  Is CCS Supported  */
  uint8_t ccs_supported;
  /**<  
      Whether concurrent service is supported (only applicable for CDMA): \n
      - 0x00 -- Not supported \n
      - 0x01 -- Supported

   */

  /*  Is the CDMA System ID Valid */
  uint8_t cdma_sys_id_valid;
  /**<   
      Indicates whether the CDMA system ID is valid; boolean value. 
   */

  /*  CDMA System ID */
  nas_cdma_system_id_type_v01 cdma_sys_id;
  /**<  
     CDMA system ID; includes: \n
     - SID -- System ID \n
     - NID -- Network ID 
   */

  /*  Is the Base Station Information Valid */
  uint8_t bs_info_valid;
  /**<   
      Indicates whether the base station information is valid; boolean value. 
   */

  /*  Base Station Information */
  nas_cdma_base_station_info_type_v01 bs_info;
  /**<  
   Base station information; includes: \n
   - Base station ID \n
   - Base station latitude \n
   - Base station longitude
   */

  /*  Is the 3GPP2 Packet Zone Valid */
  uint8_t packet_zone_valid;
  /**<   
      Indicates whether the packet zone is valid; boolean value. 
   */

  /*  3GPP2 Packet Zone */
  uint16_t packet_zone;
  /**<  
    Packet zone (8-bit). 0xFFFF indicates no packet zone. 
    (Only applicable for CDMA.)
   */

  /*  Is the Network ID Valid */
  uint8_t network_id_valid;
  /**<   
      Indicates whether the network ID is valid; boolean value. 
   */

  /*  Network Name */
  nas_common_network_id_type_v01 network_id;
  /**<  
    Network ID consists of MCC and MNC.
   */
}nas_cdma_only_sys_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Is the HDR Personality Valid */
  uint8_t hdr_personality_valid;
  /**<   
      Indicates whether the HDR personality is valid; boolean value. 
   */

  /*  HDR Personality */
  nas_hdr_personality_enum_type_v01 hdr_personality;
  /**<  
      HDR personality information (only applicable for HDR). Values: \n
      - 0x00 -- SYS_PERSONALITY_NONE -- None \n
      - 0x02 -- SYS_PERSONALITY_HRPD -- HRPD \n
      - 0x03 -- SYS_PERSONALITY_EHRPD -- eHRPD
   */

  /*  Is the HDR Active Protocol Revision Information Valid */
  uint8_t hdr_active_prot_valid;
  /**<   
      Indicates whether the HDR active protocol revision information is valid;
      boolean value.
   */

  /*  HDR Active Protocol Revision Information  */
  nas_hdr_active_prot_enum_type_v01 hdr_active_prot;
  /**<  
      HDR active protocol revision information (only applicable for HDR). 
      Values: \n
      - 0x00 -- SYS_ACTIVE_PROT_NONE -- None           \n
      - 0x02 -- SYS_ACTIVE_PROT_HDR_REL0 -- HDR Rel 0  \n
      - 0x03 -- SYS_ACTIVE_PROT_HDR_RELA -- HDR Rel A  \n
      - 0x04 -- SYS_ACTIVE_PROT_HDR_RELB -- HDR Rel B
   */

  /*  Is the IS-856 System ID Valid */
  uint8_t is856_sys_id_valid;
  /**<   
      Indicates whether the IS-856 system ID is valid; boolean value. 
   */

  /*  IS 856 */
  uint8_t is856_sys_id[NAS_IS_856_MAX_LEN_V01];
  /**<  
      IS-856 system ID (only applicable for HDR).
     */
}nas_hdr_only_sys_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Is the EGPRS Support Valid */
  uint8_t egprs_supp_valid;
  /**<   
      Indicates whether EGPRS support is valid; boolean value. 
   */

  /*  EGPRS indication  */
  uint8_t egprs_supp;
  /**<  
      EGPRS support indication (only applicable for GSM). Values: \n
      - 0x00 -- SYS_EGPRS_SUPPORT_NOT_AVAIL -- Not available \n
      - 0x01 -- SYS_EGPRS_SUPPORT_AVAIL -- Available
   */

  /*  Is the DTM Support Valid */
  uint8_t dtm_supp_valid;
  /**<   
      Indicates whether Dual Transfer mode support is valid; boolean value. 
   */

  /*  DTM support status */
  uint8_t dtm_supp;
  /**<  
      Dual Transfer mode support indication (only applicable for GSM). Values: \n
      - 0x00 -- SYS_DTM_SUPPORT_NOT_AVAIL -- Not available  \n
      - 0x01 -- SYS_DTM_SUPPORT_AVAIL -- Available
   */
}nas_gsm_only_sys_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Is the HS Call Status Valid */
  uint8_t hs_call_status_valid;
  /**<   
      Indicates whether the high-speed call status is valid; boolean value. 
   */

  /*  HS Call Status */
  nas_hs_support_enum_type_v01 hs_call_status;
  /**<  
      Call status on high speed (only applicable for WCDMA). Values: \n
      - 0x00 -- SYS_HS_IND_HSDPA_HSUPA_UNSUPP_ CELL   -- HSDPA and HSUPA are unsupported \n
      - 0x01 -- SYS_HS_IND_HSDPA_SUPP_CELL            -- HSDPA is supported \n
      - 0x02 -- SYS_HS_IND_HSUPA_SUPP_CELL            -- HSUPA is supported \n
      - 0x03 -- SYS_HS_IND_HSDPA_HSUPA_SUPP_CELL      -- HSDPA and HSUPA are supported \n
      - 0x04 -- SYS_HS_IND_HSDPAPLUS_SUPP_CELL        -- HSDPA+ is supported \n
      - 0x05 -- SYS_HS_IND_HSDPAPLUS_HSUPA_SUPP_ CELL -- HSDPA+ and HSUPA are supported \n
      - 0x06 -- SYS_HS_IND_DC_HSDPAPLUS_SUPP_CELL     -- Dual-cell HSDPA+ is supported \n
      - 0x07 -- SYS_HS_IND_DC_HSDPAPLUS_HSUPA_ SUPP_CELL    -- Dual-cell HSDPA+ and HSUPA are supported \n 
      - 0x08 -- SYS_HS_IND_HSDPAPLUS_64QAM_HSUPA_ SUPP_CELL -- Dual-cell HSDPA+, 64 QAM, and HSUPA are supported \n
      - 0x09 -- SYS_HS_IND_HSDPAPLUS_64QAM_SUPP_CELL -- Dual-cell HSDPA+ and 64 QAM are supported
   */

  /*  Is the HS Service Indication Valid */
  uint8_t hs_ind_valid;
  /**<   
      Indicates whether the high-speed service indication is valid; boolean value. 
   */

  /*   HS service indication */
  nas_hs_support_enum_type_v01 hs_ind;
  /**<  
      High-speed service indication (only applicable for WCDMA). Values: \n
      - 0x00 -- SYS_HS_IND_HSDPA_HSUPA_UNSUPP_ CELL   -- HSDPA and HSUPA are unsupported \n
      - 0x01 -- SYS_HS_IND_HSDPA_SUPP_CELL            -- HSDPA is supported \n
      - 0x02 -- SYS_HS_IND_HSUPA_SUPP_CELL            -- HSUPA is supported \n
      - 0x03 -- SYS_HS_IND_HSDPA_HSUPA_SUPP_CELL      -- HSDPA and HSUPA are supported \n
      - 0x04 -- SYS_HS_IND_HSDPAPLUS_SUPP_CELL        -- HSDPA+ is supported \n
      - 0x05 -- SYS_HS_IND_HSDPAPLUS_HSUPA_SUPP_ CELL -- HSDPA+ and HSUPA are supported \n
      - 0x06 -- SYS_HS_IND_DC_HSDPAPLUS_SUPP_CELL     -- Dual-cell HSDPA+ is supported \n
      - 0x07 -- SYS_HS_IND_DC_HSDPAPLUS_HSUPA_ SUPP_CELL    -- Dual-cell HSDPA+ and HSUPA are supported \n 
      - 0x08 -- SYS_HS_IND_HSDPAPLUS_64QAM_HSUPA_ SUPP_CELL -- Dual-cell HSDPA+, 64 QAM, and HSUPA are supported \n
      - 0x09 -- SYS_HS_IND_HSDPAPLUS_64QAM_SUPP_CELL -- Dual-cell HSDPA+ and 64 QAM are supported
   */

  /*  Is the PSC Valid */
  uint8_t psc_valid;
  /**<   
      Indicates whether the primary scrambling code is valid; boolean value. 
   */

  /*  Primary Scrambling Code (PSC) */
  uint16_t psc;
  /**<  
    Primary scrambling code.
     */
}nas_wcdma_only_sys_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Is the TAC Valid */
  uint8_t tac_valid;
  /**<   
      Indicates whether the tracking area code is valid; boolean value. 
   */

  /*  Tracking Area Code */
  uint16_t tac;
  /**<  
     Tracking area code (only applicable for LTE).
     */
}nas_lte_only_sys_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Is the System PRL Match Valid */
  uint8_t is_sys_prl_match_valid;
  /**<   
      Indicates whether the system PRL match is valid; boolean value. 
   */

  /*  Indicates if the system is in PRL  */
  uint8_t is_sys_prl_match;
  /**<  
    Indicates whether the system is in a PRL (only applies to CDMA/HDR). 
    Values: \n
    - 0x00 -- System is not in a PRL \n
    - 0x01 -- System is in a PRL

    If the system is not in a PRL, roam_status carries the value from the 
    default roaming indicator in the PRL. \n
    If the system is in a PRL, roam_status is set to the value based on the 
    standard specification.
   */
}nas_cdma_hdr_only_sys_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Is the LAC Valid */
  uint8_t lac_valid;
  /**<   
      Indicates whether the location area code is valid; boolean value. 
   */

  /*  Location Area Code  */
  uint16_t lac;
  /**<  
    Location area code (only applicable for 3GPP).
   */

  /*  Is the Cell ID Valid */
  uint8_t cell_id_valid;
  /**<   
      Indicates whether the cell ID is valid; boolean value. 
   */

  /*  Cell ID */
  uint32_t cell_id;
  /**<  
    Cell ID.
   */

  /*  Is the Registration Reject Information Valid */
  uint8_t reg_reject_info_valid;
  /**<   
      Indicates whether the registration reject information is valid; 
      boolean value. 
   */

  /*  Registration Reject Info */
  nas_reg_reject_info_type_v01 reg_reject_info;

  /*  Is the Network ID Valid */
  uint8_t network_id_valid;
  /**<   
      Indicates whether the network ID is valid; boolean value. 
   */

  /*  Network name */
  nas_common_network_id_type_v01 network_id;
  /**<  
    Network ID consists of MCC and MNC.
   */
}nas_3gpp_only_sys_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  nas_common_sys_info_type_v01 common_sys_info;

  nas_cdma_hdr_only_sys_info_type_v01 cdma_hdr_only_sys_info;

  nas_cdma_only_sys_info_type_v01 cdma_specific_sys_info;
}nas_cdma_sys_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  nas_common_sys_info_type_v01 common_sys_info;

  nas_cdma_hdr_only_sys_info_type_v01 cdma_hdr_only_sys_info;

  nas_hdr_only_sys_info_type_v01 hdr_specific_sys_info;
}nas_hdr_sys_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  nas_common_sys_info_type_v01 common_sys_info;

  nas_3gpp_only_sys_info_type_v01 threegpp_specific_sys_info;

  nas_gsm_only_sys_info_type_v01 gsm_specific_sys_info;
}nas_gsm_sys_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  nas_common_sys_info_type_v01 common_sys_info;

  nas_3gpp_only_sys_info_type_v01 threegpp_specific_sys_info;

  nas_wcdma_only_sys_info_type_v01 wcdma_specific_sys_info;
}nas_wcdma_sys_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  nas_common_sys_info_type_v01 common_sys_info;

  nas_3gpp_only_sys_info_type_v01 threegpp_specific_sys_info;

  nas_lte_only_sys_info_type_v01 lte_specific_sys_info;
}nas_lte_sys_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Is the HS Call Status Valid */
  uint8_t hs_call_status_valid;
  /**<   
    Indicates whether the high-speed call status is valid; boolean value. 
   */

  /*  HS Call Status */
  nas_hs_support_enum_type_v01 hs_call_status;
  /**<  
    Call status on high speed (only applicable for WCDMA). Values: \n
    - 0x00 -- SYS_HS_IND_HSDPA_HSUPA_UNSUPP_CELL       -- HSDPA and HSUPA are unsupported \n
    - 0x01 -- SYS_HS_IND_HSDPA_SUPP_CELL               -- HSDPA is supported \n
    - 0x02 -- SYS_HS_IND_HSUPA_SUPP_CELL               -- HSUPA is supported \n
    - 0x03 -- SYS_HS_IND_HSDPA_HSUPA_SUPP_CELL         -- HSDPA and HSUPA are supported \n
    - 0x04 -- SYS_HS_IND_HSDPAPLUS_SUPP_CELL           -- HSDPA+ is supported \n
    - 0x05 -- SYS_HS_IND_HSDPAPLUS_HSUPA_SUPP_CELL     -- HSDPA+ and HSUPA are supported \n
    - 0x06 -- SYS_HS_IND_DC_HSDPAPLUS_SUPP_CELL        -- Dual-cell HSDPA+ is supported \n
    - 0x07 -- SYS_HS_IND_DC_HSDPAPLUS_HSUPA_ SUPP_CELL    -- Dual-cell HSDPA+ and HSUPA are supported \n 
    - 0x08 -- SYS_HS_IND_HSDPAPLUS_64QAM_HSUPA_ SUPP_CELL -- Dual-cell HSDPA+, 64 QAM, and HSUPA are supported \n
    - 0x09 -- SYS_HS_IND_HSDPAPLUS_64QAM_SUPP_CELL -- Dual-cell HSDPA+ and 64 QAM are supported
   */

  /*  Is the HS Service Indication Valid */
  uint8_t hs_ind_valid;
  /**<   
    Indicates whether the high-speed service indication is valid; boolean value. 
   */

  /*   HS service indication */
  nas_hs_support_enum_type_v01 hs_ind;
  /**<  
    High-speed service indication (only applicable for WCDMA). Values: \n
    - 0x00 -- SYS_HS_IND_HSDPA_HSUPA_UNSUPP_CELL       -- HSDPA and HSUPA are unsupported \n
    - 0x01 -- SYS_HS_IND_HSDPA_SUPP_CELL               -- HSDPA is supported \n
    - 0x02 -- SYS_HS_IND_HSUPA_SUPP_CELL               -- HSUPA is supported \n
    - 0x03 -- SYS_HS_IND_HSDPA_HSUPA_SUPP_CELL         -- HSDPA and HSUPA are supported \n
    - 0x04 -- SYS_HS_IND_HSDPAPLUS_SUPP_CELL           -- HSDPA+ is supported \n
    - 0x05 -- SYS_HS_IND_HSDPAPLUS_HSUPA_SUPP_CELL     -- HSDPA+ and HSUPA are supported \n
    - 0x06 -- SYS_HS_IND_DC_HSDPAPLUS_SUPP_CELL        -- Dual-cell HSDPA+ is supported \n
    - 0x07 -- SYS_HS_IND_DC_HSDPAPLUS_HSUPA_ SUPP_CELL    -- Dual-cell HSDPA+ and HSUPA are supported \n 
    - 0x08 -- SYS_HS_IND_HSDPAPLUS_64QAM_HSUPA_ SUPP_CELL -- Dual-cell HSDPA+, 64 QAM, and HSUPA are supported \n
    - 0x09 -- SYS_HS_IND_HSDPAPLUS_64QAM_SUPP_CELL -- Dual-cell HSDPA+ and 64 QAM are supported
   */

  /*  Is the Cell Parameter ID Valid */
  uint8_t cell_parameter_id_valid;
  /**<   
    Indicates whether the cell parameter ID is valid; boolean value. 
   */

  /*  Cell Parameter ID */
  uint16_t cell_parameter_id;
  /**<  
    Cell parameter ID.
     */

  /*  Is the Cell Broadcast Capability Valid */
  uint8_t cell_broadcast_cap_valid;
  /**<   
    Indicates whether the cell broadcast capability is valid; boolean value. 
   */

  nas_cell_broadcast_cap_enum_type_v01 cell_broadcast_cap;
  /**<  
    Cell broadcast capability of the serving system. Values: \n
    - 0x00 -- NAS_CELL_BROADCAST_CAP_UNKNOWN  -- Cell broadcast support is unknown \n
    - 0x01 -- NAS_CELL_BROADCAST_CAP_OFF      -- Cell broadcast is not supported \n
    - 0x02 -- NAS_CELL_BROADCAST_CAP_ON       -- Cell broadcast is supported
    */

  /*  Is the CS Bar Status Valid */
  uint8_t cs_bar_status_valid;
  /**<   
    Indicates whether the circuit-switched call barring status is valid; 
    boolean value. 
   */

  nas_cell_access_status_e_type_v01 cs_bar_status;
  /**<  
    Call barring status for circuit-switched calls. Values: \n
    - 0x00 -- NAS_CELL_ACCESS_NORMAL_ONLY    -- Cell access is allowed for normal calls only \n
    - 0x01 -- NAS_CELL_ACCESS_EMERGENCY_ONLY -- Cell access is allowed for emergency calls only \n
    - 0x02 -- NAS_CELL_ACCESS_NO_CALLS       -- Cell access is not allowed for any call type \n
    - 0x03 -- NAS_CELL_ACCESS_ALL_CALLS      -- Cell access is allowed for all call types \n
    -   -1 -- NAS_CELL_ACCESS_UNKNOWN        -- Cell access type is unknown
    */

  /*  Is the PS Bar Status Valid */
  uint8_t ps_bar_status_valid;
  /**<   
    Indicates whether the packet-switched call barring status is valid; 
    boolean value. 
   */

  nas_cell_access_status_e_type_v01 ps_bar_status;
  /**<  
     Call barring status for packet-switched calls. Values: \n
    - 0x00 -- NAS_CELL_ACCESS_NORMAL_ONLY    -- Cell access is allowed for normal calls only \n
    - 0x01 -- NAS_CELL_ACCESS_EMERGENCY_ONLY -- Cell access is allowed for emergency calls only \n
    - 0x02 -- NAS_CELL_ACCESS_NO_CALLS       -- Cell access is not allowed for any call type \n
    - 0x03 -- NAS_CELL_ACCESS_ALL_CALLS      -- Cell access is allowed for all call types \n
    -   -1 -- NAS_CELL_ACCESS_UNKNOWN        -- Cell access type is unknown
    */

  /*  Is the Cipher Domain Valid */
  uint8_t cipher_domain_valid;
  /**<   
    Indicates whether the cipher domain is valid; boolean value 
   */

  nas_service_domain_enum_type_v01 cipher_domain;
  /**<  
    Ciphering on the service domain. Values: \n
    - 0x00 -- SYS_SRV_DOMAIN_NO_SRV  -- No service \n
    - 0x01 -- SYS_SRV_DOMAIN_CS_ONLY -- Circuit-switched only \n
    - 0x02 -- SYS_SRV_DOMAIN_PS_ONLY -- Packet-switched only \n
    - 0x03 -- SYS_SRV_DOMAIN_CS_PS   -- Circuit-switched and packet-switched
    */
}nas_tdscdma_only_sys_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  nas_common_sys_info_type_v01 common_sys_info;

  nas_3gpp_only_sys_info_type_v01 threegpp_specific_sys_info;

  nas_tdscdma_only_sys_info_type_v01 tdscdma_specific_sys_info;
}nas_tdscdma_sys_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t geo_sys_idx;
  /**<  
    System table index referencing the beginning of the geo in which
    the current serving system is present. When the system index 
    is not known, 0xFFFF is used.
   */

  uint16_t reg_prd;
  /**<  
    Registration period after the CDMA system is acquired. 
    When the CDMA registration period is not valid, 0xFFFF is used. 
   */
}nas_cdma_sys_info2_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t geo_sys_idx;
  /**<  
    System table index referencing the beginning of the geo in which
    the current serving system is present. When the system index
    is not known, 0xFFFF is used.
   */
}nas_hdr_sys_info2_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t geo_sys_idx;
  /**<  
    System table index referencing the beginning of the geo in which
    the current serving system is present. When the system index 
    is not known, 0xFFFF is used.
   */

  nas_cell_broadcast_cap_enum_type_v01 cell_broadcast_cap;
  /**<  
    Cell broadcast capability of the serving system. Values: \n
    - 0x00 -- NAS_CELL_BROADCAST_CAP_UNKNOWN -- Cell broadcast support is unknown \n
    - 0x01 -- NAS_CELL_BROADCAST_CAP_OFF     -- Cell broadcast is not supported \n
    - 0x02 -- NAS_CELL_BROADCAST_CAP_ON      -- Cell broadcast is supported
    */
}nas_gsm_sys_info2_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t geo_sys_idx;
  /**<  
    System table index referencing the beginning of the geo in which
    the current serving system is present. When the system index 
    is not known, 0xFFFF is used.
   */

  nas_cell_broadcast_cap_enum_type_v01 cell_broadcast_cap;
  /**<  
    Cell broadcast capability of the serving system. Values: \n
    - 0x00 -- NAS_CELL_BROADCAST_CAP_UNKNOWN  -- Cell broadcast support is unknown \n
    - 0x01 -- NAS_CELL_BROADCAST_CAP_OFF      -- Cell broadcast is not supported \n
    - 0x02 -- NAS_CELL_BROADCAST_CAP_ON       -- Cell broadcast is supported
    */
}nas_wcdma_sys_info2_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t geo_sys_idx;
  /**<  
    System table index referencing the beginning of the geo in which
    the current serving system is present. When the system index 
    is not known, 0xFFFF is used.
   */
}nas_lte_sys_info2_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_SIM_REJ_INFO_ENUM_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_SIM_NOT_AVAILABLE_V01 = 0, /**<  SIM is not available.  */
  NAS_SIM_AVAILABLE_V01 = 1, /**<  SIM is available.  */
  NAS_SIM_CS_INVALID_V01 = 2, /**<  SIM has been marked by the network as invalid for CS services.  */
  NAS_SIM_PS_INVALID_V01 = 3, /**<  SIM has been marked by the network as invalid for PS services. 
 SIM has been marked by the network as invalid for CS and PS services.  */
  NAS_SIM_CS_PS_INVALID_V01 = 4, 
  NAS_SIM_REJ_INFO_ENUM_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_sim_rej_info_enum_type_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Provides the system information.
               \label{idl:getSysInfo} */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */

  /* Optional */
  /*  CDMA Service Status Info */
  uint8_t cdma_srv_status_info_valid;  /**< Must be set to true if cdma_srv_status_info is being passed */
  nas_3gpp2_srv_status_info_type_v01 cdma_srv_status_info;

  /* Optional */
  /*  HDR Service Status Info */
  uint8_t hdr_srv_status_info_valid;  /**< Must be set to true if hdr_srv_status_info is being passed */
  nas_3gpp2_srv_status_info_type_v01 hdr_srv_status_info;

  /* Optional */
  /*  GSM Service Status Info */
  uint8_t gsm_srv_status_info_valid;  /**< Must be set to true if gsm_srv_status_info is being passed */
  nas_3gpp_srv_status_info_type_v01 gsm_srv_status_info;

  /* Optional */
  /*  WCDMA Service Status Info */
  uint8_t wcdma_srv_status_info_valid;  /**< Must be set to true if wcdma_srv_status_info is being passed */
  nas_3gpp_srv_status_info_type_v01 wcdma_srv_status_info;

  /* Optional */
  /*  LTE Service Status Info */
  uint8_t lte_srv_status_info_valid;  /**< Must be set to true if lte_srv_status_info is being passed */
  nas_3gpp_srv_status_info_type_v01 lte_srv_status_info;

  /* Optional */
  /*  CDMA System Info */
  uint8_t cdma_sys_info_valid;  /**< Must be set to true if cdma_sys_info is being passed */
  nas_cdma_sys_info_type_v01 cdma_sys_info;

  /* Optional */
  /*  HDR System Info */
  uint8_t hdr_sys_info_valid;  /**< Must be set to true if hdr_sys_info is being passed */
  nas_hdr_sys_info_type_v01 hdr_sys_info;

  /* Optional */
  /*  GSM System Info */
  uint8_t gsm_sys_info_valid;  /**< Must be set to true if gsm_sys_info is being passed */
  nas_gsm_sys_info_type_v01 gsm_sys_info;

  /* Optional */
  /*  WCDMA System Info */
  uint8_t wcdma_sys_info_valid;  /**< Must be set to true if wcdma_sys_info is being passed */
  nas_wcdma_sys_info_type_v01 wcdma_sys_info;

  /* Optional */
  /*  LTE System Info */
  uint8_t lte_sys_info_valid;  /**< Must be set to true if lte_sys_info is being passed */
  nas_lte_sys_info_type_v01 lte_sys_info;

  /* Optional */
  /*  Additional CDMA System Info */
  uint8_t cdma_sys_info2_valid;  /**< Must be set to true if cdma_sys_info2 is being passed */
  nas_cdma_sys_info2_type_v01 cdma_sys_info2;

  /* Optional */
  /*  Additional HDR System Info */
  uint8_t hdr_sys_info2_valid;  /**< Must be set to true if hdr_sys_info2 is being passed */
  nas_hdr_sys_info2_type_v01 hdr_sys_info2;

  /* Optional */
  /*  Additional GSM System Info */
  uint8_t gsm_sys_info2_valid;  /**< Must be set to true if gsm_sys_info2 is being passed */
  nas_gsm_sys_info2_type_v01 gsm_sys_info2;

  /* Optional */
  /*  Additional WCDMA System Info */
  uint8_t wcdma_sys_info2_valid;  /**< Must be set to true if wcdma_sys_info2 is being passed */
  nas_wcdma_sys_info2_type_v01 wcdma_sys_info2;

  /* Optional */
  /*  Additional LTE System Info */
  uint8_t lte_sys_info2_valid;  /**< Must be set to true if lte_sys_info2 is being passed */
  nas_lte_sys_info2_type_v01 lte_sys_info2;

  /* Optional */
  /*  GSM Call Barring System Info */
  uint8_t gsm_sys_info3_valid;  /**< Must be set to true if gsm_sys_info3 is being passed */
  nas_gw_sys_info3_type_v01 gsm_sys_info3;

  /* Optional */
  /*  WCDMA Call Barring System Info */
  uint8_t wcdma_sys_info3_valid;  /**< Must be set to true if wcdma_sys_info3 is being passed */
  nas_gw_sys_info3_type_v01 wcdma_sys_info3;

  /* Optional */
  /*  LTE Voice Support Sys Info */
  uint8_t voice_support_on_lte_valid;  /**< Must be set to true if voice_support_on_lte is being passed */
  uint8_t voice_support_on_lte;
  /**<  
    Indicates voice support status on LTE. Values: \n
    - 0x00 -- Voice is not supported \n
    - 1x01 -- Voice is supported
    */

  /* Optional */
  /*  GSM Cipher Domain Sys Info */
  uint8_t gsm_cipher_domain_valid;  /**< Must be set to true if gsm_cipher_domain is being passed */
  nas_service_domain_enum_type_v01 gsm_cipher_domain;
  /**<  
    Ciphering on the service domain. Values: \n
    - 0x00 -- SYS_SRV_DOMAIN_NO_SRV  -- No service \n
    - 0x01 -- SYS_SRV_DOMAIN_CS_ONLY -- Circuit-switched only \n
    - 0x02 -- SYS_SRV_DOMAIN_PS_ONLY -- Packet-switched only \n
    - 0x03 -- SYS_SRV_DOMAIN_CS_PS   -- Circuit-switched and packet-switched
    */

  /* Optional */
  /*  WCDMA Cipher Domain Sys Info */
  uint8_t wcdma_cipher_domain_valid;  /**< Must be set to true if wcdma_cipher_domain is being passed */
  nas_service_domain_enum_type_v01 wcdma_cipher_domain;
  /**<  
    Ciphering on the service domain. Values: \n
    - 0x00 -- SYS_SRV_DOMAIN_NO_SRV  -- No service \n
    - 0x01 -- SYS_SRV_DOMAIN_CS_ONLY -- Circuit-switched only \n
    - 0x02 -- SYS_SRV_DOMAIN_PS_ONLY -- Packet-switched only \n
    - 0x03 -- SYS_SRV_DOMAIN_CS_PS   -- Circuit-switched and packet-switched
    */

  /* Optional */
  /*  TDSCDMA Service Status Info */
  uint8_t tdscdma_srv_status_info_valid;  /**< Must be set to true if tdscdma_srv_status_info is being passed */
  nas_3gpp_srv_status_info_type_v01 tdscdma_srv_status_info;

  /* Optional */
  /*  TDSCDMA System Info */
  uint8_t tdscdma_sys_info_valid;  /**< Must be set to true if tdscdma_sys_info is being passed */
  nas_tdscdma_sys_info_type_v01 tdscdma_sys_info;

  /* Optional */
  /*  LTE eMBMS Coverage Info */
  uint8_t lte_embms_coverage_valid;  /**< Must be set to true if lte_embms_coverage is being passed */
  uint8_t lte_embms_coverage;
  /**<  
    Values: \n
    - TRUE  -- Current LTE system supports eMBMS \n
    - FALSE -- Current LTE system does not support eMBMS
   */

  /* Optional */
  /*  SIM Reject Information */
  uint8_t sim_rej_info_valid;  /**< Must be set to true if sim_rej_info is being passed */
  nas_sim_rej_info_enum_type_v01 sim_rej_info;
  /**<  
    Current reject state information of the SIM. Values: \n
    - 0 -- NAS_SIM_NOT_AVAILABLE -- SIM is not available \n
    - 1 -- NAS_SIM_AVAILABLE     -- SIM is available     \n
    - 2 -- NAS_SIM_CS_INVALID    -- SIM has been marked by the network as 
                                    invalid for circuit-switched services \n
    - 3 -- NAS_SIM_PS_INVALID    -- SIM has been marked by the network as 
                                    invalid for packet-switched services  \n
    - 4 -- NAS_SIM_CS_PS_INVALID -- SIM has been marked by the network as 
                                    invalid for circuit-switched and 
                                    packet-switched services
   */

  /* Optional */
  /*  WCDMA EUTRA Status Information */
  uint8_t wcdma_eutra_status_valid;  /**< Must be set to true if wcdma_eutra_status is being passed */
  nas_eutra_cell_status_enum_type_v01 wcdma_eutra_status;
  /**<  
    E-UTRA detection status. Values: \n
    - 0 -- NAS_EUTRA_CELL_PRESENT          -- E-UTRA cell is detected            \n
    - 1 -- NAS_EUTRA_CELL_NOT_PRESENT      -- E-UTRA cell is not detected        \n
    - 2 -- NAS_EUTRA_CELL_PRESENCE_UNKNOWN -- E-UTRA cell information is unknown 
                                              due to a state transition          \n
    - 3 -- NAS_EUTRA_CELL_DETECTION_ UNSUPPORTED -- E-UTRA detection is not supported
   */

  /* Optional */
  /*  IMS voice support status on LTE */
  uint8_t lte_ims_voice_avail_valid;  /**< Must be set to true if lte_ims_voice_avail is being passed */
  uint8_t lte_ims_voice_avail;
  /**<   - 0x00 -- IMS voice support on LTE not available
       - 0x01 -- IMS voice support on LTE available
   */
}nas_get_sys_info_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Indication Message; Indicates a change in the system information.   
             \label{idl:sysInfoInd} */
typedef struct {

  /* Optional */
  /*  CDMA Service Status Info */
  uint8_t cdma_srv_status_info_valid;  /**< Must be set to true if cdma_srv_status_info is being passed */
  nas_3gpp2_srv_status_info_type_v01 cdma_srv_status_info;

  /* Optional */
  /*  HDR Service Status Info */
  uint8_t hdr_srv_status_info_valid;  /**< Must be set to true if hdr_srv_status_info is being passed */
  nas_3gpp2_srv_status_info_type_v01 hdr_srv_status_info;

  /* Optional */
  /*  GSM Service Status Info */
  uint8_t gsm_srv_status_info_valid;  /**< Must be set to true if gsm_srv_status_info is being passed */
  nas_3gpp_srv_status_info_type_v01 gsm_srv_status_info;

  /* Optional */
  /*  WCDMA Service Status Info */
  uint8_t wcdma_srv_status_info_valid;  /**< Must be set to true if wcdma_srv_status_info is being passed */
  nas_3gpp_srv_status_info_type_v01 wcdma_srv_status_info;

  /* Optional */
  /*  LTE Service Status Info */
  uint8_t lte_srv_status_info_valid;  /**< Must be set to true if lte_srv_status_info is being passed */
  nas_3gpp_srv_status_info_type_v01 lte_srv_status_info;

  /* Optional */
  /*  CDMA System Info */
  uint8_t cdma_sys_info_valid;  /**< Must be set to true if cdma_sys_info is being passed */
  nas_cdma_sys_info_type_v01 cdma_sys_info;

  /* Optional */
  /*  HDR System Info */
  uint8_t hdr_sys_info_valid;  /**< Must be set to true if hdr_sys_info is being passed */
  nas_hdr_sys_info_type_v01 hdr_sys_info;

  /* Optional */
  /*  GSM System Info */
  uint8_t gsm_sys_info_valid;  /**< Must be set to true if gsm_sys_info is being passed */
  nas_gsm_sys_info_type_v01 gsm_sys_info;

  /* Optional */
  /*  WCDMA System Info */
  uint8_t wcdma_sys_info_valid;  /**< Must be set to true if wcdma_sys_info is being passed */
  nas_wcdma_sys_info_type_v01 wcdma_sys_info;

  /* Optional */
  /*  LTE System Info */
  uint8_t lte_sys_info_valid;  /**< Must be set to true if lte_sys_info is being passed */
  nas_lte_sys_info_type_v01 lte_sys_info;

  /* Optional */
  /*  Additional CDMA System Info */
  uint8_t cdma_sys_info2_valid;  /**< Must be set to true if cdma_sys_info2 is being passed */
  nas_cdma_sys_info2_type_v01 cdma_sys_info2;

  /* Optional */
  /*  Additional HDR System Info */
  uint8_t hdr_sys_info2_valid;  /**< Must be set to true if hdr_sys_info2 is being passed */
  nas_hdr_sys_info2_type_v01 hdr_sys_info2;

  /* Optional */
  /*  Additional GSM System Info */
  uint8_t gsm_sys_info2_valid;  /**< Must be set to true if gsm_sys_info2 is being passed */
  nas_gsm_sys_info2_type_v01 gsm_sys_info2;

  /* Optional */
  /*  Additional WCDMA System Info */
  uint8_t wcdma_sys_info2_valid;  /**< Must be set to true if wcdma_sys_info2 is being passed */
  nas_wcdma_sys_info2_type_v01 wcdma_sys_info2;

  /* Optional */
  /*  Additional LTE System Info */
  uint8_t lte_sys_info2_valid;  /**< Must be set to true if lte_sys_info2 is being passed */
  nas_lte_sys_info2_type_v01 lte_sys_info2;

  /* Optional */
  /*  GSM Call Barring System Info */
  uint8_t gsm_sys_info3_valid;  /**< Must be set to true if gsm_sys_info3 is being passed */
  nas_gw_sys_info3_type_v01 gsm_sys_info3;

  /* Optional */
  /*  WCDMA Call Barring System Info */
  uint8_t wcdma_sys_info3_valid;  /**< Must be set to true if wcdma_sys_info3 is being passed */
  nas_gw_sys_info3_type_v01 wcdma_sys_info3;

  /* Optional */
  /*  LTE Voice Support Sys Info */
  uint8_t voice_support_on_lte_valid;  /**< Must be set to true if voice_support_on_lte is being passed */
  uint8_t voice_support_on_lte;
  /**<  
    Indicates voice support status on LTE. Values: \n
    - 0x00 -- Voice is not supported \n
    - 1x01 -- Voice is supported
    */

  /* Optional */
  /*  GSM Cipher Domain Sys Info */
  uint8_t gsm_cipher_domain_valid;  /**< Must be set to true if gsm_cipher_domain is being passed */
  nas_service_domain_enum_type_v01 gsm_cipher_domain;
  /**<  
    Ciphering on the service domain. Values: \n
    - 0x00 -- SYS_SRV_DOMAIN_NO_SRV  -- No service \n
    - 0x01 -- SYS_SRV_DOMAIN_CS_ONLY -- Circuit-switched only \n
    - 0x02 -- SYS_SRV_DOMAIN_PS_ONLY -- Packet-switched only \n
    - 0x03 -- SYS_SRV_DOMAIN_CS_PS   -- Circuit-switched and packet-switched
    */

  /* Optional */
  /*  WCDMA Cipher Domain Sys Info */
  uint8_t wcdma_cipher_domain_valid;  /**< Must be set to true if wcdma_cipher_domain is being passed */
  nas_service_domain_enum_type_v01 wcdma_cipher_domain;
  /**<  
    Ciphering on the service domain. Values: \n
    - 0x00 -- SYS_SRV_DOMAIN_NO_SRV  -- No service \n
    - 0x01 -- SYS_SRV_DOMAIN_CS_ONLY -- Circuit-switched only \n
    - 0x02 -- SYS_SRV_DOMAIN_PS_ONLY -- Packet-switched only \n
    - 0x03 -- SYS_SRV_DOMAIN_CS_PS   -- Circuit-switched and packet-switched
    */

  /* Optional */
  /*  System Info No Change */
  uint8_t sys_info_no_change_valid;  /**< Must be set to true if sys_info_no_change is being passed */
  uint8_t sys_info_no_change;
  /**<   
    Flag used to notify clients that a request to select a network ended 
    with no change in the PLMN. Values: \n
    - 0x01 -- No change in system information
   */

  /* Optional */
  /*  TDSCDMA Service Status Info */
  uint8_t tdscdma_srv_status_info_valid;  /**< Must be set to true if tdscdma_srv_status_info is being passed */
  nas_3gpp_srv_status_info_type_v01 tdscdma_srv_status_info;

  /* Optional */
  /*  TDSCDMA System Info */
  uint8_t tdscdma_sys_info_valid;  /**< Must be set to true if tdscdma_sys_info is being passed */
  nas_tdscdma_sys_info_type_v01 tdscdma_sys_info;

  /* Optional */
  /*  LTE eMBMS Coverage Info */
  uint8_t lte_embms_coverage_valid;  /**< Must be set to true if lte_embms_coverage is being passed */
  uint8_t lte_embms_coverage;
  /**<  
    Values: \n
    - TRUE  -- Current LTE system supports eMBMBS \n
    - FALSE -- Current LTE system does not support eMBMBS
  */

  /* Optional */
  /*  SIM reject information */
  uint8_t sim_rej_info_valid;  /**< Must be set to true if sim_rej_info is being passed */
  nas_sim_rej_info_enum_type_v01 sim_rej_info;
  /**<  
       Current reject state information of the SIM. Values: \n
    - 0 -- NAS_SIM_NOT_AVAILABLE -- SIM is not available \n
    - 1 -- NAS_SIM_AVAILABLE     -- SIM is available     \n
    - 2 -- NAS_SIM_CS_INVALID    -- SIM has been marked by the network as 
                                    invalid for circuit-switched services \n
    - 3 -- NAS_SIM_PS_INVALID    -- SIM has been marked by the network as 
                                    invalid for packet-switched services  \n
    - 4 -- NAS_SIM_CS_PS_INVALID -- SIM has been marked by the network as 
                                    invalid for circuit-switched and 
                                    packet-switched services
   */

  /* Optional */
  /*  WCDMA EUTRA Status Information */
  uint8_t wcdma_eutra_status_valid;  /**< Must be set to true if wcdma_eutra_status is being passed */
  nas_eutra_cell_status_enum_type_v01 wcdma_eutra_status;
  /**<  
     E-UTRA detection status. Values: \n
    - 0 -- NAS_EUTRA_CELL_PRESENT          -- E-UTRA cell is detected            \n
    - 1 -- NAS_EUTRA_CELL_NOT_PRESENT      -- E-UTRA cell is not detected        \n
    - 2 -- NAS_EUTRA_CELL_PRESENCE_UNKNOWN -- E-UTRA cell information is unknown 
                                              due to a state transition          \n
    - 3 -- NAS_EUTRA_CELL_DETECTION_ UNSUPPORTED -- E-UTRA detection is not supported
   */

  /* Optional */
  /*  IMS voice support status on LTE */
  uint8_t lte_ims_voice_avail_valid;  /**< Must be set to true if lte_ims_voice_avail is being passed */
  uint8_t lte_ims_voice_avail;
  /**<   - 0x00 -- IMS voice support on LTE not available
       - 0x01 -- IMS voice support on LTE available
   */

  /* Optional */
  uint8_t lte_voice_status_valid;  /**< Must be set to true if lte_voice_status is being passed */
  uint32_t lte_voice_status;

  /* Optional */
  uint8_t cdma_reg_zone_valid;  /**< Must be set to true if cdma_reg_zone is being passed */
  uint16_t cdma_reg_zone;

  /* Optional */
  uint8_t gsm_rac_valid;  /**< Must be set to true if gsm_rac is being passed */
  uint8_t gsm_rac;

  /* Optional */
  uint8_t wcdma_rac_valid;  /**< Must be set to true if wcdma_rac is being passed */
  uint8_t wcdma_rac;

  /* Optional */
  uint8_t cdma_mcc_resolved_via_sid_lookup_valid;  /**< Must be set to true if cdma_mcc_resolved_via_sid_lookup is being passed */
  uint16_t cdma_mcc_resolved_via_sid_lookup;

  /* Optional */
  uint8_t srv_reg_restriction_valid;  /**< Must be set to true if srv_reg_restriction is being passed */
  uint32_t srv_reg_restriction;

  /* Optional */
  uint8_t tdscdma_reg_domain_valid;  /**< Must be set to true if tdscdma_reg_domain is being passed */
  uint32_t tdscdma_reg_domain;

  /* Optional */
  uint8_t lte_reg_domain_valid;  /**< Must be set to true if lte_reg_domain is being passed */
  uint32_t lte_reg_domain;

  /* Optional */
  uint8_t wcdma_reg_domain_valid;  /**< Must be set to true if wcdma_reg_domain is being passed */
  uint32_t wcdma_reg_domain;

  /* Optional */
  uint8_t gsm_reg_domain_valid;  /**< Must be set to true if gsm_reg_domain is being passed */
  uint32_t gsm_reg_domain;

  /* Optional */
  uint8_t lte_embms_coverage_trace_id_valid;  /**< Must be set to true if lte_embms_coverage_trace_id is being passed */
  uint32_t lte_embms_coverage_trace_id;

  /* Optional */
  uint8_t csg_id_valid;  /**< Must be set to true if csg_id is being passed */
  uint32_t csg_id;
  uint8_t name_len;
  uint16_t name[NAS_CSG_NAME_MAX_LEN];

  /* Optional */
  uint8_t lte_is_eb_supported_valid;  /**< Must be set to true if lte_is_eb_supported is being passed */
  uint32_t lte_is_eb_supported;
}nas_sys_info_ind_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_sig_info_req_msg is empty
 * typedef struct {
 * }nas_get_sig_info_req_msg_v01;
 */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  RSSI */
  int8_t rssi;
  /**<  
      RSSI in dBm (signed value); a value of -125 dBm or lower is
      used to indicate No Signal: \n 
      - For CDMA and UMTS, this indicates forward link pilot Ec   \n
       - For GSM, this indicates received signal strength
   */

  /*  ECIO */
  int16_t ecio;
  /**<  
      ECIO value representing negative 0.5 dBm increments, i.e., 
      2 means -1 dBm (14 means -7 dBm, 63 means -31.5 dBm).
   */
}nas_common_sig_info_param_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  nas_common_sig_info_param_type_v01 common_sig_str;

  /*  SINR */
  nas_sinr_enum_v01 sinr;
  /**<   
     SINR level. SINR is only applicable for 1xEV-DO. 
     Valid levels are 0 to 8, where the maximum value for:        \n
     - 0x00 -- SINR_LEVEL_0 is -9 dB     \n
     - 0x01 -- SINR_LEVEL_1 is -6 dB     \n
     - 0x02 -- SINR_LEVEL_2 is -4.5 dB   \n
     - 0x03 -- SINR_LEVEL_3 is -3 dB     \n
     - 0x04 -- SINR_LEVEL_4 is -2 dB     \n
     - 0x05 -- SINR_LEVEL_5 is +1 dB     \n
     - 0x06 -- SINR_LEVEL_6 is +3 dB     \n
     - 0x07 -- SINR_LEVEL_7 is +6 dB     \n
     - 0x08 -- SINR_LEVEL_8 is +9 dB
  */

  /*  IO */
  int32_t io;
  /**<  
     Received IO in dBm. IO is only applicable for 1xEV-DO. 
  */
}nas_hdr_sig_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  RSSI */
  int8_t rssi;
  /**<  
     RSSI in dBm (signed value); a value of -125 dBm or lower is
     used to indicate No Signal: \n 
     - For CDMA and UMTS, this indicates forward link pilot Ec   \n
       - For GSM, this indicates received signal strength
  */

  /*  RSRQ */
  int8_t rsrq;
  /**<  
     RSRQ value in dB (signed integer value) as measured by L1. 
     Range: -3 to -20 (-3 means -3 dB, -20 means -20 dB). 
  */

  /*  RSRP */
  int16_t rsrp;
  /**<  
     Current RSRP in dBm as measured by L1. 
     Range: -44 to -140 (-44 means -44 dBm, -140 means -140 dBm).
  */

  /*  SNR */
  int16_t snr;
  /**<   
     SNR level as a scaled integer in units of 0.1 dB; 
     e.g., -16 dB has a value of -160 and 24.6 dB has a value of 246.
  */
}nas_lte_sig_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Queries information regarding the signal strength.
               \label{idl:getSigInfo} */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */

  /* Optional */
  /*  CDMA Signal Strength Info */
  uint8_t cdma_sig_info_valid;  /**< Must be set to true if cdma_sig_info is being passed */
  nas_common_sig_info_param_type_v01 cdma_sig_info;

  /* Optional */
  /*  HDR Signal Strength Info */
  uint8_t hdr_sig_info_valid;  /**< Must be set to true if hdr_sig_info is being passed */
  nas_hdr_sig_info_type_v01 hdr_sig_info;

  /* Optional */
  /*  GSM Signal Strength Info */
  uint8_t gsm_sig_info_valid;  /**< Must be set to true if gsm_sig_info is being passed */
  int8_t gsm_sig_info;
  /**<  
    GSM signal strength is the RSSI in dBm (signed value). 
    A value of -125 dBm or lower is used to indicate No Signal.
   */

  /* Optional */
  /*  WCDMA Signal Strength Info */
  uint8_t wcdma_sig_info_valid;  /**< Must be set to true if wcdma_sig_info is being passed */
  nas_common_sig_info_param_type_v01 wcdma_sig_info;

  /* Optional */
  /*  LTE Signal Strength Info */
  uint8_t lte_sig_info_valid;  /**< Must be set to true if lte_sig_info is being passed */
  nas_lte_sig_info_type_v01 lte_sig_info;

  /* Optional */
  /*  TDSCDMA Signal Strength Info */
  uint8_t rscp_valid;  /**< Must be set to true if rscp is being passed */
  int8_t rscp;
  /**<  
    RSCP of the Primary Common Control Physical Channel (PCCPCH) in dBm. 
    Measurement range: -120 dBm to -25 dBm. 
   */
}nas_get_sig_info_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_LTE_SIG_RPT_RATE_ENUM_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_LTE_SIG_RPT_RATE_DEFAULT_V01 = 0, 
  NAS_LTE_SIG_RPT_RATE_1_SEC_V01 = 1, 
  NAS_LTE_SIG_RPT_RATE_2_SEC_V01 = 2, 
  NAS_LTE_SIG_RPT_RATE_3_SEC_V01 = 3, 
  NAS_LTE_SIG_RPT_RATE_4_SEC_V01 = 4, 
  NAS_LTE_SIG_RPT_RATE_5_SEC_V01 = 5, 
  NAS_LTE_SIG_RPT_RATE_ENUM_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_lte_sig_rpt_rate_enum_type_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_LTE_SIG_AVG_PRD_ENUM_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_LTE_SIG_AVG_PRD_DEFAULT_V01 = 0, 
  NAS_LTE_SIG_AVG_PRD_1_SEC_V01 = 1, 
  NAS_LTE_SIG_AVG_PRD_2_SEC_V01 = 2, 
  NAS_LTE_SIG_AVG_PRD_3_SEC_V01 = 3, 
  NAS_LTE_SIG_AVG_PRD_4_SEC_V01 = 4, 
  NAS_LTE_SIG_AVG_PRD_5_SEC_V01 = 5, 
  NAS_LTE_SIG_AVG_PRD_6_SEC_V01 = 6, 
  NAS_LTE_SIG_AVG_PRD_7_SEC_V01 = 7, 
  NAS_LTE_SIG_AVG_PRD_8_SEC_V01 = 8, 
  NAS_LTE_SIG_AVG_PRD_9_SEC_V01 = 9, 
  NAS_LTE_SIG_AVG_PRD_10_SEC_V01 = 10, 
  NAS_LTE_SIG_AVG_PRD_ENUM_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_lte_sig_avg_prd_enum_type_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Report rate */
  nas_lte_sig_rpt_rate_enum_type_v01 rpt_rate;
  /**<  
      Rate on how often the LTE signal must be checked for reporting. Values: \n
      - 0 -- Report using the default configuration \n
      - 1 -- Report every 1 sec \n
      - 2 -- Report every 2 sec \n
      - 3 -- Report every 3 sec \n
      - 4 -- Report every 4 sec \n
      - 5 -- Report every 5 sec
    */

  /*  Averaging period */
  nas_lte_sig_avg_prd_enum_type_v01 avg_period;
  /**<  
      Averaging period to be used for the LTE signal. Values: \n
      - 0 -- Average using the default configuration \n
      - 1 -- Average over 1 sec \n
      - 2 -- Average over 2 sec \n
      - 3 -- Average over 3 sec \n
      - 4 -- Average over 4 sec \n
      - 5  -- Average over 5 sec \n
      - 6  -- Average over 6 sec \n
      - 7  -- Average over 7 sec \n
      - 8  -- Average over 8 sec \n
      - 9  -- Average over 9 sec \n
      - 10 -- Average over 10 sec
    */
}nas_lte_sig_rpt_config_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Sets the signal strength reporting thresholds.
               \label{idl:configSigInfo} */
typedef struct {

  /* Optional */
  /*  RSSI Threshold List  */
  uint8_t rssi_threshold_list_valid;  /**< Must be set to true if rssi_threshold_list is being passed */
  uint32_t rssi_threshold_list_len;  /**< Must be set to # of elements in rssi_threshold_list */
  int8_t rssi_threshold_list[NAS_SIG_STR_THRESHOLD_LIST_MAX_V01];
  /**<  
      RSSI in dBm (signed value). A value of -125 dBm or lower is
      used to indicate No Signal. 
      RSSI values have the following ranges (in dBm): \n
      - 800 CDMA  is -105 to -90   \n
      - 1900 CDMA is -108 to -93   \n
      - HDR       is -105 to -90   \n
      - GSM       is -105 to -60   \n
      - WCDMA     is -105 to -60   \n
      - LTE       is -105 to -60   \n
      The threshold values specified here are used for all RATs.  \n \vspace{-.12in}

      For CDMA and UMTS, this threshold setting results in the 
      forward link pilot Ec values to be reported as part of the rssi
      field in TLV corresponding to the RAT in the QMI_NAS_SIG_INFO_IND
      indication.                                                 \n \vspace{-.12in}

      For GSM, this threshold setting results in the received 
      signal strength to be reported as part of the GSM Signal Strength Info 
      TLV in the QMI_NAS_SIG_INFO_IND indication.
  */

  /* Optional */
  /*  ECIO Threshold List */
  uint8_t ecio_threshold_list_valid;  /**< Must be set to true if ecio_threshold_list is being passed */
  uint32_t ecio_threshold_list_len;  /**< Must be set to # of elements in ecio_threshold_list */
  int16_t ecio_threshold_list[NAS_SIG_STR_THRESHOLD_LIST_MAX_V01];
  /**<  
      A sequence of thresholds delimiting ECIO event reporting bands.
      Every time a new ECIO value crosses a threshold value, an event
      report indication message with the new ECIO value is sent to the
      requesting control point. For this field: \n

      - Each ECIO threshold value is a signed 2 byte value \n
      - Maximum number of threshold values is 16           \n
      - At least one value must be specified (if report_ecio is set) \n
      - Threshold values specified here are used for all RATs
   */

  /* Optional */
  /*  HDR SINR Threshold List */
  uint8_t hdr_sinr_threshold_list_valid;  /**< Must be set to true if hdr_sinr_threshold_list is being passed */
  uint32_t hdr_sinr_threshold_list_len;  /**< Must be set to # of elements in hdr_sinr_threshold_list */
  uint8_t hdr_sinr_threshold_list[NAS_SIG_STR_THRESHOLD_LIST_MAX_V01];
  /**<  
      A sequence of thresholds delimiting SINR event reporting bands.
      Every time a new SINR value crosses a threshold value, an event
      report indication message with the new SINR value is sent to the
      requesting control point. For this field: \n
      
      - SINR is reported only for HDR \n
      - Each SINR threshold value is an unsigned 1 byte value \n
      - Maximum number of threshold values is 16              \n
      - At least one value must be specified (if report_sinr is set)
    */

  /* Optional */
  /*  LTE SNR Threshold List */
  uint8_t lte_snr_threshold_list_valid;  /**< Must be set to true if lte_snr_threshold_list is being passed */
  uint32_t lte_snr_threshold_list_len;  /**< Must be set to # of elements in lte_snr_threshold_list */
  int16_t lte_snr_threshold_list[NAS_SIG_STR_THRESHOLD_LIST_MAX_V01];
  /**<  
      A sequence of thresholds delimiting SNR event reporting bands.
      Every time a new SNR value crosses a threshold value, an event
      report indication message with the new snr value is sent to the
      requesting control point. For this field: \n

      - For LTE, each SNR threshold value is a signed 2 byte value  \n
      - Maximum number of threshold values is 16                    \n 
      - At least one value must be specified (if report_snr is set) \n
      - SNR level as a scaled integer in units of 0.1 dB; 
        e.g., -16 dB has a value of -160 and 24.6 dB has a value of 246
  
    */

  /* Optional */
  /*  IO Threshold List */
  uint8_t io_threshold_list_valid;  /**< Must be set to true if io_threshold_list is being passed */
  uint32_t io_threshold_list_len;  /**< Must be set to # of elements in io_threshold_list */
  int32_t io_threshold_list[NAS_SIG_STR_THRESHOLD_LIST_MAX_V01];
  /**<  
      A sequence of thresholds delimiting IO event reporting bands.
      Every time a new IO value crosses a threshold value, an event
      report indication message with the new IO value is sent to the
      requesting control point. For this field: \n
      
      - IO is applicable only for HDR \n
      - Each IO threshold value is a signed 4 byte value \n
      - Maximum number of threshold values is 16         \n
      - At least one value must be specified
  */

  /* Optional */
  /*  RSRQ Threshold List */
  uint8_t lte_rsrq_threshold_list_valid;  /**< Must be set to true if lte_rsrq_threshold_list is being passed */
  uint32_t lte_rsrq_threshold_list_len;  /**< Must be set to # of elements in lte_rsrq_threshold_list */
  int8_t lte_rsrq_threshold_list[NAS_SIG_STR_THRESHOLD_LIST_MAX_V01];
  /**<  
      A sequence of thresholds delimiting current RSRQ event reporting bands.
      Every time a new RSRQ value crosses a specified threshold value, an
      event report indication message with the new RSRQ value is sent
      to the requesting control point. For this field: \n

      - RSRQ values are applicable only for LTE \n
      - RSRQ values are measured in dBm, with a range of -20 dBm to -3 dBm \n
      - Each RSRQ threshold value is a signed byte value \n
      - Maximum number of threshold values is 16         \n
      - At least one value must be specified
  */

  /* Optional */
  /*  RSRP Threshold List */
  uint8_t lte_rsrp_threshold_list_valid;  /**< Must be set to true if lte_rsrp_threshold_list is being passed */
  uint32_t lte_rsrp_threshold_list_len;  /**< Must be set to # of elements in lte_rsrp_threshold_list */
  int16_t lte_rsrp_threshold_list[NAS_SIG_STR_THRESHOLD_LIST_MAX_V01];
  /**<  
      A sequence of thresholds delimiting current RSRP event reporting bands.
      Every time a new RSRP value crosses a specified threshold value, an
      event report indication message with the new RSRP value is sent
      to the requesting control point. For this field: \n

      - RSRP values are applicable only for LTE \n
      - RSRP values are measured in dBm, with a range of -44 dBm to -140 dBm \n
      - Each RSRP threshold value is a signed 2 byte value \n
      - Maximum number of threshold values is 16           \n
      - At least one value must be specified
     */

  /* Optional */
  /*  LTE Signal Report Config */
  uint8_t lte_sig_rpt_config_valid;  /**< Must be set to true if lte_sig_rpt_config is being passed */
  nas_lte_sig_rpt_config_type_v01 lte_sig_rpt_config;

  /* Optional */
  /*  RSCP Threshold List  */
  uint8_t rscp_threshold_list_valid;  /**< Must be set to true if rscp_threshold_list is being passed */
  uint32_t rscp_threshold_list_len;  /**< Must be set to # of elements in rscp_threshold_list */
  int8_t rscp_threshold_list[NAS_SIG_STR_THRESHOLD_LIST_MAX_V01];
  /**<  
       RSCP in dBm (signed value). 
       RSCP values have the following ranges (in dBm): \n
       - TD-SCDMA is -120 to -25   \n
       The threshold values specified here are used for all RATs.
      */
}nas_config_sig_info_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Sets the signal strength reporting thresholds.
               \label{idl:configSigInfo} */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_config_sig_info_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Indication Message; Provides any change in signal strength status.
             \label{idl:sigInfoInd} */
typedef struct {

  /* Optional */
  /*  CDMA Signal Strength Info */
  uint8_t cdma_sig_info_valid;  /**< Must be set to true if cdma_sig_info is being passed */
  nas_common_sig_info_param_type_v01 cdma_sig_info;

  /* Optional */
  /*  HDR Signal Strength Info */
  uint8_t hdr_sig_info_valid;  /**< Must be set to true if hdr_sig_info is being passed */
  nas_hdr_sig_info_type_v01 hdr_sig_info;

  /* Optional */
  /*  GSM Signal Strength Info */
  uint8_t gsm_sig_info_valid;  /**< Must be set to true if gsm_sig_info is being passed */
  int8_t gsm_sig_info;
  /**<  
    GSM signal strength is the RSSI in dBm (signed value). 
    A value of -125 dBm or lower is used to indicate No Signal.
     */

  /* Optional */
  /*  WCDMA Signal Strength Info */
  uint8_t wcdma_sig_info_valid;  /**< Must be set to true if wcdma_sig_info is being passed */
  nas_common_sig_info_param_type_v01 wcdma_sig_info;

  /* Optional */
  /*  LTE Signal Strength Info */
  uint8_t lte_sig_info_valid;  /**< Must be set to true if lte_sig_info is being passed */
  nas_lte_sig_info_type_v01 lte_sig_info;

  /* Optional */
  /*  TDSCDMA Signal Strength Info */
  uint8_t rscp_valid;  /**< Must be set to true if rscp is being passed */
  int8_t rscp;
  /**<  
    RSCP of the PCCPCH in dBm. 
    Measurement range: -120 dBm to -25 dBm. 
   */
}nas_sig_info_ind_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_err_rate_req_msg is empty
 * typedef struct {
 * }nas_get_err_rate_req_msg_v01;
 */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Queries the current error rate information. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */

  /* Optional */
  /*  CDMA Frame Error Rate */
  uint8_t cdma_frame_err_rate_valid;  /**< Must be set to true if cdma_frame_err_rate is being passed */
  uint16_t cdma_frame_err_rate;
  /**<  
      Valid error rate values between 1 and 10000 are returned to 
      indicate the percentage, e.g., a value of 300 means the error rate is 3%. 
      A value of 0xFFFF indicates that the error rate is unknown/unavailable.
   */

  /* Optional */
  /*  HDR Packet Error Rate */
  uint8_t hdr_packet_err_rate_valid;  /**< Must be set to true if hdr_packet_err_rate is being passed */
  uint16_t hdr_packet_err_rate;
  /**<  
      Valid error rate values between 1 and 10000 are returned to 
      indicate the percentage, e.g., a value of 300 means the error rate is 3%. 
      A value of 0xFFFF indicates that the error rate is unknown/unavailable. 
   */

  /* Optional */
  /*  GSM Bit Error Rate */
  uint8_t gsm_bit_err_rate_valid;  /**< Must be set to true if gsm_bit_err_rate is being passed */
  uint8_t gsm_bit_err_rate;
  /**<  
      GSM bit error rate represented as an RxQual metric as defined in 
      [S13, Section 8.2.4]. Valid values: 0 to 7. 
      A value of 0xFF indicates No Data.    
   */

  /* Optional */
  /*  WCDMA Block Error Rate */
  uint8_t wcdma_block_err_rate_valid;  /**< Must be set to true if wcdma_block_err_rate is being passed */
  uint8_t wcdma_block_err_rate;
  /**<  
      Valid error rate values between 1 and 100 are returned to 
      indicate the percentage value. A value of 0xFF indicates
      that the error rate is unknown/unavailable.
   */

  /* Optional */
  /*  TDSCDMA Block Error Rate */
  uint8_t tdscdma_block_err_rate_valid;  /**< Must be set to true if tdscdma_block_err_rate is being passed */
  uint8_t tdscdma_block_err_rate;
  /**<  
      Valid error rate values between 1 and 100 are returned to 
      indicate the percentage value. A value of 0xFF indicates
      that the error rate is unknown/unavailable.
   */
}nas_get_err_rate_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Indication Message; Provides RAT-specific error rate information.
             \label{idl:errRateInd} */
typedef struct {

  /* Optional */
  /*  CDMA Frame Error Rate */
  uint8_t cdma_frame_err_rate_valid;  /**< Must be set to true if cdma_frame_err_rate is being passed */
  uint16_t cdma_frame_err_rate;
  /**<  
      Valid error rate values between 1 and 10000 are returned to 
      indicate the percentage, e.g., a value of 300 means the error rate is 3%. 
      A value of 0xFFFF indicates that the error rate is unknown/unavailable.
   */

  /* Optional */
  /*  HDR Packet Error Rate */
  uint8_t hdr_packet_err_rate_valid;  /**< Must be set to true if hdr_packet_err_rate is being passed */
  uint16_t hdr_packet_err_rate;
  /**<  
      Valid error rate values between 1 and 10000 are returned to 
      indicate the percentage, e.g., a value of 300 means the error rate is 3%. 
      A value of 0xFFFF indicates that the error rate is unknown/unavailable.
   */

  /* Optional */
  /*  GSM Bit Error Rate */
  uint8_t gsm_bit_err_rate_valid;  /**< Must be set to true if gsm_bit_err_rate is being passed */
  uint8_t gsm_bit_err_rate;
  /**<  
      GSM bit error rate represented as an RxQual metric as defined in 
      [S13, Section 8.2.4]. Valid values: 0 to 7. 
      A value of 0xFF indicates No Data.
   */

  /* Optional */
  /*  WCDMA Block Error Rate */
  uint8_t wcdma_block_err_rate_valid;  /**< Must be set to true if wcdma_block_err_rate is being passed */
  uint8_t wcdma_block_err_rate;
  /**<  
      Valid error rate values between 1 and 100 are returned to 
      indicate the percentage value. A value of 0xFF indicates
      that the error rate is unknown/unavailable.
   */

  /* Optional */
  /*  TDSCDMA Block Error Rate */
  uint8_t tdscdma_block_err_rate_valid;  /**< Must be set to true if tdscdma_block_err_rate is being passed */
  uint8_t tdscdma_block_err_rate;
  /**<  
      Valid error rate values between 1 and 100 are returned to 
      indicate the percentage value. A value of 0xFF indicates
      that the error rate is unknown/unavailable.
   */
}nas_err_rate_ind_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_HDR_SESSION_CLOSE_REASON_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_HDR_CLOSE_REASON_NEW_NETWORK_V01 = 0x00, 
  NAS_HDR_CLOSE_REASON_UATI_FAIL_V01 = 0x01, 
  NAS_HDR_CLOSE_REASON_KA_EXP_V01 = 0x02, 
  NAS_HDR_CLOSE_REASON_DEACTIVATE_V01 = 0x03, 
  NAS_HDR_CLOSE_REASON_REPLY_V01 = 0x04, 
  NAS_HDR_CLOSE_REASON_CONN_OPEN_FAIL_V01 = 0x05, 
  NAS_HDR_CLOSE_REASON_CFG_MSG_FAIL_V01 = 0x06, 
  NAS_HDR_CLOSE_REASON_CFG_RSP_EXP_V01 = 0x07, 
  NAS_HDR_CLOSE_REASON_PROT_NEG_FAIL_V01 = 0x08, 
  NAS_HDR_CLOSE_REASON_AN_INIT_EXP_V01 = 0x09, 
  NAS_HDR_CLOSE_REASON_QUICK_FAILURE_V01 = 0x0A, 
  NAS_HDR_CLOSE_REASON_CONN_OPEN_DENY_V01 = 0x0B, 
  NAS_HDR_CLOSE_REASON_SILENT_DEACTIVATE_V01 = 0x0C, 
  NAS_HDR_CLOSE_REASON_NEW_ESN_V01 = 0x0D, 
  NAS_HDR_CLOSE_REASON_AN_GAUP_FAIL_V01 = 0x0E, 
  NAS_HDR_CLOSE_REASON_PERSONALITY_INDEX_INVALID_V01 = 0x0F, 
  NAS_HDR_CLOSE_REASON_NOT_MAINT_UATI_V01 = 0x10, 
  NAS_HDR_CLOSE_REASON_NEW_NAI_V01 = 0x11, 
  NAS_HDR_CLOSE_REASON_EHRPD_CREDENTIALS_CHANGED_V01 = 0x12, 
  NAS_HDR_SESSION_CLOSE_REASON_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_hdr_session_close_reason_type_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Indication Message; Indicates when an HDR session has closed and returns a 
               close reason. */
typedef struct {

  /* Mandatory */
  /*  HDR Session Close Reason */
  nas_hdr_session_close_reason_type_v01 close_reason;
  /**<   HDR session close reason. Values: \n
       - 0x00 -- NAS_HDR_CLOSE_REASON_NEW_ NETWORK -- 
         AMP failure: reacquired on a new network \n
       - 0x01 -- NAS_HDR_CLOSE_REASON_UATI_FAIL -- 
         AMP failure: timed out five times waiting for a UATI response \n
       - 0x02 -- NAS_HDR_CLOSE_REASON_KA_EXP -- 
         KeepAliveTimer was not reset for TsmpClose minutes \n
       - 0x03 -- NAS_HDR_CLOSE_REASON_DEACTIVATE -- 
         Internal deactivation \n
       - 0x04 -- NAS_HDR_CLOSE_REASON_REPLY -- 
         Received a session close message from the AN \n
       - 0x05 -- NAS_HDR_CLOSE_REASON_CONN_OPEN_ FAIL -- 
         Failed to establish a connection five times to send a session 
         configuration message \n
       - 0x06 -- NAS_HDR_CLOSE_REASON_CFG_MSG_ FAIL -- 
         In ATInit: could not send a configuration message \n
       - 0x07 -- NAS_HDR_CLOSE_REASON_CFG_RSP_EXP -- 
         In ATInit: timed out waiting for a configuration response \n
       - 0x08 -- NAS_HDR_CLOSE_REASON_PROT_NEG_ FAIL -- 
         In ATInit: bad configuration response from the AN \n
       - 0x09 -- NAS_HDR_CLOSE_REASON_AN_INIT_EXP -- 
         In ATInit: AN initialization setup timer expired \n
       - 0x0A -- NAS_HDR_CLOSE_REASON_QUICK_ FAILURE -- 
         In ATInit: connection closed in the AN initialization \n
       - 0x0B -- NAS_HDR_CLOSE_REASON_CONN_OPEN_ DENY -- 
         Failed to establish a connection five times for sending a configuration 
         message; received a connection deny at least once from the network \n
       - 0x0C -- NAS_HDR_CLOSE_REASON_SILENT_ DEACTIVATE -- 
         Internal silent deactivation \n
       - 0x0D -- NAS_HDR_CLOSE_REASON_NEW_ESN -- 
         AMP failure: phone ESN is different from the ESN associated with the 
         current session \n
       - 0x0E -- NAS_HDR_CLOSE_REASON_AN_GAUP_ FAIL -- 
         AT rejected an AN GAUP message \n
       - 0x0F -- NAS_HDR_CLOSE_REASON_ PERSONALITY_INDEX_INVALID -- 
         AN included an invalid personality index in the SoftCC message \n
       - 0x10 -- NAS_HDR_CLOSE_REASON_NOT_MAINT_ UATI -- 
         AMP: session was closed due to not maintaining the UATI \n
       - 0x11 -- NAS_HDR_CLOSE_REASON_NEW_NAI -- 
         Phone NAI is different from the NAI associated with the current session \n
       - 0x12 -- NAS_HDR_CLOSE_REASON_EHRPD_ CREDENTIALS_CHANGED -- 
         eHRPD credentials (IMSI, EAP-AKA, or OP) have changed
    */
}nas_hdr_session_close_ind_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Indication Message; Indicates when an HDR unique access terminal identifier has been 
             updated and returns its new value. */
typedef struct {

  /* Mandatory */
  /*  HDR UATI */
  uint8_t uati[QMI_NAS_UATI_LENGTH_V01];
  /**<  
      A 128-bit address that includes the access terminal identifier 
      and subnet ID.
     */
}nas_hdr_uati_update_ind_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Retrieves the current HDR protocol subtype. */
typedef struct {

  /* Mandatory */
  /*  Protocol */
  uint32_t protocol;
  /**<   HDR protocol for which the subtype is requested (see [S15, Table 2.5.4-1])
   */
}nas_get_hdr_subtype_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Retrieves the current HDR protocol subtype. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */

  /* Optional */
  /*  Protocol Subtype */
  uint8_t subtype_valid;  /**< Must be set to true if subtype is being passed */
  uint16_t subtype;
  /**<   Current HDR protocol subtype (see [S15, Table 6.4.7.1-1]). Values: \n
       - 0x0000 -- Default \n
       - 0x0000 to 0XFFFD -- Protocol subtypes \n
       - 0xFFFE -- Hardlink \n
       - 0xFFFF -- Indicates that the input protocol ID is not valid
   */
}nas_get_hdr_subtype_resp_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_hdr_color_code_req_msg is empty
 * typedef struct {
 * }nas_get_hdr_color_code_req_msg_v01;
 */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Retrieves the HDR color code value. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */

  /* Optional */
  /*  Color Code Value */
  uint8_t color_code_valid;  /**< Must be set to true if color_code is being passed */
  uint8_t color_code;
  /**<   Color code corresponding to the sector to which the AT is sending the 
       access probe (see [S15, Section 7.11.6.2.1]).
   */
}nas_get_hdr_color_code_resp_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_current_acq_sys_mode_req_msg is empty
 * typedef struct {
 * }nas_get_current_acq_sys_mode_req_msg_v01;
 */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_SYS_MODE_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_SYS_MODE_NO_SERVICE_V01 = 0x00, 
  NAS_SYS_MODE_ACQUIRING_V01 = 0x01, 
  NAS_SYS_MODE_INSERVICE_V01 = 0x02, 
  NAS_SYS_MODE_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_sys_mode_type_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Retrieves the current acquisition system mode.(deprecated) */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */

  /* Optional */
  /*  Current System Mode for CDMA 1X */
  uint8_t cdma_valid;  /**< Must be set to true if cdma is being passed */
  nas_sys_mode_type_v01 cdma;
  /**<   Radio interface system mode. Values: \n
       - 0x00 -- NAS_SYS_MODE_NO_SERVICE -- No service \n
       - 0x01 -- NAS_SYS_MODE_ACQUIRING  -- Acquiring service \n
       - 0x02 -- NAS_SYS_MODE_INSERVICE  -- In service
    */

  /* Optional */
  /*  Current System Mode for CDMA 1xEV-DO */
  uint8_t cdma_evdo_valid;  /**< Must be set to true if cdma_evdo is being passed */
  nas_sys_mode_type_v01 cdma_evdo;
  /**<   Radio interface system mode. Values: \n
       - 0x00 -- NAS_SYS_MODE_NO_SERVICE -- No service \n
       - 0x01 -- NAS_SYS_MODE_ACQUIRING  -- Acquiring service \n
       - 0x02 -- NAS_SYS_MODE_INSERVICE  -- In service
    */

  /* Optional */
  /*  Current System Mode for GSM */
  uint8_t gsm_valid;  /**< Must be set to true if gsm is being passed */
  nas_sys_mode_type_v01 gsm;
  /**<   Radio interface system mode. Values: \n
       - 0x00 -- NAS_SYS_MODE_NO_SERVICE -- No service \n
       - 0x01 -- NAS_SYS_MODE_ACQUIRING  -- Acquiring service \n
       - 0x02 -- NAS_SYS_MODE_INSERVICE  -- In service
    */

  /* Optional */
  /*  Current System Mode for UMTS */
  uint8_t umts_valid;  /**< Must be set to true if umts is being passed */
  nas_sys_mode_type_v01 umts;
  /**<   Radio interface system mode. Values: \n
       - 0x00 -- NAS_SYS_MODE_NO_SERVICE -- No service \n
       - 0x01 -- NAS_SYS_MODE_ACQUIRING  -- Acquiring service \n
       - 0x02 -- NAS_SYS_MODE_INSERVICE  -- In service
    */

  /* Optional */
  /*  Current System Mode for LTE */
  uint8_t lte_valid;  /**< Must be set to true if lte is being passed */
  nas_sys_mode_type_v01 lte;
  /**<   Radio interface system mode. Values: \n
       - 0x00 -- NAS_SYS_MODE_NO_SERVICE -- No service \n
       - 0x01 -- NAS_SYS_MODE_ACQUIRING  -- Acquiring service \n
       - 0x02 -- NAS_SYS_MODE_INSERVICE  -- In service
    */

  /* Optional */
  /*  Current System Mode for TDSCDMA */
  uint8_t tdscdma_valid;  /**< Must be set to true if tdscdma is being passed */
  nas_sys_mode_type_v01 tdscdma;
  /**<   Radio interface system mode. Values: \n
       - 0x00 -- NAS_SYS_MODE_NO_SERVICE -- No service \n
       - 0x01 -- NAS_SYS_MODE_ACQUIRING  -- Acquiring service \n
       - 0x02 -- NAS_SYS_MODE_INSERVICE  -- In service
    */
}nas_get_current_acq_sys_mode_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Radio interface */
  nas_radio_if_enum_v01 radio_if;
  /**<   Radio interface for which to set the Rx diversity. Values: \n
    - 0x01 -- NAS_RADIO_IF_CDMA_1X     -- cdma2000 1X \n
    - 0x02 -- NAS_RADIO_IF_CDMA_1XEVDO -- cdma2000 HRPD (1xEV-DO) \n
    - 0x04 -- NAS_RADIO_IF_GSM         -- GSM \n
    - 0x05 -- NAS_RADIO_IF_UMTS        -- UMTS \n
    - 0x08 -- NAS_RADIO_IF_LTE         -- LTE
    */

  /*  Rx chain setting bitmask */
  uint8_t rx_chain_bitmask;
  /**<   Rx chain setting bitmask. Values: \n
    - Bit 0 -- Rx chain 0 setting; 0 is disable, 1 is enable \n
    - Bit 1 -- Rx chain 1 setting; 0 is disable, 1 is enable \n
    - All other bits are set to zero
    */
}nas_set_rx_diversity_req_param_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Sets the Rx diversity. */
typedef struct {

  /* Mandatory */
  /*  Rx Diversity Setting */
  nas_set_rx_diversity_req_param_type_v01 req_param;
}nas_set_rx_diversity_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Sets the Rx diversity. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_set_rx_diversity_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Retrieves the detailed Tx/Rx information. */
typedef struct {

  /* Mandatory */
  /*  Radio Interface */
  nas_radio_if_enum_v01 radio_if;
  /**<  
    Radio interface from which to get the information. Values: \n
    - 0x01 -- NAS_RADIO_IF_CDMA_1X     -- cdma2000 1X \n
    - 0x02 -- NAS_RADIO_IF_CDMA_1XEVDO -- cdma2000 HRPD (1xEV-DO) \n
    - 0x04 -- NAS_RADIO_IF_GSM         -- GSM \n
    - 0x05 -- NAS_RADIO_IF_UMTS        -- UMTS \n
    - 0x08 -- NAS_RADIO_IF_LTE         -- LTE
    */
}nas_get_tx_rx_info_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t is_radio_tuned;
  /**<   Whether Rx is tuned to a channel: \n
       - 0x00 -- Not tuned \n
       - 0x01 -- Tuned \n
       If the radio is tuned, instantaneous values are set for the signal 
       information fields below. If the radio is not tuned, or is delayed or 
       invalid, the values are set depending on each technology.
    */

  int32_t rx_pwr;
  /**<   Rx power value in 1/10 dbm resolution.  */

  int32_t ecio;
  /**<   ECIO in 1/10 dbm; valid for CDMA, HDR, GSM, WCDMA, and LTE.  */

  int32_t rscp;
  /**<   Received signal code power in 1/10 dbm; valid for WCDMA.  */

  int32_t rsrp;
  /**<   Current reference signal received power in 1/10 dbm; valid for LTE.  */

  uint32_t phase;
  /**<   Phase in 1/100 degrees; valid for LTE. When the phase is unknown, 
       0xFFFFFFFF is used. 
   */
}nas_rx_chain_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t is_in_traffic;
  /**<   Whether the device is in traffic. The tx_pwr field is only 
       meaningful when in the device is in traffic. If it is not in traffic, 
       tx_pwr is invalid.
    */

  int32_t tx_pwr;
  /**<   Tx power value in 1/10 dbm.  */
}nas_tx_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Retrieves the detailed Tx/Rx information. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */

  /* Optional */
  /*  Rx Chain 0 Info */
  uint8_t rx_chain_0_valid;  /**< Must be set to true if rx_chain_0 is being passed */
  nas_rx_chain_info_type_v01 rx_chain_0;

  /* Optional */
  /*  Rx Chain 1 Info */
  uint8_t rx_chain_1_valid;  /**< Must be set to true if rx_chain_1 is being passed */
  nas_rx_chain_info_type_v01 rx_chain_1;

  /* Optional */
  /*  Tx Info */
  uint8_t tx_valid;  /**< Must be set to true if tx is being passed */
  nas_tx_info_type_v01 tx;
}nas_get_tx_rx_info_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  Service Programming Code */
  char spc[NAS_SPC_MAX_V01];
  /**<   Service programming code in ASCII format (digits 0 to 9 only).
   */

  /*  AKEY */
  uint8_t akey[QMI_NAS_AKEY_LEN_V01];
  /**<   AKEY value + checksum value in ASCII (first 20 bytes are the AKEY value,
       last 6 bytes are the checksum).
   */
}nas_akey_with_spc_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Updates the A-KEY (extended).
              \label{idl:updateAkeyExt} */
typedef struct {

  /* Mandatory */
  /*  AKEY with SPC */
  nas_akey_with_spc_type_v01 akey_with_spc;
}nas_update_akey_ext_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Updates the A-KEY (extended).
              \label{idl:updateAkeyExt} */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_update_akey_ext_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Indication Message; Indicates whether managed roaming is enabled. */
typedef struct {

  /* Optional */
  /*  Radio Interface */
  uint8_t radio_if_valid;  /**< Must be set to true if radio_if is being passed */
  nas_radio_if_enum_v01 radio_if;
  /**<  
    Radio interface from which to get the information. Values: \n
    - 0x01 -- NAS_RADIO_IF_CDMA_1X     -- cdma2000 1X \n
    - 0x02 -- NAS_RADIO_IF_CDMA_1XEVDO -- cdma2000 HRPD (1xEV-DO) \n
    - 0x04 -- NAS_RADIO_IF_GSM         -- GSM \n
    - 0x05 -- NAS_RADIO_IF_UMTS        -- UMTS \n
    - 0x08 -- NAS_RADIO_IF_LTE         -- LTE \n
    - 0x09 -- NAS_RADIO_IF_TDSCDMA     -- TD-SCDMA
    */
}nas_managed_roaming_ind_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_dual_standby_pref_req_msg is empty
 * typedef struct {
 * }nas_get_dual_standby_pref_req_msg_v01;
 */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Retrieves dual standby preference. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */

  /* Optional */
  /*  Standby Preference */
  uint8_t standby_pref_valid;  /**< Must be set to true if standby_pref is being passed */
  nas_standby_pref_enum_v01 standby_pref;
  /**<   Values: \n
       -0x01 -- Single standby \n
       -0x02 -- Dual standby with tune away \n
       -0x04 -- Dual standby without tune away \n
       -0x05 -- Automatic mode with tune away where applicable \n
       -0x06 -- Automatic mode without tune away
   */

  /* Optional */
  /*  Priority Subs */
  uint8_t priority_subs_valid;  /**< Must be set to true if priority_subs is being passed */
  nas_subs_type_enum_v01 priority_subs;
  /**<  
        Subscription to give priority when listening to the paging channel during
        dual standby. Values: \n
        -0x00 -- Primary subscription \n
        -0x01 -- Secondary subscription
   */

  /* Optional */
  /*  Active Subs */
  uint8_t active_subs_valid;  /**< Must be set to true if active_subs is being passed */
  nas_subs_type_enum_v01 active_subs;
  /**<  
        Subscription to enable when "standby_pref is 0x01 -- Single standby". 
        Values: \n
        -0x00 -- Primary subscription \n
        -0x01 -- Secondary subscription
   */

  /* Optional */
  /*  Default Data Subs */
  uint8_t default_data_subs_valid;  /**< Must be set to true if default_data_subs is being passed */
  nas_subs_type_enum_v01 default_data_subs;
  /**<  
        Default data subscription. Values: \n
        -0x00 -- Primary subscription \n
        -0x01 -- Secondary subscription
   */
}nas_get_dual_standby_pref_resp_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_detach_lte_req_msg is empty
 * typedef struct {
 * }nas_detach_lte_req_msg_v01;
 */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Detaches the current LTE system. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_detach_lte_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  MCC */
  uint16_t mcc;
  /**<   A 16-bit integer representation of MCC. Range: 0 to 999.
   */

  /*  MNC */
  uint16_t mnc;
  /**<   A 16-bit integer representation of MNC. Range: 0 to 999.
   */

  /*  MNC PCS digit include status */
  uint8_t mnc_includes_pcs_digit;
  /**<   This field is used to interpret the length of the corresponding
       MNC reported in this TLV. Values: \n

       - TRUE  -- MNC is a three-digit value; e.g., a reported value of 
                  90 corresponds to an MNC value of 090  \n
       - FALSE -- MNC is a two-digit value; e.g., a reported value of 
                  90 corresponds to an MNC value of 90
     */
}nas_plmn_id_ext_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Blocks the LTE PLMN. */
typedef struct {

  /* Mandatory */
  /*  PLMN */
  nas_plmn_id_ext_type_v01 plmn;

  /* Optional */
  /*  Blocking Interval Absolute Time */
  uint8_t blocking_interval_abs_valid;  /**< Must be set to true if blocking_interval_abs is being passed */
  uint32_t blocking_interval_abs;
  /**<   Blocking interval in absolute time (in milliseconds).
   */

  /* Optional */
  /*  Blocking Interval T3204 Multiplier */
  uint8_t blocking_interval_mult_valid;  /**< Must be set to true if blocking_interval_mult is being passed */
  float blocking_interval_mult;
  /**<   Blocking time as a multiplier of T3204.
   */
}nas_block_lte_plmn_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Blocks the LTE PLMN. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_block_lte_plmn_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Unblocks the LTE PLMN. */
typedef struct {

  /* Mandatory */
  /*  PLMN */
  nas_plmn_id_ext_type_v01 plmn;
}nas_unblock_lte_plmn_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Unblocks the LTE PLMN. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_unblock_lte_plmn_resp_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_reset_lte_plmn_blocking_req_msg is empty
 * typedef struct {
 * }nas_reset_lte_plmn_blocking_req_msg_v01;
 */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Resets all previous LTE PLMN blocking operations. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_reset_lte_plmn_blocking_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  SPN coding scheme */
  nas_coding_scheme_enum_v01 spn_enc;
  /**<  
        Coding scheme for the service provider name. Values: \n
        - 0x00 -- NAS_CODING_SCHEME_CELL_ BROADCAST_GSM -- SMS default 7-bit coded 
                  alphabet as defined in [S8] with bit 8 set to 0 \n
        - 0x01 -- NAS_CODING_SCHEME_UCS2 -- UCS2 (16 bit, little-endian) [S8] \n
        Note: This value is ignored if spn_len is zero.
   */

  /*  SPN */
  uint32_t spn_len;  /**< Must be set to # of elements in spn */
  uint8_t spn[NAS_SPN_LEN_MAX_V01];
  /**<  
     Service provider name string.
   */
}nas_spn_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  /*  PLMN name encoding scheme */
  nas_coding_scheme_enum_v01 plmn_name_enc;
  /**<  
        Coding scheme for plmn_name. Values: \n
        - 0x00 -- NAS_CODING_SCHEME_CELL_ BROADCAST_GSM -- SMS default 7-bit coded 
                  alphabet as defined in [S8] with bit 8 set to 0 \n
        - 0x01 -- NAS_CODING_SCHEME_UCS2 -- UCS2 (16 bit, little-endian) [S8] \n
        Note: This value is ignored if plmn_name_len is zero.
   */

  /*  PLMN name country initial include status */
  nas_country_initials_add_enum_v01 plmn_name_ci;
  /**<  
        Indicates whether the country initials are to be added to the plmn_name. 
        Values: \n
        - 0x00 -- Do not add the letters for the country's initials to the name \n
        - 0x01 -- Add the country's initials and a text string to the name \n
        - 0xFF -- Not specified \n
        Note: This value is ignored if plmn_name_len is zero.
   */

  /*  PLMN spare bits  */
  nas_spare_bits_enum_v01 plmn_spare_bits;
  /**<   Values: \n
       - 0x01 -- SPARE_BITS_8       -- Bit 8 is spare and set to 0 in octet n                       \n
       - 0x02 -- SPARE_BITS_7_TO_8  -- Bits 7 and 8 are spare and set to 0 in octet n               \n               
       - 0x03 -- SPARE_BITS_6_TO_8  -- Bits 6 to 8 (inclusive) are spare and set to 0 in octet n    \n
       - 0x04 -- SPARE_BITS_5_TO_8  -- Bits 5 to 8 (inclusive) are spare and set to 0 in octet n    \n
       - 0x05 -- SPARE_BITS_4_TO_8  -- Bits 4 to 8 (inclusive) are spare and set to 0 in octet n    \n
       - 0x06 -- SPARE_BITS_3_TO_8  -- Bits 3 to 8 (inclusive) are spare and set to 0 in octet n    \n
       - 0x07 -- SPARE_BITS_2_TO_8  -- Bits 2 to 8 (inclusive) are spare and set to 0 in octet n    \n
       - 0x00 -- SPARE_BITS_UNKNOWN -- Carries no information about the number of spare bits in octet n    \n
       Note: This value is ignored if plmn_name_len is zero.
   */

  uint32_t plmn_name_len;  /**< Must be set to # of elements in plmn_name */
  uint8_t plmn_name[NAS_PLMN_NAME_MAX_V01];
  /**<   PLMN name.
   */
}nas_plmn_name_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Indication Message; Indicates the current SPN and PLMN name information. */
typedef struct {

  /* Optional */
  /*  PLMN ID */
  uint8_t plmn_id_valid;  /**< Must be set to true if plmn_id is being passed */
  nas_plmn_id_ext_type_v01 plmn_id;

  /* Optional */
  /*  Service Provider Name */
  uint8_t spn_valid;  /**< Must be set to true if spn is being passed */
  nas_spn_type_v01 spn;

  /* Optional */
  /*  Short Name for Network */
  uint8_t short_name_valid;  /**< Must be set to true if short_name is being passed */
  nas_plmn_name_type_v01 short_name;

  /* Optional */
  /*  Long Name for Network */
  uint8_t long_name_valid;  /**< Must be set to true if long_name is being passed */
  nas_plmn_name_type_v01 long_name;
}nas_current_plmn_name_ind_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Requests the UE to enable/disable eMBMS. */
typedef struct {

  /* Mandatory */
  /*  Config Request */
  uint8_t enable;
  /**<   Enable/disable eMBMS. Values: \n
       - TRUE  -- Enable \n
       - FALSE -- Disable
   */
}nas_config_embms_req_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Requests the UE to enable/disable eMBMS. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type. */
}nas_config_embms_resp_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_embms_status_req_msg is empty
 * typedef struct {
 * }nas_get_embms_status_req_msg_v01;
 */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Queries the eMBMS status. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type. */

  /* Optional */
  /*  eMBMS Status */
  uint8_t enabled_valid;  /**< Must be set to true if enabled is being passed */
  uint8_t enabled;
  /**<   eMBMS status. Values: \n
       - TRUE  -- Enabled \n
       - FALSE -- Disabled
   */
}nas_get_embms_status_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Indication Message; Reports the UE's current eMBMS status change. */
typedef struct {

  /* Mandatory */
  /*  eMBMS Status */
  uint8_t enabled;
  /**<   eMBMS status. Values: \n
       - TRUE  -- Enabled \n
       - FALSE -- Disabled
   */
}nas_embms_status_ind_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_cdma_position_info_req_msg is empty
 * typedef struct {
 * }nas_get_cdma_position_info_req_msg_v01;
 */

/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum {
  NAS_CDMA_PILOT_TYPE_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_CDMA_PILOT_CURR_ACT_PLT_V01 = 0x00, 
  NAS_CDMA_PILOT_NEIGHBOR_PLT_V01 = 0x01, 
  NAS_CDMA_PILOT_TYPE_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_cdma_pilot_type_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  nas_cdma_pilot_type_enum_v01 pilot_type;
  /**<   Pilot information type. Values: \n
       - 0x00 -- NAS_CDMA_PILOT_CURR_ACT_PLT -- Current active pilot information \n
       - 0x01 -- NAS_CDMA_PILOT_NEIGHBOR_PLT -- Neighbor pilot information
    */

  uint16_t sid;
  /**<   System ID. Range: 0 to 32767. 
    */

  uint16_t nid;
  /**<   Network ID. Range: 0 to 65535.
   */

  uint16_t base_id;
  /**<   Base station ID.  */

  uint16_t pilot_pn;
  /**<   Pilot PN sequence offset index. Range: 0 to 511.
   */

  uint16_t pilot_strength;
  /**<   Strength of the pilot (in dB). Range: 0 to 64.
   */

  uint32_t base_lat;
  /**<   Latitude of the current base station in units of 0.25 sec.
    */

  uint32_t base_long;
  /**<   Longitude of the current base station in units of 0.25 sec.
    */

  uint64_t time_stamp;
  /**<   Time (in milliseconds) from the start of GPS time when the measurement 
       was taken.
    */
}nas_cdma_bs_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint8_t ue_in_idle;
  /**<   CDMA Idle state. TRUE if the UE is in Idle mode; otherwise FALSE.
    */

  /*  CDMA base station info */
  uint32_t bs_len;  /**< Must be set to # of elements in bs */
  nas_cdma_bs_info_type_v01 bs[NAS_CDMA_POSITION_INFO_MAX_V01];
}nas_cdma_position_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Queries the current CDMA base station position information for
              active and neighbor's position information. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type. */

  /* Optional */
  /*  CDMA Position Info */
  uint8_t info_valid;  /**< Must be set to true if info is being passed */
  nas_cdma_position_info_type_v01 info;
}nas_get_cdma_position_info_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Indication Message; Reports current RF band information. */
typedef struct {

  /* Mandatory */
  /*  RF Band Information */
  nas_rf_band_info_type_v01 rf_band_info;
}nas_rf_band_info_ind_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_force_network_search_req_msg is empty
 * typedef struct {
 * }nas_force_network_search_req_msg_v01;
 */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Forces a network search procedure. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type. */
}nas_force_network_search_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Indication Message; Reports network reject information. */
typedef struct {

  /* Mandatory */
  /*  Radio Interface */
  nas_radio_if_enum_v01 radio_if;
  /**<  
    Radio interface from which to get the information. Values: \n
    - 0x04 -- NAS_RADIO_IF_GSM         -- GSM \n
    - 0x05 -- NAS_RADIO_IF_UMTS        -- UMTS \n
    - 0x08 -- NAS_RADIO_IF_LTE         -- LTE \n
    - 0x09 -- NAS_RADIO_IF_TDSCDMA     -- TD-SCDMA
    */

  /* Mandatory */
  /*  Service Domain */
  nas_service_domain_enum_type_v01 reject_srv_domain;
  /**<  
      Type of service domain in which the registration is rejected. Values: \n
      - 0x00 -- SYS_SRV_DOMAIN_NO_SRV  -- No service \n
      - 0x01 -- SYS_SRV_DOMAIN_CS_ONLY -- Circuit-switched only \n
      - 0x02 -- SYS_SRV_DOMAIN_PS_ONLY -- Packet-switched only \n
      - 0x03 -- SYS_SRV_DOMAIN_CS_PS   -- Circuit-switched and packet-switched \n
      - 0x04 -- SYS_SRV_DOMAIN_CAMPED  -- Camped
       */

  /* Mandatory */
  /*  Registration Rejection Cause */
  uint8_t rej_cause;
  /**<  
    Reject cause values sent are specified in 
    [S5, Sections 10.5.3.6 and 10.5.5.14] and [S16, Section 9.9.3.9].
   */
}nas_network_reject_ind_msg_v01;  /* Message */
/**
    @}
  */

/*
 * nas_get_managed_roaming_config_req_msg is empty
 * typedef struct {
 * }nas_get_managed_roaming_config_req_msg_v01;
 */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Queries the current managed roaming configuration information */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type. */

  /* Optional */
  /*  Managed Roaming Configuration */
  uint8_t managed_roaming_supported_valid;  /**< Must be set to true if managed_roaming_supported is being passed */
  uint8_t managed_roaming_supported;
  /**<   Managed roaming support status (Corresponds to NV item 
    NV_MGRF_SUPPORTED_I)
       - 0 -- Not supported
       - 1 -- Supported
   */
}nas_get_managed_roaming_config_resp_msg_v01;  /* Message */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Indication Message; Report change in RTRE configuration status  */
typedef struct {

  /* Optional */
  /*  Current RTRE Configuration */
  uint8_t rtre_cfg_valid;  /**< Must be set to true if rtre_cfg is being passed */
  nas_rtre_cfg_enum_v01 rtre_cfg;
  /**<   Values: 
       -0x01 -- R-UIM only 
       -0x02 -- Internal settings only 
       -0x04 -- GSM on 1X
   */

  /* Optional */
  /*  RTRE Configuration Preference */
  uint8_t rtre_cfg_pref_valid;  /**< Must be set to true if rtre_cfg_pref is being passed */
  nas_rtre_cfg_enum_v01 rtre_cfg_pref;
  /**<   Values: 
       -0x01 -- R-UIM only 
       -0x02 -- Internal settings only 
       -0x03 -- Use R-UIM if available 
       -0x04 -- GSM on 1X
   */
}nas_rtre_cfg_ind_msg_v01;  /* Message */
/**
    @}
  */

#ifdef FEATURE_P_VZW_CS_NAM_SEL
/** @addtogroup nas_qmi_enums
    @{
  */
typedef enum{
  NAS_NAM_SEL_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_NAM_SEL_CM_NAM_1 = 0x00,
  NAS_NAM_SEL_CM_NAM_2 = 0x01,
  NAS_NAM_SEL_CM_NAM_3 = 0x02,
  NAS_NAM_SEL_CM_NAM_4 = 0x03,
  NAS_NAM_SEL_CM_NAM_AUTO = 0x04,
  NAS_NAM_SEL_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
} nas_nam_sel_enum_v01;
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
typedef struct {

  /* Optional */
  uint8_t nam_sel_valid;  /**< Must be set to true if nam_sel is being passed */
  
  /*  NAM selection */
  nas_nam_sel_enum_v01 nam_sel;
  /**<
    - NAS_NAM_SEL_CM_NAM_1    -- NAM 1
    - NAS_NAM_SEL_CM_NAM_2    -- NAM 2
    - NAS_NAM_SEL_CM_NAM_3    -- NAM 3
    - NAS_NAM_SEL_CM_NAM_4    -- NAM 4
    - NAS_NAM_SEL_CM_NAM_AUTO -- AUTO NAM
    */
}nas_nam_sel_req_msg_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; NAM selection */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */
}nas_nam_sel_resp_msg_v01;  /* Message */
/**
    @}
  */
#endif /* FEATURE_P_VZW_CS_NAM_SEL */

#ifdef FEATURE_P_VZW_CS_SYSTEM_SELECTION
/*
 * nas_get_prl_pref_only_req_msg is empty
 * typedef struct {
 * }nas_get_prl_pref_only_req_msg_v01;
 */

/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Retrieves the PRL's prl_pref only setting. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type.  */

  /* Optional */
  /*  Indicates the PRL's prl_pref only setting */
  uint8_t prl_pref_only_valid;  /**< Must be set to true if prl_pref_only is being passed */
  uint8_t prl_pref_only;
}nas_get_prl_pref_only_resp_msg_v01;  /* Message */
/**
    @}
  */
#endif /* FEATURE_P_VZW_CS_SYSTEM_SELECTION */

#ifdef FEATURE_P_VZW_CS_AUTH_REJ_DISPLAY
/*---------------------------------------------------------------------------
  QMI_NAS_LOCK_UNTIL_POWER_CYCLED_IND_V01
---------------------------------------------------------------------------*/
#define NAS_LUPC_IND_T10      (0x10)
#define NAS_LUPC_IND_T11      (0x11)

typedef enum {
  QMI_NAS_LOCK_REASON_NONE = 0,
  QMI_NAS_LOCK_REASON_REG_FAIL,
  QMI_NAS_LOCK_REASON_AUTH_FAIL,
  QMI_NAS_LOCK_REASON_MAX
}qmi_nas_lock_reason_enum_v01;

typedef struct
{
  /* Optional */
  /*  Lock Order */
  uint8_t lock_order_valid;  /**< Must be set to true if lock_order is being passed */
  uint8_t lock_order;

  /* Optional */
  /*  Lock Reason */
  uint8_t lock_reason_valid;  /**< Must be set to true if lock_reason is being passed */
  qmi_nas_lock_reason_enum_v01 lock_reason;
}nas_lock_until_power_cycled_ind_v01;

/*---------------------------------------------------------------------------
  QMI_NAS_MAINTENANCE_REQUIRED_IND_V01
---------------------------------------------------------------------------*/
#define NAS_MAINTREQ_IND_T10      (0x10)
#define NAS_MAINTREQ_IND_T11      (0x11)

typedef struct
{
  /* Optional */
  /*  Maintenance Requied */
  uint8_t maintenance_required_valid;  /**< Must be set to true if maintenance_required is being passed */
  uint8_t maintenance_required;

  /* Optional */
  /*  Maintenance Reason */
  uint8_t maintenance_reason_valid;  /**< Must be set to true if maintenance_reason is being passed */
  uint8_t maintenance_reason;
}nas_maint_required_ind_v01;

#endif /* FEATURE_P_VZW_CS_AUTH_REJ_DISPLAY */

/*---------------------------------------------------------------------------
  QMI_NAS_PERFORM_NETWORK_SCAN [start]
  jaeyong1.park 2017-02/20 
---------------------------------------------------------------------------*/


typedef enum {
  NAS_NW_SCAN_TYPE_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_SCAN_TYPE_PLMN_V01 = 0x00, /**<  PLMN (default) \n  */
  NAS_SCAN_TYPE_CSG_V01 = 0x01, /**<  Closed subscriber group \n  */
  NAS_SCAN_TYPE_MODE_PREF_V01 = 0x02, /**<  Mode preference \n  */
  NAS_SCAN_TYPE_PCI_V01 = 0x03, /**<  Physical cell ID  */
  NAS_NW_SCAN_TYPE_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_nw_scan_type_enum_v01;

typedef enum {
  NAS_SCAN_RESULT_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_SCAN_SUCCESS_V01 = 0x00, 
  NAS_SCAN_AS_ABORT_V01 = 0x01, 
  NAS_SCAN_REJ_IN_RLF_V01 = 0x02, 
  NAS_SCAN_RESULT_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_scan_result_enum_v01;


typedef enum {
  NAS_NW_NAME_SOURCE_ENUM_TYPE_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_NW_NAME_SOURCE_UNKNOWN_V01 = 0x00, /**<  Unknown \n  */
  NAS_NW_NAME_SOURCE_OPL_PNN_V01 = 0x01, /**<  Operator PLMN list and PLMN network name \n  */
  NAS_NW_NAME_SOURCE_CPHS_ONS_V01 = 0x02, /**<  Common PCN handset specification and operator name string \n  */
  NAS_NW_NAME_SOURCE_NITZ_V01 = 0x03, /**<  Network identity and time zone \n  */
  NAS_NW_NAME_SOURCE_SE13_V01 = 0x04, /**<  GSMA SE13 table \n  */
  NAS_NW_NAME_SOURCE_MCC_MNC_V01 = 0x05, /**<  Mobile country code and mobile network code \n  */
  NAS_NW_NAME_SOURCE_SPN_V01 = 0x06, /**<  Service provider name  */
  NAS_NW_NAME_SOURCE_ENUM_TYPE_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_nw_name_source_enum_type_v01;

typedef enum {
  NAS_CSG_LIST_CAT_ENUM_MIN_ENUM_VAL_V01 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  NAS_CSG_LIST_CAT_UNKNOWN_V01 = 0, /**<  Unknown CSG list.  */
  NAS_CSG_LIST_CAT_ALLOWED_V01 = 1, /**<  Allowed CSG list.  */
  NAS_CSG_LIST_CAT_OPERATOR_V01 = 2, /**<  Operator CSG list.  */
  NAS_CSG_LIST_CAT_ENUM_MAX_ENUM_VAL_V01 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}nas_csg_list_cat_enum_v01;


typedef struct {

  /*  Absolute cell's frequency */
  uint32_t freq;
  /**<   Absolute cell's frequency. Range: 0 to 65535.
  */

  /*   Cell ID */
  uint16_t cell_id;
  /**<   Cell ID
  */

  /*  Global cell ID */
  uint32_t global_cell_id;
  /**<   Global cell ID
  */

  /*  PLMN ID */
  uint32_t plmn_len;  /**< Must be set to # of elements in plmn */
  nas_plmn_id_ext_type_v01 plmn[NAS_PCI_SCAN_MAX_NUM_PLMN_V01];
}nas_pci_scan_cell_info_type_v01;  /* Type */


typedef struct {

  uint32_t id;
  /**<   Closed subscriber group identifier.
  */

  uint32_t name_len;  /**< Must be set to # of elements in name */
  uint16_t name[NAS_CSG_NAME_MAX_V01];
  /**<   Home Node B (HNB) or Home eNode B (HeNB) name in UTF-16.
       The network name is not guaranteed to be NULL terminated.
  */
}nas_csg_info_type_v01;  /* Type */

typedef struct {

  /*   RSRP */
  int16_t rsrp;
  /**<   Combined RSRP */

  /*   RX0 RSRP */
  int16_t rsrp_rx0;
  /**<   Rx0 RSRP */

  /*   RX1 RSRP */
  int16_t rsrp_rx1;
  /**<   Rx1 RSRP */

  /*   Combined RSRQ */
  int16_t rsrq;
  /**<   Combined RSRQ */

  /*   RX0 RSRQ */
  int16_t rsrq_rx0;
  /**<   Rx0 RSRQ */

  /*   RX1 RSRQ */
  int16_t rsrq_rx1;
  /**<   Rx1 RSRQ */
}nas_pci_scan_signal_info_type_v01;  /* Type */

typedef struct {

  uint32_t pci_cell_info_len;  /**< Must be set to # of elements in pci_cell_info */
  nas_pci_scan_cell_info_type_v01 pci_cell_info[NAS_PCI_SCAN_LIST_MAX_V01];

  nas_pci_scan_signal_info_type_v01 signal_info;
}nas_pci_nw_info_type_v01;  /* Type */


typedef struct {

  uint16_t mcc;
  /**<   A 16-bit integer representation of MCC. Range: 0 to 999.
  */

  uint16_t mnc;
  /**<   A 16-bit integer representation of MNC. Range: 0 to 999.
  */

  nas_csg_list_cat_enum_v01 csg_list_cat;
  /**<   Closed subscriber group category. Values: \n
       - 0 -- NAS_CSG_LIST_CAT_UNKNOWN -- Unknown CSG list \n
       - 1 -- NAS_CSG_LIST_CAT_ALLOWED -- Allowed CSG list \n
       - 2 -- NAS_CSG_LIST_CAT_OPERATOR -- Operator CSG list
  */

  nas_csg_info_type_v01 csg_info;
  /**<   Closed subscriber group information.
  */
}nas_csg_nw_info_type_v01;  /* Type */
/**
    @}
  */

/** @addtogroup nas_qmi_aggregates
    @{
  */
typedef struct {

  uint16_t mcc;
  /**<   A 16-bit integer representation of MCC. Range: 0 to 999.
  */

  uint16_t mnc;
  /**<   A 16-bit integer representation of MNC. Range: 0 to 999.
  */

  uint32_t csg_id;
  /**<   Closed subscriber group identifier.
  */

  int32_t signal_strength;
  /**<   Signal strength information in dBm.
  */
}nas_csg_nw_signal_strength_info_type_v01;  /* Type */


/** @addtogroup nas_qmi_messages
    @{
  */
/** Request Message; Performs a scan for visible networks. */
typedef struct {

  /* Optional */
  /*  Network Type */
  uint8_t network_type_valid;  /**< Must be set to true if network_type is being passed */
  nas_network_type_mask_type_v01 network_type;
  /**<   Bitmask representing the network type to scan. Values: \n
       - Bit 0 -- GSM \n
       - Bit 1 -- UMTS \n
       - Bit 2 -- LTE \n
       - Bit 3 -- TD-SCDMA \n
       Any combination of the bit positions can be used. If the mask is
       sent with no bits set, the scan is performed using the currently 
       set preference.
    */

  /* Optional */
  /*  Scan Type */
  uint8_t scan_type_valid;  /**< Must be set to true if scan_type is being passed */
  nas_nw_scan_type_enum_v01 scan_type;
  /**<   Network scan type. Values: \n
      - NAS_SCAN_TYPE_PLMN (0x00) --  PLMN (default) \n 
      - NAS_SCAN_TYPE_CSG (0x01) --  Closed subscriber group \n 
      - NAS_SCAN_TYPE_MODE_PREF (0x02) --  Mode preference \n 
      - NAS_SCAN_TYPE_PCI (0x03) --  Physical cell ID 
 */

  /* Optional */
  /*  Band Preference */
  uint8_t band_pref_valid;  /**< Must be set to true if band_pref is being passed */
  nas_band_pref_mask_type_v01 band_pref;
  /**<   Bitmask representing the band preference to be scanned.  
       See Table @latexonly\ref{tbl:bandPreference}@endlatexonly 
       for details.   
  */

  /* Optional */
  /*  LTE Band Preference */
  uint8_t lte_band_pref_valid;  /**< Must be set to true if lte_band_pref is being passed */
  lte_band_pref_mask_type_v01 lte_band_pref;
  /**<   Bitmask representing the LTE band preference to be scanned. 
       See Table @latexonly\ref{tbl:lteBandPreference}@endlatexonly 
       for details.  
  */

  /* Optional */
  /*  TDSCDMA Band Preference */
  uint8_t tdscdma_band_pref_valid;  /**< Must be set to true if tdscdma_band_pref is being passed */
  nas_tdscdma_band_pref_mask_type_v01 tdscdma_band_pref;
  /**<   Bitmask representing the TD-SCDMA band preference to be scanned. Values: \n
      - NAS_TDSCDMA_BAND_A (0x01) --  TD-SCDMA Band A \n 
      - NAS_TDSCDMA_BAND_B (0x02) --  TD-SCDMA Band B \n 
      - NAS_TDSCDMA_BAND_C (0x04) --  TD-SCDMA Band C \n 
      - NAS_TDSCDMA_BAND_D (0x08) --  TD-SCDMA Band D \n 
      - NAS_TDSCDMA_BAND_E (0x10) --  TD-SCDMA Band E \n 
      - NAS_TDSCDMA_BAND_F (0x20) --  TD-SCDMA Band F 

 \vspace{3pt}
 All other bits are reserved and must be set to 0.
 */
}nas_perform_network_scan_req_msg_v01;  /* Message */
/**
    @}
  */


/** @addtogroup nas_qmi_messages
    @{
  */
/** Response Message; Performs a scan for visible networks. */
typedef struct {

  /* Mandatory */
  /*  Result Code */
  qmi_response_type_v01 resp;
  /**<   Standard response type. 
 Standard response type. Contains the following data members:
     - qmi_result_type -- QMI_RESULT_SUCCESS or QMI_RESULT_FAILURE \n
     - qmi_error_type  -- Error code. Possible error code values are described in
                          the error codes section of each message definition.
  */

  /* Optional */
  /*  3GPP Network Information** */
  uint8_t nas_3gpp_network_info_valid;  /**< Must be set to true if nas_3gpp_network_info is being passed */
  uint32_t nas_3gpp_network_info_len;  /**< Must be set to # of elements in nas_3gpp_network_info */
  nas_3gpp_network_info_type_v01 nas_3gpp_network_info[NAS_3GPP_NETWORK_INFO_LIST_MAX_V01];

  /* Optional */
  /*  Network Radio Access Technology** */
  uint8_t nas_network_radio_access_technology_valid;  /**< Must be set to true if nas_network_radio_access_technology is being passed */
  uint32_t nas_network_radio_access_technology_len;  /**< Must be set to # of elements in nas_network_radio_access_technology */
  nas_network_radio_access_technology_type_v01 nas_network_radio_access_technology[NAS_3GPP_NETWORK_INFO_LIST_MAX_V01];

  /* Optional */
  /*  MNC PCS Digit Include Status */
  uint8_t mnc_includes_pcs_digit_valid;  /**< Must be set to true if mnc_includes_pcs_digit is being passed */
  uint32_t mnc_includes_pcs_digit_len;  /**< Must be set to # of elements in mnc_includes_pcs_digit */
  nas_mnc_pcs_digit_include_status_type_v01 mnc_includes_pcs_digit[NAS_3GPP_NETWORK_INFO_LIST_MAX_V01];

  /* Optional */
  /*  Network Scan Result */
  uint8_t scan_result_valid;  /**< Must be set to true if scan_result is being passed */
  nas_scan_result_enum_v01 scan_result;
  /**<   Indicates the status of the network scan. Values: \n
       - 0x00 -- NAS_SCAN_SUCCESS -- Network scan was successful \n
       - 0x01 -- NAS_SCAN_AS_ABORT -- Network scan was aborted   \n
       - 0x02 -- NAS_SCAN_REJ_IN_RLF -- Network scan did not complete due 
                 to a radio link failure recovery in progress
  */

  /* Optional */
  /*  CSG Information */
  uint8_t csg_info_valid;  /**< Must be set to true if csg_info is being passed */
  uint32_t csg_info_len;  /**< Must be set to # of elements in csg_info */
  nas_csg_nw_info_type_v01 csg_info[NAS_3GPP_NETWORK_INFO_LIST_MAX_V01];

  /* Optional */
  /*  CSG Signal Strength Information */
  uint8_t csg_sig_info_valid;  /**< Must be set to true if csg_sig_info is being passed */
  uint32_t csg_sig_info_len;  /**< Must be set to # of elements in csg_sig_info */
  nas_csg_nw_signal_strength_info_type_v01 csg_sig_info[NAS_3GPP_NETWORK_INFO_LIST_MAX_V01];

  /* Optional */
  /*  Network Name Source */
  uint8_t nw_name_source_valid;  /**< Must be set to true if nw_name_source is being passed */
  uint32_t nw_name_source_len;  /**< Must be set to # of elements in nw_name_source */
  nas_nw_name_source_enum_type_v01 nw_name_source[NAS_3GPP_NETWORK_INFO_LIST_MAX_V01];
  /**<   Network name source. Values: \n
      - NAS_NW_NAME_SOURCE_UNKNOWN (0x00) --  Unknown \n 
      - NAS_NW_NAME_SOURCE_OPL_PNN (0x01) --  Operator PLMN list and PLMN network name \n 
      - NAS_NW_NAME_SOURCE_CPHS_ONS (0x02) --  Common PCN handset specification and operator name string \n 
      - NAS_NW_NAME_SOURCE_NITZ (0x03) --  Network identity and time zone \n 
      - NAS_NW_NAME_SOURCE_SE13 (0x04) --  GSMA SE13 table \n 
      - NAS_NW_NAME_SOURCE_MCC_MNC (0x05) --  Mobile country code and mobile network code \n 
      - NAS_NW_NAME_SOURCE_SPN (0x06) --  Service provider name 
 */

  /* Optional */
  /*  PCI Information */
  uint8_t pci_plmn_info_valid;  /**< Must be set to true if pci_plmn_info is being passed */
  nas_pci_nw_info_type_v01 pci_plmn_info;
}nas_perform_network_scan_resp_msg_v01;  /* Message */
/**
    @}
  */

/*---------------------------------------------------------------------------
  QMI_NAS_PERFORM_NETWORK_SCAN [end]
  jaeyong1.park 2017-02/20 
---------------------------------------------------------------------------*/



/*Service Message Definition*/
/** @addtogroup nas_qmi_msg_ids
    @{
  */
#define QMI_NAS_RESET_REQ_MSG_V01 0x0000
#define QMI_NAS_RESET_RESP_MSG_V01 0x0000
#define QMI_NAS_ABORT_REQ_MSG_V01 0x0001
#define QMI_NAS_ABORT_RESP_MSG_V01 0x0001
#define QMI_NAS_SET_EVENT_REPORT_REQ_MSG_V01 0x0002
#define QMI_NAS_SET_EVENT_REPORT_RESP_MSG_V01 0x0002
#define QMI_NAS_EVENT_REPORT_IND_MSG_V01 0x0002
#define QMI_NAS_INDICATION_REGISTER_REQ_MSG_V01 0x0003
#define QMI_NAS_INDICATION_REGISTER_RESP_MSG_V01 0x0003
#define QMI_NAS_GET_SIGNAL_STRENGTH_REQ_MSG_V01 0x0020
#define QMI_NAS_GET_SIGNAL_STRENGTH_RESP_MSG_V01 0x0020
#define QMI_NAS_PERFORM_NETWORK_SCAN_REQ_MSG_V01 0x0021
#define QMI_NAS_PERFORM_NETWORK_SCAN_RESP_MSG_V01 0x0021
#define QMI_NAS_INITIATE_NETWORK_REGISTER_REQ_MSG_V01 0x0022
#define QMI_NAS_INITIATE_NETWORK_REGISTER_RESP_MSG_V01 0x0022
#define QMI_NAS_INITIATE_ATTACH_REQ_MSG_V01 0x0023
#define QMI_NAS_INITIATE_ATTACH_RESP_MSG_V01 0x0023
#define QMI_NAS_GET_SERVING_SYSTEM_REQ_MSG_V01 0x0024
#define QMI_NAS_GET_SERVING_SYSTEM_RESP_MSG_V01 0x0024
#define QMI_NAS_SERVING_SYSTEM_IND_MSG_V01 0x0024
#define QMI_NAS_GET_HOME_NETWORK_REQ_MSG_V01 0x0025
#define QMI_NAS_GET_HOME_NETWORK_RESP_MSG_V01 0x0025
#define QMI_NAS_GET_PREFERRED_NETWORKS_REQ_MSG_V01 0x0026
#define QMI_NAS_GET_PREFERRED_NETWORKS_RESP_MSG_V01 0x0026
#define QMI_NAS_SET_PREFERRED_NETWORKS_REQ_MSG_V01 0x0027
#define QMI_NAS_SET_PREFERRED_NETWORKS_RESP_MSG_V01 0x0027
#define QMI_NAS_GET_FORBIDDEN_NETWORKS_REQ_MSG_V01 0x0028
#define QMI_NAS_GET_FORBIDDEN_NETWORKS_RESP_MSG_V01 0x0028
#define QMI_NAS_SET_FORBIDDEN_NETWORKS_REQ_MSG_V01 0x0029
#define QMI_NAS_SET_FORBIDDEN_NETWORKS_RESP_MSG_V01 0x0029
#define QMI_NAS_SET_TECHNOLOGY_PREFERENCE_REQ_V01 0x002A
#define QMI_NAS_SET_TECHNOLOGY_PREFERENCE_RESP_V01 0x002A
#define QMI_NAS_GET_TECHNOLOGY_PREFERENCE_REQ_V01 0x002B
#define QMI_NAS_GET_TECHNOLOGY_PREFERENCE_RESP_V01 0x002B
#define QMI_NAS_GET_ACCOLC_REQ_MSG_V01 0x002C
#define QMI_NAS_GET_ACCOLC_RESP_MSG_V01 0x002C
#define QMI_NAS_SET_ACCOLC_REQ_MSG_V01 0x002D
#define QMI_NAS_SET_ACCOLC_RESP_MSG_V01 0x002D
#define QMI_NAS_GET_NETWORK_SYSTEM_PREFERENCE_REQ_V01 0x002E
#define QMI_NAS_GET_NETWORK_SYSTEM_PREFERENCE_RESP_V01 0x002E
#define QMI_NAS_GET_DEVICE_CONFIG_REQ_MSG_V01 0x002F
#define QMI_NAS_GET_DEVICE_CONFIG_RESP_MSG_V01 0x002F
#define QMI_NAS_SET_DEVICE_CONFIG_REQ_MSG_V01 0x0030
#define QMI_NAS_SET_DEVICE_CONFIG_RESP_MSG_V01 0x0030
#define QMI_NAS_GET_RF_BAND_INFO_REQ_MSG_V01 0x0031
#define QMI_NAS_GET_RF_BAND_INFO_RESP_MSG_V01 0x0031
#define QMI_NAS_GET_AN_AAA_STATUS_REQ_MSG_V01 0x0032
#define QMI_NAS_GET_AN_AAA_STATUS_RESP_MSG_V01 0x0032
#define QMI_NAS_SET_SYSTEM_SELECTION_PREFERENCE_REQ_MSG_V01 0x0033
#define QMI_NAS_SET_SYSTEM_SELECTION_PREFERENCE_RESP_MSG_V01 0x0033
#define QMI_NAS_GET_SYSTEM_SELECTION_PREFERENCE_REQ_MSG_V01 0x0034
#define QMI_NAS_GET_SYSTEM_SELECTION_PREFERENCE_RESP_MSG_V01 0x0034
#define QMI_NAS_SYSTEM_SELECTION_PREFERENCE_IND_MSG_V01 0x0034
#define QMI_NAS_SET_DDTM_PREFERENCE_REQ_MSG_V01 0x0037
#define QMI_NAS_SET_DDTM_PREFERENCE_RESP_MSG_V01 0x0037
#define QMI_NAS_DDTM_IND_MSG_V01 0x0038
#define QMI_NAS_GET_OPERATOR_NAME_DATA_REQ_MSG_V01 0x0039
#define QMI_NAS_GET_OPERATOR_NAME_DATA_RESP_MSG_V01 0x0039
#define QMI_NAS_OPERATOR_NAME_DATA_IND_MSG_V01 0x003A
#define QMI_NAS_GET_CSP_PLMN_MODE_BIT_REQ_MSG_V01 0x003B
#define QMI_NAS_GET_CSP_PLMN_MODE_BIT_RESP_MSG_V01 0x003B
#define QMI_NAS_CSP_PLMN_MODE_BIT_IND_MSG_V01 0x003C
#define QMI_NAS_UPDATE_AKEY_REQ_MSG_V01 0x003D
#define QMI_NAS_UPDATE_AKEY_RESP_MSG_V01 0x003D
#define QMI_NAS_GET_3GPP2_SUBSCRIPTION_INFO_REQ_MSG_V01 0x003E
#define QMI_NAS_GET_3GPP2_SUBSCRIPTION_INFO_RESP_MSG_V01 0x003E
#define QMI_NAS_SET_3GPP2_SUBSCRIPTION_INFO_REQ_MSG_V01 0x003F
#define QMI_NAS_SET_3GPP2_SUBSCRIPTION_INFO_RESP_MSG_V01 0x003F
#define QMI_NAS_GET_MOB_CAI_REV_REQ_MSG_V01 0x0040
#define QMI_NAS_GET_MOB_CAI_REV_RESP_MSG_V01 0x0040
#define QMI_NAS_GET_RTRE_CONFIG_REQ_MSG_V01 0x0041
#define QMI_NAS_GET_RTRE_CONFIG_RESP_MSG_V01 0x0041
#define QMI_NAS_SET_RTRE_CONFIG_REQ_MSG_V01 0x0042
#define QMI_NAS_SET_RTRE_CONFIG_RESP_MSG_V01 0x0042
#define QMI_NAS_GET_CELL_LOCATION_INFO_REQ_MSG_V01 0x0043
#define QMI_NAS_GET_CELL_LOCATION_INFO_RESP_MSG_V01 0x0043
#define QMI_NAS_GET_PLMN_NAME_REQ_MSG_V01 0x0044
#define QMI_NAS_GET_PLMN_NAME_RESP_MSG_V01 0x0044
#define QMI_NAS_BIND_SUBSCRIPTION_REQ_MSG_V01 0x0045
#define QMI_NAS_BIND_SUBSCRIPTION_RESP_MSG_V01 0x0045
#define QMI_NAS_MANAGED_ROAMING_IND_MSG_V01 0x0046
#define QMI_NAS_DUAL_STANDBY_PREF_IND_MSG_V01 0x0047
#define QMI_NAS_SUBSCRIPTION_INFO_IND_MSG_V01 0x0048
#define QMI_NAS_GET_MODE_PREF_REQ_MSG_V01 0x0049
#define QMI_NAS_GET_MODE_PREF_RESP_MSG_V01 0x0049
#define QMI_NAS_DUAL_STANDBY_PREF_REQ_MSG_V01 0x004B
#define QMI_NAS_DUAL_STANDBY_PREF_RESP_MSG_V01 0x004B
#define QMI_NAS_NETWORK_TIME_IND_MSG_V01 0x004C
#define QMI_NAS_GET_SYS_INFO_REQ_MSG_V01 0x004D
#define QMI_NAS_GET_SYS_INFO_RESP_MSG_V01 0x004D
#define QMI_NAS_SYS_INFO_IND_MSG_V01 0x004E
#define QMI_NAS_GET_SIG_INFO_REQ_MSG_V01 0x004F
#define QMI_NAS_GET_SIG_INFO_RESP_MSG_V01 0x004F
#define QMI_NAS_CONFIG_SIG_INFO_REQ_MSG_V01 0x0050
#define QMI_NAS_CONFIG_SIG_INFO_RESP_MSG_V01 0x0050
#define QMI_NAS_SIG_INFO_IND_MSG_V01 0x0051
#define QMI_NAS_GET_ERR_RATE_REQ_MSG_V01 0x0052
#define QMI_NAS_GET_ERR_RATE_RESP_MSG_V01 0x0052
#define QMI_NAS_ERR_RATE_IND_MSG_V01 0x0053
#define QMI_NAS_HDR_SESSION_CLOSE_IND_MSG_V01 0x0054
#define QMI_NAS_HDR_UATI_UPDATE_IND_MSG_V01 0x0055
#define QMI_NAS_GET_HDR_SUBTYPE_REQ_MSG_V01 0x0056
#define QMI_NAS_GET_HDR_SUBTYPE_RESP_MSG_V01 0x0056
#define QMI_NAS_GET_HDR_COLOR_CODE_REQ_MSG_V01 0x0057
#define QMI_NAS_GET_HDR_COLOR_CODE_RESP_MSG_V01 0x0057
#define QMI_NAS_GET_CURRENT_ACQ_SYS_MODE_REQ_MSG_V01 0x0058
#define QMI_NAS_GET_CURRENT_ACQ_SYS_MODE_RESP_MSG_V01 0x0058
#define QMI_NAS_SET_RX_DIVERSITY_REQ_MSG_V01 0x0059
#define QMI_NAS_SET_RX_DIVERSITY_RESP_MSG_V01 0x0059
#define QMI_NAS_GET_TX_RX_INFO_REQ_MSG_V01 0x005A
#define QMI_NAS_GET_TX_RX_INFO_RESP_MSG_V01 0x005A
#define QMI_NAS_UPDATE_AKEY_EXT_REQ_MSG_V01 0x005B
#define QMI_NAS_UPDATE_AKEY_EXT_RESP_V01 0x005B
#define QMI_NAS_GET_DUAL_STANDBY_PREF_REQ_MSG_V01 0x005C
#define QMI_NAS_GET_DUAL_STANDBY_PREF_RESP_MSG_V01 0x005C
#define QMI_NAS_DETACH_LTE_REQ_MSG_V01 0x005D
#define QMI_NAS_DETACH_LTE_RESP_MSG_V01 0x005D
#define QMI_NAS_BLOCK_LTE_PLMN_REQ_MSG_V01 0x005E
#define QMI_NAS_BLOCK_LTE_PLMN_RESP_MSG_V01 0x005E
#define QMI_NAS_UNBLOCK_LTE_PLMN_REQ_MSG_V01 0x005F
#define QMI_NAS_UNBLOCK_LTE_PLMN_RESP_MSG_V01 0x005F
#define QMI_NAS_RESET_LTE_PLMN_BLOCKING_REQ_MSG_V01 0x0060
#define QMI_NAS_RESET_LTE_PLMN_BLOCKING_RESP_MSG_V01 0x0060
#define QMI_NAS_CURRENT_PLMN_NAME_IND_V01 0x0061
#define QMI_NAS_CONFIG_EMBMS_REQ_MSG_V01 0x0062
#define QMI_NAS_CONFIG_EMBMS_RESP_MSG_V01 0x0062
#define QMI_NAS_GET_EMBMS_STATUS_REQ_MSG_V01 0x0063
#define QMI_NAS_GET_EMBMS_STATUS_RESP_MSG_V01 0x0063
#define QMI_NAS_EMBMS_STATUS_IND_V01 0x0064
#define QMI_NAS_GET_CDMA_POSITION_INFO_REQ_MSG_V01 0x0065
#define QMI_NAS_GET_CDMA_POSITION_INFO_RESP_MSG_V01 0x0065
#define QMI_NAS_RF_BAND_INFO_IND_V01 0x0066
#define QMI_NAS_FORCE_NETWORK_SEARCH_REQ_MSG_V01 0x0067
#define QMI_NAS_FORCE_NETWORK_SEARCH_RESP_MSG_V01 0x0067
#define QMI_NAS_NETWORK_REJECT_IND_V01 0x0068
#define QMI_NAS_GET_MANAGED_ROAMING_CONFIG_REQ_MSG_V01 0x0069
#define QMI_NAS_GET_MANAGED_ROAMING_CONFIG_RESP_MSG_V01 0x0069
#define QMI_NAS_RTRE_CONFIG_IND_V01 0x006A

/**
    @}
  */

#ifdef __cplusplus
}
#endif
#endif


