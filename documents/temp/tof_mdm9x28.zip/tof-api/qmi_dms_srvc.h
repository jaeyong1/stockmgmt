#ifndef QMI_DMS_SRVC_H
#define QMI_DMS_SRVC_H

/******************************************************************************
  @file    qmi_dms_srvc.h
  @brief   QMI message library DMS service definitions

  DESCRIPTION
  This file contains common, external header file definitions for QMI
  interface library.

  INITIALIZATION AND SEQUENCING REQUIREMENTS
  tof_tof_qmi_dms_srvc_init_client() must be called to create one or more clients
  tof_qmi_dms_srvc_release_client() must be called to delete each client when
  finished.

  $Header: //source/qcom/qct/modem/datacommon/qmimsglib/dev/work/inc/qmi_dms_srvc.h#5 $
  $DateTime: 2009/07/15 10:38:12 $
  ---------------------------------------------------------------------------
  Copyright (c) 2013 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/

#include "device_management_service_v01.h"
#include "wmmdiag_packet.h"
#include "TOF_API.h"

#ifdef __cplusplus
extern "C" {
#endif

#define QMI_DMS_STD_MSG_SIZE QMI_MAX_STD_MSG_SIZE

/* Custom named TLV IDs*/

/*---------------------------------------------------------------------------
  Major and Minor Version Nos for DMS
---------------------------------------------------------------------------*/
#define DMSI_BASE_VER_MAJOR    (1)
#define DMSI_BASE_VER_MINOR    (14)

#define DMSI_ADDENDUM_VER_MAJOR  (0)
#define DMSI_ADDENDUM_VER_MINOR  (0)


#define QMI_TYPE_REQUIRED_PARAMETERS   (0x01)
#define QMI_TYPE_RESULT_CODE          (0x02)


/*---------------------------------------------------------------------------
  Device Serial Numbers
---------------------------------------------------------------------------*/
#define DMSI_PRM_TYPE_ESN   (0x10)
#define DMSI_PRM_TYPE_IMEI  (0x11)
#define DMSI_PRM_TYPE_MEID  (0x12)
#define DMSI_PRM_TYPE_IMEISV_SVN (0x13)

/*---------------------------------------------------------------------------
  bind_subscription TLV definitions
---------------------------------------------------------------------------*/
#define DMSI_PRM_TYPE_BIND_SUBSCRIPTION (0x10)

/*---------------------------------------------------------------------------
  Get MSISDN TLV definitions
---------------------------------------------------------------------------*/
#define DMSI_PRM_TYPE_MIN   (0x10)
#define DMSI_PRM_TYPE_UIM_IMSI (0x11)

#define DMSI_MODEL_ID_SIZ   (256)
#define DMSI_REV_ID_SIZ     (256)
#define DMSI_SERIAL_NO_SIZ  (256)
#define DMSI_HW_REV_ID_SIZ  (256)

#define DMSI_BASE_DECIMAL   (10)
#define DMSI_BASE_HEX       (16)
#define DMSI_UIM_PIN1       (1)
#define DMSI_UIM_PIN2       (2)
#define DMSI_MAX_PINS       (2)

/*---------------------------------------------------------------------------
  Automatic Activation Info
---------------------------------------------------------------------------*/
#define DMSI_ACT_AUTO_CODE_SIZ (CM_MAX_NUMBER_CHARS)
/*---------------------------------------------------------------------------
  Manual Activation Info
---------------------------------------------------------------------------*/
/* ID reserved for single-request PRL TLV (not size limited)  */
//#define DMSI_PRM_TYPE_PRL   (0x10)
#define DMSI_PRM_TYPE_MN_HA (0x11)
#define DMSI_PRM_TYPE_MN_AAA (0x12)
#define DMSI_PRM_TYPE_PRL   (0x13)

#define DMSI_SPC_SIZ        (6)
#define DMSI_NUMB_PCS_SIZ   (22)
#define DMSI_MN_KEY_SIZ     (16)
#define DMSI_MIN_SIZ        (10)

/*---------------------------------------------------------------------------
  DMS segment length (3k)
---------------------------------------------------------------------------*/
#define DMSI_TLV_SEGMENT_LEN_MAX (1536)

/*---------------------------------------------------------------------------
  Constants for IMSI
---------------------------------------------------------------------------*/
#if defined(FEATURE_CDMA_800) || defined(FEATURE_CDMA_1900)
#define DMSI_IMSI_MCC_0 999        /* 000 */
#define DMSI_IMSI_S1_0  16378855   /* 0000000 */
#define DMSI_IMSI_S2_0  999        /* 000 */
#define DMSI_IMSI_CLASS0_ADDR_NUM 0xFF
#define DMSI_IMSI_11_12_0 99
#define DMSI_FMMIN 0
#define DMSI_CDMAMIN 1
#endif /* defined(FEATURE_CDMA_800) || defined(FEATURE_CDMA_1900) */

/*---------------------------------------------------------------------------
  Event report TLV definitions
---------------------------------------------------------------------------*/
#define DMSI_PRM_TYPE_POWER_STATE         (0x10)
#define DMSI_PRM_TYPE_BAT_LVL_RPT_LIMITS  (0x11)
#define DMSI_PRM_TYPE_PIN_STATUS          (0x12)
#define DMSI_PRM_TYPE_ACTIVATION_STATE    (0x13)
#define DMSI_PRM_TYPE_OPRT_MODE           (0x14)
#define DMSI_PRM_TYPE_UIM_GET_STATE       (0x15)
#define DMSI_PRM_TYPE_WD_STATE            (0x16)
#define DMSI_PRM_TYPE_PRL_INIT            (0x17)
//ygpark.20141201 +
#if defined(FEATURE_LGIT_OTADM_FOTA_FUMO_VZW)
 #define DMSI_PRM_TYPE_OTADM_FOTA_DOWNLOADED            (0x18)
 #define DMSI_PRM_TYPE_OTADM_FOTA_DOWNLOADED_START            (DMSI_PRM_TYPE_OTADM_FOTA_DOWNLOADED+1)
 #define DMSI_PRM_TYPE_OTADM_FOTA_DOWNLOADED_PAUSE            (DMSI_PRM_TYPE_OTADM_FOTA_DOWNLOADED_START+1)
 #define DMSI_PRM_TYPE_OTADM_FOTA_DOWNLOADED_RESTART            (DMSI_PRM_TYPE_OTADM_FOTA_DOWNLOADED_PAUSE+1)
 #define DMSI_PRM_TYPE_OTADM_FOTA_INSTALL_UNKNOWN            (DMSI_PRM_TYPE_OTADM_FOTA_DOWNLOADED_RESTART+1)
 #define DMSI_PRM_TYPE_OTADM_FOTA_INSTALL_FAIL                   (DMSI_PRM_TYPE_OTADM_FOTA_INSTALL_UNKNOWN+1)
 #define DMSI_PRM_TYPE_OTADM_FOTA_INSTALL_SUCCESS            (DMSI_PRM_TYPE_OTADM_FOTA_INSTALL_FAIL+1)
 #define DMSI_PRM_TYPE_OTADM_FOTA_SUCANCEL            (DMSI_PRM_TYPE_OTADM_FOTA_INSTALL_SUCCESS+1)
 #endif
 //ygpark.20141201 -
/*---------------------------------------------------------------------------
  Get Pin Status TLV definitions
---------------------------------------------------------------------------*/
#define DMSI_PRM_TYPE_PIN1_STATUS         (0x11)
#define DMSI_PRM_TYPE_PIN2_STATUS         (0x12)

#define DMSI_PRM_TYPE_RETRIES_LEFT        (0x10)

#define DMSI_BAT_LVL_MIN               (0)
#define DMSI_BAT_LVL_MAX               (100)
#define DMSI_BAT_LVL_INACTIVE          (255)
#define DMSI_PWR_STATE_INACTIVE        (0)
#define DMSI_EVENT_MASK_POWER_STATE    (0x01)
#define DMSI_EVENT_MASK_BATTERY_LVL    (0x02)

/*---------------------------------------------------------------------------
  Get/Set Time TLV definitions
---------------------------------------------------------------------------*/
#define DMSI_PRM_TYPE_SYS_TIME      (0x10)
#define DMSI_PRM_TYPE_USR_TIME      (0x11)
#define DMSI_PRM_TYPE_TIME_REF_TYPE (0x10)

/*---------------------------------------------------------------------------
  SIM Lock TLV definitions
---------------------------------------------------------------------------*/
#define DMSI_PRM_TYPE_BLOCKING_OPERATION (0x10)
#define DMSI_PRM_TYPE_CK_RETRY_STATUS    (0x10)
#define DMSI_GET_CK_STATE_BLOCKED        (0x2)

/*---------------------------------------------------------------------------
  LTE Band capability TLV definition
---------------------------------------------------------------------------*/
#define DMSI_PRM_TYPE_LTE_BAND_CAP       (0x10)

/*---------------------------------------------------------------------------
  TDSCDMA Band capability TLV definition
---------------------------------------------------------------------------*/
#define DMSI_PRM_TYPE_TDS_BAND_CAP       (0x11)

/*---------------------------------------------------------------------------
  UIM ICCID length
---------------------------------------------------------------------------*/
#define DMSI_MMGSDI_ICCID_LEN (10)

/*---------------------------------------------------------------------------
  User Lock Code length
---------------------------------------------------------------------------*/
#define DMSI_USER_LOCK_SIZ NV_LOCK_CODE_SIZE

/*---------------------------------------------------------------------------
  UIM IMSI length
---------------------------------------------------------------------------*/
#define DMSI_MMGSDI_IMSI_LEN (15)

/*---------------------------------------------------------------------------
  UIM MSISDN length
---------------------------------------------------------------------------*/
#define DMSI_MMGSDI_MSISDN_LEN (15)

/*---------------------------------------------------------------------------
  New Service Programming Code 
---------------------------------------------------------------------------*/
#define DMSI_PRM_TYPE_REQUIRED_PRM_NEW_SPC   (0x2)

/*---------------------------------------------------------------------------
  User Data file length
---------------------------------------------------------------------------*/
#define DMSI_USER_DATA_FILE_MAX_LEN (1024)

/*---------------------------------------------------------------------------
  ERI (Extended Roaming Indicator) file length
---------------------------------------------------------------------------*/
#define DMSI_ERI_FILE_MAX_LEN (512)

/*---------------------------------------------------------------------------
  Invalid PRL version for RUIM
---------------------------------------------------------------------------*/
#define DMSI_PRL_VERSION_INVALID (0xFFFF)

/*---------------------------------------------------------------------------
  UIM maximum Control Key length
  As per 3GPP spec(TS 22.022) The control keys shall be decimal strings 
  with an appropriate number of digits for the level of personalisation. 
  PCK (SIM category) should be at least 6 digits, and the remaining control 
  keys at least 8 digits in length. The maximum length for any control 
  key is 16 digits
---------------------------------------------------------------------------*/
#define DMSI_MMGSDI_CK_LEN_MAX (16)

#ifdef FEATURE_DATA_QMI_ADDENDUM
/*---------------------------------------------------------------------------
  Get Revision ID TLV definitions
---------------------------------------------------------------------------*/
#define DMSI_PRM_TYPE_BOOT_VER  (0x10)
#define DMSI_PRM_TYPE_PRI_REV   (0x11)

/*---------------------------------------------------------------------------
  HSU Alternate NET Config Definitions
---------------------------------------------------------------------------*/
#define DMSI_ALT_NET_CONFIG_DISABLED 0x00
#define DMSI_ALT_NET_CONFIG_ENABLED  0x01

/*---------------------------------------------------------------------------
  Get Operation Mode TLV definitions
---------------------------------------------------------------------------*/
#define DMSI_PRM_TYPE_OFFLINE_REASON    (0x10)
#define DMSI_PRM_TYPE_HW_RESTRICTED     (0x11)

/*---------------------------------------------------------------------------
  UQCN version masks used for QMI_DMS_RESTORE_FACTORY_DEFAULTS
---------------------------------------------------------------------------*/
#define DMSI_RESTORE_FACT_VALUE   0xFACD0000 
#define DMSI_RESTORE_FACT_VALUE   0xFACD0000 

/*---------------------------------------------------------------------------
  GOBI Image Definitions
---------------------------------------------------------------------------*/
/* Set firmware preference */
#define DMSI_PRM_TYPE_DOWNLOAD_OVERRIDE   (0x10)
#define DMSI_PRM_TYPE_MODEM_STORAGE_INDEX (0x11)

#define DMSI_PRM_TYPE_MAX_BUILD_ID_LEN    (0x10)

/* Shared */
#define DMSI_IMG_TYPE_MODEM (0)
#define DMSI_IMG_TYPE_PRI   (1)

#define DMSI_NUM_SUPPORTED_IMAGE_TYPES   (2)

#define DMSI_RUNNING_IMAGE_INDEX_UNKNOWN (0xFF)
#define DMSI_STORAGE_INDEX_NOT_USED      (0xFF)
#define DMSI_FAILURE_COUNT_NOT_USED      (0xFF)

#define FEATURE_QMI_GOBI_IMG_TBL_DEBUG

/* Get stored build info */
#define DMSI_PRM_TYPE_BOOT_VER    (0x10)
#define DMSI_PRM_TYPE_PRI_VER     (0x11)
#define DMSI_PRM_TYPE_OEM_LOCK_ID (0x12)

#define DMSI_PRI_VER_INFO_LEN (32)

/* Get boot image download mode */
#define DMSI_PRM_TYPE_DOWNLOAD_MODE (0x10)
#endif /* FEATURE_DATA_QMI_ADDENDUM */

#define DMSI_PRM_TYPE_PRL_ONLY (0x10)

#define DMSI_PRM_TYPE_PRL_INFO_PRL_VER  (0x10)
#define DMSI_PRM_TYPE_PRL_INFO_PRL_ONLY (0x11)

/*---------------------------------------------------------------------------
  Get Device Capability TLV definitions
---------------------------------------------------------------------------*/
#define DMSI_PRM_TYPE_DEVICE_SERVICE_CAPABILITY (0x10)
#define DMSI_PRM_TYPE_DEVICE_CAP_VOICE_SUPPORT  (0x11)
#define DMSI_PRM_TYPE_DEVICE_CAP_SIMUL_VOICE_AND_DATA  (0x12)

/*---------------------------------------------------------------------------
  Get Modem SW Version TLV definitions
---------------------------------------------------------------------------*/
#define DMSI_PRM_TYPE_ASIC_VER (0x10)
#define DMSI_PRM_TYPE_MODEL_CODE (0x11)
#define DMSI_PRM_TYPE_SW_BUILD_DATE (0x12)
#define DMSI_PRM_TYPE_SW_BUILD_TIME (0x13)
#define DMSI_PRM_TYPE_BOOT_VERSION (0x14)
#define DMSI_PRM_TYPE_CAL_INFORMATION (0x15)
#define DMSI_PRM_TYPE_HW_VERSION  (0x16)

/*---------------------------------------------------------------------------
  Macro used in command handlers (common)
---------------------------------------------------------------------------*/
#define CHECK_RETVAL()  if (FALSE == retval) { dsm_free_packet(&response); \
                                               return NULL; }

/*---------------------------------------------------------------------------
  Macro used to determine target support
---------------------------------------------------------------------------*/
#define DMSI_TARGET_SUPPORTS_CDMA(mode_capability)  (mode_capability & SYS_SYS_MODE_MASK_CDMA )
#define DMSI_TARGET_SUPPORTS_HDR(mode_capability)  (mode_capability & SYS_SYS_MODE_MASK_HDR )
#define DMSI_TARGET_SUPPORTS_GSM(mode_capability)  (mode_capability & SYS_SYS_MODE_MASK_GSM )
#define DMSI_TARGET_SUPPORTS_WCDMA(mode_capability)  (mode_capability & SYS_SYS_MODE_MASK_WCDMA )
#define DMSI_TARGET_SUPPORTS_LTE(mode_capability)  (mode_capability & SYS_SYS_MODE_MASK_LTE )
#define DMSI_TARGET_SUPPORTS_TDSCDMA(mode_capability)  (mode_capability & SYS_SYS_MODE_MASK_TDS )


/* invalid SPC used to allow certain service provisioning (defined by carrier)
   without knowing the actual SPC*/
#define SPECIAL_INVALID_SPC "999999"

/*---------------------------------------------------------------------------
  Message-internal TLV length field values
---------------------------------------------------------------------------*/
#define DMSI_PRM_TYPE_OPRT_MODE_TYPE_LEN              (0x01)


/*===========================================================================

                                DATA TYPES

===========================================================================*/

/*---------------------------------------------------------------------------
  device cap enums
---------------------------------------------------------------------------*/
typedef enum
{
  DMSI_DATA_ONLY      = 0x01, 
  DMSI_VOICE_ONLY     = 0x02,
  DMSI_SIM_VOICE_DATA = 0x03,
  DMSI_VOICE_DATA     = 0x04  // voice or data (non-simultaneous)
} qmi_dmsi_voice_cap_e_type;

typedef enum
{
  DMSI_SIM_NOT_REQ  = 0x01,
  DMSI_SIM_SUPPORT  = 0x02
} qmi_dmsi_sim_support_e_type;

typedef enum
{
  DMSI_MASK_VOICE_SUPPORT_NONE               = 0x0000,  
  DMSI_MASK_VOICE_SUPPORT_GW_CSFB_CAPABLE    = 0x0001,
  DMSI_MASK_VOICE_SUPPORT_1x_CSFB_CAPABLE    = 0x0002,
  DMSI_MASK_VOICE_SUPPORT_VOLTE_CAPABLE      = 0x0004
} qmi_dmsi_voice_support_cap_e_type;

typedef enum
{
  DMSI_MASK_SIMUL_VOICE_AND_DATA_CAP_NONE         = 0x0000,  
  DMSI_MASK_SIMUL_VOICE_AND_DATA_SVLTE_CAPABLE    = 0x0001,
  DMSI_MASK_SIMUL_VOICE_AND_DATA_SVDO_CAPABLE     = 0x0002
} qmi_dmsi_simul_voice_and_data_cap_e_type;

typedef enum
{
  DMSI_OPRT_MODE_ONLINE   = 0x00,
  DMSI_OPRT_MODE_LPM      = 0x01,
  DMSI_OPRT_MODE_FTM      = 0x02,
  DMSI_OPRT_MODE_OFFLINE  = 0x03,
  DMSI_OPRT_MODE_RESET    = 0x04,
  DMSI_OPRT_MODE_PWROFF   = 0x05,
  DMSI_OPRT_MODE_PLPM     = 0x06,
  DMSI_OPRT_MODE_MOLPM    = 0x07, // Mode only LPM
  DMSI_OPRT_MODE_NET_TEST_GW = 0x08 //Network test for GSM/WCDMA
} qmi_dmsi_oprt_mode_e_type;

/*---------------------------------------------------------------------------
  Set Event Report event bitmask
---------------------------------------------------------------------------*/
typedef enum
{
  DMSI_REPORT_STATUS_EV_POWER_STATE     = 0x01,
  DMSI_REPORT_STATUS_EV_PIN_STATUS      = 0x02,
  DMSI_REPORT_STATUS_EV_ACTIVATION_STATE= 0x04,
  DMSI_REPORT_STATUS_EV_OPRT_MODE       = 0x08,
  DMSI_REPORT_STATUS_EV_UIM_GET_STATE   = 0x10,
  DMSI_REPORT_STATUS_EV_WD_STATE        = 0x20,
  DMSI_REPORT_STATUS_EV_PRL_INIT        = 0x40,
} qmi_dmsi_report_status_ev_e_type;


/*---------------------------------------------------------------------------
  activation state enum
---------------------------------------------------------------------------*/
typedef enum
{
  DMSI_ACTIVATION_STATE_NOT_ACTIVATED = 0x00,
  DMSI_ACTIVATION_STATE_ACTIVATED     = 0x01,

  /* Call Event values */
  DMSI_ACTIVATION_STATE_CONNECTING    = 0x02,
  DMSI_ACTIVATION_STATE_CONNECTED     = 0x03,
  
  /* OTASP_API values */
  DMSI_ACTIVATION_STATE_AUTHENTICATED = 0x04,
  DMSI_ACTIVATION_STATE_NAM_DLOADED   = 0x05,
  DMSI_ACTIVATION_STATE_MDN_DLOADED   = 0x06,
  DMSI_ACTIVATION_STATE_IMSI_DLOADED  = 0x07,
  DMSI_ACTIVATION_STATE_PRL_DLOADED   = 0x08,
  DMSI_ACTIVATION_STATE_SPC_DLOADED   = 0x09,
  DMSI_ACTIVATION_STATE_COMMIT        = 0x0A,
  
  DMSI_ACTIVATION_STATE_MAX,
  DMSI_ACTIVATION_STATE_MAX32         = 0x10000000
} qmi_dmsi_activation_state_e_type;

/*---------------------------------------------------------------------------
  DMS mmgsdi perso featurs state
---------------------------------------------------------------------------*/
typedef enum
{
  DMSI_MMGSDI_PERSO_STATE_MIN         = -1,
  DMSI_MMGSDI_PERSO_STATE_DEACTIVATED,
  DMSI_MMGSDI_PERSO_STATE_ACTIVATED,
  DMSI_MMGSDI_PERSO_STATE_BLOCKED,
  DMSI_MMGSDI_PERSO_STATE_MAX
} qmi_dmsi_mmgsdi_perso_feature_state;

/*---------------------------------------------------------------------------
  DMS User Lock state enum
---------------------------------------------------------------------------*/
typedef enum
{
  DMSI_USER_LOCK_MIN      = -1,
  DMSI_USER_LOCK_UNLOCKED = 0x00,
  DMSI_USER_LOCK_LOCKED   = 0x01,
  DMSI_USER_LOCK_MAX,
  DMSI_USER_LOCK_MAX32    = 0x10000000
} qmi_dmsi_user_lock_state;

typedef enum
{
  DMSI_CMD_MIN                          = 0,
  DMSI_CMD_RESET                        = DMSI_CMD_MIN,
  DMSI_CMD_SET_EVENT_REPORT,
  DMSI_CMD_GET_DEVICE_CAP,
  DMSI_CMD_GET_DEVICE_MFR,
  DMSI_CMD_GET_DEVICE_MODEL_ID,
  DMSI_CMD_GET_DEVICE_REV_ID,
  DMSI_CMD_GET_MSISDN,
  DMSI_CMD_GET_DEVICE_SERIAL_NUMBERS,
  DMSI_CMD_GET_POWER_STATE,
  DMSI_CMD_SET_UIM_PIN_PROTECTION,
  DMSI_CMD_VERIFY_UIM_PIN,
  DMSI_CMD_UNBLOCK_UIM_PIN,
  DMSI_CMD_CHANGE_UIM_PIN,
  DMSI_CMD_GET_UIM_PIN_STATUS,
  DMSI_CMD_GET_DEVICE_HARDWARE_REV,
  DMSI_CMD_GET_OPERATING_MODE,
  DMSI_CMD_SET_OPERATING_MODE,
  DMSI_CMD_GET_TIME,
  DMSI_CMD_GET_PRL_VER,
  DMSI_CMD_GET_ACTIVATED_STATE,
  DMSI_CMD_ACTIVATE_AUTOMATIC,
  DMSI_CMD_ACTIVATE_MANUAL,
  DMSI_CMD_GET_USER_LOCK_STATE,
  DMSI_CMD_SET_USER_LOCK_STATE,
  DMSI_CMD_SET_USER_LOCK_CODE,
  DMSI_CMD_READ_USER_DATA,
  DMSI_CMD_WRITE_USER_DATA,
  DMSI_CMD_READ_ERI_FILE,
  DMSI_CMD_RESTORE_FACTORY_DEFAULTS,
  DMSI_CMD_VALIDATE_SPC,
  DMSI_CMD_GET_UIM_ICCID,
#ifdef FEATURE_DATA_QMI_ADDENDUM
  DMSI_CMD_GET_HOST_LOCK,
#endif /* FEATURE_DATA_QMI_ADDENDUM */
  DMSI_CMD_UIM_GET_CK_STATUS,
  DMSI_CMD_UIM_SET_CK_PROTECTION,
  DMSI_CMD_UIM_UNBLOCK_CK,
  DMSI_CMD_GET_UIM_IMSI,
  DMSI_CMD_UIM_GET_STATE,
  DMSI_CMD_GET_BAND_CAPABILITY,
  DMSI_CMD_GET_FACTORY_SKU,
  DMSI_CMD_SET_TIME,
  DMSI_CMD_GET_ALT_NET_CONFIG,
  DMSI_CMD_SET_ALT_NET_CONFIG,
#ifdef FEATURE_DATA_QMI_ADDENDUM
  DMSI_CMD_GET_FIRMWARE_PREF,
  DMSI_CMD_SET_FIRMWARE_PREF,
  DMSI_CMD_LIST_STORED_IMAGES,
  DMSI_CMD_DELETE_STORED_IMAGE,
  DMSI_CMD_GET_STORED_IMAGE_INFO,
  DMSI_CMD_GET_BOOT_IMAGE_DOWNLOAD_MODE,
  DMSI_CMD_SET_BOOT_IMAGE_DOWNLOAD_MODE,
#endif /* FEATURE_DATA_QMI_ADDENDUM */
  DMSI_CMD_GET_SW_VERSION,
  DMSI_CMD_SET_SPC, 
  DMSI_CMD_GET_CURRENT_PRL_INFO,
  DMSI_CMD_BIND_SUBSCRIPTION, 
  //ygpark.20141201 +
  #if defined(FEATURE_LGIT_OTADM_FOTA_FUMO_VZW)
  DMSI_CMD_OTADM_FOTA_DOWNLOAD_DONE,		/*== QMI_DMS_OTADM_FOTA_DOWNLOAD_DONE_REQ_V01 at MDM*/
  DMSI_CMD_OTADM_FOTA_DOWNLOAD_STATUS,		/*== QMI_DMS_OTADM_FOTA_DOWNLOAD_STATUS_REQ_V01 at MDM*/
  DMSI_CMD_OTADM_FOTA_INSTALL_RESULT,		/*== QMI_DMS_OTADM_FOTA_INSTALL_RESULT_REQ_V01 at MDM*/
  DMSI_CMD_OTADM_FOTA_DOWNLOAD_DONE_RECEIVED, /*== QMI_DMS_OTADM_FOTA_DOWNLOAD_DONE_RECEIVED_REQ_V01 at MDM*/
  DMSI_CMD_OTADM_FOTA_INSTALL,					/*== QMI_DMS_OTADM_FOTA_INSTALL_REQ_V01 at MDM*/
  DMSI_CMD_OTADM_FOTA_ROAMING_IGNORE, /*== QMI_DMS_OTADM_FOTA_ROAMING_IGNORE_REQ_V01 at MDM*/
  #endif
  //ygpark.20141201 -
  DMSI_CMD_MAX, 
  DMSI_CMD_WIDTH                    = 0xFFFF                        
} qmi_dmsi_cmd_e_type;

typedef enum
{
  QMI_DMS_SRVC_INVALID_IND_MSG,
  QMI_DMS_EVENT_REPORT_IND_MSG
  /* To be filled in in future release */
} qmi_dms_indication_id_type;

typedef enum 
{
  HMC_BOOT_OK = 0x00,
  HMC_EM_MSG,
  HMC_96H_END,
  HMC_ACC_ON,
  HMC_USB_SENSE,
  HMC_GPIO_MAX
} qmi_dms_client_hmc_gpio_e_type;

//05/24/2013 Added by ssaulaby09
//==> FEATURE_LGIT_HMC_SET_96H_MODE_FROM_CONFIG
typedef struct 
{
	unsigned short	time;
	uint8			delay;	//boolean
	unsigned char	delay_time;
	uint8			relcall; //boolean
} dms_modem_96h_config_type;
//<== FEATURE_LGIT_HMC_SET_96H_MODE_FROM_CONFIG

#pragma pack(1)
typedef struct 
{
    boolean enable_rat_mode;
    uint16  enter_rat_mode;
} dms_modem_96h_rat_mode_set;
#pragma pack()

typedef struct 
{
    uint8 gpio_type;
    uint8 gpio_value;
} dms_modem_gpio_mix;

typedef struct 
{
  uint8 enable;
  unsigned char duration;
} dms_modem_alive_type;

typedef struct 
{
  int32 main_dtct; 
  int32 div_dtct;
  int32 main_adc; 
  int32 div_adc;
} dms_modem_ant_detect;

typedef struct 
{
  boolean reset_log_enable; 
  int32 reset_log_normal;
  int32 reset_log_fatal;  
} dms_modem_reset_log;

/* Async notification reporting structure */
typedef union
{
  dms_event_report_ind_msg_v01  dms_status;
} qmi_dms_indication_data_type;

/** @addtogroup dms_qmi_messages
    @{
  */
/** Request Message; Requests the current version of the device. */
typedef struct {
   /* Mandatory */
  /*  Result Code */
  uint8_t usb_status;
}dms_usb_status_ind_msg_v01;


typedef void (*qmi_dms_indication_hdlr_type)
( 
  int                           user_handle,
  qmi_service_id_type           service_id,
  void                          *user_data,
  qmi_dms_indication_id_type    ind_id,
  qmi_dms_indication_data_type  *ind_data
);

EXTERN qmi_client_handle_type tof_tof_qmi_dms_srvc_init_client
(
  const char                    *dev_id,
  qmi_dms_indication_hdlr_type  user_ind_msg_hdlr,
  void                          *user_ind_msg_hdlr_user_data,
  int                           *qmi_err_code
);

EXTERN int tof_tof_qmi_dms_srvc_release_client
(
  int      user_handle,
  int      *qmi_err_code
);

/*---------------------------------------------------------------------------
  QMI asynchronous responses
---------------------------------------------------------------------------*/
typedef struct
{
  int                                       sys_err_code;
  int                                       qmi_err_code;
  qmi_dmsi_cmd_e_type                       rsp_id;
  union
  {
    dms_get_msisdn_resp_msg_v01                 get_msisdn_rsp;
    dms_uim_get_imsi_resp_msg_v01               get_imsi_rsp;
    dms_get_device_serial_numbers_resp_msg_v01  get_device_sn_rsp;
    dms_uim_get_iccid_resp_msg_v01              get_iccid_rsp;
    byte  device_vendor;
    dms_get_operating_mode_resp_msg_v01         get_operating_mode_rsp;
    dms_set_operating_mode_resp_msg_v01         set_operating_mode_rsp;    
    dms_get_modem_sw_version_resp_msg_v01       get_modem_sw_version_rsp;    
    dms_modem_96h_config_type                   modem_96h_mode_rsp;         //05/24/2013 Added by ssaulaby09
    dms_get_current_prl_info_resp_msg_v01       get_current_prl_info_rsp;
    dms_gmmp_domain_manufacture_msg_v01         gmmp_domain_manufacture_rsp;
    dms_gmmp_server_ip_port_num_msg_v01         gmmp_server_ip_port_num_rsp;
    dms_gmmp_gw_id_auth_key_device_id_msg_v01   gmmp_gw_id_auth_key_device_id_rsp;
    dms_gmmp_profile_info_msg_v01               gmmp_profile_info_rsp;
    dms_modem_alive_type                        modem_alive_rsp;
    dms_modem_96h_rat_mode_set                  modem_96h_rat_mode_set_rsp;
    dms_modem_gpio_mix                          gpio_rsp;
    dms_modem_ant_detect						            modem_ant_detect_rsp;
    dms_modem_reset_log							            modem_reset_log_rsp;
    uint8 exception_count;
    dms_modem_exception_info_type_v01 modem_exception_info_rsp;
  }                                         rsp_data;
} qmi_dms_rsp_data_type;

/*===========================================================================
  FUNCTION  qmi_wms_event_reg
===========================================================================*/
EXTERN int qmi_dms_event_reg
(
  int                                             client_handle,
  const dms_set_event_report_req_msg_v01           * params,
  dms_set_event_report_resp_msg_v01                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_get_msisdn
===========================================================================*/
EXTERN int qmi_dms_get_msisdn
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_get_imsi
===========================================================================*/
EXTERN int qmi_dms_get_imsi
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_get_imei
===========================================================================*/
EXTERN int qmi_dms_get_device_serial_number
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_get_prl_version
===========================================================================*/
EXTERN int qmi_dms_get_prl_version
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_get_iccid
===========================================================================*/
EXTERN int qmi_dms_get_iccid
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_get_vendor
===========================================================================*/
EXTERN int qmi_dms_get_vendor
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_set_vendor
===========================================================================*/
EXTERN int qmi_dms_set_vendor
(
  int                                             client_handle,
  byte                                          vendor,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_get_oprt_mode
===========================================================================*/
EXTERN int qmi_dms_get_oprt_mode
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_set_oprt_mode
===========================================================================*/
EXTERN int qmi_dms_set_oprt_mode
(
  int                                             client_handle,
  uint8                                          oprt_mode,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_get_sw_version
===========================================================================*/
EXTERN int qmi_dms_get_sw_version
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_uim_set_pin_protection
===========================================================================*/
/*!
@brief 
  
@return 

@note

*/    
/*=========================================================================*/
EXTERN int qmi_dms_uim_set_pin_protection
(
  int                                               client_handle,
  const dms_uim_set_pin_protection_req_msg_v01    * params,
  qmi_dms_rsp_data_type                           * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_uim_unblock_pin
===========================================================================*/
/*!
@brief 

@return 

@note
  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/
EXTERN int qmi_dms_uim_unblock_pin
(
  int                                                 client_handle,
  const dms_uim_unblock_pin_req_msg_v01             * params,
  qmi_dms_rsp_data_type                             * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_uim_change_pin
===========================================================================*/
/*!
@brief 

@return 

@note
  - Dependencies

  - Side Effects

*/    
/*=========================================================================*/
EXTERN int qmi_dms_uim_change_pin
(
  int                                               client_handle,
  const dms_uim_change_pin_req_msg_v01            * params,
  qmi_dms_rsp_data_type                           * rsp_data
);

//05/24/2013 Added by ssaulaby09(ygpark) : Working 96h mode...
/*===========================================================================
  FUNCTION  qmi_dms_set_96hmode
===========================================================================*/
EXTERN int qmi_dms_set_96hmode
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_get_96hmode
===========================================================================*/
EXTERN int qmi_dms_get_96hmode
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_set_96hmode_rat_mode_set
===========================================================================*/
EXTERN int qmi_dms_set_96hmode_rat_mode_set
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_get_96hmode_rat_mode_set
===========================================================================*/
EXTERN int qmi_dms_get_96hmode_rat_mode_set
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_modem_init
===========================================================================*/
int qmi_dms_modem_init
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

//--> RIL_REQUEST_CDMA_SUBSCRIPTION
/*===========================================================================

  FUNCTION  qmi_nas_dms_fetch_cur_prl_version
  
===========================================================================*/
int qmi_nas_dms_fetch_cur_prl_version(
  uint16 * prl_version,
  int      * qmi_err_code
);
//<-- RIL_REQUEST_CDMA_SUBSCRIPTION

#define QMI_NV_ITEM_SIZE_MAX (128)
/*===========================================================================
  FUNCTION  qmi_dms_nv_read
===========================================================================*/
int qmi_dms_nv_read
(
  int                                            client_handle,
  uint16                                         item,
  uint8                                          *item_data
);

/*===========================================================================
  FUNCTION  qmi_dms_nv_read_ext
===========================================================================*/
int qmi_dms_nv_read_ext
(
  int                                            client_handle,
  uint16                                         item,
  uint16                                         context,
  uint8                                          *item_data
);

/*===========================================================================
  FUNCTION  qmi_dms_nv_write
===========================================================================*/
int qmi_dms_nv_write
(
  int                                            client_handle,
  uint16                                         item,
  uint8                                          *item_data
);

/*===========================================================================
  FUNCTION  qmi_dms_nv_write_ext
===========================================================================*/
int qmi_dms_nv_write_ext
(
  int                                            client_handle,
  uint16                                         item,
  uint16                                         context,
  uint8                                          *item_data
);

/*===========================================================================
  FUNCTION  qmi_dms_get_gmmp_domain_manufacture
===========================================================================*/
int qmi_dms_get_gmmp_domain_manufacture
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_set_gmmp_domain_manufacture
===========================================================================*/
int qmi_dms_set_gmmp_domain_manufacture
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_get_gmmp_server_ip_port_num
===========================================================================*/
int qmi_dms_get_gmmp_server_ip_port_num
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_set_gmmp_server_ip_port_num
===========================================================================*/
int qmi_dms_set_gmmp_server_ip_port_num
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_get_gmmp_gw_id_auth_key_device_id
===========================================================================*/
int qmi_dms_get_gmmp_gw_id_auth_key_device_id
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_set_gmmp_gw_id_auth_key_device_id
===========================================================================*/
int qmi_dms_set_gmmp_gw_id_auth_key_device_id
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_get_gmmp_profile_info
===========================================================================*/
int qmi_dms_get_gmmp_profile_info
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_set_gmmp_profile_info
===========================================================================*/
int qmi_dms_set_gmmp_profile_info
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_get_alive_monitor_config
===========================================================================*/
EXTERN int qmi_dms_get_alive_monitor_config
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_set_alive_monitor_config
===========================================================================*/
EXTERN int qmi_dms_set_alive_monitor_config
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_get_modem_temperature
===========================================================================*/
EXTERN int qmi_dms_get_modem_temperature
(
  int                                             client_handle,
  char                         * temperature
);
/*===========================================================================
  FUNCTION  qmi_dms_get_modem_antdetect
===========================================================================*/
EXTERN int qmi_dms_get_modem_antdetect
(
   int                                             client_handle,
   qmi_dms_rsp_data_type								              * rsp_data
);
/*===========================================================================
  FUNCTION  qmi_dms_get_modem_antdetect
===========================================================================*/
EXTERN int qmi_dms_get_modem_reset_log
(
  int                                             client_handle,
  qmi_dms_rsp_data_type								               * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_set_modem_antdetect
===========================================================================*/
EXTERN int qmi_dms_set_modem_reset_log
(
  int                                             client_handle,
  boolean                                           reset_log_enable,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_max_power_control
===========================================================================*/
int qmi_dms_max_power_control
(
  int                                             client_handle,
  tof_dms_max_power_type_v01 max_pwr, 
  qmi_dms_rsp_data_type                         * rsp_data
);



/*===========================================================================
  FUNCTION  qmi_dms_fs_daig_opendir
===========================================================================*/
int qmi_dms_fs_daig_opendir
(
  int                                          client_handle,
  char                                         *path,
  uint32                                       *dirp,
  int32                                        *diag_errno
);

/*===========================================================================
  FUNCTION  qmi_dms_fs_daig_readdir
===========================================================================*/
int qmi_dms_fs_daig_readdir
(
  int                                         client_handle,
  uint32                                      dirp,
  int32                                       seqno,
  fsdiag_efs2_diag_readdir_rsp_type           *read_dir_rsp
);

/*===========================================================================
  FUNCTION  qmi_dms_fs_daig_closedir
===========================================================================*/
int qmi_dms_fs_daig_closedir
(
  int                                         client_handle,
  uint32                                      dirp,
  int32                                       *diag_errno
);

/*===========================================================================
  FUNCTION  qmi_dms_fs_daig_iter
===========================================================================*/
int qmi_dms_fs_daig_iter
(
  int                                         client_handle,
  uint8                                       file_op,
  fsdiag_iter_dirs_req_type                   *iter_req,
  byte                                        *fs_status,
  fsdiag_iter_rsp_type                        *iter_rsp
);

/*===========================================================================
  FUNCTION  qmi_dms_fs_daig_read
===========================================================================*/
int qmi_dms_fs_daig_read
(
  int                                         client_handle,
  fsdiag_read_req_type                        *read_req,
  byte                                        *fs_status,
  fsdiag_read_rsp_type                        *read_rsp
);

/*===========================================================================
  FUNCTION  qmi_dms_fs_daig_delete
===========================================================================*/
int qmi_dms_fs_daig_delete
(
  int                                         client_handle,
  fsdiag_rmfile_req_type                      *delete_req,
  byte                                        *fs_status
);

/*===========================================================================
  FUNCTION  qmi_dms_fs_daig_write
===========================================================================*/
int qmi_dms_fs_daig_write
(
  int                                         client_handle,
  fsdiag_write_req_type                       *write_req,
  byte                                        *fs_status
);

/*===========================================================================
  FUNCTION  qmi_dms_fs_daig_rmdir
===========================================================================*/
int qmi_dms_fs_daig_rmdir
(
  int                                         client_handle,
  fsdiag_rmdir_req_type                       *rmdir_req,
  byte                                        *fs_status
);

/*===========================================================================
  FUNCTION  qmi_dms_fs_daig_mkdir
===========================================================================*/
int qmi_dms_fs_daig_mkdir
(
  int                                         client_handle,
  fsdiag_mkdir_req_type                       *mkdir_req,
  byte                                        *fs_status
);

/*===========================================================================
  FUNCTION  qmi_dms_get_gpio
===========================================================================*/
int qmi_dms_get_gpio
(
  int                                             client_handle,
  uint8                                         gpio_type,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_set_gpio
===========================================================================*/
int qmi_dms_set_gpio
(
  int                                             client_handle,
  byte                                          gpio_type,
  byte                                          gpio_value,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_gpio_usb_status_info
===========================================================================*/
static int qmi_gpio_usb_status_info
(
  unsigned char                                   *rx_msg,
  int                                             rx_msg_size,
  dms_usb_status_ind_msg_v01 *t_usb_status_ind
);

//ygpark.20141201 +
#if defined(FEATURE_LGIT_OTADM_FOTA_FUMO_VZW)
/*===========================================================================
  FUNCTION  request_fota_download_done_received
===========================================================================*/
EXTERN int request_fota_download_done_received
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);
/*===========================================================================
  FUNCTION  request_fota_install
===========================================================================*/
EXTERN int request_fota_install
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);
/*===========================================================================
  FUNCTION  request_fota_user_cancel
===========================================================================*/
EXTERN int request_fota_user_cancel
(
  int                                             client_handle,
  qmi_dms_rsp_data_type                         * rsp_data
);
/*===========================================================================  
FUNCTION  request_fota_bl_install
===========================================================================*/
EXTERN int request_fota_bl_install
(
int                                             client_handle,  
qmi_dms_rsp_data_type                         * rsp_data
);

#endif /* FEATURE_LGIT_OTADM_FOTA_FUMO_VZW */
//ygpark.20141201 -

/*===========================================================================
  FUNCTION  qmi_dms_set_time
===========================================================================*/
EXTERN int qmi_dms_set_time
(
  int                                               client_handle,
  const dms_set_time_req_msg_v01    * params,
  qmi_dms_rsp_data_type                         * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_get_exception_count
===========================================================================*/
EXTERN int qmi_dms_get_exception_count
(
  int                                             client_handle,
  qmi_dms_rsp_data_type             * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_get_exception_info
===========================================================================*/
EXTERN int qmi_dms_get_exception_info
(
  int                                             client_handle,
  uint8                                          except_index,
  qmi_dms_rsp_data_type             * rsp_data
);

/*===========================================================================
  FUNCTION  qmi_dms_delete_exception_info
===========================================================================*/
EXTERN int qmi_dms_delete_exception_info
(
  int                                             client_handle,
  qmi_dms_rsp_data_type             * rsp_data
);


#ifdef __cplusplus
}
#endif

#endif /* QMI_WDS_SRVC_H  */
