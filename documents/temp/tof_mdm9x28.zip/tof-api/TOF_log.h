#ifndef TOF_LOG_H
#define TOFLOG_H
/*===========================================================================

MODULE
   LOG Print
 
DESCRIPTION
  
===========================================================================*/

/*===========================================================================
                        EDIT HISTORY FOR MODULE

when      who         what, where, why
----------------------------------------------------------------------------
160303    ygpark          create(refer to LGIT_RIL)
===========================================================================*/

//20160303.ygpark :  copy from lte_ril : ysgwak 20101122 ���� �뷮 �̻����� �αװ� ���̸� wmmdll00(01,02).log�� circular�ϵ��� ����
#define LOG_FILE_MAX_SIZE 1024*300

//TODO : Will be change usr/bin to /aplog partition
#define LOG_BASE_PATH  "/data/"  

#define LOG_FILE_PATH LOG_BASE_PATH "lgit-log/"
#define LOG_FILE_PATH_00  LOG_FILE_PATH"tofapi00.log"
#define LOG_FILE_PATH_01  LOG_FILE_PATH"tofapi01.log"
#define LOG_FILE_PATH_02  LOG_FILE_PATH"tofapi02.log"

#define LOG_FILE_CREATE "mkdir "LOG_FILE_PATH

#define MSG_LOW(fmt, a, b, c) log_print(__FILE__, __LINE__, "Log/Low", fmt, a,b,c)
#define MSG_MED(fmt, a, b, c) log_print(__FILE__, __LINE__, "Log/Medium", fmt, a,b,c)
#define MSG_HIGH(fmt, a, b, c) log_print(__FILE__, __LINE__, "Log/High", fmt, a,b,c)
#define MSG_ERROR(fmt, a, b, c) log_print(__FILE__, __LINE__, "Log/Error", fmt, a,b,c)
#define MSG_FATAL(fmt, a, b, c) log_print(__FILE__, __LINE__, "Log/Fatal", fmt, a,b,c)

#define MSG_LOW_4(fmt, a, b, c, d) log_print(__FILE__, __LINE__, "Log/Low", fmt, a,b,c,d)
#define MSG_MED_4(fmt, a, b, c, d) log_print(__FILE__, __LINE__, "Log/Medium", fmt, a,b,c,d)
#define MSG_HIGH_4(fmt, a, b, c, d) log_print(__FILE__, __LINE__, "Log/High", fmt, a,b,c,d)
#define MSG_ERROR_4(fmt, a, b, c, d) log_print(__FILE__, __LINE__, "Log/Error", fmt, a,b,c,d)
#define MSG_FATAL_4(fmt, a, b, c, d) log_print(__FILE__, __LINE__, "Log/Fatal", fmt, a,b,c,d)

/* Debug and error messages */
#define QMI_ERR_MSG_0(str)                      MSG_LOW(str, 0, 0, 0)
#define QMI_ERR_MSG_1(str,arg1)                  MSG_LOW(str, arg1, 0, 0)
#define QMI_ERR_MSG_2(str,arg1,arg2)             MSG_LOW(str, arg1, arg2, 0)
#define QMI_ERR_MSG_3(str,arg1,arg2,arg3)        MSG_LOW(str, arg1, arg2, arg3)
#define QMI_ERR_MSG_4(str,arg1,arg2,arg3,arg4)   MSG_LOW(str, arg1, arg2, arg3, arg4)

#define QMI_DEBUG_MSG_0(str)                       MSG_HIGH(str, 0, 0, 0)
#define QMI_DEBUG_MSG_1(str,arg1)                  MSG_HIGH(str, arg1, 0, 0)
#define QMI_DEBUG_MSG_2(str,arg1,arg2)             MSG_HIGH(str, arg1, arg2, 0)
#define QMI_DEBUG_MSG_3(str,arg1,arg2,arg3)        MSG_HIGH(str, arg1, arg2, arg3)
#define QMI_DEBUG_MSG_4(str,arg1,arg2,arg3,arg4)   MSG_HIGH(str, arg1, arg2, arg3, arg4)

#ifdef FEATURE_TOF_GPS
extern boolean loc_log_test(char *t_in_ptr,int t_size);
#endif /* FEATURE_TOF_GPS */

void log_color_print(char* log_ptr);  


#endif
