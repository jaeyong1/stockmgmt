/******************************************************************************
  @file    tof_event_daemon.c
  @brief   The QMI TOF API

  DESCRIPTION

  INITIALIZATION AND SEQUENCING REQUIREMENTS

  ---------------------------------------------------------------------------
  Copyright (c) 2016 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdarg.h>
#include <ctype.h> 
  
#include <termios.h>
#include <signal.h>
#include <fcntl.h>
  
#include <dirent.h>
#include <sys/signal.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>
  
#include <errno.h>
#include <time.h>
  
#include <pthread.h>

#include "TOF_event_daemon.h"
#include "Debug_string.h"
#include "TOF_log.h"

#include "wmmdiag_packet.h"

//Definition
LINKED_LIST m_eventMsgList;
pthread_t notify_thread = (pthread_t)NULL;
pthread_mutex_t notify_thread_mutex;
pthread_cond_t notify_thread_cond;

//LGIT WAKEUP GPIO
pthread_t monitor_thread = (pthread_t)NULL;
pthread_mutex_t monitor_thread_mutex;
pthread_cond_t monitor_thread_cond;

static BOOL is_notify_thread_initialize = FALSE;


TOF_MODEM_CB qmi_event_notify_call_back;
void* qmi_event_notify_user_data;

void InitializeLinkedList (LINKED_LIST *List)
{
	List->Head = List->Tail = NULL;
	List->thread_alive = FALSE;
}

BOOL IsLinkedListEmpty(LINKED_LIST *List)
{
    BOOL isEmpty;
    
    pthread_mutex_lock(&notify_thread_mutex);
    isEmpty = List->Head == NULL;
    pthread_mutex_unlock(&notify_thread_mutex);
    
    return isEmpty;
}

void InsertTailList (LINKED_LIST *List, PLIST_ITEM Entry)
{
	pthread_mutex_lock(&notify_thread_mutex);
	Entry->Next = NULL;
	if (List->Tail != NULL)
	{
		Entry->Prev = List->Tail;
		List->Tail->Next = (Entry);
	}
	else
	{
		Entry->Prev = NULL;
		List->Head = Entry;
	}
	List->Tail = Entry;

	pthread_cond_signal(&notify_thread_cond);	
	pthread_mutex_unlock(&notify_thread_mutex);
 }

PLIST_ITEM	RemoveHeadList (LINKED_LIST *List)
{
	PLIST_ITEM Entry;

	pthread_mutex_lock(&notify_thread_mutex);
	Entry = List->Head;

	if (List->Head)
	{
		List->Head = List->Head->Next;

		if (List->Head == NULL)
		{
			List->Tail = NULL;
		}
		else
		{
			List->Head->Prev = NULL;
		}
	}
	pthread_mutex_unlock(&notify_thread_mutex);

	return Entry;
}

void EnQEventMsg (UINT8 *data, UINT32 size)
{
    EVENT_MSG   *pMsg;

//    MSG_LOW("EnQEventMsg",0,0,0);
    pMsg = (EVENT_MSG*)malloc (sizeof(EVENT_MSG));
    if (pMsg)
    {
        pMsg->size = size;
        memcpy (pMsg->data, data, size);        
        InsertTailList (&m_eventMsgList, (PLIST_ITEM)pMsg);
    }
}

void DeQEventMsg (UINT8 *data, UINT32 *size)
{
    EVENT_MSG   *pMsg;

    if (IsLinkedListEmpty (&m_eventMsgList))
    {
        *size = 0;
        return;
    }

    pMsg = (EVENT_MSG*)RemoveHeadList (&m_eventMsgList);
    *size = pMsg->size;
    memcpy (data, pMsg->data, *size);        
    free (pMsg);
}

void ClearQEventMsg()
{
    uint8   data[4096];
    uint32  size = 4096;
	//�����ִ� Q�� �����..
    while(TRUE)
    {
	DeQEventMsg (data, &size);
	if (size == 0)
		break;		
    }    
}

//LGIT WAKEUP GPIO
#define WAKEUP_GPIO_CLARION "/sys/devices/1000000.pinctrl/gpio/gpio11/value"
#define WAKEUP_GPIO_BOSCH   "/sys/devices/1000000.pinctrl/gpio/gpio75/value"
#define USB_STATE "/sys/devices/virtual/android_usb/android0/state"

#define USB_STORAGE_NO_ATTACHED 0
#define USB_STORAGE_ATTACHED 1
#define USB_STORAGE_MOUNT_FAILED 2
#define USB_STORAGE_UNMOUNTED 3
#define USB_STORAGE_MOUNTED 4

int prev_wakeup_state = 0;
int prev_usb_storage_state = 0;
int usb_storage_state = 0;

extern wmmdiag_vendor_type vendor_type;
extern void print_system_function_output(char* output,char* cmd);

char *usb_storage_state_tostring(int state)
{
	switch (state) {
	case 0:
		return "USB_STORAGE_NO_ATTACHED";
	break;
	case 1:
		return "USB_STORAGE_ATTACHED";
	break;
	case 2:
		return "USB_STORAGE_MOUNT_FAILED";
	break;
	case 3:
		return "USB_STORAGE_UNMOUNTED";
	break;
	case 4:
		return "USB_STORAGE_MOUNTED";
	break;
	default:
		return "USB_STORAGE_UNKNOWN";
	break;
	}
}

void *EventMonitorThread(void* lpParam)
{
	FILE *fd = NULL;
	FILE *fd2 = NULL;
	int gpio_state = 0;
	int usb_connected = 0;
	int wakeup_state;
	char value[2];
	char usb_state[12] = {0,};
	int usb_storage_attach = 0;
//	char high[4] = "high";
//	char low[3] = "low";
	char buf[256];
	int i=0, j=0;

	TOF_EVENT_NOTIFY_TYPE notify_event={0};

	if (vendor_type == WMM_VENDOR_C_TCU_JPN ||
		vendor_type == WMM_VENDOR_C_TCU_VZW)
	{
		fd = fopen(WAKEUP_GPIO_CLARION, "r");
	}
	else if (vendor_type == WMM_VENDOR_B_EU ||
		vendor_type == WMM_VENDOR_B_CHN)
	{
		fd = fopen(WAKEUP_GPIO_BOSCH, "r");
	}

	fd2 = fopen(USB_STATE, "r");

	while(1) {
//#if FEATURE_LGIT_MONITOR_USB_STORAGE
		memset(buf, 0, 256);

		switch (usb_storage_state) {
		case USB_STORAGE_NO_ATTACHED:
			print_system_function_output(buf, "ls /sys/bus/usb/drivers/usb-storage | grep 1-1");
			if (strstr(buf, "1-1"))
			{
				printf("attach ums : %s\n", buf);
				usb_storage_attach = 1;
				usb_storage_state = USB_STORAGE_ATTACHED;
			}
		break;
		case USB_STORAGE_ATTACHED:
		for (j=0; j<5; j++) {
			if (usb_storage_state == USB_STORAGE_MOUNTED)
				continue;
			printf("check mount %d\n", j+1);

			system("mount /dev/sda /mnt/usb_storage");
				for (i=0; i<100; i++)
				{
					print_system_function_output(buf, "mount | grep usb_storage");
					if (strstr(buf, "usb_storage"))
					{
						printf("usb_storage mounted\n");
						usb_storage_state = USB_STORAGE_MOUNTED;
						break;
					}
				}
		}

		if (usb_storage_state != USB_STORAGE_MOUNTED)
		{
			printf("usb_storage_mount_failed\n");
			usb_storage_state = USB_STORAGE_MOUNT_FAILED;
		}
		break;
		case USB_STORAGE_MOUNT_FAILED:
//			printf("need mount fail handle\n");
		break;
		case USB_STORAGE_UNMOUNTED:
			usb_storage_attach = 0;
			print_system_function_output(buf, "ls /sys/bus/usb/drivers/usb-storage | grep 1-1");
			if (strstr(buf, "1-1"))
			{
				usb_storage_attach = 1;
			}

			print_system_function_output(buf, "mount | grep usb_storage");
			if (strstr(buf,"usb_storage"))
			{
				printf("usb_storage mounted\n");
				usb_storage_state = USB_STORAGE_MOUNTED;
				break;
			}
			if (usb_storage_attach == 0) {
				printf("usb_storage_no_attached\n");
				usb_storage_state = USB_STORAGE_NO_ATTACHED;
			}
		break;
		case USB_STORAGE_MOUNTED:
			usb_storage_attach = 0;
			print_system_function_output(buf, "ls /sys/bus/usb/drivers/usb-storage | grep 1-1");
			if (strstr(buf, "1-1"))
			{
				usb_storage_attach = 1;
			}
			if (usb_storage_attach == 0)
			{
				printf("usb_storage_no_attached do umount\n");
				system("umount /mnt/usb_storage");
				usb_storage_state = USB_STORAGE_NO_ATTACHED;
			}
		break;
		} // switch

		if (usb_storage_state != prev_usb_storage_state)
		{
			printf("send TOF_EVENT_USB_STORAGE_CHANGED %s\n", usb_storage_state_tostring(usb_storage_state));
			notify_event.dwEvent = TOF_EVENT_USB_STORAGE_CHANGED;
			notify_event.lParam_malloc = TRUE;
			notify_event.lParam = (DWORD)malloc(256);
			memcpy((char*)notify_event.lParam, usb_storage_state_tostring(usb_storage_state), 256);
			MSG_LOW("EventNotifyEnqueue : TOF_EVENT_USB_STORAGE_CHANGED : %s\n", (char*)notify_event.lParam,0,0);
			EnQEventMsg((uint8*)&notify_event, sizeof(TOF_EVENT_NOTIFY_TYPE));
			prev_usb_storage_state = usb_storage_state;
		}
//#endif

//#if FEATURE_LGIT_MONITOR_WAKEUP
		if (fd == NULL || fd2 == NULL)
		{
			MSG_LOW("fail to open gpio node\n",0,0,0);
		}
		else
		{
			fread(value, sizeof(char), sizeof(value), fd);
			fread(usb_state, sizeof(char), sizeof(usb_state), fd2);

			if (!strncmp(value, "0", sizeof(char)))
			{
				gpio_state = 0;
			}
			else if (!strncmp(value, "1", sizeof(char)))
			{
				gpio_state = 1;
			}
			else
			{
				MSG_LOW("Invalid gpio state = %s\n", value,0,0);
//				return 0;
			}

			usb_connected = strncmp(usb_state, "DISCONNECTED", sizeof(usb_state));

			if (usb_connected && gpio_state)
			{
					wakeup_state = 1;
			}
			else //if (!usb_connected || !current_gpio_state)
			{
					MSG_LOW("wakeup_state = 0\n",0,0,0);
					wakeup_state = 0;
			}

			if (wakeup_state && (prev_wakeup_state == 0)) // sleep to wakeup
			{
				notify_event.dwEvent = TOF_EVENT_WAKEUP_STATE_CHANGED;
//				notify_event.lParam_malloc = TRUE;
//				notify_event.lParam = (DWORD)malloc(256);
//				memcpy((char*)notify_event.lParam, gpio_state == 1 ? high:low, 256);
				MSG_LOW("EventNotifyEnqueue : TOF_EVENT_WAKEUP_STATE_CHANGED : %s\n", (char*)notify_event.lParam,0,0);
				EnQEventMsg((uint8*)&notify_event, sizeof(TOF_EVENT_NOTIFY_TYPE));
			}
			else
			{
//				printf("wakeup_state is not changed\n");
			}

			prev_wakeup_state = wakeup_state;
		}
//#endif FEATURE_LGIT_MONITOR_WAKEUP

		usleep(100 * 1000); // 100ms
	}

	fclose(fd);
	fclose(fd2);
}

void *EventNotifyThread(void* lpParam)
{
  uint8   data[4096];
  uint32  size = 4096;
  TOF_EVENT_NOTIFY_TYPE *notify_ptr;

  MSG_LOW("EventNotifyThread START\n",0,0,0);
  while(m_eventMsgList.thread_alive)
  {
    DeQEventMsg (data, &size);

    if (size == 0)
    {
      pthread_mutex_lock(&notify_thread_mutex);
      pthread_cond_wait(&notify_thread_cond, &notify_thread_mutex);
      pthread_mutex_unlock(&notify_thread_mutex);
      continue;
    }

    notify_ptr = (TOF_EVENT_NOTIFY_TYPE*)data;

   // printf("EventNotifyThread: %s param1:%d, param2:%d\r\n", EVENT_E_TYPE_str(notify_ptr->dwEvent), notify_ptr->wParam, notify_ptr->lParam);
    if(qmi_event_notify_call_back)
    {
      qmi_event_notify_call_back(notify_ptr->dwEvent, notify_ptr->wParam, notify_ptr->lParam, qmi_event_notify_user_data);
     }

    //Malloc �Ǿ� �ִٸ� Free���ش�.
    if(notify_ptr->wParam_malloc)
      free((void*)notify_ptr->wParam);

    if(notify_ptr->lParam_malloc)
      free((void*)notify_ptr->lParam);
  }

  ClearQEventMsg();
  pthread_exit((void *) 0); 
  MSG_LOW("EventNotifyThread END\n",0,0,0);

  return 0;
}

void EventNotifyEnqueue(DWORD event, uint32 wParam, uint32 lParam)
{
	TOF_EVENT_NOTIFY_TYPE notify_event={0};//�ݵ�� �ʱ�ȭ

	notify_event.dwEvent = event;
	notify_event.wParam = wParam;
	notify_event.lParam = lParam;

   // printf("EventNotifyEnqueue : EventNotifyEnqueue\r\n");
	//������ Address�� �ѱ�� ���� ���⼭ Malloc�� �ؼ� �ѱ�� DeQueue���� Free����.
	switch(event)
	{
      case TOF_EVENT_GET_MODEM_VERSION:
        MSG_LOW("EventNotifyEnqueue : TOF_EVENT_GET_MODEM_VERSION\n",0,0,0);
        //notify_event.dwEvent = event;
        //notify_event.lParam_malloc = TRUE;
        //notify_event.lParam = (dword)malloc(sizeof(STRING_SIZE));;		
        //memcpy((char*)notify_event.lParam, (char*)lParam, sizeof(STRING_SIZE));
      break;

      case TOF_EVENT_NETWORK_STATE_CHANGED:        
        notify_event.dwEvent = event;
        notify_event.lParam_malloc = TRUE;
        notify_event.lParam = (DWORD)malloc(256);
        memcpy((char*)notify_event.lParam, (char*)lParam, 256);
        MSG_LOW("EventNotifyEnqueue : TOF_EVENT_NETWORK_STATE_CHANGED : %s\n", (char*)notify_event.lParam,0,0);
      break;

    case TOF_EVENT_SIGNAL_STRENGTH_CHANGED:        
      notify_event.dwEvent = event;
      notify_event.lParam_malloc = TRUE;
      notify_event.lParam = (DWORD)malloc(sizeof(TOF_SignalStrength));
      memcpy((char*)notify_event.lParam, (char*)lParam, sizeof(TOF_SignalStrength));
      //printf("EventNotifyEnqueue : TOF_EVENT_SIGNAL_STRENGTH_CHANGED : %s\r\n", (char*)notify_event.lParam);
    break;

    case TOF_EVENT_RESPONSE_CALL_STATE_CHANGED:
      MSG_LOW( "EventNotifyEnqueue : TOF_EVENT_RESPONSE_CALL_STATE_CHANGED\n",0,0,0);
    break;

    case TOF_EVENT_POSITION_REPORT_IND:        
      notify_event.dwEvent = event;
      notify_event.lParam_malloc = TRUE;
      notify_event.lParam = (DWORD)malloc(256);
      memcpy((char*)notify_event.lParam, (char*)lParam, 256);
      MSG_LOW("EventNotifyEnqueue : TOF_EVENT_POSITION_REPORT_IND : %s\n", (char*)notify_event.lParam,0,0);
    break;

    case TOF_EVENT_POSITION_NMEA_REPORT_IND:        
      notify_event.dwEvent = event;
      notify_event.lParam_malloc = TRUE;      
      notify_event.lParam = (DWORD)malloc(256);
      memcpy((char*)notify_event.lParam, (char*)lParam, 256);
      MSG_LOW("EventNotifyEnqueue : TOF_EVENT_POSITION_NMEA_REPORT_IND : %s\n", (char*)notify_event.lParam,0,0);
    break;

    case TOF_EVENT_GPS_SET_OPERATION_MODE_IND:
      notify_event.dwEvent = event;
      notify_event.lParam_malloc = TRUE;      
      notify_event.lParam = (DWORD)malloc(256);
      memcpy((char*)notify_event.lParam, (char*)lParam, 256);
      MSG_LOW("EventNotifyEnqueue : TOF_EVENT_GPS_SET_OPERATION_MODE_IND : %s\n", (char*)notify_event.lParam,0,0);
    break;

    case TOF_EVENT_GPS_GET_OPERATION_MODE_IND:
      notify_event.dwEvent = event;
      notify_event.lParam_malloc = TRUE;      
      notify_event.lParam = (DWORD)malloc(256);
      memcpy((char*)notify_event.lParam, (char*)lParam, 256);
      MSG_LOW("EventNotifyEnqueue : TOF_EVENT_GPS_GET_OPERATION_MODE_IND : %s\n", (char*)notify_event.lParam,0,0);
    break;

    case TOF_EVENT_GPS_SET_NMEA_TYPE_IND:
      notify_event.dwEvent = event;
      notify_event.lParam_malloc = TRUE;      
      notify_event.lParam = (DWORD)malloc(256);
      memcpy((char*)notify_event.lParam, (char*)lParam, 256);
      MSG_LOW("EventNotifyEnqueue : TOF_EVENT_GPS_SET_NMEA_TYPE_IND : %s\n", (char*)notify_event.lParam,0,0);
    break;

    case TOF_EVENT_GPS_GET_NMEA_TYPE_IND:
      notify_event.dwEvent = event;
      notify_event.lParam_malloc = TRUE;      
      notify_event.lParam = (DWORD)malloc(256);
      memcpy((char*)notify_event.lParam, (char*)lParam, 256);
      MSG_LOW("EventNotifyEnqueue : TOF_EVENT_GPS_SET_NMEA_TYPE_IND : %s\n", (char*)notify_event.lParam,0,0);
    break;

    case TOF_EVENT_GPIO_USB_CONNECTED_IND:
      notify_event.dwEvent = event;
      notify_event.lParam_malloc = TRUE;
      notify_event.lParam = (DWORD)malloc(256);
      memcpy((char*)notify_event.lParam, (char*)lParam, 256);
      MSG_LOW("EventNotifyEnqueue : TOF_EVENT_GPIO_USB_CONNECTED_IND : %s\n", (char*)notify_event.lParam,0,0);
    break;

    case TOF_EVENT_GET_REGISTERED_EVENT_IND:
      notify_event.dwEvent = event;
      notify_event.lParam_malloc = TRUE;
      notify_event.lParam = (DWORD)malloc(256);
      memcpy((char*)notify_event.lParam, (char*)lParam, 256);
      MSG_LOW("EventNotifyEnqueue : TOF_EVENT_GET_REGISTERED_EVENT_IND : %s\n", (char*)notify_event.lParam,0,0);
    break;

    case TOF_EVENT_ACS_FAIL_IND:
      notify_event.dwEvent = event;
      notify_event.lParam_malloc = TRUE;
      notify_event.lParam = (DWORD)malloc(256);
      memcpy((char*)notify_event.lParam, (char*)lParam, 256);
      MSG_LOW("EventNotifyEnqueue : TOF_EVENT_ACS_FAIL_IND : %s\n", (char*)notify_event.lParam,0,0);
    break;

    case TOF_EVENT_SET_SUPL_SERVER_INFO_IND:
      notify_event.dwEvent = event;
      notify_event.lParam_malloc = TRUE;
      notify_event.lParam = (DWORD)malloc(256);
      memcpy((char*)notify_event.lParam, (char*)lParam, 256);
      MSG_LOW("EventNotifyEnqueue : TOF_EVENT_SET_SUPL_SERVER_INFO_IND : %s\n", (char*)notify_event.lParam,0,0);
    break;
    
    case TOF_EVENT_GET_SUPL_SERVER_INFO_IND:
      notify_event.dwEvent = event;
      notify_event.lParam_malloc = TRUE;
      notify_event.lParam = (DWORD)malloc(256);
      memcpy((char*)notify_event.lParam, (char*)lParam, 256);
      MSG_LOW("EventNotifyEnqueue : TOF_EVENT_GET_SUPL_SERVER_INFO_IND : %s\n", (char*)notify_event.lParam,0,0);
    break;

    case TOF_EVENT_DELETE_ASSIST_DATA_IND:
      notify_event.dwEvent = event;
      notify_event.lParam_malloc = TRUE;
      notify_event.lParam = (DWORD)malloc(256);
      memcpy((char*)notify_event.lParam, (char*)lParam, 256);
      MSG_LOW("EventNotifyEnqueue : TOF_EVENT_DELETE_ASSIST_DATA_IND : %s\n", (char*)notify_event.lParam,0,0);
    break;

	case TOF_EVENT_RESPONSE_CALL_STATE_CHANGED_TO_DELAYED_HANGUP:
	  notify_event.dwEvent = event;
	  notify_event.wParam = wParam; //call id
      MSG_LOW("EventNotifyEnqueue : TOF_EVENT_RESPONSE_CALL_STATE_CHANGED_TO_DELAYED_HANGUP, call id = %d\n", wParam,0,0);
	   return;///////////////////////
	  /////////
     //	DISABLE 
	  /////////
      break;

	
	case TOF_EVENT_RESPONSE_CALL_STATE_CHANGED_CALLMSG_RAWDATA:
	  notify_event.dwEvent = event;
	  notify_event.lParam_malloc = TRUE;
	  notify_event.lParam = (DWORD)malloc(512);
	  memcpy((char*)notify_event.lParam, (char*)lParam, 512);
      MSG_LOW("EventNotifyEnqueue : TOF_EVENT_RESPONSE_CALL_STATE_CHANGED_CALLMSG_RAWDATA\n",0,0,0);     
	  break;

    // Added Jamming detection Indication
    case TOF_EVENT_JAMMING_RF_REPORT_IND:        
      notify_event.dwEvent = event;
      notify_event.lParam_malloc = TRUE;
      notify_event.lParam = (DWORD)malloc(256);
      memcpy((char*)notify_event.lParam, (char*)lParam, 256);
      MSG_LOW("EventNotifyEnqueue : TOF_EVENT_JAMMING_RF_REPORT_IND : %s\n", (char*)notify_event.lParam,0,0);
    break;    

   case TOF_EVENT_RESPONSE_ASYNC_NETWORK_SEARCH_FINISHED:
      notify_event.dwEvent = event;
	  notify_event.lParam_malloc = TRUE;
	  notify_event.lParam = (DWORD)malloc(512);
	  memcpy((char*)notify_event.lParam, (char*)lParam, 512);
	  MSG_LOW("EventNotifyEnqueue : TOF_EVENT_RESPONSE_ASYNC_NETWORK_SEARCH_FINISHED\n",0,0,0);     
   	  break;
	  
    default:
    break;
  }
  
  EnQEventMsg((uint8*)&notify_event, sizeof(TOF_EVENT_NOTIFY_TYPE));

}

//LGIT WAKEUP GPIO
void StartMonitorThread(void)
{
	printf("=== StartMonitorThread===\r\n");

	if(monitor_thread != (pthread_t)NULL)
	{
		printf("Monitor thread is already running, thread id: %d\r\n", (int)monitor_thread);
		return;
	}
	else
	{
		pthread_mutex_init(&monitor_thread_mutex, NULL);
		pthread_cond_init(&monitor_thread_cond, NULL);
	}

	int threadID;
	threadID = pthread_create(&monitor_thread, NULL, EventMonitorThread, NULL);
	if(threadID < 0)
	{
		printf("Can't Create Monitor thread, threadID: %d\r\n", threadID);
		return;
	}
}


void StartEventNotifyThread(void)
{
    printf("=== StartEventNotifyThread===\r\n");

//LGIT WAKEUP GPIO
	if(monitor_thread == (pthread_t)NULL)
	{
		StartMonitorThread();
	}

	if(notify_thread != (pthread_t)NULL)
	{
		printf("Notify thread is already running, thread id: %d\r\n", notify_thread);
		return;
	}

	if(is_notify_thread_initialize == FALSE)
	{        
		InitializeLinkedList(&m_eventMsgList);
		pthread_mutex_init(&notify_thread_mutex, NULL);
		pthread_cond_init(&notify_thread_cond, NULL);
		is_notify_thread_initialize = TRUE;
	}
	
	m_eventMsgList.thread_alive = TRUE;

	int threadID;
	threadID = pthread_create(&notify_thread, NULL, EventNotifyThread, NULL);
	if(threadID < 0)
	{
		printf("Can't Create Notify thread, threadID: %d\r\n", threadID);
		return;
	}
}

void EndEventNotifyThread(void)
{
     printf("=== EndEventNotifyThread===\r\n");
     
	if(m_eventMsgList.thread_alive == FALSE)
	{
		printf("Notify thread is not running\r\n");
		return;
	}
	
	m_eventMsgList.thread_alive = FALSE;

	// disable event notification and wait for thread
	usleep(100*1000);	
	
	pthread_detach(notify_thread);  // pthread_join(notify_thread, NULL); //ysgwak 20101101 notify_thread destroy ����
	pthread_cond_destroy(&notify_thread_cond);
	pthread_mutex_destroy(&notify_thread_mutex);
	is_notify_thread_initialize = FALSE;
	notify_thread = (pthread_t)NULL;
}

