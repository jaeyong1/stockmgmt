/******************************************************************************
  @file    qmi_ims_srvc.c
  @brief   The QMI IMS service layer.

  DESCRIPTION
  QMI IMS service routines.  

  INITIALIZATION AND SEQUENCING REQUIREMENTS
  qmi_ims_srvc_init_client() needs to be called before sending or receiving of any 
  IMS service messages

  ---------------------------------------------------------------------------
  Copyright (c) 2013 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/

#include <string.h>
#include "qmi_i.h"
#include "qmi_service.h"
#include "qmi_ims_srvc.h"
#include "qmi_util.h"

#define QMI_IMS_STD_MSG_SIZE   QMI_MAX_STD_MSG_SIZE

/*Service Message Definition*/
/** @addtogroup imss_qmi_msg_ids
    @{
  */
#define QMI_IMS_SETTINGS_SET_SIP_CONFIG_REQ_V01 0x0020
#define QMI_IMS_SETTINGS_SET_SIP_CONFIG_RSP_V01 0x0020
#define QMI_IMS_SETTINGS_SET_REG_MGR_CONFIG_REQ_V01 0x0021
#define QMI_IMS_SETTINGS_SET_REG_MGR_CONFIG_RSP_V01 0x0021
#define QMI_IMS_SETTINGS_SET_SMS_CONFIG_REQ_V01 0x0022
#define QMI_IMS_SETTINGS_SET_SMS_CONFIG_RSP_V01 0x0022
#define QMI_IMS_SETTINGS_SET_USER_CONFIG_REQ_V01 0x0023
#define QMI_IMS_SETTINGS_SET_USER_CONFIG_RSP_V01 0x0023
#define QMI_IMS_SETTINGS_SET_VOIP_CONFIG_REQ_V01 0x0024
#define QMI_IMS_SETTINGS_SET_VOIP_CONFIG_RSP_V01 0x0024
#define QMI_IMS_SETTINGS_GET_SIP_CONFIG_REQ_V01 0x0025
#define QMI_IMS_SETTINGS_GET_SIP_CONFIG_RSP_V01 0x0025
#define QMI_IMS_SETTINGS_GET_REG_MGR_CONFIG_REQ_V01 0x0026
#define QMI_IMS_SETTINGS_GET_REG_MGR_CONFIG_RSP_V01 0x0026
#define QMI_IMS_SETTINGS_GET_SMS_CONFIG_REQ_V01 0x0027
#define QMI_IMS_SETTINGS_GET_SMS_CONFIG_RSP_V01 0x0027
#define QMI_IMS_SETTINGS_GET_USER_CONFIG_REQ_V01 0x0028
#define QMI_IMS_SETTINGS_GET_USER_CONFIG_RSP_V01 0x0028
#define QMI_IMS_SETTINGS_GET_VOIP_CONFIG_REQ_V01 0x0029
#define QMI_IMS_SETTINGS_GET_VOIP_CONFIG_RSP_V01 0x0029
#define QMI_IMS_SETTINGS_CONFIG_IND_REG_REQ_V01 0x002A
#define QMI_IMS_SETTINGS_CONFIG_IND_REG_RSP_V01 0x002A
#define QMI_IMS_SETTINGS_SIP_CONFIG_IND_V01 0x002B
#define QMI_IMS_SETTINGS_REG_MGR_CONFIG_IND_V01 0x002C
#define QMI_IMS_SETTINGS_SMS_CONFIG_IND_V01 0x002D
#define QMI_IMS_SETTINGS_USER_CONFIG_IND_V01 0x002E
#define QMI_IMS_SETTINGS_VOIP_CONFIG_IND_V01 0x002F
#define QMI_IMS_SETTINGS_SET_PRESENCE_CONFIG_REQ_V01 0x0030
#define QMI_IMS_SETTINGS_SET_PRESENCE_CONFIG_RSP_V01 0x0030
#define QMI_IMS_SETTINGS_GET_PRESENCE_CONFIG_REQ_V01 0x0031
#define QMI_IMS_SETTINGS_GET_PRESENCE_CONFIG_RSP_V01 0x0031
#define QMI_IMS_SETTINGS_PRESENCE_CONFIG_IND_V01 0x0032
#define QMI_IMS_SETTINGS_SET_MEDIA_CONFIG_REQ_V01 0x0033
#define QMI_IMS_SETTINGS_SET_MEDIA_CONFIG_RSP_V01 0x0033
#define QMI_IMS_SETTINGS_GET_MEDIA_CONFIG_REQ_V01 0x0034
#define QMI_IMS_SETTINGS_GET_MEDIA_CONFIG_RSP_V01 0x0034
#define QMI_IMS_SETTINGS_MEDIA_CONFIG_IND_V01 0x0035
#define QMI_IMS_SETTINGS_SET_QIPCALL_CONFIG_REQ_V01 0x0036
#define QMI_IMS_SETTINGS_SET_QIPCALL_CONFIG_RSP_V01 0x0036
#define QMI_IMS_SETTINGS_GET_QIPCALL_CONFIG_REQ_V01 0x0037
#define QMI_IMS_SETTINGS_GET_QIPCALL_CONFIG_RSP_V01 0x0037
#define QMI_IMS_SETTINGS_QIPCALL_CONFIG_IND_V01 0x0038
#define QMI_IMS_SETTINGS_GET_SIP_READ_ONLY_CONFIG_REQ_V01 0x0039
#define QMI_IMS_SETTINGS_GET_SIP_READ_ONLY_CONFIG_RSP_V01 0x0039
#define QMI_IMS_SETTINGS_SIP_READ_ONLY_CONFIG_IND_V01 0x003A
#define QMI_IMS_SETTINGS_GET_NETWORK_READ_ONLY_CONFIG_REQ_V01 0x003D
#define QMI_IMS_SETTINGS_GET_NETWORK_READ_ONLY_CONFIG_RSP_V01 0x003D
#define QMI_IMS_SETTINGS_NETWORK_READ_ONLY_CONFIG_IND_V01 0x003E
#define QMI_IMS_SETTINGS_GET_VOIP_READ_ONLY_CONFIG_REQ_V01 0x003F
#define QMI_IMS_SETTINGS_GET_VOIP_READ_ONLY_CONFIG_RSP_V01 0x003F
#define QMI_IMS_SETTINGS_GET_USER_READ_ONLY_CONFIG_REQ_V01 0x0040
#define QMI_IMS_SETTINGS_GET_USER_READ_ONLY_CONFIG_RSP_V01 0x0040
#define QMI_IMS_SETTINGS_GET_REG_MGR_READ_ONLY_CONFIG_REQ_V01 0x0041
#define QMI_IMS_SETTINGS_GET_REG_MGR_READ_ONLY_CONFIG_RSP_V01 0x0041
#define QMI_IMS_SETTINGS_GET_RCS_AUTO_CONFIG_READ_ONLY_CONFIG_REQ_V01 0x0042
#define QMI_IMS_SETTINGS_GET_RCS_AUTO_CONFIG_READ_ONLY_CONFIG_RSP_V01 0x0042
#define QMI_IMS_SETTINGS_GET_RCS_IMSCORE_AUTO_CONFIG_READ_ONLY_CONFIG_REQ_V01 0x0043
#define QMI_IMS_SETTINGS_GET_RCS_IMSCORE_AUTO_CONFIG_READ_ONLY_CONFIG_RSP_V01 0x0043
#define QMI_IMS_SETTINGS_SET_REG_MGR_EXTENDED_CONFIG_REQ_V01 0x0044
#define QMI_IMS_SETTINGS_SET_REG_MGR_EXTENDED_CONFIG_RSP_V01 0x0044
#define QMI_IMS_SETTINGS_GET_REG_MGR_EXTENDED_CONFIG_REQ_V01 0x0045
#define QMI_IMS_SETTINGS_GET_REG_MGR_EXTENDED_CONFIG_RSP_V01 0x0045
#define QMI_IMS_SETTINGS_REG_MGR_EXTENDED_CONFIG_IND_V01 0x0046
#define QMI_IMS_SETTINGS_SET_POL_MGR_CONFIG_REQ_V01 0x0047
#define QMI_IMS_SETTINGS_SET_POL_MGR_CONFIG_RSP_V01 0x0047
#define QMI_IMS_SETTINGS_GET_POL_MGR_CONFIG_REQ_V01 0x0048
#define QMI_IMS_SETTINGS_GET_POL_MGR_CONFIG_RSP_V01 0x0048
#define QMI_IMS_SETTINGS_POL_MGR_CONFIG_IND_V01 0x0049
/**
    @}
  */

HANDLE m_hIMSServiceThread;

//Global Variable
static int ims_service_initialized = FALSE;

/*===========================================================================
  FUNCTION  qmi_ims_settings_qipcall_config_ind
===========================================================================*/
/*!
@brief 
  This function will decode TLV's dealing with serving system info.  It
  is used both by the get serving system info cmd response as well as the
  serving system indication.   
  
@return 
  QMI_INTERNAL_ERR if an error was encountered, QMI_NO_ERR otherwise.

*/
/*=========================================================================*/
static int
qmi_ims_settings_qipcall_config_ind

(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  ims_0038_ind_s           *ims_0038_ind  
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;  

  memset(ims_0038_ind, 0, sizeof(ims_0038_ind_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                                            &rx_buf_len,
                                            &type,
                                            &length,
                                            &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case IMS_0038_IND_T12:
      {
        ims_0038_ind->t12_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,ims_0038_ind->t12.volte_enabled);
      }
      break;  

      default:
        QMI_DEBUG_MSG_1 ("qmi_ims_settings_qipcall_config_ind: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

/*===========================================================================

FUNCTION  ims_serving_system_ind_process

===========================================================================*/
void ims_qipcall_config_ind_process(ims_0038_ind_s *ims_0038_ind)
{
  int volte_enabled = -1;

  // VOIP Enabled Status
  if (ims_0038_ind->t12_valid)
  {
    MSG_HIGH("[IMS] volte enabled = %d", ims_0038_ind->t12.volte_enabled, 0, 0);
    volte_enabled = (int)ims_0038_ind->t12.volte_enabled;

    //if(wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW)
     // Send_UnsolicitedResponse (RIL_UNSOL_HK_LTE_VOLTE_ENABLED, &volte_enabled, sizeof(int));    
  }
}

/*===========================================================================
  FUNCTION  qmi_ims_srvc_indication_cb
===========================================================================*/
/*!
@brief 
  This is the callback function that will be called by the generic
  services layer to report asynchronous indications.  This function will
  process the indication TLV's and then call the user registered
  functions with the indication data.   
  
@return 
  None.

@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/

static void
qmi_ims_srvc_indication_cb
(
  int                   user_handle,
  qmi_service_id_type   service_id,
  unsigned long         msg_id,
  void                                *user_ind_msg_hdlr,
  void                                *user_ind_msg_hdlr_user_data,
  unsigned char         *rx_msg_buf,
  int                   rx_msg_len
)
{
  qmi_ims_indication_id_type      ind_id = QMI_IMS_SRVC_INVALID_IND_MSG;
  qmi_ims_indication_data_type    ind_data;
  qmi_ims_indication_hdlr_type    user_ind_hdlr;

  /* Make sure that the user indication handler isn't NULL */
  if (user_ind_msg_hdlr == NULL)
  {
    return;
  }

  printf ("qmi_ims_srvc_indication_cb::msg_id 0x%lx \r\n ",msg_id);

  switch (msg_id)
  {
    case QMI_IMS_SETTINGS_REG_MGR_CONFIG_IND_V01:
      break;

    case QMI_IMS_SETTINGS_QIPCALL_CONFIG_IND_V01:
    {
      ind_id = QMI_IMS_SRVC_SETTINGS_QIPCALL_CONFIG_IND;
      printf ("qmi_ims_srvc_indication_cb::QMI_IMS_SRVC_SETTINGS_QIPCALL_CONFIG_IND \r\n ");
      
      if (qmi_ims_settings_qipcall_config_ind(rx_msg_buf,
                                          rx_msg_len,
                                          &ind_data.ims_0038_ind) < 0)
      {
        printf ("qmi_ims_srvc_indication_cb: Failure in get serving system IND data\r\n ");
        return;
      }
      ims_qipcall_config_ind_process(&ind_data.ims_0038_ind);        
    }
    break;        

    default:
      printf ("qmi_ims_srvc_indication_cb::Invalid indication msg_id received %lx\n ",msg_id);
    break;
  }/*Switch*/


  /* If we got a valid/supported indication, report it */
  if (ind_id != QMI_IMS_SRVC_INVALID_IND_MSG)
  {
    /* Get properly cast pointer to user indication handler */
    /*lint -e{611} */
    user_ind_hdlr = (qmi_ims_indication_hdlr_type) user_ind_msg_hdlr;

    /* Call user registered handler */
    user_ind_hdlr (user_handle,
                   service_id,
                   user_ind_msg_hdlr_user_data,
                   ind_id,
                   &ind_data);
  }    

}

/*===========================================================================
  FUNCTION  qmi_dms_reg_ind_hdlr
===========================================================================*/
/*!
@brief 
  This function is a callback that will be called once during client
  initialization  
  
@return 
  None.

@note

  - Dependencies
    - None.

  - Side Effects
    - None.
*/    
/*=========================================================================*/
int qmi_ims_reg_ind_hdlr (qmi_service_ind_rx_hdlr  user_ind_msg_hdlr)
{
  int  rc = QMI_NO_ERR;
  if (!ims_service_initialized)
  {

    rc = qmi_service_set_srvc_functions (QMI_IMS_VIDEO_SERVICE,
                                 user_ind_msg_hdlr);
    if (rc != QMI_NO_ERR)
    {
      printf("qmi_ims_srvc_init: set srvc functions returns err=%d\n",rc);
    }
    else
    {
      printf("qmi_ims_srvc_init: IMS successfully initialized\r\n");
      ims_service_initialized = TRUE;
    }
  }
  else
  {
    printf("qmi_ims_srvc_init: Init failed, IMS already initialized\r\n");
  }
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_ims_srvc_init_client
===========================================================================*/
/*!
@brief 
  This function is called to initialize the IMS service.  This function
  must be called prior to calling any other IMS service functions.
  For the time being, the indication handler callback and user data
  should be set to NULL until this is implemented.  Also note that this
  function may be called multiple times to allow for multiple, independent
  clients.   
  
@return 
  0 if abort operation was sucessful, < 0 if not.  If return code is 
  QMI_INTERNAL_ERR, then the qmi_err_code will be valid and will 
  indicate which QMI error occurred.

@note

  - Dependencies
    - qmi_connection_init() must be called for the associated port first.

  - Side Effects
    - Talks to modem processor
*/    
/*=========================================================================*/
qmi_client_handle_type
qmi_ims_srvc_init_client
(
   const char                   *dev_id,
  qmi_ims_indication_hdlr_type  user_ind_msg_hdlr,
  void                          *user_ind_msg_hdlr_user_data,
  int                           *qmi_err_code
)
{
  qmi_client_handle_type client_handle;
  qmi_connection_id_type conn_id;

  printf("qmi_ims_srvc_init_client\r\n");  

  if ((conn_id = QMI_PLATFORM_DEV_NAME_TO_CONN_ID(dev_id)) == QMI_CONN_ID_INVALID)
  {
    printf("qmi_ims_srvc_init_client: conn_id fail %x\r\n",conn_id);  
    return QMI_INTERNAL_ERR;
  }

  printf("qmi_ims_srvc_init_client: conn_id %x\r\n",conn_id);

    /* Call common service layer initialization function */
    /*lint -e{611} */
    client_handle =  qmi_service_init (conn_id,
                                     QMI_IMS_VIDEO_SERVICE,
                                     (void *) user_ind_msg_hdlr,
                                     user_ind_msg_hdlr_user_data,
                                     qmi_err_code);

    if(client_handle > 0)  
      qmi_ims_reg_ind_hdlr(qmi_ims_srvc_indication_cb);
    else 
    printf("qmi_ims_srvc_init_client: client_handle  0x%x failed \r\n",client_handle);

  return client_handle;
}

/*===========================================================================
  FUNCTION  qmi_ims_srvc_release_client
===========================================================================*/
/*!
@brief 
  This function is called to release a client created by the 
  qmi_ims_srvc_init_client() function.  This function should be called
  for any client created when terminating a client process, especially
  if the modem processor is not reset.  The modem side QMI server has 
  a limited number of clients that it will allocate, and if they are not
  released, we will run out.  
  
@return 
  0 if abort operation was sucessful, < 0 if not.  If return code is 
  QMI_INTERNAL_ERR, then the qmi_err_code will be valid and will 
  indicate which QMI error occurred.

@note

  - Dependencies
    - qmi_connection_init() must be called for the associated port first.

  - Side Effects
    - Talks to modem processor
*/    
/*=========================================================================*/

int 
qmi_ims_srvc_release_client
(
  int      user_handle,
  int      *qmi_err_code
)
{
  int  rc = QMI_NO_ERR;
  
  rc = qmi_service_release (user_handle, qmi_err_code);

  if (ims_service_initialized)
  {

    rc = qmi_service_set_srvc_functions (QMI_IMS_VIDEO_SERVICE,NULL);
    if (rc != QMI_NO_ERR)
    {
      printf("qmi_ims_srvc_release: set srvc functions returns err=%d\n",rc);
    }
    else
    {
      printf("qmi_ims_srvc_release: IMS successfully released\r\n");
      ims_service_initialized = FALSE;
    }
  }
  else
  {
    printf("qmi_ims_srvc_release: Release failed, IMS not initialized\r\n");
  }
  
  return rc;
  
/* IBOX Original Code */    
#if 0
  IMSServiceConfig(INVALID_HANDLE_VALUE, NULL, NULL); 
  return close((HANDLE)user_handle);
#endif  
}

/*===========================================================================
  FUNCTION  qmi_ims_indication_register
===========================================================================*/
/*!
@brief 
  Set the IMS indication registration state for specified control point.
     
  
@return 

@note

  - Dependencies
    - qmi_ims_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_ims_indication_register
(
  int                                     client_handle,
  ims_002A_req_s                  *ims_002A_req,
  int                                    *qmi_err_code
)
{
  unsigned char     msg[QMI_IMS_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;
 
  if(!ims_002A_req)
  {
    return QMI_INTERNAL_ERR;
  }
  
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE);

  /* Write system selection preference TLV if appropriate */
  if(ims_002A_req->t17_valid)
  {
    val_ptr = (unsigned char*)&ims_002A_req->t17;
    tlv_length = sizeof(ims_002A_req->t17);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMS_002A_REQ_T17,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  /* Synchronously send message to modem processor */
  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_IMS_VIDEO_SERVICE,
                                  QMI_IMS_SETTINGS_CONFIG_IND_REG_REQ_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_IMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
} /* qmi_imsa_indication_register */

int
qmi_ims_get_ims_reg_info
(
  int                               client_handle,
  ims_0026_rsp_s             *ims_0026_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_IMS_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!ims_0026_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_IMS_VIDEO_SERVICE,
                                  QMI_IMS_SETTINGS_GET_REG_MGR_CONFIG_RSP_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_IMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_ims_get_ims_reg (msg,msg_size,ims_0026_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_ims_get_ims_reg: qmi_ims_get_ims_reg_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

int
qmi_ims_set_ims_reg_info
(
  int                               client_handle,
  ims_0021_req_s             *ims_0021_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_IMS_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!ims_0021_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE);

  if(ims_0021_req->t10_valid)
  {
    val_ptr = (unsigned char*)&ims_0021_req->t10;
    tlv_length = sizeof(ims_0021_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMS_0021_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(ims_0021_req->t11_valid)
  {
    val_ptr = (unsigned char*)&ims_0021_req->t11;
    //tlv_length = sizeof(ims_0021_req->t11);
    tlv_length = strlen((char *)ims_0021_req->t11.pcscf_domain);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMS_0021_REQ_T11,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(ims_0021_req->t12_valid)
  {
    val_ptr = (unsigned char*)&ims_0021_req->t12;
    tlv_length = sizeof(ims_0021_req->t12);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMS_0021_REQ_T12,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }
  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_IMS_VIDEO_SERVICE,
                                  QMI_IMS_SETTINGS_SET_REG_MGR_CONFIG_REQ_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_IMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}

int
qmi_ims_get_ims_reg
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  ims_0026_rsp_s            *ims_0026_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(ims_0026_rsp, 0, sizeof(ims_0026_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      // pcscf port
      case IMS_0026_RSP_T11:
      {
        ims_0026_rsp->t11_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,ims_0026_rsp->t11.pcscf_port);
      }
      break;      

      // pcscf domain
      case IMS_0026_RSP_T12:
      {
        ims_0026_rsp->t12_valid = TRUE;
        memcpy(ims_0026_rsp->t12.pcscf_domain, value_ptr, length);
      }
      break;

      // ims test mode
      case IMS_0026_RSP_T13:
      {
        ims_0026_rsp->t13_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,ims_0026_rsp->t13.ims_test_mode);
      }
      break;
      
      default:
        QMI_DEBUG_MSG_1 ("qmi_ims_get_ims_reg: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

int
qmi_ims_get_ims_user_info
(
  int                               client_handle,
  ims_0028_rsp_s             *ims_0028_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_IMS_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!ims_0028_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_IMS_VIDEO_SERVICE,
                                  QMI_IMS_SETTINGS_GET_USER_CONFIG_RSP_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_IMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_ims_get_ims_user (msg,msg_size,ims_0028_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_ims_get_ims_user: qmi_ims_get_ims_user_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

int
qmi_ims_get_ims_user
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  ims_0028_rsp_s            *ims_0028_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(ims_0028_rsp, 0, sizeof(ims_0028_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      // domain name
      case IMS_0028_RSP_T11:
      {
        ims_0028_rsp->t11_valid = TRUE;
        memcpy(ims_0028_rsp->t11.domain_name, value_ptr, length);
      }

      default:
        QMI_DEBUG_MSG_1 ("qmi_ims_get_ims_user: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

int
qmi_ims_set_ims_user_info
(
  int                               client_handle,
  ims_0023_req_s             *ims_0023_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_IMS_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!ims_0023_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE);

  if(ims_0023_req->t10_valid)
  {
    val_ptr = (unsigned char*)&ims_0023_req->t10;
    tlv_length = strlen((char *)ims_0023_req->t10.domain_name);
    //tlv_length = sizeof(ims_0023_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMS_0023_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_IMS_VIDEO_SERVICE,
                                  QMI_IMS_SETTINGS_SET_USER_CONFIG_REQ_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_IMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}

int
qmi_ims_get_ims_sip_info
(
  int                               client_handle,
  ims_0025_rsp_s             *ims_0025_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_IMS_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!ims_0025_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_IMS_VIDEO_SERVICE,
                                  QMI_IMS_SETTINGS_GET_SIP_CONFIG_RSP_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_IMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_ims_get_ims_sip (msg,msg_size,ims_0025_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_ims_get_ims_user: qmi_ims_get_ims_sip_info returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

int
qmi_ims_get_ims_sip
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  ims_0025_rsp_s            *ims_0025_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(ims_0025_rsp, 0, sizeof(ims_0025_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
    // sip local port
      case IMS_0025_RSP_T11:
      {
        ims_0025_rsp->t11_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,ims_0025_rsp->t11.sip_local_port);
      }

      // sip reg timer
      case IMS_0025_RSP_T12:
      {
        ims_0025_rsp->t12_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,ims_0025_rsp->t12.timer_sip_reg);
      }      

      // subscribe timer
      case IMS_0025_RSP_T13:
      {
        ims_0025_rsp->t13_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,ims_0025_rsp->t13.subscribe_timer);
      }      

      // timer_t1
      case IMS_0025_RSP_T14:
      {
        ims_0025_rsp->t14_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,ims_0025_rsp->t14.timer_t1);
      }  

      // timer_t2
      case IMS_0025_RSP_T15:
      {
        ims_0025_rsp->t15_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,ims_0025_rsp->t15.timer_t2);
      }  

      // timer_f
      case IMS_0025_RSP_T16:
      {
        ims_0025_rsp->t16_valid = TRUE;
        READ_32_BIT_VAL (value_ptr,ims_0025_rsp->t16.timer_f);
      }  

      default:
        QMI_DEBUG_MSG_1 ("qmi_ims_get_ims_user: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

int
qmi_ims_set_ims_sip_info
(
  int                               client_handle,
  ims_0020_req_s             *ims_0020_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_IMS_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!ims_0020_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE);

  if(ims_0020_req->t10_valid)
  {
    val_ptr = (unsigned char*)&ims_0020_req->t10;
    tlv_length = sizeof(ims_0020_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMS_0020_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(ims_0020_req->t11_valid)
  {
    val_ptr = (unsigned char*)&ims_0020_req->t11;
    tlv_length = sizeof(ims_0020_req->t11);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMS_0020_REQ_T11,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(ims_0020_req->t12_valid)
  {
    val_ptr = (unsigned char*)&ims_0020_req->t12;
    tlv_length = sizeof(ims_0020_req->t12);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMS_0020_REQ_T12,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }   

  if(ims_0020_req->t13_valid)
  {
    val_ptr = (unsigned char*)&ims_0020_req->t13;
    tlv_length = sizeof(ims_0020_req->t13);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMS_0020_REQ_T13,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }   

  if(ims_0020_req->t14_valid)
  {
    val_ptr = (unsigned char*)&ims_0020_req->t14;
    tlv_length = sizeof(ims_0020_req->t14);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMS_0020_REQ_T14,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }   

  if(ims_0020_req->t15_valid)
  {
    val_ptr = (unsigned char*)&ims_0020_req->t15;
    tlv_length = sizeof(ims_0020_req->t15);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMS_0020_REQ_T15,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }   

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_IMS_VIDEO_SERVICE,
                                  QMI_IMS_SETTINGS_SET_SIP_CONFIG_REQ_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_IMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}

int
qmi_ims_get_ims_voip_info
(
  int                               client_handle,
  ims_0029_rsp_s             *ims_0029_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_IMS_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!ims_0029_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_IMS_VIDEO_SERVICE,
                                  QMI_IMS_SETTINGS_GET_VOIP_CONFIG_RSP_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_IMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_ims_get_ims_voip (msg,msg_size,ims_0029_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_ims_get_ims_user: qmi_ims_get_ims_voip returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

int
qmi_ims_get_ims_voip
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  ims_0029_rsp_s            *ims_0029_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(ims_0029_rsp, 0, sizeof(ims_0029_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      // session expiry timer
      case IMS_0029_RSP_T11:
      {
        ims_0029_rsp->t11_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,ims_0029_rsp->t11.session_expiry_timer);
      }
      break;

      // min session expiry
      case IMS_0029_RSP_T12:
      {
        ims_0029_rsp->t12_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,ims_0029_rsp->t12.min_session_expiry);
      }
      break;

      // amr wb enable
      case IMS_0029_RSP_T13:
      {
        ims_0029_rsp->t13_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,ims_0029_rsp->t13.amr_wb_enable);
      }
      break;

      // amr codec mode set
      case IMS_0029_RSP_T16:
      {
        ims_0029_rsp->t16_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,ims_0029_rsp->t16.amr_mode);
      }
      break;

      // amr wb codec mode set
      case IMS_0029_RSP_T17:
      {
        ims_0029_rsp->t17_valid = TRUE;
        READ_16_BIT_VAL (value_ptr,ims_0029_rsp->t17.amr_wb_mode);
      }
      break;

      // amr payload format
      case IMS_0029_RSP_T18:
      {
        ims_0029_rsp->t18_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,ims_0029_rsp->t18.amr_octet_align);
      }
      break;

      // amr wb payload format
      case IMS_0029_RSP_T19:
      {
        ims_0029_rsp->t19_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,ims_0029_rsp->t19.amr_wb_octet_align);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_ims_get_ims_voip: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

int
qmi_ims_set_ims_voip_info
(
  int                               client_handle,
  ims_0024_req_s             *ims_0024_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_IMS_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!ims_0024_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE);

  if(ims_0024_req->t10_valid)
  {
    val_ptr = (unsigned char*)&ims_0024_req->t10;
    tlv_length = sizeof(ims_0024_req->t10);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMS_0024_REQ_T10,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(ims_0024_req->t11_valid)
  {
    val_ptr = (unsigned char*)&ims_0024_req->t11;
    tlv_length = sizeof(ims_0024_req->t11);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMS_0024_REQ_T11,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

  if(ims_0024_req->t12_valid)
  {
    val_ptr = (unsigned char*)&ims_0024_req->t12;
    tlv_length = sizeof(ims_0024_req->t12);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMS_0024_REQ_T12,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }   

  if(ims_0024_req->t15_valid)
  {
    val_ptr = (unsigned char*)&ims_0024_req->t15;
    tlv_length = sizeof(ims_0024_req->t15);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMS_0024_REQ_T15,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }  

  if(ims_0024_req->t16_valid)
  {
    val_ptr = (unsigned char*)&ims_0024_req->t16;
    tlv_length = sizeof(ims_0024_req->t16);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMS_0024_REQ_T16,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }    

  if(ims_0024_req->t17_valid)
  {
    val_ptr = (unsigned char*)&ims_0024_req->t17;
    tlv_length = sizeof(ims_0024_req->t17);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMS_0024_REQ_T17,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }  

  if(ims_0024_req->t18_valid)
  {
    val_ptr = (unsigned char*)&ims_0024_req->t18;
    tlv_length = sizeof(ims_0024_req->t18);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMS_0024_REQ_T18,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }  

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_IMS_VIDEO_SERVICE,
                                  QMI_IMS_SETTINGS_SET_VOIP_CONFIG_REQ_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_IMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}


int
qmi_ims_get_ims_qipcall_info
(
  int                               client_handle,
  ims_0037_rsp_s             *ims_0037_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_IMS_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!ims_0037_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_IMS_VIDEO_SERVICE,
                                  QMI_IMS_SETTINGS_GET_QIPCALL_CONFIG_REQ_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_IMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  if (rc == QMI_NO_ERR)
  {

    if (qmi_ims_get_ims_qipcall (msg,msg_size,ims_0037_rsp) < 0)
    {
      QMI_ERR_MSG_0 ("qmi_ims_get_ims_user: qmi_ims_get_ims_qipcall returned error");
      rc = QMI_INTERNAL_ERR;
    } 

  }
  return rc;     
}

int
qmi_ims_get_ims_qipcall
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  ims_0037_rsp_s            *ims_0037_rsp
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(ims_0037_rsp, 0, sizeof(ims_0037_rsp_s));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      // volte enable
      case IMS_0037_RSP_T13:
      {
        ims_0037_rsp->t13_valid = TRUE;
        READ_8_BIT_VAL (value_ptr,ims_0037_rsp->t13.volte_enabled);
      }
      break;

      default:
        QMI_DEBUG_MSG_1 ("qmi_ims_get_qipcall_voip: Unknown TLV ID=%x\n",(unsigned)type);
      break;
    } /* switch */
  } /* while */

  return QMI_NO_ERR;
}

int
qmi_ims_set_ims_qipcall_info
(
  int                               client_handle,
  ims_0036_req_s             *ims_0036_req,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_IMS_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!ims_0036_req)
  {
    return QMI_INTERNAL_ERR;
  }
 
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */  
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE);

  if(ims_0036_req->t12_valid)
  {
    val_ptr = (unsigned char*)&ims_0036_req->t12;
    tlv_length = sizeof(ims_0036_req->t12);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                IMS_0036_REQ_T12,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }   

  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_IMS_VIDEO_SERVICE,
                                  QMI_IMS_SETTINGS_SET_QIPCALL_CONFIG_REQ_V01,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_IMS_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_IMS_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
}

