/******************************************************************************
  @file    qcmap_tof.cpp
  @brief   QCMAP data service client

  DESCRIPTION

  INITIALIZATION AND SEQUENCING REQUIREMENTS

  ---------------------------------------------------------------------------
  Copyright (c) 2016 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/

#include "qcmap_tof.h"
#include "QCMAP_Client.h"
#include "TOF_API.h"
#include "TOF_event_daemon.h"

#ifdef __cplusplus
extern "C" {
#endif

#define DEFAULT_AUTO_CONNECT      0 // Auto connection default disabled

#define qcmap_3gpp_profile_path   "/data/configs/qcmap_3gpp_profile"
#define qcmap_3gpp_ip_family_path "/data/configs/qcmap_ip_family"
#define qcmap_auto_connect_path   "/data/configs/qcmap_auto_connect"

#define rmnet_data0_carrier_path  "/sys/devices/virtual/net/rmnet_data0/carrier"

static QCMAP_Client*                       QcMapClient            = NULL;
static qcmap_msgr_wwan_call_end_reason_v01 QcMapCallEndReason;
static qcmap_msgr_ip_family_enum_v01       QcMapStoredIpFamily    = QCMAP_MSGR_IP_FAMILY_V4_V01;
static int                                 QcMapStoredProfile     = 0;
static boolean                             QcMapStoredAutoConnect = FALSE;

pthread_t thread_ip46 = (pthread_t) NULL;

int qcmap_read_int_from_file(const char* path, int* value)
{
  FILE* fp = NULL;
  char buf[20] = {0};

  fp = fopen(path, "r");

  if(fp == NULL)
    return FALSE;

  fgets(buf, 20, fp);
  *value = atoi(buf);

  fclose(fp);
  return TRUE;
}

int qcmap_write_int_to_file(const char* path, int value)
{
  FILE* fp = NULL;
  char buf[20] = {0};

  fp = fopen(path, "w");

  if(fp == NULL)
    return FALSE;

  snprintf(buf, 20, "%d", value);
  fputs(buf, fp);

  fclose(fp);
  return TRUE;
}

int qcmap_store_preference(int profile, tof_qcmap_msgr_ip_family_enum_v01 ip_family)
{
  qcmap_write_int_to_file(qcmap_3gpp_profile_path, profile);
  qcmap_write_int_to_file(qcmap_3gpp_ip_family_path, ip_family);

  QcMapStoredProfile  = profile;
  QcMapStoredIpFamily = (qcmap_msgr_ip_family_enum_v01)ip_family;
  
  return TRUE;
}

int qcmap_restore_preference()
{
  int carrier      = 0;
  int profile      = 0;
  int ip_family    = 0;
  int auto_connect = DEFAULT_AUTO_CONNECT;

  qcmap_read_int_from_file(rmnet_data0_carrier_path, &carrier);
  qcmap_read_int_from_file(qcmap_3gpp_profile_path, &profile);
  qcmap_read_int_from_file(qcmap_3gpp_ip_family_path, &ip_family);
  qcmap_read_int_from_file(qcmap_auto_connect_path, &auto_connect);

  QcMapStoredProfile     = profile;
  QcMapStoredIpFamily    = (qcmap_msgr_ip_family_enum_v01)ip_family;
  QcMapStoredAutoConnect = (auto_connect == 1 ? TRUE : FALSE);

  if(QcMapStoredProfile > 0)
  {
    qcmap_set_wwan_policy(profile);
  }

  qcmap_set_auto_connect(QcMapStoredAutoConnect, FALSE);

  // do not need to connect backhaul if auto connect is already set
  if(!QcMapStoredAutoConnect && 1 == carrier)
  {     
    printf("Trying to restore MobileAP connection\n");
    if(TOF_QCMAP_MSGR_IP_FAMILY_V4V6_V01 == ip_family || 0 == ip_family)
    {
      qcmap_connect_backhaul(TOF_QCMAP_MSGR_IP_FAMILY_V4_V01);
    }
    else
    {
      qcmap_connect_backhaul((tof_qcmap_msgr_ip_family_enum_v01)ip_family);
    }
  }

  return TRUE;
}

void* thread_routine_connect_backhaul_6(void* arg)
{
  printf("Trying to setup IPv6\n");

  usleep(500000); // 500ms
  qcmap_connect_backhaul(TOF_QCMAP_MSGR_IP_FAMILY_V6_V01);

  pthread_exit((void*) 0);
  return (void*) 0;
}

void qcmap_msgr_qmi_qcmap_ind
(
 qmi_client_type user_handle,                    /* QMI user handle       */
 unsigned int    msg_id,                         /* Indicator message ID  */
 void           *ind_buf,                        /* Raw indication data   */
 unsigned int    ind_buf_len,                    /* Raw data length       */
 void           *ind_cb_data                     /* User call back handle */
)
{
  qmi_client_error_type                qmi_error;
  /* qcmap_msgr_tear_down_wwan_ind_msg_v01 and qcmap_msgr_wwan_status_ind_msg_v01 are the same structure with qcmap_msgr_bring_up_wwan_ind_msg_v01 */
  qcmap_msgr_bring_up_wwan_ind_msg_v01 ind_data;
  boolean                              notify = TRUE;

  switch (msg_id)
  {
    case QMI_QCMAP_MSGR_BRING_UP_WWAN_IND_V01:
    case QMI_QCMAP_MSGR_TEAR_DOWN_WWAN_IND_V01:
    case QMI_QCMAP_MSGR_WWAN_STATUS_IND_V01:
      qmi_error = qmi_client_message_decode(user_handle,
                                            QMI_IDL_INDICATION,
                                            msg_id,
                                            ind_buf,
                                            ind_buf_len,
                                            &ind_data,
                                            sizeof(qcmap_msgr_bring_up_wwan_ind_msg_v01));
      switch(ind_data.conn_status)
      {
        case QCMAP_MSGR_WWAN_STATUS_CONNECTING_FAIL_V01:
        case QCMAP_MSGR_WWAN_STATUS_CONNECTED_V01:
        case QCMAP_MSGR_WWAN_STATUS_DISCONNECTING_FAIL_V01:
        case QCMAP_MSGR_WWAN_STATUS_DISCONNECTED_V01:
        case QCMAP_MSGR_WWAN_STATUS_IPV6_CONNECTING_FAIL_V01:
        case QCMAP_MSGR_WWAN_STATUS_IPV6_CONNECTED_V01:
        case QCMAP_MSGR_WWAN_STATUS_IPV6_DISCONNECTING_FAIL_V01:              
        case QCMAP_MSGR_WWAN_STATUS_IPV6_DISCONNECTED_V01:
          if(ind_data.wwan_call_end_reason_valid)
          {
            memcpy(&QcMapCallEndReason, &(ind_data.wwan_call_end_reason), sizeof(qcmap_msgr_wwan_call_end_reason_v01));
            printf("qcmap_msgr_qmi_qcmap_ind: WWAN MsgID 0x%x, Status 0x%x, CallendType 0x%x, CallendCode 0x%x, Error %d\n",
              msg_id, ind_data.conn_status,
              ind_data.wwan_call_end_reason.wwan_call_end_reason_type,
              ind_data.wwan_call_end_reason.wwan_call_end_reason_code,
              qmi_error);
          }

          // Cannot control IP type of auto connection
          // Ignore to send notification if there are failures
          if(QcMapStoredAutoConnect)
          {
            switch(ind_data.conn_status)
            {
              case QCMAP_MSGR_WWAN_STATUS_CONNECTING_FAIL_V01:
              case QCMAP_MSGR_WWAN_STATUS_IPV6_CONNECTING_FAIL_V01:
                notify = FALSE;
                break;
              default:
                break;
            }    
          }
          
          if(notify)
          {
            EventNotifyEnqueue(TOF_EVENT_DATA_STATUS_CHANGED, 0, ind_data.conn_status);
          }
          break;
        default:
          break;
      }
      
      break;
    default:
      break;
  }

  if(!QcMapStoredAutoConnect &&
    QCMAP_MSGR_IP_FAMILY_V4V6_V01 == QcMapStoredIpFamily &&
    QMI_QCMAP_MSGR_BRING_UP_WWAN_IND_V01 == msg_id &&
    QCMAP_MSGR_WWAN_STATUS_CONNECTED_V01 == ind_data.conn_status)
  {
    pthread_create(&thread_ip46, NULL, thread_routine_connect_backhaul_6, NULL);
  }

  return;
}

int qcmap_call_end_reason(int32_t* reason_code)
{
  if(QCMAP_MSGR_WWAN_CALL_END_TYPE_INVALID_V01 != QcMapCallEndReason.wwan_call_end_reason_type)
  {
    *reason_code = QcMapCallEndReason.wwan_call_end_reason_code;
    return TRUE;
  }
  else
  {
    printf("No data call end reason\n");
  }

  return FALSE;
}

int qcmap_get_data_call_list(tof_data_call_response* call_resp)
{
  qcmap_msgr_wwan_status_enum_v01 v4_status, v6_status;
  qcmap_msgr_ip_family_enum_v01 ip_family;
  qcmap_nw_params_t qcmap_nw_params;
  qmi_error_type_v01  qmi_err_num;
  char ip6_addr_buf[INET6_ADDRSTRLEN];

  if(!qcmap_client_validate())
    return FALSE;

  if (!QcMapClient->GetWWANStatus(&v4_status, &v6_status, &qmi_err_num))
  {
    printf("Cannot get IPv4 or IPv6 status\n");
    return FALSE;
  }

  memset(call_resp, 0x0, sizeof(tof_data_call_response));

  call_resp->inet_status  = (tof_qcmap_msgr_wwan_status_enum_v01) v4_status;
  call_resp->inet6_status = (tof_qcmap_msgr_wwan_status_enum_v01) v6_status;

  if(QCMAP_MSGR_WWAN_STATUS_CONNECTED_V01 == v4_status)
  {
    ip_family = QCMAP_MSGR_IP_FAMILY_V4_V01;
    if(QcMapClient->GetNetworkConfiguration(ip_family, &qcmap_nw_params, &qmi_err_num) &&
       QMI_ERR_NONE_V01 == qmi_err_num)
    {
      qcmap_nw_params.v4_conf.public_ip.s_addr = htonl(qcmap_nw_params.v4_conf.public_ip.s_addr);
      qcmap_nw_params.v4_conf.primary_dns.s_addr = htonl(qcmap_nw_params.v4_conf.primary_dns.s_addr);
      qcmap_nw_params.v4_conf.secondary_dns.s_addr = htonl(qcmap_nw_params.v4_conf.secondary_dns.s_addr);

      strncpy(call_resp->inet_addr, inet_ntoa(qcmap_nw_params.v4_conf.public_ip), INET_ADDRSTRLEN);
      strncpy(call_resp->inet_pdns_addr, inet_ntoa(qcmap_nw_params.v4_conf.primary_dns), INET_ADDRSTRLEN);
      strncpy(call_resp->inet_sdns_addr, inet_ntoa(qcmap_nw_params.v4_conf.secondary_dns), INET_ADDRSTRLEN);
    }
    else
    {
      printf("Error in IPv4 config - 0x%x\n", qmi_err_num);
    }
  }

  if(QCMAP_MSGR_WWAN_STATUS_IPV6_CONNECTED_V01 == v6_status)
  {
    ip_family = QCMAP_MSGR_IP_FAMILY_V6_V01;
    if(QcMapClient->GetNetworkConfiguration(ip_family, &qcmap_nw_params, &qmi_err_num) &&
       QMI_ERR_NONE_V01 == qmi_err_num)
    {
      strncpy(call_resp->inet6_addr,
              inet_ntop(AF_INET6, &qcmap_nw_params.v6_conf.public_ip_v6, ip6_addr_buf, sizeof(ip6_addr_buf)),
              INET6_ADDRSTRLEN);
      strncpy(call_resp->inet6_pdns_addr,
              inet_ntop(AF_INET6, &qcmap_nw_params.v6_conf.primary_dns_v6, ip6_addr_buf, sizeof(ip6_addr_buf)),
              INET6_ADDRSTRLEN);
      strncpy(call_resp->inet6_sdns_addr,
              inet_ntop(AF_INET6, &qcmap_nw_params.v6_conf.secondary_dns_v6, ip6_addr_buf, sizeof(ip6_addr_buf)),
              INET6_ADDRSTRLEN);
    }
    else
    {
      printf("Error in IPv6 config - 0x%x\n", qmi_err_num);
    }
  }

  return TRUE;
}

int qcmap_connect_backhaul(tof_qcmap_msgr_ip_family_enum_v01 ip_family)
{
  qmi_error_type_v01  qmi_err_num;
  qcmap_msgr_wwan_call_type_v01 call_type;

  // use qcmap_check_and_enable_mobile_ap instead of qcmap_client_validate
  // allow 1 more chance
  if(!qcmap_check_and_enable_mobile_ap())
    return FALSE;

  // auto connection priority is higher than manual connection
  qcmap_set_auto_connect(QcMapStoredAutoConnect, FALSE);
  printf("Restore auto connect setting %d\n", QcMapStoredAutoConnect);

  // do not need to connect backhaul if auto connect is already set
  if(!QcMapStoredAutoConnect)
  {
    call_type = (TOF_QCMAP_MSGR_IP_FAMILY_V6_V01 == ip_family ? QCMAP_MSGR_WWAN_CALL_TYPE_V6_V01 : QCMAP_MSGR_WWAN_CALL_TYPE_V4_V01);
    if(!QcMapClient->ConnectBackHaul(call_type, &qmi_err_num))
    {
      printf("ConnectBackHaul fails, IP_family: %d, Error: 0x%x\n", ip_family, qmi_err_num);
      return FALSE;
    }
  }

  return TRUE;
}

int qcmap_disconnect_backhaul(void)
{
  qmi_error_type_v01  qmi_err_num;
  qcmap_msgr_wwan_call_type_v01 call_type;

  if(!qcmap_client_validate())
    return FALSE;

  for(int i = 0 ; i < 2 ; i++)
  {
    // Try to disconnect all of IPv4 and IPv6 calls
    call_type = (i == 0 ? QCMAP_MSGR_WWAN_CALL_TYPE_V4_V01 : QCMAP_MSGR_WWAN_CALL_TYPE_V6_V01);
    if (!QcMapClient->DisconnectBackHaul(call_type, &qmi_err_num))
    {
      printf("DisconnectBackHaul fails, Call type: %d, Error: 0x%x\n", call_type, qmi_err_num);
      continue;
    }
  }

  // disable auto connect if disconnected by user
  qcmap_set_auto_connect(FALSE, FALSE);

  return TRUE;
}

void qcmap_get_auto_connect_from_preference(boolean* enable)
{
  *enable = QcMapStoredAutoConnect;

  return;
}

int qcmap_set_auto_connect(boolean enable, boolean file_write)
{
  qmi_error_type_v01  qmi_err_num;

  // use qcmap_check_and_enable_mobile_ap instead of qcmap_client_validate
  // allow 1 more chance
  if(!qcmap_check_and_enable_mobile_ap())
    return FALSE;
  
  if(!QcMapClient->SetAutoconnect(enable, &qmi_err_num))
  {
    printf("qcmap_set_auto_connect failure %d\n", qmi_err_num);
    return FALSE;
  }

  if(file_write)
  {
    qcmap_write_int_to_file(qcmap_auto_connect_path, (enable ? 1 : 0));
    QcMapStoredAutoConnect = enable;
  }

  return TRUE;
}

int qcmap_set_wwan_policy(int profile)
{
  qmi_error_type_v01  qmi_err_num;
  qcmap_msgr_net_policy_info_v01 net_policy;

  net_policy.tech_pref = 0; // Any
  net_policy.ip_family = QCMAP_MSGR_IP_FAMILY_V4V6_V01; // It will not affect IP type selection of auto connection
  net_policy.v4_profile_id_3gpp = profile;
  net_policy.v6_profile_id_3gpp = profile;
  net_policy.v4_profile_id_3gpp2 = 0;
  net_policy.v6_profile_id_3gpp2 = 0;

  if(!qcmap_client_validate())
    return FALSE;

  if(!QcMapClient->SetWWANPolicy(net_policy, &qmi_err_num))
  {
    printf("SetWWANPolicy set failure %d\n", qmi_err_num);
    return FALSE;
  }

  return TRUE;
}

int qcmap_check_and_enable_mobile_ap(void)
{
  qmi_error_type_v01  qmi_err_num;

  if(QcMapClient->mobile_ap_handle != 0)
  {
    return TRUE;
  }

  if(!QcMapClient->EnableMobileAP(&qmi_err_num) && QMI_ERR_NO_EFFECT_V01 != qmi_err_num)
  {
    printf("MobileAP enables failure %d\n", qmi_err_num);
    return FALSE;
  }

  return TRUE;
}

int qcmap_client_validate(void)
{
  if(QcMapClient != NULL && QcMapClient->mobile_ap_handle != 0)
  {
    return TRUE;
  }

  printf("QcMAP client validate failure\n");
  return FALSE;
}

int qcmap_client_init(void)
{
  int ret = TRUE;

  if(QcMapClient == NULL)
  {
    QcMapClient = new QCMAP_Client( qcmap_msgr_qmi_qcmap_ind );
    QcMapCallEndReason.wwan_call_end_reason_type = QCMAP_MSGR_WWAN_CALL_END_TYPE_INVALID_V01;
  }

  if(QcMapClient != NULL && QcMapClient->qmi_qcmap_msgr_handle != 0)
  {
    printf("qcmap_client_init success\n");
    if(qcmap_check_and_enable_mobile_ap())
    {
      qcmap_restore_preference();
    }
    else
    {
      // do not return here.
      printf("qcmap_check_and_enable_mobile_ap in qcmap_client_init failure\n");
    }
  }
  else
  {
    printf("qcmap_client_init failure\n");
    qcmap_client_release();

    return FALSE;
  }
  return TRUE;
}

void qcmap_client_release(void)
{
  qmi_error_type_v01  qmi_err_num;

  if(NULL != QcMapClient)
  {
    QcMapClient->DisableMobileAP(&qmi_err_num);

    delete QcMapClient;
    QcMapClient = NULL;
    
    printf("qcmap_client_release\n");
  }
}

#ifdef __cplusplus
}
#endif
