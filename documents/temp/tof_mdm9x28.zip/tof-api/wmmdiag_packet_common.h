#ifndef WMMDIAG_PACKET_COMMON_H
#define WMMDIAG_PACKET_COMMON_H

/*===========================================================================

HEADER WMMDIAG_PACKET_COMMON

DESCRIPTION
  
===========================================================================*/

#include "TOF_Definition.h"
//#include "dmss_comdef.h"
//#include "cust_lgit_target.h"

#define LOG_TAG "RIL"
#ifdef FEATURE_EMULATOR  //dsji_20110502
#include "emulator.h"  //dsji_20110502
#else
//#include <utils/Log.h>
#endif

#ifdef FEATURE_EMULATOR
#define strlcpy(a,b,c) strncpy(a,b,c)
#endif


#pragma pack(1)
#define PACKED

// no use x64 machine: test program like hmc_demo execute in x86 machine
// build for x64 machine
//#define USE_x64_OS //x64: long int -> 8byte, x86: long int -> 4byte
// packet structure
//UINT32, uint32 (4byte) -> UINT(4byte): unsigned long int (x86), unsigned int (x64)
// dword (4byte) -> UINT(4byte): unsigned long int (x86), unsigned int (x64)


/*===========================================================================
  Constant Define
===========================================================================*/

typedef enum {
  WMM_STATE_OTA_NONE,
  WMM_STATE_OTA_REQUESTED,
  WMM_STATE_OTA_BOOTED,
  WMM_STATE_OTA_BOOTED_AND_WAIT_RESULT,
  WMM_STATE_OTA_COMPLETED,
  WMM_STATE_OTA_ERRORED,
  WMM_STATE_OTA_MAX
} wmm_ota_state_enum_type;


/*===========================================================================
  Structure Define
===========================================================================*/
#define MAX_DIAL_DIGITS_HMC    40  //jisim_110704 32-> 40 HMC API 0.22 ������ 40���� ������  NV_MAX_DIAL_DIGITS �� �����ϰ� �����ؾ� �� 

// shpark, add to display the calibration version and date information 2012.05.03
#define MAX_RF_CAL_INFO_LEN   40


#define CISS_MAX_REC_LENGTH 90
typedef PACKED struct
{
  UINT32  mask;
  UINT16  name_len;
  UINT16  name_offset;
  UINT16  ctxt_len;
  UINT16  ctxt_offset;
  UINT16  bell_len;
  UINT16  bell_offset;
  UINT16  url_len;
  UINT16  url_offset;
  UINT8  data_buf[CISS_MAX_REC_LENGTH+1];
} HKS_CISS_INFO;

typedef PACKED struct
{
  UINT8  call_id;
  char num_buf[MAX_DIAL_DIGITS_HMC+1]; //40+1
  boolean  CLIR; //�߽Ź�ȣ ǥ�ÿ��� (0:ǥ������, 1:ǥ��) : 0 �� ��� AVN���� "�߽��� ǥ�� ����"���� ��� 
  boolean  CLIP; //�߽Ź�ȣ ǥ�ÿ��� (0:�߽� ��ȣ ����, 1:�߽� ��ȣ ���� ) : 0 �� ��� AVN���� "�߽� ǥ�� ��Ȯ��"���� ��� 
  UINT8    TON;  //0:unknown,1:������ȭ, 2:local(�Ϲ���ȭ)  
  HKS_CISS_INFO ciss_handle;  //KTF Spec
} HKS_CALL_CONTEXT_INFO;  

/*Voice Call */ 
typedef enum
{
  CM_CALL_TYPE_NONE=-1,
  CM_CALL_TYPE_VOICE=0,
  CM_CALL_TYPE_CS_DATA=1,
  CM_CALL_TYPE_PS_DATA=2,
  CM_CALL_TYPE_SMS=3,
  CM_CALL_TYPE_PD=4,
  CM_CALL_TYPE_TEST=5,
  CM_CALL_TYPE_OTAPA=6,
  CM_CALL_TYPE_STD_OTASP=7,
  CM_CALL_TYPE_NON_STD_OTASP=8,
  CM_CALL_TYPE_EMERGENCY=9,
  CM_CALL_TYPE_SUPS=10,
  CM_CALL_TYPE_VT=11,
  CM_CALL_TYPE_VT_LOOPBACK,
  CM_CALL_TYPE_VS,
  CM_CALL_TYPE_PS_DATA_IS707B,
  CM_CALL_TYPE_MAX
}cm_call_type_e_type; //jisim_110620  cm.h�� cm_call_type_e_type ������ �����ϰ� �迭�� 

typedef PACKED struct 
{
  uint8  call_id;
  cm_call_type_e_type  call_type;
} wmmdiag_notify_call_status_type;


/////////////////////////////////////////////////////////////////////////////////////////////////
typedef PACKED struct
{
  byte              cmd_code;   // fixed cmd code value
  byte              pkt_seqno;  // pkt sequence no.
  word              pkt_length; // current packet length :: sizeof(hm_diag_reqpkt_t)
  byte              ack_flag;   // need ack flag (ack_flag ? 1 : 0)
  word              pkt_status; // response status code per pkt
  byte              func_code;     // function code : ref. hm_diag_cmd_enum_t
  byte              op_code;       // by func_code : ref. hm_diag_op_enum_t
  word              item_count;    // count of item_data in current pkt
} wmmdiag_header_type;


/*sclee 2011.06.26 debuging for internal sms erro*/
typedef PACKED struct
{
  UINT32 wmm_interanl_erro;
  UINT32 wmm_wmsmsg_status_erro;  
} wmm_sms_internal_erro_type;
/*end*/

#if 0  //05/24/2013 Deleted by ssaulaby09
//==> FEATURE_LGIT_HMC_SET_48H_MODE_FROM_CONFIG
typedef PACKED struct 
{
  unsigned short time;
  uint8 delay; //boolean
  unsigned char delay_time;
  uint8 relcall; //boolean
} wmmdiag_mode_48h_config_type;
//<== FEATURE_LGIT_HMC_SET_48H_MODE_FROM_CONFIG
#endif

typedef enum
{
  NETSEL_BAND_MODE_UNSPECIFIED = 0,  // selected by baseband automatically
  NETSEL_BAND_MODE_EURO,                     // GSM-900 / DCS-1800 / WCDMA-IMT-2000
  NETSEL_BAND_MODE_US,                         // GSM-850 / PCS-1900 / WCDMA-850 / WCDMA-PCS-1900
  NETSEL_BAND_MODE_JPN,                       // WCDMA-800 / WCDMA-IMT-2000
  NETSEL_BAND_MODE_AUS,                      // GSM-900 / DCS-1800 / WCDMA-850 / WCDMA-IMT-2000
  NETSEL_BAND_MODE_AUS2,                    // GSM-900 / DCS-1800 / WCDMA-850
  NETSEL_BAND_MODE_CELLULAR,             // 800-MHz Band
  NETSEL_BAND_MODE_PCS,                       // 1900-MHz Band
  NETSEL_BAND_MODE_BC3,                       // JTACS Band
  NETSEL_BAND_MODE_BC4,                       // Korean PCS Band
  NETSEL_BAND_MODE_BC5,                       // 450-MHz Band
  NETSEL_BAND_MODE_BC6,                       // 2-GMHz IMT2000 Band
  NETSEL_BAND_MODE_BC7,                       // Upper 700-MHz Band
  NETSEL_BAND_MODE_BC8,                       // 1800-MHz Band
  NETSEL_BAND_MODE_BC9,                       // 900-MHz Band
  NETSEL_BAND_MODE_BC10,                     // Secondary 800-MHz Band
  NETSEL_BAND_MODE_BC11,                     // 400-MHz European PAMR Band
  NETSEL_BAND_MODE_BC15,                     // AWS Band
  NETSEL_BAND_MODE_BC16,                     // US 2.5-GHz Band
  NETSEL_BAND_MODE_MAX
} wmmdiag_netsel_band_mode_type;

typedef enum
{
  NETSEL_PREF_NET_TYPE_GSM_WCDMA_PREF = 0,       // GSM/WCDMA (WCDMA preferred)
  NETSEL_PREF_NET_TYPE_GSM_ONLY,                           // GSM only
  NETSEL_PREF_NET_TYPE_WCDMA_ONLY,                      // WCDMA only
  NETSEL_PREF_NET_TYPE_GSM_WCDMA_AUTO,            // GSM/WCDMA (auto mode, according to PRL)
  NETSEL_PREF_NET_TYPE_CDMA_EVDO,                        // CDMA and EvDo (auto mode, according to PRL)
  NETSEL_PREF_NET_TYPE_CDMA_ONLY,                        // CDMA only
  NETSEL_PREF_NET_TYPE_EVDO_ONLY,                         // EvDo only
  NETSEL_PREF_NET_TYPE_GSM_WCDMA_CDMA_EVDO,  // GSM/WCDMA, CDMA, and EvDo (auto mode, according to PRL)
  NETSEL_PREF_NET_TYPE_MAX
} wmmdiag_netsel_pref_net_type;


#define WMMDIAG_INVALID_TZ 97
#define WMMDIAG_CDMA_INVALID_TZ 0xFF

typedef PACKED struct
{
  uint8 year;
  uint8 month;
  uint8 day;
  uint8 hour;
  uint8 minute;
  uint8 second;
  int time_zone;
  uint8 dst;
} wmmdiag_nitz_time_info_type;

typedef enum
{
  MODEM_RESET_MODE = 0,
  MODEM_OFFLINE_MODE,
  MODEM_NORMAL_MODE,
  MODEM_DEBUG_MODE,
  MODEM_CALLDEBUG_MODE,
  MODEM_LOOP_BACK_ON, 
  MODEM_LOOP_BACK_OFF,
  MODEM_FTM_MODE,
  MODEM_LPM_MODE,
  MODEM_ONLINE_MODE,  
  MODEM_MODE_MAX
} wmmdiag_mode_mode_enum_type;

typedef enum
{
  RF_MODE_CDMA = 0,
  RF_MODE_SLEEP =2,
  RF_MODE_GPS,
  RF_MODE_CDMA_800 =5,
  RF_MODE_CDMA_1900,
  RF_MODE_HDR,
  RF_MODE_CDMA_1800,
  RF_MODE_WCDMA_IMT,
  RF_MODE_GSM_900,
  RF_MODE_GSM_1800,
  RF_MODE_GSM_1900,
  RF_MODE_BLUETOOTH,
  RF_MODE_JCDMA = 14,
  RF_MODE_WCDMA_1900A,
  RF_MODE_WCDMA_1900B,
  RF_MODE_CDMA_450,
  RF_MODE_GSM_850,
  RF_MODE_IMT,
  RF_MODE_HDR_800,
  RF_MODE_HDR_1900,
  RF_MODE_WCDMA_800,
  RF_MODE_WCDMA_BC3=25,
  RF_MODE_CDMA_BC14 = 26,
  RF_MODE_CDMA_BC11 = 27,
  RF_MODE_WCDMA_BC4=28,
  RF_MODE_WCDMA_BC8=29,
  RF_MODE_MF_700=30,
  RF_MODE_WCDMA_BC9=31,
  RF_MODE_CDMA_BC15=32,
  RF_MODE_CDMA_BC10=33,
  RF_MODE_LTE_BC1=34,
  RF_MODE_LTE_BC7=35,
  RF_MODE_LTE_BC13=36,
  RF_MODE_LTE_BC17=37,
  RF_MODE_LTE_BC38=38,
  RF_MODE_LTE_BC40=39,
  RF_MODE_WCDMA_BC11=40,
  RF_MODE_WCDMA_BC19=75,
  RF_MODE_MAX
} wmmdiag_rf_mode_enum_type;

// jgkim 130402
typedef PACKED struct{
  int reg_status;  
  int lac;
  int cell_id;
  int rat;
  int bs_id;
  int bs_latitude;
  int bs_longitude;
  int services_support_ind;
  int sid;
  int nid;
  int roaming_ind;
  int prl_ind;
  int default_roaming_ind;
  int reject_cause;
  int gprs_status;       //only WCDMA
  int srv_status;
  int hs_call_status;
} wmm_registartion_status_type;

typedef struct
{
  unsigned char  profile_num;                    // valid profile number are 1 -16
  unsigned char  apn_length;
  unsigned char  apn [100 + 1];
  unsigned char  traffic_class;                    // Traffic class: subscribed=0, conversational=1, streaming=2, interactive=3, background=4
  unsigned char  pdp_type;                         // Pdp type: IP=0, PPP=1
  unsigned int  ip_addr;
  unsigned int  primary_dns;
  unsigned int  secondary_dns;
  unsigned char  max_ul;                            // Maximum uplink bitrate: 64kbps=0, 384kbps=1, max kbps=2
  unsigned char  max_dl;                            // Maximum downlink bitrate: 64kbps=0, 384kbps=1, max kbps=2
  unsigned char  guar_ul;
  unsigned char  guar_dl;
  unsigned char  residual_error;
  unsigned char  delivery_order;
  unsigned char  delivery_sub_error;
  unsigned char  traffic_handling_priority;
  unsigned int  max_sdu_size;
  unsigned int  traffic_delay;
} wmm_profile_info_type;

typedef struct
{
  boolean  apn_name;                    // valid profile number are 1 -16
  boolean  pdp_type;
  boolean max_ul;
  boolean max_dl;
} wmm_profile_write_enable_type;

typedef PACKED struct
{
  uint8 year;
  uint8 month;
  uint8 day;
  uint8 hour;
  uint8 minute;
  uint8 second;
  uint8 day_of_week;
  int8 time_zone;
  uint8 daylt_sav_adj;
  uint8 radio_if;
} wmm_nitz_time_info_type;

typedef struct {
  uint8     security;
  boolean rrc_integrity_enabled;
  boolean rrc_ciphering_enabled;
  boolean rrc_fake_security_enabled;
} RIL_Security_Info;

typedef struct {
  uint16   pref_mode;
  uint16   service_domain_pref;
  RIL_Security_Info   security_info;
  byte      sms_gw_bearer_pref;
  uint8      ipv6_enabled;
  uint8      isr_enabled;
  uint8      rrc_version;
  uint8 wcdma_dl_freq;
  uint32 user_freq;
  uint16  gcf_test_mode;
} RIL_Protocol_Info;

typedef struct {
  uint8 initialized_plmn_name;  
  uint16  mcc;
  uint16  mnc;
  char plmn_name_short[255];
  char plmn_name_long[255];  
} RIL_Operator_Info;

typedef struct {
  uint16   pcscf_port;
  char     pcscf_domain[255];
  boolean  ims_test_mode;
} RIL_Ims_Reg_Info;

typedef struct {
  char     domain_name[255];
} RIL_Ims_User_Info;

typedef struct {
  char     regConfigUserName[128];
  char     regConfigPassword[128];
  char     regConfigPrivateURI[128];
  char     regConfigDomainName[256];
} RIL_Ims_Param_Config;

typedef struct {
  uint8 DisableAutoConfig;
  char RCSConfigServerAddress[45];
  char RCSConfigServerPort[5];
} RIL_Ims_Rcs_Auto_Config;
//hongsg 20140729
typedef struct {
  uint8     rtcp;
} RIL_Ims_Qipcall_Config;

typedef struct {
  uint8     reg_event_packet;
} RIL_Ims_Reg_Config;

typedef struct {
  uint16  sip_local_port;
  uint32  timer_sip_reg;
  uint32  subscribe_timer;
  uint32  timer_t1;
  uint32  timer_t2;
  uint32  timer_f;
} RIL_Ims_Sip_Info;

typedef struct {
  uint16  session_expiry_timer;
  uint16  min_session_expiry;
  boolean amr_wb_enable;
  uint8 amr_mode;
  uint16 amr_wb_mode;
  boolean amr_octet_align;
  boolean amr_wb_octet_align;
} RIL_Ims_Voip_Info;

typedef struct {
  uint8   voip_service_status;
} RIL_Imsa_Service_Status_Info;


#define MAX_AVG_RF_DATA_INDEX 10
typedef struct
{
  int count;
  int avg;
  int value[MAX_AVG_RF_DATA_INDEX];
} qmi_nas_avg_rf_data_type;

typedef struct {
  char  profile_num;                    // valid profile number are 1 -16
  char class_id;
  char  apn_length;
  char  apn [100 + 1];
  char  iptype;                         // Pdp type: IP=0, PPP=1
  unsigned int  ip_addr;
  char apn_disabled_flag;
  uint32  inactivity_timer;
  char  bearer;
  uint16 max_conn;
  uint16 max_conn_t;
  uint16 wait_time;
} RIL_Apn_Info;
#pragma pack()

typedef struct {
  boolean   ims_registered;
  uint16   ims_registration_failure_error_code;
} RIL_Imsa_Reg_Status_Info;

typedef struct {
  char UserAgent[1024];
} RIL_Ims_User_Agent; //hongsg 20140821

typedef struct {
  uint32  timer_t1;
  uint32  timer_t2;
  uint32  timer_f;
} RIL_Ims_Sip_Timer_Info;

#endif /*DIAG_PACKET_H*/
