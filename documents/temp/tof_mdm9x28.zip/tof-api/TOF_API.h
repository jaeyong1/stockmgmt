#ifndef	LGIT_TOF_API_H
#define	LGIT_TOF_API_H
/******************************************************************************
  @file    TOF_API.h
  @brief   lgit tof_api lib

  DESCRIPTION
  
  ---------------------------------------------------------------------------
  Copyright (c) 2016 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/
#include "TOF_Definition.h"

#ifdef __cplusplus
  extern "C" {
#endif

/*===========================================================================
  Constant Define
===========================================================================*/

/*=========================================================================*/
// Event
/*=========================================================================*/

typedef enum
{
  // ## sync with TOF JAVA APIs.. do not change ordering..  ##
	TOF_EVENT_NULL = 0,
  //DMS
  TOF_EVENT_GET_MODEM_VERSION,  // 1
  TOF_EVENT_GPIO_USB_CONNECTED_IND,

  //NAS
  TOF_REQUEST_SET_PREFERRED_NETWORK_TYPE,
  TOF_REQUEST_GET_PREFERRED_NETWORK_TYPE,
  TOF_EVENT_NETWORK_STATE_CHANGED, //5
  TOF_EVENT_SIGNAL_STRENGTH_CHANGED,
	
  //UIM
  TOF_EVENT_RESPONSE_SIM_STATUS_CHANGED,
  TOF_IND_SIM_REFRESH,

  //VOICE
  TOF_EVENT_RESPONSE_CALL_STATE_CHANGED,

  //DATA
  TOF_EVENT_DATA_STATUS_CHANGED,//10

  //SMS
  TOF_EVENT_IND_RESPONSE_NEW_SMS, //dsji_20160311 add

  //GPS  //TOF_QMI_LOC
  TOF_EVENT_POSITION_REPORT_IND,
  TOF_EVENT_GNSS_SV_INFO_IND,  
  TOF_EVENT_POSITION_NMEA_REPORT_IND,
  TOF_EVENT_GPS_SET_OPERATION_MODE_IND, //15  
  TOF_EVENT_GPS_GET_OPERATION_MODE_IND,  
  TOF_EVENT_GPS_SET_NMEA_TYPE_IND,   
  TOF_EVENT_GPS_GET_NMEA_TYPE_IND,  
  TOF_EVENT_GET_REGISTERED_EVENT_IND,
  TOF_EVENT_SET_SUPL_SERVER_INFO_IND,  //20
  TOF_EVENT_GET_SUPL_SERVER_INFO_IND,
  TOF_EVENT_DELETE_ASSIST_DATA_IND,

  // IMSA
  TOF_EVENT_ACS_FAIL_IND,

  // WAKEUP_GPIO
  TOF_EVENT_WAKEUP_STATE_CHANGED,

//eCall
  TOF_EVENT_ECALL_IND, //25

//VOICE
	TOF_EVENT_RESPONSE_CALL_STATE_CHANGED_TO_DELAYED_HANGUP,  //26
	TOF_EVENT_RESPONSE_CALL_STATE_CHANGED_CALLMSG_RAWDATA, //27

  //GNSS  Added Jamming detection Indication
  TOF_EVENT_JAMMING_RF_REPORT_IND,  //28

  //NAS network search async result
  TOF_EVENT_RESPONSE_ASYNC_NETWORK_SEARCH_FINISHED, //29
  
  // USB_STORAGE
  TOF_EVENT_USB_STORAGE_CHANGED, //30

  //NAS Sim State	
  TOF_EVENT_RESPONSE_NAS_SIM_STATE_CHANGED, //31
  TOF_EVENT_MAX
} HK_EVENT_TYPE;



/*---------------------------------------------------------------------------
  TOF Callback Function Type
---------------------------------------------------------------------------*/
typedef void (*TOF_MODEM_CB)(uint32 dwEvent, uint32 wParam, uint32 lParam, void *pUserData);

/*=========================================================================*/
// Common Functions
/*=========================================================================*/

typedef enum {
  REQ_REGI_STATE_FROM_CACHE,
  REQ_DATA_REGI_STATE_FROM_CACHE,
  REQ_REGI_STATE_RUNTIME,
}REGISTRATION_REQ_TYPE;

/*===========================================================================
  FUNCTION  TOF_API_version
===========================================================================*/
/*!
@brief
  Get TOF library version.

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_API_version(char *ver);

/*===========================================================================
  FUNCTION  TOF_API_init
===========================================================================*/
/*!
@brief
  Init TOF library for API.

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_API_init(void);

/*===========================================================================
  FUNCTION  TOF_API_release
===========================================================================*/
/*!
@brief
  Release TOF library for API.

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_API_release(void);

/*===========================================================================
  FUNCTION  TOF_SetEventHandle
===========================================================================*/
/*!
@brief
  Set event handler for TOF API. When event occur pFunc & pUserData called by TOF.

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_SetEventHandle(TOF_MODEM_CB pFunc, void *pUserData);

/*===========================================================================
  FUNCTION  TOF_request_set_audio_volume
===========================================================================*/
/*!
@brief
  Set audio volume

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_set_audio_volume(int volume);

/*===========================================================================
  FUNCTION  TOF_request_get_audio_volume
===========================================================================*/
/*!
@brief
  Get audio volume

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_get_audio_volume(int *volume);

/*===========================================================================
  FUNCTION  1.6.	TOF_gpio_config
===========================================================================*/
/*!
@brief
  Configure GPIO
  flag : GPIO_INPUT, GPIO_OUTPUT

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_gpio_config(int gpio_num, int flag);

/*===========================================================================
  FUNCTION  1.6.	TOF_gpio_get_direction
===========================================================================*/
/*!
@brief
  Configure GPIO
  dir : in, out

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_gpio_get_direction(int gpio_num, char* dir);

/*===========================================================================
  FUNCTION  1.6.	TOF_gpio_set
===========================================================================*/
/*!
@brief
  Set GPIO Output status
  status : LOW -> 0, HIGH -> 1

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_gpio_set(int gpio_num, int status);

/*===========================================================================
  FUNCTION  1.6.	TOF_gpio_get_edge
===========================================================================*/
/*!
@brief
  Get GPIO Edge status
  edge : "none", "falling", "rising", "both"
  
@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_gpio_get_edge(int gpio_num, char* edge);

/*===========================================================================
  FUNCTION  1.6.	TOF_gpio_set_edge
===========================================================================*/
/*!
@brief
  Set GPIO Edge for interrupt
  edge : "none", "falling", "rising", "both"

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_gpio_set_edge(int gpio_num, char* edge);

/*===========================================================================
  FUNCTION  1.6.	TOF_gpio_fd_open
===========================================================================*/
/*!
@brief
  Get GPIO file descriptor

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_gpio_fd_open(int gpio_num,int *gpio_fd);

/*===========================================================================
  FUNCTION  1.6.	TOF_gpio_fd_close
===========================================================================*/
/*!
@brief
  Close GPIO file descriptor

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_gpio_fd_close(int gpio_fd);



/*===========================================================================
  FUNCTION  1.6.	TOF_gpio_get
===========================================================================*/
/*!
@brief
  Get GPIO status
  status : 0 -> LOW, 1 -> HIGH
  
@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_gpio_get(int gpio_num, int *status);

/*===========================================================================
  FUNCTION  TOF_SetLogPrint
===========================================================================*/
/*!
@brief
  Set logging state TOF library. (TRUE : ON, FALSE : OFF)

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_SetLogPrint(boolean state);

/*=========================================================================*/
// Device Information Functions
/*=========================================================================*/

/*===========================================================================
  FUNCTION  TOF_request_get_basebandversion
===========================================================================*/
/*!
@brief
  Get device informartion as below.
  1) S/W Version
  2) Model Name
  3) Build Date
  4) RF Cal Information
  5) H/W Version

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_get_basebandversion(tof_dms_get_modem_sw_version_resp_msg *get_modem_sw_version);

/*===========================================================================
  FUNCTION  TOF_request_get_imei
===========================================================================*/
/*!
@brief
  Get device IMEI.

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_get_imei(char* imei);

/*======================================================================

FUNCTION TOF_request_modem_reset

DESCRIPTION
modem reset

======================================================================*/
extern int TOF_request_modem_reset(void);

/*======================================================================

FUNCTION TOF_request_modem_init

DESCRIPTION
modem init

======================================================================*/
extern int TOF_request_modem_init(void);

/*===========================================================================
  FUNCTION  TOF_request_get_phone_number
===========================================================================*/
/*!
@brief
  Get MSISDN(Phone Number).

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_get_phone_number(char* phone_number);

/*===========================================================================
  FUNCTION  TOF_request_get_iccid
===========================================================================*/
/*!
@brief
  Get ICCID(SIM ID).

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_get_iccid(char* iccid);

/*===========================================================================
  FUNCTION  TOF_request_get_exception_count
===========================================================================*/
/*!
  @brief
  It is used to get the exception total count.
    
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
*/
extern int TOF_request_get_exception_count(uint8 *count);

/*===========================================================================
  FUNCTION  TOF_request_get_exception_info
===========================================================================*/
/*!
  @brief
  It is used to get the exception information.
    
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
*/
extern int TOF_request_get_exception_info(uint8 index, tof_dms_get_exception_info *exception_info);

/*===========================================================================
  FUNCTION  TOF_request_delete_exception_info
===========================================================================*/
/*!
  @brief
  It is used to delete the all exeption information.
    
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
*/
extern int TOF_request_delete_exception_info(void);

/*=========================================================================*/
// USIM Functions
/*=========================================================================*/

/*===========================================================================
  FUNCTION  TOF_request_get_sim_status
===========================================================================*/
/*!
@brief
  Get SIM Status. (RIL_CardStatus_v6)

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_get_sim_status(RIL_CardStatus_v6 *pcard_status);

/*===========================================================================
  FUNCTION  TOF_request_get_pin_status
===========================================================================*/
/*!
@brief
  Get SIM Status. (RIL_PinStatus)

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_get_pin_status(RIL_PinStatus *pin_status);

/*===========================================================================
  FUNCTION  TOF_request_enter_sim_pin
===========================================================================*/
/*!
@brief
  Enter SIM PIN

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_enter_sim_pin(uint8 pin_id, uint8 *pin_value, uint8 pin_operation);

/*===========================================================================
  FUNCTION  TOF_request_enter_sim_pin2
===========================================================================*/
/*!
@brief
  Enter SIM PIN2

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_enter_sim_pin2(uint8 pin_id, uint8 *pin_value, uint8 pin_operation);

/*===========================================================================
  FUNCTION  TOF_request_enter_sim_puk
===========================================================================*/
/*!
@brief
  Enter PUK

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_enter_sim_puk(uint8 pin_id, uint8 *puk_value, uint8 *new_pin_value);

/*===========================================================================
  FUNCTION  TOF_request_enter_sim_puk2
===========================================================================*/
/*!
@brief
  Enter PUK

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_enter_sim_puk2(uint8 pin_id, uint8 *puk_value, uint8 *new_pin_value);

/*===========================================================================
  FUNCTION  TOF_request_change_sim_pin
===========================================================================*/
/*!
@brief
  Change PIN

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_change_sim_pin(uint8 pin_id, uint8 *old_pin_value, uint8 *new_pin_value);

/*===========================================================================
  FUNCTION  TOF_request_change_sim_pin2
===========================================================================*/
/*!
@brief
  Change PIN2

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_change_sim_pin2(uint8 pin_id, uint8 *old_pin_value, uint8 *new_pin_value);

/*===========================================================================
  FUNCTION  TOF_unlock_sim
===========================================================================*/
extern int TOF_unlock_sim(char *pin);

/*===========================================================================
  FUNCTION  TOF_is_locked
===========================================================================*/
extern int TOF_is_locked(boolean *lock);

/*===========================================================================
  FUNCTION  TOF_is_enabled
===========================================================================*/
extern int TOF_is_enabled(boolean *enabled);

/*===========================================================================
  FUNCTION  TOF_GetSubscriberId
===========================================================================*/
extern int TOF_GetSubscriberId(uint8 *subsid);

/*===========================================================================
  FUNCTION  TOF_GetICCIdentification
===========================================================================*/
extern int TOF_GetICCIdentification(uint8 *iccid);

/*===========================================================================
  FUNCTION  TOF_IsPresent
===========================================================================*/
extern boolean TOF_IsPresent(void);

/*===========================================================================
  FUNCTION  TOF_ReadFPLMN
===========================================================================*/
extern int TOF_ReadFPLMN(uint8 *fplmn);

/*===========================================================================
  FUNCTION  TOF_WriteFPLMN
===========================================================================*/
extern int TOF_WriteFPLMN(uint8 *fplmn);

/*===========================================================================
  FUNCTION  TOF_getIMSI
===========================================================================*/
extern int TOF_getIMSI(uint64 *imsi);

/*===========================================================================
  FUNCTION  TOF_getMSIN
===========================================================================*/
extern int TOF_getMSIN(uint64 *msin);

/*===========================================================================
  FUNCTION  TOF_getMSINString
===========================================================================*/
extern int TOF_getMSINString(char *msin);

/*===========================================================================
  FUNCTION  TOF_getMCC
===========================================================================*/
extern int TOF_getMCC(void);

/*===========================================================================
  FUNCTION  TOF_getMCCString
===========================================================================*/
extern int TOF_getMCCString(char *mcc);

/*===========================================================================
  FUNCTION  TOF_getMNC
===========================================================================*/
extern int TOF_getMNC(void);

/*===========================================================================
  FUNCTION  TOF_getMNCString
===========================================================================*/
extern int TOF_getMNCString(char *mnc);

/*===========================================================================
  FUNCTION  TOF_setFieldsChangedEvent
===========================================================================*/
extern int TOF_setFieldsChangedEvent(void);

/*===========================================================================
  FUNCTION  TOF_request_dial
===========================================================================*/
/*!
@brief
  Originate Voice Call (TOF_Dial)

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_dial(TOF_Dial *dial);

/*===========================================================================
  FUNCTION  TOF_request_get_imsi
===========================================================================*/
/*!
@brief
  Get IMSI.

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_get_imsi(char* imsi);

/*===========================================================================
  FUNCTION  TOF_request_get_imeisv
===========================================================================*/
/*!
@brief
  Get IMEISV.

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_get_imeisv(char* imeisv);

/*===========================================================================
  FUNCTION  TOF_request_get_current_calls
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_get_current_calls(TOF_Current_Call_Info *Call_info);
/*===========================================================================
  FUNCTION  TOF_request_hangup
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_hangup(uint8 call_id);

/*===========================================================================
  FUNCTION  TOF_request_answer
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_answer();

/*===========================================================================
  FUNCTION  TOF_request_last_call_fail_cause
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

int TOF_request_last_call_fail_cause(int* cause);

/*===========================================================================
  FUNCTION  TOF_request_switch_waiting_or_holding_and_active
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
int TOF_request_switch_waiting_or_holding_and_active(void);

/*===========================================================================
  FUNCTION  TOF_request_hangup_foreground_resume_background
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
int TOF_request_hangup_foreground_resume_background(void);

/*===========================================================================
  FUNCTION  TOF_request_hangup_waiting_or_background
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
int TOF_request_hangup_waiting_or_background(void);

/*===========================================================================
  FUNCTION  TOF_request_dtmf_start
===========================================================================*/
/*!
@brief

Start playing a DTMF tone. Continue playing DTMF tone until
TOF_request_dtmf_stop is received

If a TOF_request_dtmf_start is received while a tone is currently playing,
it should cancel the previous tone and play the new one.

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
int TOF_request_dtmf_start(char* key);

/*===========================================================================
  FUNCTION  TOF_request_dtmf_stop
===========================================================================*/
/*!
@brief

Stop playing a currently playing DTMF tone.

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
int TOF_request_dtmf_stop(void);

/*===========================================================================
  FUNCTION  TOF_request_dtmf
===========================================================================*/
/*!
@brief

Send a DTMF tone

Automatically transmits a STOP DTMF after START DTMF transmission.
Interval between START DTMF and STOP DTMF shall be in accordance with the default time(140ms).

If the implementation is currently playing a tone requested via
TOF_request_dtmf_start, that tone should be cancelled and the new tone
should be played instead

NOTE 1: If the Network operator implements the time limit option, 
        then the tone ends if the timer expires before the 'Stop DTMF' is received.


See also: TOF_request_dtmf_stop, TOF_request_dtmf_start

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
int TOF_request_dtmf(char* dtmf_data);

/*===========================================================================
  FUNCTION  TOF_request_data_registration_state
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_data_registration_state(tof_registration_status_type *t_data_regi_stateu);

/*===========================================================================
  FUNCTION  TOF_request_voice_registration_state
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_voice_registration_state(tof_registration_status_type *t_voice_regi_stateu);

/*===========================================================================
  FUNCTION  TOF_request_signal_strength
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_signal_strength(TOF_SignalStrength* tof_signal_strength);

/*===========================================================================
  FUNCTION  TOF_request_set_pref_network
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_set_pref_network(uint16 tof_mode_pref);

/*===========================================================================
  FUNCTION  TOF_request_get_pref_network
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_get_pref_network(uint16 *tof_mode_pref);

/*===========================================================================
  FUNCTION  TOF_request_set_pref_mode
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_set_pref_mode(uint16 tof_mode_pref, uint64 tof_mode_band_pref );

/*===========================================================================
  FUNCTION  TOF_request_get_pref_mode
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_get_pref_mode(uint16 *tof_mode_pref, uint64 *tof_mode_band_pref);



/*===========================================================================
  FUNCTION  TOF_request_get_service_domain
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_get_service_domain(uint16 * tof_service_domain);

/*===========================================================================
  FUNCTION  TOF_request_set_service_domain
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_set_service_domain(uint16 tof_service_doamin);

/*===========================================================================
  FUNCTION  TOF_request_set_wcdma_rrc_version
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_set_wcdma_rrc_version(uint16 tof_rrc_version);

/*===========================================================================
  FUNCTION  TOF_request_get_wcdma_rrc_version
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_get_wcdma_rrc_version(uint16 * tof_rrc_version);

/*===========================================================================
  FUNCTION  TOF_request_get_wcdma_sms_mo_domain
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_get_wcdma_sms_mo_domain(byte * tof_mo_domain);

/*===========================================================================
  FUNCTION  TOF_request_set_wcdma_sms_mo_domain
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_set_wcdma_sms_mo_domain(byte tof_mo_domain);

/*===========================================================================
  FUNCTION  TOF_request_set_isr_enable
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_set_isr_enable(boolean tof_isr_enable);

/*===========================================================================
  FUNCTION  TOF_request_get_isr_enable
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_get_isr_enable(boolean * tof_isr_enable);

/*===========================================================================
  FUNCTION  TOF_request_delete_stored_cell
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_delete_stored_cell();

/*===========================================================================
  FUNCTION  TOF_request_get_network_selection_mode
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_get_network_selection_mode(uint8* net_sel_mode);

/*===========================================================================
  FUNCTION  TOF_request_set_network_selection_auto
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_set_network_selection_auto();

/*===========================================================================
  FUNCTION  TOF_request_get_operator
===========================================================================*/
/*!
@brief


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_get_operator(TOF_Operator_Info *Tof_Operator);

/*===========================================================================
  FUNCTION  TOF_request_set_ims_auth_scheme
===========================================================================*/
/*!
@brief
  it is used to set a IMS Auth Scheme.

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_set_ims_auth_scheme(uint8 auth_scheme);

/*===========================================================================
  FUNCTION  TOF_request_get_ims_auth_scheme
===========================================================================*/
/*!
@brief
 it is used to get a status of IMS Auth Scheme.


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_get_ims_auth_scheme(uint8 *auth_scheme);

/*===========================================================================
  FUNCTION  TOF_request_set_ims_dpl_param_src
===========================================================================*/
/*!
@brief
  it is used to set a IMS DPL Param Source

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_set_ims_dpl_param_src(uint8 ims_param_src);

/*===========================================================================
  FUNCTION  TOF_request_get_ims_dpl_param_src
===========================================================================*/
/*!
@brief
 it is used to get a status of IMS DPL Param Source.


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_get_ims_dpl_param_src(uint8 *ims_param_src);

/*===========================================================================
  FUNCTION  TOF_request_set_reg_event
===========================================================================*/
/*!
@brief
  it is used to set a value for whether Reg Event will be used or not

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_set_reg_event(uint8 ims_reg_event_en);

/*===========================================================================
  FUNCTION  TOF_request_get_reg_event
===========================================================================*/
/*!
@brief
 it is used to get a value for whether Reg Event will be used or not


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_get_reg_event(uint8 *ims_reg_event_en);


/*===========================================================================
  FUNCTION  TOF_request_setup_data_call
===========================================================================*/
/*!
@brief

  
@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_setup_data_call(int profile, tof_qcmap_msgr_ip_family_enum_v01 ip_family);

/*===========================================================================
  FUNCTION  TOF_request_deactivate_data_call
===========================================================================*/
/*!
@brief

  
@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_deactivate_data_call(void);

/*===========================================================================
  FUNCTION  TOF_request_data_call_list
===========================================================================*/
/*!
@brief

  
@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_data_call_list(tof_data_call_response* call_resp);

/*===========================================================================
  FUNCTION  TOF_request_last_data_call_fail_cause
===========================================================================*/
/*!
@brief

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_last_data_call_fail_cause(int32_t* reason_code);

/*===========================================================================
  FUNCTION  TOF_request_enable_data_auto_connect
===========================================================================*/
/*!
@brief

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_enable_data_auto_connect(int profile);

/*===========================================================================
  FUNCTION  TOF_request_disable_data_auto_connect
===========================================================================*/
/*!
@brief

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_disable_data_auto_connect(void);

/*===========================================================================
  FUNCTION  TOF_request_get_data_auto_connect
===========================================================================*/
/*!
@brief

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_get_data_auto_connect(boolean* enable);

/*===========================================================================
  FUNCTION  TOF_request_set_data_profile_info
===========================================================================*/
/*!
@brief

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_set_data_profile_info(int profile, char* apn_name, tof_qcmap_msgr_ip_family_enum_v01 ip_family);

/*===========================================================================
  FUNCTION  TOF_request_get_data_profile_info
===========================================================================*/
/*!
@brief

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_request_get_data_profile_info(int profile, char* apn_name, int apn_name_buf_len, tof_qcmap_msgr_ip_family_enum_v01* ip_family);
//20170215 yjoh add for cell info
extern int TOF_request_get_cell_info(TOF_cellinfo *cellinfo);

#ifdef FEATURE_TOF_UI
extern int TOF_request_send_sms( const TOF_request_send_sms_s* const TOF_request_data, TOF_response_send_sms_s* TOF_response_data );
extern int TOF_request_delete_sms( const TOF_request_delete_sms_s* const TOF_request_data, TOF_response_delete_sms_s* TOF_response_data );
extern int TOF_request_read_sms( const TOF_request_read_sms_s* const TOF_request_data, TOF_response_read_sms_s* TOF_response_data );
extern int TOF_request_list_sms( const TOF_request_list_sms_s* const TOF_request_data, TOF_response_list_sms_s* TOF_response_data );
extern int TOF_request_get_smsc_address( const TOF_request_get_smsc_address_s* const TOF_request_data, TOF_response_get_smsc_address_s* TOF_response_data );
extern int TOF_request_set_smsc_address( const TOF_request_set_smsc_address_s* const TOF_request_data, TOF_response_set_smsc_address_s* TOF_response_data );
extern int TOF_request_get_memory_status( const TOF_request_get_memory_status_s* const TOF_request_data, TOF_response_get_memory_status_s* TOF_response_data );

extern int TOF_request_encode_sms(const TOF_wms_request_encode_sms_s TOF_request_data, unsigned char *TOF_response_data);
extern int TOF_request_send_sms_pdu(const char* pdu);
extern int TOF_request_read_sms_pdu(const int index, unsigned char* pdu_ascii);
#endif

/*===========================================================================
  FUNCTION  TOF_request_gps_reg_event
===========================================================================*/
extern int TOF_request_gps_reg_event(TOF_Loc_Event_Reg_Mask_type output_type);

/*===========================================================================
  FUNCTION  TOF_request_gps_start
===========================================================================*/
extern int TOF_request_gps_start(void);

/*===========================================================================
  FUNCTION  TOF_request_gps_stop
===========================================================================*/
extern int TOF_request_gps_stop(void);

/*===========================================================================
  FUNCTION  TOF_request_gps_set_nmea_type
===========================================================================*/
extern int TOF_request_gps_set_nmea_type(uint32 type);

/*===========================================================================
  FUNCTION  TOF_request_gps_get_nmea_type
===========================================================================*/
extern int TOF_request_gps_get_nmea_type();

/*===========================================================================
  FUNCTION  TOF_request_gps_set_operation_mode
===========================================================================*/
extern int TOF_request_gps_set_operation_mode(uint16 mode);

/*===========================================================================
  FUNCTION  TOF_request_gps_get_operation_mode
===========================================================================*/
extern int TOF_request_gps_get_operation_mode();

/*===========================================================================
  FUNCTION  TOF_request_gps_set_spl_server_info
===========================================================================*/
extern int TOF_request_gps_set_spl_server_info(tof_loc_spl_server_info_type t_supl_info);

/*===========================================================================
  FUNCTION  TOF_request_gps_get_spl_server_info
===========================================================================*/
extern int TOF_request_gps_get_spl_server_info(int server_type);

/*===========================================================================
  FUNCTION  TOF_request_gps_spl_server_open
===========================================================================*/
extern int TOF_request_gps_spl_server_conn_handle(UINT8 open_close);

/*===========================================================================
  FUNCTION  TOF_request_gps_del_assist_data
===========================================================================*/
extern int TOF_request_gps_del_assist_data(UINT8 all_data);

/*===========================================================================
  FUNCTION  TOF_request_gps_getLatitude
===========================================================================*/
extern int TOF_request_gps_getLatitude(double* lat);
/*===========================================================================
  FUNCTION  TOF_request_gps_getLongitude
===========================================================================*/
extern int TOF_request_gps_getLongitude(double* lon);

/*===========================================================================
  FUNCTION  TOF_request_gps_getAltitude
===========================================================================*/
extern int TOF_request_gps_getAltitude(float* alt);

/*===========================================================================
  FUNCTION  TOF_request_gps_getHeading
===========================================================================*/
extern int TOF_request_gps_getHeading(float* heading);

/*===========================================================================
  FUNCTION  TOF_request_gps_getSpeed
===========================================================================*/
extern int TOF_request_gps_getSpeed(float* speed);

/*===========================================================================
  FUNCTION  TOF_request_gps_getVerticalSpeed
===========================================================================*/
extern int TOF_request_gps_getVerticalSpeed(float* vspeed);

/*===========================================================================
  FUNCTION  TOF_request_gps_getVDOP
===========================================================================*/
extern int TOF_request_gps_getVDOP(float* vdop);

/*===========================================================================
  FUNCTION  TOF_request_gps_getHDOP
===========================================================================*/
extern int TOF_request_gps_getHDOP(float* hdop);

/*===========================================================================
  FUNCTION  TOF_request_gps_PDOP
===========================================================================*/
extern int TOF_request_gps_getPDOP(float* pdop);

/*===========================================================================
  FUNCTION  TOF_request_gps_getSpeedAccuracy
===========================================================================*/
extern int TOF_request_gps_getSpeedAccuracy(float* sacc);

/*===========================================================================
  FUNCTION  TOF_request_gps_getAltitudeMSL
===========================================================================*/
extern int TOF_request_gps_getAltitudeMSL(float* altmsl);

/*===========================================================================
  FUNCTION  TOF_request_gps_getHorizontalAccuracy
===========================================================================*/
extern int TOF_request_gps_getHorizontalAccuracy(float* hacc);

/*===========================================================================
  FUNCTION  TOF_request_gps_getGnssSVInfo
===========================================================================*/
extern int TOF_request_gps_getGnssSVInfo(tof_qmiLocEventGnssSvInfoIndMsgT_v02  *SVInfo);

/*===========================================================================
  FUNCTION  TOF_request_gps_getPositionInfo
===========================================================================*/
extern int TOF_request_gps_getPositionInfo(tof_qmiLocEventPositionReportIndMsgT_v02  *poInfo);

#ifdef FEATURE_TOF_WIFI
/*===========================================================================
  FUNCTION  TOF_request_gps_get_reg_event
===========================================================================*/
extern int TOF_request_gps_get_reg_event(void);


/*===========================================================================
  FUNCTION  TOF_wifi_connect
===========================================================================*/
extern int TOF_wifi_connect(char* ssid, char* pw, int encryption);

/*===========================================================================
  FUNCTION  TOF_wifi_disconnect
===========================================================================*/
extern int TOF_wifi_disconnect();

/*===========================================================================
  FUNCTION  TOF_wifi_module_unload
===========================================================================*/
extern int TOF_wifi_module_unload();
/*===========================================================================
  FUNCTION  TOF_wifi_module_load
===========================================================================*/
extern int TOF_wifi_module_load();
#endif

#ifdef FEATURE_TOF_AUDIO_CONTROL
/*===========================================================================
  FUNCTION  TOF_START_VOICE_CALL
===========================================================================*/
extern int TOF_START_VOICE_CALL(void);
/*===========================================================================
  FUNCTION  TOF_END_VOICE_CALL
===========================================================================*/
extern int TOF_END_VOICE_CALL(void);
/*===========================================================================
  FUNCTION  TOF_AUDIO_LOOBACK
===========================================================================*/
extern int TOF_AUDIO_LOOBACK(void);
/*===========================================================================
  FUNCTION  TOF_TONE_PLAY
===========================================================================*/
extern int TOF_TONE_PLAY(void);
#endif
/*===========================================================================
  FUNCTION  TOF_request_set_volte
===========================================================================*/
/*!
@brief
It is used to set a VoLTE function.

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_set_volte(boolean on_off);

/*===========================================================================
  FUNCTION  TOF_request_set_volte
===========================================================================*/
/*!
@brief
It is used to get a status of VoLTE function.

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_request_get_volte(uint8 *on_off);

/*===========================================================================
  FUNCTION  TOF_request_ims_enable
===========================================================================*/
/*!
@brief
It is used to enable/disable a IMS service.

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
extern int TOF_request_set_ims_enable(uint8 enable);

/*===========================================================================
  FUNCTION  TOF_request_ims_enable
===========================================================================*/
/*!
@brief
It is used to get a status of IMS setting whether IMS is set to use or not.

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
extern int TOF_request_get_ims_enable(uint8 *enable);

/*===========================================================================
  FUNCTION  TOF_request_set_volte_session_timer
===========================================================================*/
/*!
@brief
It is used to set a session timer of VoLTE.

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
extern int TOF_request_set_volte_session_timer(uint16 sess_time);

/*===========================================================================
  FUNCTION  TOF_request_get_volte_session_timer
===========================================================================*/
/*!
@brief
It is used to get a session timer value for VoLTE.

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
extern int TOF_request_get_volte_session_timer(uint16 *sess_time);

/*===========================================================================
  FUNCTION  TOF_request_set_amr_payload_format
===========================================================================*/
/*!
@brief
It is used to set a AMR Payload format of VoLT.

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
extern int TOF_request_set_amr_payload_format(boolean amr_octet_alian);

/*===========================================================================
  FUNCTION  TOF_request_get_amr_payload_format
===========================================================================*/
/*!
@brief
It is used to get a AMR Payload format of VoLTE.

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
extern int TOF_request_get_amr_payload_format(boolean *amr_octet_alian);

/*===========================================================================
  FUNCTION  TOF_request_set_amr_wb_payload_format
===========================================================================*/
/*!
  @brief
  It is used to set a AMR WB Payload format of VoLTE.
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_set_amr_wb_payload_format(boolean amr_wb_octet_align);

/*===========================================================================
  FUNCTION  TOF_request_get_amr_wb_payload_format
===========================================================================*/
/*!
  @brief
  It is used to get a AMR WB Payload format of VoLTE.
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_get_amr_wb_payload_format(boolean *amr_wb_octet_align);

/*===========================================================================
  FUNCTION  TOF_request_set_amr_codec_mode_set
===========================================================================*/
/*!
  @brief
  It is used to set a AMR Codec Mode of VoLTE.
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_set_amr_codec_mode_set(uint8 amr_codec_mode);


/*===========================================================================
  FUNCTION  TOF_request_get_amr_codec_mode_set
===========================================================================*/
/*!
  @brief
  It is used to get a AMR Codec Mode of VoLTE.
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_get_amr_codec_mode_set(uint8 *amr_codec_mode);

/*===========================================================================
  FUNCTION  TOF_request_set_amr_wb_codec_mode_set
===========================================================================*/
/*!
  @brief
  It is used to set a AMR WB Codec Mode of VoLTE.
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_set_amr_wb_codec_mode_set(uint16 amr_wb_codec_mode);

/*===========================================================================
  FUNCTION  TOF_request_get_amr_wb_codec_mode_set
===========================================================================*/
/*!
  @brief
  It is used to get a AMR WB Codec Mode of VoLTE.
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_get_amr_wb_codec_mode_set(uint16 *amr_wb_codec_mode);

/*===========================================================================
  FUNCTION  TOF_request_set_amr_wb_enable
===========================================================================*/
/*!
  @brief
  It is used to set a AMR Enable of VoLTE.
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_set_amr_wb_enable(boolean amr_wb_enable);

/*===========================================================================
  FUNCTION  TOF_request_get_amr_wb_enable
===========================================================================*/
/*!
  @brief
  It is used to get a AMR Enable of VoLTE.
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_get_amr_wb_enable(boolean *amr_wb_enable);

/*===========================================================================
  FUNCTION  TOF_request_set_rtcp_enable
===========================================================================*/
/*!
  @brief
  It is used to set a RTCP Enable of VoLTE.
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_set_rtcp_enable(uint8 rtcp_enable);

/*===========================================================================
  FUNCTION  TOF_request_get_rtcp_enable
===========================================================================*/
/*!
  @brief
  It is used to get a RTCP Enable of VoLTE.
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_get_rtcp_enable(uint8 *rtcp_enable);

/*===========================================================================
  FUNCTION  TOF_request_set_pcscf_port
===========================================================================*/
/*!
  @brief
  It is used to set a pcscf port.
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_set_pcscf_port(uint16 pcscf_port);

/*===========================================================================
  FUNCTION  TOF_request_get_pcscf_port
===========================================================================*/
/*!
  @brief
  It is used to get a pcscf port.
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_get_pcscf_port(uint16 *pcscf_port);

/*===========================================================================
  FUNCTION  TOF_request_set_pcscf_domain
===========================================================================*/
/*!
  @brief
  It is used to set a pcscf domain name.
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_set_pcscf_domain(char *pcscf_domain);

/*===========================================================================
  FUNCTION  TOF_request_get_pcscf_domain
===========================================================================*/
/*!
  @brief
  It is used to get a pcscf domain name.
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_get_pcscf_domain(char *pcscf_domain);

/*===========================================================================
  FUNCTION  TOF_request_set_ims_test_mode
===========================================================================*/
/*!
  @brief
  It is used to enable/disable a ims test mode.
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_set_ims_test_mode(boolean ims_test_mode);

/*===========================================================================
  FUNCTION  TOF_request_get_ims_test_mode
===========================================================================*/
/*!
  @brief
  It is used to get a status of a ims test mode
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_get_ims_test_mode(boolean *ims_test_mode);

/*===========================================================================
  FUNCTION  TOF_request_set_sip_local_port
===========================================================================*/
/*!
  @brief
  It is used to set a SIP Local Port
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_set_sip_local_port(uint16 local_port);

/*===========================================================================
  FUNCTION  TOF_request_get_sip_local_port
===========================================================================*/
/*!
  @brief
  It is used to get a SIP Local Port
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_get_sip_local_port(uint16 *local_port);

/*===========================================================================
  FUNCTION  TOF_request_set_sip_reg_timer
===========================================================================*/
/*!
  @brief
  It is used to set a SIP Reg Timer
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_set_sip_reg_timer(uint32 reg_timer);

/*===========================================================================
  FUNCTION  TOF_request_get_sip_reg_timer
===========================================================================*/
/*!
  @brief
  It is used to get a SIP Reg Timer
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_get_sip_reg_timer(uint32 *reg_timer);

/*===========================================================================
  FUNCTION  TOF_request_set_sip_subscribe_timer
===========================================================================*/
/*!
  @brief
  It is used to set a SIP Subscribe timer
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_set_sip_subscribe_timer(uint32 subsc_timer);

/*===========================================================================
  FUNCTION  TOF_request_get_sip_subscribe_timer
===========================================================================*/
/*!
  @brief
  It is used to get a SIP Subscribe timer
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_get_sip_subscribe_timer(uint32 *subsc_timer);

/*===========================================================================
  FUNCTION  TOF_request_get_voip_srv_status
===========================================================================*/
/*!
  @brief
  It is used to get a voip service status
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_get_voip_srv_status(uint8 *voip_srv_status);

/*===========================================================================
  FUNCTION  TOF_request_get_ims_srv_status
===========================================================================*/
/*!
  @brief
  It is used to get a ims service status
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_get_ims_srv_status(tof_Imsa_Reg_Status_Info *ims_reg_stat);

/*===========================================================================
  FUNCTION  TOF_request_set_maxpwr
===========================================================================*/
/*!
  @brief
  It is used to set to force tx power
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
  
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_set_maxpwr(tof_dms_max_power_type_v01 max_pwr);

/*===========================================================================
  FUNCTION  TOF_request_set_ecall_enable
===========================================================================*/
/*!
  @brief
  It is used to set ecall feature enable or disable
  0 : disable
  1 : enable
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
    
  @author
    jaeyong1.park
    
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_set_ecall_enable(int mode); //jaeyong1.park
/*===========================================================================
  FUNCTION  TOF_request_set_ecall_number
===========================================================================*/
/*!
  @brief
  Set ECALL tel number in modem file(for test, set manully)
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
    
  @author
    jaeyong1.park
    
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_set_ecall_number(char* ecallnumber); //jaeyong1.park
extern int TOF_request_set_ecall_enable(int mode);

extern int TOF_request_set_ecall_vocconf (int numdata);
extern int 	TOF_request_set_ecall_cannedmsd(int numdata);
extern int 	TOF_request_set_ecall_numtodial(int numdata);
extern int TOF_request_set_ecall_gnsssestimeout(int numdata);
extern int 	TOF_request_set_ecall_callback_timeout(int numdata);


/*===========================================================================
  FUNCTION  TOF_request_enable_ecall_only_mode
===========================================================================*/
/*!
  @brief
  It is used to Enable/Disable ecall only mode
  0 : disable
  1 : enable
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
    
  @author
    jaeyong1.park
    
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_enable_ecall_only_mode(int mode);

/*===========================================================================
  FUNCTION  TOF_request_read_ecall_oper_mode
===========================================================================*/
/*!
  @brief
  It is used to read ecall operation mode
  
  @return
    TOF API Return Value ( 0 : TOF_SUCCESS)
    
  @author
    mwkim
    
  @note
    - Dependencies
    
    - Side Effects
    
  */
extern int TOF_request_read_ecall_oper_mode(uint8 * ecall_mode_value);


/*===========================================================================
  FUNCTION  TOF_request_get_ecall_enable
===========================================================================*/
/*!
@brief
Get ecall enable

@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
extern int TOF_request_get_ecall_enable(uint32 *enable);

extern int TOF_request_get_ecall_number(char* strdata);
extern int TOF_request_get_ecall_vocconf(char* strdata);
extern int TOF_request_get_ecall_cannedmsd(char* strdata);
extern int TOF_request_get_ecall_numtodial(char* strdata);
extern int TOF_request_get_ecall_gnsssestimeout(char* strdata);
extern int TOF_request_get_ecall_callback_timeout(char* strdata);

/*===========================================================================
  FUNCTION  TOF_request_get_gsm_dtm_supported
===========================================================================*/
/*!
@brief
Qualcomm devices support Class A. 
when camped on GSM, if the cell supports DTM (Dual TRasnfewr Mode), both GPRS and GSM services are possible simultaneously.
First parram indicated that cell supports DTM.


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
extern int TOF_request_get_gsm_dtm_supported(uint32* dtmsupported);


/*===========================================================================
  FUNCTION  TOF_request_get_gsm_pathhloss_criteria
===========================================================================*/
/*!
@brief
3GPP TS 45.008 6.1	
The path loss criterion parameter C1 used for cell selection and reselection.
The path loss criterion (3GPP TS 43.022) is satisfied if C1 > 0.


@return
  TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies
  
  - Side Effects
  
*/
extern int TOF_request_get_gsm_pathhloss_criteria(TOF_GSM_PathLossCriteria_list* criteria);


/*===========================================================================
  int TOF_getModemVersion(char* strdata))
===========================================================================*/
/*!
@brief
  Get modem image version

@return
 NONE

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern int TOF_getModemVersion(char* strdata);

/*===========================================================================
  int TOF_getApVersion(char* strdata)
===========================================================================*/
/*!
@brief
  Get AP version

@return
 NONE

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/


extern int TOF_getApVersion(char* strdata);

/*===========================================================================
  int TOF_get_is_roaming(uint8* data)
===========================================================================*/
/*!
@brief
  return is roaming or not

@return
 NONE

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_get_is_roaming(uint8* data);
	


/*===========================================================================
  int TOF_get_networkscan()
===========================================================================*/
/*!
@brief
  return network scan result

@return
 NONE

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/

extern int TOF_get_networkscan();
	



/*===========================================================================
  void TOF_setRingIndicatorLow(void)
===========================================================================*/
/*!
@brief
  Set RING indicator to Low value

@return
 NONE

@note
  - Dependencies
  
  - Side Effects
  
*/
/*=========================================================================*/
extern void TOF_setRingIndicatorLow(void);


/*===========================================================================
  int TOF_request_get_thermal_management_info
===========================================================================*/
/*!
@brief
  Get thermal mitigation information

@return
 NONE

@note
  - Dependencies

  - Side Effects

*/
/*=========================================================================*/
extern int TOF_request_get_thermal_management_info(tof_thermal_info *info);

/*===========================================================================
   int TOF_change_usb_composition(char *idproduct)
===========================================================================*/
/*!
@brief
  Change USB composition

@return
 NONE

@note
  - Dependencies

  - Side Effects

*/
/*=========================================================================*/
extern int TOF_change_usb_composition(char *idproduct);

/*===========================================================================
   int int TOF_get_enabled_usb_composition(void)
===========================================================================*/
/*!
@brief
  Get enabled USB composition

@return
  Number of USB product ID
  TOF API Return Value (1 : TOF_FAIL)

@note
  - Dependencies

  - Side Effects

*/
/*=========================================================================*/
extern int TOF_get_enabled_usb_composition(void);

/*===========================================================================
   int TOF_disable_usb_composition(void)
===========================================================================*/
/*!
@brief
  Disable USB composition

@return
	TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies

  - Side Effects

*/
/*=========================================================================*/
extern int TOF_disable_usb_composition(void);

/*===========================================================================
    int TOF_get_usb_mode(char *buf);
===========================================================================*/
/*!
@brief
  Get USB mode

@return
	TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies

  - Side Effects

*/
/*=========================================================================*/
extern int TOF_get_usb_mode(char *buf);

/*===========================================================================
    int TOF_change_usb_mode(char *mode;
===========================================================================*/
/*!
@brief
  Change USB mode

@return
	TOF API Return Value ( 0 : TOF_SUCCESS)

@note
  - Dependencies

  - Side Effects

*/
/*=========================================================================*/
extern int TOF_change_usb_mode(char *mode);

extern int TOF_get_usb_storage_state(char *state);

extern int TOF_setClockConfig(boolean nitzEnable,
                            boolean gnssEnable,
                            boolean ntpEnable,
                            char* ntpServerUrl);

extern int TOF_getCurrentClock(int *clk_source);

extern int TOF_set_reboot(char *reason);

extern int TOF_get_reboot(char *reason);

#ifdef __cplusplus
}
#endif

#endif
