/******************************************************************************
  @file    qmi_loc_lgit.c
  @brief   The QMI TOF API

  DESCRIPTION
  This file contains a API to use a QMI of modem processor.
  
  INITIALIZATION AND SEQUENCING REQUIREMENTS

  ---------------------------------------------------------------------------
  Copyright (c) 2016 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/
#include <string.h>

  //Qmi header
#include "qmi_client.h"  
#include <qmi.h>
#include "qmi_platform.h"
#include "qmi_i.h"

#include "qmi_loc_lgit.h"
//#include "location_service_v02.h"
#include "TOF_API.h"
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>


#define LOC_CLIENT_CB_DATA 0xDEAD

//set a session ID for TOF to "0xFE"
#define TOF_LOC_SESSION_ID  0xFE

#define QMI_LOC_MANDATORY_1_TLV_ID                      0x01
#define QMI_LOC_MANDATORY_2_TLV_ID                      0x02
#define QMI_LOC_MANDATORY_3_TLV_ID                      0x03
#define QMI_LOC_MANDATORY_4_TLV_ID                      0x04
#define QMI_LOC_MANDATORY_5_TLV_ID                      0x05
#define QMI_LOC_OPTIONAL_1_TLV_ID                       0x10
#define QMI_LOC_OPTIONAL_2_TLV_ID                       0x11
#define QMI_LOC_OPTIONAL_3_TLV_ID                       0x12
#define QMI_LOC_OPTIONAL_4_TLV_ID                       0x13
#define QMI_LOC_OPTIONAL_5_TLV_ID                       0x14
#define QMI_LOC_OPTIONAL_6_TLV_ID                       0x15
#define QMI_LOC_OPTIONAL_7_TLV_ID                       0x16
#define QMI_LOC_OPTIONAL_8_TLV_ID                       0x17
#define QMI_LOC_OPTIONAL_9_TLV_ID                       0x18

/*********************************************/
/*                          NMEA MASK                                   */
/*********************************************/
#define LOC_NMEA_MASK_ALL    0xffffffff
#define LOC_NMEA_MASK_GGA    0x00000001
#define LOC_NMEA_MASK_RMC    0x00000002
#define LOC_NMEA_MASK_GSV    0x00000004
#define LOC_NMEA_MASK_GSA    0x00000008
#define LOC_NMEA_MASK_VTG    0x00000010
#define LOC_NMEA_MASK_PQXFI  0x00000020
#define LOC_NMEA_MASK_PSTIS  0x00000040
#define LOC_NMEA_MASK_GLGSV  0x00000080
#define LOC_NMEA_MASK_GNGSA  0x00000100
#define LOC_NMEA_MASK_GNGNS  0x00000200
#define LOC_NMEA_MASK_GARMC  0x00000400
#define LOC_NMEA_MASK_GAGSV  0x00000800
#define LOC_NMEA_MASK_GAGSA  0x00001000
#define LOC_NMEA_MASK_GAVTG  0x00002000
#define LOC_NMEA_MASK_GAGGA  0x00004000
#define LOC_NMEA_MASK_PQGSA  0x00008000
#define LOC_NMEA_MASK_PQGSV  0x00010000
/**********************************************/

#define LOC_SPL_SV_IPV4_TYPE_LEN  6
#define LOC_SPL_SV_IPV6_TYPE_LEN  20

qmi_client_handle_type loc_client_handle = QMI_INVALID_CLIENT_HANDLE;
static int loc_service_initialized = FALSE;

static boolean loc_service_start = FALSE;
static boolean loc_event_registered = FALSE;

typedef enum{
  LOC_TIME_WAIT_CONN_STATUS_ID = 0,     //wait until receiving a QMI_LOC_EVENT_LOCATION_SERVER_CONNECTION_REQ (0x0031) after Starting A-GPS
  LOC_TIME_WAIT_TO_SEND_SRV_CONN_REQ_ID = 1,//wait to send a QMI_LOC_INFORM_LOCATION_SERVER_CONN_STATUS (0x0053) 
                                        // after receiving a QMI_LOC_EVENT_LOCATION_SERVER_CONNECTION_REQ (0x0031)
  LOC_TIME_WAIT_SERVER_CONN_ID = 2,         //wait until receiving a response of QMI_LOC_INFORM_LOCATION_SERVER_CONN_STATUS (0x0053)
  LOC_TIME_WAIT_SERVER_CONN_CLOSE_ID = 3,    //wait to send a QMI_LOC_INFORM_LOCATION_SERVER_CONN_STATUS (0x0053) with Close parameter.
  LOC_TIME_WAIT_MAX_ID = 4
}loc_time_count_id_type;

static loc_time_count_type time_cnt_def[LOC_TIME_WAIT_MAX_ID]={
  {LOC_TIME_WAIT_CONN_STATUS_ID ,           5/*sec*/,   FALSE,  FALSE, 0},
  {LOC_TIME_WAIT_TO_SEND_SRV_CONN_REQ_ID ,  1/*sec*/,   FALSE,  FALSE, 0},
  {LOC_TIME_WAIT_SERVER_CONN_ID ,           10/*sec*/,  FALSE,  FALSE, 0},
  {LOC_TIME_WAIT_SERVER_CONN_CLOSE_ID ,     2/*sec*/,   FALSE,  FALSE, 0}
};

static loc_oper_mode_type curr_gps_mode = LOC_OPER_MODE_DEFAULT;

// the Local variable which is containing a current general information of GPS Paramters.
static loc_static_curr_set_val_type static_curr_set_val;

// the Local variable which is saving a current information of ATL connection to handling this connection.
static qmiLocEventLocationServerConnectionReqIndMsgT_v02 static_curr_Loc_Server_Conn_Info;


static qmiLocEventPositionReportIndMsgT_v02 gps_Position_report_data;
static qmiLocEventGnssSvInfoIndMsgT_v02 gps_gnss_sv_info_data;
static qmiLocEventNmeaIndMsgT_v02 gps_nmea_ind_data;
/*---------------------------------------------------------------------------
   GPS Client cookie
---------------------------------------------------------------------------*/

loc_event_mask_convert_type loc_event_mask_type_convert[]={
  {LOC_EVENT_MASK_POSITION_REPORT ,                   QMI_LOC_EVENT_MASK_POSITION_REPORT_V02} , 
  {LOC_EVENT_MASK_GNSS_SV_INFO ,                      QMI_LOC_EVENT_MASK_GNSS_SV_INFO_V02} ,
  {LOC_EVENT_MASK_NMEA ,                              QMI_LOC_EVENT_MASK_NMEA_V02} , 
  {LOC_EVENT_MASK_NI_NOTIFY_VERIFY_REQ ,              QMI_LOC_EVENT_MASK_NI_NOTIFY_VERIFY_REQ_V02} , 
  {LOC_EVENT_MASK_INJECT_TIME_REQ ,                   QMI_LOC_EVENT_MASK_INJECT_TIME_REQ_V02} , 
  {LOC_EVENT_MASK_INJECT_PREDICTED_ORBITS_REQ ,       QMI_LOC_EVENT_MASK_INJECT_PREDICTED_ORBITS_REQ_V02} ,
  {LOC_EVENT_MASK_INJECT_POSITION_REQ ,               QMI_LOC_EVENT_MASK_INJECT_POSITION_REQ_V02} , 
  {LOC_EVENT_MASK_ENGINE_STATE ,                      QMI_LOC_EVENT_MASK_ENGINE_STATE_V02} , 
  {LOC_EVENT_MASK_FIX_SESSION_STATE ,                 QMI_LOC_EVENT_MASK_FIX_SESSION_STATE_V02} , 
  {LOC_EVENT_MASK_WIFI_REQ ,                          QMI_LOC_EVENT_MASK_WIFI_REQ_V02} , 
  {LOC_EVENT_MASK_SENSOR_STREAMING_READY_STATUS ,     QMI_LOC_EVENT_MASK_SENSOR_STREAMING_READY_STATUS_V02} ,
  {LOC_EVENT_MASK_TIME_SYNC_REQ ,                     QMI_LOC_EVENT_MASK_TIME_SYNC_REQ_V02} , 
  {LOC_EVENT_MASK_SET_SPI_STREAMING_REPORT ,          QMI_LOC_EVENT_MASK_SET_SPI_STREAMING_REPORT_V02} ,
  {LOC_EVENT_MASK_LOCATION_SERVER_CONNECTION_REQ ,    QMI_LOC_EVENT_MASK_LOCATION_SERVER_CONNECTION_REQ_V02} ,
  {LOC_EVENT_MASK_NI_GEOFENCE_NOTIFICATION ,          QMI_LOC_EVENT_MASK_NI_GEOFENCE_NOTIFICATION_V02} ,
  {LOC_EVENT_MASK_GEOFENCE_GEN_ALERT ,                QMI_LOC_EVENT_MASK_GEOFENCE_GEN_ALERT_V02} , 
  {LOC_EVENT_MASK_GEOFENCE_BREACH_NOTIFICATION ,      QMI_LOC_EVENT_MASK_GEOFENCE_BREACH_NOTIFICATION_V02} , 
  {LOC_EVENT_MASK_PEDOMETER_CONTROL ,                 QMI_LOC_EVENT_MASK_PEDOMETER_CONTROL_V02} , 
  {LOC_EVENT_MASK_MOTION_DATA_CONTROL ,               QMI_LOC_EVENT_MASK_MOTION_DATA_CONTROL_V02} , 
  {LOC_EVENT_MASK_BATCH_FULL_NOTIFICATION ,           QMI_LOC_EVENT_MASK_BATCH_FULL_NOTIFICATION_V02} , 
  {LOC_EVENT_MASK_LIVE_BATCHED_POSITION_REPORT ,      QMI_LOC_EVENT_MASK_LIVE_BATCHED_POSITION_REPORT_V02} ,
  {LOC_EVENT_MASK_INJECT_WIFI_AP_DATA_REQ ,           QMI_LOC_EVENT_MASK_INJECT_WIFI_AP_DATA_REQ_V02} ,
  {LOC_EVENT_MASK_GEOFENCE_BATCH_BREACH_NOTIFICATION ,QMI_LOC_EVENT_MASK_GEOFENCE_BATCH_BREACH_NOTIFICATION_V02}, 
  {LOC_EVENT_MASK_VEHICLE_DATA_READY_STATUS ,         QMI_LOC_EVENT_MASK_VEHICLE_DATA_READY_STATUS_V02} , 
  {LOC_EVENT_MASK_GNSS_MEASUREMENT_REPORT ,           QMI_LOC_EVENT_MASK_GNSS_MEASUREMENT_REPORT_V02},
  {LOC_EVENT_MASK_GNSS_SV_POLYNOMIAL_REPORT ,         QMI_LOC_EVENT_MASK_GNSS_SV_POLYNOMIAL_REPORT_V02} ,
  {LOC_EVENT_MASK_GEOFENCE_PROXIMITY_NOTIFICATION ,   QMI_LOC_EVENT_MASK_GEOFENCE_PROXIMITY_NOTIFICATION_V02} ,
  {LOC_EVENT_MASK_GDT_UPLOAD_BEGIN_REQ ,              QMI_LOC_EVENT_MASK_GDT_UPLOAD_BEGIN_REQ_V02} , 
  {LOC_EVENT_MASK_GDT_UPLOAD_END_REQ ,                QMI_LOC_EVENT_MASK_GDT_UPLOAD_END_REQ_V02} , 
  {LOC_EVENT_MASK_GEOFENCE_BATCH_DWELL_NOTIFICATION , QMI_LOC_EVENT_MASK_GEOFENCE_BATCH_DWELL_NOTIFICATION_V02} ,
  {LOC_EVENT_MASK_GET_TIME_ZONE_REQ ,                 QMI_LOC_EVENT_MASK_GET_TIME_ZONE_REQ_V02} , 
  {LOC_EVENT_MASK_BATCHING_STATUS,                    QMI_LOC_EVENT_MASK_BATCHING_STATUS_V02} ,
};

pthread_t loc_timer_thread = (pthread_t) NULL;
pthread_mutex_t loc_timer_thread_mutex;
pthread_cond_t loc_timer_thread_cond;
uint8 timerid_for_thread =0;

/*===========================================================================

  FUNCTION  tof_qmi_loc_init
  
===========================================================================*/
boolean tof_qmi_loc_init()
{
  int rc = QMI_INTERNAL_ERR;
  int qmi_err_code = QMI_NO_ERR;
  loc_0021_req_s loc_0021_req;


  if(loc_client_handle != QMI_INVALID_CLIENT_HANDLE)
  {
    MSG_ERROR("qmi_loc_lgit_init()loc_client_handle is valid ",0,0,0);
    RESULT_SUCCESS;
  }
  
  /* Bring up LOC  service for second port */
  if ((loc_client_handle = tof_qmi_loc_srvc_init_client (QMI_PORT_RMNET_0,
                                                 qmi_loc_srvc_indication_cb, // callback function. 
                                                 NULL, 
                                                 &qmi_err_code)) < 0)
  {
    QMI_ERR_MSG_2("Unable to start LOC service loc_client_handle= %x, qmi_err_code=%x\n", 
           loc_client_handle, 
           qmi_err_code);
    return RESULT_FAILURE;
  }
  else
  {
    QMI_ERR_MSG_1("Opened LOC Client. loc_client_handle= %x \r\n", loc_client_handle);
  }  

  //Init Static Variables
  loc_init_static_curr_set_val();
  
  //default NMEA 
//  qmi_loc_client_register_event(LOC_EVENT_MASK_NMEA);

  QMI_ERR_MSG_0("[LOC] EVENT_REGISER_SUCCESS\r\n");
  
  return RESULT_SUCCESS;
}

/*========================== Servie Function ================================*/

/*===========================================================================
  FUNCTION  qmi_loc_lgit_srvc_init_client
===========================================================================*/
/*!
@brief 
  This function is called to initialize the LOC service.  This function
  must be called prior to calling any other LOC service functions.
  For the time being, the indication handler callback and user data
  should be set to NULL until this is implemented.  Also note that this
  function may be called multiple times to allow for multiple, independent
  clients.   
  
@return 
  0 if abort operation was sucessful, < 0 if not.  If return code is 
  QMI_INTERNAL_ERR, then the qmi_err_code will be valid and will 
  indicate which QMI error occurred.

@note

  - Dependencies
    - qmi_connection_init() must be called for the associated port first.

  - Side Effects
    - Talks to modem processor
*/    
/*=========================================================================*/
qmi_client_handle_type
tof_qmi_loc_srvc_init_client
(
  const char                   *dev_id,
  qmi_loc_indication_hdlr_type  user_ind_msg_hdlr,
  void                          *user_ind_msg_hdlr_user_data,
  int                           *qmi_err_code
)
{
  qmi_client_handle_type client_handle;
  qmi_connection_id_type conn_id;
  
  QMI_ERR_MSG_0("tof_qmi_loc_srvc_init_client\r\n");
  
  if ((conn_id = QMI_PLATFORM_DEV_NAME_TO_CONN_ID(dev_id)) == QMI_CONN_ID_INVALID)
  {
    QMI_ERR_MSG_1("tof_qmi_loc_srvc_init_client: conn_id fail %x\r\n",conn_id);
    return QMI_INTERNAL_ERR;
  }

  QMI_ERR_MSG_1("tof_qmi_loc_srvc_init_client: conn_id %x\r\n",conn_id);
  
   /* Call common service layer initialization function */
  /*lint -e{611} */
  client_handle =  qmi_service_init (conn_id,
                                   QMI_LOC_SERVICE,
                                   (void *) user_ind_msg_hdlr,
                                   user_ind_msg_hdlr_user_data,
                                   qmi_err_code);
 
 
  if(client_handle > 0)  
    qmi_loc_reg_ind_hdlr(user_ind_msg_hdlr);
  else 
    QMI_ERR_MSG_1("tof_qmi_loc_srvc_init_client: client_handle  0x%x failed \r\n",client_handle);

  return client_handle;
}

/*===========================================================================

  FUNCTION  tof_qmi_loc_release
  
===========================================================================*/
boolean tof_qmi_loc_release()
{
  int qmi_err_code = QMI_NO_ERR;
  int rc = QMI_NO_ERR;

  if(loc_client_handle == QMI_INVALID_CLIENT_HANDLE) 
    return RESULT_SUCCESS;
   
  if(loc_client_handle != QMI_INVALID_CLIENT_HANDLE)
  {
    rc = tof_tof_qmi_loc_srvc_release_client(loc_client_handle, &qmi_err_code);
    if(rc != QMI_NO_ERR)
    {
      printf("tof_tof_qmi_loc_srvc_release_client rc = %d, qmi_err_code \n", rc, qmi_err_code);
      return RESULT_FAILURE;
    } 
  }
  else
  {
    printf("tof_qmi_loc_release loc_client_handle= %x\r\n", loc_client_handle);
  }

  return RESULT_SUCCESS;
}

/*===========================================================================
  FUNCTION  tof_tof_qmi_loc_srvc_release_client
===========================================================================*/
/*!
@brief 
  This function is called to release a client created by the 
  tof_qmi_nas_srvc_init_client() function.  This function should be called
  for any client created when terminating a client process, especially
  if the modem processor is not reset.  The modem side QMI server has 
  a limited number of clients that it will allocate, and if they are not
  released, we will run out.  
  
@return 
  0 if abort operation was sucessful, < 0 if not.  If return code is 
  QMI_INTERNAL_ERR, then the qmi_err_code will be valid and will 
  indicate which QMI error occurred.

@note

  - Dependencies
    - qmi_connection_init() must be called for the associated port first.

  - Side Effects
    - Talks to modem processor
*/    
/*=========================================================================*/

int 
tof_tof_qmi_loc_srvc_release_client
(
  int      user_handle,
  int      *qmi_err_code
)
{
  int  rc = QMI_NO_ERR;
  
  rc = qmi_service_release (user_handle, qmi_err_code);

  if (loc_service_initialized)
  {

    rc = qmi_service_set_srvc_functions (QMI_LOC_SERVICE,NULL);
    if (rc != QMI_NO_ERR)
    {
      printf("tof_qmi_loc_srvc_release: set srvc functions returns err=%d\n",rc);
    }
    else
    {
      printf("tof_qmi_loc_srvc_release: LOC successfully released\r\n");
      loc_service_initialized = FALSE;
    }
  }
  else
  {
    printf("tof_qmi_loc_srvc_release: Release failed, LOC not initialized\r\n");
  }
  
  return rc;     
}

/*===========================================================================
  FUNCTION  loc_init_static_curr_set_val
===========================================================================*/
/*!
@brief 
  This function is used to initialize a static variable for GPS parameters.  
  
@return 
  None.

@note

  - Dependencies
    - None.

  - Side Effects
    - None.
*/    
/*=========================================================================*/
void loc_init_static_curr_set_val(void)
{
  int rc = QMI_NO_ERR;
  int i =0;
  
  QMI_ERR_MSG_0("loc_init_static_curr_set_val()Start to initialize static current set values\r\n");
#if 1  
    static_curr_set_val.curr_mode = 0;
    static_curr_set_val.curr_nmeaSentenceType = 0;
    static_curr_set_val.curr_eventRegMask_qti = 0;
    for(i =0; i < 4; i++)
    {
      memset(&static_curr_set_val.curr_serverReqMsg[i],0,sizeof(qmiLocSetServerReqMsgT_v02));
    }
#endif  
  
  //get a current operation mode
  if((rc = request_loc_get_operation_mode()) != RESULT_SUCCESS)
  {
    QMI_ERR_MSG_1("loc_init_static_curr_set_val()Fail to get a current operation mode rc =%d\r\n",rc);
  }
  
  // get a current nmea sentence type
  if((rc = request_loc_get_nmea_type()) != RESULT_SUCCESS)
  {
    QMI_ERR_MSG_1("loc_init_static_curr_set_val()Fail to get a current nmea sentence type rc =%d\r\n",rc);
  }
  
  // get a current event reg mask
  if((rc = request_loc_get_reg_event()) != RESULT_SUCCESS)
  {
    QMI_ERR_MSG_1("loc_init_static_curr_set_val()Fail to get a current event reg mask rc =%d\r\n",rc);
  }
  
  //  get a current spl server info for each server type
  for(i =1; i < 5; i++) //1:CDMA_PDE 2:CDMA_MPC 3:UMTS_SLP 4:CUSTOM_PDE
  {
    if((rc = request_loc_get_supl_server_info(i)) != RESULT_SUCCESS)
    {
      QMI_ERR_MSG_1("loc_init_static_curr_set_val()Fail to get a current spl server info rc =%d\r\n",rc);
    }
  }

  QMI_ERR_MSG_0("loc_init_static_curr_set_val()End to initialize static current set values\r\n");
}   

/*===========================================================================
  FUNCTION  qmi_loc_reg_ind_hdlr
===========================================================================*/
/*!
@brief 
  This function is a callback that will be called once during client
  initialization  
  
@return 
  None.

@note

  - Dependencies
    - None.

  - Side Effects
    - None.
*/    
/*=========================================================================*/
int qmi_loc_reg_ind_hdlr (qmi_service_ind_rx_hdlr  user_ind_msg_hdlr)
{
  int  rc = QMI_NO_ERR;
  if (!loc_service_initialized)
  {

    rc = qmi_service_set_srvc_functions (QMI_LOC_SERVICE,
                                 user_ind_msg_hdlr);
    if (rc != QMI_NO_ERR)
    {
      QMI_ERR_MSG_1("qmi_loc_reg_ind_hdlr: set srvc functions returns err=%d\n",rc);
    }
    else
    {
      QMI_ERR_MSG_0("qmi_loc_reg_ind_hdlr: LOC successfully initialized\r\n");
      loc_service_initialized = TRUE;
    }
  }
  else
  {
    QMI_ERR_MSG_0("qmi_loc_reg_ind_hdlr: Init failed, LOC already initialized\r\n");
  }
  return rc;
}

/*===========================================================================
  FUNCTION  qmi_loc_srvc_indication_cb
===========================================================================*/
/*!
@brief 
  This is the callback function that will be called by the generic
  services layer to report asynchronous indications.  This function will
  process the indication TLV's and then call the user registered
  functions with the indication data.   
  
@return 
  None.

@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/

static void
qmi_loc_srvc_indication_cb
(
  int                   user_handle,
  qmi_service_id_type   service_id,
  unsigned long         msg_id,
  void                  *user_ind_msg_hdlr,
  void                  *user_ind_msg_hdlr_user_data,
  unsigned char         *rx_msg_buf,
  int                   rx_msg_len
)
{
  qmi_loc_indication_id_type      ind_id = QMI_LOC_SRVC_INVALID_IND_MSG;
  qmi_loc_indication_data_type t_position_report_ind;
  qmi_loc_indication_nmea_data_type t_nmea_report_ind;
  qmiLocGetOperationModeIndMsgT_v02 t_Get_opmode_ind;
  qmiLocSetOperationModeIndMsgT_v02 t_Set_opmode_ind;
  qmiLocGetNmeaTypesIndMsgT_v02 t_Get_nmeaType_ind;
  qmiLocSetNmeaTypesIndMsgT_v02 t_Set_nmeaType_ind;
  qmiLocGetRegisteredEventsIndMsgT_v02	t_Get_reg_ind;
  qmiLocEventLocationServerConnectionReqIndMsgT_v02 t_Loc_Server_Conn_Req_Ind;
  qmiLocSetServerIndMsgT_v02 t_Set_SPL_Server_ind;
  qmiLocGetServerIndMsgT_v02  t_Get_SPL_Server_Info_Ind;
  qmiLocDeleteAssistDataIndMsgT_v02 t_Del_Assist_Data_ind;
  qmi_loc_indication_gnss_sv_data_type t_event_gnss_sv_info_ind;
  // Added Jamming detection Indication
  qmi_loc_jamming_rf_data_type t_jamming_rf_ind;
  int reg_event = 0;
  char tmp_buf[256] = {0};
  char t_inet6_addr[INET6_ADDRSTRLEN] ={0};
  struct sockaddr_in addr_inet;
  char url_tmp[256] = {0};
  
  /* Make sure that the user indication handler isn't NULL */
  if (user_ind_msg_hdlr == NULL)
  {
    QMI_ERR_MSG_0 ("qmi_loc_srvc_indication_cb::user_ind_msg_hdlr is NULL \r\n ");
    return;
  }

  QMI_ERR_MSG_1 ("qmi_loc_srvc_indication_cb::msg_id 0x%lx \r\n ",msg_id);
  QMI_ERR_MSG_2("qmi_loc_srvc_indication_cb::msg_id 0x%lx, rx_msg_len =%d\r\n ",msg_id,rx_msg_len);

  memset((void *)tmp_buf,0,256);
  
  switch (msg_id)
  {    
    case QMI_LOC_EVENT_POSITION_REPORT_IND_V02:
    {
      memset(&t_position_report_ind,0,sizeof(t_position_report_ind));
        
      ind_id = QMI_LOC_EVENT_POSITION_REPORT_IND_MSG;     
      if(qmi_loc_position_report_ind(rx_msg_buf, rx_msg_len, &t_position_report_ind.loc_position_report) < 0)
      {
        QMI_ERR_MSG_0 ("[GPS] qmi_loc_position_report_ind: fail\n ");
        return;
      }
      else
      {
        if(loc_service_start == TRUE) // if the GPS service started by User then reply a response to User
        {
          memcpy((void*)&gps_Position_report_data, &t_position_report_ind.loc_position_report, sizeof(qmiLocEventPositionReportIndMsgT_v02));
        
          sprintf(tmp_buf,"%d,%lf,%lf,%llu,%d,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%d",
                  t_position_report_ind.loc_position_report.sessionStatus,
                  t_position_report_ind.loc_position_report.latitude,
                  t_position_report_ind.loc_position_report.longitude,
                  t_position_report_ind.loc_position_report.timestampUtc,
                  t_position_report_ind.loc_position_report.speedHorizontal_valid,
                  t_position_report_ind.loc_position_report.speedHorizontal*3.6,
                  //Add Boash parameter
                  t_position_report_ind.loc_position_report.speedVertical,     //getVerticalSpeed()
                  t_position_report_ind.loc_position_report.speedHorizontal,  //getSpeed()
                  t_position_report_ind.loc_position_report.speedUnc,          //getSpeedAccuracy()            
                  t_position_report_ind.loc_position_report.horUncCircular,    //getHorizontalAccuracy()   
                  t_position_report_ind.loc_position_report.vertUnc,             //getVerticalAccuracy()

                  t_position_report_ind.loc_position_report.DOP.VDOP,          //getVDOP()
                  t_position_report_ind.loc_position_report.DOP.HDOP,          //getHDOP()     
                  t_position_report_ind.loc_position_report.DOP.PDOP,          //getHDOP()    
                  t_position_report_ind.loc_position_report.heading,             //getHeading()     
                  t_position_report_ind.loc_position_report.altitudeWrtMeanSeaLevel,  //getAltitudeMSL()     
                  t_position_report_ind.loc_position_report.altitudeAssumed   //getaltitudeAssumed()                       
                  );

          EventNotifyEnqueue(TOF_EVENT_POSITION_REPORT_IND, NULL, (uint32)tmp_buf);
        }
        else
        {
          QMI_ERR_MSG_0("[GPS]loc_service_start == FALSE");
        }
      }
      QMI_ERR_MSG_0 ("qmi_loc_srvc_indication_cb::QMI_LOC_EVENT_POSITION_REPORT_IND_V02 \r\n ");
    }
    break;
    // Added Jamming detection Indication
    case QMI_LOC_EVENT_JAMMING_RF_REPORT_IND_V02:
    {
      memset(&t_jamming_rf_ind,0,sizeof(t_jamming_rf_ind));
        
      ind_id = QMI_LOC_EVENT_JAMMING_RF_REPORT_IND_MSG;     
      if(qmi_loc_jamming_rf_report_ind(rx_msg_buf, rx_msg_len, &t_jamming_rf_ind.loc_jamming_rf_report) < 0)
      {
        QMI_ERR_MSG_0 ("[GPS] qmi_loc_jamming_rf_report_ind: fail\n ");
        return;
      }
      else
      {
      
        if(loc_service_start == TRUE) // if the GPS service started by User then reply a response to User
        {
          //memcpy((void*)&gps_Position_report_data, &t_position_report_ind.loc_position_report, sizeof(qmiLocEventPositionReportIndMsgT_v02));
          
          sprintf(tmp_buf,"%d,%d,%d,%d,%d",
                  t_jamming_rf_ind.loc_jamming_rf_report.l_PGAGain,
                  t_jamming_rf_ind.loc_jamming_rf_report.q_Bp1LbwAmplI,
                  t_jamming_rf_ind.loc_jamming_rf_report.q_Bp1LbwAmplQ,
                  t_jamming_rf_ind.loc_jamming_rf_report.q_Bp3GloAmplI,
                  t_jamming_rf_ind.loc_jamming_rf_report.q_Bp3GloAmplQ                 
                  );

          EventNotifyEnqueue(TOF_EVENT_JAMMING_RF_REPORT_IND, NULL, (uint32)tmp_buf);
        }
        else
        {
          QMI_ERR_MSG_0("[GPS]loc_service_start == FALSE");
        }
      }
      QMI_ERR_MSG_0 ("qmi_loc_srvc_indication_cb::QMI_LOC_EVENT_JAMMING_RF_REPORT_IND_V02 \r\n ");
    }
    break;

    case QMI_LOC_EVENT_GNSS_SV_INFO_IND_V02:
    {
      memset(&t_event_gnss_sv_info_ind,0,sizeof(t_event_gnss_sv_info_ind));

      ind_id = QMI_LOC_EVENT_GNSS_SV_INFO_IND_MSG;     
      if(qmi_loc_gnss_sv_info_report_ind(rx_msg_buf, rx_msg_len, &t_event_gnss_sv_info_ind.loc_gnss_sv_report) < 0)
      {
        QMI_ERR_MSG_0 ("[GPS] qmi_loc_position_report_ind: fail\n ");
        return;
      }
      else
      {
        if(loc_service_start == TRUE) // if the GPS service started by User then reply a response to User
        {
          memcpy(&gps_gnss_sv_info_data, &t_event_gnss_sv_info_ind.loc_gnss_sv_report, sizeof(qmiLocEventGnssSvInfoIndMsgT_v02));
        
          sprintf(tmp_buf,"%d,%d,%d,%d,%d,%d,%d,%d,%d,%lf,%lf,%lf",
                  t_event_gnss_sv_info_ind.loc_gnss_sv_report.altitudeAssumed,
                  t_event_gnss_sv_info_ind.loc_gnss_sv_report.svList_valid,
                  t_event_gnss_sv_info_ind.loc_gnss_sv_report.svList_len,
                  t_event_gnss_sv_info_ind.loc_gnss_sv_report.svList[0].validMask,
                  t_event_gnss_sv_info_ind.loc_gnss_sv_report.svList[0].system,  
                  t_event_gnss_sv_info_ind.loc_gnss_sv_report.svList[0].gnssSvId,
                  t_event_gnss_sv_info_ind.loc_gnss_sv_report.svList[0].healthStatus,                  
                  t_event_gnss_sv_info_ind.loc_gnss_sv_report.svList[0].svStatus,
                  t_event_gnss_sv_info_ind.loc_gnss_sv_report.svList[0].svInfoMask,
                  t_event_gnss_sv_info_ind.loc_gnss_sv_report.svList[0].elevation,          
                  t_event_gnss_sv_info_ind.loc_gnss_sv_report.svList[0].azimuth,
                  t_event_gnss_sv_info_ind.loc_gnss_sv_report.svList[0].snr              
                  );
          
          EventNotifyEnqueue(TOF_EVENT_GNSS_SV_INFO_IND, NULL, (uint32)tmp_buf);

        }
        else
        {
          QMI_ERR_MSG_0("[GPS]loc_service_start == FALSE");
        }
      }
      QMI_ERR_MSG_0 ("qmi_loc_srvc_indication_cb::QMI_LOC_EVENT_POSITION_REPORT_IND_V02 \r\n ");
    }
    break;

    case QMI_LOC_EVENT_NMEA_IND_V02:
      memset(&t_nmea_report_ind,0,sizeof(t_nmea_report_ind));

      ind_id = QMI_LOC_EVENT_NMEA_IND_MSG; 
      if(qmi_loc_position_nmea_report_ind(rx_msg_buf, rx_msg_len, &t_nmea_report_ind.loc_nmea_report) < 0)
      {
        QMI_ERR_MSG_0 ("[GPS] qmi_loc_event_nmea_ind: fail\n ");
        return;
      }
      else
      {
        memcpy(&gps_nmea_ind_data, &t_nmea_report_ind.loc_nmea_report, sizeof(qmiLocEventNmeaIndMsgT_v02));

        sprintf(tmp_buf,"%s",t_nmea_report_ind.loc_nmea_report.nmea);
        EventNotifyEnqueue(TOF_EVENT_POSITION_NMEA_REPORT_IND, NULL, (uint32)tmp_buf);
      }
    break;

    case QMI_LOC_SET_OPERATION_MODE_IND_V02:
      memset(&t_Set_opmode_ind,0,sizeof(t_Set_opmode_ind));
      if(qmi_loc_set_operation_mode_info(rx_msg_buf,rx_msg_len,&t_Set_opmode_ind) < 0)
      {
        QMI_ERR_MSG_0 ("[GPS] qmi_loc_position_report_ind: fail\n ");
        return;
      }
      else
      {
        sprintf(tmp_buf,"%d",t_Set_opmode_ind.status);
        EventNotifyEnqueue(TOF_EVENT_GPS_SET_OPERATION_MODE_IND, NULL, (uint32)tmp_buf);
      }
    break;

    case QMI_LOC_GET_OPERATION_MODE_IND_V02:
      QMI_ERR_MSG_0("qmi_loc_srvc_indication_cb : QMI_LOC_GET_OPERATION_MODE_IND_V02\n");
      memset(&t_Get_opmode_ind,0,sizeof(t_Get_opmode_ind));
      if(qmi_loc_get_operation_mode_info (rx_msg_buf,rx_msg_len,&t_Get_opmode_ind) < 0)
      {
        QMI_ERR_MSG_0 ("[GPS] qmi_loc_position_report_ind: fail\n ");
        return;
      }
      else
      {
        QMI_ERR_MSG_2("[GPS] QMI_LOC_GET_OPERATION_MODE_IND_V02: curr_mode =%d, operationMode =%d\n ",
                                                            static_curr_set_val.curr_mode,t_Get_opmode_ind.operationMode);
        //save a current operation mode into a static local vaiable if the local variable is '0'
        if(static_curr_set_val.curr_mode == 0)
        {
          static_curr_set_val.curr_mode = t_Get_opmode_ind.operationMode;
        }
        else
        {
          sprintf(tmp_buf,"%d,%d",t_Get_opmode_ind.status ,t_Get_opmode_ind.operationMode);
          EventNotifyEnqueue(TOF_EVENT_GPS_GET_OPERATION_MODE_IND, NULL, (uint32)tmp_buf);
        }
      }
    break;

    case QMI_LOC_SET_NMEA_TYPES_IND_V02:
      memset(&t_Set_nmeaType_ind,0,sizeof(t_Set_nmeaType_ind));
      if(qmi_loc_set_nmea_type_info(rx_msg_buf,rx_msg_len,&t_Set_nmeaType_ind) < 0)
      {
        QMI_ERR_MSG_0 ("[GPS] qmi_loc_set_nmea_type_ind: fail\n ");
        return;
      }
      else
      {
        sprintf(tmp_buf,"%d",t_Set_nmeaType_ind.status);
        EventNotifyEnqueue(TOF_EVENT_GPS_SET_NMEA_TYPE_IND, NULL, (uint32)tmp_buf);
      }                            
    break;

    case QMI_LOC_GET_NMEA_TYPES_IND_V02:
      memset(&t_Get_nmeaType_ind,0,sizeof(t_Get_nmeaType_ind));
      if(qmi_loc_get_nmea_type_info (rx_msg_buf,rx_msg_len,&t_Get_nmeaType_ind) < 0)
      {
        QMI_ERR_MSG_0 ("[GPS] qmi_loc_get_nmea_type_ind: fail\n ");
        return;
      }
      else
      {
        QMI_ERR_MSG_2("[GPS] QMI_LOC_GET_NMEA_TYPES_IND_V02: curr_nmeaSentenceType =%x, nmeaSentenceType =%x\n ", 
                                      static_curr_set_val.curr_nmeaSentenceType,t_Get_nmeaType_ind.nmeaSentenceType);
        //save a current nmea sentence type into a static local vaiable if the local variable is '0'
        if(static_curr_set_val.curr_nmeaSentenceType == 0)
        {
          static_curr_set_val.curr_nmeaSentenceType = t_Get_nmeaType_ind.nmeaSentenceType;
        }
        else
        {
          sprintf(tmp_buf,"%d,%d",t_Get_nmeaType_ind.status,t_Get_nmeaType_ind.nmeaSentenceType);
          EventNotifyEnqueue(TOF_EVENT_GPS_GET_NMEA_TYPE_IND, NULL, (uint32)tmp_buf);
        }
      }
    break;

    case QMI_LOC_GET_REGISTERED_EVENTS_IND_V02: 
      memset(&t_Get_reg_ind,0,sizeof(t_Get_reg_ind));
      QMI_ERR_MSG_1("QMI_LOC_GET_REGISTERED_EVENTS_IND_V02 rx_msg_len =%d\r\n",rx_msg_len);
#if 0 //Test
      static int shot_one_time =0;
      if(shot_one_time == 0)
      {
        FILE *msg_log_fp = NULL;
        size_t ret;
    
        if((msg_log_fp=fopen(LOG_FILE_PATH"Chad_RegEVT_Test1", "a+")) == NULL)
        {
          if((msg_log_fp=fopen(LOG_FILE_PATH"Chad_RegEVT_Test1", "a+")) == NULL)
          {
            chmod(LOG_FILE_PATH"Chad_RegEVT_Test1", 0755);
          }
          else
          {
            QMI_ERR_MSG_0("[GPS]qmi_loc_get_reg_evnet_info()Fail to make a file!!/r/n");
          }
        }
        else
        {
          chmod(LOG_FILE_PATH"Chad_RegEVT_Test1", 0755);
        }
    
        QMI_ERR_MSG_0("[GPS]qmi_loc_get_reg_evnet_info()Succeeded to make a file!!/r/n");
        
        ret = fwrite(rx_msg_buf, 1, rx_msg_len, msg_log_fp);
    
        QMI_ERR_MSG_1("[GPS]qmi_loc_get_reg_evnet_info()Write to File!! ret =%d, msg_log_fp =%d/r/n",ret,msg_log_fp);
        
        fclose(msg_log_fp);   
  
        shot_one_time =1;
      }  
#endif
      
      if(qmi_loc_get_reg_evnet_info (rx_msg_buf,rx_msg_len,&t_Get_reg_ind) < 0)
      {
        QMI_ERR_MSG_0 ("[GPS] qmi_loc_get_reg_event_ind: fail\n ");
        return;
      }
      else
      {
        QMI_ERR_MSG_2("[GPS]QMI_LOC_GET_REGISTERED_EVENTS_IND_V02!! curr_eventRegMask_qti =%llu, eventRegMask =0x%llu ended!!\n",
                                    static_curr_set_val.curr_eventRegMask_qti,t_Get_reg_ind.eventRegMask);
        if(static_curr_set_val.curr_eventRegMask_qti == 0)
        {
          static_curr_set_val.curr_eventRegMask_qti = t_Get_reg_ind.eventRegMask;
        }
        else
        {
          sprintf(tmp_buf,"%d,%llu",t_Get_reg_ind.status, t_Get_reg_ind.eventRegMask);
          EventNotifyEnqueue(TOF_EVENT_GET_REGISTERED_EVENT_IND, NULL, (uint32)tmp_buf);
        }
      }		
    break;

    case QMI_LOC_EVENT_LOCATION_SERVER_CONNECTION_REQ_IND_V02: //once this event is indicated on the AGPS processing, Should be opened a ATL.
    {
      memset(&t_Loc_Server_Conn_Req_Ind,0,sizeof(t_Loc_Server_Conn_Req_Ind));

      QMI_ERR_MSG_1 ("[GPS] QMI_LOC_EVENT_LOCATION_SERVER_CONNECTION_REQ_IND_V02 received!! requestType =%d\n ",t_Loc_Server_Conn_Req_Ind.requestType);
      if(qmi_loc_get_server_conn_req_ind_event (rx_msg_buf,rx_msg_len,&t_Loc_Server_Conn_Req_Ind) < 0)
      {
        QMI_ERR_MSG_0 ("[GPS] qmi_loc_get_server_conn_req_ind_event: fail\n ");
        return;
      }
      else
      {
        QMI_ERR_MSG_3 ("[GPS] QMI_LOC_EVENT_LOCATION_SERVER_CONNECTION_REQ_IND_V02 requestType =%ld, connHandle =%ld, wwanType =%ld\n ",
                    t_Loc_Server_Conn_Req_Ind.requestType,t_Loc_Server_Conn_Req_Ind.connHandle,t_Loc_Server_Conn_Req_Ind.wwanType);

        if(t_Loc_Server_Conn_Req_Ind.requestType == eQMI_LOC_SERVER_REQUEST_OPEN_V02)
        {
          static_curr_Loc_Server_Conn_Info.connHandle = t_Loc_Server_Conn_Req_Ind.connHandle;
          static_curr_Loc_Server_Conn_Info.requestType = t_Loc_Server_Conn_Req_Ind.requestType;  
          static_curr_Loc_Server_Conn_Info.wwanType = t_Loc_Server_Conn_Req_Ind.wwanType; 

          // Kill the Timer which is used to wait a incoming QMI_LOC_EVENT_LOCATION_SERVER_CONNECTION_REQ_IND_V02.
          LocKillTimerSet(LOC_TIME_WAIT_CONN_STATUS_ID); 

          // Start a Timer which is used to wait to send a QMI_LOC_INFORM_LOCATION_SERVER_CONN_STATUS_REQ_V02
          if(loc_time_count(LOC_TIME_WAIT_TO_SEND_SRV_CONN_REQ_ID) != TRUE)
          {
            QMI_ERR_MSG_0 ("[GPS] QMI_LOC_EVENT_LOCATION_SERVER_CONNECTION_REQ_IND_V02: fail to start Timer!!\n ");
          }
        }
        else
        {
          //Initialize a Local variable which is containing a current ATL information.
//          memset(&static_curr_Loc_Server_Conn_Info,0,sizeof(static_curr_Loc_Server_Conn_Info));
        }
      }
    }
    break;
    case QMI_LOC_SET_SERVER_IND_V02:
      memset(&t_Set_SPL_Server_ind,0,sizeof(t_Set_SPL_Server_ind));
      if(qmi_loc_set_supl_server_info(rx_msg_buf,rx_msg_len,&t_Set_SPL_Server_ind) < 0)
      {
        QMI_ERR_MSG_0 ("[GPS] QMI_LOC_SET_SERVER_IND_V02: fail\n ");
        return;
      }
      else
      {
        sprintf(tmp_buf,"%d",t_Set_SPL_Server_ind.status);
        EventNotifyEnqueue(TOF_EVENT_SET_SUPL_SERVER_INFO_IND, NULL, (uint32)tmp_buf);
      }                            
    break;
    case QMI_LOC_GET_SERVER_IND_V02:
    {
      memset(&t_Get_SPL_Server_Info_Ind,0,sizeof(t_Get_SPL_Server_Info_Ind));
      if(qmi_loc_get_supl_server_info (rx_msg_buf,rx_msg_len,&t_Get_SPL_Server_Info_Ind) < 0)
      {
        QMI_ERR_MSG_0 ("[GPS] t_Get_SPL_Server_Info_Ind: fail\n ");
        return;
      }
      else
      {
        QMI_ERR_MSG_2 ("[GPS] QMI_LOC_GET_SERVER_IND_V02 received!! serverType =%d, get_serverType =%d\n ",
                      static_curr_set_val.curr_serverReqMsg[t_Get_SPL_Server_Info_Ind.serverType -1].serverType,t_Get_SPL_Server_Info_Ind.serverType);
        
        if(static_curr_set_val.curr_serverReqMsg[t_Get_SPL_Server_Info_Ind.serverType -1].serverType == 0)
        {
          static_curr_set_val.curr_serverReqMsg[t_Get_SPL_Server_Info_Ind.serverType -1].serverType = t_Get_SPL_Server_Info_Ind.serverType;
          if(t_Get_SPL_Server_Info_Ind.ipv4Addr_valid)
          {
            static_curr_set_val.curr_serverReqMsg[t_Get_SPL_Server_Info_Ind.serverType -1].ipv4Addr = t_Get_SPL_Server_Info_Ind.ipv4Addr;
          }

          if(t_Get_SPL_Server_Info_Ind.ipv6Addr_valid)
          {
            static_curr_set_val.curr_serverReqMsg[t_Get_SPL_Server_Info_Ind.serverType -1].ipv6Addr = t_Get_SPL_Server_Info_Ind.ipv6Addr;
          }

          if(t_Get_SPL_Server_Info_Ind.urlAddr_valid)
          {
            strncpy(static_curr_set_val.curr_serverReqMsg[t_Get_SPL_Server_Info_Ind.serverType -1].urlAddr
                                          ,t_Get_SPL_Server_Info_Ind.urlAddr,QMI_LOC_MAX_SERVER_ADDR_LENGTH_V02 + 1);
          }
        }
        else
        {
          memset((void *)&addr_inet,0,sizeof(addr_inet));
          addr_inet.sin_addr.s_addr = t_Get_SPL_Server_Info_Ind.ipv4Addr.addr;
          
          QMI_ERR_MSG_3("QMI_LOC_GET_SERVER_IND_V02 ipv4Addr_valid =%d, addr =%s, port =%d\r\n",t_Get_SPL_Server_Info_Ind.ipv4Addr_valid,
                                                          inet_ntoa(addr_inet.sin_addr),t_Get_SPL_Server_Info_Ind.ipv4Addr.port);

          if(t_Get_SPL_Server_Info_Ind.urlAddr_valid == TRUE)
          {
            memset((void *)url_tmp,0,256);
            strcpy((char *)url_tmp,t_Get_SPL_Server_Info_Ind.urlAddr);
            QMI_ERR_MSG_2("url_size =%d, urlAddr =%s\r\n",strlen(url_tmp),url_tmp);
          }          
#if 1  // Incase of supporting IPv4 Only
          sprintf(tmp_buf,"%d,%d,%s,%d,%s",t_Get_SPL_Server_Info_Ind.status,t_Get_SPL_Server_Info_Ind.serverType,
              (t_Get_SPL_Server_Info_Ind.ipv4Addr_valid == TRUE)? inet_ntoa(addr_inet.sin_addr):"0.0.0.0",
              (t_Get_SPL_Server_Info_Ind.ipv4Addr_valid == TRUE)? t_Get_SPL_Server_Info_Ind.ipv4Addr.port:0,
              (t_Get_SPL_Server_Info_Ind.urlAddr_valid == TRUE)? url_tmp:"None");
#else // Incase of supporting IPv4 and IPv6
          sprintf(tmp_buf,"%d,%d,%s,%d,%s,%d,%s",t_Get_SPL_Server_Info_Ind.status,t_Get_SPL_Server_Info_Ind.serverType,
              (t_Get_SPL_Server_Info_Ind.ipv4Addr_valid == TRUE)? inet_ntoa(addr_inet.sin_addr):"0.0.0.0",
              (t_Get_SPL_Server_Info_Ind.ipv4Addr_valid == TRUE)? t_Get_SPL_Server_Info_Ind.ipv4Addr.port:0,
              (t_Get_SPL_Server_Info_Ind.ipv6Addr_valid == TRUE)? inet_ntop(AF_INET6,t_Get_SPL_Server_Info_Ind.ipv6Addr.addr,t_inet6_addr,INET6_ADDRSTRLEN):":::::",
              (t_Get_SPL_Server_Info_Ind.ipv6Addr_valid == TRUE)? t_Get_SPL_Server_Info_Ind.ipv6Addr.port:0,
              (t_Get_SPL_Server_Info_Ind.urlAddr_valid == TRUE)? url_tmp:"None");
#endif          
          EventNotifyEnqueue(TOF_EVENT_GET_SUPL_SERVER_INFO_IND, NULL, (uint32)tmp_buf);
        }
#if 0        
        int i = 0;
        while((t_Get_SPL_Server_Info_Ind.ipv6Addr.addr[i++] != NULL) && (i < QMI_LOC_IPV6_ADDR_LENGTH_V02))
        {
          if(i == 0)
          {
            if(t_Get_SPL_Server_Info_Ind.ipv6Addr.addr[i] != NULL)
              sprintf(t_inet6_addr,"%s:",t_Get_SPL_Server_Info_Ind.ipv6Addr.addr[i]);
            
          }
          else
          {
            if(t_Get_SPL_Server_Info_Ind.ipv6Addr.addr[i] != NULL)
            {
              strcat(t_inet6_addr,itoa(t_Get_SPL_Server_Info_Ind.ipv6Addr.addr[i]));
              if(i != QMI_LOC_IPV6_ADDR_LENGTH_V02-1)
              {
                t_inet6_addr[strlen(t_inet6_addr)]= ":";
              }
            }
          }
          
        }
        if((i = inet_ntop(AF_INET6,t_Get_SPL_Server_Info_Ind.ipv6Addr.addr,t_inet6_addr,INET6_ADDRSTRLEN)) != 1)
        {
          QMI_ERR_MSG_1("[GPS] t_Get_SPL_Server_Info_Ind: IPv6 convert Fail i =%d\n ",i);
          printf("[GPS] t_Get_SPL_Server_Info_Ind: IPv6 convert Fail i =%d\n ",i);
        }
#endif  
      }
    }
    break;
    case QMI_LOC_DELETE_ASSIST_DATA_IND_V02:
      memset(&t_Del_Assist_Data_ind,0,sizeof(t_Del_Assist_Data_ind));
      if(qmi_loc_del_assist_data(rx_msg_buf,rx_msg_len,&t_Del_Assist_Data_ind) < 0)
      {
        QMI_ERR_MSG_0 ("[GPS] QMI_LOC_DELETE_ASSIST_DATA_IND_V02: fail\n ");
        return;
      }
      else
      {
        sprintf(tmp_buf,"%d",t_Del_Assist_Data_ind.status);
        EventNotifyEnqueue(TOF_EVENT_DELETE_ASSIST_DATA_IND, NULL, (uint32)tmp_buf);
      }                            
    break;
    default:
      QMI_ERR_MSG_1 ("qmi_loc_srvc_indication_cb::Invalid indication msg_id received %lx\n ",msg_id);
    break;
  }/*Switch*/

}

int
qmi_loc_indication_register
(
  int                                     client_handle,
  loc_0021_req_s                         *loc_0021_req,
  int                                    *qmi_err_code
)
{
  unsigned char     msg[QMI_LOC_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;
 
  if(!loc_0021_req)
  {
    return QMI_INTERNAL_ERR;
  }
  
  /* Set tmp_msg_ptr to beginning of message-specific TLV portion of 
  ** message buffer
  */
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_LOC_STD_MSG_SIZE);

  /* Write system selection preference TLV if appropriate */
  if(loc_0021_req->t01_valid)
  {
    val_ptr = (unsigned char*)&loc_0021_req->t01;
    tlv_length = sizeof(loc_0021_req->t01);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                LOC_0021_REQ_T01,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  } 

 
  /* Synchronously send message to modem processor */
  rc = qmi_service_send_msg_sync (client_handle,
                                  QMI_LOC_SERVICE,
                                  QMI_LOC_REG_EVENTS_REQ_V02,
                                  QMI_SRVC_PDU_PTR(msg),
                                  QMI_SRVC_PDU_SIZE(QMI_LOC_STD_MSG_SIZE) - msg_size,
                                  msg,                 
                                  &msg_size,
                                  QMI_LOC_STD_MSG_SIZE,
                                  QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                  qmi_err_code);

  return rc;
} /* qmi_nas_indication_register */


/*===========================================================================

  FUNCTION  qmi_loc_position_report_ind

  Description : FOR the TOF of Clarion, this function is only returned a "Latitude", "Longitude" and "Time Stamp".
                    Please keep in mind that If you want to have more information returned, you must change this function 
                    to what you want to make.

===========================================================================*/
static int qmi_loc_position_report_ind
(
  unsigned char                                   *rx_buf,
  int                                             rx_buf_len,
  qmiLocEventPositionReportIndMsgT_v02            *t_position_report_ind
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;
  int  retval =0;
  
  unsigned char temp_8bit =0;
  unsigned short  temp_16bit =0;
  uint32  temp_32bit =0;
  uint64  temp_64bit =0;
  int16   temp_int_16bit =0;
  int32   temp_int_32bit =0;
  int64   temp_int_64bit =0;
  unsigned long long  long_temp_64bit =0;
  double  temp_long = 0;
  float   temp_float = 0;
  uint64_t temp_uint64 = 0;
  uint32  temp_time_hi =0;
  uint32  temp_time_low = 0;
  
  memset(t_position_report_ind, 0, sizeof(t_position_report_ind));

  MSG_ERROR("[GPS]qmi_loc_position_report_ind() rx_buf_len =%d \n",rx_buf_len,0,0);

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      MSG_ERROR("qmi_util_read_std_tlv() Failed!!! Return ERR",0,0,0);
      return QMI_INTERNAL_ERR;
    }

//    printf("[GPS]qmi_loc_position_report_ind() type =0x%x length =%d\n",type,length);
    /* Now process TLV */
    switch (type)
    {
      case LOC_POS_REPT_SESSION_STATUS:
      {
        READ_32_BIT_VAL(value_ptr, temp_32bit); 
        t_position_report_ind->sessionStatus = (qmiLocSessionStatusEnumT_v02)temp_32bit;

//        printf("[GPS]qmi_loc_position_report_ind() sessionStatus =%ld\n",t_position_report_ind->sessionStatus);
      }
      break;
      case LOC_POS_REPT_SESSION_ID:
      {
        READ_8_BIT_VAL(value_ptr, temp_8bit); 
        t_position_report_ind->sessionId = (uint8_t)temp_8bit;

//        printf("[GPS]qmi_loc_position_report_ind() sessionId =%d \n",t_position_report_ind->sessionId);
      }
      break;
      case LOC_POS_REPT_LATITUDE:
      {
        t_position_report_ind->latitude_valid = TRUE;
        READ_64_BIT_VAL(value_ptr, temp_long);
        t_position_report_ind->latitude = (double)temp_long;

//        printf("[GPS]qmi_loc_position_report_ind() latitude =%lf\n",t_position_report_ind->latitude);
      }
      break;
      case LOC_POS_REPT_LONGITUDE:
      {
        t_position_report_ind->longitude_valid = TRUE;
        READ_64_BIT_VAL(value_ptr, temp_long);
        t_position_report_ind->longitude = (double)temp_long;

//        printf("[GPS]qmi_loc_position_report_ind() longitude =%lf\n",t_position_report_ind->longitude);
      }
      break;
      case LOC_POS_REPT_CIR_HORIZ_POS_UNCERT:
      {
        t_position_report_ind->horUncCircular_valid = TRUE;
        READ_32_BIT_VAL(value_ptr, temp_float);
        t_position_report_ind->horUncCircular = (float)temp_float;

//        printf("[GPS]qmi_loc_position_report_ind() horUncCircular =%lf\n",t_position_report_ind->horUncCircular);
      }
      break;
      case LOC_POS_REPT_HORIZ_ELLIP_UNCERT_MINOR:
      {
        t_position_report_ind->horUncEllipseSemiMinor_valid = TRUE;
        READ_32_BIT_VAL(value_ptr, temp_float);
        t_position_report_ind->horUncEllipseSemiMinor = (float)temp_float;

//        printf("[GPS]qmi_loc_position_report_ind() horUncEllipseSemiMinor =%lf\n",t_position_report_ind->horUncEllipseSemiMinor);
      }
      break;
      case LOC_POS_REPT_HORIZ_ELLIP_UNSERT_MAJOR:
      {
        t_position_report_ind->horUncEllipseSemiMajor_valid = TRUE;
        READ_32_BIT_VAL(value_ptr, temp_float);
        t_position_report_ind->horUncEllipseSemiMajor = (float)temp_float;

//        printf("[GPS]qmi_loc_position_report_ind() horUncEllipseSemiMajor =%lf\n",t_position_report_ind->horUncEllipseSemiMajor);
      }
      break;
      case LOC_POS_REPT_ELLIP_HORIZ_UNCERT_AZI:
      {
        t_position_report_ind->horUncEllipseOrientAzimuth_valid = TRUE;
        READ_32_BIT_VAL(value_ptr, temp_float);
        t_position_report_ind->horUncEllipseOrientAzimuth = (float)temp_float;

//        printf("[GPS]qmi_loc_position_report_ind() horUncEllipseOrientAzimuth =%lf\n",t_position_report_ind->horUncEllipseOrientAzimuth);
      }
      break;
      case LOC_POS_REPT_HORIZ_CONFIDENCE:
      {
        t_position_report_ind->horConfidence_valid = TRUE;
        READ_8_BIT_VAL(value_ptr, temp_8bit);
        t_position_report_ind->horConfidence = (uint8_t)temp_8bit;

//        printf("[GPS]qmi_loc_position_report_ind() horConfidence =%d \n",t_position_report_ind->horConfidence);
      }
      break;
      case LOC_POS_REPT_HORIZ_RELIABILITY:
      {
        t_position_report_ind->horReliability_valid = TRUE;
        READ_32_BIT_VAL(value_ptr, temp_int_32bit);
        t_position_report_ind->horReliability = (qmiLocReliabilityEnumT_v02)temp_int_32bit;

//        printf("[GPS]qmi_loc_position_report_ind() horReliability =%ld\n",t_position_report_ind->horReliability);
      }
      break;
      case LOC_POS_REPT_HORIZ_SPEED:
      {
        t_position_report_ind->speedHorizontal_valid = TRUE;
        READ_32_BIT_VAL(value_ptr, temp_float);
        t_position_report_ind->speedHorizontal = (float)temp_float;

//        printf("[GPS]qmi_loc_position_report_ind() speedHorizontal =%lf\n",t_position_report_ind->speedHorizontal);
      }
      break;
      case LOC_POS_REPT_SPEED_UNCERT:
      {
        t_position_report_ind->speedUnc_valid = TRUE;
        READ_32_BIT_VAL(value_ptr, temp_float);
        t_position_report_ind->speedUnc = (float)temp_float;

//        printf("[GPS]qmi_loc_position_report_ind() speedUnc =%lf\n",t_position_report_ind->speedUnc);
      }
      break;
      case LOC_POS_REPT_ALTI_WITH_RESP_ELLIP:
      {
        t_position_report_ind->altitudeWrtEllipsoid_valid = TRUE;
        READ_32_BIT_VAL(value_ptr, temp_float);
        t_position_report_ind->altitudeWrtEllipsoid = (float)temp_float;

//        printf("[GPS]qmi_loc_position_report_ind() altitudeWrtEllipsoid =%lf\n",t_position_report_ind->altitudeWrtEllipsoid);
      }
      break;
      case LOC_POS_REPT_ALTIT_WITH_RESP_SEA_LEVEL:
      {
        t_position_report_ind->altitudeWrtMeanSeaLevel_valid = TRUE;
        READ_32_BIT_VAL(value_ptr, temp_float);
        t_position_report_ind->altitudeWrtMeanSeaLevel = (float)temp_float;

//        printf("[GPS]qmi_loc_position_report_ind() altitudeWrtMeanSeaLevel =%lf\n",t_position_report_ind->altitudeWrtMeanSeaLevel);
      }
      break;
      case LOC_POS_REPT_VERTICAL_UNCERT:
      {
        t_position_report_ind->vertUnc_valid = TRUE;
        READ_32_BIT_VAL(value_ptr, temp_float);
        t_position_report_ind->vertUnc = (float)temp_float;

//        printf("[GPS]qmi_loc_position_report_ind() vertUnc =%lf\n",t_position_report_ind->vertUnc);
      }
      break;
      case LOC_POS_REPT_VERTICAL_CONFIDENCE:
      {
        t_position_report_ind->vertConfidence_valid = TRUE;
        READ_8_BIT_VAL(value_ptr, temp_8bit);
        t_position_report_ind->vertConfidence = (uint8_t)temp_8bit;

//        printf("[GPS]qmi_loc_position_report_ind() vertConfidence =%d \n",t_position_report_ind->vertConfidence);
      }
      break;
      case LOC_POS_REPT_VERTICAL_ELIABILITY:
      {
        t_position_report_ind->vertReliability_valid = TRUE;
        READ_32_BIT_VAL(value_ptr, temp_int_32bit);
        t_position_report_ind->vertReliability = (qmiLocReliabilityEnumT_v02)temp_int_32bit;

//        printf("[GPS]qmi_loc_position_report_ind() vertReliability =%ld \n",t_position_report_ind->vertReliability);
      }
      break;
      case LOC_POS_REPT_VERTICAL_SPEEDD:
      {
        t_position_report_ind->speedVertical_valid = TRUE;
        READ_32_BIT_VAL(value_ptr, temp_float);
        t_position_report_ind->speedVertical = (float)temp_float;

//        printf("[GPS]qmi_loc_position_report_ind() speedVertical =%lf\n",t_position_report_ind->speedVertical);
      }
      break;
      case LOC_POS_REPT_HEADING:
      {
        t_position_report_ind->heading_valid = TRUE;
        READ_32_BIT_VAL(value_ptr, temp_float);
        t_position_report_ind->heading = (float)temp_float;

//        printf("[GPS]qmi_loc_position_report_ind() heading =%lf\n",t_position_report_ind->heading);
      }
      break;
      case LOC_POS_REPT_HEADING_UNCERT:
      {
        t_position_report_ind->headingUnc_valid = TRUE;
        READ_32_BIT_VAL(value_ptr, temp_float);
        t_position_report_ind->headingUnc = (float)temp_float;

//        printf("[GPS]qmi_loc_position_report_ind() headingUnc =%lf\n",t_position_report_ind->headingUnc);
      }
      break;
      case LOC_POS_REPT_MAGNETIC_DEVIATION:
      {
        t_position_report_ind->magneticDeviation_valid = TRUE;
        READ_32_BIT_VAL(value_ptr, temp_float);
        t_position_report_ind->magneticDeviation = (float)temp_float;

//        printf("[GPS]qmi_loc_position_report_ind() magneticDeviation =%lf\n",t_position_report_ind->magneticDeviation);
      }
      break;
      case LOC_POS_REPT_TECH_USED:
      {
        t_position_report_ind->technologyMask_valid = TRUE;
        READ_32_BIT_VAL(value_ptr, temp_32bit);
        t_position_report_ind->technologyMask = (qmiLocPosTechMaskT_v02)temp_32bit;

//        printf("[GPS]qmi_loc_position_report_ind() technologyMask =%d\n",t_position_report_ind->technologyMask);
      }
      break;
      case LOC_POS_REPT_DILUTION_PRECISION:
      {
        t_position_report_ind->DOP_valid = TRUE;
        
        READ_32_BIT_VAL(value_ptr, temp_float);
        t_position_report_ind->DOP.PDOP = (float)temp_float;

//        printf("[GPS]qmi_loc_position_report_ind() DOP.PDOP =%lf\n",t_position_report_ind->DOP.PDOP);
        READ_32_BIT_VAL(value_ptr, temp_float);
        t_position_report_ind->DOP.HDOP = (float)temp_float;

//        printf("[GPS]qmi_loc_position_report_ind() DOP.HDOP =%lf\n",t_position_report_ind->DOP.HDOP);
        READ_32_BIT_VAL(value_ptr, temp_float);
        t_position_report_ind->DOP.VDOP = (float)temp_float;

//        printf("[GPS]qmi_loc_position_report_ind() DOP.VDOP =%lf\n",t_position_report_ind->DOP.VDOP);
      }
      break;
      case LOC_POS_REPT_UTC_TIMESTAMP:
      {
        t_position_report_ind->timestampUtc_valid = TRUE;

        READ_32_BIT_VAL(value_ptr, temp_32bit);
        temp_time_hi = temp_32bit;

        temp_32bit =0;
        READ_32_BIT_VAL(value_ptr, temp_32bit);
        temp_time_low = temp_32bit;

        t_position_report_ind->timestampUtc = 0;
        t_position_report_ind->timestampUtc |= temp_time_low;
        t_position_report_ind->timestampUtc = ((t_position_report_ind->timestampUtc << 32) | temp_time_hi);

//        printf("[GPS]qmi_loc_position_report_ind()  timestampUtc = %llu, temp_time_hi =%u, temp_time_low =%u\n",
//                                                    t_position_report_ind->timestampUtc,temp_time_hi,temp_time_low);
      }
      break;
      case LOC_POS_REPT_LEAP_SEC:
      {
        t_position_report_ind->leapSeconds_valid = TRUE;
        READ_8_BIT_VAL(value_ptr, temp_8bit);
        t_position_report_ind->leapSeconds = (uint8_t)temp_8bit;

//        printf("[GPS]qmi_loc_position_report_ind() leapSeconds =%d \n",t_position_report_ind->leapSeconds);
      }
      break;
      case LOC_POS_REPT_GPS_TIME:
      {
        t_position_report_ind->gpsTime_valid = TRUE;
        
        READ_16_BIT_VAL(value_ptr, temp_16bit);
        t_position_report_ind->gpsTime.gpsWeek = (uint16_t)temp_16bit;

//        printf("[GPS]qmi_loc_position_report_ind() gpsWeek =%d \n",t_position_report_ind->gpsTime.gpsWeek);
        READ_32_BIT_VAL(value_ptr, temp_32bit);
        t_position_report_ind->gpsTime.gpsTimeOfWeekMs = (uint32_t)temp_32bit;

//        printf("[GPS]qmi_loc_position_report_ind() gpsTimeOfWeekMs =%d \n",t_position_report_ind->gpsTime.gpsTimeOfWeekMs);
      }
      break;
      case LOC_POS_REPT_TIME_UNCERT:
      {
        t_position_report_ind->timeUnc_valid = TRUE;
        READ_32_BIT_VAL(value_ptr, temp_float);
        t_position_report_ind->timeUnc = (float)temp_float;

//        printf("[GPS]qmi_loc_position_report_ind() timeUnc =%lf\n",t_position_report_ind->timeUnc);
      }
      break;
      case LOC_POS_REPT_TIME_SOURCE:
      {
        t_position_report_ind->timeSrc_valid = TRUE;
        READ_32_BIT_VAL(value_ptr, temp_int_32bit);
        t_position_report_ind->timeSrc = (qmiLocTimeSourceEnumT_v02)temp_int_32bit;

//        printf("[GPS]qmi_loc_position_report_ind() timeSrc =%ld\n",t_position_report_ind->timeSrc);
      }
      break;
      case LOC_POS_REPT_SENSOR_DATA_USAGE:
      {
        t_position_report_ind->sensorDataUsage_valid = TRUE;
        
        READ_32_BIT_VAL(value_ptr, temp_32bit);
        t_position_report_ind->sensorDataUsage.usageMask = (qmiLocSensorUsageMaskT_v02)temp_32bit;

//        printf("[GPS]qmi_loc_position_report_ind() usageMask =%ld\n",t_position_report_ind->sensorDataUsage.usageMask);
        READ_32_BIT_VAL(value_ptr, temp_32bit);
        t_position_report_ind->sensorDataUsage.aidingIndicatorMask = (qmiLocSensorAidedMaskT_v02)temp_32bit;

//        printf("[GPS]qmi_loc_position_report_ind() aidingIndicatorMask =%ld\n",t_position_report_ind->sensorDataUsage.aidingIndicatorMask);
      }
      break;
      case LOC_POS_REPT_FIX_CNT_FOR_THIS_SESSION:
      {
        t_position_report_ind->fixId_valid = TRUE;
        
        READ_32_BIT_VAL(value_ptr, temp_32bit);
        t_position_report_ind->fixId = (uint32_t)temp_32bit;

//        printf("[GPS]qmi_loc_position_report_ind() fixId =%ld\n",t_position_report_ind->fixId);
      }
      break;
      case LOC_POS_REPT_SVC_USED_TO_CALC_FIX:
      {
        t_position_report_ind->gnssSvUsedList_valid = TRUE;

        READ_8_BIT_VAL(value_ptr, temp_8bit);
        t_position_report_ind->gnssSvUsedList_len = temp_8bit;

//        printf("[GPS]qmi_loc_position_report_ind() gnssSvUsedList_len =% d\n",t_position_report_ind->gnssSvUsedList_len);
        for(i=0; (i < t_position_report_ind->gnssSvUsedList_len && i < QMI_LOC_MAX_SV_USED_LIST_LENGTH_V02); i++)
        {
          READ_16_BIT_VAL(value_ptr, temp_16bit);
          t_position_report_ind->gnssSvUsedList[i] = temp_16bit;

//          printf("[GPS]qmi_loc_position_report_ind() gnssSvUsedList[%d] =%d\n",i,t_position_report_ind->gnssSvUsedList[i]);
        }
      }
      break;
      case LOC_POS_REPT_ALTITUDE_ASSUMED:
      {
        t_position_report_ind->altitudeAssumed_valid = TRUE;
        READ_8_BIT_VAL(value_ptr, temp_8bit);
        t_position_report_ind->altitudeAssumed = (uint8_t)temp_8bit;

//        printf("[GPS]qmi_loc_position_report_ind() altitudeAssumed =%d\n",t_position_report_ind->altitudeAssumed);
      }
      break;
      default:
        MSG_ERROR("Unknown Type =%d",type,0,0);
      break;
    }
  }

  
#if 0 // Just for Debugging..    
        static boolean save_log = FALSE;
  
        if(save_log == FALSE)
        {
          save_log = TRUE;
          if(loc_log_test(t_position_report_ind,sizeof(qmiLocEventPositionReportIndMsgT_v02)) == FALSE)
          {
            printf("loc_log_test() process FALSE \n");
          }
          else
          {
            printf("loc_log_test() process TRUE \n");
          }
        }
#endif      

  return QMI_NO_ERR;
}


/*===========================================================================

  FUNCTION  qmi_loc_gnss_sv_info_report_ind

  Description : FOR the TOF of Clarion, this function is only returned a "Latitude", "Longitude" and "Time Stamp".
                    Please keep in mind that If you want to have more information returned, you must change this function 
                    to what you want to make.

===========================================================================*/
static int qmi_loc_gnss_sv_info_report_ind
(
  unsigned char                                   *rx_buf,
  int                                             rx_buf_len,
  qmiLocEventGnssSvInfoIndMsgT_v02            *t_event_gnss_sv_info_ind
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;

  uint32  temp_32bit_validMask =0;
  uint32  temp_32bit_system =0;
  uint16_t  temp_16bit_gnssSvId =0;
  uint32  temp_32bit_svStatus =0;
  unsigned char temp_32bit_svList_len =0;  
  uint16_t  temp_16bit =0;
  uint8_t temp_8bit_healthStatus = 0;
  uint8_t temp_8bit_svInfoMask = 0;
  uint8_t temp_8bit_altitudeAssumed =0;
  uint8 u_Cntr = 0;
  float   temp_float_elevation = 0;
  float   temp_float_azimuth = 0;
  float   temp_float_snr = 0;
    
  /* Clear response buffer */
  memset(t_event_gnss_sv_info_ind, 0, sizeof(t_event_gnss_sv_info_ind));

  MSG_ERROR("[GPS]qmi_loc_gnss_sv_info_report_ind() rx_buf_len =%d \n",rx_buf_len,0,0);
  
  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      MSG_ERROR("qmi_util_read_std_tlv() Failed!!! Return ERR",0,0,0);
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case LOC_POS_GNSS_SV_ALTITUDE_ASSUMED:
      {
        READ_8_BIT_VAL(value_ptr, temp_8bit_altitudeAssumed ); 
        t_event_gnss_sv_info_ind->altitudeAssumed = (uint8_t)temp_8bit_altitudeAssumed ;
      }
      break;
      case LOC_POS_GNSS_SV_SATELLITE_INFO:
      {
        t_event_gnss_sv_info_ind->svList_valid = TRUE;
        READ_8_BIT_VAL(value_ptr, temp_32bit_svList_len); 
        t_event_gnss_sv_info_ind->svList_len = temp_32bit_svList_len;

        /* Loop through allowed count of SV-Infos from Loc-Mw */
        
        for ( u_Cntr = 0; 
              u_Cntr < t_event_gnss_sv_info_ind->svList_len; 
              u_Cntr++ )
        {
            READ_32_BIT_VAL(value_ptr, temp_32bit_validMask);
            t_event_gnss_sv_info_ind->svList[u_Cntr].validMask = (qmiLocSvInfoValidMaskT_v02)temp_32bit_validMask;

            READ_32_BIT_VAL(value_ptr, temp_32bit_system);
            t_event_gnss_sv_info_ind->svList[u_Cntr].system = (qmiLocSvSystemEnumT_v02)temp_32bit_system;

            READ_16_BIT_VAL(value_ptr, temp_16bit_gnssSvId);
            t_event_gnss_sv_info_ind->svList[u_Cntr].gnssSvId =  temp_16bit_gnssSvId;

            READ_8_BIT_VAL(value_ptr, temp_8bit_healthStatus); 
            t_event_gnss_sv_info_ind->svList[u_Cntr].healthStatus = temp_8bit_healthStatus;

            READ_32_BIT_VAL(value_ptr, temp_32bit_svStatus);
            t_event_gnss_sv_info_ind->svList[u_Cntr].svStatus = (qmiLocSvStatusEnumT_v02)temp_32bit_svStatus;

            READ_8_BIT_VAL(value_ptr, temp_8bit_svInfoMask); 
            t_event_gnss_sv_info_ind->svList[u_Cntr].svInfoMask = (qmiLocSvInfoMaskT_v02)temp_8bit_svInfoMask;

            READ_32_BIT_VAL(value_ptr, temp_float_elevation);
            t_event_gnss_sv_info_ind->svList[u_Cntr].elevation =  temp_float_elevation;

            READ_32_BIT_VAL(value_ptr, temp_float_azimuth);
            t_event_gnss_sv_info_ind->svList[u_Cntr].azimuth =  temp_float_azimuth;

            READ_32_BIT_VAL(value_ptr, temp_float_snr);
            t_event_gnss_sv_info_ind->svList[u_Cntr].snr =  temp_float_snr;
        }
 
      }
      break;

      default:
        MSG_ERROR("Unknown Type =%d",type,0,0);
      break;
    }
  }

  return QMI_NO_ERR;
}



static int qmi_loc_position_nmea_report_ind
(
  unsigned char                                   *rx_msg,
  int                                             rx_msg_size,
  qmiLocEventNmeaIndMsgT_v02 *t_position_nmea_report_ind
)
{
  unsigned long                          type;
  unsigned long                          length;
  unsigned char                        * value_ptr;

  /* Clear response buffer */
  memset((char *)&t_position_nmea_report_ind->nmea, 0x0 ,sizeof(qmiLocEventNmeaIndMsgT_v02));
  
  if (qmi_util_read_std_tlv (&rx_msg,
                           &rx_msg_size,
                           &type,
                           &length,
                           &value_ptr) < 0)
  {
    return QMI_INTERNAL_ERR;
  }
  
  memcpy(t_position_nmea_report_ind->nmea, value_ptr, length);

  return QMI_NO_ERR;

}

/*===========================================================================
FUNCTION       QMI_LOC_CLIENT_ERROR_CB

DESCRIPTION 
  QMI_LOC error callback handler. This callback is called by QCCI
  to notify error.

DEPENDENCIES  

RETURN VALUE 
  None 

SIDE EFFECTS 
  None 
===========================================================================*/
void qmi_loc_client_error_cb
(
  int user_handle,
  int error,
  void *err_cb_data
)
{
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

  MSG_ERROR("ecall_qmi_loc_client_error_cb()",0,0,0);

  /*---------------------------------------------------------------------
     Check if err cb data pointer is valid
  ---------------------------------------------------------------------*/
  if(err_cb_data == NULL)
  {
    MSG_ERROR("Null pointer passed",0,0,0);
    return;
  }

  /*---------------------------------------------------------------------
     Check if calback data is valid
  ---------------------------------------------------------------------*/
  if((int)(*((int*)err_cb_data)) != LOC_CLIENT_CB_DATA)
  {
    MSG_ERROR("Invalid callback data",0,0,0);
    return;
  }

  switch(error)
  {
    /*-----------------------------------------------------------------------
      In case of service error, client will be released. No attempt to recover
      the QMI connection will be made.
    ------------------------------------------------------------------------*/
    case QMI_SERVICE_ERR:
      MSG_ERROR("QMI_LOC service is down",0,0,0);

    /*-----------------------------------------------------------------------
        Release the client.
      ------------------------------------------------------------------------*/
      if(QMI_NO_ERR != qmi_client_release(loc_client_handle))
      {
        MSG_ERROR("Client release failed",0,0,0);
        return;
      }

      loc_client_handle = NULL;
      break;

    default:
      MSG_ERROR("ecall_qmi_loc_client_error_cb(): error=%ld",error,0,0);
  }
  return;
}

/*===========================================================================
FUNCTION QMI_LOC_CLIENT_REGISTER_EVENT

DESCRIPTION


DEPENDENCIES  

RETURN VALUE 
  None

SIDE EFFECTS 
  None
===========================================================================*/
void qmi_loc_client_register_event
(
  TOF_Loc_Event_Reg_Mask_type local_EvtRegMask
)
{
  qmi_txn_handle get_sys_txn_hdl;
  qmiLocRegEventsReqMsgT_v02 *LocRegEventsReqMsg;
  qmiLocGenRespMsgT_v02 *loc_ind_reg_resp_msg;
  int r = QMI_NO_ERR;

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
  QMI_ERR_MSG_0("qmi_loc_client_register_event()) start \n");
  /*-----------------------------------------------------------------------
    Allocate dynamic memory for response message. Memory will be freed
    during response message callback handler
  ------------------------------------------------------------------------*/
  if(loc_service_initialized == FALSE)
  {
    MSG_ERROR("LOC service is not initialized yet!!",0,0,0);
    return;
  }
  
  loc_ind_reg_resp_msg
    = (qmiLocGenRespMsgT_v02 *)malloc(sizeof(qmiLocGenRespMsgT_v02));

  if(loc_ind_reg_resp_msg == NULL)
  {
    MSG_ERROR("Couldn't get data_block_ptr memory",0,0,0);
    return;
  }

  LocRegEventsReqMsg
    = (qmiLocRegEventsReqMsgT_v02*)malloc(sizeof(qmiLocRegEventsReqMsgT_v02));

  if(LocRegEventsReqMsg == NULL)
  {
    MSG_ERROR("Couldn't get data_block_ptr memory",0,0,0);
    free(loc_ind_reg_resp_msg);
    return;
  }

  memset(LocRegEventsReqMsg,0,sizeof(qmiLocRegEventsReqMsgT_v02));

  LocRegEventsReqMsg->eventRegMask = (qmiLocEventRegMaskT_v02)local_EvtRegMask;

  QMI_ERR_MSG_2("[GPS]local_type =%x, eventRegMask =%x",local_EvtRegMask,LocRegEventsReqMsg->eventRegMask);

  memset(loc_ind_reg_resp_msg,0,sizeof(qmiLocGenRespMsgT_v02));

  r = qmi_loc_msg_req( (int)loc_client_handle,
                QMI_LOC_REG_EVENTS_REQ_V02,
                (void*)&LocRegEventsReqMsg,
                (void*)loc_ind_reg_resp_msg,
                NULL,
                NULL );

  QMI_ERR_MSG_1("[GPS]after qmi_loc_msg_req() r =%d",r);
  
  if ( QMI_NO_ERR != r )
  {
    MSG_ERROR( "[GPS] request_dial() fail, error:%d", r, 0, 0 );
    free(loc_ind_reg_resp_msg);
    free(LocRegEventsReqMsg);
    return FALSE;
  }

  if ( QMI_RESULT_SUCCESS_V01 != loc_ind_reg_resp_msg->resp.result )
  {
    MSG_ERROR( "[GPS] request_dial() rsp fail, error:%d", loc_ind_reg_resp_msg->resp.error, 0, 0 );
    free(loc_ind_reg_resp_msg);
    free(LocRegEventsReqMsg);
    return FALSE;
  }

  {
    static_curr_set_val.curr_eventRegMask_qti = LocRegEventsReqMsg->eventRegMask;
    QMI_ERR_MSG_2("[GPS]request_loc_get_nmea_type() curr_eventRegMask_qti =%d, eventRegMask =0x%x ended!!\n",
                                static_curr_set_val.curr_eventRegMask_qti,LocRegEventsReqMsg->eventRegMask);
  }
    
  if(LocRegEventsReqMsg != NULL)
  {
    free(LocRegEventsReqMsg);
  }

  if(loc_ind_reg_resp_msg != NULL)
  {
    free(loc_ind_reg_resp_msg);
  }

  QMI_ERR_MSG_0("[GPS]qmi_loc_client_register_event() End!!!");
}


/*===========================================================================
FUNCTION  QMI_LOC_CLIENT_RECV_LOC_START_RESP

DESCRIPTION 
  Handle callbacks response of QMI_LOC_START_REQ_V02 and
  QMI_LOC_REG_EVENTS_REQ_V02.

DEPENDENCIES 
  FEATURE_ECALL_HAS_QMI_LOC

RETURN VALUE 
  None 

SIDE EFFECTS 
  Release the memory assigned for response
===========================================================================*/
void qmi_loc_client_recv_loc_start_resp( int             qmi_err_code,
                                    int             msg_id,
                                    unsigned char*  msg,
                                    int             msg_size,
                                    void*           rsp )
{
  qmiLocGenRespMsgT_v02    *loc_resp = NULL;

  loc_resp = (qmiLocGenRespMsgT_v02 *)rsp;
  
  if ( QMI_SERVICE_ERR_NONE == qmi_err_code )
  {
    loc_resp->resp.result = (qmi_result_type_v01)QMI_RESULT_SUCCESS_V01;
  }
  else
  {
    loc_resp->resp.error  = (qmi_error_type_v01)qmi_err_code;
    loc_resp->resp.result = (qmi_result_type_v01)QMI_RESULT_FAILURE_V01;

    return QMI_SERVICE_ERR;
  }

  if( (msg_id != QMI_LOC_START_RESP_V02) && 
      (msg_id != QMI_LOC_REG_EVENTS_RESP_V02) &&
      (msg_id != QMI_LOC_STOP_RESP_V02) &&
      (msg_id != QMI_LOC_INFORM_LOCATION_SERVER_CONN_STATUS_REQ_V02))
  {
    MSG_ERROR("Invalid msg_id=%u. Free mem 0x%x",msg_id,loc_resp,0 );
    return;
  }

  if(loc_resp->resp.result == QMI_RESULT_SUCCESS_V01 && loc_resp->resp.error == QMI_ERR_NONE_V01)
  {
    MSG_ERROR("Success to register a event mask !! ",0,0,0);
    switch(msg_id)
    {
      case QMI_LOC_REG_EVENTS_REQ_V02:
        loc_event_registered = TRUE;
        QMI_ERR_MSG_0("Registration Mask for Position Report is sucessfully set!!");
      break;
      case QMI_LOC_START_RESP_V02:
        loc_service_start = TRUE;
        QMI_ERR_MSG_0("LOC service START command is sucessfully set!!");
      break;
      case QMI_LOC_STOP_RESP_V02:
        loc_service_start = FALSE;
        QMI_ERR_MSG_0("LOC service STOP command is sucessfully set!!");
      break;
      case QMI_LOC_INFORM_LOCATION_SERVER_CONN_STATUS_REQ_V02:
        QMI_ERR_MSG_0("LOC TCP Open for SPL server command is sucessfully set!!");
      break;
    }
       
  }
}

/*===========================================================================
FUNCTION       QMI_LOC_GET_POSITION_START

DESCRIPTION
  This function will send the QMI_LOC_START_REQ_V02 command to QMI_LOC
  to start the location session.

DEPENDENCIES 
  FEATURE_ECALL_HAS_QMI_LOC 

RETURN VALUE 
  None

SIDE EFFECTS 
  None
===========================================================================*/
void qmi_loc_get_position_start
(
  uint32 gnss_update_time_ms
)
{
  qmi_txn_handle          get_sys_txn_hdl;
  qmiLocGenRespMsgT_v02   loc_resp_msg;
  qmiLocStartReqMsgT_v02  loc_req_msg;
  int r = QMI_NO_ERR;
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

  MSG_ERROR( "ecall_qmi_loc_client_session_start()",0,0,0 );

  if(loc_service_initialized == FALSE || loc_event_registered == FALSE)
  {
    MSG_ERROR("LOC service is not initialized yet!! service =%d, event =%d",loc_service_initialized,loc_event_registered,0);
    return;
  }
  
  memset(&loc_req_msg,0,sizeof(qmiLocStartReqMsgT_v02));
  memset(&loc_resp_msg,0,sizeof(qmiLocGenRespMsgT_v02));

 memset((void*)&gps_Position_report_data, 0, sizeof(qmiLocEventPositionReportIndMsgT_v02));
 memset((void*)&gps_gnss_sv_info_data, 0, sizeof(qmiLocEventGnssSvInfoIndMsgT_v02));
 memset((void*)&gps_nmea_ind_data, 0, sizeof(qmiLocEventNmeaIndMsgT_v02));

 /* --------------GPS Test Only---------------*/
  /*
  gps_Position_report_data.latitude=37.297156 ;
  gps_Position_report_data.longitude=306.000000;
  gps_Position_report_data.altitudeWrtEllipsoid=15.300000;
  gps_Position_report_data.heading= 1.378768;
  gps_Position_report_data.speedHorizontal=61.000000;
  gps_Position_report_data.speedVertical=64.000000;
  gps_Position_report_data.DOP.VDOP=22.00000;
  gps_Position_report_data.DOP.HDOP=33.00000;
  gps_Position_report_data.DOP.PDOP=44.00000;
  gps_Position_report_data.speedUnc=55.00000;
  gps_Position_report_data.altitudeWrtMeanSeaLevel=66.00000;
  gps_Position_report_data.horUncCircular=77.00000;

  gps_gnss_sv_info_data.svList[0].gnssSvId = 10;
  gps_gnss_sv_info_data.svList[1].gnssSvId = 20;
  gps_gnss_sv_info_data.svList[2].gnssSvId = 30;
  gps_gnss_sv_info_data.svList[3].gnssSvId = 40;
  gps_gnss_sv_info_data.svList[4].gnssSvId = 50;
  gps_gnss_sv_info_data.svList[5].gnssSvId = 60;
  gps_gnss_sv_info_data.svList[6].gnssSvId = 70;
  gps_gnss_sv_info_data.svList[7].gnssSvId = 80;
  gps_gnss_sv_info_data.svList[8].gnssSvId = 90;
  gps_gnss_sv_info_data.svList[9].gnssSvId = 100;
  gps_gnss_sv_info_data.svList[10].gnssSvId = 110;
  gps_gnss_sv_info_data.svList[11].gnssSvId = 120;
	
  gps_Position_report_data.gnssSvUsedList[0] = 13;
  gps_Position_report_data.gnssSvUsedList[1] = 15;
  gps_Position_report_data.gnssSvUsedList[2] = 20;
  gps_Position_report_data.gnssSvUsedList[3] = 29;
  gps_Position_report_data.gnssSvUsedList[4] = 69;
  gps_Position_report_data.gnssSvUsedList[5] = 83;
  gps_Position_report_data.gnssSvUsedList[6] = 213;
  gps_Position_report_data.gnssSvUsedList[7] = 214;
  gps_Position_report_data.gnssSvUsedList[8] = 273;
  gps_Position_report_data.gnssSvUsedList[9] = 337;	
  */
  
  loc_req_msg.sessionId = TOF_LOC_SESSION_ID;
  /* Request for periodic Fixes */
  loc_req_msg.fixRecurrence_valid = FALSE; /* Single Fix */ /* Request periodic position Fix */
//  loc_req_msg.fixRecurrence = 1 /* 1 : Recurrence Periodic,  2 : Recurrnece Single*/
  /* Request for stable fixes only */
  loc_req_msg.intermediateReportState_valid = TRUE;
  loc_req_msg.intermediateReportState = 0x00000002; /* 0x00000002 -- OFF; default: 0x00000001 -- ON */
  /* Set the minimum interval between fixes */
  loc_req_msg.minInterval_valid = TRUE;
  loc_req_msg.minInterval = gnss_update_time_ms;
  /* Set horizontal accuracy to HIGH */
  loc_req_msg.horizontalAccuracyLevel_valid = TRUE;
  loc_req_msg.horizontalAccuracyLevel = 0x00000002; /* 0x00000003 -- HIGH; default: 0x00000001 -- LOW */

  r = qmi_loc_msg_req( (int)loc_client_handle,
                QMI_LOC_START_REQ_V02,
                (void*)&loc_req_msg,
                (void*)&loc_resp_msg.resp,
                NULL,
                NULL );

  if ( QMI_NO_ERR != r )
  {
    MSG_ERROR( "[GPS] request_dial() fail, error:%d", r, 0, 0 );
    return;
  }

  if ( QMI_RESULT_SUCCESS_V01 != loc_resp_msg.resp.result )
  {
    MSG_ERROR( "[GPS] request_dial() rsp fail, error:%d", loc_resp_msg.resp.error, 0, 0 );
    return;
  }

  MSG_ERROR( "[GPS] request_dial() fail, error:%d", r, 0, 0 );
  if((static_curr_set_val.curr_mode != LOC_OPER_MODE_DEFAULT) && 
      (static_curr_set_val.curr_mode != LOC_OPER_MODE_STANDALONE))
  {
    if(loc_time_count(LOC_TIME_WAIT_CONN_STATUS_ID) != TRUE) 
    {
      QMI_ERR_MSG_0 ("[GPS] LOC_TIME_WAIT_CONN_STATUS_ID: fail to start Timer!!\n ");
    }
  }
  
  QMI_ERR_MSG_0("qmi_loc_get_position_start() Success to execute!!");
  
} 

/*===========================================================================
FUNCTION       QMI_LOC_GET_POSITION_STOP

DESCRIPTION
  This function will send the QMI_LOC_STOP_REQ_V02 command to QMI_LOC
  to stop the location session.

DEPENDENCIES 
  FEATURE_ECALL_HAS_QMI_LOC 

RETURN VALUE 
  None

SIDE EFFECTS 
  None
===========================================================================*/
void qmi_loc_get_position_stop
(
  void
)
{
  qmi_txn_handle get_sys_txn_hdl;
  qmiLocGenRespMsgT_v02   loc_resp_msg;
  qmiLocStopReqMsgT_v02   loc_req_msg;
  int r = QMI_NO_ERR;
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

  MSG_ERROR("qmi_loc_get_position_stop()",0,0,0 );

 memset((void*)&gps_Position_report_data, 0, sizeof(qmiLocEventPositionReportIndMsgT_v02));
 memset((void*)&gps_gnss_sv_info_data, 0, sizeof(qmiLocEventGnssSvInfoIndMsgT_v02));
 memset((void*)&gps_nmea_ind_data, 0, sizeof(qmiLocEventNmeaIndMsgT_v02));

  if(loc_service_initialized == FALSE || loc_service_start == FALSE)
  {
    MSG_ERROR("LOC service is not initialized yet!! service =%d, start =%d",loc_service_initialized,loc_service_start,0);
    return;
  }

  memset(&loc_req_msg,0,sizeof(qmiLocStopReqMsgT_v02));

  loc_req_msg.sessionId = TOF_LOC_SESSION_ID;

  memset(&loc_resp_msg,0,sizeof(qmiLocGenRespMsgT_v02));
  
  r = qmi_loc_msg_req( (int)loc_client_handle,
                QMI_LOC_STOP_REQ_V02,
                (void*)&loc_req_msg,
                (void*)&loc_resp_msg,
                NULL,
                NULL );

  if ( QMI_NO_ERR != r )
  {
    MSG_ERROR( "[GPS] request_dial() fail, error:%d", r, 0, 0 );
    return;
  }

  if ( QMI_RESULT_SUCCESS_V01 != loc_resp_msg.resp.result )
  {
    MSG_ERROR( "[GPS] request_dial() rsp fail, error:%d", loc_resp_msg.resp.error, 0, 0 );
    return;
  }

  if((static_curr_set_val.curr_mode != LOC_OPER_MODE_DEFAULT) && 
      (static_curr_set_val.curr_mode != LOC_OPER_MODE_STANDALONE))
  {
    // Send a QMI_LOC_INFORM_LOCATION_SERVER_CONN_STATUS set with "Close" to handle a ATL.
    if(loc_time_count(LOC_TIME_WAIT_SERVER_CONN_CLOSE_ID) != TRUE)
    {
      QMI_ERR_MSG_0 ("[GPS] LOC_TIME_WAIT_SERVER_CONN_CLOSE_ID: fail to start Timer!!\n ");
    }
  }
  
  MSG_ERROR( "Send loc start request successful",0,0,0 );
  
} 

static void qmi_loc_srvc_async_cb( int   user_handle,
                    qmi_service_id_type     service_id,
                    unsigned long           msg_id,
                    int                     rsp_rc,
                    int                     qmi_err_code,
                    unsigned char*          reply_msg_data,
                    int                     reply_msg_size,
                    void*                   srvc_async_cb_data,
                    void*                   user_async_cb_fn,
                    void*                   user_async_cb_data )
{
  void* rsp = NULL;

  qmiLocGenRespMsgT_v02   loc_srvc_rsp;

  memset( &loc_srvc_rsp, 0x0, sizeof( qmiLocGenRespMsgT_v02 ) );

  rsp = &loc_srvc_rsp;
  
  qmi_loc_client_recv_loc_start_resp( qmi_err_code, msg_id, reply_msg_data, reply_msg_size, rsp );

}

int  qmi_loc_msg_req( int client_handle,
              int qmi_loc_msg_id,
              void* req_data,
              void* rsp_data,
              qmi_loc_user_async_cb_type  user_cb,
              void* user_data )
{
  int        r = QMI_NO_ERR;
  int        qmi_err_code = QMI_SERVICE_ERR_NONE;

  unsigned char  msg[ QMI_LOC_STD_MSG_SIZE ];
  int        msg_size = 0;
  unsigned char*  tmp_msg_ptr;
  
  QMI_ERR_MSG_0("[GPS]qmi_loc_msg_req() Start!!!\n");
  
  if ( NULL == user_cb && NULL == rsp_data )
    return QMI_SERVICE_ERR;

  tmp_msg_ptr = QMI_SRVC_PDU_PTR( msg );
  msg_size  = QMI_SRVC_PDU_SIZE( QMI_LOC_STD_MSG_SIZE );

  if ( qmi_loc_req_write_tlv( qmi_loc_msg_id, &tmp_msg_ptr, &msg_size, req_data ) < 0 )
  {
    QMI_ERR_MSG_0("[GPS]qmi_loc_msg_req() failed to qmi_loc_req_write_tlv()\n");
    return QMI_INTERNAL_ERR;
  }

  QMI_ERR_MSG_2("[GPS]qmi_loc_msg_req() after qmi_loc_req_write_tlv() qmi_loc_msg_id =%x, msg_size =%d \n",qmi_loc_msg_id,msg_size);
  if ( NULL == user_cb )
  {
    r = qmi_service_send_msg_sync( client_handle,
                     QMI_LOC_SERVICE,
                     qmi_loc_msg_id,
                     QMI_SRVC_PDU_PTR( msg ),
                     (int)QMI_SRVC_PDU_SIZE( QMI_LOC_STD_MSG_SIZE ) - msg_size,
                     msg,                 
                     &msg_size,
                     QMI_LOC_STD_MSG_SIZE,
                     QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                     &qmi_err_code );
    
    QMI_ERR_MSG_2("[GPS]qmi_loc_msg_req() after qmi_service_send_msg_sync() r =%d, qmi_err_code =%d \n",r,qmi_err_code);
    
    if ( QMI_NO_ERR == r )
    {
      QMI_ERR_MSG_0("[GPS]qmi_loc_msg_req() r == QMI_NO_ERR \n");
      if ( NULL != rsp_data )
      {
        QMI_ERR_MSG_0("[GPS]qmi_loc_msg_req() rsp_data is not NULL \n");
        r = qmi_loc_reg_event_ind( qmi_err_code, qmi_loc_msg_id, msg, msg_size, rsp_data );

        QMI_ERR_MSG_0("[GPS]qmi_loc_msg_req() End!!!\n");
      }
    }
  }
  else
  {
    r = qmi_service_send_msg_async( client_handle,
                    QMI_LOC_SERVICE,
                    qmi_loc_msg_id,
                    QMI_SRVC_PDU_PTR( msg ),
                    (int)QMI_SRVC_PDU_SIZE( QMI_LOC_STD_MSG_SIZE ) - msg_size,
                    qmi_loc_srvc_async_cb,
                    NULL,
                    (void *)user_cb,
                    user_data );
  }
  
  return r;
}

static int  qmi_loc_req_write_tlv( int        msg_id,
                   unsigned char**  msg,
                   int*        msg_size,
                   void*        req )
{
  
  switch ( msg_id )
  {
    case QMI_LOC_REG_EVENTS_REQ_V02:
    {
      qmiLocRegEventsReqMsgT_v02* loc_reg_event_req = (qmiLocRegEventsReqMsgT_v02*)req;

      QMI_ERR_MSG_1("[GPS]qmi_loc_req_write_tlv() eventRegMask =%llu \n",loc_reg_event_req->eventRegMask);            
      if ( qmi_util_write_std_tlv( msg,
                     msg_size,
                     QMI_LOC_MANDATORY_1_TLV_ID,
                     sizeof( qmiLocEventRegMaskT_v02 ),
                     (loc_reg_event_req->eventRegMask) ) < 0 )
      {
        return QMI_INTERNAL_ERR;
      }
    }
    break;
    case QMI_LOC_START_REQ_V02:
    {
      qmiLocStartReqMsgT_v02 * loc_start_reg = (qmiLocStartReqMsgT_v02 *)req;

  //Session ID (M : 0x01)
      QMI_ERR_MSG_1("[GPS]qmi_loc_req_write_tlv() QMI_LOC_START_REQ_V02 sessionId =0x%x \n",loc_start_reg->sessionId);  

      if ( qmi_util_write_std_tlv( msg,
                     msg_size,
                     QMI_LOC_MANDATORY_1_TLV_ID,
                     sizeof( uint8_t),
                     &(loc_start_reg->sessionId)) < 0 )
      {
        return QMI_INTERNAL_ERR;
      }

      QMI_ERR_MSG_1("[GPS]qmi_loc_req_write_tlv() Horizontal Accuracy Leve =0x%x\n",loc_start_reg->horizontalAccuracyLevel); 
  // Horizontal Accuracy Level (O : 0x11)
      if(loc_start_reg->horizontalAccuracyLevel_valid == TRUE)
      {
        if ( qmi_util_write_std_tlv( msg,
                     msg_size,
                     QMI_LOC_OPTIONAL_2_TLV_ID,
                     sizeof( qmiLocAccuracyLevelEnumT_v02),
                     &(loc_start_reg->horizontalAccuracyLevel)) < 0 )
        {
          return QMI_INTERNAL_ERR;
        }
      }

      QMI_ERR_MSG_1("[GPS]qmi_loc_req_write_tlv() Intermediate Report State =0x%x \n",loc_start_reg->horizontalAccuracyLevel); 
  // Intermediate Report State (O : 0x12)
      if(loc_start_reg->intermediateReportState_valid == TRUE)
      {
        if ( qmi_util_write_std_tlv( msg,
                     msg_size,
                     QMI_LOC_OPTIONAL_3_TLV_ID,
                     sizeof( qmiLocIntermediateReportStateEnumT_v02),
                     &loc_start_reg->intermediateReportState) < 0 )
        {
          return QMI_INTERNAL_ERR;
        }
      }

      QMI_ERR_MSG_1("[GPS]qmi_loc_req_write_tlv() Minimum Time Interval =0x%x \n",loc_start_reg->horizontalAccuracyLevel); 
  // Minimum Time Interval (O : 0x13)
      if(loc_start_reg->minInterval_valid == TRUE)
      {
        if ( qmi_util_write_std_tlv( msg,
                     msg_size,
                     QMI_LOC_OPTIONAL_4_TLV_ID,
                     sizeof( uint32_t),
                     &loc_start_reg->minInterval) < 0 )
        {
          return QMI_INTERNAL_ERR;
        }
      }   
  
    }
    break;
    case QMI_LOC_STOP_REQ_V02:
    {
      qmiLocStopReqMsgT_v02 * loc_stop_reg = (qmiLocStopReqMsgT_v02 *)req;

      QMI_ERR_MSG_1("[GPS]qmi_loc_req_write_tlv() qmiLocStopReqMsgT_v02 sessiondID =0x%x \n",loc_stop_reg->sessionId);            
      if ( qmi_util_write_std_tlv( msg,
                     msg_size,
                     QMI_LOC_MANDATORY_1_TLV_ID,
                     sizeof( qmiLocStopReqMsgT_v02 ),
                     &loc_stop_reg->sessionId) < 0 )
      {
        return QMI_INTERNAL_ERR;
      }
    }
    break;
    case QMI_LOC_SET_OPERATION_MODE_REQ_V02:
    {
      qmiLocSetOperationModeReqMsgT_v02 *operation_mode_req = (qmiLocSetOperationModeReqMsgT_v02 *)req;
      QMI_ERR_MSG_1("[GPS]qmi_loc_req_write_tlv() qmiLocSetOperationModeReqMsgT_v02 operation_mode_req =%d \n",operation_mode_req->operationMode);            
      if ( qmi_util_write_std_tlv( msg,
                     msg_size,
                     QMI_LOC_MANDATORY_1_TLV_ID,
                     sizeof( qmiLocOperationModeEnumT_v02 ),
                     &operation_mode_req->operationMode) < 0 )
      {
        return QMI_INTERNAL_ERR;
      }
    }
    break;
    case QMI_LOC_SET_NMEA_TYPES_REQ_V02:
    {
      qmiLocSetNmeaTypesReqMsgT_v02 *nmea_type_req = (qmiLocSetNmeaTypesReqMsgT_v02 *)req;
      QMI_ERR_MSG_1("[GPS]qmi_loc_req_write_tlv() qmiLocSetNmeaTypesReqMsgT_v02 nmeaSentenceType =%d \n",nmea_type_req->nmeaSentenceType);            
      if ( qmi_util_write_std_tlv( msg,
                     msg_size,
                     QMI_LOC_MANDATORY_1_TLV_ID,
                     sizeof( qmiLocNmeaSentenceMaskT_v02 ),
                     &nmea_type_req->nmeaSentenceType) < 0 )
      {
        return QMI_INTERNAL_ERR;
      }
    }
    break;
    case QMI_LOC_SET_SERVER_REQ_V02:
    {
      qmiLocSetServerReqMsgT_v02   *supl_server_req = (qmiLocSetServerReqMsgT_v02 *)req;

      //Server Type (M : 0x01)
      QMI_ERR_MSG_3("[GPS]qmi_loc_req_write_tlv() qmiLocSetServerReqMsgT_v02 serverType =%d, ipv4Addr_valid =%d, msg_size =%d \n",
                                                    supl_server_req->serverType,supl_server_req->ipv4Addr_valid,msg_size);            
      if ( qmi_util_write_std_tlv( msg,
                     msg_size,
                     QMI_LOC_MANDATORY_1_TLV_ID,
                     sizeof( qmiLocServerTypeEnumT_v02 ),
                     &supl_server_req->serverType) < 0 )
      {
        return QMI_INTERNAL_ERR;
      }

      // IPv4 Address (O : 0x10) 
      if(supl_server_req->ipv4Addr_valid == TRUE)
      {
        QMI_ERR_MSG_3("[GPS]qmi_loc_req_write_tlv() ip addr =%x, Port =%d, msg_size =%d \n",
                                                    supl_server_req->ipv4Addr.addr,supl_server_req->ipv4Addr.port,msg_size);  
        if ( qmi_util_write_std_tlv( msg,
                     msg_size,
                     QMI_LOC_OPTIONAL_1_TLV_ID,
                     LOC_SPL_SV_IPV4_TYPE_LEN,
                     &(supl_server_req->ipv4Addr)) < 0 )
        {
          return QMI_INTERNAL_ERR;
        }
      }
      // IPv6 Address (O : 0x11) 
      if(supl_server_req->ipv6Addr_valid == TRUE)
      {
        if ( qmi_util_write_std_tlv( msg,
                     msg_size,
                     QMI_LOC_OPTIONAL_2_TLV_ID,
                     LOC_SPL_SV_IPV6_TYPE_LEN,
                     &(supl_server_req->ipv6Addr)) < 0 )
        {
          return QMI_INTERNAL_ERR;
        }
      }
      // URL Address (O : 0x12) 
      printf("QMI_LOC_SET_SERVER_REQ_V02 urlAddr_valid =%d, urlAddr_len =%d, urlAddr =%s",
                                                        supl_server_req->urlAddr_valid,strlen(supl_server_req->urlAddr),supl_server_req->urlAddr);
      if(supl_server_req->urlAddr_valid == TRUE)
      {
        if ( qmi_util_write_std_tlv( msg,
                     msg_size,
                     QMI_LOC_OPTIONAL_3_TLV_ID,
                     strlen(supl_server_req->urlAddr),
                     &(supl_server_req->urlAddr)) < 0 )
        {
          return QMI_INTERNAL_ERR;
        }
      }
      
    }
    break;
    case QMI_LOC_GET_SERVER_REQ_V02:
    {
      qmiLocGetServerReqMsgT_v02 *supl_server_req = (qmiLocGetServerReqMsgT_v02 *)req;
      QMI_ERR_MSG_1("[GPS]qmi_loc_req_write_tlv() qmiLocGetServerReqMsgT_v02 serverType =%d \n",supl_server_req->serverType);            
      if ( qmi_util_write_std_tlv( msg,
                     msg_size,
                     QMI_LOC_MANDATORY_1_TLV_ID,
                     sizeof( qmiLocServerTypeEnumT_v02 ),
                     &supl_server_req->serverType) < 0 )
      {
        return QMI_INTERNAL_ERR;
      }
    }
    break;
    case QMI_LOC_INFORM_LOCATION_SERVER_CONN_STATUS_REQ_V02:
    {
      qmiLocEventLocationServerConnectionReqIndMsgT_v02* conn_loc_server_req_msg = (qmiLocEventLocationServerConnectionReqIndMsgT_v02*)req;
      QMI_ERR_MSG_1("[GPS]qmi_loc_req_write_tlv() QMI_LOC_INFORM_LOCATION_SERVER_CONN_STATUS_REQ_V02 requestType =%d \n",conn_loc_server_req_msg->requestType);            
      if ( qmi_util_write_std_tlv( msg,
                     msg_size,
                     QMI_LOC_MANDATORY_1_TLV_ID,
                     sizeof( uint32_t ),
                     &conn_loc_server_req_msg->connHandle) < 0 )
      {
        return QMI_INTERNAL_ERR;
      }

      if ( qmi_util_write_std_tlv( msg,
                     msg_size,
                     QMI_LOC_MANDATORY_2_TLV_ID,
                     sizeof( qmiLocServerRequestEnumT_v02 ),
                     &conn_loc_server_req_msg->requestType) < 0 )
      {
        return QMI_INTERNAL_ERR;
      }

      if ( qmi_util_write_std_tlv( msg,
                     msg_size,
                     QMI_LOC_MANDATORY_3_TLV_ID,
                     sizeof( qmiLocWWANTypeEnumT_v02 ),
                     &conn_loc_server_req_msg->wwanType) < 0 )
      {
        return QMI_INTERNAL_ERR;
      }
    }
    break;
    case QMI_LOC_DELETE_ASSIST_DATA_REQ_V02:
    {
      qmiLocDeleteAssistDataReqMsgT_v02 *del_assist_dat_req = (qmiLocDeleteAssistDataReqMsgT_v02 *)req;
      QMI_ERR_MSG_1("[GPS]qmi_loc_req_write_tlv() qmiLocDeleteAssistDataReqMsgT_v02 deleteAllFlag =%d \n",del_assist_dat_req->deleteAllFlag);            
      if ( qmi_util_write_std_tlv( msg,
                     msg_size,
                     QMI_LOC_MANDATORY_1_TLV_ID,
                     sizeof( uint8_t ),
                     &del_assist_dat_req->deleteAllFlag) < 0 )
      {
        return QMI_INTERNAL_ERR;
      }
    }
    break;
    default:
      QMI_ERR_MSG_1("[GPS]qmi_loc_req_write_tlv() No Case for msg_id =%d \n",msg_id);        
    break;
  }

  return QMI_NO_ERR;
}

static int qmi_loc_reg_event_ind
(                                     int             qmi_err_code,
                                      int             msg_id,
                                      unsigned char*  msg,
                                      int             msg_size,
                                      void*           rsp )
{
//  unsigned long type;
//  unsigned long length;
  unsigned char *value_ptr;
  int  retval =0;  
  int32   temp_int_32bit =0;

  qmi_response_type_v01* t_resp = (qmi_response_type_v01*)rsp;

  if ( QMI_SERVICE_ERR_NONE == qmi_err_code )
  {
    t_resp->error = (qmi_error_type_v01)qmi_err_code;
    t_resp->result = (qmi_result_type_v01)QMI_RESULT_SUCCESS_V01;
  }
  else
  {
    t_resp->error = (qmi_error_type_v01)qmi_err_code;
    t_resp->result = (qmi_result_type_v01)QMI_RESULT_FAILURE_V01;

    return QMI_SERVICE_ERR;
  }
  
  QMI_ERR_MSG_2("[GPS]qmi_loc_reg_event_ind() result =%ld, error =%ld \n",t_resp->result,t_resp->error);
  switch(msg_id)
  {
    case QMI_LOC_REG_EVENTS_RESP_V02:
      loc_event_registered = TRUE;
      QMI_ERR_MSG_0("Registration Mask for Position Report is sucessfully set!! \n");
    break;
    case QMI_LOC_START_RESP_V02:
      loc_service_start = TRUE;
      QMI_ERR_MSG_0("LOC service START command is sucessfully set!! \n");
    break;
    case QMI_LOC_STOP_RESP_V02:
      loc_service_start = FALSE;
      QMI_ERR_MSG_0("LOC service STOP command is sucessfully set!! \n");
    break;
    default:
      QMI_ERR_MSG_1("qmi_loc_reg_event_ind() msg_id =%d \n",msg_id);
    break;
  }

#if 0 //If needed to process for returned value, do it in below source code  
  /* Cycle through return message reading all TLV's */
  while (msg_size > 0)
  {
    if (qmi_util_read_std_tlv ( &msg,
                                &msg_size,
                                &type,
                                &length,
                                &value_ptr ) < 0)
    {
      MSG_ERROR("qmi_util_read_std_tlv() Failed!!! Return ERR \n",0,0,0);
      return QMI_INTERNAL_ERR;
    }

    printf("[GPS]qmi_loc_reg_event_ind() msg_id =%d\n",msg_id);

  }
#endif 
  QMI_ERR_MSG_1("[GPS]qmi_loc_reg_event_ind() msg_id =%dended!!\n",msg_id);

  return QMI_NO_ERR;
}

static int qmi_loc_set_operation_mode_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  qmiLocSetOperationModeIndMsgT_v02            *operation_mode_rsp
)
{
  uint32  temp_32bit =0;
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;

  memset(operation_mode_rsp, 0, sizeof(qmiLocSetOperationModeIndMsgT_v02));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                             &rx_buf_len,
                             &type,
                             &length,
                             &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
    
    switch(type)
    {
      case QMI_LOC_MANDATORY_1_TLV_ID:
        READ_32_BIT_VAL(value_ptr, temp_32bit); 
        operation_mode_rsp->status = (qmiLocStatusEnumT_v02)temp_32bit;
      break;
    }
  }
  
  return QMI_NO_ERR;
}


static int qmi_loc_get_operation_mode_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  qmiLocGetOperationModeIndMsgT_v02            *operation_mode_rsp
)
{
  uint32  temp_32bit =0;
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;

  memset(operation_mode_rsp, 0, sizeof(qmiLocGetOperationModeIndMsgT_v02));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                             &rx_buf_len,
                             &type,
                             &length,
                             &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    switch(type)
    {
      case  QMI_LOC_MANDATORY_1_TLV_ID:
        READ_32_BIT_VAL(value_ptr, temp_32bit); 
        operation_mode_rsp->status = (qmiLocStatusEnumT_v02)temp_32bit;
      break;

      case QMI_LOC_OPTIONAL_1_TLV_ID:
        operation_mode_rsp->operationMode_valid= TRUE;
        READ_32_BIT_VAL(value_ptr, temp_32bit); 
        operation_mode_rsp->operationMode = (qmiLocOperationModeEnumT_v02)temp_32bit;
      break;
    }
 
  }
  
  return QMI_NO_ERR;
}

static int qmi_loc_set_nmea_type_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  qmiLocSetNmeaTypesIndMsgT_v02            *nmea_type_req
)
{
  uint32  temp_32bit =0;
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;

  memset(nmea_type_req, 0, sizeof(qmiLocSetNmeaTypesIndMsgT_v02));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                             &rx_buf_len,
                             &type,
                             &length,
                             &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
    
    switch(type)
    {
      case QMI_LOC_MANDATORY_1_TLV_ID:
        READ_32_BIT_VAL(value_ptr, temp_32bit); 
        nmea_type_req->status = (qmiLocStatusEnumT_v02)temp_32bit;
      break;
    }
  }
  
  return QMI_NO_ERR;
}


static int qmi_loc_get_nmea_type_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  qmiLocGetNmeaTypesIndMsgT_v02            *nmea_type_rsp
)
{
  uint32  temp_32bit =0;
  uint64  temp_64bit =0;
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;

  memset(nmea_type_rsp, 0, sizeof(qmiLocGetNmeaTypesIndMsgT_v02));

#if 0 //Test
  {
    FILE *msg_log_fp = NULL;
    size_t ret;

    if((msg_log_fp=fopen(LOG_FILE_PATH"Chad_NMEA_Test", "a+")) == NULL)
    {
      if((msg_log_fp=fopen(LOG_FILE_PATH"Chad_NMEA_Test", "a+")) == NULL)
      {
        chmod(LOG_FILE_PATH"Chad_NMEA_Test", 0755);
      }
      else
      {
        printf("[GPS]qmi_loc_get_nmea_type_info()Fail to make a file!!");
      }
    }
    else
    {
      chmod(LOG_FILE_PATH"Chad_NMEA_Test", 0755);
    }

    printf("[GPS]qmi_loc_get_nmea_type_info()Succeeded to make a file!!");
    
    ret = fwrite(rx_buf, 1, rx_buf_len, msg_log_fp);

    printf("[GPS]qmi_loc_get_nmea_type_info()Write to File!! ret =%d, msg_log_fp =%d",ret,msg_log_fp);
    
    fclose(msg_log_fp);    
  }  
#endif

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                             &rx_buf_len,
                             &type,
                             &length,
                             &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    switch(type)
    {
      case  QMI_LOC_MANDATORY_1_TLV_ID:
        READ_32_BIT_VAL(value_ptr, temp_32bit); 
        nmea_type_rsp->status = (qmiLocStatusEnumT_v02)temp_32bit;        
      break;

      case QMI_LOC_OPTIONAL_1_TLV_ID:
        nmea_type_rsp->nmeaSentenceType_valid= TRUE;
        READ_64_BIT_VAL(value_ptr, temp_64bit); 
        nmea_type_rsp->nmeaSentenceType = (qmiLocNmeaSentenceMaskT_v02)temp_64bit;
      break;
    }
  }
  
  return QMI_NO_ERR;
}

int  qmi_loc_set_operation_mode
(
  int                               client_handle,
  qmiLocSetOperationModeReqMsgT_v02             *operation_mode_req, 
  int                               *qmi_err_code
)
{

  unsigned char     msg[QMI_LOC_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!operation_mode_req)
  {
    return QMI_INTERNAL_ERR;
  }


    tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
    msg_size = QMI_SRVC_PDU_SIZE(QMI_LOC_STD_MSG_SIZE);

    QMI_ERR_MSG_1("qmi_loc_set_operation_mode : operation_mode_req->status : %d",operation_mode_req->operationMode);

    
    /* Write system selection preference TLV if appropriate */
    val_ptr = (unsigned char*)&operation_mode_req->operationMode;
    tlv_length = sizeof(qmiLocStatusEnumT_v02);

    QMI_ERR_MSG_1("qmi_loc_set_operation_mode : tlv_length : %d",tlv_length);

    
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                QMI_LOC_MANDATORY_1_TLV_ID,
                                tlv_length,
                                (void *)val_ptr) < 0)
      {
        printf("qmi_loc_set_operation_mode : QMI_INTERNAL_ERR");
        return QMI_INTERNAL_ERR;
      }

  rc = qmi_service_send_msg_sync (client_handle,
                      QMI_LOC_SERVICE,
                      QMI_LOC_SET_OPERATION_MODE_REQ_V02,
                      QMI_SRVC_PDU_PTR(msg),
                     (int)QMI_SRVC_PDU_SIZE(QMI_LOC_STD_MSG_SIZE) - msg_size,
                      msg,                 
                      &msg_size,
                      QMI_LOC_STD_MSG_SIZE,
                      QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                      qmi_err_code );

  QMI_ERR_MSG_1("qmi_loc_set_operation_mode : rc : %d", rc);

  return rc;     
}


int  qmi_loc_get_operation_mode
(
  int                               client_handle,
  qmiLocGetOperationModeIndMsgT_v02             *operation_mode_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_LOC_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!operation_mode_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_LOC_STD_MSG_SIZE);


  rc = qmi_service_send_msg_sync (client_handle,
                      QMI_LOC_SERVICE,
                      QMI_LOC_GET_OPERATION_MODE_REQ_V02,
                      QMI_SRVC_PDU_PTR(msg),
                     (int)QMI_SRVC_PDU_SIZE(QMI_LOC_STD_MSG_SIZE) - msg_size,
                      msg,                 
                      &msg_size,
                      QMI_LOC_STD_MSG_SIZE,
                      QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                      qmi_err_code );

  return rc;     
}

int  qmi_loc_set_nmea_type
(
  int                               client_handle,
  qmiLocSetNmeaTypesReqMsgT_v02             *nmea_type_req, 
  int                               *qmi_err_code
)
{

  unsigned char     msg[QMI_LOC_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;

  if(!nmea_type_req)
  {
    return QMI_INTERNAL_ERR;
  }


    tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
    msg_size = QMI_SRVC_PDU_SIZE(QMI_LOC_STD_MSG_SIZE);

    /* Write system selection preference TLV if appropriate */
    val_ptr = (unsigned char*)&nmea_type_req->nmeaSentenceType;
    tlv_length = sizeof(qmiLocNmeaSentenceMaskT_v02);

    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                QMI_LOC_MANDATORY_1_TLV_ID,
                                tlv_length,
                                (void *)val_ptr) < 0)
      {
        return QMI_INTERNAL_ERR;
      }

  rc = qmi_service_send_msg_sync (client_handle,
                      QMI_LOC_SERVICE,
                      QMI_LOC_SET_NMEA_TYPES_REQ_V02,
                      QMI_SRVC_PDU_PTR(msg),
                     (int)QMI_SRVC_PDU_SIZE(QMI_LOC_STD_MSG_SIZE) - msg_size,
                      msg,                 
                      &msg_size,
                      QMI_LOC_STD_MSG_SIZE,
                      QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                      qmi_err_code );

  return rc;     
}


int  qmi_loc_get_nmea_type
(
  int                               client_handle,
  qmiLocGetNmeaTypesIndMsgT_v02             *nmea_type_rsp, 
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_LOC_STD_MSG_SIZE];
  int               msg_size, rc;

  if(!nmea_type_rsp)
  {
    return QMI_INTERNAL_ERR;
  }

  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_LOC_STD_MSG_SIZE);


  rc = qmi_service_send_msg_sync (client_handle,
                      QMI_LOC_SERVICE,
                      QMI_LOC_GET_NMEA_TYPES_REQ_V02,
                      QMI_SRVC_PDU_PTR(msg),
                     (int)QMI_SRVC_PDU_SIZE(QMI_LOC_STD_MSG_SIZE) - msg_size,
                      msg,                 
                      &msg_size,
                      QMI_LOC_STD_MSG_SIZE,
                      QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                      qmi_err_code );

  return rc;     
}

// Added Jamming detection Indication
static int qmi_loc_jamming_rf_report_ind
(
  unsigned char                                   *rx_buf,
  int                                             rx_buf_len,
  qmiLocEventJammingRFIndMsgT_v02 *t_jamming_rf_ind
)
{
  unsigned long                          type;
  unsigned long                          length;
  unsigned char                        * value_ptr;
  int32_t   temp_int_PGAGain =0;
  uint32_t  temp_uint_Bp1LbwAmplI =0;
  uint32_t  temp_uint_Bp1LbwAmplQ =0;
  uint32_t  temp_uint_Bp3GloAmplI =0;
  uint32_t  temp_uint_Bp3GloAmplQ =0;
  
  memset(t_jamming_rf_ind, 0, sizeof(t_jamming_rf_ind));

  MSG_ERROR("[GPS]qmi_loc_jamming_rfreport_ind()",0,0,0);

  /* Cycle through return message reading all TLV's */
  
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      MSG_ERROR("qmi_util_read_std_tlv() Failed!!! Return ERR",0,0,0);
      return QMI_INTERNAL_ERR;
    }

//    printf("[GPS]qmi_loc_position_report_ind() type =0x%x length =%d\n",type,length);
    /* Now process TLV */
    switch (type)
    {
      case LOC_POS_JAMMING_RF_PGAGAIN:
      {
        READ_32_BIT_VAL(value_ptr, temp_int_PGAGain); 
        t_jamming_rf_ind->l_PGAGain = temp_int_PGAGain;

        //printf("[GPS]qmi_loc_jamming_rfreport_ind() t_jamming_rf_ind->l_PGAGain  =%ld\n",t_jamming_rf_ind->l_PGAGain );
      }
      break;
      case LOC_POS_JAMMING_RF_BP1LBWAMPLII:
      {
        READ_32_BIT_VAL(value_ptr, temp_uint_Bp1LbwAmplI); 
        t_jamming_rf_ind->q_Bp1LbwAmplI = temp_uint_Bp1LbwAmplI;

        //printf("[GPS]qmi_loc_jamming_rfreport_ind() t_jamming_rf_ind->q_Bp1LbwAmplI  =%ld\n",t_jamming_rf_ind->q_Bp1LbwAmplI );
      }
      break;
      case LOC_POS_JAMMING_RF_BP1LBWAMPLIQ:
      {
        READ_32_BIT_VAL(value_ptr, temp_uint_Bp1LbwAmplQ); 
        t_jamming_rf_ind->q_Bp1LbwAmplQ = temp_uint_Bp1LbwAmplQ;

        //printf("[GPS]qmi_loc_jamming_rfreport_ind() t_jamming_rf_ind->q_Bp1LbwAmplQ  =%ld\n",t_jamming_rf_ind->q_Bp1LbwAmplQ );
      }
      break;

      case LOC_POS_JAMMING_RF_BP3LBWAMPLII:
      {
        READ_32_BIT_VAL(value_ptr, temp_uint_Bp3GloAmplI); 
        t_jamming_rf_ind->q_Bp3GloAmplI = temp_uint_Bp3GloAmplI;

        //printf("[GPS]qmi_loc_jamming_rfreport_ind() t_jamming_rf_ind->q_Bp3GloAmplI  =%ld\n",t_jamming_rf_ind->q_Bp3GloAmplI );
      }
      break;
      case LOC_POS_JAMMING_RF_BP3LBWAMPLIQ:
      {
        READ_32_BIT_VAL(value_ptr, temp_uint_Bp3GloAmplQ); 
        t_jamming_rf_ind->q_Bp3GloAmplQ = temp_uint_Bp3GloAmplQ;

        //printf("[GPS]qmi_loc_jamming_rfreport_ind() t_jamming_rf_ind->q_Bp3GloAmplQ  =%ld\n",t_jamming_rf_ind->q_Bp3GloAmplQ );
      }
      break;
      
      default:
        MSG_ERROR("Unknown Type =%d",type,0,0);
      break;
    }
  }

  return QMI_NO_ERR;

}

#if 0
int  qmi_loc_set_supl_server_info
(
  int                               client_handle,
  qmiLocSetServerReqMsgT_v02        *supl_server_req, 
  int                               *qmi_err_code
)
{

  unsigned char     msg[QMI_LOC_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;
  
  if(!supl_server_req)
  {
    return QMI_INTERNAL_ERR;
  }

  QMI_ERR_MSG_2("[GPS]qmi_loc_set_supl_server_info()client_handle =%d, serverType =%d \r\n",client_handle,supl_server_req->serverType);
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_LOC_STD_MSG_SIZE);

  /* Write system selection preference TLV if appropriate */
  val_ptr = (unsigned char*)&supl_server_req->serverType;
  tlv_length = sizeof(supl_server_req->serverType);

  QMI_ERR_MSG_3("[GPS]qmi_loc_set_supl_server_info()tlv_length =%d, uint32_t =%d, ipv4Addr_len =%d\r\n",
                tlv_length,sizeof(uint32_t),sizeof(supl_server_req->ipv4Addr));
  
  if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                              &msg_size,
                              QMI_LOC_MANDATORY_1_TLV_ID,
                              tlv_length,
                              (void *)val_ptr) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  QMI_ERR_MSG_3("[GPS]qmi_loc_set_supl_server_info()ipv4Addr_valid =%d, ipv6Addr_valid =%d, urlAddr_valid =%d \r\n",
        supl_server_req->ipv4Addr_valid,supl_server_req->ipv6Addr_valid,supl_server_req->urlAddr_valid);
  if(supl_server_req->ipv4Addr_valid)
  {
    val_ptr = (unsigned char*)&supl_server_req->ipv4Addr;
    tlv_length = sizeof(qmiLocIpV4AddrStructType_v02);

    QMI_ERR_MSG_2("[GPS]qmi_loc_set_supl_server_info()tlv_length =%d, ipv4Addr =%x \r\n",
                                                              tlv_length,supl_server_req->ipv4Addr.addr);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                QMI_LOC_OPTIONAL_1_TLV_ID,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }

  if(supl_server_req->ipv6Addr_valid)
  {
    val_ptr = (unsigned char*)&supl_server_req->ipv6Addr;
    tlv_length = sizeof(qmiLocIpV6AddrStructType_v02);

    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                QMI_LOC_OPTIONAL_2_TLV_ID,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }

  if(supl_server_req->urlAddr_valid)
  {
    val_ptr = (unsigned char*)&supl_server_req->urlAddr;
    tlv_length = strlen((char *)supl_server_req->urlAddr);

    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                QMI_LOC_OPTIONAL_3_TLV_ID,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }
  QMI_ERR_MSG_0("[GPS]qmi_loc_set_supl_server_info() Try to send a Msg to Modem!!\r\n");
  rc = qmi_service_send_msg_sync (client_handle,
                      QMI_LOC_SERVICE,
                      QMI_LOC_SET_SERVER_REQ_V02,
                      QMI_SRVC_PDU_PTR(msg),
                     (int)QMI_SRVC_PDU_SIZE(QMI_LOC_STD_MSG_SIZE) - msg_size,
                      msg,                 
                      &msg_size,
                      QMI_LOC_STD_MSG_SIZE,
                      QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                      qmi_err_code );

  return rc;     
}
#endif
int qmi_loc_set_supl_server_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  qmiLocSetServerIndMsgT_v02            *supl_server_info_req
)
{
  uint32  temp_32bit =0;
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;

  memset(supl_server_info_req, 0, sizeof(qmiLocSetServerIndMsgT_v02));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                             &rx_buf_len,
                             &type,
                             &length,
                             &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
    
    switch(type)
    {
      case QMI_LOC_MANDATORY_1_TLV_ID:
        READ_32_BIT_VAL(value_ptr, temp_32bit); 
        supl_server_info_req->status = (qmiLocStatusEnumT_v02)temp_32bit;
      break;
    }
  }
  
  return QMI_NO_ERR;
}

int  qmi_loc_get_supl_server_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  qmiLocGetServerIndMsgT_v02        *supl_server_Ind
)
{
  uint32  temp_32bit =0;
  uint16  temp_16bit =0;
  uint8   temp_8bit =0;
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  memset(supl_server_Ind, 0, sizeof(qmiLocGetServerIndMsgT_v02));

  QMI_ERR_MSG_2("[GPS]qmi_loc_get_supl_server_info() rx_buf_len =%d, rx_buf =%s\r",rx_buf_len,rx_buf);

#if 0 //Test
  {
    FILE *msg_log_fp = NULL;
    size_t ret;

//    system("rm -r /ap_conf/lgit-log/Chad_Loc_Test");
    
    if((msg_log_fp=fopen(LOG_FILE_PATH"Chad_Loc_Test", "a+")) == NULL)
    {
      if((msg_log_fp=fopen(LOG_FILE_PATH"Chad_Loc_Test", "a+")) == NULL)
      {
        chmod(LOG_FILE_PATH"Chad_Loc_Test", 0755);
      }
      else
      {
        printf("[GPS]qmi_loc_get_supl_server_info()Fail to make a file!!\r");
      }
    }
    else
    {
      chmod(LOG_FILE_PATH"Chad_Loc_Test", 0755);
    }

    printf("[GPS]qmi_loc_get_supl_server_info()Succeeded to make a file!!\r");
    
    ret = fwrite(&rx_buf, 1, rx_buf_len, msg_log_fp);

    printf("[GPS]qmi_loc_get_supl_server_info()Write to File!! ret =%d, msg_log_fp =%d\r",ret,msg_log_fp);
    
    fclose(msg_log_fp);    
  }  
#endif

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                             &rx_buf_len,
                             &type,
                             &length,
                             &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    switch(type)
    {
      case  QMI_LOC_MANDATORY_1_TLV_ID:
        READ_32_BIT_VAL(value_ptr, temp_32bit); 
        supl_server_Ind->status = (qmiLocStatusEnumT_v02)temp_32bit;
      break;
      
      case  QMI_LOC_MANDATORY_2_TLV_ID:
        QMI_ERR_MSG_1("[GPS]qmi_loc_get_supl_server_info()ServerType value_ptr =%ld\r",value_ptr);
        READ_32_BIT_VAL(value_ptr, temp_32bit); 
        supl_server_Ind->serverType = (qmiLocServerTypeEnumT_v02)temp_32bit;
        QMI_ERR_MSG_2("[GPS]qmi_loc_get_supl_server_info()ServerType %d, temp_32bit =%d\r",supl_server_Ind->serverType,temp_32bit);
      break;
      
      case QMI_LOC_OPTIONAL_1_TLV_ID:  //IPv4 Address
        supl_server_Ind->ipv4Addr_valid = TRUE;

        QMI_ERR_MSG_1("[GPS]qmi_loc_get_supl_server_info()IP value_ptr =%ld\r",value_ptr);
        READ_32_BIT_VAL(value_ptr, temp_32bit); 
        supl_server_Ind->ipv4Addr.addr = temp_32bit;

        QMI_ERR_MSG_1("[GPS]qmi_loc_get_supl_server_info()Port value_ptr =%d\r",value_ptr);
        READ_16_BIT_VAL(value_ptr, temp_16bit); 
        supl_server_Ind->ipv4Addr.port = temp_16bit;

        QMI_ERR_MSG_3("[GPS]qmi_loc_get_supl_server_info() ipv4 =%ld, temp_32bit =%ld, port =%d\r",
                                                        supl_server_Ind->ipv4Addr.addr,temp_32bit,supl_server_Ind->ipv4Addr.port);
      break;
      case QMI_LOC_OPTIONAL_2_TLV_ID:  //IPv6 Address
        supl_server_Ind->ipv6Addr_valid = TRUE;

        for(i=0; i<QMI_LOC_IPV6_ADDR_LENGTH_V02; i++)
        {
          READ_16_BIT_VAL(value_ptr, temp_16bit); 
          supl_server_Ind->ipv6Addr.addr[i] = temp_16bit;
        }

        READ_32_BIT_VAL(value_ptr, temp_32bit); 
        supl_server_Ind->ipv6Addr.port = temp_32bit;
      break;
      case QMI_LOC_OPTIONAL_3_TLV_ID: //URL Address
        supl_server_Ind->urlAddr_valid = TRUE;

        i =0;
        while((i < QMI_LOC_MAX_SERVER_ADDR_LENGTH_V02+1) && (i < length))
        {
          QMI_ERR_MSG_2 ("[GPS] QMI_LOC_OPTIONAL_3_TLV_ID 1 =%d, length =%d\n ",i,length);
          if(*value_ptr != NULL)
          {
            READ_8_BIT_VAL(value_ptr, temp_8bit); 
            supl_server_Ind->urlAddr[i] = temp_8bit;
            QMI_ERR_MSG_2 ("[GPS] QMI_LOC_OPTIONAL_3_TLV_ID 1 =%d, urlAddr =%c\n ",i,supl_server_Ind->urlAddr[i]);
          }
          else
          {
            supl_server_Ind->urlAddr[i] = NULL;

            break;
          }
          i++;
        }

        if(i == (QMI_LOC_MAX_SERVER_ADDR_LENGTH_V02+1))
        {
          supl_server_Ind->urlAddr[QMI_LOC_MAX_SERVER_ADDR_LENGTH_V02+1] = NULL;
        }
      break;
    }
 
  }
  
  return QMI_NO_ERR;
}

int qmi_loc_del_assist_data
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  qmiLocDeleteAssistDataIndMsgT_v02            *del_assist_data_req
)
{
  uint32  temp_32bit =0;
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;

  memset(del_assist_data_req, 0, sizeof(qmiLocDeleteAssistDataIndMsgT_v02));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                             &rx_buf_len,
                             &type,
                             &length,
                             &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
    
    switch(type)
    {
      case QMI_LOC_MANDATORY_1_TLV_ID:
        READ_32_BIT_VAL(value_ptr, temp_32bit); 
        del_assist_data_req->status = (qmiLocStatusEnumT_v02)temp_32bit;
      break;
    }
  }
  
  return QMI_NO_ERR;
}

int  qmi_loc_spl_server_conn_handle
(
  int                                           client_handle,
  qmiLocEventLocationServerConnectionReqIndMsgT_v02   *supl_server_conn_hdl_req, 
  int                                           *qmi_err_code
)
{

  unsigned char     msg[QMI_LOC_STD_MSG_SIZE],*tmp_msg_ptr;
  int               msg_size, rc,tlv_length = 0;  
  unsigned char     *val_ptr;
  
  if(!supl_server_conn_hdl_req)
  {
    return QMI_INTERNAL_ERR;
  }

  QMI_ERR_MSG_2("[GPS]qmi_loc_spl_server_conn_handle()client_handle =%d, serverType =%d \r\n",client_handle,supl_server_conn_hdl_req->connHandle);
  tmp_msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_LOC_STD_MSG_SIZE);

  /* Write system selection preference TLV if appropriate */
  val_ptr = (unsigned char*)&supl_server_conn_hdl_req->connHandle;
  tlv_length = sizeof(supl_server_conn_hdl_req->connHandle);

  QMI_ERR_MSG_2("[GPS]qmi_loc_spl_server_conn_handle()tlv_length =%d, connHandle =%ld\r\n",
                                                            tlv_length,supl_server_conn_hdl_req->connHandle);

  // ConnHandle
  if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                              &msg_size,
                              QMI_LOC_MANDATORY_1_TLV_ID,
                              tlv_length,
                              (void *)val_ptr) < 0)
  {
    return QMI_INTERNAL_ERR;
  }

  // requestType
  {
    val_ptr = (unsigned char*)&supl_server_conn_hdl_req->requestType;
    tlv_length = sizeof(qmiLocServerRequestEnumT_v02);

    QMI_ERR_MSG_2("[GPS]qmi_loc_spl_server_conn_handle()tlv_length =%d, requestType =%ld \r\n",
                                                              tlv_length,supl_server_conn_hdl_req->requestType);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                QMI_LOC_MANDATORY_2_TLV_ID,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }

  //wwanType
  {
    val_ptr = (unsigned char*)&supl_server_conn_hdl_req->wwanType;
    tlv_length = sizeof(qmiLocWWANTypeEnumT_v02);

    QMI_ERR_MSG_2("[GPS]qmi_loc_spl_server_conn_handle()tlv_length =%d, wwanType =%ld \r\n",
                                                              tlv_length,supl_server_conn_hdl_req->wwanType);
    if (qmi_util_write_std_tlv (&tmp_msg_ptr,
                                &msg_size,
                                QMI_LOC_MANDATORY_3_TLV_ID,
                                tlv_length,
                                (void *)val_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
  }

  QMI_ERR_MSG_0("[GPS]qmi_loc_spl_server_conn_handle() Try to send a Msg to Modem!!\r\n");
  rc = qmi_service_send_msg_sync (client_handle,
                      QMI_LOC_SERVICE,
                      QMI_LOC_INFORM_LOCATION_SERVER_CONN_STATUS_REQ_V02,
                      QMI_SRVC_PDU_PTR(msg),
                     (int)QMI_SRVC_PDU_SIZE(QMI_LOC_STD_MSG_SIZE) - msg_size,
                      msg,                 
                      &msg_size,
                      QMI_LOC_STD_MSG_SIZE,
                      QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                      qmi_err_code );

  return rc;     
}

UINT32 converter_nmea_type(UINT32 type)
{
  UINT32 locData= 0;
  
  if ( QMI_LOC_NMEA_MASK_GGA_V02 & type )
  {
    locData |= LOC_NMEA_MASK_GGA;
  }
  if ( QMI_LOC_NMEA_MASK_RMC_V02 & type )
  {
    locData |= LOC_NMEA_MASK_RMC;
  }
  if ( QMI_LOC_NMEA_MASK_GSV_V02 & type )
  {
    locData |= LOC_NMEA_MASK_GSV;
  }
  if ( QMI_LOC_NMEA_MASK_GSA_V02 & type )
  {
    locData |= LOC_NMEA_MASK_GSA;
  }
  if ( QMI_LOC_NMEA_MASK_VTG_V02 & type )
  {
    locData |= LOC_NMEA_MASK_VTG;
  }
  if ( QMI_LOC_NMEA_MASK_PQXFI_V02 & type )
  {
    locData |= LOC_NMEA_MASK_PQXFI;
  }
  if ( QMI_LOC_NMEA_MASK_GLGSV_V02 & type )
  {
    locData |= LOC_NMEA_MASK_GLGSV;
  }
  if ( QMI_LOC_NMEA_MASK_GNGSA_V02 & type )
  {
    locData |= LOC_NMEA_MASK_GNGSA;
  }
  if ( QMI_LOC_NMEA_MASK_GNGNS_V02 & type )
  {
    locData |= LOC_NMEA_MASK_GNGNS;
  }
  if ( QMI_LOC_NMEA_MASK_GARMC_V02 & type )
  {
    locData |= LOC_NMEA_MASK_GARMC;
  }
  if ( QMI_LOC_NMEA_MASK_GAGSV_V02 & type )
  {
    locData |= LOC_NMEA_MASK_GAGSV;
  }
  if ( QMI_LOC_NMEA_MASK_GAGSA_V02 & type )
  {
    locData |= LOC_NMEA_MASK_GAGSA;
  }
  if ( QMI_LOC_NMEA_MASK_GAVTG_V02 & type )
  {
    locData |= LOC_NMEA_MASK_GAVTG;
  }
  if ( QMI_LOC_NMEA_MASK_PSTIS_V02 & type )
  {
    locData |= LOC_NMEA_MASK_PSTIS;
  }
  if ( QMI_LOC_NMEA_MASK_GAGGA_V02 & type )
  {
    locData |= LOC_NMEA_MASK_GAGGA;
  }
  if ( QMI_LOC_NMEA_MASK_PQGSA_V02 & type )
  {
    locData |= LOC_NMEA_MASK_PQGSA;
  }
  if ( QMI_LOC_NMEA_MASK_PQGSV_V02 & type )
  {
    locData |= LOC_NMEA_MASK_PQGSV;
  }

  return locData;
}

static int qmi_loc_get_reg_evnet_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  qmiLocGetRegisteredEventsIndMsgT_v02            *reg_event_rsp
)
{
  uint32  temp_32bit =0;
  uint64  temp_64bit =0;
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  uint32  temp_time_hi =0;
  uint32  temp_time_low = 0;
  static int shot_one_time =0;
  
  memset(reg_event_rsp, 0, sizeof(qmiLocGetRegisteredEventsIndMsgT_v02));

#if 0 //Test
    if(shot_one_time == 0)
    {
      FILE *msg_log_fp = NULL;
      size_t ret;
  
      if((msg_log_fp=fopen(LOG_FILE_PATH"Chad_RegEVT_Test", "a+")) == NULL)
      {
        if((msg_log_fp=fopen(LOG_FILE_PATH"Chad_RegEVT_Test", "a+")) == NULL)
        {
          chmod(LOG_FILE_PATH"Chad_RegEVT_Test", 0755);
        }
        else
        {
          QMI_ERR_MSG_0("[GPS]qmi_loc_get_reg_evnet_info()Fail to make a file!!/r/n");
        }
      }
      else
      {
        chmod(LOG_FILE_PATH"Chad_RegEVT_Test", 0755);
      }
  
      QMI_ERR_MSG_0("[GPS]qmi_loc_get_reg_evnet_info()Succeeded to make a file!!/r/n");
      
      ret = fwrite(rx_buf, 1, rx_buf_len, msg_log_fp);
  
      QMI_ERR_MSG_2("[GPS]qmi_loc_get_reg_evnet_info()Write to File!! ret =%d, msg_log_fp =%d/r/n",ret,msg_log_fp);
      
      fclose(msg_log_fp);   

      shot_one_time =1;
    }  
#endif

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                             &rx_buf_len,
                             &type,
                             &length,
                             &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    switch(type)
    {
      case  QMI_LOC_MANDATORY_1_TLV_ID:
        READ_32_BIT_VAL(value_ptr, temp_32bit); 
        reg_event_rsp->status = (qmiLocStatusEnumT_v02)temp_32bit;      
        QMI_ERR_MSG_1("qmi_loc_get_reg_evnet_info() status =%ld\r\n",reg_event_rsp->status);
      break;

      case QMI_LOC_OPTIONAL_1_TLV_ID:
        reg_event_rsp->eventRegMask_valid = TRUE;

        QMI_ERR_MSG_3("qmi_loc_get_reg_evnet_info() value_ptr[0] =%x, value_ptr[1] =%x, value_ptr[2] =%x\r\n",
                                                      value_ptr[0],value_ptr[1],value_ptr[2]);
        QMI_ERR_MSG_3("qmi_loc_get_reg_evnet_info() value_ptr[4] =%x, value_ptr[5] =%x, value_ptr[6] =%x\r\n",
                                                      value_ptr[4],value_ptr[5],value_ptr[6]);
        
        READ_32_BIT_VAL(value_ptr, temp_32bit);
        temp_time_hi = temp_32bit;
        QMI_ERR_MSG_1("qmi_loc_get_reg_evnet_info() temp_time_hi =%lu\r\n",temp_time_hi);
        
        temp_32bit =0;
        READ_32_BIT_VAL(value_ptr, temp_32bit);
        temp_time_low = temp_32bit;
        QMI_ERR_MSG_1("qmi_loc_get_reg_evnet_info() temp_time_low =%lu\r\n",temp_time_low);
        
        reg_event_rsp->eventRegMask = 0;
        reg_event_rsp->eventRegMask |= temp_time_low;
        reg_event_rsp->eventRegMask = ((reg_event_rsp->eventRegMask << 32) | temp_time_hi);
        QMI_ERR_MSG_1("qmi_loc_get_reg_evnet_info() eventRegMask =%llu\r\n",reg_event_rsp->eventRegMask);
      break;
    }
  }
  
  return QMI_NO_ERR;
}


int  qmi_loc_get_gps_reg_event
(
  int                               client_handle,
  int                               *qmi_err_code
)
{
  unsigned char     msg[QMI_LOC_STD_MSG_SIZE];
  int               msg_size, rc;


  /*Prepare the Request Message*/
  msg_size = QMI_SRVC_PDU_SIZE(QMI_LOC_STD_MSG_SIZE);

  rc = qmi_service_send_msg_sync (client_handle,
                      QMI_LOC_SERVICE,
                      QMI_LOC_GET_REGISTERED_EVENTS_REQ_V02,
                      QMI_SRVC_PDU_PTR(msg),
                     (int)QMI_SRVC_PDU_SIZE(QMI_LOC_STD_MSG_SIZE) - msg_size,
                      msg,                 
                      &msg_size,
                      QMI_LOC_STD_MSG_SIZE,
                      QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                      qmi_err_code );

  return rc;     
}


int request_loc_set_operation_mode(UINT16 mode)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  qmiLocSetOperationModeReqMsgT_v02 operation_mode_req;
  qmiLocGenRespMsgT_v02   loc_resp_msg;
  int r = QMI_NO_ERR;
  
  if(loc_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  if((mode < eQMI_LOC_OPER_MODE_DEFAULT_V02) || (mode > eQMI_LOC_OPER_MODE_STANDALONE_V02))
  {
    MSG_ERROR( "[GPS] request_loc_set_operation_mode() Not Support Current mode:%d", mode, 0, 0 );

    return RESULT_FAILURE;
  }
  memset(&operation_mode_req, 0x0, sizeof(qmiLocSetOperationModeIndMsgT_v02));

  operation_mode_req.operationMode= mode;  

  QMI_ERR_MSG_0("request_loc_set_operation_mode\n");

  r = qmi_loc_msg_req( (int)loc_client_handle,
                QMI_LOC_SET_OPERATION_MODE_REQ_V02,
                (void*)&operation_mode_req,
                (void*)&loc_resp_msg,
                NULL,
                NULL );

  if ( QMI_NO_ERR != r )
  {
    MSG_ERROR( "[GPS] request_loc_set_operation_mode() fail, error:%d", r, 0, 0 );
    return;
  }

  if ( QMI_RESULT_SUCCESS_V01 != loc_resp_msg.resp.result )
  {
    MSG_ERROR( "[GPS] request_loc_set_operation_mode() rsp fail, error:%d", loc_resp_msg.resp.error, 0, 0 );
    return;
  }

  static_curr_set_val.curr_mode = mode;
  QMI_ERR_MSG_2("[GPS]request_loc_set_operation_mode() curr_mode =%d, mode =%d ended!!\n",static_curr_set_val.curr_mode,mode);
  MSG_ERROR( "Send loc start request successful",0,0,0 );

  return r;
}


int request_loc_get_operation_mode()
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  qmiLocGetOperationModeIndMsgT_v02 operation_mode_rsp;

  if(loc_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&operation_mode_rsp, 0x0, sizeof(qmiLocGetOperationModeIndMsgT_v02));
 
  rc = qmi_loc_get_operation_mode((int)loc_client_handle, &operation_mode_rsp, &qmi_err_code);
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("request_loc_get_operation_mode!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    QMI_ERR_MSG_2("[GPS]request_loc_get_operation_mode() curr_mode =%d, mode =%d ended!!\n",static_curr_set_val.curr_mode,operation_mode_rsp.operationMode);
    
    return RESULT_SUCCESS;
  }
}

int request_loc_set_nmea_type(UINT32 type)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  qmiLocSetNmeaTypesReqMsgT_v02 nmea_type_req;
  qmiLocGenRespMsgT_v02   loc_resp_msg;
  int r = QMI_NO_ERR;
  
  if(loc_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nmea_type_req, 0x0, sizeof(qmiLocSetNmeaTypesReqMsgT_v02));

  if(type >= LOC_NMEA_MASK_GGA && type <= LOC_NMEA_MASK_ALL)
  {  
    nmea_type_req.nmeaSentenceType = converter_nmea_type(type);
  }
  else
  {
    return RESULT_FAILURE;
  }

  r = qmi_loc_msg_req( (int)loc_client_handle,
                QMI_LOC_SET_NMEA_TYPES_REQ_V02,
                (void*)&nmea_type_req,
                (void*)&loc_resp_msg,
                NULL,
                NULL );

  if ( QMI_NO_ERR != r )
  {
    MSG_ERROR( "[GPS] request_loc_set_nmea_type() fail, error:%d", r, 0, 0 );
    return r;
  }

  if ( QMI_RESULT_SUCCESS_V01 != loc_resp_msg.resp.result )
  {
    MSG_ERROR( "[GPS] request_loc_set_nmea_type() rsp fail, error:%d", loc_resp_msg.resp.error, 0, 0 );
    return loc_resp_msg.resp.result;
  }

  static_curr_set_val.curr_nmeaSentenceType = type;
  QMI_ERR_MSG_2("[GPS]request_loc_set_nmea_type() curr_nmeaSentenceType =%d, type =%d ended!!\n",static_curr_set_val.curr_nmeaSentenceType,type);

  return r;
}


int request_loc_get_nmea_type()
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  qmiLocGetNmeaTypesIndMsgT_v02 nmea_type_rsp;

  if(loc_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nmea_type_rsp, 0x0, sizeof(qmiLocGetNmeaTypesIndMsgT_v02));
    
  rc = qmi_loc_get_nmea_type((int)loc_client_handle, &nmea_type_rsp, &qmi_err_code);
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("request_loc_get_nmea_type!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    QMI_ERR_MSG_2("[GPS]request_loc_get_nmea_type() curr_nmeaSentenceType =%d, nmeaSentenceType =%d ended!!\n",
                                static_curr_set_val.curr_nmeaSentenceType,nmea_type_rsp.nmeaSentenceType);
    return RESULT_SUCCESS;
  }
}

int request_loc_set_supl_server_info(tof_loc_spl_server_info_type t_supl_info)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  qmiLocSetServerReqMsgT_v02   supl_server_req;
  qmiLocGenRespMsgT_v02   loc_resp_msg;
  int r = QMI_NO_ERR;
  struct sockaddr_in addr_inet;
  
  if(loc_client_handle == INVALID_HANDLE_VALUE)
  {
    QMI_ERR_MSG_0("loc_client_handle is Invalid!!!!\r\n");
    return RESULT_FAILURE;
  }

  QMI_ERR_MSG_3("urlAddr was set urlAddr[0] =%d, urlAddr[1] =%d, urlAddr[2] =%d!!!!!!!\r\n",
                                            t_supl_info.urlAddr[0],t_supl_info.urlAddr[1],t_supl_info.urlAddr[2]);
  memset(&supl_server_req, 0x0, sizeof(qmiLocSetServerReqMsgT_v02));
  supl_server_req.ipv4Addr_valid = FALSE;
  supl_server_req.ipv6Addr_valid = FALSE;
  supl_server_req.urlAddr_valid = FALSE;
  
  supl_server_req.serverType = t_supl_info.loc_agps_supl_server_type;

//  printf("[GPS]set_supl_info() serverType =%d,port =%d, ipv4_addr =%s\r\n",
//                                  supl_server_req.serverType,t_supl_info.ipv4_port,t_supl_info.ipv4_addr);
  QMI_ERR_MSG_2("[GPS]request_loc_set_supl_server_info()Length of ipv4_addr =%d, ipv4 =%s\r\n",strlen(t_supl_info.ipv4_addr),t_supl_info.ipv4_addr);
  if(strlen(t_supl_info.ipv4_addr) != 0)
  {
    supl_server_req.ipv4Addr_valid = TRUE;
    
    if(inet_aton(t_supl_info.ipv4_addr, &addr_inet.sin_addr) == 0)
    {
      printf("Fail to Convert IP address!!\r\n");
    }
    supl_server_req.ipv4Addr.addr = addr_inet.sin_addr.s_addr;
    supl_server_req.ipv4Addr.port = t_supl_info.ipv4_port;    

    printf("[GPS]set_supl_info() addr =%x,port =%d\r\n",
                                  supl_server_req.ipv4Addr.addr,supl_server_req.ipv4Addr.port);
  }

  printf("Success to set a IPv4!!\r\n");
#if 0
  if(strlen(t_supl_info.ipv6_addr) != 0)
  {
    supl_server_req.ipv6Addr_valid = TRUE;
    memcpy((void *)supl_server_req.ipv6Addr.addr,t_supl_info.ipv6_addr,LOC_IPV6_ADDR_LENGTH);
    supl_server_req.ipv6Addr.port = t_supl_info.ipv6_port;
  }
#endif
  QMI_ERR_MSG_3("urlAddr was set urlAddr[0] =%d, urlAddr_size =%d, urlAddr =%s!!!!!!!\r\n",
                                            t_supl_info.urlAddr[0],strlen(t_supl_info.urlAddr),t_supl_info.urlAddr);

  QMI_ERR_MSG_3("urlAddr was set urlAddr[1] =%d, urlAddr[2] =%d, urlAddr[3] =%d!!!!!!!\r\n",
                                            t_supl_info.urlAddr[1],t_supl_info.urlAddr[2],t_supl_info.urlAddr[3]);
  if(strlen(t_supl_info.urlAddr) != 0)
  {
    supl_server_req.urlAddr_valid = TRUE;
    memcpy((void *)supl_server_req.urlAddr,t_supl_info.urlAddr,strlen(t_supl_info.urlAddr));

    QMI_ERR_MSG_3("urlAddr was set urlAddr_valid =%d, urlAddr_size =%d, urlAddr =%s!!!!!!!\r\n",supl_server_req.urlAddr_valid,strlen(t_supl_info.urlAddr),t_supl_info.urlAddr);
  }
  QMI_ERR_MSG_0("Success to set All Parameters!!\r\n");

  r = qmi_loc_msg_req( (int)loc_client_handle,
                QMI_LOC_SET_SERVER_REQ_V02,
                (void*)&supl_server_req,
                (void*)&loc_resp_msg,
                NULL,
                NULL );


  if ( QMI_NO_ERR != r )
  {
    MSG_ERROR( "[GPS] request_loc_set_supl_server_info() fail, error:%d\r\n", r, 0, 0 );
    return RESULT_FAILURE;
  }

  if ( QMI_RESULT_SUCCESS_V01 != loc_resp_msg.resp.result )
  {
    MSG_ERROR( "[GPS] request_loc_set_supl_server_info() rsp fail, error:%d\r", loc_resp_msg.resp.error, 0, 0 );
    return RESULT_FAILURE;
  }

  QMI_ERR_MSG_1("[GPS]request_loc_set_supl_server_info() serverType =%d!!\r\n",static_curr_set_val.curr_serverReqMsg[supl_server_req.serverType-1].serverType);

  return r;
}


int request_loc_get_supl_server_info(int server_type)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  qmiLocGetServerReqMsgT_v02   supl_server_req;
  qmiLocGenRespMsgT_v02   loc_resp_msg;
  int r = QMI_NO_ERR;
  
  if(loc_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&supl_server_req, 0x0, sizeof(qmiLocGetServerReqMsgT_v02));

  QMI_ERR_MSG_1("[GPS]ServerType =%d,",server_type);
  if((server_type < eQMI_LOC_SERVER_TYPE_CDMA_PDE_V02) ||
        (server_type > eQMI_LOC_SERVER_TYPE_CUSTOM_PDE_V02))
  {
    supl_server_req.serverType = eQMI_LOC_SERVER_TYPE_CUSTOM_PDE_V02;
  }
  else
  {
    supl_server_req.serverType = server_type;
  }

  // Server Addr Typs as default ALL
  supl_server_req.serverAddrTypeMask_valid = TRUE;
  supl_server_req.serverAddrTypeMask = 
            (QMI_LOC_SERVER_ADDR_TYPE_IPV4_MASK_V02 | QMI_LOC_SERVER_ADDR_TYPE_IPV6_MASK_V02 | QMI_LOC_SERVER_ADDR_TYPE_URL_MASK_V02);
  
  QMI_ERR_MSG_3("[GPS] request_loc_get_supl_server_info() rsp serverType =%d, serverAddrTypeMask =%x", 
                          supl_server_req.serverType, supl_server_req.serverAddrTypeMask, 0 );
  
  r = qmi_loc_msg_req( (int)loc_client_handle,
                QMI_LOC_GET_SERVER_REQ_V02,
                (void*)&supl_server_req,
                (void*)&loc_resp_msg,
                NULL,
                NULL );

  if ( QMI_NO_ERR != r )
  {
    QMI_ERR_MSG_1( "[GPS] request_loc_get_supl_server_info() fail, error:%d", r);
    return RESULT_FAILURE;
  }

  if ( QMI_RESULT_SUCCESS_V01 != loc_resp_msg.resp.result )
  {
    QMI_ERR_MSG_1( "[GPS] request_loc_get_supl_server_info() rsp fail, error:%d", loc_resp_msg.resp.error);
    return RESULT_FAILURE;
  }

  QMI_ERR_MSG_1("[GPS]request_loc_get_supl_server_info() Sucess!!\n",0);

  return r;
}

int request_loc_set_handle_server_conn(UINT8 req_type)
{
  int r = QMI_NO_ERR;

  QMI_ERR_MSG_3( "[GPS] request_loc_set_handle_server_conn() connHandle =%d, req_type =%d, wwanType =%d", 
                            static_curr_Loc_Server_Conn_Info.connHandle, req_type, static_curr_Loc_Server_Conn_Info.wwanType );

#if 0
  if(loc_time_count(LOC_TIME_WAIT_SERVER_CONN_ID) != TRUE)
  {
    QMI_ERR_MSG_0 ("[GPS] LOC_TIME_WAIT_CONN_STATUS_ID: fail to start Timer!!\n ");
  }
#endif  
  if((r = qmi_loc_set_conn_loc_server(static_curr_Loc_Server_Conn_Info.connHandle
                                 ,(qmiLocServerRequestEnumT_v02)req_type
                                 ,static_curr_Loc_Server_Conn_Info.wwanType)) != QMI_NO_ERR)
  {
    QMI_ERR_MSG_0("request_loc_set_handle_server_conn() Failed\n");

    return r;
  }

  return r;
}

int request_loc_set_delete_assist_data(boolean all_data)
{
  qmiLocDeleteAssistDataReqMsgT_v02   delete_assist_data_req;
  qmiLocGenRespMsgT_v02   delete_assist_data_resp;
  int r = QMI_NO_ERR;
  
  if(loc_client_handle == INVALID_HANDLE_VALUE)
  {
    QMI_ERR_MSG_0("loc_client_handle is Invalid!!!!\r\n");
    return RESULT_FAILURE;
  }

  memset(&delete_assist_data_req, 0x0, sizeof(qmiLocDeleteAssistDataReqMsgT_v02));
  memset(&delete_assist_data_resp, 0x0, sizeof(qmiLocGenRespMsgT_v02));
  
  if(all_data == TRUE) // Delete all Assist Data
  {
    delete_assist_data_req.deleteAllFlag = TRUE;
  }
  else // Delete only set by the option, but not used at this time.
  {
    //Do nothing for this option.
    QMI_ERR_MSG_0("[GPS]request_loc_set_delete_assist_data() Don't Support this option at this time!!!\r\n");
    return RESULT_FAILURE;
  }
  
  QMI_ERR_MSG_1("[GPS]request_loc_set_delete_assist_data() deleteAllFlag =%d\r\n",delete_assist_data_req.deleteAllFlag);

  r = qmi_loc_msg_req( (int)loc_client_handle,
                QMI_LOC_DELETE_ASSIST_DATA_REQ_V02,
                (void*)&delete_assist_data_req,
                (void*)&delete_assist_data_resp,
                NULL,
                NULL );


  if ( QMI_NO_ERR != r )
  {
    QMI_ERR_MSG_1( "[GPS] request_loc_set_delete_assist_data() fail, error:%d\r\n", r);
    return RESULT_FAILURE;
  }

  if ( QMI_RESULT_SUCCESS_V01 != delete_assist_data_resp.resp.result )
  {
    QMI_ERR_MSG_1( "[GPS] request_loc_set_delete_assist_data() rsp fail, error:%d\r", delete_assist_data_resp.resp.error);
    return RESULT_FAILURE;
  }

  QMI_ERR_MSG_0("[GPS]request_loc_set_delete_assist_data() suceeded!!\r\n");

  return r;
}

int request_loc_get_Latitude(double* lat)
{
  int r = QMI_NO_ERR;
  
  if(loc_client_handle == INVALID_HANDLE_VALUE)
  {
    QMI_ERR_MSG_0("loc_client_handle is Invalid!!!!\r\n");
    return RESULT_FAILURE;
  }

  *lat = gps_Position_report_data.latitude;
  printf("1 request_loc_get_Latitude latitude= %lf \n", *lat);
 
  return r;
}

int request_loc_get_Longitude(double* lon)
{
  int r = QMI_NO_ERR;
  
  if(loc_client_handle == INVALID_HANDLE_VALUE)
  {
    QMI_ERR_MSG_0("loc_client_handle is Invalid!!!!\r\n");
    return RESULT_FAILURE;
  }
  
  *lon = gps_Position_report_data.longitude;
  printf("request_loc_get_Longitude longitude= %lf \n", *lon);
  
  return r;
}

int request_loc_get_Altitude(float* alt)
{
  int r = QMI_NO_ERR;
  
  if(loc_client_handle == INVALID_HANDLE_VALUE)
  {
    QMI_ERR_MSG_0("loc_client_handle is Invalid!!!!\r\n");
    return RESULT_FAILURE;
  }

  *alt = gps_Position_report_data.altitudeWrtEllipsoid;
  printf("request_loc_get_Altitude altitude= %lf \n", *alt);
  
  return r;
}

int request_loc_get_Heading(float* heading)
{
  int r = QMI_NO_ERR;
  
  if(loc_client_handle == INVALID_HANDLE_VALUE)
  {
    QMI_ERR_MSG_0("loc_client_handle is Invalid!!!!\r\n");
    return RESULT_FAILURE;
  }

  *heading = gps_Position_report_data.heading;
  printf("request_loc_get_Heading heading= %f \n", *heading);
  
  return r;
}

int request_loc_get_Speed(float* speed)
{
  int r = QMI_NO_ERR;
  
  if(loc_client_handle == INVALID_HANDLE_VALUE)
  {
    QMI_ERR_MSG_0("loc_client_handle is Invalid!!!!\r\n");
    return RESULT_FAILURE;
  }

  *speed = gps_Position_report_data.speedHorizontal;
  printf("request_loc_get_Speed speed= %f \n", *speed);
  
  return r;
}

int request_loc_get_VerticalSpeed(float* vspeed)
{
  int r = QMI_NO_ERR;
  
  if(loc_client_handle == INVALID_HANDLE_VALUE)
  {
    QMI_ERR_MSG_0("loc_client_handle is Invalid!!!!\r\n");
    return RESULT_FAILURE;
  }

  *vspeed = gps_Position_report_data.speedVertical;
  printf("request_loc_get_VerticalSpeed Vspeed= %f \n", *vspeed);
  
  return r;
}

int request_loc_get_VDOP(float* vdop)
{
  int r = QMI_NO_ERR;
  
  if(loc_client_handle == INVALID_HANDLE_VALUE)
  {
    QMI_ERR_MSG_0("loc_client_handle is Invalid!!!!\r\n");
    return RESULT_FAILURE;
  }

  *vdop = gps_Position_report_data.DOP.VDOP;
  printf("request_loc_get_VDOP vdop= %f \n", *vdop);
  
  return r;
}

int request_loc_get_HDOP(float* hdop)
{
  int r = QMI_NO_ERR;
  
  if(loc_client_handle == INVALID_HANDLE_VALUE)
  {
    QMI_ERR_MSG_0("loc_client_handle is Invalid!!!!\r\n");
    return RESULT_FAILURE;
  }

  *hdop = gps_Position_report_data.DOP.HDOP;
  printf("request_loc_get_HDOP hdop= %f \n", *hdop);
  
  return r;
}

int request_loc_get_PDOP(float* pdop)
{
  int r = QMI_NO_ERR;
  
  if(loc_client_handle == INVALID_HANDLE_VALUE)
  {
    QMI_ERR_MSG_0("loc_client_handle is Invalid!!!!\r\n");
    return RESULT_FAILURE;
  }

  *pdop = gps_Position_report_data.DOP.PDOP;
  printf("request_loc_get_PDOP pdop= %f \n", *pdop);
  
  return r;
}

int request_loc_get_SpeedAccuracy(float* sacc)
{
  int r = QMI_NO_ERR;
  
  if(loc_client_handle == INVALID_HANDLE_VALUE)
  {
    QMI_ERR_MSG_0("loc_client_handle is Invalid!!!!\r\n");
    return RESULT_FAILURE;
  }

  *sacc = gps_Position_report_data.speedUnc;
  printf("request_loc_get_PDOP sacc= %f \n", *sacc);
  
  return r;
}

int request_loc_get_AltitudeMSL(float* altmsl)
{
  int r = QMI_NO_ERR;
  
  if(loc_client_handle == INVALID_HANDLE_VALUE)
  {
    QMI_ERR_MSG_0("loc_client_handle is Invalid!!!!\r\n");
    return RESULT_FAILURE;
  }

  *altmsl = gps_Position_report_data.altitudeWrtMeanSeaLevel;
  printf("request_loc_get_PDOP vdop= %f \n", *altmsl);
  
  return r;
}

int request_loc_get_HorizontalAccuracy(float* hacc)
{
  int r = QMI_NO_ERR;
  
  if(loc_client_handle == INVALID_HANDLE_VALUE)
  {
    QMI_ERR_MSG_0("loc_client_handle is Invalid!!!!\r\n");
    return RESULT_FAILURE;
  }

  *hacc = gps_Position_report_data.horUncCircular;
  printf("request_loc_get_PDOP vdop= %f \n", *hacc);
  
  return r;
}

int request_loc_get_getGnssSVInfo(tof_qmiLocEventGnssSvInfoIndMsgT_v02* svinfo)
{
  int r = QMI_NO_ERR;
  int i=0;
  
  if(loc_client_handle == INVALID_HANDLE_VALUE)
  {
    QMI_ERR_MSG_0("loc_client_handle is Invalid!!!!\r\n");
    return RESULT_FAILURE;

  }

  memcpy(svinfo, &gps_gnss_sv_info_data, sizeof(tof_qmiLocEventGnssSvInfoIndMsgT_v02));
  
  return r;
}

int request_loc_get_getPositionInfo(tof_qmiLocEventPositionReportIndMsgT_v02* poinfo)
{
  int r = QMI_NO_ERR;
  int i=0;
  
  if(loc_client_handle == INVALID_HANDLE_VALUE)
  {
    QMI_ERR_MSG_0("loc_client_handle is Invalid!!!!\r\n");
    return RESULT_FAILURE;

  }

  memcpy(poinfo, &gps_Position_report_data, sizeof(tof_qmiLocEventPositionReportIndMsgT_v02));
       
  return r;
}

int request_loc_get_reg_event(void)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;

  if(loc_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_loc_get_gps_reg_event((int)loc_client_handle, &qmi_err_code);
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    QMI_ERR_MSG_2("request_loc_get_nmea_type!! rc: %d err_code : %d", rc, qmi_err_code);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

static int qmi_loc_get_server_conn_req_ind_event
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  qmiLocEventLocationServerConnectionReqIndMsgT_v02    *loc_server_conn_ind_event_rsp
)
{
  uint32  temp_32bit =0;
  uint64  temp_64bit =0;
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;

  memset(loc_server_conn_ind_event_rsp, 0, sizeof(qmiLocEventLocationServerConnectionReqIndMsgT_v02));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                             &rx_buf_len,
                             &type,
                             &length,
                             &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    switch(type)
    {
      case  QMI_LOC_MANDATORY_1_TLV_ID:
        READ_32_BIT_VAL(value_ptr, temp_32bit); 
        loc_server_conn_ind_event_rsp->connHandle = temp_32bit;        
      break;

      case  QMI_LOC_MANDATORY_2_TLV_ID:
        READ_32_BIT_VAL(value_ptr, temp_32bit); 
        loc_server_conn_ind_event_rsp->requestType = (qmiLocServerRequestEnumT_v02)temp_32bit;        
      break;

      case  QMI_LOC_MANDATORY_3_TLV_ID:
        READ_32_BIT_VAL(value_ptr, temp_32bit); 
        loc_server_conn_ind_event_rsp->wwanType = (qmiLocWWANTypeEnumT_v02)temp_32bit;        
      break;

      default:
        QMI_ERR_MSG_1("Unknown TLV type : %d", type);
      break;
    }
  }
  
  return QMI_NO_ERR;
}

/*===========================================================================
FUNCTION       QMI_LOC_SET_CONN_LOC_SERVER

DESCRIPTION
  This function will send the QMI_LOC_INFORM_LOCATION_SERVER_CONN_STATUS_REQ_V02 command to QMI_LOC
  to open a TCP connection to SUPL server.

DEPENDENCIES 
   

RETURN VALUE 
  None

SIDE EFFECTS 
  None
===========================================================================*/
int qmi_loc_set_conn_loc_server
(
  uint32 ConnHdl,
  int32  ReqType,
  int32  WwanType
)
{
  qmi_txn_handle get_sys_txn_hdl;
  qmiLocGenRespMsgT_v02   conn_loc_server_resp_msg;
  qmiLocEventLocationServerConnectionReqIndMsgT_v02 conn_loc_server_req_msg;
  int r = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

  MSG_ERROR("qmi_loc_set_conn_loc_server()",0,0,0 );

  if(loc_service_initialized == FALSE)// || loc_service_start == FALSE)
  {
    QMI_ERR_MSG_2("GPS service is not initialized yet!! service =%d, start =%d",loc_service_initialized,loc_service_start);
    return QMI_RESULT_FAILURE_V01;
  }

  memset(&conn_loc_server_req_msg,0,sizeof(qmiLocEventLocationServerConnectionReqIndMsgT_v02));

  conn_loc_server_req_msg.connHandle= ConnHdl;
  conn_loc_server_req_msg.requestType = ReqType;  //eQMI_LOC_SERVER_REQUEST_OPEN_V02;
  conn_loc_server_req_msg.wwanType = WwanType;    //eQMI_LOC_WWAN_TYPE_AGNSS_V02;

  memset(&conn_loc_server_resp_msg,0,sizeof(qmiLocGenRespMsgT_v02));

  QMI_ERR_MSG_3 ("[GPS] qmi_loc_set_conn_loc_server() requestType =%ld, connHandle =%ld, wwanType =%ld\n ",
                    conn_loc_server_req_msg.requestType,conn_loc_server_req_msg.connHandle,conn_loc_server_req_msg.wwanType);

  r = qmi_loc_msg_req( (int)loc_client_handle,
                QMI_LOC_INFORM_LOCATION_SERVER_CONN_STATUS_REQ_V02,
                (void*)&conn_loc_server_req_msg,
                (void*)&conn_loc_server_resp_msg,
                NULL,
                NULL );

  if ( QMI_NO_ERR != r )
  {
    QMI_ERR_MSG_1( "[GPS] qmi_loc_set_conn_loc_server() fail, error:%d", r);
    return r;
  }

  if ( QMI_RESULT_SUCCESS_V01 != conn_loc_server_resp_msg.resp.result )
  {
    QMI_ERR_MSG_1( "[GPS] qmi_loc_set_conn_loc_server() rsp fail, error:%d", conn_loc_server_resp_msg.resp.error );
    return QMI_RESULT_FAILURE_V01;
  }

  //Initialize a Local variable which is used for saving a SPL server connection information When it Closed
  if(ReqType == eQMI_LOC_SERVER_REQUEST_CLOSE_V02)
  {
    memset(&static_curr_Loc_Server_Conn_Info,0,sizeof(static_curr_Loc_Server_Conn_Info));
  }
  
  QMI_ERR_MSG_0( "Connect to Loc Server request successful");

  return r;
}

/*===========================================================================
  FUNCTION  LocTimerKillSet
===========================================================================*/
/*!
@brief 
  This function is used to initialize of specific timer. 
  
@return 
  None.

@note

  - Dependencies
    - None.

  - Side Effects
    - None.
*/    
/*=========================================================================*/
void InitLocTimerDefVal(int timer_id)
{
  QMI_ERR_MSG_1("InitLocTimerDefValSTART timerID =%d\n",timer_id);

  pthread_mutex_lock(&loc_timer_thread_mutex);
  time_cnt_def[timer_id].time_cnt_act = FALSE;
  time_cnt_def[timer_id].alive_timer = FALSE;
  time_cnt_def[timer_id].time_wait_count = 0;
  pthread_mutex_unlock(&loc_timer_thread_mutex);
}

/*===========================================================================
  FUNCTION  LocKillTimerSet
===========================================================================*/
/*!
@brief 
  This function is used to cancel a specific Timer by setting up the time_count as '0'.  
  
@return 
  None.

@note

  - Dependencies
    - None.

  - Side Effects
    - None.
*/    
/*=========================================================================*/
void LocKillTimerSet(uint8 timer_id)
{
  QMI_ERR_MSG_1("LocKillTimerSet timerID =%d\n",timer_id);

  pthread_mutex_lock(&loc_timer_thread_mutex);
  time_cnt_def[timer_id].alive_timer = FALSE;
  pthread_mutex_unlock(&loc_timer_thread_mutex);
  
  QMI_ERR_MSG_1("LocKillTimerSet time_count =%d\n",time_cnt_def[timer_id].time_count);
}

/*===========================================================================
  FUNCTION  LocTimerActSet
===========================================================================*/
/*!
@brief 
  This function is used to set a specific timer which was called for doing something in the futhure.  
  
@return 
  None.

@note

  - Dependencies
    - None.

  - Side Effects
    - None.
*/    
/*=========================================================================*/
void LocTimerActSet(uint8 timer_id)
{
    pthread_mutex_lock(&loc_timer_thread_mutex);
    time_cnt_def[timer_id].time_cnt_act = TRUE;
    time_cnt_def[timer_id].alive_timer = TRUE;
    time_cnt_def[timer_id].time_wait_count = (uint32)(time(NULL) + (time_cnt_def[timer_id].time_count));
    pthread_mutex_unlock(&loc_timer_thread_mutex);

    QMI_ERR_MSG_3("LocTimerActSet : timer_id =%d, time_cnt_act =%d, time_wait_count =%d \n",
                                  timer_id,time_cnt_def[timer_id].time_cnt_act,time_cnt_def[timer_id].time_wait_count);
}

void *LocTimerThread(void* lpParam)
{
  uint8 i =0;
  uint8 t_timer_cnt =0;
  uint8 timerID = timerid_for_thread;
  
  QMI_ERR_MSG_2("LocTimerThread START timerID =%d, timerid_for_thread =%d\n",timerID,timerid_for_thread);

  // Init a Incoming TimerID
  timerid_for_thread = 0;
  
  //Set a Flag which indicate a timer activity.
  time_cnt_def[timerID].time_cnt_act = TRUE;
  time_cnt_def[timerID].alive_timer = TRUE;
  
  QMI_ERR_MSG_1("loc_timer_thread() time_cnt_act =%d\n",time_cnt_def[timerID].time_cnt_act);
  time_cnt_def[timerID].time_wait_count = (uint32)(time(NULL) + (time_cnt_def[timerID].time_count));
  QMI_ERR_MSG_2("loc_timer_thread time_wait_count =%ld, LOC_TIME_WAIT_MAX_ID =%d\n",time_cnt_def[timerID].time_wait_count,LOC_TIME_WAIT_MAX_ID);
  
  while(1)
  {
    t_timer_cnt =0;

    QMI_ERR_MSG_1("loc_timer_thread LOC_TIME_WAIT_MAX_ID =%d\n",LOC_TIME_WAIT_MAX_ID);
    for(i=0; i<LOC_TIME_WAIT_MAX_ID; i++)
    {
      QMI_ERR_MSG_3("LocTimerThread i =%d, time_cnt_id =%d, time_cnt_act =%d\n",i,time_cnt_def[i].time_cnt_id,time_cnt_def[i].time_cnt_act);
      if(time_cnt_def[i].time_cnt_act == TRUE) //No Connection Status Ind, then Stop a GPS.
      {
        t_timer_cnt++; // To check whether there are any Timer activating or not

        QMI_ERR_MSG_2("LocTimerThread START time =%ld, time_wait_count =%ld\n",time(NULL),time_cnt_def[i].time_wait_count);
        if(time(NULL) > time_cnt_def[i].time_wait_count)
        {
          QMI_ERR_MSG_2("LocTimerThread i =%d, time_cnt_id =%d\n",i,time_cnt_def[i].time_cnt_id);
          //Definition here what a Device have to do after expiring a Timer.
          switch(i)
          {
            case LOC_TIME_WAIT_CONN_STATUS_ID:
            {
              if(time_cnt_def[i].alive_timer == TRUE)
              {
                InitLocTimerDefVal(i);

                //No Connection Status Ind, then Stop a GPS.
                qmi_loc_get_position_stop();
              }
              else
              {
                InitLocTimerDefVal(i);
              }
            }
            break;
            case LOC_TIME_WAIT_TO_SEND_SRV_CONN_REQ_ID:
            {
              if(time_cnt_def[i].alive_timer == TRUE)
              {
                InitLocTimerDefVal(i);

                QMI_ERR_MSG_3("LocTimerThread connHandle =%ld, connHandle =%ld, connHandle =%ld\n",
                                                          static_curr_Loc_Server_Conn_Info.connHandle,
                                                          static_curr_Loc_Server_Conn_Info.requestType,
                                                          static_curr_Loc_Server_Conn_Info.wwanType);
              
                // Send a QMI_LOC_INFORM_LOCATION_SERVER_CONN_STATUS_REQ to open a TCP connection
                if(request_loc_set_handle_server_conn(static_curr_Loc_Server_Conn_Info.requestType) != QMI_NO_ERR)
                {
                  QMI_ERR_MSG_0 ("[GPS] qmi_loc_set_conn_loc_server(): fail\n ");
                }
              }
              else
              {
                InitLocTimerDefVal(i);
              }
                            
            }
            break;
            case LOC_TIME_WAIT_SERVER_CONN_ID:
            {
              if(time_cnt_def[i].alive_timer == TRUE)
              {
                InitLocTimerDefVal(i);

                //No Connection Status Ind, then Stop a GPS.
                qmi_loc_get_position_stop();

                // Send a QMI_LOC_INFORM_LOCATION_SERVER_CONN_STATUS_REQ to Close a TCP connection
                if(request_loc_set_handle_server_conn(eQMI_LOC_SERVER_REQUEST_CLOSE_V02) != QMI_NO_ERR)
                {
                  QMI_ERR_MSG_0 ("[GPS] qmi_loc_set_conn_loc_server(): fail\n ");
                }
              }
              else
              {
                InitLocTimerDefVal(i);
              }
              
            }
            break;
            case LOC_TIME_WAIT_SERVER_CONN_CLOSE_ID:
            {
              if(time_cnt_def[i].alive_timer == TRUE)
              {
                InitLocTimerDefVal(i);

                // Send a QMI_LOC_INFORM_LOCATION_SERVER_CONN_STATUS_REQ to Close a TCP connection
                if(request_loc_set_handle_server_conn(eQMI_LOC_SERVER_REQUEST_CLOSE_V02) != QMI_NO_ERR)
                {
                  QMI_ERR_MSG_0 ("[GPS] qmi_loc_set_conn_loc_server(): fail\n ");
                }
              }
              else
              {
                InitLocTimerDefVal(i);
              }
              
            }
            break;
            default:
              printf("loc_time_count()Unknown timeID =%d",i);
            break;
          }
        }
      }

    }

    if(t_timer_cnt == 0) // There is no activating Timer now. so Kill the Thread here!
    {
      QMI_ERR_MSG_0("loc_timer_thread Kill the Thread here since there are no Timer remaining.\n");
      break;
    }
    usleep(1000*1000); //1000ms
  }  

  loc_timer_thread = (pthread_t)NULL;
  QMI_ERR_MSG_0("loc_timer_thread END\n");
  
  pthread_exit((void *) 0); 

  return 0;
}

boolean loc_time_count(int timeID)
{
  int threadID;
  int i =0;
  
  timerid_for_thread = timeID;
  
  QMI_ERR_MSG_3("loc_time_count()start time count!! timerid_for_thread =%d, current_seconds =%ld, LOC_TIME_WAIT_MAX_ID =%d\r\n",
                                                                                          (int)timerid_for_thread,time(NULL),LOC_TIME_WAIT_MAX_ID);

  if(loc_timer_thread != (pthread_t)NULL)
  {
    //Set a Flag which indicate a timer activity.
    LocTimerActSet(timeID);
    
    printf("loc_time_count() loc_timer_thread is already exist!! loc_timer_thread: %d\r\n", (int)loc_timer_thread);
		return TRUE;
  }
  else
  {
    for(i=0; i<LOC_TIME_WAIT_MAX_ID; i++)
    {
      time_cnt_def[i].time_cnt_act = FALSE;
      time_cnt_def[i].time_wait_count = 0;
    }
  }
  
	threadID = pthread_create(&loc_timer_thread, NULL, LocTimerThread, NULL);
	if(threadID < 0)
	{
		QMI_ERR_MSG_1("Can't Create Monitor thread, threadID: %d\r\n", threadID);
		return FALSE;
	}

  return TRUE;
}

boolean loc_set_curr_gps_mode(loc_oper_mode_type gps_mode)
{
  boolean re_val = TRUE;

  if((gps_mode > LOC_OPER_MODE_WWAN) || (gps_mode < LOC_OPER_MODE_DEFAULT))
  {
    QMI_ERR_MSG_1("loc_set_curr_gps_mode : gps_mode is invalid =%d \n",gps_mode);
    return FALSE;
  }
  
  curr_gps_mode = gps_mode;

  MSG_ERROR( "loc_set_curr_gps_mode() gps_mode =%d",gps_mode,0,0 );

  return re_val;
}
