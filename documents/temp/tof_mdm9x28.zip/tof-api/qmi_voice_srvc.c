//dsji_20130204
//dsji_20130311
//dsji_20130617

/******************************************************************************
  @file    qmi_voice_srvc.c
  @brief   The QMI VOICE service layer.

  DESCRIPTION
  QMI VOICE service routines.  

  INITIALIZATION AND SEQUENCING REQUIREMENTS
  qmi_voice_srvc_init_client() needs to be called before sending or receiving of any 
  VOICE service messages

  ---------------------------------------------------------------------------
  Copyright (c) 2013 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/



#include <string.h>
#include "qmi_i.h"
#include "qmi_service.h"
#include "qmi_voice_srvc.h"
#include "voice_service_v02.h"
#include "qmi_util.h"
//#include "qmi_io.h"
#include "qmi_nas.h" // EMERGENCY_CALLBACK_MODE
#include "qmi_voice.h" //for g_voice_all_call_info (because missing qmi_io.h)


#define QMI_VOICE_MANDATORY_1_TLV_ID                      0x01
#define QMI_VOICE_MANDATORY_2_TLV_ID                      0x02
#define QMI_VOICE_MANDATORY_3_TLV_ID                      0x03
#define QMI_VOICE_MANDATORY_4_TLV_ID                      0x04
#define QMI_VOICE_MANDATORY_5_TLV_ID                      0x05
#define QMI_VOICE_OPTIONAL_1_TLV_ID                       0x10
#define QMI_VOICE_OPTIONAL_2_TLV_ID                       0x11
#define QMI_VOICE_OPTIONAL_3_TLV_ID                       0x12
#define QMI_VOICE_OPTIONAL_4_TLV_ID                       0x13
#define QMI_VOICE_OPTIONAL_5_TLV_ID                       0x14
#define QMI_VOICE_OPTIONAL_6_TLV_ID                       0x15
#define QMI_VOICE_OPTIONAL_7_TLV_ID                       0x16
#define QMI_VOICE_OPTIONAL_8_TLV_ID                       0x17
#define QMI_VOICE_OPTIONAL_9_TLV_ID                       0x18

// LGInnotek-SH.Lee-20160920, 
#define QMI_VOICE_OPTIONAL_10_TLV_ID                       0x19
#define QMI_VOICE_OPTIONAL_11_TLV_ID                       0x1A
#define QMI_VOICE_OPTIONAL_12_TLV_ID                       0x1B
#define QMI_VOICE_OPTIONAL_13_TLV_ID                       0x1C
#define QMI_VOICE_OPTIONAL_15_TLV_ID                       0x1F

TOF_CDMA_InformationRecords CDMA_InformationRecords; //RIL_UNSOL_CDMA_INFO_REC
boolean call_got_connected = FALSE; //EMERGENCY_CALLBACK_MODE

//Global Variable
static int voice_service_initialized = FALSE;

// 20140710 VoLTE Ring Back Tone Play
#ifdef FEATURE_LGIT_VOLTE_RING_BACK_TONE_PLAY
extern boolean ring_back_tone_play_enable;
#endif


//Global Variable for store phone number from call stats chg ind
int g_called_party_num_len = 0;
voice_num_with_id_type_v02 g_remote_party_number[6] ={0,}; //jaeyong1.park 2017-01-12 AS057-1103

typedef struct
{
	unsigned int voice_ind_reg_mask;
	unsigned int voice_ind_reg_val;
} voice_ind_reg_conv_table_type;

voice_ind_reg_conv_table_type	g_voice_ind_reg_conv_table[] =
{
	{ VOICE_IND_REG_MASK_DTMF,					VOICEI_IND_REG_DTMF },
	{ VOICE_IND_REG_MASK_VOICE_PRIV,			VOICEI_IND_REG_VOICE_PRIV },
	{ VOICE_IND_REG_MASK_SUPS_NOTIFY,			VOICEI_IND_REG_SUPS_NOTIFY },				
	{ VOICE_IND_REG_MASK_CALL_EVENTS_NOTIFY,	VOICEI_IND_REG_CALL_EVENTS_NOTIFY },
	{ VOICE_IND_REG_MASK_HANDOVER_NOTIFY,		VOICEI_IND_REG_HANDOVER_NOTIFY },	
	{ VOICE_IND_REG_MASK_SPEECH_NOTIFY,			VOICEI_IND_REG_SPEECH_NOTIFY },			
	{ VOICE_IND_REG_MASK_USSD_NOTIFY,			VOICEI_IND_REG_USSD_NOTIFY },
	{ VOICE_IND_REG_MASK_SUPS_OTHER_NOTIFY,		VOICEI_IND_REG_SUPS_OTHER_NOTIFY },
	{ VOICE_IND_REG_MASK_MODIFICATION_NOTIFY,	VOICEI_IND_REG_MODIFICATION_NOTIFY },
	{ VOICE_IND_REG_MASK_UUS_NOTIFY,			VOICEI_IND_REG_UUS_NOTIFY },
	{ VOICE_IND_REG_MASK_AOC_NOTIFY,			VOICEI_IND_REG_AOC_NOTIFY },
	{ VOICE_IND_REG_MASK_CONF_NOTIFY,			VOICEI_IND_REG_CONF_NOTIFY },
	{ VOICE_IND_REG_MASK_EXT_BRST_INTL_NOTIFY,	VOICEI_IND_REG_EXT_BRST_INTL_NOTIFY },
		//20161012 yjoh, add eCall ind
	{ VOICE_IND_REG_MASK_ECALL_EVENT_NOTIFY,			VOICEI_IND_REG_ECALL_EVENT_NOTIFY }
};



static int	qmi_voice_req_write_tlv( int				msg_id,
									 unsigned char**	msg,
									 int*				msg_size,
									 void*				req )
{
	unsigned char	temp_8bit;
	uint32_t temp_32bit;

	switch ( msg_id )
	{
	case QMI_VOICE_DIAL_CALL_REQ_V02:
		{
			voice_dial_call_req_msg_v02* voice_dial_call_req = (voice_dial_call_req_msg_v02*)req;

			if ( qmi_util_write_std_tlv( msg,
										 msg_size,
										 QMI_VOICE_MANDATORY_1_TLV_ID,
										 (unsigned long)strlen( voice_dial_call_req->calling_number ),
										 (void*)voice_dial_call_req->calling_number ) < 0 )
			{
				return QMI_INTERNAL_ERR;
			}

//--> VOLTE_CALL_TYPE
                  if(voice_dial_call_req->call_type_valid)
                  {
                    temp_8bit = voice_dial_call_req->call_type;
            
              			if ( qmi_util_write_std_tlv( msg,
              										 msg_size,
              										 QMI_VOICE_OPTIONAL_1_TLV_ID,
              										 sizeof( temp_8bit ),
              										 &(temp_8bit) ) < 0 )
              			{
              				return QMI_INTERNAL_ERR;
              			}
                  }
//<-- VOLTE_CALL_TYPE

			//dsji_20130620 add {
			temp_8bit = voice_dial_call_req->clir_type;

			if ( qmi_util_write_std_tlv( msg,
										 msg_size,
										 QMI_VOICE_OPTIONAL_2_TLV_ID,
										 sizeof( temp_8bit ),
										 &(temp_8bit) ) < 0 )
			{
				return QMI_INTERNAL_ERR;
			}
			//dsji_20130620 add }

// LGInnotek-SH.Lee-20160920, 
      if(voice_dial_call_req->emer_cat_valid)
      {
        temp_8bit = voice_dial_call_req->emer_cat;
      
        if ( qmi_util_write_std_tlv( msg,
                       msg_size,
                       QMI_VOICE_OPTIONAL_5_TLV_ID,
                       sizeof( temp_8bit ),
                       &(temp_8bit) ) < 0 )
        {
          MSG_ERROR( "[ECALL] qmi_voice_req_write_tlv() fail[emer_cat], error:%d", QMI_INTERNAL_ERR, 0, 0 );
          return QMI_INTERNAL_ERR;
        }
      }

    if(voice_dial_call_req->ecall_variant_valid)
    {
      temp_32bit = voice_dial_call_req->ecall_variant;
    
      if ( qmi_util_write_std_tlv( msg,
                     msg_size,
                     QMI_VOICE_OPTIONAL_13_TLV_ID,
                     sizeof( temp_32bit ),
                     &(temp_32bit) ) < 0 )
      {
        MSG_ERROR( "[ECALL] qmi_voice_req_write_tlv() fail[ecall_variant], error:%d", QMI_INTERNAL_ERR, 0, 0 );
        return QMI_INTERNAL_ERR;
      }
    }

	if(voice_dial_call_req->ecall_msd_valid)
	{
	unsigned char temp_8bit_buf[ 1024 ];

	temp_8bit_buf[ 0 ] = voice_dial_call_req->ecall_msd_len;
	memcpy( &temp_8bit_buf[ 1 ], voice_dial_call_req->ecall_msd, voice_dial_call_req->ecall_msd_len );

	if ( qmi_util_write_std_tlv( msg,
							 msg_size,
							 QMI_VOICE_OPTIONAL_15_TLV_ID,									
							 (voice_dial_call_req->ecall_msd_len  + sizeof (voice_dial_call_req->ecall_msd_len) ),
							 (void*)temp_8bit_buf ) < 0 )
	{
		return QMI_INTERNAL_ERR;
	}
	}

		}
		break;

	case QMI_VOICE_SET_CONFIG_REQ_V02:
	{
	voice_set_config_req_msg_v02* voice_set_conf_req = (voice_set_config_req_msg_v02*)req;

	if(voice_set_conf_req->ecall_msd_valid)
	{
	unsigned char temp_8bit_buf[ 1024 ];

	temp_8bit_buf[0] = voice_set_conf_req->ecall_msd_len;
	memcpy( &temp_8bit_buf[1], voice_set_conf_req->ecall_msd, voice_set_conf_req->ecall_msd_len );

	if ( qmi_util_write_std_tlv( msg,
						 msg_size,
						QMI_VOICE_OPTIONAL_8_TLV_ID,
						 (voice_set_conf_req->ecall_msd_len  + sizeof (voice_set_conf_req->ecall_msd_len)),
						 (void*)temp_8bit_buf ) < 0 )
		{
        MSG_ERROR( "[ECALL] qmi_voice_req_write_tlv() fail, error:%d", QMI_INTERNAL_ERR, 0, 0 );

		return QMI_INTERNAL_ERR;
		}
	}
	}
		break;
		
	case QMI_VOICE_ECALL_SET_MSD_V02:
	{
	voice_set_ecall_msd_req_msg_v02* voice_set_ecall_msd = (voice_set_ecall_msd_req_msg_v02*)req;

//	if(voice_set_ecall_msd->ecall_tx_mode_valid)
	{
	temp_8bit =voice_set_ecall_msd->ecall_tx_mode;

	if ( qmi_util_write_std_tlv( msg,
						 msg_size,
						QMI_VOICE_OPTIONAL_1_TLV_ID,
                       sizeof( temp_8bit ),
                       &(temp_8bit) ) < 0 )
		{
        MSG_ERROR( "[ECALL] qmi_voice_req_write_tlv() fail, error:%d", QMI_INTERNAL_ERR, 0, 0 );

		return QMI_INTERNAL_ERR;
		}
		}
	
	if(voice_set_ecall_msd->ecall_msd_valid)
	{
	unsigned char temp_8bit_buf[ 1024 ];

	temp_8bit_buf[0] = voice_set_ecall_msd->ecall_msd_len;
	memcpy( &temp_8bit_buf[1], voice_set_ecall_msd->ecall_msd, voice_set_ecall_msd->ecall_msd_len );

	if ( qmi_util_write_std_tlv( msg,
						 msg_size,
						QMI_VOICE_OPTIONAL_2_TLV_ID,
						 (voice_set_ecall_msd->ecall_msd_len  + sizeof (voice_set_ecall_msd->ecall_msd_len)),
						 (void*)temp_8bit_buf ) < 0 )
		{
        MSG_ERROR( "[ECALL] qmi_voice_req_write_tlv() fail, error:%d", QMI_INTERNAL_ERR, 0, 0 );

		return QMI_INTERNAL_ERR;
		}
		}
	}
	break;
	
	case QMI_VOICE_END_CALL_REQ_V02:
		{
			voice_end_call_req_msg_v02* voice_end_call_req = (voice_end_call_req_msg_v02*)req;

			if ( qmi_util_write_std_tlv( msg,
										 msg_size,
										 QMI_VOICE_MANDATORY_1_TLV_ID,
										 sizeof( voice_end_call_req->call_id ),
										 &(voice_end_call_req->call_id) ) < 0 )
			{
				return QMI_INTERNAL_ERR;
			}
		}
		break;

	case QMI_VOICE_ANSWER_CALL_REQ_V02:
		{
			voice_answer_call_req_msg_v02* voice_answer_call_req = (voice_answer_call_req_msg_v02*)req;

			temp_8bit = voice_answer_call_req->call_id;

			if ( qmi_util_write_std_tlv( msg,
										 msg_size,
										 QMI_VOICE_MANDATORY_1_TLV_ID,
										 sizeof( temp_8bit ),
										 &(temp_8bit) ) < 0 )
			{
				return QMI_INTERNAL_ERR;
			}
		}
		break;

	case QMI_VOICE_MANAGE_CALLS_REQ_V02:
		{
			voice_manage_calls_req_msg_v02* voice_manage_calls_req = (voice_manage_calls_req_msg_v02*)req;

			temp_8bit = voice_manage_calls_req->sups_type;

			if ( qmi_util_write_std_tlv( msg,
										 msg_size,
										 QMI_VOICE_MANDATORY_1_TLV_ID,
										 sizeof( temp_8bit ),
										 &(temp_8bit) ) < 0 )
			{
				return QMI_INTERNAL_ERR;
			}
		}
		break;

	case QMI_VOICE_GET_ALL_CALL_INFO_REQ_V02:
		{
		}
		break;

	case QMI_VOICE_START_CONT_DTMF_REQ_V02:
		{
			voice_start_cont_dtmf_req_msg_v02* voice_start_cont_dtmf_req = (voice_start_cont_dtmf_req_msg_v02*)req;

			if ( qmi_util_write_std_tlv( msg,
										 msg_size,
										 QMI_VOICE_MANDATORY_1_TLV_ID,
										 sizeof( voice_start_cont_dtmf_req->cont_dtmf_info ),
										 &(voice_start_cont_dtmf_req->cont_dtmf_info) ) < 0 )
			{
				return QMI_INTERNAL_ERR;
			}
		}
		break;

	case QMI_VOICE_STOP_CONT_DTMF_REQ_V02:
		{
			voice_stop_cont_dtmf_req_msg_v02* voice_stop_cont_dtmf_req = (voice_stop_cont_dtmf_req_msg_v02*)req;

			if ( qmi_util_write_std_tlv( msg,
										 msg_size,
										 QMI_VOICE_MANDATORY_1_TLV_ID,
										 sizeof( voice_stop_cont_dtmf_req->call_id ),
										 &(voice_stop_cont_dtmf_req->call_id) ) < 0 )
			{
				return QMI_INTERNAL_ERR;
			}
		}
		break;

//BKS_20131119 - start
       case QMI_VOICE_BURST_DTMF_REQ_V02:
            {
               voice_burst_dtmf_req_msg_v02* voice_burst_dtmf_req = (voice_burst_dtmf_req_msg_v02*)req;
                unsigned char temp_8bit_array[ 2 ] = {0,};

		   if ( qmi_util_write_std_tlv( msg,
										 msg_size,
										 QMI_VOICE_MANDATORY_1_TLV_ID,
										 sizeof( voice_burst_dtmf_req->burst_dtmf_info),
										 &(voice_burst_dtmf_req->burst_dtmf_info) ) < 0 )
			{
				return QMI_INTERNAL_ERR;
			} 	
//BKS_20131121- start
               if(voice_burst_dtmf_req->dtmf_lengths_valid == TRUE)
               {
			temp_8bit_array[ 0 ] = voice_burst_dtmf_req->dtmf_lengths.dtmf_onlength;
			temp_8bit_array[ 1 ] = voice_burst_dtmf_req->dtmf_lengths.dtmf_offlength;

			
                  if ( qmi_util_write_std_tlv( msg,
											 msg_size,
											 QMI_VOICE_OPTIONAL_1_TLV_ID,
											 sizeof( temp_8bit_array ),
											 temp_8bit_array ) < 0 )
                  {
			  return QMI_INTERNAL_ERR;
			}
               }
//BKS_20131121 - end
       	}
		break;
//BKS_20131119 - end
	case QMI_VOICE_GET_CLIR_REQ_V02:
		{
		}
		break;

	case QMI_VOICE_SET_SUPS_SERVICE_REQ_V02:
		{
			unsigned char temp_8bit_array[ 2 ];

			voice_set_sups_service_req_msg_v02* voice_set_sups_service_req = (voice_set_sups_service_req_msg_v02*)req;

			temp_8bit_array[ 0 ] = voice_set_sups_service_req->supplementary_service_info.voice_service;
			temp_8bit_array[ 1 ] = voice_set_sups_service_req->supplementary_service_info.reason;

			if ( qmi_util_write_std_tlv( msg,
										 msg_size,
										 QMI_VOICE_MANDATORY_1_TLV_ID,
										 sizeof( temp_8bit_array ),
										 temp_8bit_array ) < 0 )
			{
				return QMI_INTERNAL_ERR;
			}

			if ( TRUE == voice_set_sups_service_req->service_class_valid )
			{
				if ( qmi_util_write_std_tlv( msg,
											 msg_size,
											 QMI_VOICE_OPTIONAL_1_TLV_ID,
											 sizeof( voice_set_sups_service_req->service_class ),
											 &(voice_set_sups_service_req->service_class) ) < 0 )
				{
					return QMI_INTERNAL_ERR;
				}
			}

			if ( TRUE == voice_set_sups_service_req->number_valid )
			{
				if ( qmi_util_write_std_tlv( msg,
											 msg_size,
											 QMI_VOICE_OPTIONAL_3_TLV_ID,
											 strlen( voice_set_sups_service_req->number ),
											 voice_set_sups_service_req->number ) < 0 )
				{
					return QMI_INTERNAL_ERR;
				}
			}

			if ( TRUE == voice_set_sups_service_req->timer_value_valid )
			{
				if ( qmi_util_write_std_tlv( msg,
											 msg_size,
											 QMI_VOICE_OPTIONAL_4_TLV_ID,
											 sizeof( voice_set_sups_service_req->timer_value ),
											 &(voice_set_sups_service_req->timer_value) ) < 0 )
				{
					return QMI_INTERNAL_ERR;
				}
			}

			if ( TRUE == voice_set_sups_service_req->num_type_plan_valid )
			{
				temp_8bit_array[ 0 ] = voice_set_sups_service_req->num_type_plan.num_type;
				temp_8bit_array[ 1 ] = voice_set_sups_service_req->num_type_plan.num_plan;

				if ( qmi_util_write_std_tlv( msg,
											 msg_size,
											 QMI_VOICE_OPTIONAL_5_TLV_ID,
											 sizeof( temp_8bit_array ),
											 temp_8bit_array ) < 0 )
				{
					return QMI_INTERNAL_ERR;
				}
			}
		}
		break;

	case QMI_VOICE_GET_CALL_WAITING_REQ_V02:
		{
			voice_get_call_waiting_req_msg_v02* voice_get_call_waiting_req = (voice_get_call_waiting_req_msg_v02*)req;

			if ( TRUE == voice_get_call_waiting_req->service_class_valid )
			{
				if ( qmi_util_write_std_tlv( msg,
											 msg_size,
											 QMI_VOICE_OPTIONAL_1_TLV_ID,
											 sizeof( voice_get_call_waiting_req->service_class ),
											 &(voice_get_call_waiting_req->service_class) ) < 0 )
				{
					return QMI_INTERNAL_ERR;
				}
			}
		}
		break;

	case QMI_VOICE_GET_CALL_FORWARDING_REQ_V02:
		{
			voice_get_call_forwarding_req_msg_v02* voice_get_call_forwarding_req = (voice_get_call_forwarding_req_msg_v02*)req;

			temp_8bit = voice_get_call_forwarding_req->reason;

			if ( qmi_util_write_std_tlv( msg,
										 msg_size,
										 QMI_VOICE_MANDATORY_1_TLV_ID,
										 sizeof( temp_8bit ),
										 &(temp_8bit) ) < 0 )
			{
				return QMI_INTERNAL_ERR;
			}

			if ( TRUE == voice_get_call_forwarding_req->service_class_valid )
			{
				if ( qmi_util_write_std_tlv( msg,
											 msg_size,
											 QMI_VOICE_OPTIONAL_1_TLV_ID,
											 sizeof( voice_get_call_forwarding_req->service_class ),
											 &(voice_get_call_forwarding_req->service_class) ) < 0 )
				{
					return QMI_INTERNAL_ERR;
				}
			}
		}
		break;

	case QMI_VOICE_GET_CLIP_REQ_V02:
		{
		}
		break;

	case QMI_VOICE_GET_COLP_REQ_V02:
		{
		}
		break;

	case QMI_VOICE_GET_COLR_REQ_V02:
		{
		}
		break;
#if 0	//dsji_20130620 disable
	case QMI_VOICE_SET_CLIR_REQ:
		{
			voice_set_clir_req_msg* voice_set_clir_req = (voice_set_clir_req_msg*)req;

			temp_32bit = voice_set_clir_req->n;

			if ( qmi_util_write_std_tlv( msg,
										 msg_size,
										 QMI_VOICE_MANDATORY_1_TLV_ID,
										 sizeof( temp_32bit ),
										 &(temp_32bit) ) < 0 )
			{
				return QMI_INTERNAL_ERR;
			}
		}
		break;

	case QMI_VOICE_SET_CLIP_REQ:
		{
			voice_set_clip_req_msg* voice_set_clip_req = (voice_set_clip_req_msg*)req;

			temp_32bit = voice_set_clip_req->n;

			if ( qmi_util_write_std_tlv( msg,
										 msg_size,
										 QMI_VOICE_MANDATORY_1_TLV_ID,
										 sizeof( temp_32bit ),
										 &(temp_32bit) ) < 0 )
			{
				return QMI_INTERNAL_ERR;
			}
		}
		break;

	case QMI_VOICE_SET_COLP_REQ:
		{
			voice_set_colp_req_msg* voice_set_colp_req = (voice_set_colp_req_msg*)req;

			temp_32bit = voice_set_colp_req->n;

			if ( qmi_util_write_std_tlv( msg,
										 msg_size,
										 QMI_VOICE_MANDATORY_1_TLV_ID,
										 sizeof( temp_32bit ),
										 &(temp_32bit) ) < 0 )
			{
				return QMI_INTERNAL_ERR;
			}
		}
		break;
#endif		
		//dsji_20130702 add {
	case QMI_VOICE_ORIG_USSD_REQ_V02:
		{
			unsigned char temp_8bit_buf[ 1024 ];

			voice_orig_ussd_req_msg_v02* voice_orig_ussd_req = (voice_orig_ussd_req_msg_v02*)req;

			temp_8bit_buf[ 0 ] = voice_orig_ussd_req->uss_info.uss_dcs;
			temp_8bit_buf[ 1 ] = voice_orig_ussd_req->uss_info.uss_data_len;
			memcpy( &temp_8bit_buf[ 2 ], voice_orig_ussd_req->uss_info.uss_data, voice_orig_ussd_req->uss_info.uss_data_len );

			if ( qmi_util_write_std_tlv( msg,
										 msg_size,
										 QMI_VOICE_MANDATORY_1_TLV_ID,
										 ( voice_orig_ussd_req->uss_info.uss_data_len + 2 ),
										 (void*)temp_8bit_buf ) < 0 )
			{
				return QMI_INTERNAL_ERR;
			}
		}
		break;

	case QMI_VOICE_ANSWER_USSD_REQ_V02:
		{
		}
		break;
		//dsji_20130702 add }

    case QMI_VOICE_GET_CONFIG_REQ_V02:
		{
			voice_get_config_req_msg_v02* voice_get_config_req = (voice_get_config_req_msg_v02*)req;

      //--> RIL_REQUEST_CDMA_QUERY_PREFERRED_VOICE_PRIVACY_MODE
      if( TRUE == voice_get_config_req->voice_privacy_valid)
      {
        if ( qmi_util_write_std_tlv( msg,
                                     msg_size,
                                     QMI_VOICE_OPTIONAL_7_TLV_ID,
                                     sizeof( voice_get_config_req->voice_privacy),
                                     &(voice_get_config_req->voice_privacy) ) < 0 )
        {
          return QMI_INTERNAL_ERR;
        }
      }
      //<-- RIL_REQUEST_CDMA_QUERY_PREFERRED_VOICE_PRIVACY_MODE
		}
		break;

    //--> RIL_REQUEST_CDMA_SET_PREFERRED_VOICE_PRIVACY_MODE
    case QMI_VOICE_SET_PREFERRED_PRIVACY_REQ_V02:
    {
      voice_set_preferred_privacy_req_msg_v02* set_preferred_privacy_req = (voice_set_preferred_privacy_req_msg_v02 *)req;

      temp_8bit = set_preferred_privacy_req->privacy_pref;

      if ( qmi_util_write_std_tlv( msg,
                                   msg_size,
                                   QMI_VOICE_MANDATORY_1_TLV_ID,
                                   sizeof( temp_8bit ),
                                   &(temp_8bit) ) < 0 )
      {
        return QMI_INTERNAL_ERR;
      }
    }
    break;
    //<-- RIL_REQUEST_CDMA_SET_PREFERRED_VOICE_PRIVACY_MODE
	}

	return QMI_NO_ERR;
}



static int	qmi_voice_rsp_read_tlv( int             qmi_err_code,
                                    int             msg_id,
                                    unsigned char*  msg,
                                    int             msg_size,
                                    void*           rsp )
{
  int i;

  unsigned long type;
  unsigned long length;
  unsigned char *value;

  unsigned char	temp_8bit;
  unsigned short	temp_16bit;
  //unsigned int	temp_32bit;
  unsigned char	temp_var[ 1024 ];

  qmi_response_type_v01* qmi_rsp = (qmi_response_type_v01*)rsp;

  if ( QMI_SERVICE_ERR_NONE == qmi_err_code )
  {
    qmi_rsp->result = (qmi_result_type_v01)QMI_RESULT_SUCCESS_V01;
  }
  else
  {
    qmi_rsp->error	= (qmi_error_type_v01)qmi_err_code;
    qmi_rsp->result = (qmi_result_type_v01)QMI_RESULT_FAILURE_V01;

    return QMI_SERVICE_ERR;
  }

  while ( msg_size > 0 )
  {
    if ( qmi_util_read_std_tlv( &msg,
                                &msg_size,
                                &type,
                                &length,
                                &value ) < 0 )
    {
      return QMI_INTERNAL_ERR;
    }

    switch( msg_id )
    {
      case QMI_VOICE_DIAL_CALL_REQ_V02:
      {
        voice_dial_call_resp_msg_v02* voice_dial_call_rsp = (voice_dial_call_resp_msg_v02*)rsp;

        switch ( type )
        {
          case VOICEI_DIAL_CALL_ID:
          {
            READ_8_BIT_VAL( value, temp_8bit );		voice_dial_call_rsp->call_id = temp_8bit;
            voice_dial_call_rsp->call_id_valid = TRUE;
          }
          break;

          case VOICEI_DIAL_ALPHA_ID:
          {
            READ_8_BIT_VAL( value, temp_8bit );		voice_dial_call_rsp->alpha_ident.alpha_dcs = (alpha_dcs_enum_v02)temp_8bit;
            READ_8_BIT_VAL( value, temp_8bit );		voice_dial_call_rsp->alpha_ident.alpha_text_len = temp_8bit;
            READ_VAR_BIT_VAL( value, temp_var[ 0 ], voice_dial_call_rsp->alpha_ident.alpha_text_len );
            memcpy( voice_dial_call_rsp->alpha_ident.alpha_text, temp_var, voice_dial_call_rsp->alpha_ident.alpha_text_len );
            voice_dial_call_rsp->alpha_ident_valid = TRUE;
          }
          break;

          case VOICEI_DIAL_CC_RESULT_TYPE:
          {
            READ_8_BIT_VAL( value, temp_8bit );		voice_dial_call_rsp->cc_result_type = (voice_cc_result_type_enum_v02)temp_8bit;
            voice_dial_call_rsp->cc_result_type_valid = TRUE;
          }
          break;

          case VOICEI_DIAL_CC_RESULT_SUPS:
          {
            READ_8_BIT_VAL( value, temp_8bit );		voice_dial_call_rsp->cc_sups_result.service_type = (voice_cc_sups_result_service_type_enum_v02)temp_8bit;
            READ_8_BIT_VAL( value, temp_8bit );		voice_dial_call_rsp->cc_sups_result.reason = (voice_cc_sups_result_reason_enum_v02)temp_8bit;
            voice_dial_call_rsp->cc_sups_result_valid = TRUE;
          }
          break;

          case VOICEI_DIAL_RESP_END_REASON:
          {
            READ_16_BIT_VAL( value, temp_16bit );	voice_dial_call_rsp->end_reason = (call_end_reason_enum_v02)temp_16bit;
            voice_dial_call_rsp->end_reason_valid = TRUE;
          }
          break;
        }
      }
      break;

      case QMI_VOICE_END_CALL_REQ_V02:
      {
        voice_end_call_resp_msg_v02* voice_end_call_rsp = (voice_end_call_resp_msg_v02*)rsp;

        switch ( type )
        {
          case VOICEI_END_CALL_ID:
          {
            READ_8_BIT_VAL( value, temp_8bit ); voice_end_call_rsp->call_id = temp_8bit;
          }
          break;
        }
      }
      break;

      case QMI_VOICE_ANSWER_CALL_REQ_V02:
      {
        voice_answer_call_resp_msg_v02* voice_answer_call_rsp = (voice_answer_call_resp_msg_v02*)rsp;

        switch ( type )
        {
          case VOICEI_ANSWER_CALL_ID:
          {
            READ_8_BIT_VAL( value, temp_8bit ); voice_answer_call_rsp->call_id = temp_8bit;
          }
          break;
        }
      }
      break;

      case QMI_VOICE_MANAGE_CALLS_REQ_V02:
      {
        voice_manage_calls_resp_msg_v02* voice_manage_calls_rsp = (voice_manage_calls_resp_msg_v02*)rsp;

        switch ( type )
        {
          case VOICEI_MNG_CALLS_FAILURE_CAUSE:
          {
            READ_8_BIT_VAL( value, temp_16bit ); voice_manage_calls_rsp->failure_cause = (qmi_sups_errors_enum_v02)temp_16bit;
            voice_manage_calls_rsp->failure_cause_valid = TRUE;
          }
          break;
        }
      }
      break;

      case QMI_VOICE_GET_ALL_CALL_INFO_REQ_V02:
      {
        voice_get_all_call_info_resp_msg_v02* voice_get_all_call_info_rsp = (voice_get_all_call_info_resp_msg_v02*) rsp;

        switch ( type )
        {
          case VOICEI_GET_ALL_CALL_INFO:
          {
            READ_8_BIT_VAL( value, temp_8bit );			voice_get_all_call_info_rsp->call_info_len = temp_8bit;

            for ( i = 0; i < voice_get_all_call_info_rsp->call_info_len; ++i )
            {
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->call_info[ i ].call_id		= temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->call_info[ i ].call_state	= (call_state_enum_v02)temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->call_info[ i ].call_type	= (call_type_enum_v02)temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->call_info[ i ].direction	= (call_direction_enum_v02)temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->call_info[ i ].mode		= (call_mode_enum_v02)temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->call_info[ i ].is_mpty		= temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->call_info[ i ].als			= (als_enum_v02)temp_8bit;
            }
          }
          break;

          case VOICEI_GET_ALL_CALL_RP_NUM:
          {
            READ_8_BIT_VAL( value, temp_8bit );			voice_get_all_call_info_rsp->remote_party_number_len = temp_8bit;

            for ( i = 0; i < voice_get_all_call_info_rsp->remote_party_number_len; ++i )
            {
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->remote_party_number[ i ].call_id		= temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->remote_party_number[ i ].number_pi		= (pi_num_enum_v02)temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->remote_party_number[ i ].number_len	= temp_8bit;
              READ_VAR_BIT_VAL( value, temp_var[ 0 ], voice_get_all_call_info_rsp->remote_party_number[ i ].number_len );
              memcpy( voice_get_all_call_info_rsp->remote_party_number[ i ].number, temp_var, voice_get_all_call_info_rsp->remote_party_number[ i ].number_len );
              voice_get_all_call_info_rsp->remote_party_number_valid = TRUE;
            }
          }
          break;

          //dsji_20130702 add {
          case VOICEI_GET_ALL_CALL_RP_NAME:
          {
            READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->remote_party_name_len = temp_8bit;

            for ( i = 0; i < voice_get_all_call_info_rsp->remote_party_name_len; ++i )
            {
              voice_get_all_call_info_rsp->remote_party_name_valid = TRUE;
              READ_8_BIT_VAL( value, temp_8bit ); voice_get_all_call_info_rsp->remote_party_name[ i ].call_id 			= temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->remote_party_name[ i ].name_pi 		= (pi_name_enum_v02)temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->remote_party_name[ i ].coding_scheme	= temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->remote_party_name[ i ].name_len		= temp_8bit;
              READ_VAR_BIT_VAL( value, temp_var[ 0 ], voice_get_all_call_info_rsp->remote_party_name[ i ].name_len );
              memcpy( voice_get_all_call_info_rsp->remote_party_name[ i ].name, temp_var, voice_get_all_call_info_rsp->remote_party_name[ i ].name_len );
            }	
          }
          break;

/* Indication���� �ö�� ���� ����ϵ��� �����Ͽ� �ּ� ó�� ��
          case VOICEI_GET_ALL_CALL_ALERTING:
          { 
            READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->alerting_type_len = temp_8bit;

            for ( i = 0; i < voice_get_all_call_info_rsp->alerting_type_len; ++i )
            {
              READ_8_BIT_VAL( value, temp_8bit ); voice_get_all_call_info_rsp->alerting_type[ i ].call_id       = temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit ); voice_get_all_call_info_rsp->alerting_type[ i ].alerting_type = (alerting_type_enum_v02) temp_8bit;

              MSG_HIGH("[VOICE] call_id = %d alerting_type = %d", voice_get_all_call_info_rsp->alerting_type[ i ].call_id, 
                                                                  voice_get_all_call_info_rsp->alerting_type[ i ].alerting_type, 0);
            }
          }
          break;
*/
          case VOICEI_GET_ALL_CALL_UUS_INFO:
          {
            READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->uus_info_len = temp_8bit;
            for ( i = 0; i < voice_get_all_call_info_rsp->uus_info_len; ++i )
            {
              voice_get_all_call_info_rsp->uus_info_valid = TRUE;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->uus_info[ i ].call_id			= temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->uus_info[ i ].uus_type			= (uus_type_enum_v02)temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->uus_info[ i ].uus_dcs			= (uus_dcs_enum_v02)temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->uus_info[ i ].uus_data_len		= temp_8bit;
              READ_VAR_BIT_VAL( value, temp_var[ 0 ], voice_get_all_call_info_rsp->uus_info[ i ].uus_data_len );
              memcpy( voice_get_all_call_info_rsp->uus_info[ i ].uus_data, temp_var, voice_get_all_call_info_rsp->uus_info[ i ].uus_data_len );
            }		  	
          }
          break;

          case VOICEI_GET_ALL_CALL_SO:
          case VOICEI_GET_ALL_CALL_OTASP:
          break;

          case VOICEI_GET_ALL_CALL_VP:
          {
            READ_8_BIT_VAL( value, temp_8bit ); voice_get_all_call_info_rsp->voice_privacy = (voice_privacy_enum_v02)temp_8bit;
          }
          break;

          case VOICEI_GET_ALL_CALL_END_REASON:
          {
            READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->call_end_reason_len = temp_8bit;
            for ( i = 0; i < voice_get_all_call_info_rsp->call_end_reason_len; ++i )
            {
              voice_get_all_call_info_rsp->call_end_reason_valid = TRUE;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->call_end_reason[i].call_id = temp_8bit;
              READ_16_BIT_VAL( value, temp_16bit );	voice_get_all_call_info_rsp->call_end_reason[i].call_end_reason = (call_end_reason_enum_v02) temp_16bit;
            }		  	
          }
          break;

          case VOICEI_GET_ALL_CALL_ALPHA:
          break;

          case VOICEI_GET_ALL_CALL_CONNECTED_NUM:
          {
            READ_8_BIT_VAL( value, temp_8bit ); voice_get_all_call_info_rsp->conn_party_num_len = temp_8bit;
            for ( i = 0; i < voice_get_all_call_info_rsp->conn_party_num_len; ++i )
            {
              voice_get_all_call_info_rsp->conn_party_num_valid = TRUE;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->conn_party_num[ i ].call_id		= temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->conn_party_num[ i ].conn_num_pi	= (pi_num_enum_v02)temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->conn_party_num[ i ].conn_num_si	= (voice_si_enum_v02)temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->conn_party_num[ i ].conn_num_type 	= (voice_num_type_enum_v02)temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->conn_party_num[ i ].conn_num_plan 	= (voice_num_plan_enum_v02)temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->conn_party_num[ i ].conn_num_len	= temp_8bit;
              READ_VAR_BIT_VAL( value, temp_var[ 0 ], voice_get_all_call_info_rsp->conn_party_num[ i ].conn_num_len );
              memcpy( voice_get_all_call_info_rsp->conn_party_num[ i ].conn_num, temp_var, voice_get_all_call_info_rsp->conn_party_num[ i ].conn_num_len );
            }
          }
          break;

          case VOICEI_GET_ALL_CALL_DIAGNOSTICS:
          break;

          case VOICEI_GET_ALL_CALL_CALLED_PARTY_NUM:
          {
            READ_8_BIT_VAL( value, temp_8bit ); voice_get_all_call_info_rsp->called_party_num_len = temp_8bit;
            for ( i = 0; i < voice_get_all_call_info_rsp->called_party_num_len; ++i )
            {
              voice_get_all_call_info_rsp->called_party_num_valid = TRUE;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->called_party_num[ i ].call_id	= temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->called_party_num[ i ].num_pi	= (pi_num_enum_v02)temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->called_party_num[ i ].num_si	= (voice_si_enum_v02)temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->called_party_num[ i ].num_type = (voice_num_type_enum_v02)temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->called_party_num[ i ].num_plan = (voice_num_plan_enum_v02)temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_all_call_info_rsp->called_party_num[ i ].num_len	= temp_8bit;
              READ_VAR_BIT_VAL( value, temp_var[ 0 ], voice_get_all_call_info_rsp->called_party_num[ i ].num_len );
              memcpy( voice_get_all_call_info_rsp->called_party_num[ i ].num, temp_var, voice_get_all_call_info_rsp->called_party_num[ i ].num_len );
            }
          }
          break;

          case VOICEI_GET_ALL_CALL_REDIRECTING_PARTY_NUM:
          case VOICEI_GET_ALL_CALL_ALERTING_PATTERN:
          case VOICEI_GET_ALL_CALL_AUDIO_ATTRIBUTE:
          case VOICEI_GET_ALL_CALL_VIDEO_ATTRIBUTE:
          break;
        }
      }
      break;

      case QMI_VOICE_START_CONT_DTMF_REQ_V02:
      {
      }
      break;

      case QMI_VOICE_STOP_CONT_DTMF_REQ_V02:
      {
      }
      break;

      case QMI_VOICE_GET_CLIR_REQ_V02:
      {
        voice_get_clir_resp_msg_v02* voice_get_clir_rsp = (voice_get_clir_resp_msg_v02*)rsp;

        switch ( type )
        {
          case VOICEI_GET_CLIR_RESP:
          {
            READ_8_BIT_VAL( value, temp_8bit );		voice_get_clir_rsp->clir_response.active_status = (active_status_enum_v02)temp_8bit;
            READ_8_BIT_VAL( value, temp_8bit );		voice_get_clir_rsp->clir_response.provision_status = (provision_status_enum_v02)temp_8bit;
            voice_get_clir_rsp->clir_response_valid = TRUE;
          }
          break;
        }
      }
      break;

      case QMI_VOICE_SET_SUPS_SERVICE_REQ_V02:
      {
      }
      break;

      case QMI_VOICE_GET_CALL_WAITING_REQ_V02:
      {
        voice_get_call_waiting_resp_msg_v02* voice_get_call_waiting_rsp = (voice_get_call_waiting_resp_msg_v02*)rsp;

        switch ( type )
        {
          case VOICEI_GET_CW_SC:
          {
            READ_8_BIT_VAL( value, temp_8bit );		voice_get_call_waiting_rsp->service_class = (uint8_t)temp_8bit;
            voice_get_call_waiting_rsp->service_class_valid = TRUE;
          }
          break;
        }
      }
      break;

      case QMI_VOICE_GET_CALL_FORWARDING_REQ_V02:
      {
        voice_get_call_forwarding_resp_msg_v02* voice_get_call_forwarding_rsp = (voice_get_call_forwarding_resp_msg_v02*)rsp;

        switch ( type )
        {
          case VOICEI_GET_CF_INFO:
          {
            READ_8_BIT_VAL( value, temp_8bit );			voice_get_call_forwarding_rsp->get_call_forwarding_info_len = temp_8bit;

            for ( i = 0; i < voice_get_call_forwarding_rsp->get_call_forwarding_info_len; ++i )
            {
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_call_forwarding_rsp->get_call_forwarding_info[ i ].service_status = (service_status_enum_v02)temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_call_forwarding_rsp->get_call_forwarding_info[ i ].service_class = (uint8_t)temp_8bit;
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_call_forwarding_rsp->get_call_forwarding_info[ i ].number_len = temp_8bit;
              READ_VAR_BIT_VAL( value, temp_var[ 0 ], voice_get_call_forwarding_rsp->get_call_forwarding_info[ i ].number_len );
              memcpy( voice_get_call_forwarding_rsp->get_call_forwarding_info[ i ].number, temp_var, voice_get_call_forwarding_rsp->get_call_forwarding_info[ i ].number_len );
              READ_8_BIT_VAL( value, temp_8bit );	voice_get_call_forwarding_rsp->get_call_forwarding_info[ i ].no_reply_timer = (uint8_t)temp_8bit;
              voice_get_call_forwarding_rsp->get_call_forwarding_info_valid = TRUE;
            }
          }
          break;
        }
      }
      break;

      case QMI_VOICE_GET_CLIP_REQ_V02:
      {
        voice_get_clip_resp_msg_v02* voice_get_clip_rsp = (voice_get_clip_resp_msg_v02*)rsp;

        switch ( type )
        {
          case VOICEI_GET_CLIP_RESP:
          {
            READ_8_BIT_VAL( value, temp_8bit );		voice_get_clip_rsp->clip_response.active_status = (active_status_enum_v02)temp_8bit;
            READ_8_BIT_VAL( value, temp_8bit );		voice_get_clip_rsp->clip_response.provision_status = (provision_status_enum_v02)temp_8bit;
            voice_get_clip_rsp->clip_response_valid = TRUE;
          }
          break;
        }
      }
      break;

      case QMI_VOICE_GET_COLP_REQ_V02:
      {
        voice_get_colp_resp_msg_v02* voice_get_colp_rsp = (voice_get_colp_resp_msg_v02*)rsp;

        switch ( type )
        {
          case VOICEI_GET_COLP_RESP:
          {
            READ_8_BIT_VAL( value, temp_8bit );		voice_get_colp_rsp->colp_response.active_status = (active_status_enum_v02)temp_8bit;
            READ_8_BIT_VAL( value, temp_8bit );		voice_get_colp_rsp->colp_response.provision_status = (provision_status_enum_v02)temp_8bit;
            voice_get_colp_rsp->colp_response_valid = TRUE;
          }
          break;
        }
      }
      break;

      case QMI_VOICE_GET_COLR_REQ_V02:
      {
        voice_get_colr_resp_msg_v02* voice_get_colr_rsp = (voice_get_colr_resp_msg_v02*)rsp;

        switch ( type )
        {
          case VOICEI_GET_COLR_RESP:
          {
            READ_8_BIT_VAL( value, temp_8bit );		voice_get_colr_rsp->colr_response.active_status = (active_status_enum_v02)temp_8bit;
            READ_8_BIT_VAL( value, temp_8bit );		voice_get_colr_rsp->colr_response.provision_status = (provision_status_enum_v02)temp_8bit;
            voice_get_colr_rsp->colr_response_valid = TRUE;
          }
          break;
        }
      }
      break;

      case QMI_VOICE_ORIG_USSD_REQ_V02:
      {
        voice_orig_ussd_resp_msg_v02* voice_orig_ussd_rsp = (voice_orig_ussd_resp_msg_v02*)rsp;

        switch( type )
        {
          case VOICEI_ORIG_USSD_FAILURE_CAUSE:
          {
            READ_16_BIT_VAL( value, temp_16bit );	voice_orig_ussd_rsp->failure_cause = (qmi_sups_errors_enum_v02)temp_16bit;
            voice_orig_ussd_rsp->failure_cause_valid = TRUE;
          }
          break;

          case VOICEI_ORIG_USSD_ALPHA_ID:
          {
            READ_8_BIT_VAL( value, temp_8bit );	voice_orig_ussd_rsp->alpha_id.alpha_dcs = (alpha_dcs_enum_v02)temp_8bit;
            READ_8_BIT_VAL( value, temp_8bit );	voice_orig_ussd_rsp->alpha_id.alpha_text_len = temp_8bit;
            READ_VAR_BIT_VAL( value, temp_var[ 0 ], voice_orig_ussd_rsp->alpha_id.alpha_text_len );
            memcpy( voice_orig_ussd_rsp->alpha_id.alpha_text, temp_var, voice_orig_ussd_rsp->alpha_id.alpha_text_len );
            voice_orig_ussd_rsp->alpha_id_valid = TRUE;
          }
          break;

          case VOICEI_ORIG_USSD_DATA:
          {
            READ_8_BIT_VAL( value, temp_8bit );	voice_orig_ussd_rsp->uss_info.uss_dcs = (uss_dcs_enum_v02)temp_8bit;
            READ_8_BIT_VAL( value, temp_8bit );	voice_orig_ussd_rsp->uss_info.uss_data_len = temp_8bit;
            READ_VAR_BIT_VAL( value, temp_var[ 0 ], voice_orig_ussd_rsp->uss_info.uss_data_len );
            memcpy( voice_orig_ussd_rsp->uss_info.uss_data, temp_var, voice_orig_ussd_rsp->uss_info.uss_data_len );
            voice_orig_ussd_rsp->uss_info_valid = TRUE;
          }
          break;

          case VOICEI_ORIG_USSD_CC_RESULT_TYPE:
          case VOICEI_ORIG_USSD_CC_RESULT_CALL_ID:
          case VOICEI_ORIG_USSD_CC_RESULT_SUPS:
          break;

          case VOICEI_ORIG_USSD_DATA_UTF16:
          {
            READ_8_BIT_VAL( value, temp_8bit );	voice_orig_ussd_rsp->uss_info_utf16_len = temp_8bit;
            READ_VAR_BIT_VAL( value, temp_var[ 0 ], voice_orig_ussd_rsp->uss_info_utf16_len * sizeof( uint16 ) );
            memcpy( voice_orig_ussd_rsp->uss_info_utf16, temp_var, voice_orig_ussd_rsp->uss_info_utf16_len * sizeof( uint16 ) );
            voice_orig_ussd_rsp->uss_info_utf16_valid = TRUE;
          }
          break;
        }
      }
      break;

      case QMI_VOICE_GET_CONFIG_REQ_V02:
      {
        voice_get_config_resp_msg_v02* voice_get_config_rsp = (voice_get_config_resp_msg_v02*)rsp;

        switch ( type )
        {
          case VOICEI_MODEM_GET_CONFIG_PREF_VOICE_DOMAIN:
          {
            READ_8_BIT_VAL( value, temp_8bit );		voice_get_config_rsp->voice_domain = (voice_domain_pref_enum_v02)temp_8bit;
            voice_get_config_rsp->voice_domain_valid = TRUE;
          }
          break;

          //--> RIL_REQUEST_CDMA_QUERY_PREFERRED_VOICE_PRIVACY_MODE
          case VOICEI_MODEM_CONFIG_VOICE_PRIVACY:
          {
            READ_8_BIT_VAL( value, temp_8bit );		voice_get_config_rsp->current_voice_privacy_pref = (voice_privacy_enum_v02)temp_8bit;
            voice_get_config_rsp->current_voice_privacy_pref_valid = TRUE;
          }
          break;
          //<-- RIL_REQUEST_CDMA_QUERY_PREFERRED_VOICE_PRIVACY_MODE

          case VOICEI_MODEM_GET_CONFIG_AMR_STATUS:
          {
            READ_8_BIT_VAL( value, temp_8bit );		voice_get_config_rsp->current_arm_config.gsm_amr_status = temp_8bit;
            READ_8_BIT_VAL( value, temp_8bit );		voice_get_config_rsp->current_arm_config.wcdma_amr_status = temp_8bit;
            voice_get_config_rsp->current_arm_config_valid = TRUE;
          }
          break;
        }
      }
      break;      

      case QMI_VOICE_SET_CONFIG_REQ_V02:
      {
      }
      break;

      //--> RIL_REQUEST_CDMA_SET_PREFERRED_VOICE_PRIVACY_MODE
      case QMI_VOICE_SET_PREFERRED_PRIVACY_REQ_V02:
      {
      }
      break;
      //<-- RIL_REQUEST_CDMA_SET_PREFERRED_VOICE_PRIVACY_MODE
    }
  }

  return QMI_NO_ERR;
}



//dsji_20140402 add {
static int qmi_voice_ussd_ind( unsigned char*			msg,
							   int						msg_size,
							   voice_ussd_ind_msg_v02*	voice_ussd_ind )
{
	unsigned long type;
	unsigned long length;
	unsigned char *value;

	unsigned char	temp_8bit;
	unsigned char	temp_var[ 1024 ];

	while ( msg_size > 0 )
	{
		if ( qmi_util_read_std_tlv( &msg,
									&msg_size,
									&type,
									&length,
									&value ) < 0 )
		{
			return QMI_INTERNAL_ERR;
		}

		switch ( type )
		{
		case VOICEI_USSD_NOTIFY_TYPE:
			{
				READ_8_BIT_VAL( value, temp_8bit );		voice_ussd_ind->notification_type = (further_user_action_enum_v02)temp_8bit;
			}
			break;

		case VOICEI_USSD_IND_DATA:
			{
				READ_8_BIT_VAL( value, temp_8bit );		voice_ussd_ind->uss_info.uss_dcs		= (uss_dcs_enum_v02)temp_8bit;
				READ_8_BIT_VAL( value, temp_8bit );		voice_ussd_ind->uss_info.uss_data_len	= temp_8bit;
				READ_VAR_BIT_VAL( value, temp_var[ 0 ], voice_ussd_ind->uss_info.uss_data_len );
				memcpy( voice_ussd_ind->uss_info.uss_data, temp_var, voice_ussd_ind->uss_info.uss_data_len );
				voice_ussd_ind->uss_info_valid = TRUE;
			}
			break;

		case VOICEI_USSD_IND_DATA_UTF16:
			{
				//not support
			}
			break;
		}
	}
	
	return QMI_NO_ERR;
}
//dsji_20140402 add }

/*===========================================================================

  FUNCTION  qmi_voice_all_call_status_ind

===========================================================================*/
static int qmi_voice_all_call_status_ind
(
  unsigned char                                   *rx_buf,
  int                                             rx_buf_len,
  voice_get_all_call_info_resp_msg_v02            *voice_get_all_call_info_ind
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  unsigned char	temp_8bit;
  unsigned short	temp_16bit;
  //unsigned char	temp_var[ 1024 ];

  memset(voice_get_all_call_info_ind, 0, sizeof(voice_get_all_call_info_ind));


  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

//	printf("[JYP]qmi_voice_all_call_status_ind , Parsing Per TLV.. type  %x\n",type);

    /* Now process TLV */
    switch (type)
    {
      case VOICEI_ALL_CALL_IND_END_REASON:
      {
        READ_8_BIT_VAL(value_ptr, temp_8bit); 
        voice_get_all_call_info_ind->call_end_reason_len = (uint32_t) temp_8bit;

        for ( i = 0; i < (int) voice_get_all_call_info_ind->call_end_reason_len; ++i )
        {
          voice_get_all_call_info_ind->call_end_reason_valid = TRUE;
          READ_8_BIT_VAL( value_ptr, temp_8bit );	voice_get_all_call_info_ind->call_end_reason[i].call_id = temp_8bit;
          READ_16_BIT_VAL( value_ptr, temp_16bit );	voice_get_all_call_info_ind->call_end_reason[i].call_end_reason = (call_end_reason_enum_v02) temp_16bit;
        }		 
      }
      break;

      // Mandatory basic call information
      case QMI_TYPE_REQUIRED_PARAMETERS:
      {
        voice_get_all_call_info_ind->call_info_valid = TRUE;

        READ_8_BIT_VAL(value_ptr, g_voice_basic_call_info.num_of_calls);
		voice_get_all_call_info_ind->call_info_len = g_voice_basic_call_info.num_of_calls; //jaeyong1.park 2017-01-12  
		
        for( i = 0 ; i < g_voice_basic_call_info.num_of_calls ; i++)
        {
          READ_8_BIT_VAL(value_ptr, voice_get_all_call_info_ind->call_info[i].call_id);
          READ_8_BIT_VAL(value_ptr, temp_8bit);
          voice_get_all_call_info_ind->call_info[i].call_state = (call_state_enum_v02)temp_8bit;
          READ_8_BIT_VAL(value_ptr, temp_8bit);
          voice_get_all_call_info_ind->call_info[i].call_type = (call_type_enum_v02)temp_8bit;
          READ_8_BIT_VAL(value_ptr, temp_8bit);
          voice_get_all_call_info_ind->call_info[i].direction = (call_direction_enum_v02)temp_8bit;
          READ_8_BIT_VAL(value_ptr, temp_8bit);
          voice_get_all_call_info_ind->call_info[i].mode = (call_mode_enum_v02)temp_8bit;
          READ_8_BIT_VAL(value_ptr, voice_get_all_call_info_ind->call_info[i].is_mpty);
          READ_8_BIT_VAL(value_ptr, temp_8bit);
          voice_get_all_call_info_ind->call_info[i].als = (als_enum_v02)temp_8bit;
        }
      }
      break;

	  // Optional data	
	  // Get dial number from call ind- jaeyong1.park 2017-01-12 AS057-1103
	  case VOICEI_ALL_CALL_IND_RP_NUM:
	  {

	  	voice_get_all_call_info_ind->called_party_num_valid = TRUE;

		int _j=0;		
		unsigned char	temp_var[ 1024 ];
		
		READ_8_BIT_VAL(value_ptr, temp_8bit);
		voice_get_all_call_info_ind->called_party_num_len = (uint32_t)temp_8bit;
		g_called_party_num_len = (uint32_t)temp_8bit;

		for ( _j=0 ; _j< voice_get_all_call_info_ind->called_party_num_len ; _j++)
		{
			READ_8_BIT_VAL(value_ptr, temp_8bit);
			voice_get_all_call_info_ind->called_party_num[_j].call_id = (uint8_t)temp_8bit;
			g_remote_party_number[_j].call_id = (uint8_t)temp_8bit;;

			READ_8_BIT_VAL(value_ptr, temp_8bit);
			voice_get_all_call_info_ind->called_party_num[_j].num_pi = (pi_num_enum_v02)temp_8bit;
			g_remote_party_number[_j].num_pi = (pi_num_enum_v02)temp_8bit;

			READ_8_BIT_VAL(value_ptr, temp_8bit);
			voice_get_all_call_info_ind->called_party_num[_j].num_len= (uint32_t)temp_8bit;
			g_remote_party_number[_j].num_len= (uint32_t)temp_8bit;
			

			READ_VAR_BIT_VAL( value_ptr, temp_var[ 0 ], voice_get_all_call_info_ind->called_party_num[_j].num_len );
			temp_var[voice_get_all_call_info_ind->called_party_num[_j].num_len]=0; 
			memcpy(g_remote_party_number[_j].num , temp_var, voice_get_all_call_info_ind->called_party_num[_j].num_len +1);
//	        printf("[JYP] ------------ In message num : %d , %s \n", g_remote_party_number[_j].num_len, g_remote_party_number[_j].num );
		}//for
	  }
	  	break;

      // 20140627 VoLTE Ring Back Tone
      case VOICEI_ALL_CALL_IND_ALERTING:
      {
        voice_get_all_call_info_ind->alerting_type_valid = TRUE;
        READ_8_BIT_VAL(value_ptr, temp_8bit); 
        voice_get_all_call_info_ind->alerting_type_len = (uint32_t) temp_8bit;

        for ( i = 0; i < (int) voice_get_all_call_info_ind->alerting_type_len; ++i )
        {
          READ_8_BIT_VAL( value_ptr, temp_8bit );	voice_get_all_call_info_ind->alerting_type[i].call_id = temp_8bit;
          READ_8_BIT_VAL( value_ptr, temp_8bit );	voice_get_all_call_info_ind->alerting_type[i].alerting_type = (alerting_type_enum_v02) temp_8bit;
          MSG_HIGH("[VOICE] call_id = %d remote_ringback_tone = %d", voice_get_all_call_info_ind->alerting_type[i].call_id, voice_get_all_call_info_ind->alerting_type[i].alerting_type,0);
        }		 
      }
      break;
        }				
			}

	return QMI_NO_ERR;
}

/*===========================================================================

  FUNCTION  qmi_voice_speech_codec_info_ind

===========================================================================*/
static int qmi_voice_speech_codec_info_ind
(
  unsigned char                                   *rx_buf,
  int                                             rx_buf_len,
  voice_speech_codec_info_ind_msg_v02             *voice_speech_codec_info_ind
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;

  unsigned int	temp_32bit;

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case VOICEI_SPEECH_CODEC_INFO_NW_MODE:
      {
        READ_32_BIT_VAL(value_ptr, temp_32bit); 
        voice_speech_codec_info_ind->network_mode_valid = TRUE;
        voice_speech_codec_info_ind->network_mode = (voice_network_mode_enum_v02) temp_32bit;
      }
      break;

      case VOICEI_SPEECH_CODEC_INFO_CODEC_TYPE:
      {
        READ_32_BIT_VAL(value_ptr, temp_32bit); 
        voice_speech_codec_info_ind->speech_codec_valid = TRUE;
        voice_speech_codec_info_ind->speech_codec = (voice_speech_codec_enum_v02) temp_32bit;
      }
      break;

      case VOICEI_SPEECH_CODEC_INFO_SAMPLE_RATE:
      {
        READ_32_BIT_VAL(value_ptr, temp_32bit); 
        voice_speech_codec_info_ind->speech_enc_samp_freq_valid = TRUE;
        voice_speech_codec_info_ind->speech_enc_samp_freq = temp_32bit;
      }
      break;
		}
	}

	return QMI_NO_ERR;
}

//--> RIL_UNSOL_CDMA_INFO_REC
/*===========================================================================

FUNCTION  qmi_voice_print_number

===========================================================================*/
void qmi_voice_print_number(char number[], char len)
{
  int i = 0;

  for(i = 0 ; i < len ; i++)
    MSG_ERROR("[INFO] number[%d] = [%d], len(%d)", i, number[i], len);
}

/*===========================================================================

FUNCTION  qmi_voice_info_rec_ind_process

===========================================================================*/
void qmi_voice_info_rec_ind_process(voice_info_rec_ind_msg_v02 *voice_info_rec_ind)
{
  TOF_CDMA_InformationRecord *    info_rec_ptr;
  int                             idx = 0;
  uint8                           display_tag;
  uint8                           display_len;
  unsigned int                    buf_len = 0;
  struct
  {
    char buf[QMI_VOICE_CALLER_ID_MAX_V02+1];
    char pi;
  } number;
  char                            name[QMI_VOICE_CALLER_NAME_MAX_V02+1];
  boolean                         name_changed = FALSE, 
                                  number_changed = FALSE;

  MSG_ERROR("[INFO] qmi_voice_info_rec_ind start", 0, 0, 0);
  TOF_CDMA_SignalInfoRecord       signal_info_rec;
  TOF_CDMA_SignalInfoRecord*      info_rec_pass_over;

  memset(&CDMA_InformationRecords, 0, sizeof(CDMA_InformationRecords));
  memset( &number, 0, sizeof(number) );
  memset( &name, 0, sizeof(name) );
  memset( &signal_info_rec, 0, sizeof(signal_info_rec) );

  MSG_ERROR("[INFO] caller_id_info_valid [%d], calling_party_info_valid [%d]", voice_info_rec_ind->caller_id_info_valid, voice_info_rec_ind->calling_party_info_valid, 0);
  if(voice_info_rec_ind->caller_id_info_valid && voice_info_rec_ind->calling_party_info_valid)
  {
    info_rec_ptr = & CDMA_InformationRecords.infoRec[idx];
    info_rec_ptr->name = TOF_CDMA_CALLING_PARTY_NUMBER_INFO_REC;
    info_rec_ptr->rec.number.len = voice_info_rec_ind->caller_id_info.caller_id_len;
    memcpy(info_rec_ptr->rec.number.buf, voice_info_rec_ind->caller_id_info.caller_id, info_rec_ptr->rec.number.len);
    info_rec_ptr->rec.number.pi = (char)voice_info_rec_ind->caller_id_info.pi;
    info_rec_ptr->rec.number.number_type = voice_info_rec_ind->calling_party_info.num_type;
    info_rec_ptr->rec.number.number_plan = voice_info_rec_ind->calling_party_info.num_type;
    info_rec_ptr->rec.number.si = voice_info_rec_ind->calling_party_info.si;
    idx++;
    memcpy(number.buf, info_rec_ptr->rec.number.buf, info_rec_ptr->rec.number.len);
    number.pi = info_rec_ptr->rec.number.pi;
    number_changed = TRUE;

    #ifdef BOGUS //for test
    qmi_voice_print_number(info_rec_ptr->rec.number.buf, info_rec_ptr->rec.number.len);
    #endif /* BOGUS */
  }
  else if(voice_info_rec_ind->caller_id_info_valid && !voice_info_rec_ind->calling_party_info_valid)
  {
    info_rec_ptr = & CDMA_InformationRecords.infoRec[idx];
    info_rec_ptr->name = TOF_CDMA_CALLING_PARTY_NUMBER_INFO_REC;
    info_rec_ptr->rec.number.len = voice_info_rec_ind->caller_id_info.caller_id_len;
    memcpy(info_rec_ptr->rec.number.buf, voice_info_rec_ind->caller_id_info.caller_id, info_rec_ptr->rec.number.len);
    info_rec_ptr->rec.number.pi = (char)voice_info_rec_ind->caller_id_info.pi;
    info_rec_ptr->rec.number.number_type = QMI_VOICE_NUM_TYPE_UNKNOWN_V02;
    info_rec_ptr->rec.number.number_plan = QMI_VOICE_NUM_PLAN_UNKNOWN_V02;
    info_rec_ptr->rec.number.si = QMI_VOICE_SI_USER_PROVIDED_NOT_SCREENED_V02;
    idx++;
    memcpy(number.buf, info_rec_ptr->rec.number.buf, info_rec_ptr->rec.number.len);
    number.pi = info_rec_ptr->rec.number.pi;
    number_changed = TRUE;

    #ifdef BOGUS //for test
    qmi_voice_print_number(info_rec_ptr->rec.number.buf, info_rec_ptr->rec.number.len);
    #endif /* BOGUS */
  }
  else if(voice_info_rec_ind->calling_party_info_valid)
  {
    info_rec_ptr = & CDMA_InformationRecords.infoRec[idx];
    info_rec_ptr->name = TOF_CDMA_CALLING_PARTY_NUMBER_INFO_REC;
    info_rec_ptr->rec.number.len = voice_info_rec_ind->calling_party_info.num_len;
    memcpy(info_rec_ptr->rec.number.buf, voice_info_rec_ind->calling_party_info.num, info_rec_ptr->rec.number.len);
    info_rec_ptr->rec.number.pi = (char)voice_info_rec_ind->calling_party_info.pi;
    info_rec_ptr->rec.number.number_type = voice_info_rec_ind->calling_party_info.num_type;
    info_rec_ptr->rec.number.number_plan = voice_info_rec_ind->calling_party_info.num_plan;
    info_rec_ptr->rec.number.si = voice_info_rec_ind->calling_party_info.si;
    idx++;
    memcpy(number.buf, info_rec_ptr->rec.number.buf, info_rec_ptr->rec.number.len);
    number.pi = info_rec_ptr->rec.number.pi;
    number_changed = TRUE;

    #ifdef BOGUS //for test
    qmi_voice_print_number(info_rec_ptr->rec.number.buf, info_rec_ptr->rec.number.len);
    #endif /* BOGUS */
  }

  MSG_ERROR("[INFO] signal_info_valid [%d]", voice_info_rec_ind->signal_info_valid, 0, 0);
  if(voice_info_rec_ind->signal_info_valid)
  {
    info_rec_ptr = &CDMA_InformationRecords.infoRec[idx];
    info_rec_ptr->name = TOF_CDMA_SIGNAL_INFO_REC;
    info_rec_ptr->rec.signal.isPresent = TRUE;
    info_rec_ptr->rec.signal.signalType = (char)voice_info_rec_ind->signal_info.signal_type;
    info_rec_ptr->rec.signal.alertPitch = (char)voice_info_rec_ind->signal_info.alert_pitch;
    info_rec_ptr->rec.signal.signal = (char)voice_info_rec_ind->signal_info.signal;
    idx++;
  }

  MSG_ERROR("[INFO] display_buffer_valid [%d]", voice_info_rec_ind->display_buffer_valid, 0, 0);
  if(voice_info_rec_ind->display_buffer_valid)
  {
    buf_len = strlen(voice_info_rec_ind->display_buffer);
    info_rec_ptr = &CDMA_InformationRecords.infoRec[idx];
    info_rec_ptr->name = TOF_CDMA_DISPLAY_INFO_REC;
    info_rec_ptr->rec.display.alpha_len = buf_len;
    if(info_rec_ptr->rec.display.alpha_len > CDMA_ALPHA_INFO_BUFFER_LENGTH)
    {
      info_rec_ptr->rec.display.alpha_len = CDMA_ALPHA_INFO_BUFFER_LENGTH;
    }
    memcpy(info_rec_ptr->rec.display.alpha_buf, voice_info_rec_ind->display_buffer, info_rec_ptr->rec.display.alpha_len);
    idx++;
  }

  MSG_ERROR("[INFO] ext_display_record_valid [%d], ext_display_buffer_valid [%d]", voice_info_rec_ind->ext_display_record_valid, voice_info_rec_ind->ext_display_buffer_valid, 0);
  if(voice_info_rec_ind->ext_display_record_valid)
  {
    display_tag = voice_info_rec_ind->ext_display_record.ext_display_info[0];
    display_len = voice_info_rec_ind->ext_display_record.ext_display_info[1];

    if ( display_tag == 0x8D || display_tag == 0x8F || (display_tag == 0x9E)) //0x9E
    {
      memcpy(name, voice_info_rec_ind->ext_display_record.ext_display_info+2, display_len);
      name_changed = TRUE;
    }
    else
    {
      info_rec_ptr = &CDMA_InformationRecords.infoRec[idx];
      info_rec_ptr->name = TOF_CDMA_EXTENDED_DISPLAY_INFO_REC;
      info_rec_ptr->rec.display.alpha_len = voice_info_rec_ind->ext_display_record.ext_display_info_len;
      if(info_rec_ptr->rec.display.alpha_len > CDMA_ALPHA_INFO_BUFFER_LENGTH)
      {
        info_rec_ptr->rec.display.alpha_len = CDMA_ALPHA_INFO_BUFFER_LENGTH;
      }
      memcpy(info_rec_ptr->rec.display.alpha_buf, voice_info_rec_ind->ext_display_record.ext_display_info, info_rec_ptr->rec.display.alpha_len);
      idx++;
      //0x9E
    }
  }
  else if(voice_info_rec_ind->ext_display_buffer_valid)
  {
    buf_len = strlen(voice_info_rec_ind->ext_display_buffer);
    info_rec_ptr = &CDMA_InformationRecords.infoRec[idx];
    info_rec_ptr->name = TOF_CDMA_EXTENDED_DISPLAY_INFO_REC;
    info_rec_ptr->rec.display.alpha_len = buf_len;
    if(info_rec_ptr->rec.display.alpha_len > CDMA_ALPHA_INFO_BUFFER_LENGTH)
    {
      info_rec_ptr->rec.display.alpha_len = CDMA_ALPHA_INFO_BUFFER_LENGTH;
    }
    memcpy(info_rec_ptr->rec.display.alpha_buf, voice_info_rec_ind->ext_display_buffer, info_rec_ptr->rec.display.alpha_len);
    idx++;
  }

  MSG_ERROR("[INFO] caller_name_valid [%d]", voice_info_rec_ind->caller_name_valid, 0, 0);
  if(voice_info_rec_ind->caller_name_valid && !name_changed)
  {
    memcpy(name, voice_info_rec_ind->caller_name, strlen(voice_info_rec_ind->caller_name));
    name_changed = TRUE;
  }

  if(voice_info_rec_ind->audio_control_valid)
  {
    info_rec_ptr = &CDMA_InformationRecords.infoRec[idx];
    info_rec_ptr->name = TOF_CDMA_T53_AUDIO_CONTROL_INFO_REC;
    info_rec_ptr->rec.audioCtrl.downLink = voice_info_rec_ind->audio_control.down_link;
    info_rec_ptr->rec.audioCtrl.upLink = voice_info_rec_ind->audio_control.up_link;
    idx++;
  }

  if(voice_info_rec_ind->clir_cause_valid)
  {
    info_rec_ptr = &CDMA_InformationRecords.infoRec[idx];
    info_rec_ptr->name = TOF_CDMA_T53_CLIR_INFO_REC;
    info_rec_ptr->rec.clir.cause = (char)voice_info_rec_ind->clir_cause;
    number_changed = TRUE;
    idx++;
  }

  if(voice_info_rec_ind->nss_release_valid)
  {
    // TODO:
  }

  MSG_ERROR("[INFO] redirecting_num_info_valid [%d]", voice_info_rec_ind->redirecting_num_info_valid, 0, 0);
  if( voice_info_rec_ind->redirecting_num_info_valid )
  {
    info_rec_ptr = &CDMA_InformationRecords.infoRec[idx];
    info_rec_ptr->name = TOF_CDMA_REDIRECTING_NUMBER_INFO_REC;
    info_rec_ptr->rec.redir.redirectingReason = (TOF_CDMA_RedirectingReason)voice_info_rec_ind->redirecting_num_info.reason;
    info_rec_ptr->rec.redir.redirectingNumber.pi = voice_info_rec_ind->redirecting_num_info.pi;
    info_rec_ptr->rec.redir.redirectingNumber.si = voice_info_rec_ind->redirecting_num_info.si;
    info_rec_ptr->rec.redir.redirectingNumber.number_plan = voice_info_rec_ind->redirecting_num_info.num_plan;
    info_rec_ptr->rec.redir.redirectingNumber.number_type = voice_info_rec_ind->redirecting_num_info.num_type;
    info_rec_ptr->rec.redir.redirectingNumber.len = voice_info_rec_ind->redirecting_num_info.num_len;
    if(info_rec_ptr->rec.redir.redirectingNumber.len >= sizeof(info_rec_ptr->rec.redir.redirectingNumber.buf))
    {
      info_rec_ptr->rec.redir.redirectingNumber.len = sizeof(info_rec_ptr->rec.redir.redirectingNumber.buf) - 1;
    }
    if(info_rec_ptr->rec.redir.redirectingNumber.len > 0)
    {
      strncpy(info_rec_ptr->rec.redir.redirectingNumber.buf, voice_info_rec_ind->redirecting_num_info.num, (info_rec_ptr->rec.redir.redirectingNumber.len-1));
      info_rec_ptr->rec.redir.redirectingNumber.buf[info_rec_ptr->rec.redir.redirectingNumber.len] = '\0';
    }
    idx++;
  }

  if(voice_info_rec_ind->line_control_valid)
  {
    info_rec_ptr = &CDMA_InformationRecords.infoRec[idx];
    info_rec_ptr->name = TOF_CDMA_LINE_CONTROL_INFO_REC;
    info_rec_ptr->rec.lineCtrl.lineCtrlPolarityIncluded = (char) voice_info_rec_ind->line_control.polarity_included;
    info_rec_ptr->rec.lineCtrl.lineCtrlToggle = voice_info_rec_ind->line_control.toggle_mode;
    info_rec_ptr->rec.lineCtrl.lineCtrlReverse = voice_info_rec_ind->line_control.reverse_polarity;
    info_rec_ptr->rec.lineCtrl.lineCtrlPowerDenial = voice_info_rec_ind->line_control.power_denial_time;
    idx++;
  }

  MSG_ERROR("[INFO] conn_num_info_valid [%d]", voice_info_rec_ind->conn_num_info_valid, 0, 0);
  if(voice_info_rec_ind->conn_num_info_valid)
  {
    info_rec_ptr = &CDMA_InformationRecords.infoRec[idx];
    info_rec_ptr->name = TOF_CDMA_CONNECTED_NUMBER_INFO_REC;
    info_rec_ptr->rec.number.number_plan = voice_info_rec_ind->conn_num_info.num_plan;
    info_rec_ptr->rec.number.number_type = voice_info_rec_ind->conn_num_info.num_type;
    info_rec_ptr->rec.number.pi = voice_info_rec_ind->conn_num_info.pi;
    info_rec_ptr->rec.number.si = voice_info_rec_ind->conn_num_info.si;
    info_rec_ptr->rec.number.len = voice_info_rec_ind->conn_num_info.num_len;
    memcpy(info_rec_ptr->rec.number.buf, voice_info_rec_ind->conn_num_info.num, info_rec_ptr->rec.number.len);
    idx++;

    #ifdef BOGUS //for test
    qmi_voice_print_number(info_rec_ptr->rec.number.buf, info_rec_ptr->rec.number.len);
    #endif /* BOGUS */
  }


  MSG_ERROR("[INFO] called_party_info_valid [%d]", voice_info_rec_ind->called_party_info_valid, 0, 0);
  if(voice_info_rec_ind->called_party_info_valid)
  {
    info_rec_ptr = &CDMA_InformationRecords.infoRec[idx];
    info_rec_ptr->name = TOF_CDMA_CALLED_PARTY_NUMBER_INFO_REC;
    info_rec_ptr->rec.number.number_plan = voice_info_rec_ind->conn_num_info.num_plan;
    info_rec_ptr->rec.number.number_type = voice_info_rec_ind->conn_num_info.num_type;
    info_rec_ptr->rec.number.pi = voice_info_rec_ind->conn_num_info.pi;
    info_rec_ptr->rec.number.si = voice_info_rec_ind->conn_num_info.si;
    info_rec_ptr->rec.number.len = voice_info_rec_ind->conn_num_info.num_len;
    memcpy(info_rec_ptr->rec.number.buf, voice_info_rec_ind->conn_num_info.num, info_rec_ptr->rec.number.len);
    idx++;

    #ifdef BOGUS //for test
    qmi_voice_print_number(info_rec_ptr->rec.number.buf, info_rec_ptr->rec.number.len);
    #endif /* BOGUS */
  }

  // TODO: call_info_entry & call waiting

  CDMA_InformationRecords.numberOfInfoRecs = idx;
  
  if (number_changed || name_changed)
  {
    //Send_UnsolicitedResponse( RIL_UNSOL_RESPONSE_CALL_STATE_CHANGED, NULL, 0 );
    EventNotifyEnqueue(TOF_EVENT_RESPONSE_CALL_STATE_CHANGED, 0, 0);
  }

  if ( idx > 0 )
  {
    //Send_UnsolicitedResponse (RIL_UNSOL_CDMA_INFO_REC, &CDMA_InformationRecords, sizeof(CDMA_InformationRecords));
  }

  //--> RIL_UNSOL_CALL_RING
  // RING indication for an incoming call.
  if(voice_info_rec_ind->signal_info_valid && CALL_DIRECTION_MT_V02 == g_voice_all_call_info.call_info[0].direction)
  {
    info_rec_pass_over = (TOF_CDMA_SignalInfoRecord*)malloc(sizeof(*info_rec_pass_over));
    if(info_rec_pass_over)
    {
      *info_rec_pass_over = signal_info_rec;
      qmi_voice_make_incoming_call_ring(info_rec_pass_over);
    }

    if(info_rec_pass_over)
    {
      free(info_rec_pass_over);
    }
  }
  //<-- RIL_UNSOL_CALL_RING

  MSG_ERROR("[INFO] qmi_voice_info_rec_ind end", 0, 0, 0);
} /* qmi_voice_info_rec_ind_process */

/*===========================================================================

  FUNCTION  qmi_voice_info_rec_ind

===========================================================================*/
static int qmi_voice_info_rec_ind
(
  unsigned char                                   *rx_buf,
  int                                             rx_buf_len,
  voice_info_rec_ind_msg_v02                      *voice_info_rec_ind
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;
  unsigned char	temp_8bit;

  MSG_ERROR("[INFO] qmi_voice_info_rec_ind start", 0, 0, 0);

  memset(voice_info_rec_ind, 0, sizeof(voice_info_rec_ind_msg_v02));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case VOICEI_INFO_REC_CALL_ID:
        MSG_ERROR("[INFO] VOICEI_INFO_REC_CALL_ID", 0, 0, 0);
        READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->call_id);
				break;

      case VOICEI_SIGNAL_INFO:
        MSG_ERROR("[INFO] VOICEI_SIGNAL_INFO", 0, 0, 0);
        voice_info_rec_ind->signal_info_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->signal_info.signal_type = (signal_type_enum_v02)temp_8bit;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->signal_info.alert_pitch = (alert_pitch_enum_v02)temp_8bit;
        READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->signal_info.signal);
        break;
      
      case VOICEI_CALLER_ID:
        MSG_ERROR("[INFO] VOICEI_CALLER_ID", 0, 0, 0);
        voice_info_rec_ind->caller_id_info_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->caller_id_info.pi = (pi_num_enum_v02)temp_8bit;
        READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->caller_id_info.caller_id_len);
        
        for(i = 0 ; i < voice_info_rec_ind->caller_id_info.caller_id_len ; i++)
          READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->caller_id_info.caller_id[i]);
        break;
      
      case VOICEI_DISPLAY_INFO:
        MSG_ERROR("[INFO] VOICEI_DISPLAY_INFO", 0, 0, 0);
        voice_info_rec_ind->display_buffer_valid = TRUE;
        for( i = 0 ; i < QMI_VOICE_DISPLAY_BUFFER_MAX_V02 + 1 ; i++)
          READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->display_buffer[i]);
        break;

      case VOICEI_EXT_DISPLAY_INFO:
        MSG_ERROR("[INFO] VOICEI_EXT_DISPLAY_INFO", 0, 0, 0);
        voice_info_rec_ind->ext_display_buffer_valid = TRUE;
        for( i = 0 ; i < QMI_VOICE_DISPLAY_BUFFER_MAX_V02 + 1 ; i++)
          READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->ext_display_buffer[i]);
				break;

      case VOICEI_CALLER_NAME_INFO:
        MSG_ERROR("[INFO] VOICEI_CALLER_NAME_INFO", 0, 0, 0);
        voice_info_rec_ind->caller_name_valid = TRUE;
        for( i = 0 ; i < QMI_VOICE_CALLER_NAME_MAX_V02 + 1 ; i++)
          READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->caller_name[i]);
				break;
      
      case VOICEI_CALL_WAITING_IND:
        MSG_ERROR("[INFO] VOICEI_CALL_WAITING_IND", 0, 0, 0);
        voice_info_rec_ind->call_waiting_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->call_waiting = (call_waiting_enum_v02)temp_8bit;
        break;

      case VOICEI_CONN_NUM_INFO:
        MSG_ERROR("[INFO] VOICEI_CONN_NUM_INFO", 0, 0, 0);
        voice_info_rec_ind->conn_num_info_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->conn_num_info.pi = (pi_num_enum_v02)temp_8bit;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->conn_num_info.si = (voice_si_enum_v02)temp_8bit;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->conn_num_info.num_type = (voice_num_type_enum_v02)temp_8bit;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->conn_num_info.num_plan = (voice_num_plan_enum_v02)temp_8bit;
        READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->conn_num_info.num_len);

        for(i = 0 ; i < voice_info_rec_ind->conn_num_info.num_len ; i++)
          READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->conn_num_info.num[i]);
				break;
      
      case VOICEI_CALLING_PARTY_NUM_INFO:
        MSG_ERROR("[INFO] VOICEI_CALLING_PARTY_NUM_INFO", 0, 0, 0);
        voice_info_rec_ind->calling_party_info_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->calling_party_info.pi = (pi_num_enum_v02)temp_8bit;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->calling_party_info.si = (voice_si_enum_v02)temp_8bit;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->calling_party_info.num_type = (voice_num_type_enum_v02)temp_8bit;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->calling_party_info.num_plan = (voice_num_plan_enum_v02)temp_8bit;
        READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->calling_party_info.num_len);

        for(i = 0 ; i < voice_info_rec_ind->calling_party_info.num_len ; i++)
          READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->calling_party_info.num[i]);
        break;

      case VOICEI_CALLED_PARTY_NUM_INFO:
        MSG_ERROR("[INFO] VOICEI_CALLED_PARTY_NUM_INFO", 0, 0, 0);
        voice_info_rec_ind->called_party_info_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->called_party_info.pi = (pi_num_enum_v02)temp_8bit;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->called_party_info.si = (voice_si_enum_v02)temp_8bit;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->called_party_info.num_type = (voice_num_type_enum_v02)temp_8bit;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->called_party_info.num_plan = (voice_num_plan_enum_v02)temp_8bit;
        READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->called_party_info.num_len);

        for(i = 0 ; i < voice_info_rec_ind->called_party_info.num_len ; i++)
          READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->called_party_info.num[i]);
				break;

      case VOICEI_REDIRECT_NUM_INFO:
        MSG_ERROR("[INFO] VOICEI_REDIRECT_NUM_INFO", 0, 0, 0);
        voice_info_rec_ind->redirecting_num_info_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->redirecting_num_info.pi = (pi_num_enum_v02)temp_8bit;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->redirecting_num_info.si = (voice_si_enum_v02)temp_8bit;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->redirecting_num_info.num_type = (voice_num_type_enum_v02)temp_8bit;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->redirecting_num_info.num_plan = (voice_num_plan_enum_v02)temp_8bit;
        READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->redirecting_num_info.num_len);

        for(i = 0 ; i < voice_info_rec_ind->redirecting_num_info.num_len ; i++)
          READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->redirecting_num_info.num[i]);
				break;

      case VOICEI_NSS_CLIR_INFO:
        voice_info_rec_ind->clir_cause_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->clir_cause = (voice_nss_clir_cause_enum_v02)temp_8bit;
				break;

      case VOICEI_NSS_AUD_CTRL_INFO:
        voice_info_rec_ind->audio_control_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->audio_control.up_link);
        READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->audio_control.down_link);
				break;

      case VOICEI_NSS_RELEASE_INFO:
        voice_info_rec_ind->nss_release_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        voice_info_rec_ind->nss_release = (voice_nss_release_enum_v02)temp_8bit;
				break;

      case VOICEI_LINE_CTRL_INFO:
        voice_info_rec_ind->line_control_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->line_control.polarity_included);
        READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->line_control.toggle_mode);
        READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->line_control.reverse_polarity);
        READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->line_control.power_denial_time);
				break;

      case VOICEI_EXT_DISPLAY_INFO_RECORD:
        MSG_ERROR("[INFO] VOICEI_EXT_DISPLAY_INFO_RECORD", 0, 0, 0);
        voice_info_rec_ind->ext_display_record_valid = TRUE;
        READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->ext_display_record.display_type);
        READ_32_BIT_VAL (value_ptr, voice_info_rec_ind->ext_display_record.ext_display_info_len);
        for(i = 0 ; i < voice_info_rec_ind->ext_display_record.ext_display_info_len ; i++)
          READ_8_BIT_VAL (value_ptr, voice_info_rec_ind->ext_display_record.ext_display_info[i]);
				break;
    }
  }

  MSG_ERROR("[INFO] qmi_voice_info_rec_ind end", 0, 0, 0);

	return QMI_NO_ERR;
}
//<-- RIL_UNSOL_CDMA_INFO_REC

//--> RIL_UNSOL_CDMA_OTA_PROVISION_STATUS
/*===========================================================================

FUNCTION  qmi_voice_otasp_status_ind_process

===========================================================================*/
void qmi_voice_otasp_status_ind_process(voice_otasp_status_ind_msg_v02 *otasp_status_ind_ptr)
{
  TOF_CDMA_OTA_ProvisionStatus ota_status;

  MSG_ERROR("[OTASP] qmi_voice_otasp_status_ind_process call_id = %d otasp_status %d",
                           otasp_status_ind_ptr->otasp_status_info.otasp_status,
                           otasp_status_ind_ptr->otasp_status_info.call_id, 0);

  ota_status = (TOF_CDMA_OTA_ProvisionStatus)otasp_status_ind_ptr->otasp_status_info.otasp_status;

  //Send_UnsolicitedResponse (RIL_UNSOL_CDMA_OTA_PROVISION_STATUS, &ota_status, sizeof(RIL_CDMA_OTA_ProvisionStatus));
} /* qmi_voice_otasp_status_ind_process */

/*===========================================================================

  FUNCTION  qmi_voice_otasp_status_ind

===========================================================================*/
static int qmi_voice_otasp_status_ind
(
  unsigned char                                   *rx_buf,
  int                                             rx_buf_len,
  voice_otasp_status_ind_msg_v02                  *otasp_status_ind_ptr
)
{
  unsigned long type;
  unsigned long length;
  unsigned char *value_ptr;
  int i = 0;
  unsigned char	temp_8bit;

  MSG_ERROR("[OTASP] qmi_voice_otasp_status_ind start", 0, 0, 0);

  memset(otasp_status_ind_ptr, 0, sizeof(voice_otasp_status_ind_msg_v02));

  /* Cycle through return message reading all TLV's */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }

    /* Now process TLV */
    switch (type)
    {
      case QMI_TYPE_REQUIRED_PARAMETERS:
        MSG_ERROR("[OTASP] otasp status", 0, 0, 0);
        READ_8_BIT_VAL (value_ptr, otasp_status_ind_ptr->otasp_status_info.call_id);
        READ_8_BIT_VAL (value_ptr, temp_8bit);
        otasp_status_ind_ptr->otasp_status_info.otasp_status = (otasp_status_enum_v02)temp_8bit;
        break;
    }
  }

  MSG_ERROR("[OTASP] qmi_voice_otasp_status_ind end", 0, 0, 0);

	return QMI_NO_ERR;
}/* qmi_voice_otasp_status_ind */
//<-- RIL_UNSOL_CDMA_OTA_PROVISION_STATUS

//20161012 yjoh, add eCall ind
static int qmi_voice_ecall_event_ind( unsigned char*			msg,
							   int						msg_size,
							   voice_ecall_event_ind_msg_v02*	voice_ecall_event_ind )
{
	unsigned long type;
	unsigned long length;
	unsigned char *value;

	unsigned char	temp_8bit;

	while ( msg_size > 0 )
	{
		if ( qmi_util_read_std_tlv( &msg,
									&msg_size,
									&type,
									&length,
									&value ) < 0 )
		{
			return QMI_INTERNAL_ERR;
		}
		switch ( type )
		{
			case VOICEI_ECALL_EVENT_IND:
			{
				READ_8_BIT_VAL( value, temp_8bit );		voice_ecall_event_ind->ecall_event_ind= (ecall_event_ind_enum_v02)temp_8bit;
			    MSG_ERROR("[ECALL] VOICEI_ECALL_EVENT_IND event : %d", voice_ecall_event_ind->ecall_event_ind, 0, 0);
			}
			break;

		}
	}
	
	return QMI_NO_ERR;
}
/*===========================================================================

  FUNCTION  qmi_voice_srvc_indication_cb

===========================================================================*/
static void qmi_voice_srvc_indication_cb
( 
  int                    user_handle,
  qmi_service_id_type    service_id,
  unsigned long          msg_id,
  void*                  user_ind_msg_hdlr,
  void*                  user_ind_msg_hdlr_user_data,
  unsigned char*         rx_msg_buf,
  int                    rx_msg_len
)
{
	qmi_voice_indication_id_type	voice_ind_id = QMI_VOICE_CM_IF_CMD_INVALID_IND;
	void*							voice_ind_data = NULL;
	qmi_voice_indication_hdlr_type	voice_user_ind_hdlr;

	voice_get_all_call_info_resp_msg_v02 voice_get_all_call_info_ind;
	voice_speech_codec_info_ind_msg_v02 voice_speech_codec_info_ind;

	voice_info_rec_ind_msg_v02 voice_info_rec_ind; //RIL_UNSOL_CDMA_INFO_REC
	voice_otasp_status_ind_msg_v02* otasp_status_ind_ptr; //RIL_UNSOL_CDMA_OTA_PROVISION_STATUS

	voice_ussd_ind_msg_v02	voice_ussd_ind;	//dsji_20140402 add

	voice_ecall_event_ind_msg_v02	voice_ecall_ind; 	//20161012 yjoh, add eCall ind

	
	memset( &voice_get_all_call_info_ind, 0x0, sizeof( voice_get_all_call_info_resp_msg_v02 ) );
	memset( &voice_speech_codec_info_ind, 0x0, sizeof( voice_speech_codec_info_ind_msg_v02 ) );
	memset( &g_voice_basic_call_info, 0x0, sizeof( voice_basic_call_info_type ) );

	memset( &voice_ussd_ind, 0x0, sizeof( voice_ussd_ind_msg_v02 ) );	//dsji_20140402 add

	memset( &voice_ecall_ind, 0x0, sizeof( voice_ecall_event_ind_msg_v02 ) );	//20161012 yjoh, add eCall ind
		
	if ( NULL == user_ind_msg_hdlr )
	{
		return;
	}
	switch ( msg_id )
	{
	  //case QMI_VOICE_OTASP_STATUS_IND_V02:
	  //case QMI_VOICE_INFO_REC_IND_V02:
	  //case QMI_VOICE_DTMF_IND_V02:
	  //case QMI_VOICE_PRIVACY_IND_V02:

      case QMI_VOICE_ALL_CALL_STATUS_IND_V02:
      {
	  	
        if(qmi_voice_all_call_status_ind(rx_msg_buf, rx_msg_len, &voice_get_all_call_info_ind) < 0)
        {
          QMI_ERR_MSG_0 ("[VOICE] qmi_voice_call_call_status_ind: fail\n ");
          return;
        }
		MSG_HIGH("[VOICE] QMI_VOICE_ALL_CALL_STATUS_IND_V02 = %d", 0, 0, 0);

		char inddatapack[512] ={0,};
		
		if (voice_get_all_call_info_ind.call_info_valid)
		{
		   update_g_voice_basic_call_info(voice_get_all_call_info_ind.call_info);
   		   int numberInstances = voice_get_all_call_info_ind.call_info_len;

		   char tmpstr[100] = {0,};
		   sprintf(tmpstr, "CALLEVENTRAWDATAV1:%d:", numberInstances);
		   strcat(inddatapack, tmpstr);

//		   printf("[JYP] num of calls : %d\n" ,numberInstances ) ;
		   int _i = 0;
		   for (_i = 0 ; _i < numberInstances ; _i++ )
		   	{
		   	
			int callId = voice_get_all_call_info_ind.call_info[_i].call_id;
			int callState = voice_get_all_call_info_ind.call_info[_i].call_state;
			int callType = voice_get_all_call_info_ind.call_info[_i].call_type;
			int callDirection = voice_get_all_call_info_ind.call_info[_i].direction;
			int callMode = voice_get_all_call_info_ind.call_info[_i].mode;
			char tmpstr[100] = {0,};
			sprintf(tmpstr, "%d:%d:%d:%d:%d:", callId, callState, callType, callDirection, callMode );
			strcat(inddatapack, tmpstr);

			//get phone number.. aleady parsed and saved during message received through QMI
			int callNumberLen = g_remote_party_number[_i].num_len;
			char* callNumber = g_remote_party_number[_i].num;
			sprintf(tmpstr, "%d:%s:", callNumberLen, callNumber);
			strcat(inddatapack, tmpstr);

//			printf("[JYP] QMI_VOICE_ALL_CALL_STATUS_IND_V02, callIO %d, callState %d, callType %d, dir %d, mode %d, len %d, number %s \n", callId, callState, callType, callDirection, callMode, callNumberLen, callNumber);
			

		   	}//for	
//			printf("[JYP] %s\n", inddatapack);		   	
			
		}
		
   
        if(voice_get_all_call_info_ind.call_end_reason_valid)
        {
          g_voice_call_end_reason = voice_get_all_call_info_ind.call_end_reason[0].call_end_reason;
          //MSG_HIGH("[VOICE] g_voice_call_end_reason = %d(%s)", g_voice_call_end_reason, get_voice_call_end_reason_string(g_voice_call_end_reason), 0);
        }

		int _j = 0;
		if(voice_get_all_call_info_ind.call_end_reason_valid) //jaeyong1.park end reason
		{
		  char tmpstr[100] = {0,};
		  sprintf(tmpstr, "CALLENDCAUSE:%d:", voice_get_all_call_info_ind.call_end_reason_len);
		  strcat(inddatapack, tmpstr);

		  for (_j=0; _j<voice_get_all_call_info_ind.call_end_reason_len; _j++)
		  {
		    sprintf(tmpstr, "%d:%d:", voice_get_all_call_info_ind.call_end_reason[_j].call_id, voice_get_all_call_info_ind.call_end_reason[_j].call_end_reason);
			strcat(inddatapack, tmpstr);
		  }	
		}
		
		if (voice_get_all_call_info_ind.call_info_valid)
		{
		  EventNotifyEnqueue(TOF_EVENT_RESPONSE_CALL_STATE_CHANGED_CALLMSG_RAWDATA, 0, inddatapack);
		}

        if(voice_get_all_call_info_ind.call_info_valid)
        {
          //update_g_voice_basic_call_info(voice_get_all_call_info_ind.call_info);	//dsji_20150323 disable

          if((wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ) || ( wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ))
          {
          	update_g_voice_basic_call_info(voice_get_all_call_info_ind.call_info);	//dsji_20150323 add
						
            if( CALL_STATE_CONVERSATION_V02 == voice_get_all_call_info_ind.call_info[0].call_state )
            {
              call_got_connected = TRUE;
            }

            if( CALL_STATE_END_V02 == voice_get_all_call_info_ind.call_info[0].call_state )
            {
              if( CALL_MODE_CDMA_V02 == voice_get_all_call_info_ind.call_info[0].mode           &&
                   CALL_TYPE_EMERGENCY_V02 == voice_get_all_call_info_ind.call_info[0].call_type &&
                   TRUE == call_got_connected )
              {
                qmi_ril_nwr_set_eme_cbm( QMI_RIL_EME_CBM_ACTIVE );
              }
              call_got_connected = FALSE;
            }
          }
        }

        // 20140710 VoLTE Ring Back Tone Play
        #ifdef FEATURE_LGIT_VOLTE_RING_BACK_TONE_PLAY
          if(voice_get_all_call_info_ind.call_info[0].call_state == CALL_STATE_ALERTING_V02)
          {
            if(voice_get_all_call_info_ind.alerting_type_valid == TRUE && 
                voice_get_all_call_info_ind.alerting_type[0].alerting_type == ALERTING_LOCAL_V02)
            {
              ring_back_tone_play_enable = TRUE;
            }
            else
            {
              ring_back_tone_play_enable = FALSE;
            }
          }
          else
          {        
            MSG_HIGH("[RED_VOICE] ring_back_tone_play_enable = %d", ring_back_tone_play_enable,0,0);
            ring_back_tone_play_enable = FALSE;
          }
        #endif

        voice_ind_id	= QMI_VOICE_CM_IF_CMD_ALL_CALL_STATUS_IND;
        voice_ind_data	= NULL;
      }
      break;

    //--> RIL_UNSOL_CDMA_OTA_PROVISION_STATUS
    case QMI_VOICE_OTASP_STATUS_IND_V02:
    #if 0 // fixed OTAPA-CSIM 8.5 failure
      if(wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW)
      {
        voice_ind_id	= QMI_VOICE_CM_IF_CMD_OTASP_STATUS_IND;
        if (qmi_voice_otasp_status_ind(rx_msg_buf,
                                       rx_msg_len,
                                       otasp_status_ind_ptr) < 0)
        {
          QMI_ERR_MSG_0 ("qmi_voice_srvc_indication_cb: Failure in OTASP status indication data\n ");
          return;
        }
        qmi_voice_otasp_status_ind_process(otasp_status_ind_ptr);
      }
      #endif
      break;
    //<-- RIL_UNSOL_CDMA_OTA_PROVISION_STATUS

    //--> RIL_UNSOL_CDMA_INFO_REC
    case QMI_VOICE_INFO_REC_IND_V02:
      voice_ind_id	= QMI_VOICE_CM_IF_CMD_INFO_REC_IND;
      if (qmi_voice_info_rec_ind(rx_msg_buf,
                                 rx_msg_len,
                                 &voice_info_rec_ind) < 0)
      {
        QMI_ERR_MSG_0 ("qmi_voice_srvc_indication_cb: Failure in CDMA Info Rec indication data\n ");
        return;
      }
      qmi_voice_info_rec_ind_process(&voice_info_rec_ind);
      break;
    //<-- RIL_UNSOL_CDMA_INFO_REC

	  //case QMI_VOICE_SUPS_NOTIFICATION_IND_V02:
	  //dsji_20140402 add {
		  //dsji_20130702 add {
	  case QMI_VOICE_USSD_IND_V02:
		{
			if ( QMI_NO_ERR != qmi_voice_ussd_ind( rx_msg_buf, rx_msg_len, &voice_ussd_ind ) )
			{
				//error
				return;
			}

			voice_ind_id = QMI_VOICE_CM_IF_CMD_SUPS_USSD_IND;
			voice_ind_data = (void*)&voice_ussd_ind;
		}
		break;
		//dsji_20130702 add }
		//dsji_20140402 add }
	  //case QMI_VOICE_UUS_IND_V02:
	  //case QMI_VOICE_SUPS_IND_V02:
	  //case QMI_VOICE_ORIG_USSD_NO_WAIT_IND_V02:
	  //case QMI_VOICE_AOC_LOW_FUNDS_IND_V02:
	  //case QMI_VOICE_MODIFIED_IND_V02:
	  //case QMI_VOICE_MODIFY_ACCEPT_IND_V02:

    case QMI_VOICE_SPEECH_CODEC_INFO_IND_V02:
    {
      if(qmi_voice_speech_codec_info_ind(rx_msg_buf, rx_msg_len, &voice_speech_codec_info_ind) < 0)
      {
        QMI_ERR_MSG_0 ("[VOICE] qmi_voice_call_call_status_ind: fail\n ");
        return;
      }
      g_voice_speech_codec = voice_speech_codec_info_ind.speech_codec;

      MSG_HIGH("[VOICE] Codec_Info - network %d codec = %d frequency = %d", 
                voice_speech_codec_info_ind.network_mode,
                voice_speech_codec_info_ind.speech_codec,
                voice_speech_codec_info_ind.speech_enc_samp_freq);
    }
    break;

	  //case QMI_VOICE_HANDOVER_IND_V02:
	  //case QMI_VOICE_CONFERENCE_INFO_IND_V02:
	  //case QMI_VOICE_CONFERENCE_JOIN_IND_V02:
	  //case QMI_VOICE_CONFERENCE_PARTICIPANT_UPDATE_IND_V02:
	  //case QMI_VOICE_EXT_BRST_INTL_IND_V02:
	  
	//20161012 yjoh, add eCall ind
	case QMI_VOICE_ECALL_EVENT_IND_V02:
			if ( QMI_NO_ERR != qmi_voice_ecall_event_ind( rx_msg_buf, rx_msg_len, &voice_ecall_ind ) )
			{
				//error
				return;
			}

			voice_ind_id = QMI_VOICE_CM_IF_CMD_ECALL_EVENT_IND;
			voice_ind_data = (void*)&voice_ecall_ind;
	break;
		
	  default:
		  MSG_ERROR( "[VOICE] qmi_voice_srvc_indication_cb() fail, invalid msg id:%d", msg_id, 0, 0 );
		  break;
	}

	if ( QMI_VOICE_CM_IF_CMD_INVALID_IND != voice_ind_id )
	{
		voice_user_ind_hdlr = (qmi_voice_indication_hdlr_type)user_ind_msg_hdlr;

		voice_user_ind_hdlr( user_handle,
							 service_id,
							 user_ind_msg_hdlr_user_data,
							 voice_ind_id,
							 voice_ind_data );
	}
}


static void	qmi_voice_srvc_async_cb( int                    user_handle,
									 qmi_service_id_type    service_id,
									 unsigned long          msg_id,
									 int                    rsp_rc,
									 int                    qmi_err_code,
									 unsigned char*			reply_msg_data,
									 int					reply_msg_size,
									 void*					srvc_async_cb_data,
									 void*					user_async_cb_fn,
									 void*					user_async_cb_data )
{
	void* rsp = NULL;

	voice_dial_call_resp_msg_v02			voice_dial_call_rsp;
	voice_end_call_resp_msg_v02				voice_end_call_rsp;
	voice_answer_call_resp_msg_v02			voice_answer_call_rsp;
	voice_manage_calls_resp_msg_v02			voice_manage_calls_rsp;
	voice_get_all_call_info_resp_msg_v02	voice_get_all_call_info_rsp;

	memset( &voice_dial_call_rsp, 0x0, sizeof( voice_dial_call_rsp ) );
	memset( &voice_end_call_rsp, 0x0, sizeof( voice_end_call_rsp ) );
	memset( &voice_answer_call_rsp, 0x0, sizeof( voice_answer_call_rsp ) );
	memset( &voice_manage_calls_rsp, 0x0, sizeof( voice_manage_calls_rsp ) );
	memset( &voice_get_all_call_info_rsp, 0x0, sizeof( voice_get_all_call_info_rsp ) );

	switch ( msg_id )
	{
	case QMI_VOICE_DIAL_CALL_REQ_V02:			rsp = &voice_dial_call_rsp;			break;
	case QMI_VOICE_END_CALL_REQ_V02:			rsp = &voice_end_call_rsp;			break;
	case QMI_VOICE_ANSWER_CALL_REQ_V02:			rsp = &voice_answer_call_rsp;		break;
	case QMI_VOICE_MANAGE_CALLS_REQ_V02:		rsp = &voice_manage_calls_rsp;		break;
	case QMI_VOICE_GET_ALL_CALL_INFO_REQ_V02:	rsp = &voice_get_all_call_info_rsp;	break;
	}

	qmi_voice_rsp_read_tlv( qmi_err_code, msg_id, reply_msg_data, reply_msg_size, rsp );
}

/*===========================================================================
  FUNCTION  qmi_voice_reg_ind_hdlr
===========================================================================*/
/*!
@brief 
  This function is a callback that will be called once during client
  initialization  
  
@return 
  None.

@note

  - Dependencies
    - None.

  - Side Effects
    - None.
*/    
/*=========================================================================*/
int qmi_voice_reg_ind_hdlr (qmi_voice_indication_hdlr_type  user_ind_msg_hdlr)
{
  int  rc = QMI_NO_ERR;
  if (!voice_service_initialized)
  {

    rc = qmi_service_set_srvc_functions (QMI_VOICE_SERVICE,
                                 user_ind_msg_hdlr);
    if (rc != QMI_NO_ERR)
    {
      MSG_ERROR("qmi_voice_srvc_init: set srvc functions returns err=%d\n",rc,0,0);
    }
    else
    {
      MSG_LOW("qmi_voice_srvc_init: Voice successfully initialized\r\n",0,0,0);
      voice_service_initialized = TRUE;
    }
  }
  else
  {
    MSG_ERROR("qmi_voice_srvc_init: Init failed, Voice already initialized\r\n",0,0,0);
  }
  return rc;
}

/*===========================================================================
  FUNCTION  tof_qmi_voice_srvc_init_client
===========================================================================*/
/*!
@brief 
  This function is called to initialize the VOICE service.  This function
  must be called prior to calling any other VOICE service functions.
  For the time being, the indication handler callback and user data
  should be set to NULL until this is implemented.  Also note that this
  function may be called multiple times to allow for multiple, independent
  clients.   
  
@return 
  0 if abort operation was sucessful, < 0 if not.  If return code is 
  QMI_INTERNAL_ERR, then the qmi_err_code will be valid and will 
  indicate which QMI error occurred.

@note

  - Dependencies
    - qmi_connection_init() must be called for the associated port first.

  - Side Effects
    - Talks to modem processor
*/    
/*=========================================================================*/
qmi_client_handle_type tof_qmi_voice_srvc_init_client(    
	const char                   *dev_id,
  qmi_voice_indication_hdlr_type  user_ind_msg_hdlr,
  void                          *user_ind_msg_hdlr_user_data,
  int                           *qmi_err_code )
{

  qmi_client_handle_type client_handle;
  qmi_connection_id_type conn_id;

  MSG_LOW("tof_qmi_voice_srvc_init_client\r\n",0,0,0);
  
  if ((conn_id = QMI_PLATFORM_DEV_NAME_TO_CONN_ID(dev_id)) == QMI_CONN_ID_INVALID)
  {
    MSG_ERROR("tof_qmi_voice_srvc_init_client: conn_id fail %x\r\n",conn_id,0,0);
    return QMI_INTERNAL_ERR;
  }

  MSG_LOW("tof_qmi_voice_srvc_init_client: conn_id %x\r\n",conn_id,0,0);
  
   /* Call common service layer initialization function */
  /*lint -e{611} */
  client_handle =  qmi_service_init (conn_id,
                                   QMI_VOICE_SERVICE,
                                   (void *) user_ind_msg_hdlr,
                                   user_ind_msg_hdlr_user_data,
                                   qmi_err_code);
 
 
  if(client_handle > 0)  
    qmi_voice_reg_ind_hdlr(qmi_voice_srvc_indication_cb);
  else 
    MSG_ERROR("tof_qmi_voice_srvc_init_client: client_handle  0x%x failed \r\n",client_handle,0,0);


  return client_handle;

}



/*===========================================================================
  FUNCTION  tof_tof_qmi_voice_srvc_release_client
===========================================================================*/
/*!
@brief 
  This function is called to release a client created by the 
  qmi_voice_srvc_init_client() function.  This function should be called
  for any client created when terminating a client process, especially
  if the modem processor is not reset.  The modem side QMI server has 
  a limited number of clients that it will allocate, and if they are not
  released, we will run out.  
  
@return 
  0 if abort operation was sucessful, < 0 if not.  If return code is 
  QMI_INTERNAL_ERR, then the qmi_err_code will be valid and will 
  indicate which QMI error occurred.

@note

  - Dependencies
    - qmi_connection_init() must be called for the associated port first.

  - Side Effects
    - Talks to modem processor
*/    
/*=========================================================================*/
int	tof_tof_qmi_voice_srvc_release_client( int user_handle,
								   int *qmi_err_code )
{

  int  rc = QMI_NO_ERR;

	rc = qmi_service_release (user_handle, qmi_err_code);

	if (voice_service_initialized)
  {
  	rc = qmi_service_set_srvc_functions (QMI_VOICE_SERVICE,NULL);
		if (rc != QMI_NO_ERR)
		{
			MSG_ERROR("tof_qmi_voice_srvc_release: set srvc functions returns err=%d\n",rc,0,0);
		}
		else
		{
			MSG_LOW("tof_qmi_voice_srvc_release: VOICE successfully released\r\n",0,0,0);
			voice_service_initialized = FALSE;
		}
	}
	else
	{
		MSG_ERROR("tof_qmi_voice_srvc_release: Release failed, VOICE not initialized\r\n",0,0,0);
	}
	
	return rc;		
}

/*===========================================================================
  FUNCTION  qmi_voice_indication_register
===========================================================================*/
/*!
@brief 
  Set the VOICE indication registration state for specified control point.
     
  
@return 

@note

  - Dependencies
    - qmi_qos_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int	qmi_voice_indication_register( int				client_handle,
								   unsigned int		voice_ind_reg_mask,
								   int*				qmi_err_code )
{
	int i;
	int r;

	unsigned char	msg[ QMI_MAX_STD_MSG_SIZE ];
	unsigned char*	tmp_msg_ptr;

	int				msg_size;

	unsigned char   tlv[ 5 ];
	unsigned char*	temp_tlv_ptr;

	int				enable = TRUE;

	tmp_msg_ptr = QMI_SRVC_PDU_PTR( msg );
	msg_size = QMI_SRVC_PDU_SIZE( QMI_VOICE_STD_MSG_SIZE );

	for ( i = 0; i < sizeof( g_voice_ind_reg_conv_table ) / sizeof( voice_ind_reg_conv_table_type ) ; ++i )
	{
		if ( voice_ind_reg_mask & g_voice_ind_reg_conv_table[ i ].voice_ind_reg_mask )
		{
			temp_tlv_ptr = tlv;

			WRITE_8_BIT_VAL( temp_tlv_ptr, enable );
			
			if ( qmi_util_write_std_tlv( &tmp_msg_ptr,
										 &msg_size,
										 g_voice_ind_reg_conv_table[ i ].voice_ind_reg_val,
										 1,
										 (void *)tlv ) < 0 )
			{
				return QMI_INTERNAL_ERR;
			}
		}
	}

	r = qmi_service_send_msg_sync( client_handle,
								   QMI_VOICE_SERVICE,
								   QMI_VOICE_INDICATION_REGISTER_REQ_V02,
								   QMI_SRVC_PDU_PTR( msg ),
								   QMI_SRVC_PDU_SIZE( QMI_VOICE_STD_MSG_SIZE ) - msg_size,
								   msg,
								   &msg_size,
								   QMI_VOICE_STD_MSG_SIZE,
								   QMI_SYNC_MSG_DEFAULT_TIMEOUT,
								   qmi_err_code );
	return r;
}




int	qmi_voice_msg_req( int client_handle,
					   int qmi_voice_msg_id,
					   void* req_data,
					   void* rsp_data,
					   qmi_voice_user_async_cb_type	user_cb,
					   void* user_data )
{
	int				r = QMI_NO_ERR;
	int				qmi_err_code = QMI_SERVICE_ERR_NONE;

	unsigned char	msg[ QMI_VOICE_STD_MSG_SIZE ];
	int				msg_size = 0;
	unsigned char*	tmp_msg_ptr;

	if ( NULL == user_cb && NULL == rsp_data )
		return QMI_SERVICE_ERR;

	tmp_msg_ptr = QMI_SRVC_PDU_PTR( msg );
	msg_size	= QMI_SRVC_PDU_SIZE( QMI_VOICE_STD_MSG_SIZE );

	if ( qmi_voice_req_write_tlv( qmi_voice_msg_id, &tmp_msg_ptr, &msg_size, req_data ) < 0 )
	{
       MSG_ERROR( "[VOICE] qmi_voice_msg_req(),  error:%d", QMI_INTERNAL_ERR, 0, 0 );

		return QMI_INTERNAL_ERR;
	}

	if ( NULL == user_cb )
	{
		r = qmi_service_send_msg_sync( client_handle,
									   QMI_VOICE_SERVICE,
									   qmi_voice_msg_id,
									   QMI_SRVC_PDU_PTR( msg ),
									   (int)QMI_SRVC_PDU_SIZE( QMI_VOICE_STD_MSG_SIZE ) - msg_size,
									   msg,                 
									   &msg_size,
									   QMI_VOICE_STD_MSG_SIZE,
									   /*QMI_SYNC_MSG_DEFAULT_TIMEOUT*/5,
									   &qmi_err_code );

       MSG_ERROR( "[VOICE] qmi_service_send_msg_sync(),  qmi_err_code:%d",qmi_err_code, 0, 0 );
			 
		if ( QMI_NO_ERR == r )
		{
			if ( NULL != rsp_data )
			{
				r = qmi_voice_rsp_read_tlv( qmi_err_code, qmi_voice_msg_id, msg, msg_size, rsp_data );
			}
		}
	}
	else
	{
		r = qmi_service_send_msg_async( client_handle,
										QMI_VOICE_SERVICE,
										qmi_voice_msg_id,
										QMI_SRVC_PDU_PTR( msg ),
										(int)QMI_SRVC_PDU_SIZE( QMI_VOICE_STD_MSG_SIZE ) - msg_size,
										qmi_voice_srvc_async_cb,
										NULL,
										(void *)user_cb,
										user_data );
		MSG_ERROR( "[VOICE] qmi_service_send_msg_async(),  error:%d", r, 0, 0 );
	}
	
	return r;
}
