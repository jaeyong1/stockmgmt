/******************************************************************************
  @file    qmi_loc_lgit.h
  @brief   The QMI TOF API

  DESCRIPTION
  This file contains a API to use a QMI of modem processor.
  
  INITIALIZATION AND SEQUENCING REQUIREMENTS

  ---------------------------------------------------------------------------
  Copyright (c) 2016 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/
#include "location_service_v02.h"
#include "TOF_Definition.h"
#include "wmmdiag_packet.h"

/*=================== Definition ================================*/
#define QMI_LOC_SERVICE 0x10

#define QMI_GPS_FIX_TIMEOUT  (1*1000) /* GPS Timer of 1 secs as a default Interval Timer */

#define QMI_LOC_STD_MSG_SIZE QMI_MAX_STD_MSG_SIZE

#define QMI_TYPE_RESULT_CODE          (0x02)

#define LOC_API_MAX_NMEA_STRING_LENGTH            200

/*=================== Structure ================================*/
typedef enum
{
  QMI_LOC_SRVC_INVALID_IND_MSG,
  QMI_LOC_EVENT_POSITION_REPORT_IND_MSG,
  QMI_LOC_EVENT_GNSS_SV_INFO_IND_MSG,
  QMI_LOC_EVENT_NMEA_IND_MSG,
  QMI_LOC_EVENT_NI_NOTIFY_VERIFY_REQ_IND_MSG,
  QMI_LOC_EVENT_INJECT_TIME_REQ_IND_MSG,
  QMI_LOC_EVENT_INJECT_PREDICTED_ORBITS_REQ_IND_MSG,
  QMI_LOC_EVENT_INJECT_POSITION_REQ_IND_MSG,
  QMI_LOC_EVENT_ENGINE_STATE_IND_MSG,
  QMI_LOC_EVENT_FIX_SESSION_STATE_IND_MSG,
  QMI_LOC_EVENT_WIFI_REQ_IND_MSG,
  QMI_LOC_EVENT_SENSOR_STREAMING_READY_STATUS_IND_MSG,
  QMI_LOC_EVENT_TIME_SYNC_REQ_IND_MSG,
  QMI_LOC_EVENT_SET_SPI_STREAMING_REPORT_IND_MSG,
  QMI_LOC_EVENT_LOCATION_SERVER_CONNECTION_REQ_IND_MSG,
  QMI_LOC_GET_SERVICE_REVISION_IND_MSG,
  QMI_LOC_GET_FIX_CRITERIA_IND_MSG,
  QMI_LOC_NI_USER_RESPONSE_IND_MSG,
  QMI_LOC_INJECT_PREDICTED_ORBITS_DATA_IND_MSG,
  QMI_LOC_GET_PREDICTED_ORBITS_DATA_SOURCE_IND_MSG,
  QMI_LOC_GET_PREDICTED_ORBITS_DATA_VALIDITY_IND_MSG,
  QMI_LOC_INJECT_UTC_TIME_IND_MSG,
  QMI_LOC_INJECT_POSITION_IND_MSG,
  // Added Jamming detection Indication
  QMI_LOC_EVENT_JAMMING_RF_REPORT_IND_MSG,  
  /* To be filled in in future release */
} qmi_loc_indication_id_type;

#define LOC_POS_REPT_SESSION_STATUS             0x01 /* Session Status */
#define LOC_POS_REPT_SESSION_ID                 0x02 /* Session ID */

#define LOC_POS_REPT_LATITUDE                   0x10 /* latitude */
#define LOC_POS_REPT_LONGITUDE                  0x11 /* longitude */
#define LOC_POS_REPT_CIR_HORIZ_POS_UNCERT       0x12 /* horUncCircular */
#define LOC_POS_REPT_HORIZ_ELLIP_UNCERT_MINOR   0x13 /* horUncEllipseSemiMinor */
#define LOC_POS_REPT_HORIZ_ELLIP_UNSERT_MAJOR   0x14 /* horUncEllipseSemiMajor */
#define LOC_POS_REPT_ELLIP_HORIZ_UNCERT_AZI     0x15 /* horUncEllipseOrientAzimuth */
#define LOC_POS_REPT_HORIZ_CONFIDENCE           0x16 /* horConfidence */
#define LOC_POS_REPT_HORIZ_RELIABILITY          0x17 /* horReliability */
#define LOC_POS_REPT_HORIZ_SPEED                0x18 /* speedHorizontal */
#define LOC_POS_REPT_SPEED_UNCERT               0x19 /* speedUnc */
#define LOC_POS_REPT_ALTI_WITH_RESP_ELLIP       0x1A /* altitudeWrtEllipsoid */
#define LOC_POS_REPT_ALTIT_WITH_RESP_SEA_LEVEL  0x1B /* altitudeWrtMeanSeaLevel */
#define LOC_POS_REPT_VERTICAL_UNCERT            0x1C /* vertUnc */
#define LOC_POS_REPT_VERTICAL_CONFIDENCE        0x1D /* vertConfidence */
#define LOC_POS_REPT_VERTICAL_ELIABILITY        0x1E /* vertReliability */
#define LOC_POS_REPT_VERTICAL_SPEEDD            0x1F /* speedVertical */
#define LOC_POS_REPT_HEADING                    0x20 /* heading */
#define LOC_POS_REPT_HEADING_UNCERT             0x21 /* headingUnc */
#define LOC_POS_REPT_MAGNETIC_DEVIATION         0x22 /* magneticDeviation */
#define LOC_POS_REPT_TECH_USED                  0x23 /* technologyMask */
#define LOC_POS_REPT_DILUTION_PRECISION         0x24 /* DOP */
#define LOC_POS_REPT_UTC_TIMESTAMP              0x25 /* timestampUtc */
#define LOC_POS_REPT_LEAP_SEC                   0x26 /* leapSeconds */
#define LOC_POS_REPT_GPS_TIME                   0x27 /* gpsTime */
#define LOC_POS_REPT_TIME_UNCERT                0x28 /* timeUnc */
#define LOC_POS_REPT_TIME_SOURCE                0x29 /* timeSrc */
#define LOC_POS_REPT_SENSOR_DATA_USAGE          0x2A /* sensorDataUsage */
#define LOC_POS_REPT_FIX_CNT_FOR_THIS_SESSION   0x2B /* fixId */
#define LOC_POS_REPT_SVC_USED_TO_CALC_FIX       0x2C /* gnssSvUsedList */
#define LOC_POS_REPT_ALTITUDE_ASSUMED           0x2D /* altitudeAssumed */

//add QMI_LOC_EVENT_GNSS_SV_INFO
#define LOC_POS_GNSS_SV_ALTITUDE_ASSUMED        0x01 /* altitudeAssumed */
#define LOC_POS_GNSS_SV_SATELLITE_INFO          0x10 /* Satellite Info */

// Added Jamming detection Indication
#define LOC_POS_JAMMING_RF_PGAGAIN        0x01 /* l_PGAGain */
#define LOC_POS_JAMMING_RF_BP1LBWAMPLII        0x02 /* Bp1LbwAmplI */
#define LOC_POS_JAMMING_RF_BP1LBWAMPLIQ        0x03 /* Bp1LbwAmplQ */
#define LOC_POS_JAMMING_RF_BP3LBWAMPLII        0x04 /* Bp3GloAmplI */
#define LOC_POS_JAMMING_RF_BP3LBWAMPLIQ        0x05 /* Bp3GloAmplQ */

typedef enum{
  LOC_EVENT_MASK_POSITION_REPORT =0 , 
  LOC_EVENT_MASK_GNSS_SV_INFO ,
  LOC_EVENT_MASK_NMEA , 
  LOC_EVENT_MASK_NI_NOTIFY_VERIFY_REQ , 
  LOC_EVENT_MASK_INJECT_TIME_REQ , 
  LOC_EVENT_MASK_INJECT_PREDICTED_ORBITS_REQ ,
  LOC_EVENT_MASK_INJECT_POSITION_REQ , 
  LOC_EVENT_MASK_ENGINE_STATE , 
  LOC_EVENT_MASK_FIX_SESSION_STATE , 
  LOC_EVENT_MASK_WIFI_REQ , 
  LOC_EVENT_MASK_SENSOR_STREAMING_READY_STATUS ,
  LOC_EVENT_MASK_TIME_SYNC_REQ , 
  LOC_EVENT_MASK_SET_SPI_STREAMING_REPORT ,
  LOC_EVENT_MASK_LOCATION_SERVER_CONNECTION_REQ ,
  LOC_EVENT_MASK_NI_GEOFENCE_NOTIFICATION ,
  LOC_EVENT_MASK_GEOFENCE_GEN_ALERT , 
  LOC_EVENT_MASK_GEOFENCE_BREACH_NOTIFICATION , 
  LOC_EVENT_MASK_PEDOMETER_CONTROL , 
  LOC_EVENT_MASK_MOTION_DATA_CONTROL , 
  LOC_EVENT_MASK_BATCH_FULL_NOTIFICATION , 
  LOC_EVENT_MASK_LIVE_BATCHED_POSITION_REPORT ,
  LOC_EVENT_MASK_INJECT_WIFI_AP_DATA_REQ ,
  LOC_EVENT_MASK_GEOFENCE_BATCH_BREACH_NOTIFICATION ,
  LOC_EVENT_MASK_VEHICLE_DATA_READY_STATUS , 
  LOC_EVENT_MASK_GNSS_MEASUREMENT_REPORT ,
  LOC_EVENT_MASK_GNSS_SV_POLYNOMIAL_REPORT ,
  LOC_EVENT_MASK_GEOFENCE_PROXIMITY_NOTIFICATION ,
  LOC_EVENT_MASK_GDT_UPLOAD_BEGIN_REQ , 
  LOC_EVENT_MASK_GDT_UPLOAD_END_REQ , 
  LOC_EVENT_MASK_GEOFENCE_BATCH_DWELL_NOTIFICATION ,
  LOC_EVENT_MASK_GET_TIME_ZONE_REQ , 
  LOC_EVENT_MASK_BATCHING_STATUS,
  LOC_EVENT_MASK_MAX
}loc_local_reg_event_mask_type;

typedef enum {
  LOC_OPER_MODE_DEFAULT     = 1, /**<  Use the default engine mode  */
  LOC_OPER_MODE_MSB         = 2, /**<  Use the MS-based mode  */
  LOC_OPER_MODE_MSA         = 3, /**<  Use the MS-assisted mode  */
  LOC_OPER_MODE_STANDALONE  = 4, /**<  Use Standalone mode  */
  LOC_OPER_MODE_CELL_ID     = 5, /**<  Use cell ID; this mode is only valid for GSM/UMTS networks  */
  LOC_OPER_MODE_WWAN        = 6, /**<  Use WWAN measurements to calculate the position; if this mode is
       set, AFLT will be used for 1X networks and OTDOA will be used
       for LTE networks  */
}loc_oper_mode_type;

typedef enum{
  LOC_AGPS_REG_EVT_REQ_MSG_ST          = 0,
  LOC_AGPS_SET_NMEA_TYPE_REQ_MSG_ST    = 1,
  LOC_AGPS_SET_OPER_MODE_REQ_MSG_ST    = 2,
  LOC_AGPS_SET_SERVER_REQ_MSG_ST       = 3,
  LOC_AGPS_START_REQMSG_ST             = 4,
  LOC_AGPS_SET_CONN_SERVER_REQ_MSG_ST  = 5,
}loc_agps_curr_step_type;

typedef struct{
  loc_oper_mode_type    curr_mode;
  loc_agps_curr_step_type curr_state;
  
}loc_agps_status_type;

typedef struct{
  loc_oper_mode_type          curr_mode;
  qmiLocNmeaSentenceMaskT_v02 curr_nmeaSentenceType;
  qmiLocEventRegMaskT_v02     curr_eventRegMask_qti;
  qmiLocSetServerReqMsgT_v02  curr_serverReqMsg[4];
}loc_static_curr_set_val_type;

typedef struct{
  loc_local_reg_event_mask_type local_type;
  uint64  qmi_type;
}loc_event_mask_convert_type;

/* Async notification reporting structure */
typedef union
{
  qmiLocEventPositionReportIndMsgT_v02  loc_position_report;
} qmi_loc_indication_data_type;

// Added Jamming detection Indication
typedef union
{
  qmiLocEventJammingRFIndMsgT_v02  loc_jamming_rf_report;
} qmi_loc_jamming_rf_data_type;

typedef union
{
  qmiLocEventNmeaIndMsgT_v02  loc_nmea_report;
} qmi_loc_indication_nmea_data_type;

typedef union
{
  qmiLocEventGnssSvInfoIndMsgT_v02  loc_gnss_sv_report;
} qmi_loc_indication_gnss_sv_data_type;

typedef void (*qmi_loc_indication_hdlr_type)
( 
  int                           user_handle,
  qmi_service_id_type           service_id,
  void                          *user_data,
  qmi_loc_indication_id_type    ind_id,
  qmi_loc_indication_data_type  *ind_data
);

typedef void (*qmi_loc_user_async_cb_type)( int user_handle,
                        qmi_service_id_type   service_id,
                        void*                 user_data );
typedef struct{
  uint8 time_cnt_id;
  uint16 time_count; /* ms (milliseconds)*/
  boolean alive_timer;
  boolean time_cnt_act;
  uint32 time_wait_count;
}loc_time_count_type;

/*---------------------------------------------------------------------------
 QMI_LOC_SET_EVENT_MASK
---------------------------------------------------------------------------*/
#define LOC_0021_REQ_T01        (0x01)

typedef struct {
  struct loc_0021_req_t01_s {
    uint64 event_mask;  
  } t01;

  boolean t01_valid;
}loc_0021_req_s;


/*========================== Servie Function ================================*/
/*===========================================================================

  FUNCTION  tof_qmi_loc_init
  
===========================================================================*/
extern boolean	tof_qmi_loc_init( void );
extern boolean	tof_qmi_loc_release( void );

EXTERN qmi_client_handle_type
tof_qmi_loc_srvc_init_client
(
   const char                   *dev_id,
  qmi_loc_indication_hdlr_type  user_ind_msg_hdlr,
  void                          *user_ind_msg_hdlr_user_data,
  int                           *qmi_err_code
);


EXTERN int 
tof_tof_qmi_loc_srvc_release_client
(
  int      user_handle,
  int      *qmi_err_code
);

/*===========================================================================
  FUNCTION  loc_init_static_curr_set_val
===========================================================================*/
/*!
@brief 
  This function is used to initialize a static variable for GPS parameters.  
  
@return 
  None.

@note

  - Dependencies
    - None.

  - Side Effects
    - None.
*/    
/*=========================================================================*/
void loc_init_static_curr_set_val(void);

/*===========================================================================
  FUNCTION  qmi_loc_reg_ind_hdlr
===========================================================================*/
/*!
@brief 
  This function is a callback that will be called once during client
  initialization  
  
@return 
  None.

@note

  - Dependencies
    - None.

  - Side Effects
    - None.
*/    
/*=========================================================================*/
int qmi_loc_reg_ind_hdlr (qmi_service_ind_rx_hdlr  user_ind_msg_hdlr);

/*===========================================================================
  FUNCTION  qmi_loc_srvc_indication_cb
===========================================================================*/
/*!
@brief 
  This is the callback function that will be called by the generic
  services layer to report asynchronous indications.  This function will
  process the indication TLV's and then call the user registered
  functions with the indication data.   
  
@return 
  None.

@note

  - Dependencies

  - Side Effects
*/    
/*=========================================================================*/

static void
qmi_loc_srvc_indication_cb
(
  int                   user_handle,
  qmi_service_id_type   service_id,
  unsigned long         msg_id,
  void                                *user_ind_msg_hdlr,
  void                                *user_ind_msg_hdlr_user_data,
  unsigned char         *rx_msg_buf,
  int                   rx_msg_len
);

/*===========================================================================

  FUNCTION  qmi_loc_position_report_ind

  Description : FOR the TOF of Clarion, this function is only returned a "Latitude", "Longitude" and "Time Stamp".
                    Please keep in mind that If you want to have more information returned, you must change this function 
                    to what you want to make.

===========================================================================*/
static int qmi_loc_position_report_ind
(
  unsigned char                                   *rx_buf,
  int                                             rx_buf_len,
  qmiLocEventPositionReportIndMsgT_v02            *t_position_report_ind
);

/*===========================================================================

  FUNCTION  qmi_loc_position_nmea_report_ind

  Description : FOR the TOF of Clarion, this function is only returned NMEA.
                    Please keep in mind that If you want to have more information returned, you must change this function 
                    to what you want to make.

===========================================================================*/
static int qmi_loc_position_nmea_report_ind
(
  unsigned char                                   *rx_msg,
  int                                             rx_msg_size,
  qmiLocEventNmeaIndMsgT_v02 *t_position_nmea_report_ind
);

/*===========================================================================

  FUNCTION  qmi_loc_gnss_sv_info_report_ind

  Description : FOR the TOF of Clarion, this function is only returned a "Latitude", "Longitude" and "Time Stamp".
                    Please keep in mind that If you want to have more information returned, you must change this function 
                    to what you want to make.

===========================================================================*/
static int qmi_loc_gnss_sv_info_report_ind
(
  unsigned char                                   *rx_buf,
  int                                             rx_buf_len,
  qmiLocEventGnssSvInfoIndMsgT_v02            *t_event_gnss_sv_info_ind
);

// Added Jamming detection Indication
static int qmi_loc_jamming_rf_report_ind
(
  unsigned char                                   *rx_buf,
  int                                             rx_buf_len,
  qmiLocEventJammingRFIndMsgT_v02 *t_jamming_rf_ind
);

/*===========================================================================
FUNCTION       QMI_LOC_CLIENT_ERROR_CB

DESCRIPTION 
  QMI_LOC error callback handler. This callback is called by QCCI
  to notify error.

DEPENDENCIES  

RETURN VALUE 
  None 

SIDE EFFECTS 
  None 
===========================================================================*/
void qmi_loc_client_error_cb
(
  int user_handle,
  int error,
  void *err_cb_data
);

/*===========================================================================
  FUNCTION  qmi_nas_indication_register
===========================================================================*/
/*!
@brief 
  Set the NAS indication registration state for specified control point.
     
  
@return 

@note

  - Dependencies
    - qmi_qos_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
EXTERN int
qmi_loc_indication_register
(
  int                                     client_handle,
  loc_0021_req_s                  *loc_0021_req,
  int                                    *qmi_err_code
);


/*===========================================================================
FUNCTION QMI_LOC_CLIENT_REGISTER_EVENT

DESCRIPTION


DEPENDENCIES  

RETURN VALUE 
  None

SIDE EFFECTS 
  None
===========================================================================*/
void qmi_loc_client_register_event
(
  TOF_Loc_Event_Reg_Mask_type local_EvtRegMask
);

/*===========================================================================
FUNCTION       QMI_LOC_REG_EVENT_TYPE_CONVERT

DESCRIPTION 
  This is used to convert a local_reg_event_id to QMI REG EVENT ID.

DEPENDENCIES  

RETURN VALUE 
  None 

SIDE EFFECTS 
  None 
===========================================================================*/

uint32 qmi_loc_reg_event_type_convert(uint8 local_event_type);

/*===========================================================================
FUNCTION  QMI_LOC_CLIENT_RECV_LOC_START_RESP

DESCRIPTION 
  Handle callbacks response of QMI_LOC_START_REQ_V02 and
  QMI_LOC_REG_EVENTS_REQ_V02.

DEPENDENCIES 
  FEATURE_ECALL_HAS_QMI_LOC

RETURN VALUE 
  None 

SIDE EFFECTS 
  Release the memory assigned for response
===========================================================================*/
#if 0
void qmi_loc_client_recv_loc_start_resp
(
 int                            user_handle,
 unsigned int                   msg_id,
 void                          *resp_c_struct,
 unsigned int                   resp_c_struct_len,
 void                          *resp_cb_data,
 int                            transp_err
);
#else
void qmi_loc_client_recv_loc_start_resp( int             qmi_err_code,
                                    int             msg_id,
                                    unsigned char*  msg,
                                    int             msg_size,
                                    void*           rsp );
#endif
/*===========================================================================
FUNCTION       QMI_LOC_GET_POSITION_START

DESCRIPTION
  This function will send the QMI_LOC_START_REQ_V02 command to QMI_LOC
  to start the location session.

DEPENDENCIES 
  FEATURE_ECALL_HAS_QMI_LOC 

RETURN VALUE 
  None

SIDE EFFECTS 
  None
===========================================================================*/
void qmi_loc_get_position_start
(
  uint32 gnss_update_time_ms
);

/*===========================================================================
FUNCTION       QMI_LOC_GET_POSITION_STOP

DESCRIPTION
  This function will send the QMI_LOC_STOP_REQ_V02 command to QMI_LOC
  to stop the location session.

DEPENDENCIES 
  FEATURE_ECALL_HAS_QMI_LOC 

RETURN VALUE 
  None

SIDE EFFECTS 
  None
===========================================================================*/
void qmi_loc_get_position_stop
(
  void
);

boolean loc_set_curr_gps_mode(loc_oper_mode_type gps_mode);

int qmi_loc_set_supl_server_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  qmiLocSetServerIndMsgT_v02            *supl_server_info_req
);

int  qmi_loc_get_supl_server_info
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  qmiLocGetServerIndMsgT_v02        *supl_server_Ind
);

int qmi_loc_del_assist_data
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  qmiLocDeleteAssistDataIndMsgT_v02            *del_assist_data_req
);

static void qmi_loc_srvc_async_cb( int   user_handle,
                    qmi_service_id_type     service_id,
                    unsigned long           msg_id,
                    int                     rsp_rc,
                    int                     qmi_err_code,
                    unsigned char*          reply_msg_data,
                    int                     reply_msg_size,
                    void*                   srvc_async_cb_data,
                    void*                   user_async_cb_fn,
                    void*                   user_async_cb_data );

static int  qmi_loc_req_write_tlv( 
                   int        msg_id,
                   unsigned char**  msg,
                   int*        msg_size,
                   void*        req );

static int qmi_loc_reg_event_ind(                                     
                   int             qmi_err_code,
                   int             msg_id,
                   unsigned char*  msg,
                   int             msg_size,
                   void*           rsp );

static int qmi_loc_set_operation_mode_info(
                  unsigned char                     *rx_buf,
                  int                               rx_buf_len,
                  qmiLocSetOperationModeIndMsgT_v02            *operation_mode_rsp);


static int qmi_loc_get_operation_mode_info(
                   unsigned char                     *rx_buf,
                   int                               rx_buf_len,
                   qmiLocGetOperationModeIndMsgT_v02            *operation_mode_rsp);

static int qmi_loc_set_nmea_type_info(
                  unsigned char                     *rx_buf,
                  int                               rx_buf_len,
                  qmiLocSetNmeaTypesIndMsgT_v02            *nmea_type_req);

static int qmi_loc_get_nmea_type_info(
                  unsigned char                     *rx_buf,
                  int                               rx_buf_len,
                  qmiLocGetNmeaTypesIndMsgT_v02            *nmea_type_rsp);
									
static int qmi_loc_get_reg_evnet_info(
                  unsigned char                     *rx_buf,
                  int                               rx_buf_len,
                  qmiLocGetRegisteredEventsIndMsgT_v02      *reg_event_rsp);
									

static int qmi_loc_get_server_conn_req_ind_event
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  qmiLocEventLocationServerConnectionReqIndMsgT_v02    *loc_server_conn_ind_event_rsp
);

boolean loc_time_count(int timeID);

