#include "TOF_Definition.h"

typedef enum {OPEN, WPA_TKIP, WPA_AES, WPA2_TKIP, WPA2_AES, WPAWPA2_TKIPAESES} WIFI_ENCRYPTION; 

#define BUFFER_MAX_LENGTH 256

extern int connect_wifi(char* ssid, char* pw, int encryption);
extern int disconnect_wifi(void);
extern bool unload_wifimodule(void);
extern bool load_wifimodule(void);



