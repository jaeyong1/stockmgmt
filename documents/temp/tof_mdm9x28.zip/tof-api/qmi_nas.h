#ifndef QMI_NAS_H
#define QMI_NAS_H

/******************************************************************************
  @file    qmi_nas.h
  @brief   QMI NAS header

  $Id$

  DESCRIPTION

  INITIALIZATION AND SEQUENCING REQUIREMENTS

  ---------------------------------------------------------------------------
  Copyright (c) 2013 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/

#include "qmi_nas_srvc.h"
#include "network_access_service_v01.h"

extern wmm_registartion_status_type registration_status;
extern RIL_Operator_Info  operator_status;
// 130718 jgkim, for debug information
extern qmi_nas_avg_rf_data_type avg_rsrp;

#define QMI_NAS_RAT_MODE_PREF_CDMA2000_1X_BIT_V01 0
#define QMI_NAS_RAT_MODE_PREF_CDMA2000_HRPD_BIT_V01 1
#define QMI_NAS_RAT_MODE_PREF_GSM_BIT_V01 2
#define QMI_NAS_RAT_MODE_PREF_UMTS_BIT_V01 3
#define QMI_NAS_RAT_MODE_PREF_LTE_BIT_V01 4

#define QMI_NAS_RAT_MODE_PREF_CDMA                          ( 1 << QMI_NAS_RAT_MODE_PREF_CDMA2000_1X_BIT_V01 )
#define QMI_NAS_RAT_MODE_PREF_HRPD                          ( 1 << QMI_NAS_RAT_MODE_PREF_CDMA2000_HRPD_BIT_V01 )
#define QMI_NAS_RAT_MODE_PREF_GSM                           ( 1 << QMI_NAS_RAT_MODE_PREF_GSM_BIT_V01 )
#define QMI_NAS_RAT_MODE_PREF_UMTS                          ( 1 << QMI_NAS_RAT_MODE_PREF_UMTS_BIT_V01 )
#define QMI_NAS_RAT_MODE_PREF_LTE                           ( 1 << QMI_NAS_RAT_MODE_PREF_LTE_BIT_V01 )
#define QMI_NAS_RAT_MODE_PREF_CDMA_HRPD                     ( QMI_NAS_RAT_MODE_PREF_CDMA + QMI_NAS_RAT_MODE_PREF_HRPD )
#define QMI_NAS_RAT_MODE_PREF_GSM_UMTS                      ( QMI_NAS_RAT_MODE_PREF_GSM + QMI_NAS_RAT_MODE_PREF_UMTS )
#define QMI_NAS_RAT_MODE_PREF_UMTS_LTE                      ( QMI_NAS_RAT_MODE_PREF_UMTS + QMI_NAS_RAT_MODE_PREF_LTE )
#define QMI_NAS_RAT_MODE_PREF_GSM_UMTS_LTE                  ( QMI_NAS_RAT_MODE_PREF_GSM_UMTS + QMI_NAS_RAT_MODE_PREF_LTE )
#define QMI_NAS_RAT_MODE_PREF_GSM_UMTS_CDMA_HRPD            ( QMI_NAS_RAT_MODE_PREF_GSM_UMTS + QMI_NAS_RAT_MODE_PREF_CDMA_HRPD )
#define QMI_NAS_RAT_MODE_PREF_CDMA_HRPD_LTE                 ( QMI_NAS_RAT_MODE_PREF_CDMA_HRPD + QMI_NAS_RAT_MODE_PREF_LTE )
#define QMI_NAS_RAT_MODE_PREF_GSM_UMTS_CDMA_HRPD_LTE        ( QMI_NAS_RAT_MODE_PREF_GSM_UMTS_LTE + QMI_NAS_RAT_MODE_PREF_CDMA_HRPD )

/* Determine whether the service domain supports CS */
#define QMI_SRV_DOMAIN_SUPPORT_CS( srv_domain )                                                 \
  ( ( srv_domain == SYS_SRV_DOMAIN_CS_ONLY ) || ( srv_domain == SYS_SRV_DOMAIN_CS_PS ) )

/* Determine whether the service capability supports CS */
#define QMI_SRV_CAPABILITY_SUPPORT_CS( srv_capability )                                         \
  ( ( srv_capability == SYS_SRV_DOMAIN_CS_ONLY ) || ( srv_capability == SYS_SRV_DOMAIN_CS_PS ) )
  
/* Determine whether the service domain supports PS */
#define QMI_SRV_DOMAIN_SUPPORT_PS( srv_domain )                                                 \
  ( ( srv_domain == SYS_SRV_DOMAIN_PS_ONLY ) || ( srv_domain == SYS_SRV_DOMAIN_CS_PS ) )

/* Determine whether the service capability supports PS */
#define QMI_SRV_CAPABILITY_SUPPORT_PS( srv_capability )                                         \
  ( ( srv_capability == SYS_SRV_DOMAIN_PS_ONLY ) || ( srv_capability == SYS_SRV_DOMAIN_CS_PS ) )

/* Determine whether the service status indicates full service  */
#define QMI_SRV_STATUS_INDICATES_FULL_SRV( srv_status ) \
  ( srv_status == SYS_SRV_STATUS_SRV )

/* Determine whether the service status indicates LTE full service */
#define QMI_SRV_STATUS_INDICATES_LTE_FULL_SRV( srv_status, srv_status_info_valid ) \
  ( QMI_SRV_STATUS_INDICATES_FULL_SRV( srv_status ) && srv_status_info_valid )
  
/* Determine whether the service status indicates GWL full service */
#define QMI_SRV_STATUS_INDICATES_GWL_FULL_SRV( srv_status, srv_status_info_valid ) \
  ( QMI_SRV_STATUS_INDICATES_FULL_SRV( srv_status ) && srv_status_info_valid )

/* Determine whether the service status indicates CDMA full service */
#define QMI_SRV_STATUS_INDICATES_CDMA_FULL_SRV( srv_status, srv_status_info_valid ) \
  ( QMI_SRV_STATUS_INDICATES_FULL_SRV( srv_status ) && srv_status_info_valid )

/* Determine whether the service status indicates HDR full service */
#define QMI_SRV_STATUS_INDICATES_HDR_FULL_SRV( srv_status, srv_status_info_valid ) \
  ( QMI_SRV_STATUS_INDICATES_FULL_SRV( srv_status ) && srv_status_info_valid )

/* Determine whether the service status indicates hybrid HDR full service */
#define QMI_SRV_STATUS_INDICATES_HYBRID_HDR_FULL_SRV( hdr_hybrid, hdr_srv_status ) \
  ( hdr_hybrid && QMI_SRV_STATUS_INDICATES_FULL_SRV( hdr_srv_status ) )

/* Determine whether the service status indicates 1XEVO full service */
#define QMI_SRV_STATUS_INDICATES_1XEVDO_FULL_SRV( srv_status, srv_status_info_valid, hdr_srv_status_info_valid, hdr_hybrid, hdr_srv_status ) \
  ( QMI_SRV_STATUS_INDICATES_CDMA_FULL_SRV( srv_status, srv_status_info_valid ) || \
    QMI_SRV_STATUS_INDICATES_HDR_FULL_SRV( hdr_srv_status, hdr_srv_status_info_valid ) ||  \
    QMI_SRV_STATUS_INDICATES_HYBRID_HDR_FULL_SRV( hdr_hybrid, hdr_srv_status ) )

typedef enum
{
  SYS_HS_IND_NONE = -1,					/**< FOR INTERNAL USE OF CM ONLY! */
  SYS_HS_IND_HSDPA_HSUPA_UNSUPP_CELL,   /**< Cell does not support either HSDPA or HSUPA */
  SYS_HS_IND_HSDPA_SUPP_CELL,           /**< Cell supports HSDPA */
  SYS_HS_IND_HSUPA_SUPP_CELL,           /**< Cell supports HSUPA */
  SYS_HS_IND_HSDPA_HSUPA_SUPP_CELL,     /**< Cell supports HSDPA and HSUPA */  
  SYS_HS_IND_HSDPAPLUS_SUPP_CELL,
  SYS_HS_IND_HSDPAPLUS_HSUPA_SUPP_CELL,
  SYS_HS_IND_DC_HSDPAPLUS_SUPP_CELL,
  SYS_HS_IND_DC_HSDPAPLUS_HSUPA_SUPP_CELL,
  SYS_HS_IND_HSDPAPLUS_64QAM_HSUPA_SUPP_CELL,
  SYS_HS_IND_HSDPAPLUS_64QAM_SUPP_CELL,
  SYS_HS_IND_MAX                        /**< FOR INTERNAL USE OF CM ONLY! */
} sys_hs_ind_e_type;

/* Radio Interface */
typedef enum
{
  RADIO_IF_NO_SVC =0x00,
  RADIO_IF_CDMA_1X,
  RADIO_IF_CDMA_1XEVDO,
  RADIO_IF_AMPS,
  RADIO_IF_GSM,
  RADIO_IF_UMTS,
  RADIO_IF_LTE = 0x08,
  RADIO_IF_TDSCDMA
}radio_interface_type;

typedef enum {
  RIL_ACT_UNKNOWN = 0, 
  RIL_ACT_GPRS    = 1,
  RIL_ACT_EDGE    = 2,
  RIL_ACT_UMTS    = 3,  
  RIL_ACT_IS95A   = 4,   
  RIL_ACT_IS95B   = 5,   
  RIL_ACT_1XRTT   = 6,   
  RIL_ACT_EVDO0   = 7,   
  RIL_ACT_EVDOA   = 8,   
  RIL_ACT_HSDPA   = 9,   
  RIL_ACT_HSUPA   = 10, 
  RIL_ACT_HSPA    = 11,   
  RIL_ACT_EVDOB   = 12,
  RIL_ACT_EHRPD   = 13,   
  RIL_ACT_LTE     = 14, 
  RIL_ACT_HSPAP   = 15, // HSPA+  
  RIL_ACT_GSM     = 16  // Only supports voice
} ril_act_e_type;

typedef enum
{
  /*! 1.4MHz bandwidth */
  LTE_BW_IDX_NRB_6 = 0,
  /*! 3MHz bandwidth */
  LTE_BW_IDX_NRB_15,
  /*! 5MHz bandwidth */
  LTE_BW_IDX_NRB_25,
  /*! 10MHz bandwidth */
  LTE_BW_IDX_NRB_50,
  /*! 15MHz bandwidth */
  LTE_BW_IDX_NRB_75,
  /*! 20MHz bandwidth */
  LTE_BW_IDX_NRB_100,
  /*! Minimum supported bandwidth */
  LTE_BW_IDX_MIN = LTE_BW_IDX_NRB_6,
  /*! Maximum supported bandwidth */
  LTE_BW_IDX_MAX = LTE_BW_IDX_NRB_100
} lte_bandwidth_idx_e;

typedef struct
{
  int earfcn_dl;
  int earfcn_ul;
  int band_class;
  float band_width;

  int mnc;
  int mcc;
  int mnc_includes_pcs_digit;
  int tac;
  int pci;
  int cell_id;

  int esm_cause;

  int drx;
  int rsrp;
  int rsrq;
  int rssi;
  int l2w;
  int ri;
  int cqi;

  int sinr;
  int tx_pwr;  

  int avg_rsrp;
  int avg_antbar;

  int srv_status;
  int emm_status;
  int sub_status;
  int rrc_state;
  int svc;

  unsigned char tmsi[4];
  unsigned char pdn_addr[4];

  // WCDMA �׸� �߰�
  int uarfcn_dl;
  int uarfcn_ul;
  int network_type;
  int network_mode;
  int lac;
  int rac;
  int mm_cause;
  int mm_state;
  int mm_substate;
  int gmm_cause;
  int gmm_state;
  int gmm_substate;
  int gmm_update_status;;
  int sm_cause;
  int w_rrc_state;
  int pmm_mode;
  int pdp_state;
  int sim_state;
  int cm_call_state;
  int w2l;
  int bler;
  int iference;
  int oprt_mode;;
  int location_update_status;
  int rx_pwr;
  int tx_adj;
  int nset_psc[4];
  int nset_rscp[4];
  int nset_ecio[4];
  unsigned char p_tmsi[4];
  unsigned char pdp_addr[4];
  unsigned char imsi[20];
  unsigned char msisdn[20];
  
} qmi_nas_debug_info_type;

typedef enum
{
  SKT_PREQ_FULL = 0,
  SKT_PREQ_10664,
  SKT_PREQ_10689,
  SKT_PREQ_10713,
  SKT_PREQ_10737,
  SKT_PREQ_10639,
  SKT_PREQ_10614,
  SKT_PREQ_PREF,
  SKT_PREQ_USER,
  SKT_PREQ_MAX
} skt_freq_type;

typedef enum
{
  KT_PREQ_FULL = 0,
  KT_PREQ_10763,
  KT_PREQ_10787,
  KT_PREQ_10812,
  KT_PREQ_10836,
  KT_PREQ_PREF,
  KT_PREQ_USER,
  KT_PREQ_MAX
} kt_freq_type;

//--> RIL_REQUEST_CDMA_SUBSCRIPTION
enum
{
  NAS_CDMA_SUBSCRIPTION_INFO_MDN = 0,
  NAS_CDMA_SUBSCRIPTION_INFO_H_SID,
  NAS_CDMA_SUBSCRIPTION_INFO_H_NID,
  NAS_CDMA_SUBSCRIPTION_INFO_MIN,
  NAS_CDMA_SUBSCRIPTION_INFO_PRL_VER,
  NAS_CDMA_SUBSCRIPTION_INFO_MAX
};

#define NAS_SID_NID_ELEMENT_MAX_SIZE ( 6 )
#define NAS_SID_NID_STR_MAX_SIZE     ( NAS_SID_NID_ELEMENT_MAX_SIZE * 20 + 1 )
#define NAS_MIN_S_STR_MAX_SIZE       ( 11 )
#define NAS_NEIGHBOR_LIST_MAX_SIZE   ( 64 )
#define NAS_PRL_VERSION_MAX_SIZE     ( 7 )
#define NAS_CID_ASCII_MAX_LEN        ( 9 )
#define NAS_MDN_STR_MAX_SIZE         ( MDN_MAX_LEN_V01 + 1)

typedef struct
{
  char *cdma_subscription[ NAS_CDMA_SUBSCRIPTION_INFO_MAX ];
  char mob_dir_number[ NAS_MDN_STR_MAX_SIZE ];
  char home_sid[ NAS_SID_NID_STR_MAX_SIZE ];
  char home_nid[ NAS_SID_NID_STR_MAX_SIZE ];
  char min_s[ NAS_IMSI_MIN1_LEN_V01 + NAS_IMSI_MIN2_LEN_V01 + 1 ];
  char prl_version[ NAS_PRL_VERSION_MAX_SIZE ];
} qmi_nas_cdma_subscription_type;
//<-- RIL_REQUEST_CDMA_SUBSCRIPTION

//--> RIL_REQUEST_REGISTRATION_STATE
#define NAS_REG_STATE_RESP_MAX_ARR_SIZE (14) // TODO:VZW (15)

typedef struct
{
  char *registration_info_array[ NAS_REG_STATE_RESP_MAX_ARR_SIZE ];
  char registration_state[ 3 ];
  char lac[ 7 ];
  char cid[ 11 ];
  char radio_tech[ 3 ];
  char base_id[ 6 ];
  char base_latitude[ 12 ];
  char base_longitude[ 12 ];
  char ccs[ 4 ];
  char prl_ind[ 4 ];
  char sid[ 6 ];
  char nid[ 6 ];
  char roam_status[ 4 ];
  char def_roam_ind[ 4 ];
  char reg_reject_cause[12];
  // TODO:VZW char primary_scrambling_code[12];
} qmi_nas_registration_state_resp_helper_type;
//<-- RIL_REQUEST_REGISTRATION_STATE

//BKS_20131202 //--> RIL_REQUEST_OPERATOR
#define NAS_OPERATOR_RESP_MAX_ARR_SIZE (3)

#define NAS_OPERATOR_RESP_MAX_EONS_LEN (512)

#define NAS_OPERATOR_RESP_MAX_MCC_MNC_LEN (16) //length of MNC_MNC should be 5-7 characters. Extra space is a safeguard.

typedef struct
{
  char *operator_info_array[ NAS_OPERATOR_RESP_MAX_ARR_SIZE ];
  char long_eons[ NAS_OPERATOR_RESP_MAX_EONS_LEN ];
  char short_eons[ NAS_OPERATOR_RESP_MAX_EONS_LEN ];
  char mcc_mnc_ascii[ NAS_OPERATOR_RESP_MAX_MCC_MNC_LEN ];
} qmi_operator_resp_helper_type;
//BKS_20131202 //<-- RIL_REQUEST_OPERATOR

//--> EMERGENCY_CALLBACK_MODE
typedef enum
{
  QMI_RIL_EME_CBM_INVALID,
  QMI_RIL_EME_CBM_NOT_ACTIVE,
  QMI_RIL_EME_CBM_ACTIVE
} qmi_ril_emergency_callback_mode_state_type;
//<-- EMERGENCY_CALLBACK_MODE

typedef enum
{
  QMI_RIL_RTE_NONE = 0,
  QMI_RIL_RTE_FIRST,
  QMI_RIL_RTE_1x = QMI_RIL_RTE_FIRST,
  QMI_RIL_RTE_GSM,
  QMI_RIL_RTE_WCDMA,
  QMI_RIL_RTE_SUB_LTE,
  QMI_RIL_RTE_SUB_DO,
  QMI_RIL_RTE_LAST = QMI_RIL_RTE_SUB_DO,
  QMI_RIL_RTE_CAP
} qmi_ril_nw_reg_rte_type;

//--> VOLTE_CALL_TYPE
typedef enum
{
  QMI_RIL_NW_REG_FULL_SERVICE             = 1,
  QMI_RIL_NW_REG_LIMITED_SERVICE          = 2,
  QMI_RIL_NW_REG_VOICE_CALLS_AVAILABLE    = 4,
  QMI_RIL_NW_REG_VOIP_CALLS_AVAILABLE     = 8
} qmi_ril_nw_reg_status_overview_item_type;
//<-- VOLTE_CALL_TYPE

struct nas_cached_info_type
{
//BKS_20131202
  uint8_t plmn_id_valid;
  nas_plmn_id_ext_type_v01 * plmn_id;

  uint8_t short_name_valid;
  nas_plmn_name_type_v01 * short_name;

  uint8_t long_name_valid;
  nas_plmn_name_type_v01 * long_name;

  // ** from nas_system_selection_preference_ind_msg_v01
  uint8_t emergency_mode_valid;
  uint8_t emergency_mode;	

  uint8_t mode_pref_valid;
  uint16_t mode_pref;

  uint8_t band_pref_valid;
  uint64_t band_pref;

  uint8_t prl_pref_valid;	
  uint16_t prl_pref;	

  uint8_t roam_pref_valid;	
  uint16_t roam_pref;	

  uint8_t lte_band_pref_valid;	
  uint64_t lte_band_pref;	

  uint8_t net_sel_pref_valid;
  uint8_t net_sel_pref;

  uint8_t cdma_sys_id_valid;
  nas_cdma_system_id_type_v01 cdma_sys_id;

  uint8_t roam_status_valid;
  nas_roam_status_enum_type_v01 roam_status;
  uint8_t voice_roam_status_reported;

  uint8_t is_sys_prl_match_valid;
  uint8_t is_sys_prl_match;

  uint8_t def_roam_ind_valid;	
  uint8_t def_roam_ind;	

  uint8_t cdma_srv_status_info_valid;	
  nas_3gpp2_srv_status_info_type_v01 * cdma_srv_status_info;

  uint8_t hdr_srv_status_info_valid;
  nas_3gpp2_srv_status_info_type_v01 * hdr_srv_status_info;

  uint8_t lte_srv_status_info_valid;	
  nas_3gpp_srv_status_info_type_v01 * lte_srv_status_info;

  uint8_t cdma_sys_info_valid;	
  nas_cdma_sys_info_type_v01 * cdma_sys_info;

  uint8_t hdr_sys_info_valid;	
  nas_hdr_sys_info_type_v01 * hdr_sys_info;

  uint8_t lte_sys_info_valid;	
  nas_lte_sys_info_type_v01 * lte_sys_info;

  uint8_t voice_support_on_lte_valid;
  uint8_t voice_support_on_lte;

  qmi_ril_emergency_callback_mode_state_type eme_cbm;

  uint8_t hdr_hybrid;
  uint8_t radio_tech;
};

#define NAS_CACHE_STORE_ENTRY( placeholder, value, type ) {   if (value ## _valid) { \
                                                                                         if ( placeholder ) { free( placeholder ); placeholder = NULL;  placeholder ## _valid = FALSE;  }   \
                                                                                         placeholder = (type *)malloc( sizeof( * placeholder ) ); \
                                                                                         if ( placeholder ) { memcpy(placeholder, & value, sizeof(* placeholder) ); placeholder ## _valid = TRUE; } \
                                                                             } \
                                                    }

#define NAS_CACHE_STORE_TINY_ENTRY( placeholder, value ) {   if (value ## _valid) { \
                                                                                          placeholder = value; placeholder ## _valid = TRUE;  \
                                                                             } \
                                                         }

#define NAS_CACHE_IS_ENTRY_VALID( placeholder )                                          (placeholder ## _valid) 

#define NAS_CACHE_STORE_TINY_ENTRY_VAL( placeholder, value ) {  placeholder = value; placeholder ## _valid = TRUE;  }

#define NAS_CACHE_INVALIDATE_ENTRY( placeholder )         { if ((placeholder ## _valid) && ( NULL != placeholder ) ) { free( placeholder ); placeholder = NULL;  placeholder ## _valid = FALSE; } }

#define NAS_CACHE_INVALIDATE_TINY_ENTRY( placeholder )         { if ( placeholder ## _valid  ) { placeholder ## _valid = FALSE; } }

/*===========================================================================
  FUNCTION
===========================================================================*/
boolean tof_qmi_nas_init();
boolean tof_qmi_nas_release();
extern bool tof_qmi_nas_srvc_init();
extern int tof_qmi_nas_srvc_release();

extern uint8 ril_request_get_registration_status(int request, tof_registration_status_type *response);
extern uint8 ril_request_vzw_get_registration_status(int request, qmi_nas_registration_state_resp_helper_type *ril_resp_helper); //RIL_REQUEST_REGISTRATION_STATE
extern uint8 ril_request_get_operator(char *response[3]);
extern uint8 ril_request_vzw_get_operator(qmi_operator_resp_helper_type *ril_resp_helper); //RIL_REQUEST_OPERATOR //BKS_20131202
extern uint8 request_get_network_selection_mode(uint8* net_sel_mode);
extern uint8 request_set_auto_mode();
extern uint8 request_get_operator_status(TOF_Operator_Info *Tof_Operator);
extern uint8 ril_request_get_pref_network(uint16 *mode_pref);
extern uint8 ril_request_set_pref_network(uint16 mode_pref);
extern 	uint8 ril_request_get_pref_mode(uint16 *mode_pref, uint64 *band_mode_pref);
extern 	uint8 ril_request_set_pref_mode(uint16 mode_pref, uint64 mode_band_pref);

extern uint8 ril_request_get_sys_info();
extern uint8 ril_nas_config_sig_info_req();
extern uint8 ril_request_get_signal_strength(int response[2]);
extern uint8 ril_request_get_sig_info(TOF_SignalStrength* tof_signal_strength);

extern uint8 get_registration_status_info();
extern uint8 get_operator_status();
extern uint8 get_network_selection_mode_status();
extern int get_registration_status(uint8 service_status, uint8 reg_status);
extern int get_radio_access_technology(uint8 radio_if, uint8 hs_call_status);

#ifdef FEATURE_LGIT_TIME
#else
extern uint8 ril_request_get_network_time_info(wmm_nitz_time_info_type *nitz_time_info);
#endif
extern uint8 get_current_plmn_name_cache();
extern uint8 ril_request_get_debug_screen_info(qmi_nas_debug_info_type *lte_debug_info);
extern uint8 ril_request_delete_stored_cell();
extern uint8 get_lte_debug_screen_info(char *response[20], int *index_count);
extern uint8 get_wcdma_debug_screen_info(RIL_WCDMA_DEBUG_INFO *wcdma_debug_info);
extern uint8 add_avg_rf_data(qmi_nas_avg_rf_data_type *avg_rf_data, int value);
extern uint8 ril_request_get_hd_mode(uint8 *hd_mode);

//20170215 yjoh add for cell info
extern boolean request_get_cell_info(TOF_cellinfo *cell_info);

extern uint8 ril_request_get_ecall_mode(uint32 *ecall_mode);//jaeyong1.park
extern boolean request_get_ecall_enable(uint32 *on_off);//jaeyong1.park

extern boolean request_get_ecall_config(int index, char* ecallnumber);


extern uint8 ril_request_get_modem_value(int getvalcmd, char* reqstr, char *rspstr); //jaeyong1.park

extern uint8 ril_request_get_network_scan();//jaeyong1.park

extern boolean request_set_ecall_session_timeout2(uint32 numdata); //jaeyong1.park
extern uint8 request_set_ecall_enable(nas_ecall_setenable_e_type_v02 on_off);//jaeyong1.park
extern uint8 request_set_ecall_only_mode(uint8 on_off);//mwkim, InnoJIRA : AS045-670, 672
extern uint8 request_get_ecall_oper_mode(uint8 * ecall_mode_value);//mwkim, InnoJIRA : AS045-671

extern uint8 ril_request_set_hd_mode(uint8 hd_mode);
extern uint8 convert_frequency_to_ril_Index(boolean freq_enable, uint32 freq, uint32 forced_freq, uint8 *p_index, uint32 *p_frequency);
extern uint8 convert_ril_Index_to_frequency(uint8 p_index, uint32 p_frequency, boolean *freq_enable, uint32 *freq, uint32 *forced_freq);
extern uint8 ril_request_get_ims_pdn(uint16 *ims_pdn);
extern uint8 ril_request_set_ims_pdn(uint16 ims_pdn);
extern uint8 ril_request_get_ims_param_config(RIL_Ims_Param_Config *ims_param);
extern uint8 ril_request_set_ims_param_config(RIL_Ims_Param_Config ims_param);
extern uint8 ril_request_get_ims_rcs_auto_config(RIL_Ims_Rcs_Auto_Config *ims_rcs_auto_config);
extern uint8 ril_request_set_ims_rcs_auto_config(RIL_Ims_Rcs_Auto_Config ims_rcs_auto_config);
extern uint8 ril_request_get_ims_acs_disable(uint8 *acs_disable);
extern uint8 ril_request_set_ims_acs_disable(uint8 acs_disable);
//hongsg 20140729
extern uint8 ril_request_get_ims_qipcall_config(int request, RIL_Ims_Qipcall_Config *ims_qipcall_config);
extern uint8 ril_request_set_ims_qipcall_config(int request, RIL_Ims_Qipcall_Config ims_qipcall_config);
extern uint8 ril_request_get_ims_reg_config(uint8 request, RIL_Ims_Reg_Config *ims_reg_config);
extern uint8 ril_request_set_ims_reg_config(uint8 request, RIL_Ims_Reg_Config ims_reg_config);
extern uint8 ril_request_get_ims_voip_config(uint16 *session_timer);
extern uint8 ril_request_set_ims_voip_config(uint16 session_timer);
extern uint8 ril_request_get_ims_user_agent(int request, RIL_Ims_User_Agent *user_agent); //hongsg 20140814
extern uint8 ril_request_set_ims_user_agent(int request, RIL_Ims_User_Agent user_agent);

extern uint8 ril_request_get_preferred_network_type(uint16 *mode_pref);
extern uint8 ril_request_set_preferred_network_type(uint16 mode_pref);

extern uint8 qmi_nas_request_cdma_subscription(qmi_nas_cdma_subscription_type *ril_response_data); //RIL_REQUEST_CDMA_SUBSCRIPTION

extern boolean qmi_srv_query_lte_full_srv();
extern boolean qmi_srv_query_cdma_full_srv();//BKS_20141029 

extern RIL_Errno qmi_nas_vzw_fetch_sys_info();
extern int qmi_nas_query_avail_radio_tech(boolean reporting_data_reg_state);

extern qmi_ril_emergency_callback_mode_state_type qmi_ril_nwr_get_eme_cbm(); //EMERGENCY_CALLBACK_MODE
extern void qmi_ril_nwr_set_eme_cbm(qmi_ril_emergency_callback_mode_state_type new_mode); //EMERGENCY_CALLBACK_MODE
extern uint8 ril_request_exit_emergency_callback_mode(); //RIL_REQUEST_EXIT_EMERGENCY_CALLBACK_MODE
// --> RIL_REQUEST_EVDO_REV
extern uint8 ril_request_get_evdo_rev(uint8 * evdo_rev);
extern uint8 ril_request_set_evdo_rev(uint8 evdo_rev);
// <-- RIL_REQUEST_EVDO_REV
extern RIL_Errno qmi_nas_set_vzw_config_sig_info2();
extern RIL_Errno qmi_nas_set_config_sig_info2();

//--> RIL_REQUEST_APN_SETTING
extern uint8 ril_request_get_sdm_apn_info(int request_info,uint8 profile_num, RIL_Apn_Info *apninfo);
extern uint8 ril_request_get_sdm_apn_info_ack(int request_info,uint8 profile_num, RIL_Apn_Info *apninfo);
extern uint8 ril_request_set_sdm_apn_info(int request_info ,RIL_Apn_Info apninfo);
//<-- RIL_REQUEST_APN_SETTING
// --> RIL_REQUEST_VZW_IMS_SETTING
extern uint8 ril_request_get_vzw_ims_setting(uint8 * ims_setting);
extern uint8 ril_request_set_vzw_ims_setting(uint8 ims_setting);
// <-- RIL_REQUEST_VZW_IMS_SETTING
//--> RIL_REQUEST_EHRPD_IPV6
extern uint8 ril_request_get_ehrpd_ipv6_enabled(uint8 *ehprd_ipv6);
extern uint8 ril_request_set_ehrpd_ipv6_enabled(uint8 ehprd_ipv6);
//<-- RIL_REQUEST_EHRPD_IPV6
//--> RIL_REQUEST_T3402
extern uint8 ril_request_get_t3402(uint32 *timer);
extern uint8 ril_request_set_t3402(uint32 timer);
//<-- RIL_REQUEST_T3402

//RIL_REQUEST_HK_GET_IMS_AUTH
extern uint8 ril_request_get_ims_sip_extended_config(uint8 *ims_auth);
//RIL_REQUEST_HK_SET_IMS_AUTH
extern 	uint8 ril_request_set_ims_sip_extended_config(uint8 ims_auth);

//-->RIL_REQUEST_HK_SET_LTE_BAND_PREF
extern uint8 ril_request_set_lte_band_pref(int lte_band_pref);
//--> RIL_REQUEST_HK_SET_CDMA_SYS_SEL_PREF
extern uint8 ril_request_set_system_selection(uint16 sys_sel);
//--> RIL_REQUEST_HK_GET_CDMA_SYS_SEL_PREF
extern uint8 ril_request_query_system_selection(int *sys_sel);

//--> VOLTE_CALL_TYPE
extern uint32 qmi_ril_nw_reg_get_status_overview( void );
//<-- VOLTE_CALL_TYPE

extern bool qmi_check_cdma_roaming(void);

extern uint8 ril_request_get_ims_test_mode(uint16 *ims_test_mode);
extern uint8 ril_request_set_ims_test_mode(uint16 ims_test_mode);

extern uint8 ril_request_set_sdm_dcmo_vzw_config_init(void);
extern uint8 ril_request_set_vzw_test_menu(char * cmd);

//chad_20160602 start>>>

extern boolean request_set_ims_enable(boolean on_off);
extern boolean request_get_ims_enable(boolean *on_off);

extern boolean request_set_volte_session_timer(uint16 sess_time);
extern boolean request_get_volte_session_timer(uint16 *sess_time);

//chad_20160602 end <<<

#if defined(FEATURE_LGIT_OTADM_FOTA_FUMO_VZW)  //ygpark.20150119
/*===========================================================================

  FUNCTION  ril_request_set_fota_wap_push_test
  
===========================================================================*/
extern uint8 ril_request_set_fota_wap_push_test(uint16 wappushpkg);
#endif



#ifdef FEATURE_LGIT_TIME
typedef struct
{
  uint16 		year;
  uint8 		month;
  uint8 		day;
  uint8 		hour;
  uint8 		minute;
  uint8 		second;
  uint8 		day_of_week;
	
  int8			time_zone;
  uint8			daylt_sav_adj;
  uint8			radio_if;
	
  boolean		t01_valid;
  boolean		t10_valid;
  boolean		t11_valid;
  boolean		t12_valid;
} qmi_nitz_time_s;	//same as nas_5558_rsp_s, nas_004C_ind_s



typedef enum
{
  NITZ_TIME_MANAGER_STATE_TRY_UPDATE,
	NITZ_TIME_MANAGER_STATE_UPDATED,
	NITZ_TIME_MANAGER_STATE_WAIT_FOR_TRY_UPDATE,
} nitz_time_manager_state_e;



typedef struct
{
  qmi_nitz_time_s								qmi_nitz_time;
	nitz_time_manager_state_e			state;
} nitz_time_manager_s;



//public function
void	init_nitz_time( void );
bool	get_qmi_nitz_time( qmi_nitz_time_s* qmi_nitz_time );
bool	update_nitz_time( qmi_nitz_time_s* qmi_nitz_time );
void	uninit_nitz_time( void );

nitz_time_manager_state_e	get_nitz_time_manager_state();
void set_nitz_time_manager_state( nitz_time_manager_state_e state );
qmi_nitz_time_s* get_nitz_time_manager_qmi_nitz_time();

//local function
bool	check_qmi_nitz_time_valid( qmi_nitz_time_s* qmi_nitz_time );
void	log_qmi_nitz_time( qmi_nitz_time_s* qmi_nitz_time );
#endif

#endif /* QMI_NAS_H */
