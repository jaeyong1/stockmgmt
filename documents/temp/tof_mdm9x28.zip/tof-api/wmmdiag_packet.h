#ifndef WMMDIAG_PACKET_H
#define WMMDIAG_PACKET_H
/*===========================================================================

HEADER WMMDIAG_PACKET

DESCRIPTION
  
===========================================================================*/

#include "wmmdiag_packet_cdma.h"
#include "wmmdiag_packet_gw.h"

#include "qmi.h"
#include "TOF_log.h"


/* Total message size numbers */
#define QMI_MAX_STD_MSG_SIZE         (512)
#define QMI_MAX_MSG_SIZE             (2048)

/* Synchronous message default timeouts (in seconds) */
#define QMI_SYNC_MSG_DEFAULT_TIMEOUT  3 // 5 -> 2 -> 3
#define QMI_SYNC_MSG_EXTENDED_TIMEOUT 30
#define QMI_SYNC_MSG_APN_INFO_TIMEOUT 5
#define QMI_SYNC_MSG_SUBSCRIPTION_TIMEOUT 5
#define QMI_SYNC_MSG_DELETE_EXCEPTION_INFO_TIMEOUT 5

#define QMI_RIL_ZERO                     (0)

typedef enum {
  RESULT_SUCCESS,
  RESULT_FAILURE,
  RESULT_INVALID_OPPERATION,//A��������E ��oAAAC Command
  RESULT_INVALID_PARAMETER,//A��������E CEAU��a
} RESULT_TYPE;

//ysgwak 20110224 wmmdiag_device_info_type ����A��A������ net_vendor_type A���Ƣ�
typedef enum
{
  WMM_VENDOR_NONE = -1,
  WMM_VENDOR_T_SKT, // SKT T-BOX
  WMM_VENDOR_T_KT, // KT T-BOX
  WMM_VENDOR_I_SKT, // SKT I-BOX
  WMM_VENDOR_I_KT, // KT I-BOX
  WMM_VENDOR_I_VZW, // VZW I-BOX
  WMM_VENDOR_I_CHU, // China Unicom I-BOX
  WMM_VENDOR_T_QZKT, // KT T-BOX QZ // ysgwak 20120402 Vendor QZKT A���Ƣ�
  WMM_VENDOR_I_LTE_SKT = 0x10,
  WMM_VENDOR_I_LTE_KT,
  WMM_VENDOR_I_LTE_VZW, 
  WMM_VENDOR_H_LTE_SKT = 0x20,
  WMM_VENDOR_H_LTE_KT,
  WMM_VENDOR_H_LTE_VZW,
  WMM_VENDOR_H_CHU,
  WMM_VENDOR_D_CHU = 0x30,
  WMM_VENDOR_D_CAN = 0x31,
  WMM_VENDOR_D_KT = 0x32,	//DAUDIO KT
  WMM_VENDOR_D_CHT = 0x33, // 2G CHT	  
  WMM_VENDOR_D_LTE_CAN = 0x34,	//DAUDIO LTE CAN  
  WMM_VENDOR_G_SKT = 0x40, //LCN SKT

    //TODO : need re-define, 
  WMM_VENDOR_C_TCU_JPN = 0x50,   //Clarion_TCU_JPN  , �ӽ� ��� by ygpark
  WMM_VENDOR_C_TCU_VZW = 0x51,   //Clarion_TCU_VZW  , �ӽ� ��� by ygpark

  // ������AVN1.0
  WMM_VENDOR_A_KOR = 0x60,
  WMM_VENDOR_A_CAN = 0x61,
  WMM_VENDOR_A_VZW = 0x62,

  // Bosch
  WMM_VENDOR_B_EU = 0x70,
  WMM_VENDOR_B_CHN = 0x71,
  
  WMM_VENDOR_MAX
} wmmdiag_vendor_type;

typedef enum {
    RIL_E_SUCCESS = 0,
    RIL_E_RADIO_NOT_AVAILABLE = 1,     /* If radio did not start or is resetting */
    RIL_E_GENERIC_FAILURE = 2,
    RIL_E_PASSWORD_INCORRECT = 3,      /* for PIN/PIN2 methods only! */
    RIL_E_SIM_PIN2 = 4,                /* Operation requires SIM PIN2 to be entered */
    RIL_E_SIM_PUK2 = 5,                /* Operation requires SIM PIN2 to be entered */
    RIL_E_REQUEST_NOT_SUPPORTED = 6,
    RIL_E_CANCELLED = 7,
    RIL_E_OP_NOT_ALLOWED_DURING_VOICE_CALL = 8, /* data ops are not allowed during voice
                                                   call on a Class C GPRS device */
    RIL_E_OP_NOT_ALLOWED_BEFORE_REG_TO_NW = 9,  /* data ops are not allowed before device
                                                   registers in network */
    RIL_E_SMS_SEND_FAIL_RETRY = 10,             /* fail to send sms and need retry */
    RIL_E_SIM_ABSENT = 11,                      /* fail to set the location where CDMA subscription
                                                   shall be retrieved because of SIM or RUIM
                                                   card absent */
    RIL_E_SUBSCRIPTION_NOT_AVAILABLE = 12,      /* fail to find CDMA subscription from specified
                                                   location */
    RIL_E_MODE_NOT_SUPPORTED = 13,              /* HW does not support preferred network type */
    RIL_E_FDN_CHECK_FAILURE = 14,               /* command failed because recipient is not on FDN list */
    RIL_E_ILLEGAL_SIM_OR_ME = 15                /* network selection failed due to
                                                   illegal SIM or ME */
} RIL_Errno;

typedef enum {
    RADIO_TECH_UNKNOWN = 0,
    RADIO_TECH_GPRS = 1,
    RADIO_TECH_EDGE = 2,
    RADIO_TECH_UMTS = 3,
    RADIO_TECH_IS95A = 4,
    RADIO_TECH_IS95B = 5,
    RADIO_TECH_1xRTT =  6,
    RADIO_TECH_EVDO_0 = 7,
    RADIO_TECH_EVDO_A = 8,
    RADIO_TECH_HSDPA = 9,
    RADIO_TECH_HSUPA = 10,
    RADIO_TECH_HSPA = 11,
    RADIO_TECH_EVDO_B = 12,
    RADIO_TECH_EHRPD = 13,
    RADIO_TECH_LTE = 14,
    RADIO_TECH_HSPAP = 15, // HSPA+
    RADIO_TECH_GSM = 16, // Only supports voice
    RADIO_TECH_TD_SCDMA = 17
} RIL_RadioTechnology;

/* QMI Modem ID */
typedef enum
{
  QMI_DEFAULT_MODEM_ID = 0,   /* CDMA & EVDO */
  QMI_SECOND_MODEM_ID  = 1,   /* GWL */
  QMI_MAX_MODEM_ID     = 2
} qmi_modem_id_e_type;

typedef struct
{
  int psc; // Active SET
  int ecio; // ASET ECIO
} RIL_CDMA_DEBUG_INFO_PSC;

typedef struct
{
  /* command parameters */
  int reg_zone;
  int packet_zone;
  unsigned char bs_p_rev;
  unsigned char p_rev_in_use;
  unsigned char is_registered;
  unsigned char ccs_supported;
  int uz_id;
  unsigned char srch_win_n;
  int base_lat;
  int base_long;
  int base_id;

  unsigned char reject_srv_domain;
  unsigned char reject_cause;

  unsigned char active_status;
  unsigned char service_option;
  unsigned char slot_cycle_index;
  unsigned char cdma_lock_mode;

  unsigned char curr_nam;
  unsigned char ps_data_suspend;
  unsigned char packet_state;

  /* 1x related parameters */
  unsigned char service_status;
  int roam_status;
  int sid;
  int nid;
  int mcc;
  unsigned char imsi_11_12;
  int active_band;
  int active_channel;
  int rssi;
  int ecio;
  int tx_pwr;
  int tx_adj;
  RIL_CDMA_DEBUG_INFO_PSC psc[3];
  int frame_err_rate;

  /* Evdo related parameters */
  unsigned char hdr_service_status;
  int hdr_roam_status;
  int hdr_sid;
  int hdr_nid;
  int hdr_mcc;
  unsigned char hdr_imsi_11_12;
  int hybrid_active_band;
  int hybrid_active_channel;
  int hdr_rssi;
  int hdr_ecio;
  unsigned char hdr_sinr;
  int hdr_packet_err_rate;
  /* 20120229, add more items */
  int serving_pn;
  unsigned char prot_state;
  unsigned char hdr_session_state;
  int uati24;
  unsigned char  color_code;
  unsigned char uati_subnet_mask;
  unsigned char sector_color_code;
  int attempts_count;
  int success_count;
  int failure_count;
  int dl_rate;
  int ul_rate;
  unsigned char fcp_enabled;
  unsigned char sector_id[16];

  /* command more... */
  unsigned char rf_mode;
  unsigned char ac_state;
} RIL_CDMA_DEBUG_INFO;

typedef struct
{
  /* RF */
  int band; /*wmmdiag_debug_scrn_band_type*/
  int chan; // Frequency / Channel	UARFCN UL/DL
  int rssi; // (KT) RSSI
  int psc1; // Active SET
  int ecio1; // ASET RSCP
  int rscp1; // ASET Ec/Io
  int psc2; // (SKT) Neighbor SET  
  int ecio2; // (SKT) Neighbor SET
  int rscp2; // (SKT) Neighbor SET
  int psc3; // (SKT) Neighbor SET  
  int ecio3; // (SKT) Neighbor SET
  int rscp3; // (SKT) Neighbor SET
  int psc4; // (SKT) Neighbor SET  
  int ecio4; // (SKT) Neighbor SET
  int rscp4; // (SKT) Neighbor SET
  int cqi;	//SKT  
  int rx;	 // (SKT) rx
  int tx_pwr; // (KT) TxPower
  int tx_adj;  // (KT) KTF_Tx_Adjust
  int bler; // (KT) BLER
  int drx; // DRX Cycle Length
  unsigned int cell_id; // Cell_ID

  /* NETWORK */
  int mcc;
  int mnc;
  unsigned char mnc_includes_pcs_digit;
  unsigned char net_type; //(SKT) R4, R5(HSDPA), R6(HSUPA) -->  gw_config.rrc_version  
  unsigned char network_op_mode; // Network Operation Mode
  int lac;
  unsigned char rac;
  unsigned char ms_op_mode; // CN ID / Service Domain: Combined, CS, PS

  /* CM/SYSTEM */
  unsigned char cm_call_state;
  unsigned char srv_status;
  unsigned char last_mm_cause; // (SKT) MM Cause
  unsigned char last_gmm_cause; //(SKT)  GMM Cause
  unsigned char cm_oprt_mode;

  /* MM/GMM Status */
  unsigned char mm_state; 
  unsigned char mm_idle_substate;
  unsigned char location_update_status;
  unsigned char gmm_state; 
  unsigned char gmm_substate;
  unsigned char sm_cause;	// (SKT)  
  unsigned char gmm_update_status;
  unsigned char pmm_mode;
  unsigned char pdp_state;

  /* RRC */
  unsigned char rrc_state;

  /* USIM */
  unsigned char sim_state;
  unsigned char imsi_p[20];	//SKT  
  unsigned int tmsi;	//SKT
  unsigned int ptmsi;	//SKT
  unsigned char msisdn[13];	//SKT  
} RIL_WCDMA_DEBUG_INFO;

typedef struct {
    uint8 IMSParamSrc;
} RIL_Ims_Dpl_Param;


//Internal Function for tof library
/*===========================================================================
  Internal Function
===========================================================================*/
wmmdiag_vendor_type   wmm_get_vendor_type();  


typedef void (*qmi_service_ind_rx_hdlr) 
(
  int                     user_handle,
  qmi_service_id_type     service_id,
  unsigned long           msg_id,
  void                                *user_ind_msg_hdlr,
  void                                *user_ind_msg_hdlr_user_data,
  unsigned char           *rx_msg_buf,
  int                     rx_msg_len
);

#define READ_VAR_BIT_VAL(buf,dest,size) \
do { unsigned char *b_ptr = buf; \
     unsigned char *d_ptr = (unsigned char *)&dest; \
     int unlikely_cntr; \
     dest = 0; \
     for (unlikely_cntr=0; unlikely_cntr<size; unlikely_cntr++) {*d_ptr++ = *b_ptr++;} \
     buf = b_ptr; \
   } while (0)

#endif /* WMMDIAG_PACKET_H */
