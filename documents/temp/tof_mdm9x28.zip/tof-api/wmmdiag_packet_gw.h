#ifndef WMMDIAG_PACKET_GW_H
#define WMMDIAG_PACKET_GW_H

/*===========================================================================

HEADER WMMDIAG_PACKET_GW

DESCRIPTION
  
===========================================================================*/

#include "wmmdiag_packet_common.h"

#pragma pack(1)
#define PACKED

#define NO_SET_TYPE			0x02

#define GSDI_ICC_IC_LEN              10
#define GSDI_MAX_DATA_BLOCK_LEN      256

//shkim 2012.01.04 add
#define WMMDIAG_RIL_WCDMA_SMS_ADDRESS_MAX 36

typedef PACKED struct
{
  /*RF*/
  UINT16 band; /*wmmdiag_debug_scrn_band_type*/
  UINT16 chan; // Frequency / Channel	UARFCN UL/DL
  INT16 rssi; // (KT) RSSI
  UINT16 psc1; // Active SET
  INT16 ecio1; // ASET RSCP
  INT16 rscp1; // ASET Ec/Io
  UINT16 psc2; // (SKT) Neighbor SET  
  INT16 ecio2; // (SKT) Neighbor SET
  INT16 rscp2; // (SKT) Neighbor SET
  UINT16 psc3; // (SKT) Neighbor SET  
  INT16 ecio3; // (SKT) Neighbor SET
  INT16 rscp3; // (SKT) Neighbor SET
  UINT16 psc4; // (SKT) Neighbor SET  
  INT16 ecio4; // (SKT) Neighbor SET
  INT16 rscp4; // (SKT) Neighbor SET
  INT16 cqi;	//SKT  
  INT16 rx;	 // (SKT) rx
  INT16 tx_pwr; // (KT) TxPower
  INT16 tx_adj;  // (KT) KTF_Tx_Adjust
  UINT16 bler; // (KT) BLER
  UINT16 drx; // DRX Cycle Length
  UINT32 cell_id; // Cell_ID

  /*NETWORK*/
  UINT16 mcc;
  UINT16 mnc;
  UINT8 mnc_includes_pcs_digit;
  UINT8 net_type; //(SKT) R4, R5(HSDPA), R6(HSUPA) -->  gw_config.rrc_version  
  UINT8 network_op_mode; // Network Operation Mode
  UINT16 lac;
  UINT8 rac;
  UINT8 ms_op_mode; // CN ID / Service Domain: Combined, CS, PS

  /*CM/SYSTEM*/
  UINT8 cm_call_state;
  UINT8 srv_status;
  UINT8 last_mm_cause; // (SKT) MM Cause
  UINT8 last_gmm_cause; //(SKT)  GMM Cause
  UINT8 cm_oprt_mode;

  /*MM/GMM Status*/
  UINT8 mm_state; 
  UINT8 mm_idle_substate;
  UINT8 location_update_status;
  UINT8 gmm_state; 
  UINT8 gmm_substate;
  UINT8 sm_cause;	// (SKT)  
  UINT8 gmm_update_status;
  UINT8 pmm_mode;
  UINT8 pdp_state;

  /*RRC*/
  UINT8 rrc_state;

  /* USIM */
  UINT8 sim_state;
  UINT8 imsi_p[20];	//SKT  
  UINT tmsi;	//SKT
  UINT ptmsi;	//SKT
  UINT8 msisdn[12];	//SKT  
  //UINT8 imsi[20]; // SKT, KT spec�� ��� ����

  /* Add more items */
  UINT8 rat; //serving network type
} wmm_debug_screen_info_type;

typedef PACKED struct
{
	UINT8	msg_type;	//0 - �ܹ�, 1 - ����, 2 - ����Ȯ������
	UINT8	msg_seq;
	UINT8	msg_pid;		//0x00 - �Ϲ�, 0x4F - MMS Pull/Push, 0x48 - �����缭��, 0x53: ��޸޽���
	UINT8	msg_alphabet;
	UINT8	msg_dest[21+1];
	UINT8	msg_callback[21+1];
	UINT8	msg_data[160 + 1];
	UINT8	msg_data_len;
} HKS_SMS_SEND_DATA;

typedef PACKED struct
{
  uint32 digit_mode;
  uint32 number_mode;
  uint32 number_type;
  uint32 number_plan;
  unsigned char number_of_digits;
  unsigned char digits[36];//WMMDIAG_RIL_SMS_ADDRESS_MAX = 36
}WMMDIAG_RIL_SMS_ADDRESS;

typedef PACKED struct
{
  uint8                     Is_Broadcast;
  WMMDIAG_RIL_SMS_ADDRESS    sAddress;
  unsigned int              uRawDataLen;
  unsigned char             uRawData[255];//WMMDIAG_RIL_SMS_RAW_DATA_MAX = WMS_MAX_LEN = 255
} WMMDIAG_RIL_WCDMA_SMS_Message;

typedef PACKED struct
{
	UINT8	ril_call_state; //0:active, 1:holding, 2:dialing, 3:alerting, 4:incoming, 5:waiting
	UINT8	call_id;
	UINT8	toa;   //type of address  ex).145=intl   /* Type bits - bit7 = 1, bits 6-4 = number type, bits 3-0 = number plan *
	UINT8	ismpty;   /* nonzero if is mpty call */
	UINT8	isMT;     // 0: MO call, 1:MT Call
	UINT8	isVoice;   // 0:Non Voice call 1:Voice call 
	UINT8	isVoice_privacy;  //0: CDMA non voice privacy mode  1:CDMA voice privacy mode is active   (CDMA �� )
	UINT8	call_num[40+1];   //call number 
	UINT8	number_presentation;  //��ȣ ǥ�� ���� /* 0=Allowed, 1=Restricted, 2=Not Specified/Unknown 3=Payphone */
	UINT8	name[1+1];  //name�� ������� ���� ���̹Ƿ� �켱 ����� �۰� ����. 
	UINT8   name_presentation;  //�̸� ǥ�� ���� /* 0=Allowed, 1=Restricted, 2=Not Specified/Unknown 3=Payphone */
} wmmdiag_ril_call_item_type; //jisim_110531  

#define USSD_MAX_DATA_LENGTH 160
typedef PACKED struct
{
	BYTE	ussd_id;	//dsji_20110105
	BYTE  dcs;
	BYTE  data_len;
	BYTE  data_buf[USSD_MAX_DATA_LENGTH + 1];
} HKS_USSD_CONTEXT_INFO;

typedef PACKED struct	//dsji_20110113
{
	HKS_USSD_CONTEXT_INFO	ussd_context_info;
	int		event_id;
	int		event_param;
} HKS_USSD_NOTIFY_INFO;

//dsji_20120710 add {
typedef PACKED struct
{
	int n;
} HKS_SET_CLIP_REQ_INFO;

typedef PACKED struct
{
	int	n;
	int m;
} HKS_GET_CLIP_RSP_INFO;

typedef PACKED struct
{
	int n;
} HKS_SET_COLP_REQ_INFO;

typedef PACKED struct
{
	int	n;
	int m;
} HKS_GET_COLP_RSP_INFO;

typedef PACKED struct
{
	int m;
} HKS_GET_COLR_RSP_INFO;
//dsji_20120710 add }


//dsji_20110830 add {
//set
typedef PACKED struct
{
	int n;
} HKS_SET_CLIR_REQ_INFO;

typedef PACKED struct
{
	int	n;
	int m;
} HKS_GET_CLIR_RSP_INFO;

typedef PACKED struct
{
	int status;
	int reason;
	int serviceClass;
	int	toa;
	char number[ 28 + 1 ];	//SUPS_MAXNO_FORWARD_TO_NUMBER = 28 + 1
	int timeSeconds;
} CALL_FORWARD_INFO;

//set
typedef PACKED struct
{
	CALL_FORWARD_INFO setInfo;
} HKS_SET_CALL_FORWARD_REQ_INFO;

typedef PACKED struct
{
	int setInfoNum;
	CALL_FORWARD_INFO setInfo[ 13 ];	//SUPS_FWD_FEATURE_LIST_SIZE = 13	
} HKS_SET_CALL_FORWARD_RSP_INFO;

//get
typedef PACKED struct
{
	CALL_FORWARD_INFO queryInfo;
} HKS_QUERY_CALL_FORWARD_STATUS_REQ_INFO;

typedef PACKED struct
{
	int queryInfoNum;
	CALL_FORWARD_INFO queryInfo[ 13 ];	//SUPS_FWD_FEATURE_LIST_SIZE = 13
} HKS_QUERY_CALL_FORWARD_STATUS_RSP_INFO;

//set
typedef PACKED struct
{
	int enabled;
	int serviceClassBitVector;
} HKS_SET_CALL_WAITING_REQ_INFO;

typedef PACKED struct
{
	int result;
} HKS_SET_CALL_WAITING_RSP_INFO;

//get
typedef PACKED struct
{
	int serviceClass;
} HKS_QUERY_CALL_WAITING_REQ_INFO;

typedef PACKED struct
{
	int enabled;
	int serviceClassBitVector;
} HKS_QUERY_CALL_WAITING_RSP_INFO;

typedef PACKED struct
{
	int errorInfo;
	int causeInfo;
} HKS_SS_ERROR_CAUSE_INFO;
//dsji_20110830 add }

typedef enum
{
	E_LOG_LOW = 0x00,		//���� �ܰ迡�� ������� ���ؼ� ����� ���
	E_LOG_MED = 0x01,		//���α׷� ���࿡ ���� ������ ����� ���
	E_LOG_HIGH = 0x02,		//������ �ƴ����� ���� �߻� ������ �ְų� �߿��� ������ ���
	E_LOG_ERROR = 0x03,		//������ �߻��� ���
	E_LOG_FATAL = 0x04		//�ý����� �ɰ��� ��ֳ� �� �̻� ��� ������ �� �� ���� ���
} HKE_LOG_LEVEL_TYPE;

/*===========================================================================
  Constant Define
===========================================================================*/
#define  HMBASIC_VER_LEN 20

/*Phone Book*/
#define SPEC_GROUP_NAME_LEN    (214)
#define SPEC_PB_MAX_GRP_NUM_PER_ITEM    (10)
#define SPEC_PB_NAME_LEN    (16)
#define SPEC_PB_NUM_LEN    (40)
#define SPEC_PB_EMAIL_LEN    (40)
#define SPEC_PB_NUMBER_MAX_IDX    (2)

#define SPEC_MSG_NUM_LEN 23 //  '+' + ������ȣ2�ڸ� + SPEC 20
#define SPEC_MSG_MAX_LEN           255

//#define MAX_DIAL_DIGIT 40 //jisim_110704 32-> 40 HMC API 0.22 ������ 40���� ������ //jisim_101001  ����� �䱸���� Ȯ�� �� ���� �ʿ� /NV_MAX_DIAL_DIGITS �� ���� Ȯ�� 

#define MAX_NETWORK_NAME_LEN 32
#define MAX_REGISTRATION_STR_LEN  128

#define MAX_APN_STRING_LEN 100
#define PDP_READ_SUCCESS 0
#define PDP_WRITE_SUCCESS 0

#define UICC_PIN_LENGTH 8
#define UICC_ERR_STR_LENGTH 255

#define NTW_MAX_STR_SIZE    50  /// plmn display size
#define KTF_PLMNWACT_MAX_SIZE   20

#define WMS_GW_ADDRESS_MAX     20 //dykang 20101223 smsp

#define MAX_ALPHA_LEN   40
#define MAX_ADDRESS_LEN   20
#define MAX_PERIOD_LEN  3
#define KTF_SMSP_ITEM_NUM   2

#define KTF_UST_ITEM_NUM  58
#define KTF_EST_ITEM_NUM  3

#define KTF_SMSP_ITEM_NUM 2
#define KTF_FPLMN_MAX_ITEM_NUM    20

#define GSDI_IMSI_M_LEN			25

#define NTW_MAX_PLMN_LIST 20

#define WMM_DIAG_NV_ITEM_SIZE 128
#define WMM_DIAG_NV_AKEY_SIZE 26

/* Bit Error Rate Status */
#define DSAT_BER_UNKNOWN     99   /* per 3GPP 27.007  */

/* Signal level conversion result codes */
#define RSSI_TOOLO_CODE   0
#define RSSI_TOOHI_CODE   31
#define RSSI_UNKNOWN_CODE 99

/* RSSI range conversion */
#define RSSI_MIN        51   /* per 3GPP 27.007  (negative value) */
#define RSSI_MAX        113  /* per 3GPP 27.007  (negative value) */
#define RSSI_NO_SIGNAL  125  /* from CM */
#define RSSI_OFFSET       182.26
#define RSSI_SLOPE        (-100.0/62.0)

#define DSAT_CSQ_MAX_SIGNAL       RSSI_TOOHI_CODE  /* = Maximum signal      */

/* GSM RSSI range conversion */
#define GSM_RSSI_MIN        49   
#define GSM_RSSI_MAX        110
#define GSM_RSSI_TOOLO_CODE   0
#define GSM_RSSI_TOOHI_CODE   63

typedef PACKED struct
{
  byte  mcc[3+1];
  byte  mnc[3+1];
  byte  rat;
} wmmdiag_plmnwact_item_type;

typedef PACKED struct
{
  byte  result;
  byte  est_available[KTF_EST_ITEM_NUM];
} wmmdiag_get_est_rsp_type;

typedef PACKED struct
{
  byte  result;
  byte  card_mode;
  byte  ust_available[KTF_UST_ITEM_NUM];
} wmmdiag_get_ust_rsp_type;

typedef PACKED struct
{
  byte  fplmn[50];
} wmmdiag_fplmn_item_type;

typedef PACKED struct
{
  byte  item_cnt;
  wmmdiag_fplmn_item_type  fplmn_item[KTF_FPLMN_MAX_ITEM_NUM];
} wmmdiag_get_fplmn_rsp_type;

typedef PACKED struct
{
  byte  alpha_id[MAX_ALPHA_LEN];
  byte  dst_ton;
  byte  dst_npi;
  byte  dst_addr[MAX_ADDRESS_LEN];
  byte  sc_ton;
  byte  sc_npi;
  byte  sc_addr[MAX_ADDRESS_LEN];
  byte  pid;
  byte  dcs;
} wmmdiag_smsp_item_type;

typedef PACKED struct
{
  byte  item_cnt;
  wmmdiag_smsp_item_type   smsp[KTF_SMSP_ITEM_NUM];
} wmmdiag_get_smsp_rsp_type;

//swjo 20111110 KT Requst, read HPLMN List, ACM_MAX
typedef PACKED struct
{
  UINT8  result;
  UINT8  acm_max[3];
} HKS_ACM_MAX_INFO_TYPE;

#define wmmdiag_acm_max_item_type HKS_ACM_MAX_INFO_TYPE //swjo 20111110 KT Requst, read HPLMN List, ACM_MAX

typedef PACKED struct
{
  byte  item_cnt;
  wmmdiag_plmnwact_item_type plmn[NTW_MAX_STR_SIZE];
} wmmdiag_plmnwact_list_type;

typedef PACKED struct
{
  byte  offset;
  byte  mcc[3+1];
  byte  mnc[3+1];
  byte  rat;
} wmmdiag_set_plmnwact_type;

//dykang 20101223 smsp
typedef PACKED struct
{
  uint8 sc_addr[20 + 2];
} wmmdiag_smsp_list_type;


#pragma pack()


#endif /*WMMDIAG_PACKET_GW_H*/
