/******************************************************************************
  @file    qmi_dms.c
  @brief   The QMI TOF API

  DESCRIPTION

  INITIALIZATION AND SEQUENCING REQUIREMENTS

  ---------------------------------------------------------------------------
  Copyright (c) 2016 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/
#include <string.h>

//Qmi header
//#include <qmi.h>
//#include "qmi_platform.h"
#include "qmi_dms.h"
#include "qmi_nas_srvc.h"
#include "TOF_event_daemon.h"
#include "TOF_log.h"

/* Log assertion level message */
#define QCRIL_ASSERT( xx_exp )                                         \
  if ( !( xx_exp ) )                                                       \
  {                                                                        \
    MSG_FATAL( "*****ASSERTION FAILED*****",0,0,0); \
  } 
  
//Global Variable
/*qmi message library handle*/
qmi_client_handle_type dms_client_handle = QMI_INVALID_CLIENT_HANDLE;

/*=========================================================================

  FUNCTION:  qmi_dms_indication_cb

===========================================================================*/
/*!
    @brief
    Callback for QMI indications.

    @return
    None
*/
/*=========================================================================*/
//call back function
void 
qmi_dms_indication_cb
( 
  int                           user_handle,
  qmi_service_id_type           service_id,
  void                          *user_data,
  qmi_dms_indication_id_type    ind_id,
  qmi_dms_indication_data_type  *ind_data
)
{
  MSG_HIGH("qmi_dms_indication ind_id received 0x%x", ind_id, 0, 0);
}

/*===========================================================================

  FUNCTION  tof_qmi_dms_init
  
===========================================================================*/
boolean tof_qmi_dms_init()
{
  int qmi_err_code = QMI_NO_ERR;

   if(dms_client_handle != QMI_INVALID_CLIENT_HANDLE) RESULT_SUCCESS;

  /* Initialize DMS service */
  if ((dms_client_handle = tof_tof_qmi_dms_srvc_init_client (QMI_PORT_RMNET_0,
                                                 qmi_dms_indication_cb, // callback function. 
                                                 NULL, 
                                                 &qmi_err_code)) < 0)
  {
    printf("Unable to start DMS service dms_client_handle= %x, qmi_err_code=%x\n", 
           dms_client_handle, 
           qmi_err_code);
    return RESULT_FAILURE;
  }
  else
  {
    printf("Opened DMS Client. dms_client_handle= %x \r\n", dms_client_handle);
  }  

  return RESULT_SUCCESS;
}

/*===========================================================================

  FUNCTION  tof_qmi_dms_release
  
===========================================================================*/
boolean tof_qmi_dms_release()
{
   int qmi_err_code = QMI_NO_ERR;
   int rc = QMI_NO_ERR;

   if(dms_client_handle == QMI_INVALID_CLIENT_HANDLE) return RESULT_SUCCESS;
    
  if(dms_client_handle != QMI_INVALID_CLIENT_HANDLE)
  {
    rc = tof_tof_qmi_dms_srvc_release_client(dms_client_handle, &qmi_err_code);
    if(rc != QMI_NO_ERR)
    {
      printf("tof_tof_qmi_dms_srvc_release_client rc = %d, qmi_err_code \n", rc, qmi_err_code);
      return RESULT_FAILURE;
    } 
  }
  else
  {
    printf("tof_qmi_release dms_client_handle= %x\r\n", dms_client_handle);
  }

  return RESULT_SUCCESS;
}

/*===========================================================================

  FUNCTION  tof_qmi_dms_srvc_init
  
===========================================================================*/
bool tof_qmi_dms_srvc_init()
{
  int rc = QMI_INTERNAL_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
//  dms_indication_register_req_msg_v01         dms_ind_req_v01;
  dms_set_event_report_req_msg_v01 dms_event_report_req_v01;
  dms_set_event_report_resp_msg_v01 dms_event_report_resp_v01;

  return TRUE;
} /* tof_qmi_dms_srvc_init */

/*===========================================================================

  FUNCTION  qmi_dms_get_msissn
  
===========================================================================*/
uint8 ril_request_get_phone_number(char* voice_number)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;
  
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_dms_get_msisdn((int)dms_client_handle, &dms_rsp_data);
  if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_get_msisdn!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    memcpy(voice_number, dms_rsp_data.rsp_data.get_msisdn_rsp.voice_number, sizeof(dms_rsp_data.rsp_data.get_msisdn_rsp.voice_number));
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  ril_request_get_imsi
  
===========================================================================*/
uint8 ril_request_get_imsi(char* imsi)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;
  
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_dms_get_msisdn((int)dms_client_handle, &dms_rsp_data);
  if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_get_imsi!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    memcpy(imsi, dms_rsp_data.rsp_data.get_msisdn_rsp.imsi, sizeof(dms_rsp_data.rsp_data.get_msisdn_rsp.imsi));
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  ril_request_get_imei
  
===========================================================================*/
  uint8 ril_request_get_imei(char* imei)
  {
    int rc = QMI_NO_ERR;
    qmi_dms_rsp_data_type dms_rsp_data;
    
    if(dms_client_handle == INVALID_HANDLE_VALUE)
      return RESULT_FAILURE;
      
    rc = qmi_dms_get_device_serial_number((int)dms_client_handle, &dms_rsp_data);
    if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
    {
      printf("[DMS]qmi_dms_get_device_serial_number!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code);
      return RESULT_FAILURE;
    }
    else
    {
      if( dms_rsp_data.rsp_data.get_device_sn_rsp.imei_valid == TRUE)
        memcpy(imei, dms_rsp_data.rsp_data.get_device_sn_rsp.imei, sizeof(dms_rsp_data.rsp_data.get_device_sn_rsp.imei));
      else
      {
        char error[] = "IMEI nonexist";
  
        memcpy(imei, error, sizeof(error));
      }
        
      return RESULT_SUCCESS;
    }
  }

//isyoon_20150224
/*===========================================================================

  FUNCTION  ril_request_get_imeisv
  
===========================================================================*/
uint8 ril_request_get_imeisv(char* imeisv)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;
  
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_dms_get_device_serial_number((int)dms_client_handle, &dms_rsp_data);
  if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_get_device_serial_number!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    if( dms_rsp_data.rsp_data.get_device_sn_rsp.imeisv_svn_valid == TRUE)
      memcpy(imeisv, dms_rsp_data.rsp_data.get_device_sn_rsp.imeisv_svn, sizeof(dms_rsp_data.rsp_data.get_device_sn_rsp.imeisv_svn));
    else
    {
      char error[] = "IMEISV nonexist";

      memcpy(imeisv, error, sizeof(error));
    }
      
    return RESULT_SUCCESS;
  }
}


/*===========================================================================

  FUNCTION  ril_request_device_identity
  
===========================================================================*/
uint8 ril_request_device_identity(dms_get_device_serial_numbers_resp_msg_v01* identity)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;
  
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_dms_get_device_serial_number((int)dms_client_handle, &dms_rsp_data);
  if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_get_device_serial_number!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    memcpy(identity, &dms_rsp_data.rsp_data.get_device_sn_rsp, sizeof(dms_rsp_data.rsp_data.get_device_sn_rsp));
      
    return RESULT_SUCCESS;
  }
}

#ifdef BOGUS //RIL_REQUEST_CDMA_SUBSCRIPTION
/*===========================================================================

  FUNCTION  ril_request_cdma_subscription
  
===========================================================================*/
uint8 ril_request_cdma_subscription(dms_get_cdma_subscription_msg* subscription)
{
  int rc = QMI_NO_ERR;
  uint8 result = RESULT_FAILURE;
  qmi_dms_rsp_data_type dms_rsp_data;
  
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_dms_get_msisdn((int)dms_client_handle, &dms_rsp_data);
  if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_get_msisdn!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
    result = RESULT_FAILURE;
  }
  else
  {
    memcpy(subscription->mdn, &dms_rsp_data.rsp_data.get_msisdn_rsp.voice_number, sizeof(dms_rsp_data.rsp_data.get_msisdn_rsp.voice_number));
    memcpy(subscription->min, &dms_rsp_data.rsp_data.get_msisdn_rsp.voice_number, sizeof(dms_rsp_data.rsp_data.get_msisdn_rsp.voice_number));
    result = RESULT_SUCCESS;
  }

  rc = qmi_dms_get_prl_version((int)dms_client_handle, &dms_rsp_data);
  if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_get_prl_version!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
    memset((char *)&subscription->prl_version, 0x0, sizeof(dms_rsp_data.rsp_data.get_current_prl_info_rsp.prl_version));
    if(result == RESULT_FAILURE)
      result = RESULT_FAILURE;
  }
  else
  {
    if(dms_rsp_data.rsp_data.get_current_prl_info_rsp.prl_version_valid)
      memcpy((char *)&subscription->prl_version, &dms_rsp_data.rsp_data.get_current_prl_info_rsp.prl_version, sizeof(dms_rsp_data.rsp_data.get_current_prl_info_rsp.prl_version));
    else
      memset((char *)&subscription->prl_version, 0x0, sizeof(dms_rsp_data.rsp_data.get_current_prl_info_rsp.prl_version));
    
    result = RESULT_SUCCESS;
  }

  //Get home sid & nid must will be define

  return result;
}
#endif /* BOGUS */

/*===========================================================================

  FUNCTION  request_set_pin_protection
  
===========================================================================*/
uint8 request_set_pin_protection(dms_uim_set_pin_protection_req_msg_v01* params)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;
  
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_dms_uim_set_pin_protection((int)dms_client_handle, params, &dms_rsp_data);
  if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_uim_set_pin_protection!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  request_unblock_pin
  
===========================================================================*/
uint8 request_unblock_pin(dms_uim_unblock_pin_req_msg_v01* params)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;
  
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_dms_uim_unblock_pin((int)dms_client_handle, params, &dms_rsp_data);
  if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_uim_unblock_pin!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  request_unblock_pin
  
===========================================================================*/
uint8 request_change_pin(dms_uim_change_pin_req_msg_v01* params)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;
  
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_dms_uim_change_pin((int)dms_client_handle, params, &dms_rsp_data);
  if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_uim_change_pin!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  ril_request_hk_modem_reset
  
===========================================================================*/
uint8 ril_request_hk_modem_reset()
{
  UINT32 ret = RESULT_SUCCESS;
  uint8 oprt_mode;

  MSG_HIGH("[DMS] ril_request_hk_modem_reset()", 0,0,0);
  ret = request_get_oprt_mode(&oprt_mode);
  if(ret == RESULT_SUCCESS)
  {
    if(oprt_mode == DMS_OP_MODE_OFFLINE_V01 || oprt_mode == DMS_OP_MODE_RESETTING_V01)
    {
      ret = request_set_oprt_mode(DMS_OP_MODE_RESETTING_V01);
    }
    else
    {
      ret = request_set_oprt_mode(DMS_OP_MODE_OFFLINE_V01);
      if(ret == RESULT_SUCCESS)
      {
        ret = request_set_oprt_mode(DMS_OP_MODE_RESETTING_V01);
      }
      else
      {
        local_msleep(3000);
        ret = request_get_oprt_mode(&oprt_mode);
        if(ret == RESULT_SUCCESS && oprt_mode == DMS_OP_MODE_OFFLINE_V01)
        {
          ret = request_set_oprt_mode(DMS_OP_MODE_RESETTING_V01);
        }
        else
        {
          ret = request_set_oprt_mode(DMS_OP_MODE_OFFLINE_V01);
          ret = request_set_oprt_mode(DMS_OP_MODE_RESETTING_V01);
        }
      }
    }
  }
  
  return ret;
}

/*===========================================================================

  FUNCTION  request_get_vendor
  
===========================================================================*/
uint8 request_get_vendor(uint8* vendor)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;
  
  if(dms_client_handle == QMI_INVALID_CLIENT_HANDLE)
    return RESULT_FAILURE;
    
  rc = qmi_dms_get_vendor((int)dms_client_handle, &dms_rsp_data);
  if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    printf("[DMS]qmi_dms_get_vendor!! rc: %d err_code : %d\r\n",rc,dms_rsp_data.qmi_err_code);
    return RESULT_FAILURE;
  }
  else
  {
    *vendor = dms_rsp_data.rsp_data.device_vendor;
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  request_set_vendor
  
===========================================================================*/
uint8 request_set_vendor(char vendor)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;
  
  if(dms_client_handle == QMI_INVALID_CLIENT_HANDLE)
    return RESULT_FAILURE;
    
  rc = qmi_dms_set_vendor((int)dms_client_handle, vendor, &dms_rsp_data);
  if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    printf("[DMS]qmi_dms_set_vendor!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  request_set_maxpwr
  
===========================================================================*/
uint8 request_set_maxpwr(tof_dms_max_power_type_v01 max_pwr)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;
  
  if(dms_client_handle == QMI_INVALID_CLIENT_HANDLE)
    return RESULT_FAILURE;

  rc = qmi_dms_max_power_control((int)dms_client_handle, max_pwr, &dms_rsp_data);
  if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_max_power_control!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  request_get_oprt_mode
  
===========================================================================*/
uint8 request_get_oprt_mode(uint8 *oprt_mode)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;
  
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_dms_get_oprt_mode((int)dms_client_handle, &dms_rsp_data);
  if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]request_get_oprt_mode!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    *oprt_mode = dms_rsp_data.rsp_data.get_operating_mode_rsp.operating_mode;
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  request_set_oprt_mode
  
===========================================================================*/
uint8 request_set_oprt_mode(uint8 oprt_mode)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;
  
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_dms_set_oprt_mode((int)dms_client_handle, oprt_mode, &dms_rsp_data);
  if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]request_set_oprt_mode!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  qmi_dms_get_sw_version
  
===========================================================================*/
uint8 request_get_modem_sw_version (dms_get_modem_sw_version_resp_msg_v01 *get_modem_sw_version_rsp)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;
  
  if(dms_client_handle == QMI_INVALID_CLIENT_HANDLE)
    return RESULT_FAILURE;
    
  rc = qmi_dms_get_sw_version((int)dms_client_handle, &dms_rsp_data);
  if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {    
    printf( "[DMS]qmi_dms_get_sw_version!! rc: %d err_code : %d\r\n",rc,dms_rsp_data.qmi_err_code);
    return RESULT_FAILURE;
  }
  else
  {
    //qmi_notify_event(TOF_EVENT_GET_MODEM_VERSION, 0, 7); //just test code, Get modem_version success..
    memcpy(get_modem_sw_version_rsp, &dms_rsp_data.rsp_data.get_modem_sw_version_rsp, sizeof(dms_get_modem_sw_version_resp_msg_v01));
    return RESULT_SUCCESS;
  }
}

//05/24/2013 Added by ssaulaby09
/*===========================================================================

  FUNCTION  HK_MDM_Get96HConfig
  
===========================================================================*/
uint8 HK_MDM_Get96HConfig(UINT16 *time, BOOL *delay, UINT8 *delay_time, BOOL *relcall, BOOL *msgtoggle)
{
	int rc = QMI_NO_ERR;
	qmi_dms_rsp_data_type dms_rsp_data;
  
	if(dms_client_handle == INVALID_HANDLE_VALUE)
    {
        MSG_ERROR("[96H]HK_MDM_Get96HConfig!! dms_client_handle invalid: %d",dms_client_handle,0,0);
        return RESULT_FAILURE;
	}
	
	rc = qmi_dms_get_96hmode((int)dms_client_handle, &dms_rsp_data);


	if(rc != QMI_NO_ERR)	  
	{
		MSG_ERROR("[96H]HK_MDM_Get96HConfig!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
	else
	{
		*time = dms_rsp_data.rsp_data.modem_96h_mode_rsp.time;
		*delay = (BOOL)dms_rsp_data.rsp_data.modem_96h_mode_rsp.delay;
		*delay_time = (BOOL)dms_rsp_data.rsp_data.modem_96h_mode_rsp.delay_time;
		*relcall = (BOOL)dms_rsp_data.rsp_data.modem_96h_mode_rsp.relcall;
	    *msgtoggle = FALSE;

		return RESULT_SUCCESS;
		
	}

}

/*===========================================================================

  FUNCTION  HK_MDM_Set96HConfig
  
===========================================================================*/
uint8 HK_MDM_Set96HConfig(UINT16 time, BOOL delay, UINT8 delay_time, BOOL relcall, BOOL msgtoggle)
{
	int rc = QMI_NO_ERR;
	qmi_dms_rsp_data_type dms_rsp_data;

	if(dms_client_handle == INVALID_HANDLE_VALUE)
    {
        MSG_ERROR("[96H]HK_MDM_Set96HConfig!! dms_client_handle invalid: %d",dms_client_handle,0,0);
        return RESULT_FAILURE;
	}

    
    MSG_ERROR("[96H]HK_MDM_Set96HConfig!!%d,%d,%d",time,delay,delay);

	dms_rsp_data.rsp_data.modem_96h_mode_rsp.time = time;
	dms_rsp_data.rsp_data.modem_96h_mode_rsp.delay = (uint8)delay;
	dms_rsp_data.rsp_data.modem_96h_mode_rsp.delay_time = delay_time;
	dms_rsp_data.rsp_data.modem_96h_mode_rsp.relcall = (uint8)relcall;


	rc = qmi_dms_set_96hmode((int)dms_client_handle, &dms_rsp_data);
    
	if(rc != QMI_NO_ERR)
	  {
		MSG_ERROR("[96H]HK_MDM_Set96HConfig!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	  }
	  else
	  {		  
		  return RESULT_SUCCESS;
	  }

}

/*===========================================================================

  FUNCTION  HK_MDM_Get96HMode_Rat_Mode_Set
  
===========================================================================*/
uint8 HK_MDM_Get96HMode_Rat_Mode_Set(boolean *enable_rat_mode, UINT16 *enter_rat_mode)
{
	int rc = QMI_NO_ERR;
	qmi_dms_rsp_data_type dms_rsp_data;
      uint16 mode_pref = 0;  //BKS_20141029 
      int ret = RESULT_SUCCESS;

	if(dms_client_handle == INVALID_HANDLE_VALUE)	return RESULT_FAILURE;
	
     memset(&dms_rsp_data, 0, sizeof(qmi_dms_rsp_data_type));
  
	rc = qmi_dms_get_96hmode_rat_mode_set((int)dms_client_handle, &dms_rsp_data);

      ret = ril_request_get_pref_network(&mode_pref);	//dsji_20150323 modify
	  
	if(rc != QMI_NO_ERR || ret != RESULT_SUCCESS )	  //dsji_20150323 modify
	{
		MSG_ERROR("[96H]HK_MDM_Get96HMode_Rat_Mode_Set!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
	else
	{
	   if( mode_pref == PREF_NET_TYPE_LTE_ONLY)	//dsji_20150323 modify
	   {
			*enable_rat_mode = dms_rsp_data.rsp_data.modem_96h_rat_mode_set_rsp.enable_rat_mode;
			*enter_rat_mode = 0x10/*dms_rsp_data.rsp_data.modem_96h_rat_mode_set_rsp.enter_rat_mode */;
	   }
	   else if((qmi_srv_query_cdma_full_srv() == FALSE) &&(qmi_srv_query_lte_full_srv() == TRUE) )
		{
			*enable_rat_mode = dms_rsp_data.rsp_data.modem_96h_rat_mode_set_rsp.enable_rat_mode;
			*enter_rat_mode = 0x10/*dms_rsp_data.rsp_data.modem_96h_rat_mode_set_rsp.enter_rat_mode */;
		}
		else
		{
   		*enable_rat_mode = dms_rsp_data.rsp_data.modem_96h_rat_mode_set_rsp.enable_rat_mode;
   		*enter_rat_mode = dms_rsp_data.rsp_data.modem_96h_rat_mode_set_rsp.enter_rat_mode;
		}
		return RESULT_SUCCESS;
		
	}

}

/*===========================================================================

  FUNCTION  HK_MDM_Set96HMode_Rat_Mode_Set
  
===========================================================================*/
uint8 HK_MDM_Set96HMode_Rat_Mode_Set(boolean enable_rat_mode, UINT16 enter_rat_mode)
{
	int rc = QMI_NO_ERR;
	qmi_dms_rsp_data_type dms_rsp_data;

    memset(&dms_rsp_data, 0, sizeof(qmi_dms_rsp_data_type));

    dms_rsp_data.rsp_data.modem_96h_rat_mode_set_rsp.enable_rat_mode = enable_rat_mode;
    dms_rsp_data.rsp_data.modem_96h_rat_mode_set_rsp.enter_rat_mode = enter_rat_mode;
    
	rc = qmi_dms_set_96hmode_rat_mode_set((int)dms_client_handle, &dms_rsp_data);
	if(rc != QMI_NO_ERR)
	  {
		MSG_ERROR("[96H]HK_MDM_Set96HMode_Rat_Mode_Set!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	  }
	  else
	  {		  
		  return RESULT_SUCCESS;
	  }

}

/*===========================================================================

  FUNCTION  HK_MDM_MODEM_INIT
  
===========================================================================*/
uint8 HK_MDM_MODEM_INIT()
{
	int rc = QMI_NO_ERR;
	qmi_dms_rsp_data_type dms_rsp_data;
	if(dms_client_handle == INVALID_HANDLE_VALUE)
      return RESULT_FAILURE;
	
	rc = qmi_dms_modem_init((int)dms_client_handle, &dms_rsp_data);
	if(rc != QMI_NO_ERR)
	{
		MSG_ERROR("HK_MDM_MODEM_INIT error!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
	else
	{		  
		return RESULT_SUCCESS;
	}

}

//--> RIL_REQUEST_CDMA_SUBSCRIPTION
/*===========================================================================

  FUNCTION  qmi_dms_get_current_prl_info
  
===========================================================================*/
static int
qmi_dms_get_current_prl_info
(
  unsigned char                                 *rx_buf,
  int                                           rx_buf_len,
  dms_get_current_prl_info_resp_msg_v01  *current_prl_info
)
{
  unsigned long  type;
  unsigned long  length;
  unsigned char  * value_ptr;

  /* loop to read the TLVs */
  while (rx_buf_len > 0)
  {
    if (qmi_util_read_std_tlv (&rx_buf,
                               &rx_buf_len,
                               &type,
                               &length,
                               &value_ptr) < 0)
    {
      return QMI_INTERNAL_ERR;
    }
    
    /* Process the TLVS and update response data */
    switch (type)
    {
      case DMSI_PRM_TYPE_PRL_INFO_PRL_VER:
        current_prl_info->prl_version_valid = TRUE;
        READ_16_BIT_VAL(value_ptr, current_prl_info->prl_version);
        break;

      case DMSI_PRM_TYPE_PRL_INFO_PRL_ONLY:
        current_prl_info->prl_only_valid = TRUE;
        READ_16_BIT_VAL(value_ptr, current_prl_info->prl_only);
        break;
      
      default:
        QMI_ERR_MSG_1 ("qmi_dms_get_current_prl_info: unknown TLV type = %x", (unsigned int)type);
        break;
    }
  }
  
  return QMI_NO_ERR;
}

/*===========================================================================

  FUNCTION  qmi_nas_dms_fetch_cur_prl_version
  
===========================================================================*/
int qmi_nas_dms_fetch_cur_prl_version(
  uint16   * prl_version,
  int      * qmi_err_code
)
{
  dms_get_current_prl_info_resp_msg_v01  qmi_current_prl_info_response;
  int res = QMI_NO_ERR;

  unsigned char msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char *msg_ptr;
  int           msg_size;
  int           rc;

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset(&qmi_current_prl_info_response, 0, sizeof(qmi_current_prl_info_response) );

  if( prl_version )
  {
    rc = qmi_service_send_msg_sync ((int)dms_client_handle,
                                    QMI_DMS_SERVICE,
                                    QMI_DMS_GET_CURRENT_PRL_INFO_REQ_V01,
                                    QMI_SRVC_PDU_PTR(msg),
                                    (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                    msg,                 
                                    &msg_size,
                                    QMI_DMS_STD_MSG_SIZE,
                                    QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                    qmi_err_code);

    if (rc == QMI_NO_ERR)
    {
      if (qmi_dms_get_current_prl_info (msg, msg_size, &qmi_current_prl_info_response) < 0)
      {
        MSG_HIGH("qmi_nas_dms_fetch_cur_prl_version: qmi_dms_get_current_prl_info returned error", 0, 0, 0);
      }
      else
      {
        if(TRUE == qmi_current_prl_info_response.prl_version_valid)
        {
          *prl_version = qmi_current_prl_info_response.prl_version;
          MSG_HIGH("prl_version %d", *prl_version, 0, 0);
          res = QMI_NO_ERR;
        }
      }
    }
  }
  
  return res;
}
//<-- RIL_REQUEST_CDMA_SUBSCRIPTION

//BKS_20140307 start
//--> RIL_REQUEST_HK_GET_PRL_PREF_ONLY
/*===========================================================================

  FUNCTION  qmi_nas_dms_fetch_cur_prl_only
  
===========================================================================*/
uint8 qmi_nas_dms_fetch_cur_prl_only(
  uint8   * prl_only,
  int      * qmi_err_code
)
{
  dms_get_current_prl_info_resp_msg_v01  qmi_current_prl_info_response;
  int res = QMI_NO_ERR;

  unsigned char msg[QMI_DMS_STD_MSG_SIZE];
  unsigned char *msg_ptr;
  int           msg_size;
  int           rc;

  /* Prepare the request message */
  msg_ptr = QMI_SRVC_PDU_PTR(msg);
  msg_size = QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE);

  memset(&qmi_current_prl_info_response, 0, sizeof(qmi_current_prl_info_response) );

  rc = qmi_service_send_msg_sync ((int)dms_client_handle,
                                    QMI_DMS_SERVICE,
                                    QMI_DMS_GET_CURRENT_PRL_INFO_REQ_V01,
                                    QMI_SRVC_PDU_PTR(msg),
                                    (int)QMI_SRVC_PDU_SIZE(QMI_DMS_STD_MSG_SIZE) - msg_size,
                                    msg,                 
                                    &msg_size,
                                    QMI_DMS_STD_MSG_SIZE,
                                    QMI_SYNC_MSG_DEFAULT_TIMEOUT,
                                    qmi_err_code);

    if (rc == QMI_NO_ERR)
    {
      if (qmi_dms_get_current_prl_info (msg, msg_size, &qmi_current_prl_info_response) < 0)
      {
        MSG_HIGH("[qmi_nas_dms_fetch_cur_prl_only]: qmi_dms_get_current_prl_info returned error", 0, 0, 0);
      }
      else
      {
        if(TRUE == qmi_current_prl_info_response.prl_only_valid)
        {
          *prl_only = qmi_current_prl_info_response.prl_only;
          MSG_HIGH("prl_only %d", *prl_only, 0, 0);
          res = QMI_NO_ERR;
        }
      }
    }
  
  return res;
}
//<-- RIL_REQUEST_HK_GET_PRL_PREF_ONLY
//BKS_20140307 end

/*===========================================================================

  FUNCTION  request_qmi_dms_nv_read
  
===========================================================================*/
uint8 request_qmi_dms_nv_read(uint16 item, uint8 *item_data)
{
	int rc = QMI_NO_ERR;
	if(dms_client_handle == INVALID_HANDLE_VALUE)
      return RESULT_FAILURE;
	
	rc = qmi_dms_nv_read((int)dms_client_handle, item, item_data);
	if(rc != QMI_NO_ERR)
	{
		MSG_ERROR("request_qmi_dms_nv_read error!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
	else
	{		  
		return RESULT_SUCCESS;
	}

}

/*===========================================================================

  FUNCTION  request_qmi_dms_nv_read_ext
  
===========================================================================*/
uint8 request_qmi_dms_nv_read_ext(uint16 item, uint16 context, uint8 *item_data)
{
	int rc = QMI_NO_ERR;
	if(dms_client_handle == INVALID_HANDLE_VALUE)
      return RESULT_FAILURE;
	
	rc = qmi_dms_nv_read_ext((int)dms_client_handle, item, context, item_data);
	if(rc != QMI_NO_ERR)
	{
		MSG_ERROR("request_qmi_dms_nv_read_ext error!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
	else
	{		  
		return RESULT_SUCCESS;
	}
}

/*===========================================================================

  FUNCTION  request_qmi_dms_nv_write
  
===========================================================================*/
uint8 request_qmi_dms_nv_write(uint16 item, uint8 *item_data)
{
	int rc = QMI_NO_ERR;
	if(dms_client_handle == INVALID_HANDLE_VALUE)
      return RESULT_FAILURE;
	
	rc = qmi_dms_nv_write((int)dms_client_handle, item, item_data);
	if(rc != QMI_NO_ERR)
	{
		MSG_ERROR("request_qmi_dms_nv_write error!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
	else
	{		  
		return RESULT_SUCCESS;
	}

}

/*===========================================================================

  FUNCTION  request_qmi_dms_nv_write_ext
  
===========================================================================*/
uint8 request_qmi_dms_nv_write_ext(uint16 item, uint16 context, uint8 *item_data)
{
	int rc = QMI_NO_ERR;
	if(dms_client_handle == INVALID_HANDLE_VALUE)
      return RESULT_FAILURE;
	
	rc = qmi_dms_nv_write_ext((int)dms_client_handle, item, context, item_data);
	if(rc != QMI_NO_ERR)
	{
		MSG_ERROR("request_qmi_dms_nv_read_ext error!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
	else
	{		  
		return RESULT_SUCCESS;
	}
}

/*===========================================================================

  FUNCTION  request_qmi_dms_get_gmmp_domain_manufacture
  
===========================================================================*/
uint8 request_qmi_dms_get_gmmp_domain_manufacture(dms_gmmp_domain_manufacture_msg_v01 *pGmmp_domain_manufacture)
{
	int rc = QMI_NO_ERR;
	qmi_dms_rsp_data_type dms_rsp_data;
  
	if(dms_client_handle == INVALID_HANDLE_VALUE)	return RESULT_FAILURE;
	
	rc = qmi_dms_get_gmmp_domain_manufacture((int)dms_client_handle, &dms_rsp_data);

	if(rc != QMI_NO_ERR)	  
	{
		MSG_ERROR("request_qmi_dms_get_gmmp_domain_manufacture error!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
	else
	{
    memcpy(pGmmp_domain_manufacture, &dms_rsp_data.rsp_data.gmmp_domain_manufacture_rsp, sizeof(dms_gmmp_domain_manufacture_msg_v01));
		return RESULT_SUCCESS;
	}
}

/*===========================================================================

  FUNCTION  request_qmi_dms_set_gmmp_domain_manufacture
  
===========================================================================*/
uint8 request_qmi_dms_set_gmmp_domain_manufacture(dms_gmmp_domain_manufacture_msg_v01 *pGmmp_domain_manufacture)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;

  memcpy(&dms_rsp_data.rsp_data.gmmp_domain_manufacture_rsp, pGmmp_domain_manufacture, sizeof(dms_gmmp_domain_manufacture_msg_v01));

  rc = qmi_dms_set_gmmp_domain_manufacture((int)dms_client_handle, &dms_rsp_data);
  if(rc != QMI_NO_ERR)
  {
    MSG_ERROR("request_qmi_dms_set_gmmp_domain_manufacture error!! rc: %d",rc,0,0);
    return RESULT_FAILURE;
  }
  else
  {		  
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  request_qmi_dms_get_gmmp_server_ip_port_num
  
===========================================================================*/
uint8 request_qmi_dms_get_gmmp_server_ip_port_num(dms_gmmp_server_ip_port_num_msg_v01 *pGmmp_server_ip_port_num)
{
	int rc = QMI_NO_ERR;
	qmi_dms_rsp_data_type dms_rsp_data;
  
	if(dms_client_handle == INVALID_HANDLE_VALUE)	return RESULT_FAILURE;
	
	rc = qmi_dms_get_gmmp_server_ip_port_num((int)dms_client_handle, &dms_rsp_data);

	if(rc != QMI_NO_ERR)	  
	{
		MSG_ERROR("request_qmi_dms_get_gmmp_server_ip_port_num error!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
	else
	{
    memcpy(pGmmp_server_ip_port_num, &dms_rsp_data.rsp_data.gmmp_server_ip_port_num_rsp, sizeof(dms_gmmp_server_ip_port_num_msg_v01));
		return RESULT_SUCCESS;
	}
}

/*===========================================================================

  FUNCTION  request_qmi_dms_set_gmmp_server_ip_port_num
  
===========================================================================*/
uint8 request_qmi_dms_set_gmmp_server_ip_port_num(dms_gmmp_server_ip_port_num_msg_v01 *pGmmp_server_ip_port_num)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;

  memcpy(&dms_rsp_data.rsp_data.gmmp_server_ip_port_num_rsp, pGmmp_server_ip_port_num, sizeof(dms_gmmp_server_ip_port_num_msg_v01));

  rc = qmi_dms_set_gmmp_server_ip_port_num((int)dms_client_handle, &dms_rsp_data);
  if(rc != QMI_NO_ERR)
  {
    MSG_ERROR("request_qmi_dms_set_gmmp_server_ip_port_num error!! rc: %d",rc,0,0);
    return RESULT_FAILURE;
  }
  else
  {		  
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  request_qmi_dms_get_gmmp_gw_id_auth_key_device_id
  
===========================================================================*/
uint8 request_qmi_dms_get_gmmp_gw_id_auth_key_device_id(dms_gmmp_gw_id_auth_key_device_id_msg_v01 *pGmmp_gw_id_auth_key_device_id)
{
	int rc = QMI_NO_ERR;
	qmi_dms_rsp_data_type dms_rsp_data;
  
	if(dms_client_handle == INVALID_HANDLE_VALUE)	return RESULT_FAILURE;
	
	rc = qmi_dms_get_gmmp_gw_id_auth_key_device_id((int)dms_client_handle, &dms_rsp_data);

	if(rc != QMI_NO_ERR)	  
	{
		MSG_ERROR("qmi_dms_get_gmmp_gw_id_auth_key_device_id error!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
	else
	{
    memcpy(pGmmp_gw_id_auth_key_device_id, &dms_rsp_data.rsp_data.gmmp_gw_id_auth_key_device_id_rsp, sizeof(dms_gmmp_gw_id_auth_key_device_id_msg_v01));
		return RESULT_SUCCESS;
	}
}

/*===========================================================================

  FUNCTION  request_qmi_dms_set_gmmp_gw_id_auth_key_device_id
  
===========================================================================*/
uint8 request_qmi_dms_set_gmmp_gw_id_auth_key_device_id(dms_gmmp_gw_id_auth_key_device_id_msg_v01 *pGmmp_gw_id_auth_key_device_id)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;

  memcpy(&dms_rsp_data.rsp_data.gmmp_gw_id_auth_key_device_id_rsp, pGmmp_gw_id_auth_key_device_id, sizeof(dms_gmmp_gw_id_auth_key_device_id_msg_v01));

  rc = qmi_dms_set_gmmp_gw_id_auth_key_device_id((int)dms_client_handle, &dms_rsp_data);
  if(rc != QMI_NO_ERR)
  {
    MSG_ERROR("request_qmi_dms_set_gmmp_gw_id_auth_key_device_id error!! rc: %d",rc,0,0);
    return RESULT_FAILURE;
  }
  else
  {		  
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  request_qmi_dms_get_gmmp_profile_info
  
===========================================================================*/
uint8 request_qmi_dms_get_gmmp_profile_info(dms_gmmp_profile_info_msg_v01 *pGmmp_profile_info)
{
	int rc = QMI_NO_ERR;
	qmi_dms_rsp_data_type dms_rsp_data;
  
	if(dms_client_handle == INVALID_HANDLE_VALUE)	return RESULT_FAILURE;
	
	rc = qmi_dms_get_gmmp_profile_info((int)dms_client_handle, &dms_rsp_data);

	if(rc != QMI_NO_ERR)	  
	{
		MSG_ERROR("request_qmi_dms_get_gmmp_profile_info error!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
	else
	{
    memcpy(pGmmp_profile_info, &dms_rsp_data.rsp_data.gmmp_profile_info_rsp, sizeof(dms_gmmp_profile_info_msg_v01));
		return RESULT_SUCCESS;
	}
}

/*===========================================================================

  FUNCTION  request_qmi_dms_set_gmmp_profile_info
  
===========================================================================*/
uint8 request_qmi_dms_set_gmmp_profile_info(dms_gmmp_profile_info_msg_v01 *pGmmp_profile_info)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;

  memcpy(&dms_rsp_data.rsp_data.gmmp_profile_info_rsp, pGmmp_profile_info, sizeof(dms_gmmp_profile_info_msg_v01));

  rc = qmi_dms_set_gmmp_profile_info((int)dms_client_handle, &dms_rsp_data);
  if(rc != QMI_NO_ERR)
  {
    MSG_ERROR("request_qmi_dms_set_gmmp_profile_info error!! rc: %d",rc,0,0);
    return RESULT_FAILURE;
  }
  else
  {		  
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  request_qmi_dms_get_modem_temperature
  
===========================================================================*/
uint8 request_qmi_dms_get_modem_temperature(char *temperature_val)
{

	int rc = QMI_NO_ERR;
	if(dms_client_handle == INVALID_HANDLE_VALUE)	return RESULT_FAILURE;	

	MSG_ERROR("request_qmi_dms_get_modem_temperature",0,0,0);
	rc = qmi_dms_get_modem_temperature((int)dms_client_handle, temperature_val);

	if(rc != QMI_NO_ERR)	  
	{
		MSG_ERROR("request_qmi_dms_get_modem_temperature error!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
	return RESULT_SUCCESS;
}

/*===========================================================================

  FUNCTION  request_qmi_dms_get_modem_antdetect
  
===========================================================================*/
uint8 request_qmi_dms_get_modem_antdetect(int32 *main_dtct, int32 *div_dtct, int32 *main_adc, int32 *div_adc)
{

	int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;
  
	if(dms_client_handle == INVALID_HANDLE_VALUE)	return RESULT_FAILURE;	

	MSG_ERROR("request_qmi_dms_get_modem_antdetect",0,0,0);
	rc = qmi_dms_get_modem_antdetect((int)dms_client_handle, &dms_rsp_data);

	if(rc != QMI_NO_ERR)	  
	{
		MSG_ERROR("request_qmi_dms_get_modem_antdetect error!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
  else
  {
    *main_dtct = dms_rsp_data.rsp_data.modem_ant_detect_rsp.main_dtct;
		*div_dtct = dms_rsp_data.rsp_data.modem_ant_detect_rsp.div_dtct;
		*main_adc = dms_rsp_data.rsp_data.modem_ant_detect_rsp.main_adc;
		*div_adc = dms_rsp_data.rsp_data.modem_ant_detect_rsp.div_adc;
		return RESULT_SUCCESS;
  
  }
	return RESULT_SUCCESS;
}

/*===========================================================================

  FUNCTION  request_qmi_dms_get_modem_reset_log
  
===========================================================================*/
uint8 request_qmi_dms_get_modem_reset_log(boolean *reset_log_enable, int32 *reset_log_nor, int32 *reset_log_fatal)
{

	int rc = QMI_NO_ERR;
 	qmi_dms_rsp_data_type dms_rsp_data;
  
	if(dms_client_handle == INVALID_HANDLE_VALUE)	return RESULT_FAILURE;	

	MSG_ERROR("request_qmi_dms_get_modem_reset_log",0,0,0);
  
	rc = qmi_dms_get_modem_reset_log((int)dms_client_handle, &dms_rsp_data);

	if(rc != QMI_NO_ERR)	  
	{
		MSG_ERROR("request_qmi_dms_get_modem_reset_log error!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}

	*reset_log_enable = dms_rsp_data.rsp_data.modem_reset_log_rsp.reset_log_enable;
	*reset_log_nor = dms_rsp_data.rsp_data.modem_reset_log_rsp.reset_log_normal;
	*reset_log_fatal = dms_rsp_data.rsp_data.modem_reset_log_rsp.reset_log_fatal;

	return RESULT_SUCCESS;
}

/*===========================================================================

  FUNCTION  request_qmi_dms_set_modem_reset_log
  
===========================================================================*/
uint8 request_qmi_dms_set_modem_reset_log(boolean reset_log_enable)
{

	int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;
	if(dms_client_handle == INVALID_HANDLE_VALUE)	return RESULT_FAILURE;	

	MSG_ERROR("request_qmi_dms_set_modem_reset_log",0,0,0);
	rc = qmi_dms_set_modem_reset_log((int)dms_client_handle, reset_log_enable, &dms_rsp_data);

	if(rc != QMI_NO_ERR)	  
	{
		MSG_ERROR("request_qmi_dms_set_modem_reset_log error!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
	return RESULT_SUCCESS;
}



/*===========================================================================

  FUNCTION  HK_MDM_MAX_POWER_CONTROL
  
===========================================================================*/
uint8 HK_MDM_MAX_POWER_CONTROL(tof_dms_max_power_type_v01 max_pwr)
{
	int rc = QMI_NO_ERR;
	qmi_dms_rsp_data_type dms_rsp_data;
	if(dms_client_handle == INVALID_HANDLE_VALUE)
      return RESULT_FAILURE;
	
	rc = qmi_dms_max_power_control((int)dms_client_handle, max_pwr, &dms_rsp_data);
    if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
    {
      MSG_ERROR("[DMS]request_set_oprt_mode!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
      return RESULT_FAILURE;
    }
    else
    {
      return RESULT_SUCCESS;
    }
}

/*===========================================================================

  FUNCTION  request_qmi_dms_get_alive_monitor_config
  
===========================================================================*/
uint8 request_qmi_dms_get_alive_monitor_config(uint8 *enable, uint8 *duration)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;

  if(dms_client_handle == INVALID_HANDLE_VALUE)	return RESULT_FAILURE;	

  MSG_ERROR("request_qmi_dms_get_alive_monitor_config",0,0,0);
  rc = qmi_dms_get_alive_monitor_config((int)dms_client_handle, &dms_rsp_data);

  if(rc != QMI_NO_ERR)	  
  {
    MSG_ERROR("request_qmi_dms_get_alive_monitor_config error!! rc: %d",rc,0,0);
    return RESULT_FAILURE;
  }

  *enable = dms_rsp_data.rsp_data.modem_alive_rsp.enable;
  *duration = dms_rsp_data.rsp_data.modem_alive_rsp.duration;
  
  return RESULT_SUCCESS;
}

/*===========================================================================

  FUNCTION  request_qmi_dms_set_alive_monitor_config
  
===========================================================================*/
uint8 request_qmi_dms_set_alive_monitor_config(uint8 enable, uint8 duration)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;

  if(dms_client_handle == INVALID_HANDLE_VALUE)	return RESULT_FAILURE;	

  MSG_ERROR("request_qmi_dms_set_alive_monitor_config",0,0,0);

  dms_rsp_data.rsp_data.modem_alive_rsp.enable = enable;
  dms_rsp_data.rsp_data.modem_alive_rsp.duration = duration;

  rc = qmi_dms_set_alive_monitor_config((int)dms_client_handle, &dms_rsp_data);

  if(rc != QMI_NO_ERR)	  
  {
    MSG_ERROR("request_qmi_dms_set_alive_monitor_config error!! rc: %d",rc,0,0);
    return RESULT_FAILURE;
  }
  
  return RESULT_SUCCESS;
}

/*===========================================================================

  FUNCTION  request_qmi_dms_fs_daig_opendir
  
===========================================================================*/
uint8 request_qmi_dms_fs_daig_opendir (char *path, uint32 *dirp, int32 *diag_errno)
{
  int rc = QMI_NO_ERR;
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_dms_fs_daig_opendir ((int)dms_client_handle, path, dirp, diag_errno);
  if(rc != QMI_NO_ERR)
  {
    MSG_ERROR("request_qmi_dms_fs_daig_opendir error!! rc: %d",rc,0,0);
    return RESULT_FAILURE;
  }
  else
  {		  
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  request_qmi_dms_fs_daig_readdir
  
===========================================================================*/
uint8 request_qmi_dms_fs_daig_readdir (uint32 dirp, int32 seqno, fsdiag_efs2_diag_readdir_rsp_type *read_dir_rsp)
{
	int rc = QMI_NO_ERR;
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

	rc = qmi_dms_fs_daig_readdir ((int)dms_client_handle, dirp, seqno, read_dir_rsp);
	if(rc != QMI_NO_ERR)
	{
		MSG_ERROR("request_qmi_dms_fs_daig_readdir error!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
	else
	{		  
		return RESULT_SUCCESS;
	}
}

/*===========================================================================

  FUNCTION  request_qmi_dms_fs_daig_closedir
  
===========================================================================*/
uint8 request_qmi_dms_fs_daig_closedir (uint32 dirp, int32 *diag_errno)
{
	int rc = QMI_NO_ERR;
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

	rc = qmi_dms_fs_daig_closedir ((int)dms_client_handle, dirp, diag_errno);
	if(rc != QMI_NO_ERR)
	{
		MSG_ERROR("request_qmi_dms_fs_daig_closedir error!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
	else
	{		  
		return RESULT_SUCCESS;
	}
}

/*===========================================================================

  FUNCTION  request_qmi_dms_fs_daig_iter
  
===========================================================================*/
uint8 request_qmi_dms_fs_daig_iter (uint8 file_op, fsdiag_iter_dirs_req_type *iter_req, byte *fs_status, fsdiag_iter_rsp_type *iter_rsp)
{
	int rc = QMI_NO_ERR;
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

	rc = qmi_dms_fs_daig_iter ((int)dms_client_handle, file_op, iter_req, fs_status, iter_rsp);
	if(rc != QMI_NO_ERR)
	{
		MSG_ERROR("request_qmi_dms_fs_daig_iter error!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
	else
	{		  
		return RESULT_SUCCESS;
	}
}

/*===========================================================================

  FUNCTION  request_qmi_dms_fs_daig_read
  
===========================================================================*/
uint8 request_qmi_dms_fs_daig_read (fsdiag_read_req_type  *read_req, byte *fs_status, fsdiag_read_rsp_type *read_rsp)
{
	int rc = QMI_NO_ERR;
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

	rc = qmi_dms_fs_daig_read ((int)dms_client_handle, read_req, fs_status, read_rsp);
	if(rc != QMI_NO_ERR)
	{
		MSG_ERROR("request_qmi_dms_fs_daig_read error!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
	else
	{		  
		return RESULT_SUCCESS;
	}
}

/*===========================================================================

  FUNCTION  request_qmi_dms_fs_daig_delete
  
===========================================================================*/
uint8 request_qmi_dms_fs_daig_delete (fsdiag_rmfile_req_type  *read_req, byte *fs_status)
{
	int rc = QMI_NO_ERR;
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

	rc = qmi_dms_fs_daig_delete ((int)dms_client_handle, read_req, fs_status);
	if(rc != QMI_NO_ERR)
	{
		MSG_ERROR("request_qmi_dms_fs_daig_delete error!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
	else
	{		  
		return RESULT_SUCCESS;
	}
}

/*===========================================================================

  FUNCTION  request_qmi_dms_fs_daig_write
  
===========================================================================*/
uint8 request_qmi_dms_fs_daig_write (fsdiag_write_req_type *write_req, byte *fs_status)
{
	int rc = QMI_NO_ERR;
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

	rc = qmi_dms_fs_daig_write ((int)dms_client_handle, write_req, fs_status);
	if(rc != QMI_NO_ERR)
	{
		MSG_ERROR("request_qmi_dms_fs_daig_write error!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
	else
	{		  
		return RESULT_SUCCESS;
	}
}

/*===========================================================================

  FUNCTION  request_qmi_dms_fs_daig_rmdir
  
===========================================================================*/
uint8 request_qmi_dms_fs_daig_rmdir (fsdiag_rmdir_req_type *rmdir_req, byte *fs_status)
{
	int rc = QMI_NO_ERR;
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

	rc = qmi_dms_fs_daig_rmdir ((int)dms_client_handle, rmdir_req, fs_status);
	if(rc != QMI_NO_ERR)
	{
		MSG_ERROR("request_qmi_dms_fs_daig_rmdir error!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
	else
	{		  
		return RESULT_SUCCESS;
	}
}

/*===========================================================================

  FUNCTION  request_qmi_dms_fs_daig_mkdir
  
===========================================================================*/
uint8 request_qmi_dms_fs_daig_mkdir (fsdiag_mkdir_req_type *mkdir_req, byte *fs_status)
{
	int rc = QMI_NO_ERR;
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

	rc = qmi_dms_fs_daig_mkdir ((int)dms_client_handle, mkdir_req, fs_status);
	if(rc != QMI_NO_ERR)
	{
		MSG_ERROR("request_qmi_dms_fs_daig_mkdir error!! rc: %d",rc,0,0);
		return RESULT_FAILURE;
	}
	else
	{		  
		return RESULT_SUCCESS;
	}
}

/*===========================================================================

  FUNCTION  request_get_gpio
  
===========================================================================*/
uint8 request_get_gpio(uint8 gpio_type, uint8* value)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;
  
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_dms_get_gpio((int)dms_client_handle, gpio_type, &dms_rsp_data);
  if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_get_gpio!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    *value = dms_rsp_data.rsp_data.gpio_rsp.gpio_value;
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  request_set_gpio
  
===========================================================================*/
uint8 request_set_gpio(uint8 gpio_type, uint8 gpio_value)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;
  
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
    
  rc = qmi_dms_set_gpio((int)dms_client_handle, gpio_type, gpio_value, &dms_rsp_data);
  if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_set_vendor!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

//ygpark.20141201 +
#if defined(FEATURE_LGIT_OTADM_FOTA_FUMO_VZW)
/*===========================================================================

  FUNCTION  ril_request_fota_download_done_received
  
===========================================================================*/
uint8 ril_request_fota_download_done_received()
{
	int rc = QMI_NO_ERR;
	qmi_dms_rsp_data_type dms_rsp_data;

	if(dms_client_handle == INVALID_HANDLE_VALUE)
	return RESULT_FAILURE;

	ALOGD("onRequest ril_request_fota_download_done_received \r\n");
	
	rc = request_fota_download_done_received((int)dms_client_handle, &dms_rsp_data);
	if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
	{
		MSG_ERROR("[DMS]request_fota_download_done_received!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
		return RESULT_FAILURE;
	}
	else
	{
		return RESULT_SUCCESS;
	}
}

/*===========================================================================

  FUNCTION  ril_request_fota_install
  
===========================================================================*/
uint8 ril_request_fota_install()
{
	int rc = QMI_NO_ERR;
	qmi_dms_rsp_data_type dms_rsp_data;

	if(dms_client_handle == INVALID_HANDLE_VALUE)
	return RESULT_FAILURE;

	ALOGD("onRequest ril_request_fota_install \r\n");

	rc = request_fota_install((int)dms_client_handle, &dms_rsp_data);
	if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
	{
		MSG_ERROR("[DMS]request_fota_install!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
		return RESULT_FAILURE;
	}
	else
	{
		return RESULT_SUCCESS;
	}
}

/*===========================================================================

  FUNCTION  ril_request_fota_user_cancel
  
===========================================================================*/
uint8 ril_request_fota_user_cancel()
{
	int rc = QMI_NO_ERR;
	qmi_dms_rsp_data_type dms_rsp_data;

	if(dms_client_handle == INVALID_HANDLE_VALUE)
	return RESULT_FAILURE;

	ALOGD("onRequest ril_request_fota_user_cancel \r\n");

	rc = request_fota_install((int)dms_client_handle, &dms_rsp_data);
	if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
	{
		MSG_ERROR("[DMS]request_fota_install!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
		return RESULT_FAILURE;
	}
	else
	{
		return RESULT_SUCCESS;
	}
}

/*===========================================================================

  FUNCTION  ril_request_fota_bl_install
  
===========================================================================*/
uint8 ril_request_fota_bl_install()
{
	int rc = QMI_NO_ERR;
	qmi_dms_rsp_data_type dms_rsp_data;

	if(dms_client_handle == INVALID_HANDLE_VALUE)
	return RESULT_FAILURE;

	ALOGD("onRequest ril_request_fota_bl_install \r\n");

	rc = request_fota_bl_install((int)dms_client_handle, &dms_rsp_data);
	if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
	{
		MSG_ERROR("[DMS]request_fota_bl_install!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
		return RESULT_FAILURE;
	}
	else
	{
		return RESULT_SUCCESS;
	}
}
#endif
//ygpark.20141201 -
/*===========================================================================

  FUNCTION  request_set_time
  
===========================================================================*/
uint8 request_set_time(uint64 user_time)
{
  int rc = QMI_NO_ERR;
  dms_set_time_req_msg_v01 req_data;
  qmi_dms_rsp_data_type dms_rsp_data;
  
  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  req_data.time_in_ms = user_time;
  req_data.time_reference_type_valid = TRUE;
  req_data.time_reference_type = (dms_time_ref_type_enum_v01)0x0; //User Time
  
  rc = qmi_dms_set_time((int)dms_client_handle, &req_data, &dms_rsp_data);
  if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_set_time!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}



void convert_second_from_19800106_to_system_time( uint64 second_from_19800106, system_time_s* system_time )
{
	const uint16 days_of_quad_year = ( 366 + ( 3 * 365 ) );
	
	const uint16 days_per_quad_year[] = { 0,
																				 366,
																				 366 + 365,
																				 366 + 365 + 365,
																				 366 + 365 + 365 + 365 };

	const uint16 days_per_month[] = { 0,
																		 31,
																		 31 + 28,
																		 31 + 28 + 31,
																		 31 + 28 + 31 + 30,
																		 31 + 28 + 31 + 30 + 31,
																		 31 + 28 + 31 + 30 + 31 + 30,
																		 31 + 28 + 31 + 30 + 31 + 30 + 31,
																		 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31,
																		 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30,
																		 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31,
																		 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30,
																		 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30 + 31 };

const uint16 days_per_leap_month[] = { 0,
																				31,
																				31 + 29,
																				31 + 29 + 31,
																				31 + 29 + 31 + 30,
																				31 + 29 + 31 + 30 + 31,
																				31 + 29 + 31 + 30 + 31 + 30,
																				31 + 29 + 31 + 30 + 31 + 30 + 31,
																				31 + 29 + 31 + 30 + 31 + 30 + 31 + 31,
																				31 + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30,
																				31 + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31,
																				31 + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30,
																				31 + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30 + 31 };

  uint64 year_index, month_index;
	uint64 total_seconds, total_minutes, total_hours, total_days, total_quad_years;
	uint64 month, day;
	
	uint16* days_per_month_ptr;

	total_seconds 	 = second_from_19800106 + (uint64)( 3600 * 24 * 5 );	//calculate from 1980-01-01
	total_minutes 	 = total_seconds / 60;	
	total_hours   	 = total_minutes / 60;
	total_days    	 = total_hours / 24;
	total_quad_years = total_days / days_of_quad_year;

	day = total_days % days_of_quad_year;

  for ( year_index = 0; day >= (uint64)( days_per_quad_year[ year_index + 1 ] ); ++year_index )
  {
  }

	day = day - (uint64)( days_per_quad_year[ year_index ] );
	
	if ( 0 == year_index )
		days_per_month_ptr = days_per_leap_month;
	else
		days_per_month_ptr = days_per_month;
	
  for ( month_index = 0; day >= (uint64)( days_per_month_ptr[ month_index + 1 ] ); ++month_index )
  {
  }
	
	day = day - (uint64)days_per_month_ptr[ month_index ] + 1;
	month = month_index + 1;

	system_time->year		= (uint16)( (uint64)1980 + ( total_quad_years * 4 ) + year_index );
	system_time->month		= (uint8)month;
	system_time->day			= (uint8)day;
	system_time->hour	 	= (uint8)( total_hours % 24 );
	system_time->minute 	= (uint8)( total_minutes % 60 );
	system_time->second 	= (uint8)( total_seconds % 60 );

	{
		char temp_str[ 256 ];

		sprintf( temp_str, "convert_second_from_19800106_to_system_time() %04d/%02d/%02d-%02d:%02d:%02d",
														system_time->year, 
														system_time->month,
														system_time->day,
														system_time->hour,
														system_time->minute,
														system_time->second );
		
		MSG_HIGH( "%s", temp_str, 0, 0 );
	}
}



bool request_get_system_time( system_time_s* system_time )
{
  int r = QMI_NO_ERR;	

	//request parameter
	unsigned char	msg_buf[ QMI_MAX_STD_MSG_SIZE ];
	int						num_bytes_in_msg_buf = 0;
	
	unsigned char		reply_buf[ QMI_MAX_STD_MSG_SIZE ];
	int 						reply_buf_size = 0;
	unsigned char*	reply_buf_ptr = reply_buf;
	
	int qmi_err_code = QMI_SERVICE_ERR_NONE;

	//result parameter
	dms_get_time_resp_msg_v01 rsp;
	
  unsigned long type;
  unsigned long length;
  unsigned char *value;

  unsigned short			temp_16bit;
	unsigned long long	temp_64bit;
  unsigned char				temp_var[ 64 ];

	//buffer initialize
  memset( msg_buf, 0x0, sizeof( msg_buf ) );
	memset( reply_buf, 0x0, sizeof( reply_buf ) );

	memset( &rsp, 0x0, sizeof( rsp ) );
	
  r = qmi_service_send_msg_sync( (int)dms_client_handle,				//user_handle
  																   QMI_DMS_SERVICE,									//service_id
  																   QMI_DMS_GET_TIME_REQ_V01,				//msg_id
  																   QMI_SRVC_PDU_PTR( msg_buf ),		//msg_buf
  																   num_bytes_in_msg_buf,						//num_bytes_in_msg_buf
  																   reply_buf,												//reply_buf
  																   &reply_buf_size,									//reply_buf_size_ptr
  																   sizeof( reply_buf ),							//reply_buf_size
  																   QMI_SYNC_MSG_DEFAULT_TIMEOUT,		//timeoust_secs
  																   &qmi_err_code );									//qmi_err_code
  																   
	if ( QMI_NO_ERR != r )
	{
	  MSG_ERROR( "request_get_system_time() qmi_service_send_msg_sync() fail, r:%d", r, 0, 0 );
	  return FALSE;
	}
	
  if ( QMI_SERVICE_ERR_NONE != qmi_err_code )
	{
	  MSG_ERROR( "request_get_system_time() fail, qmi_err_code:%d", qmi_err_code, 0, 0 );
		return FALSE;
  }

	rsp.resp.result = QMI_RESULT_SUCCESS_V01;
	rsp.resp.error = QMI_ERR_NONE_V01;
	
  while ( reply_buf_size > 0 )
	{
    if ( qmi_util_read_std_tlv( &reply_buf_ptr,
                                   &reply_buf_size,
                                   &type,
                                   &length,
                                   &value ) < 0 )
    {
  		MSG_ERROR( "request_get_system_time() qmi_util_read_std_tlv() fail", 0, 0, 0 );
      return FALSE;
    }

		switch( type )
		{
		case QMI_TYPE_REQUIRED_PARAMETERS:	//device time
			{
				READ_VAR_BIT_VAL( value, temp_var[ 0 ], sizeof( rsp.device_time.time_count ) );
				READ_16_BIT_VAL( value, temp_16bit );

				memcpy( rsp.device_time.time_count, temp_var, sizeof( rsp.device_time.time_count ) );
				rsp.device_time.time_source = (dms_time_source_enum_v01)temp_16bit;
			}
			break;

		case DMSI_PRM_TYPE_SYS_TIME:	//system time
			{
				READ_64_BIT_VAL( value, temp_64bit );

				rsp.sys_time_in_ms_valid = TRUE;
				rsp.sys_time_in_ms = temp_64bit;
			}
			break;

		case DMSI_PRM_TYPE_USR_TIME:	//user time
			{
				READ_64_BIT_VAL( value, temp_64bit );

				rsp.user_time_in_ms_valid = TRUE;
				rsp.user_time_in_ms = temp_64bit;
			}
			break;
		}
	}	

	if ( FALSE == rsp.sys_time_in_ms_valid )
	{
	  MSG_ERROR( "request_get_system_time() sys_time_in_ms_valid is not valid", 0, 0, 0 );
		return FALSE;
	}

	MSG_HIGH( "request_get_system_time() time_source:%d, sys_time:%lu, user_time:%lu", 
														rsp.device_time.time_source,
														rsp.sys_time_in_ms, 
														rsp.user_time_in_ms );

	convert_second_from_19800106_to_system_time( ( rsp.sys_time_in_ms / 1000 ), system_time );

	if ( system_time->year < 2015 )
	{
	  MSG_ERROR( "request_get_system_time() system time is not valid", 0, 0, 0 );
	  ALOGD( "request_get_system_time() system time is not valid", 0, 0, 0 );
	  return FALSE;
	}

	return TRUE;
}

/*===========================================================================

  FUNCTION  ril_request_get_exception_count
  
===========================================================================*/
uint8 ril_request_get_exception_count(uint8 *count)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;
  
  if(dms_client_handle == QMI_INVALID_CLIENT_HANDLE)
    return RESULT_FAILURE;
    
  rc = qmi_dms_get_exception_count((int)dms_client_handle, &dms_rsp_data);
  
  if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    printf("[DMS]qmi_dms_get_exception_count!! rc: %d err_code : %d\r\n",rc,dms_rsp_data.qmi_err_code);
    return RESULT_FAILURE;
  }
  else
  {
    *count = dms_rsp_data.rsp_data.exception_count;
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  ril_request_get_exception_info
  
===========================================================================*/
uint8 ril_request_get_exception_info(uint8 index, dms_modem_exception_info_type_v01* exception_info)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;

  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_dms_get_exception_info((int)dms_client_handle, index, &dms_rsp_data);

  if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_get_exception_info!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    #if 0
      printf("[ril_request_get_exception_info data] ==============\n");
      printf("%s\n", dms_rsp_data.rsp_data.modem_exception_info_rsp.modem_sw_version);
      printf("%s\n", dms_rsp_data.rsp_data.modem_exception_info_rsp.exception_date);
      printf("%s\n", dms_rsp_data.rsp_data.modem_exception_info_rsp.exception_time);
      printf("%d\n", dms_rsp_data.rsp_data.modem_exception_info_rsp.exception_line);
      printf("%s\n", dms_rsp_data.rsp_data.modem_exception_info_rsp.exception_file);
      printf("%s\n", dms_rsp_data.rsp_data.modem_exception_info_rsp.exception_msg);
      printf("=========================\n");
    #endif

    memcpy(exception_info, &dms_rsp_data.rsp_data.modem_exception_info_rsp, sizeof(dms_modem_exception_info_type_v01));
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  ril_request_delete_exception_info
  
===========================================================================*/
uint8 ril_request_delete_exception_info(void)
{
  int rc = QMI_NO_ERR;
  qmi_dms_rsp_data_type dms_rsp_data;

  if(dms_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_dms_delete_exception_info((int)dms_client_handle, &dms_rsp_data);

  if(rc != QMI_NO_ERR || dms_rsp_data.qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[DMS]qmi_dms_delete_exception_info!! rc: %d err_code : %d",rc,dms_rsp_data.qmi_err_code,0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }

  return RESULT_SUCCESS;
}

