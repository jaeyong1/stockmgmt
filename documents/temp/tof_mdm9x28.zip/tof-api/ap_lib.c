/******************************************************************************
  @file    ap_lib.c
  @brief   The TOF API for application processor

  DESCRIPTION

  GPIO CONTROL

  ---------------------------------------------------------------------------
  Copyright (c) 2016 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/

#include <ap_lib.h>

int gpio_export( int gpio)
{
 int fd, len;
 char buf[MAX_BUF];

 fd = open(SYSFS_GPIO_DIR "/export", O_WRONLY);

 if (fd < 0) {
	 //fprintf(stderr, "Can't export GPIO %d pin: %s\n", gpio, strerror(errno));
	 return fd;
 }

 len = snprintf(buf, sizeof(buf), "%d", gpio);
 write(fd, buf, len);
 close(fd);

 return 0;
}

int gpio_is_exported( int gpio)
{
 int fd;
 char buf[MAX_BUF];

 snprintf(buf, sizeof(buf), SYSFS_GPIO_DIR "/gpio%d/direction", gpio);

 fd = open(buf, O_RDONLY);

 if (fd < 0) {
	 //fprintf(stderr, "Can't get GPIO %d pin direction: %s\n", gpio, strerror(errno));
	 return 0;
 }
 
 close(fd);

 return 1;
}


int gpio_unexport( int gpio)
{
 int fd, len;
 char buf[MAX_BUF];

 fd = open(SYSFS_GPIO_DIR "/unexport", O_WRONLY);

 if (fd < 0) {
	 //fprintf(stderr, "Can't unexport GPIO %d pin: %s\n", gpio, strerror(errno));
	 return fd;
 }

 len = snprintf(buf, sizeof(buf), "%d", gpio);
 write(fd, buf, len);
 close(fd);

 return 0;
}

int gpio_get_dir( int gpio,  char* dir)
{
 int fd;
 char buf[MAX_BUF];

 snprintf(buf, sizeof(buf), SYSFS_GPIO_DIR "/gpio%d/direction", gpio);

 fd = open(buf, O_RDONLY);

 if (fd < 0) {
	 //fprintf(stderr, "Can't get GPIO %d pin direction: %s\n", gpio, strerror(errno));
	 return fd;
 }
 
 if (read(fd, buf, MAX_BUF) == -1) {
     //fprintf(stderr, "Can't read gpio%d/direction pin: %s\n", gpio, strerror(errno));
     return -1;
 }
 close(fd);
 
 if(strncmp("in", buf, 2) == 0)
 {
     strncpy(dir, "in", 2);
     dir[2] = '\0';
 }
 else if(strncmp("out", buf, 3) == 0)
 {
     strncpy(dir, "out", 3);
     dir[3] = '\0';
 }
 else
 {
     fprintf(stderr, "Can't find edge %s\n", strerror(errno));
     return -1;
 }
 
 return 0;
}

int gpio_set_dir( int gpio,  int dir)
{
 int fd;
 char buf[MAX_BUF];

 snprintf(buf, sizeof(buf), SYSFS_GPIO_DIR  "/gpio%d/direction", gpio);

 fd = open(buf, O_WRONLY);

 if (fd < 0) {
	 //fprintf(stderr, "Can't set GPIO %d pin direction: %s\n", gpio, strerror(errno));
	 return fd;
 }

 if (dir == GPIO_OUTPUT) {
	 write(fd, "out", 4);
 } else {
	 write(fd, "in", 3);
 }

 close(fd);

 return 0;
}

int gpio_get_val( int gpio,  int *val)
{
 int fd;
 char buf[MAX_BUF];

 snprintf(buf, sizeof(buf), SYSFS_GPIO_DIR "/gpio%d/value", gpio);

 fd = open(buf, O_RDONLY);

 if (fd < 0) {
	 //fprintf(stderr, "Can't get GPIO %d pin value: %s\n", gpio, strerror(errno));
	 return fd;
 }

 read(fd, buf, 1);
 close(fd);

 if (*buf != '0')
	 *val = GPIO_HIGH;
 else
	 *val = GPIO_LOW;

 return 0;
}

int gpio_set_val( int gpio,  int val)
{
 int fd;
 char buf[MAX_BUF];

 snprintf(buf, sizeof(buf), SYSFS_GPIO_DIR "/gpio%d/value", gpio);

 fd = open(buf, O_WRONLY);

 if (fd < 0) {
	 //fprintf(stderr, "Can't set GPIO %d pin value: %s\n", gpio, strerror(errno));
	 return fd;
 }

 if (val == GPIO_HIGH)
	 write(fd, "1", 2);
 else
	 write(fd, "0", 2);

 close(fd);

 return 0;
}

int gpio_set_edge( int gpio, char *edge)
{
 int fd;
 char buf[MAX_BUF];

 snprintf(buf, sizeof(buf), SYSFS_GPIO_DIR "/gpio%d/edge", gpio);

 fd = open(buf, O_WRONLY);

 if (fd < 0) {
	 //fprintf(stderr, "Can't set GPIO %d pin edge: %s\n", gpio, strerror(errno));
	 return fd;
 }

 write(fd, edge, strlen(edge)+1);
 close(fd);

 return 0;
}

int gpio_get_edge(int gpio, char* edge)
{
    int fd;
    char buf[MAX_BUF];

    snprintf(buf, sizeof(buf), SYSFS_GPIO_DIR "/gpio%d/edge", gpio);
	
    fd = open(buf, O_RDONLY);

    if(fd < 0){
        //fprintf(stderr, "Can't get GPIO %d pin value: %s\n", gpio, strerror(errno));
        return fd;
    }

	if (read(fd, buf, MAX_BUF) == -1) {
        //fprintf(stderr, "Can't read gpio%d/edge pin: %s\n", gpio, strerror(errno));
        return -1;
    }
    close(fd);

    if(strncmp("none", buf, 4) == 0)
    {
        strncpy(edge, "none", 4);
        edge[4] = '\0';
    }
    else if(strncmp("falling", buf, 7) == 0)
    {
        strncpy(edge, "falling", 7);
        edge[7] = '\0';
    }
    else if(strncmp("rising", buf, 6) == 0)
    {
        strncpy(edge, "rising", 6);
        edge[6] = '\0';
    }
    else if(strncmp("both", buf, 4) == 0)
    {
        strncpy(edge,"both", 4);
        edge[4] = '\0';
    }
    else
    {
        fprintf(stderr, "Can't find edge %s\n", strerror(errno));
        return 1;
    }

 return 0;
}

int gpio_fd_open(int gpio)
{
    int fd;
    char buf[MAX_BUF];

    snprintf(buf, sizeof(buf), SYSFS_GPIO_DIR "/gpio%d/value", gpio);

    fd = open(buf, O_RDONLY|O_NONBLOCK);

    if (fd < 0)
      {
        //fprintf(stderr, "Can't open GPIO %d pin: %s\n", gpio, strerror(errno));
        return fd;
      }
    
    return fd;
}

int gpio_fd_close(int fd)
{
    return close(fd);
}

int gpio_read(int fd, int *val)
{
    int ret;
    char ch; 

    lseek(fd, 0, SEEK_SET);

    ret = read(fd, &ch, 1);

    if (ret != 1) {
        fprintf(stderr, "Can't read GPIO pin: %s\n", strerror(errno));
        return ret;
    }

    if (ch != '0')
        *val = GPIO_HIGH;
    else
        *val = GPIO_LOW;

    return 0;
}

int (*gpio_check)(int gpio);
int (*gpio_trans)(int gpio);
void (*print_supported_gpios)(void);

int gpio_check_clarion( int gpio)
{
    switch(gpio)
   {
		case 70:
    case 71:
    case 72:
    case 33:
    case 34: //INT
    case 35: //INT
    case 75:
    case 91:
    case 92:
    case 93:
    case 94:
      return 1; //Supported gpio
    default:
			return 0; //Unsupported gpio
		break;
   }    
}

int gpio_trans_clarion( int gpio)
{
  switch(gpio)
     {
      case 70:
        return 75; 
      case 71:
        return 26;
      case 72:
        return 38;
      case 33:
        return 53;
      case 34: //INT
        return 10;
      case 35: //INT
        return 11;
      case 75:
        return 54;
      case 91:
        return 78;
      case 92:
        return 79;
      case 93:
        return 76;
      case 94:
        return 77;
      default:
        return 255; //Unsupported gpio
      break;
     } 
}
void print_supported_gpios_clarion()
{
  printf("PAD : PIN NAME \n");
  printf("==================== \n");
  printf(" 70 : GPIO8 \n");
  printf(" 71 : GPIO9 \n");
  printf(" 72 : GPIO10 \n");
  printf(" 33 : DSRC_PPS \n");
  printf(" 34 : MDM2AP_INT_N \n");
  printf(" 35 : AP2MDM_INT_N \n");
  printf(" 75 : GPS_LNA_EN \n");
  printf(" 91 : PCM_CLK \n");
  printf(" 92 : PCM_SYNC \n");
  printf(" 93 : PCM_DIN \n");        
  printf(" 94 : PCM_DOUT \n");        
}

int gpio_check_bosch(int gpio)
{
    switch(gpio)
    {
    case 68:
    case 69:
        return 1;
    default:
        return 0; //Unsupported gpio
    break;
    }
}

int gpio_trans_bosch(int gpio)
{
    switch(gpio)
    {
    case 68:
        return 6;
    case 69:
        return 7;
    default:
        return 255; //Unsupported gpio
    break;
    }
}

void print_supported_gpios_bosch()
{
  printf("PAD : PIN NAME \n");
  printf("==================== \n");
  printf(" 68 : GPIO6 \n");
  printf(" 69 : GPIO7 \n");
}

int request_get_ap_version(char* AP_version)
{
  int fd;
  char* ptr;
  char buf[MAX_BUF];

  if(0 > ( fd = open(AP_VERSION_PATH,O_RDONLY))) //Get AP version file string fron /etc/version.info
  {
    return RESULT_FAIL;
  }
  read(fd, &buf, MAX_BUF);
  ptr = strtok( buf, "="); //Cut useless string("version=" in /etc/version.info)
  ptr = strtok( NULL, "=");
  ptr[strlen(ptr)-1]='\0'; //Remove carriage return character
  strcpy(AP_version,ptr);
  close(fd);

  return RESULT_SUCCESS;
}

int is_supported_usb_composition(char *idproduct)
{
	int length = strlen(idproduct);

	if(length != USB_PID_LENGTH)
	{
		return RESULT_FAIL;
	}

	if(!strncmp(USB_PID_3100, idproduct, USB_PID_LENGTH)
		|| !strncmp(USB_PID_3300, idproduct, USB_PID_LENGTH)
		|| !strncmp(USB_PID_3301, idproduct, USB_PID_LENGTH))
	{
		return RESULT_SUCCESS;
	}

	return RESULT_FAIL;
}

int check_usb_composition(char *idproduct)
{
	int fd;
	char buf[5] = {0,};

	if(is_supported_usb_composition(idproduct) == RESULT_FAIL)
	{
		return RESULT_FAIL;
	}

	if(0 > (fd = open(SYSFS_USB_IDPRODUCT, O_RDONLY)))
	{
		return RESULT_FAIL;
	}

	read(fd, &buf, 4);

	if(!strncmp(buf, idproduct, USB_PID_LENGTH))
	{
		return RESULT_SUCCESS;
	}
	return RESULT_FAIL;
}

int change_usb_composition(char *idproduct, int make_default)
{
	char command[60] = {0,};

	if(is_supported_usb_composition(idproduct) == RESULT_FAIL)
	{
		return RESULT_FAIL;
	}

	sprintf(command, "start-stop-daemon -S -b -a usb_composition %s n %s y y", idproduct, make_default==1 ? "y":"n");
	system(command);

	sleep(2);
	system("sync");

	return check_usb_composition(idproduct);
}

int get_enabled_usb_composition(void)
{
	int fd;
	char buf[5] = {0,};

	if(0 > (fd = open(SYSFS_USB_IDPRODUCT, O_RDONLY)))
	{
		return RESULT_FAIL;
	}

	read(fd, &buf, 4);

	if(!strncmp(buf, USB_PID_3100, USB_PID_LENGTH))
	{
		return 0x3100;
	}
	if(!strncmp(buf, USB_PID_3300, USB_PID_LENGTH))
	{
		return 0x3300;
	}
	else if(!strncmp(buf, USB_PID_3301, USB_PID_LENGTH))
	{
		return 0x3301;
	}

	return RESULT_FAIL;
}

int disable_usb_composition(void)
{
	int fd;
	char buf[2] = {0,};

	if(0 > (fd = open(SYSFS_USB_ENABLE, O_WRONLY)))
	{
		return RESULT_FAIL;
	}

	write(fd, buf, 1);

	return RESULT_SUCCESS;
}

int get_usb_mode(char *buf)
{
	int fd;
	char tmp_buf[11] = {0,};

	if(0 > (fd = open(SYSFS_USB_MODE, O_RDONLY)))
	{
		return RESULT_FAIL;
	}

	read(fd, &tmp_buf, 15);

	if (!strncmp("host", tmp_buf, strlen("host")))
		strncpy(buf, "host", strlen("host"));
	else if(!strncmp("peripheral", tmp_buf, strlen("peripheral")))
		strncpy(buf, "peripheral", strlen("peripheral"));
	else
		strncpy(buf, "none", strlen("none"));

	return RESULT_SUCCESS;
}

int change_usb_mode(char *mode)
{
	int fd;

	if(0 > (fd = open(SYSFS_USB_MODE, O_WRONLY)))
	{
		return RESULT_FAIL;
	}

	if (!strncmp("host", mode, strlen("host")))
	{
		write(fd, "host", strlen("host"));
		return RESULT_SUCCESS;
	}
	else if (!strncmp("peripheral", mode, strlen("peripheral")))
	{
		write(fd, "peripheral", strlen("peripheral"));
		return RESULT_SUCCESS;
	}
	return RESULT_FAIL;
}

extern int usb_storage_state;
extern char *usb_storage_state_tostring(int state);

int get_usb_storage_state(char *state)
{
	int ret;

	printf("get_usb_storage_state usb_storage_state = %d\n", usb_storage_state);

	ret = strcpy(state, usb_storage_state_tostring(usb_storage_state));

	printf("get_usb_storage_state state = %s\n", state);

	if (ret)
		return RESULT_SUCCESS;
	else
		return RESULT_FAIL;
}

int GetPIDbyName(char* pidName)
{
    FILE *fp;
    char pidofCmd[50]={0};
    int pidValue=-1;
        
    if(pidName != 0) {
        strcpy(pidofCmd, "pidof ");
        strcat(pidofCmd, pidName);
        strcat(pidofCmd,  "> /tmp/pidof");
        system(pidofCmd); 
        fp = fopen("/tmp/pidof", "r");
        fscanf(fp, "%d", &pidValue);
        fclose(fp);
    }
    return pidValue;
}

int read_clock_config(int *source, int *gmt)
{
	int rt = 0;
	FILE *fp = NULL;
	fp = fopen(CLOCK_CONFIG_FILE, "r");
	if(fp == NULL) {
		rt = -1;
    printf("clock_config file read failed!\n");
		return rt;
	}
	fscanf(fp, "source=%d\n",source);
	fscanf(fp, "gmt=%d\n", gmt);  
  
	fclose(fp);
	return rt;
}

int write_clock_config(int source, int gmt)
{
  int rt = 0;

  FILE *fp = NULL;
  fp = fopen(CLOCK_CONFIG_FILE, "w+");
  if(fp == NULL) {
    rt = -1;
    return rt;
  }

  fprintf(fp, "source=%d\n", source);
  fprintf(fp, "gmt=%d\n", gmt);

  fflush(fp);
  fclose(fp);
  
  return rt;
}

int write_ntp_config(char* server, int port)
{
  int rt = 0;

  FILE *fp = NULL;
  fp = fopen(NTP_CONFIG_FILE, "w+");
  if(fp == NULL) {
    rt = -1;
    return rt;
  }

  fprintf(fp, "server=%s\n", server);
  fprintf(fp, "port=%d\n", port);
  fprintf(fp, "retry_count=%d\n", DEFAULT_NTP_COUNT);
  fprintf(fp, "retry_delay=%d\n", DEFAULT_NTP_DELAY);

  fflush(fp);
  fclose(fp);
  
  return rt;
}

int write_reboot_reason(char *reason)
{
  int rt = 0;

  FILE *fp = NULL;
  fp = fopen(REBOOT_REASON_FILE, "w+");
  if(fp == NULL) {
    rt = -1;
    return rt;
  }
  fprintf(fp, "%.*s\n",REBOOT_REASON_LENGTH-1,reason);
  fflush(fp);
  fclose(fp);
  
  return rt;
}

int read_reboot_reason(char *reason)
{
  int rt = 0;
  FILE *fp = NULL;
  char buf[REBOOT_REASON_LENGTH]={0};
  fp = fopen(REBOOT_REASON_FILE, "r");
  if(fp == NULL) {
  rt = -1;
  printf("reboot reason file read failed!\n");
  return rt;
  }
  fread(buf, 1, REBOOT_REASON_LENGTH-1, fp);
  strcpy(reason, buf);
  fclose(fp);
  return rt;
}

