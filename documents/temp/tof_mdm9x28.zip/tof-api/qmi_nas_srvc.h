#ifndef QMI_NAS_SRVC_H
#define QMI_NAS_SRVC_H

/******************************************************************************
  @file    qmi_nas_srvc.h
  @brief   QMI NAS SRVC header

  $Id$

  DESCRIPTION

  INITIALIZATION AND SEQUENCING REQUIREMENTS

  ---------------------------------------------------------------------------
  Copyright (c) 2013 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/
#include "qmi.h"
//#include "qmi_uim_srvc.h"
#include "network_access_service_v01.h"
#include "device_management_service_v01.h"


#include "wmmdiag_packet.h"
#include "TOF_Definition.h"

#include "Debug_string.h"

#ifdef __cplusplus
extern "C" {
#endif

//typedef void           *qmi_client_type;
typedef int            qmi_client_error_type;
typedef void           *qmi_txn_handle;


typedef enum
{
  QMI_NAS_NO_SERVICE        = 0x00,
  QMI_NAS_CDMA_20001x       = 0x01,
  QMI_NAS_CDMA_2000_HRPD    = 0x02,
  QMI_NAS_AMPS              = 0x03,
  QMI_NAS_GSM               = 0x04,
  QMI_NAS_UMTS              = 0x05,
  QMI_NAS_WLAN              = 0x06,
  QMI_NAS_GPS               = 0x07,
  QMI_NAS_LTE               = 0x08
}qmi_nas_radio_interface;


/*Get serving System Related*/
typedef enum
{
  QMI_NAS_NOT_REGISTERED            = 0,
  QMI_NAS_REGISTERED                = 1,
  QMI_NAS_NOT_REGISTERED_SEARCHING  = 2,
  QMI_NAS_REGISTRATION_DENIED       = 3,
  QMI_NAS_REGISTRATION_UNKNOWN      = 4
}qmi_nas_registration_state;

typedef enum
{
  QMI_NAS_CS_ATTACH_UNKNOWN_OR_NOTAPPLICABLE    = 0,
  QMI_NAS_CS_ATTACHED   = 1,
  QMI_NAS_CS_DETACHED   = 2
}qmi_nas_cs_attach_state;

typedef enum
{
  QMI_NAS_PS_ATTACH_UNKNOWN_OR_NOTAPPLICABLE    = 0,
  QMI_NAS_PS_ATTACHED   = 1,
  QMI_NAS_PS_ATTACH = QMI_NAS_PS_ATTACHED,
  QMI_NAS_PS_DETACHED   = 2,
  QMI_NAS_PS_DETACH = QMI_NAS_PS_DETACHED
}qmi_nas_ps_attach_state;

typedef enum
{
  QMI_NAS_REG_NETWORK_UNKNOWN   = 0x00,
  QMI_NAS_REG_NETWORK_3GPP2     = 0x01,
  QMI_NAS_REG_NETWORK_3GPP      = 0x02
}qmi_nas_reg_network_type;

typedef enum
{
  QMI_NAS_DS_CAPABILITY_NONE = 0x00,
  QMI_NAS_DS_CAPABILITY_GPRS = 0x01,
  QMI_NAS_DS_CAPABILITY_EDGE = 0x02,
  QMI_NAS_DS_CAPABILITY_HSDPA = 0x03,   
  QMI_NAS_DS_CAPABILITY_HSUPA = 0x04,
  QMI_NAS_DS_CAPABILITY_WCDMA = 0x05,
  QMI_NAS_DS_CAPABILITY_MAX = QMI_NAS_DS_CAPABILITY_WCDMA
} qmi_nas_ds_capability_type;

#define QMI_NAS_ROAMING_INDICATOR_PARAM_TYPE    0x0001
#define QMI_NAS_CURRENT_PLMN_PARAM_TYPE         0x0002
#define QMI_NAS_DS_CAPABILITY_PARAM_TYPE         0x0004

typedef enum
{
    PREF_NET_TYPE_GSM_WCDMA                = 0, /* GSM/WCDMA (WCDMA preferred) */
    PREF_NET_TYPE_GSM_ONLY                 = 1, /* GSM only */
    PREF_NET_TYPE_WCDMA                    = 2, /* WCDMA  */
    PREF_NET_TYPE_GSM_WCDMA_AUTO           = 3, /* GSM/WCDMA (auto mode, according to PRL) */
    PREF_NET_TYPE_CDMA_EVDO_AUTO           = 4, /* CDMA and EvDo (auto mode, according to PRL) */
    PREF_NET_TYPE_CDMA_ONLY                = 5, /* CDMA only */
    PREF_NET_TYPE_EVDO_ONLY                = 6, /* EvDo only */
    PREF_NET_TYPE_GSM_WCDMA_CDMA_EVDO_AUTO = 7, /* GSM/WCDMA, CDMA, and EvDo (auto mode, according to PRL) */
    PREF_NET_TYPE_LTE_CDMA_EVDO            = 8, /* LTE, CDMA and EvDo */
    PREF_NET_TYPE_LTE_GSM_WCDMA            = 9, /* LTE, GSM/WCDMA */
    PREF_NET_TYPE_LTE_CMDA_EVDO_GSM_WCDMA  = 10, /* LTE, CDMA, EvDo, GSM/WCDMA */
    PREF_NET_TYPE_LTE_ONLY                 = 11,  /* LTE only */
    PREF_NET_TYPE_LTE_850                   = 12,  /* LTE 850 only */
    PREF_NET_TYPE_LTE_1800                 = 13,  /* LTE 1800 only */
    PREF_NET_TYPE_LTE_BAND4                = 14,  /* LTE BAND4 only */
    PREF_NET_TYPE_LTE_BAND13               = 15,  /* LTE BAND13 only */
    PREF_NET_TYPE_LTE_WCDMA                =16,  /* LTE, WCDMA */
    PREF_NET_TYPE_MAX
} pref_net_type;

//hongsg 20140729
typedef enum
{
    REQUEST_REG_EVENT             = 0
} ims_reg_event_request_type;

typedef enum
{
    REQUEST_RTCP             = 0
} ims_qipcall_request_type;

typedef enum
{
		REQUEST_IMS_USER_AGENT = 0
} ims_user_agent_type;

//--> RIL_REQUEST_APN_SETTING
typedef enum
{
    REQUEST_CLASS_ID          = 0,
    REQUEST_APN_NAME          = 1,
    REQUEST_IP_TYPE           = 2,
    REQUEST_APN_ENABLED       = 3,
    REQUEST_INACTIVITY_TIMER  = 4,
    REQUEST_BEARER_TYPE       = 5,
    REQUEST_MAX_CONN          = 6,
    REQUEST_MAX_CONN_T        = 7,
    REQUEST_WAIT_TIME         = 8,
    REQUEST_APN_MAX
} request_apn_type;
//<-- RIL_REQUEST_APN_SETTING


#pragma pack(1)

/*---------------------------------------------------------------------------
  Shared Constants
---------------------------------------------------------------------------*/
#define MAX_ECIO_THRESHOLDS        (10)
#define MAX_SINR_THRESHOLDS        (5)

#define NAS_IS_856_MAX_LEN         (16)


/*---------------------------------------------------------------------------
  QMI_NAS_SET_EVENT_REPORT
---------------------------------------------------------------------------*/

#define NAS_0002_REQ_T10                                      0x10
#define NAS_0002_REQ_T10_REPORT_SIGNAL_STRENGTH_DO_NOT_REPORT 0
#define NAS_0002_REQ_T10_REPORT_SIGNAL_STRENGTH_REPORT        1
#define NAS_0002_REQ_T10_NUM_SIGNAL_STRENGTH_THRESHOLDS_MAX   5

#define NAS_0002_REQ_T11                                   0x11
#define NAS_0002_REQ_T11_REPORT_RF_BAND_INFO_DO_NOT_REPORT 0
#define NAS_0002_REQ_T11_REPORT_RF_BAND_INFO_REPORT        1

#define NAS_0002_REQ_T12                                           0x12
#define NAS_0002_REQ_T12_REGISTRATION_REJECT_REASONS_DO_NOT_REPORT 0
#define NAS_0002_REQ_T12_REGISTRATION_REJECT_REASONS_REPORT        1

#define NAS_0002_REQ_T13                           0x13
#define NAS_0002_REQ_T13_REPORT_RSSI_DO_NOT_REPORT  0
#define NAS_0002_REQ_T13_REPORT_RSSI_REPORT         1
#define NAS_0002_REQ_T13_REPORT_RSSI_DELTA          4

#define NAS_0002_REQ_T14                           0x14
#define NAS_0002_REQ_T14_REPORT_ECIO_DO_NOT_REPORT  0
#define NAS_0002_REQ_T14_REPORT_ECIO_REPORT         1
#define NAS_0002_REQ_T14_REPORT_ECIO_DELTA          5

#define NAS_0002_REQ_T15                         0x15
#define NAS_0002_REQ_T15_REPORT_IO_DO_NOT_REPORT 0
#define NAS_0002_REQ_T15_REPORT_IO_REPORT        1
#define NAS_0002_REQ_T15_REPORT_IO_DELTA        3

#define NAS_0002_REQ_T16                           0x16
#define NAS_0002_REQ_T16_REPORT_SINR_DO_NOT_REPORT 0
#define NAS_0002_REQ_T16_REPORT_SINR_REPORT        1

#define NAS_0002_REQ_T17                                 0x17
#define NAS_0002_REQ_T17_REPORT_ERROR_RATE_DO_NOT_REPORT 0
#define NAS_0002_REQ_T17_REPORT_ERROR_RATE_REPORT        1

#define NAS_0002_REQ_T18                           0x18
#define NAS_0002_REQ_T18_REPORT_RSRQ_DO_NOT_REPORT 0
#define NAS_0002_REQ_T18_REPORT_RSRQ_REPORT        1
#define NAS_0002_REQ_T18_REPORT_RSRQ_DELTA           2                 // Range: -3 to -20

#define NAS_0002_REQ_T19                           0x19
#define NAS_0002_REQ_T19_REPORT_ECIO_DO_NOT_REPORT 0
#define NAS_0002_REQ_T19_REPORT_ECIO_REPORT        1

#define NAS_0002_REQ_T1A                           0x1A
#define NAS_0002_REQ_T1A_REPORT_SINR_DO_NOT_REPORT 0
#define NAS_0002_REQ_T1A_REPORT_SINR_REPORT        1

#define NAS_0002_REQ_T1B                               0x1B
#define NAS_0002_REQ_T1B_REPORT_LTE_SNR_DO_NOT_REPORT  0
#define NAS_0002_REQ_T1B_REPORT_LTE_SNR_REPORT         1
#define NAS_0002_REQ_T1B_REPORT_LTE_SNR_DELTA            10                     // 1 = 0.1, 10 = 1, 20 =2

#define NAS_0002_REQ_T1C                               0x1C
#define NAS_0002_REQ_T1C_REPORT_LTE_RSRP_DO_NOT_REPORT 0
#define NAS_0002_REQ_T1C_REPORT_LTE_RSRP_REPORT                1
#define NAS_0002_REQ_T1C_REPORT_LTE_RSRP_DELTA                   4            // Range : -44 to -140

typedef struct {
  struct nas_0002_req_t10_s {
    uint8 report_signal_strength;
    uint8 num_signal_strength_thresholds;
    int8 report_signal_strength_threshold_list[NAS_0002_REQ_T10_NUM_SIGNAL_STRENGTH_THRESHOLDS_MAX];
  } t10;
  struct nas_0002_req_t11_s {
    uint8 report_rf_band_info;
  } t11;

  struct nas_0002_req_t12_s {
    uint8 report_reg_reject;
  } t12;

  struct nas_0002_req_t13_s {
    uint8 report_rssi;
    uint8 rssi_delta;
  } t13;

  struct nas_0002_req_t14_s {
    uint8 report_ecio;
    uint8 ecio_delta;
  } t14;

  struct nas_0002_req_t15_s {
    uint8 report_io;
    uint8 io_delta;
  } t15;

  struct nas_0002_req_t16_s {
    uint8 report_sinr;
    uint8 sinr_delta;
  } t16;

  struct nas_0002_req_t17_s {
    uint8 report_error_rate;
  } t17;

  struct nas_0002_req_t18_s {
    uint8 report_rsrq;
    uint8 rsrq_delta;
  } t18;

  struct nas_0002_req_t19_s {
    uint8 report_ecio;
    uint8 num_thresholds;
    int16 threshold_list[MAX_ECIO_THRESHOLDS];
  } t19;

  struct nas_0002_req_t1A_s {
    uint8 report_sinr;
    uint8 num_thresholds;
    uint8 threshold_list[MAX_SINR_THRESHOLDS];
  } t1A;

  struct nas_0002_req_t1B_s {
    uint8  report_lte_snr;
    uint16 lte_snr_delta;
  } t1B;

  struct nas_0002_req_t1C_s {
    uint8 report_lte_rsrp;
    uint8 lte_rsrp_delta;
  } t1C;

  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
  boolean t14_valid;
  boolean t15_valid;
  boolean t16_valid;
  boolean t17_valid;
  boolean t18_valid;
  boolean t19_valid;
  boolean t1A_valid;
  boolean t1B_valid;
  boolean t1C_valid;
}nas_0002_req_s;

/*---------------------------------------------------------------------------
  QMI_NAS_EVENT_REPORT_IND
---------------------------------------------------------------------------*/

#define NAS_0002_IND_T10      0x10

#define NAS_0002_IND_T11      0x11
#define NAS_0002_IND_T11_MAX_RADIO_IFS      0x02

#define NAS_0002_IND_T12      0x12
#define NAS_0002_IND_T12_SERVICE_DOMAIN_CS      0x01
#define NAS_0002_IND_T12_SERVICE_DOMAIN_PS      0x02
#define NAS_0002_IND_T12_SERVICE_DOMAIN_CSPS      0x03

#define NAS_0002_IND_T13      0x13
#define NAS_0002_IND_T14      0x14
#define NAS_0002_IND_T15      0x15
#define NAS_0002_IND_T16      0x16
#define NAS_0002_IND_T17      0x17
#define NAS_0002_IND_T18      0x18
#define NAS_0002_IND_T19      0x19
#define NAS_0002_IND_T1A      0x1A

typedef struct
{
  struct nas_0002_ind_t10_s // Signal Strength TLV
  {
    int8  sig_strength;
    uint8 radio_if;
  } t10;

  struct nas_0002_ind_t11_s // RF Band Information List TLV
  {
    uint8 num_instances;
    struct nas_0002_ind_t11_rf_band_info_s
    {
      uint8  radio_if;
      uint16 active_band;
      uint16 active_channel;
    } rf_band[NAS_0002_IND_T11_MAX_RADIO_IFS];
  } t11;

  struct nas_0002_ind_t12_s // Registration Reject Reason
  {
    uint8  service_domain;
    uint16 reject_cause;
  } t12;

  struct nas_0002_ind_t13_s // RSSI TLV
  {
    uint8 rssi;
    uint8 radio_if;
  } t13;

  struct nas_0002_ind_t14_s // ECIO TLV
  {
    uint8 ecio;
    uint8 radio_if;
  } t14;

  struct nas_0002_ind_t15_s // IO TLV
  {
    int32 io;
  } t15;

  struct nas_0002_ind_t16_s // SINR TLV
  {
    uint8 sinr;
  } t16;

  struct nas_0002_ind_t17_s // Error Rate TLV
  {
    uint16 error_rate;
    uint8 radio_if;
  } t17;

  struct nas_0002_ind_t18_s // RSRQ TLV
  {
    int8  rsrq;
    uint8 radio_if;
  } t18;

  struct nas_0002_ind_t19_s
  {
    int16 lte_snr;
  } t19;

  struct nas_0002_ind_t1A_s
  {
    int16 lte_rsrp;
  } t1A;

  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
  boolean t14_valid;
  boolean t15_valid;
  boolean t16_valid;
  boolean t17_valid;
  boolean t18_valid;
  boolean t19_valid;
  boolean t1A_valid;
}nas_0002_ind_s;

/*---------------------------------------------------------------------------
  QMI_NAS_INDICATION_REGISTER
---------------------------------------------------------------------------*/
#define NAS_0003_REQ_T10      (0x10)
#define NAS_0003_REQ_T11      (0x11)
#define NAS_0003_REQ_T12      (0x12)
#define NAS_0003_REQ_T13      (0x13)
#define NAS_0003_REQ_T14      (0x14)
#define NAS_0003_REQ_T15      (0x15)
#define NAS_0003_REQ_T16      (0x16) //TODO: Try to remove this. It's ok for now.
#define NAS_0003_REQ_T17      (0x17)
#define NAS_0003_REQ_T18      (0x18) 
#define NAS_0003_REQ_T19      (0x19) 
#define NAS_0003_REQ_T1A      (0x1A) 
#define NAS_0003_REQ_T1B      (0x1B)
#define NAS_0003_REQ_T1C      (0x1C)
#define NAS_0003_REQ_T1D      (0x1D)
#define NAS_0003_REQ_T1E      (0x1E)
#define NAS_0003_REQ_T1F      (0x1F)
#define NAS_0003_REQ_T20      (0x20)
#define NAS_0003_REQ_T21      (0x21)
#define NAS_0003_REQ_T22      (0x22)
#define NAS_0003_REQ_T23      (0x23)
#define NAS_0003_REQ_T24      (0x24)
#define NAS_0003_REQ_DISABLE  (0x00)
#define NAS_0003_REQ_ENABLE   (0x01)

typedef struct {
  struct nas_0003_req_t10_s {
    uint8 reg_sys_sel_pref;
  } t10;
  
#if 0 // reserved
  struct nas_0003_req_t11_s {
  uint8 reg_current_nam;
  } t11;
#endif

  struct nas_0003_req_t12_s {
    uint8 reg_ddtm_events;
  } t12;

  struct nas_0003_req_t13_s {
    uint8 reg_serving_system;
  } t13;
  
  struct nas_0003_req_t14_s {
    uint8 dual_standby_pref;
  } t14;
  
  struct nas_0003_req_t15_s {
    uint8 subscription_info;
  } t15;
  
  struct nas_0003_req_t16_s {
    uint8 reg_thermal_emergency_state;
  } t16;
  
  struct nas_0003_req_t17_s {
    uint8 reg_network_time;
  } t17;
  
  struct nas_0003_req_t18_s {
    uint8 reg_sys_info;
  } t18;    
  
  struct nas_0003_req_t19_s {
    uint8 reg_sig_info;
  } t19;
  
  struct nas_0003_req_t1A_s {
    uint8 reg_err_rate;
  } t1A;
  
  struct nas_0003_req_t1B_s {
    uint8 uati;
  } t1B;
  
  struct nas_0003_req_t1C_s {
    uint8 session_close;
  } t1C;
  
  struct nas_0003_req_t1D_s {
    uint8 managed_roaming;
  } t1D;
  
  struct nas_0003_req_t1E_s {
    uint8 reg_current_plmn_name;
  } t1E;
  
  struct nas_0003_req_t1F_s {
    uint8 reg_embms_status;
  } t1F;
  
  struct nas_0003_req_t20_s {
    uint8 reg_rf_band_info;
  } t20;
  
  struct nas_0003_req_t21_s {
    uint8 reg_network_reject;
    uint8 suppress_sys_info;
  } t21;
  
  struct nas_0003_req_t22_s {
    uint8 reg_operator_name_data_ind;
  } t22;  
  
  struct nas_0003_req_t23_s {
    uint8 reg_csp_plmn_mode_bit_ind;
  } t23;
  
  struct nas_0003_req_t24_s {
    uint8 reg_rtre_cfg;
  } t24;

  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
  boolean t14_valid;
  boolean t15_valid;
  boolean t16_valid;
  boolean t17_valid;
  boolean t18_valid;
  boolean t19_valid;
  boolean t1A_valid;
  boolean t1B_valid;
  boolean t1C_valid;
  boolean t1D_valid;
  boolean t1E_valid;
  boolean t1F_valid;  
  boolean t20_valid;
  boolean t21_valid;
  boolean t22_valid;
  boolean t23_valid;
  boolean t24_valid;
}nas_0003_req_s;

/*---------------------------------------------------------------------------
  QMI_NAS_GET_SIGNAL_STRENGTH 
---------------------------------------------------------------------------*/
#define NAS_0020_RSP_MAX_RADIO_IFS   (2)

#define NAS_0020_RSP_SIG_STR_MAX      (2) 
#define NAS_0020_RSP_RSSI_MAX         (7)
#define NAS_0020_RSP_ECIO_MAX         (6)
#define NAS_0020_RSP_ERROR_RATE_MAX   (6)

#define NAS_0020_RSP_RSSI_MASK        (0x01)
#define NAS_0020_RSP_ECIO_MASK        (0x02)
#define NAS_0020_RSP_IO_MASK          (0x04)
#define NAS_0020_RSP_SINR_MASK        (0x08)
#define NAS_0020_RSP_ERR_RATE_MASK    (0x10)
#define NAS_0020_RSP_RSRQ_MASK        (0x20)
#define NAS_0020_RSP_LTE_SNR_MASK     (0x40)
#define NAS_0020_RSP_RSRP_MASK        (0x80)

#define NAS_0020_RSP_RSRP             (0x18)
#define NAS_0020_RSP_LTE_SNR          (0x17)
#define NAS_0020_RSP_RSRQ             (0x16)
#define NAS_0020_RSP_ERROR_RATE       (0x15)
#define NAS_0020_RSP_SINR_LIST        (0x14)
#define NAS_0020_RSP_IO_LIST          (0x13)
#define NAS_0020_RSP_ECIO_LIST        (0x12)
#define NAS_0020_RSP_RSSI_LIST        (0x11)
#define NAS_0020_RSP_SIG_STR_LIST     (0x10)
#define NAS_0020_RSP_SIG_STR_REQD     (0x01)

#define NAS_0020_REQ_MASK             (0x10)

#define NAS_0020_RSP_T01                      0x01
#define NAS_0020_RSP_T10                      0x10
#define NAS_0020_RSP_T10_SIG_STR_MAX		2
#define NAS_0020_RSP_T11                      0x11
#define NAS_0020_RSP_T11_RSSI_MAX			7
#define NAS_0020_RSP_T12                      0x12
#define NAS_0020_RSP_T12_ECIO_MAX			6
#define NAS_0020_RSP_T13                      0x13
#define NAS_0020_RSP_T14                      0x14
#define NAS_0020_RSP_T15                      0x15
#define NAS_0020_RSP_T15_ERROR_RATE_MAX		6
#define NAS_0020_RSP_T16                      0x16
#define NAS_0020_RSP_T17                      0x17
#define NAS_0020_RSP_T18                      0x18

typedef struct
{
  struct nas_0020_rsp_t01_s
  {
    int8 sig_strength;
    uint8 radio_if;
  } t01;
  
  struct nas_0020_rsp_t10_s
  {
    uint16 num_instances;
    struct
    {
      int8 sig_strength;
      uint8 radio_if;
    } instances[NAS_0020_RSP_T10_SIG_STR_MAX];
  } t10;
  
  struct nas_0020_rsp_t11_s
  {
    uint16 num_instances;
    struct
    {
      uint8 rssi;
      uint8 radio_if;
    } instances[NAS_0020_RSP_T11_RSSI_MAX];
  } t11;
  
  struct nas_0020_rsp_t12_s
  {
    uint16 num_instances;
    struct
    {
      uint8 ecio;
      uint8 radio_if;
    } instances[NAS_0020_RSP_T12_ECIO_MAX];
  } t12;
  
  struct nas_0020_rsp_t13_s
  {
    int32 io;
  } t13;
  
  struct nas_0020_rsp_t14_s
  {
    uint8 sinr;
  } t14;
  
  struct nas_0020_rsp_t15_s
  {
    uint16 num_instances;
    struct
    {
      uint16 error_rate;
      uint8 radio_if;
    } instances[NAS_0020_RSP_T15_ERROR_RATE_MAX];
  } t15;
  
  struct nas_0020_rsp_t16_s
  {
    int8 rsrq;
    uint8 radio_if;
  } t16;
  
  struct nas_0020_rsp_t17_s {
    int16 lte_snr;
  } t17;
  
  struct nas_0020_rsp_t18_s {
    int16 lte_rsrp;
  } t18;
  
  boolean t01_valid;
  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
  boolean t14_valid;
  boolean t15_valid;
  boolean t16_valid;
  boolean t17_valid;
  boolean t18_valid;
}nas_0020_rsp_s;

/*---------------------------------------------------------------------------
  QMI_NAS_GET_SERVING_SYSTEM
---------------------------------------------------------------------------*/

#define NAS_0024_RSP_T01                      0x01
#define NAS_0024_RSP_T01_RADIO_IF_MAX            7
#define NAS_0024_RSP_T10                      0x10
#define NAS_0024_RSP_T11                      0x11
#define NAS_0024_RSP_T11_DATA_CAP_LIST_LEN_MAX  10
#define NAS_0024_RSP_T12                      0x12
#define NAS_0024_RSP_T12_NET_DESC_LEN_MAX      256
#define NAS_0024_RSP_T13                      0x13
#define NAS_0024_RSP_T14                      0x14
#define NAS_0024_RSP_T15                      0x15
#define NAS_0024_RSP_T15_ROAM_RSP_MAX            6
#define NAS_0024_RSP_T16                      0x16
#define NAS_0024_RSP_T17                      0x17
#define NAS_0024_RSP_T18                      0x18
#define NAS_0024_RSP_T1A                      0x1A
#define NAS_0024_RSP_T1B                      0x1B
#define NAS_0024_RSP_T1C                      0x1C
#define NAS_0024_RSP_T1D                      0x1D
#define NAS_0024_RSP_T1E                      0x1E
#define NAS_0024_RSP_T1F                      0x1F
#define NAS_0024_RSP_T20                      0x20
#define NAS_0024_RSP_T21                      0x21
#define NAS_0024_RSP_T22                      0x22
#define NAS_0024_RSP_T23                      0x23
#define NAS_0024_RSP_T24                      0x24
#define NAS_0024_RSP_T25                      0x25
#define NAS_0024_RSP_T26                      0x26
#define NAS_0024_RSP_T27                      0x27
#define NAS_0024_RSP_T28                      0x28

struct nas_0024_req_s {
  int placeholder;
};

typedef struct {
  struct nas_0024_rsp_t01_s {
    uint8 registration_state;
    uint8 cs_attach_state;
    uint8 ps_attach_state;
    uint8 registered_network;
    uint8 in_use_radio_if_list_num;
    uint8 radio_if[NAS_0024_RSP_T01_RADIO_IF_MAX];
  } t01;
  
  struct nas_0024_rsp_t10_s {
    uint8 roaming_indicator;
  } t10;
  
  struct nas_0024_rsp_t11_s {
    uint8 data_capability_list_len;
    uint8 data_capabilities[NAS_0024_RSP_T11_DATA_CAP_LIST_LEN_MAX];
  } t11;
  
  struct nas_0024_rsp_t12_s {
    uint16 mobile_country_code;
    uint16 mobile_network_code;
    uint8  network_description_length;
    uint8  network_description[NAS_0024_RSP_T12_NET_DESC_LEN_MAX];
  } t12;
  
  struct nas_0024_rsp_t13_s {
    uint16 sid;
    uint16 nid;
  } t13;
  
  struct nas_0024_rsp_t14_s {
    uint16 base_id;
    int32  base_lat;
    int32  base_long;
  } t14;
  
  struct nas_0024_rsp_t15_s {
    uint8 num_instances;
    struct nas_0024_rsp_t15_roam_ind_s {
      uint8 radio_if;
      uint8 roaming_indicator;
    } roam_ind[NAS_0024_RSP_T15_ROAM_RSP_MAX];
  } t15;
  
  struct nas_0024_rsp_t16_s {
    uint8 def_roam_ind;
  } t16;
  
  struct nas_0024_rsp_t17_s {
    uint8 lp_sec;
    int8  ltm_offset;
    uint8 daylt_savings;
  } t17;
  
  struct nas_0024_rsp_t18_s {
    uint8 p_rev_in_use;
  } t18;
  
  struct nas_0024_rsp_t1A_s {
    int8 time_zone;
  } t1A;
  
  struct nas_0024_rsp_t1B_s {
    uint8 adj;
  } t1B;
  
  struct nas_0024_rsp_t1C_s {
    uint16 lac;
  } t1C;
  
  struct nas_0024_rsp_t1D_s {
    uint32 cell_id;
  } t1D;
  
  struct nas_0024_rsp_t1E_s {
    uint8 ccs;  
  } t1E;
  
  struct nas_0024_rsp_t1F_s {
    uint8 prl_ind;
  } t1F;
  
  struct nas_0024_rsp_t20_s {
    uint8 dtm_ind;
  } t20;
  
  struct nas_0024_rsp_t21_s {
    uint8 srv_status;
    uint8 srv_capability;
    uint8 hdr_srv_status;
    uint8 hdr_hybrid;
    uint8 is_sys_forbidden;
  } t21;
  
  struct nas_0024_rsp_t22_s {
    uint16 mcc;
    uint8 imsi_11_12;
  } t22;
  
  struct nas_0024_rsp_t23_s {
    uint8 hdr_personality; // qmi_nas_hdr_personality_e
  } t23;
  
  struct nas_0024_rsp_t24_s {
    uint16 tac;
  } t24;
  
  struct nas_0024_rsp_t25_s {
    uint32 cs_bar_status; // enum nas_cell_access_e
    uint32 ps_bar_status; // enum nas_cell_access_e
  } t25;
  
  struct nas_0024_rsp_t26_s {
    uint16 umts_psc;
  } t26;
  
  struct nas_0024_rsp_t27_s {
    uint16 mcc;
    uint16 mnc;
    uint8  mnc_includes_pcs_digit;
  } t27;
  
  struct nas_0024_rsp_t28_s {
    uint8 hs_call_status;
  } t28;

  boolean t01_valid;
  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
  boolean t14_valid;
  boolean t15_valid;
  boolean t16_valid;
  boolean t17_valid;
  boolean t18_valid;
  boolean t1A_valid;
  boolean t1B_valid;
  boolean t1C_valid;
  boolean t1D_valid;
  boolean t1E_valid;
  boolean t1F_valid;
  boolean t20_valid;
  boolean t21_valid;
  boolean t22_valid;
  boolean t23_valid;
  boolean t24_valid;
  boolean t25_valid;
  boolean t26_valid;
  boolean t27_valid;
  boolean t28_valid;
} nas_0024_rsp_s;

/*---------------------------------------------------------------------------
  QMI_NAS_GET_SERVING_SYSTEM_IND
---------------------------------------------------------------------------*/

#define NAS_0024_IND_T01                      0x01
#define NAS_0024_IND_T01_RADIO_IF_MAX            7
#define NAS_0024_IND_T10                      0x10
#define NAS_0024_IND_T11                      0x11
#define NAS_0024_IND_T11_DATA_CAP_LIST_LEN_MAX  10
#define NAS_0024_IND_T12                      0x12
#define NAS_0024_IND_T12_NET_DESC_LEN_MAX      256
#define NAS_0024_IND_T13                      0x13
#define NAS_0024_IND_T14                      0x14
#define NAS_0024_IND_T15                      0x15
#define NAS_0024_IND_T15_ROAM_IND_MAX            6
#define NAS_0024_IND_T16                      0x16
#define NAS_0024_IND_T17                      0x17
#define NAS_0024_IND_T18                      0x18
#define NAS_0024_IND_T19                      0x19
#define NAS_0024_IND_T1A                      0x1A
#define NAS_0024_IND_T1B                      0x1B
#define NAS_0024_IND_T1C                      0x1C
#define NAS_0024_IND_T1D                      0x1D
#define NAS_0024_IND_T1E                      0x1E
#define NAS_0024_IND_T1F                      0x1F
#define NAS_0024_IND_T20                      0x20
#define NAS_0024_IND_T21                      0x21
#define NAS_0024_IND_T22                      0x22
#define NAS_0024_IND_T23                      0x23
#define NAS_0024_IND_T24                      0x24
#define NAS_0024_IND_T25                      0x25
#define NAS_0024_IND_T26                      0x26
#define NAS_0024_IND_T27                      0x27
#define NAS_0024_IND_T28                      0x28
#define NAS_0024_IND_T29                      0x29
#define NAS_0024_IND_T2A                      0x2A

typedef struct {
  struct nas_0024_ind_t01_s {
    uint8 registration_state;
    uint8 cs_attach_state;
    uint8 ps_attach_state;
    uint8 selected_network;
    uint8 in_use_radio_if_list_num;
    uint8 radio_if[NAS_0024_IND_T01_RADIO_IF_MAX];
  } t01;
  
  struct nas_0024_ind_t10_s {
    uint8 roaming_indicator;
  } t10;
  
  struct nas_0024_ind_t11_s {
    uint8 data_capability_list_len;
    uint8 data_capabilities[NAS_0024_IND_T11_DATA_CAP_LIST_LEN_MAX];
  } t11;
  
  struct nas_0024_ind_t12_s {
    uint16 mobile_country_code;
    uint16 mobile_network_code;
    uint8  network_description_length;
    uint8  network_description[NAS_0024_IND_T12_NET_DESC_LEN_MAX];
  } t12;
  
  struct nas_0024_ind_t13_s {
    uint16 sid;
    uint16 nid;
  } t13;
  
  struct nas_0024_ind_t14_s {
    uint16 base_id;
    int32  base_lat;
    int32  base_long;
  } t14;
  
  struct nas_0024_ind_t15_s {
    uint8 num_instances;
    struct nas_0024_ind_t15_roam_ind_s {
      uint8 radio_if;
      uint8 roaming_indicator;
    } roam_ind[NAS_0024_IND_T15_ROAM_IND_MAX];
  } t15;
  
  struct nas_0024_ind_t16_s {
    uint8 def_roam_ind;
  } t16;
  
  struct nas_0024_ind_t17_s {
    uint8 lp_sec;
    int8  ltm_offset;
    uint8 daylt_savings;
  } t17;
  
  struct nas_0024_ind_t18_s {
    uint8 p_rev_in_use;
  } t18;
  
  struct nas_0024_ind_t19_s {
    uint8 is_plmn_changed;
  } t19;
  
  struct nas_0024_ind_t1A_s {
    int8 time_zone;
  } t1A;
  
  struct nas_0024_ind_t1B_s {
    uint8 adj;
  } t1B;
  
  struct nas_0024_ind_t1C_s {
    uint16 year;
    uint8  month;
    uint8  day;
    uint8  hour;
    uint8  minute;
    uint8  second;
    int8   time_zone;
  } t1C;
  
  struct nas_0024_ind_t1D_s {
    uint16 lac;
  } t1D;
  
  struct nas_0024_ind_t1E_s {
    uint32 cell_id;
  } t1E;
  
  struct nas_0024_ind_t1F_s {
    uint8 ccs;  
  } t1F;
  
  struct nas_0024_ind_t20_s {
    uint8 prl_ind;
  } t20;
  
  struct nas_0024_ind_t21_s {
    uint8 dtm_ind;
  } t21;
  
  struct nas_0024_ind_t22_s {
    uint8 srv_status;
    uint8 srv_capability;
    uint8 hdr_srv_status;
    uint8 hdr_hybrid;
    uint8 is_sys_forbidden;
  } t22;
  
  struct nas_0024_ind_t23_s {
    uint16 mcc;
    uint8 imsi_11_12;
  } t23;
  
  struct nas_0024_ind_t24_s {
    uint8 hdr_personality; // enum qmi_nas_hdr_personality_e
  } t24;
  
  struct nas_0024_ind_t25_s {
    uint16 tac;
  } t25;
  
  struct nas_0024_ind_t26_s {
    uint32 cs_bar_status; // enum nas_cell_access_e
    uint32 ps_bar_status; // enum nas_cell_access_e
  } t26;
  
  struct nas_0024_ind_t27_s {
    uint8 srv_sys_no_change; 
  } t27;
  
  struct nas_0024_ind_t28_s {
    uint16 umts_psc;
  } t28;
  
  struct nas_0024_ind_t29_s {
    uint16 mcc;
    uint16 mnc;
    uint8  mnc_includes_pcs_digit;
  } t29;
  
  struct nas_0024_ind_t2A_s {
    uint8 hs_call_status;
  } t2A;

  boolean t01_valid;
  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
  boolean t14_valid;
  boolean t15_valid;
  boolean t16_valid;
  boolean t17_valid;
  boolean t18_valid;
  boolean t19_valid;
  boolean t1A_valid;
  boolean t1B_valid;
  boolean t1C_valid;
  boolean t1D_valid;
  boolean t1E_valid;
  boolean t1F_valid;
  boolean t20_valid;
  boolean t21_valid;
  boolean t22_valid;
  boolean t23_valid;
  boolean t24_valid;
  boolean t25_valid;
  boolean t26_valid;
  boolean t27_valid;
  boolean t28_valid;
  boolean t29_valid;
  boolean t2A_valid;
} nas_0024_ind_s;

/*---------------------------------------------------------------------------
  QMI_NAS_GET_HOME_NETWORK
---------------------------------------------------------------------------*/
#define NAS_CDMA_SPN_DO_NOT_DISPLAY (0x00)
#define NAS_CDMA_SPN_DISPLAY        (0x01)
#define NAS_CDMA_SPN_UNKNOWN        (0xFF)

#define NAS_CDMA_SPN_ENC_UNKNOWN    (0x00)

#define NAS_0025_RSP_T01      (0x01)
#define NAS_0025_RSP_T01_MAX_NETWORK_NAME_LEN (255)
#define NAS_0025_RSP_T10      (0x10)
#define NAS_0025_RSP_T11      (0x11)
#define NAS_0025_RSP_T11_CDMA_SPN_MAX_NETWORK_NAME_LEN (32) // per 3GPP2 C.S0065-0 v1.0 cl. 5.2.32
#define NAS_0025_RSP_T12      (0x12)

typedef struct {
  struct nas_0025_rsp_t01_s {
    uint16 mobile_country_code;
    uint16 mobile_network_code;
    uint8  network_description_length;
    uint8  network_description[NAS_0025_RSP_T01_MAX_NETWORK_NAME_LEN];
  } t01;
  
  struct nas_0025_rsp_t10_s {
    uint16 sid;
    uint16 nid;
  } t10;
  
  struct nas_0025_rsp_t11_s {
    uint16 mobile_country_code;
    uint16 mobile_network_code;
    uint8  network_description_display;
    uint8  network_description_encoding;
    uint8  network_description_length;
    uint8  network_description[NAS_0025_RSP_T11_CDMA_SPN_MAX_NETWORK_NAME_LEN];
  } t11;
  
  struct nas_0025_rsp_t12_s {
    uint8 is_3gpp_network;
    uint8 mnc_includes_pcs_digit;
  } t12;
  
  struct nas_0025_rsp_t13_s {
    uint8 static_3gpp_mnc_includes_pcs_digit_len;
    uint16 mcc;
    uint16 mnc;
    uint8 mnc_includes_pcs_digit;
  } t13;

  boolean t01_valid;
  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
} nas_0025_rsp_s;

/*---------------------------------------------------------------------------
  QMI_NAS_SET_SYSTEM_SELECTION_PREFERENCE
---------------------------------------------------------------------------*/
#define NAS_0033_REQ_T10      (0x10)
#define NAS_0033_REQ_T11      (0x11)
#define NAS_0033_REQ_T12      (0x12)
#define NAS_0033_REQ_T13      (0x13)
#define NAS_0033_REQ_T14      (0x14)
#define NAS_0033_REQ_T15      (0x15)
#define NAS_0033_REQ_T16      (0x16)
#define NAS_0033_REQ_T17      (0x17)
#define NAS_0033_REQ_T18      (0x18)
#define NAS_0033_REQ_T19      (0x19)
#define NAS_0033_REQ_T1A      (0x1A)
#define NAS_0033_REQ_T1B      (0x1B)
#define NAS_0033_REQ_T1C      (0x1C)
#define NAS_0033_REQ_T1D      (0x1D)
#define NAS_0033_REQ_T1E      (0x1E)
#define NAS_0033_REQ_T1F      (0x1F)
#define NAS_0033_REQ_T20      (0x20)

#define NAS_0033_MODE_PREF_BIT_CDMA   0x0001
#define NAS_0033_MODE_PREF_BIT_HDR    0x0002
#define NAS_0033_MODE_PREF_BIT_GSM    0x0004
#define NAS_0033_MODE_PREF_BIT_UMTS   0x0008
#define NAS_0033_MODE_PREF_BIT_LTE    0x0010
#define NAS_0033_MODE_PREF_BIT_TDS    0x0020
#define NAS_0033_MODE_PREF_BIT_ALL    0x003F

#define NAS_0033_ACQ_ORDER_LIST_MAX   10

typedef enum
{
  NAS_0033_EMERGENCY_MODE_OFF     = 0x00,
  NAS_0033_EMERGENCY_MODE_ON      = 0x01
} nas_0033_emergency_mode_e_type;

typedef enum
{
  NAS_0033_NET_SEL_PREF_AUTOMATIC = 0x00,
  NAS_0033_NET_SEL_PREF_MANUAL    = 0x01
} nas_0033_net_sel_pref_e_type;

typedef enum
{
  NAS_0033_CHANGE_DURATION_POWER_CYCLE = 0x00,
  NAS_0033_CHANGE_DURATION_PERMANENT   = 0x01
} nas_0033_change_duration_e_type;

typedef enum
{
  NAS_0033_DOMAIN_PREF_CS_ONLY     = 0x00,
  NAS_0033_DOMAIN_PREF_PS_ONLY     = 0x01,
  NAS_0033_DOMAIN_PREF_CS_PS       = 0x02,
  NAS_0033_DOMAIN_PREF_PS_ATTACH   = 0x03,
  NAS_0033_DOMAIN_PREF_PS_DETACH   = 0x04,
  NAS_0033_DOMAIN_PREF_PS_DETACH_NO_PREF_CHANGE = 0x05
} nas_0033_srv_domain_e_type;

typedef enum
{
  NAS_0033_GW_ACQ_ORDER_PREF_AUTOMATIC = 0x00,
  NAS_0033_GW_ACQ_ORDER_PREF_GSM_WCDMA = 0x01,
  NAS_0033_GW_ACQ_ORDER_PREF_WCDMA_GSM = 0x02
} nas_0033_gw_acq_order_pref_e_type;

typedef enum
{
  NAS_0033_SRV_REG_RESTRICTION_UNRESTRICTED = 0x00,
  NAS_0033_SRV_REG_RESTRICTION_CAMPED_ONLY  = 0x01,
  NAS_0033_SRV_REG_RESTRICTION_LIMITED      = 0x02
} nas_0033_srv_reg_restriction_e_type;

typedef struct {
  struct nas_0033_req_t10_s {
    uint8 emergency_mode;
  } t10;
  
  struct nas_0033_req_t11_s {
    uint16 mode_pref;
  } t11;
  
  struct nas_0033_req_t12_s {
    uint64 band_pref;
  } t12;
  
  struct nas_0033_req_t13_s {
    uint16 prl_pref;
  } t13;
  
  struct nas_0033_req_t14_s {
    uint16 roam_pref;
  } t14;
  
  struct nas_0033_req_t15_s {
    uint64 lte_band_pref;
  } t15;
  
  struct nas_0033_req_t16_s {
    uint8  net_sel_pref;
    uint16 mcc;
    uint16 mnc;
  } t16;
  
  struct nas_0033_req_t17_s {
    uint8  change_duration;
  } t17;
  
  struct nas_0033_req_t18_s {
    uint32 srv_domain_pref;  // nas_0033_srv_domain_e_type
  } t18;  
  
  struct nas_0033_req_t19_s {
    uint32 gw_acq_order_pref;
  } t19;
  
  struct nas_0033_req_t1A_s {
    uint8 mnc_includes_pcs_digit;
  } t1A;

  // 0x1B is a duplicate TLV. Maps to 0x18
  // 0x1C is a duplicate TLV. Maps to 0x19
  struct nas_0033_req_t1D_s
  {
    uint64 tds_band_pref;
  } t1D;

  struct nas_0033_req_t1E_s {
    uint8 acq_order_len;
    uint8 acq_order[NAS_0033_ACQ_ORDER_LIST_MAX];
  } t1E;

  struct nas_0033_req_t1F_s {
    uint32 srv_reg_restriction;
  } t1F;

  struct nas_0033_req_t20_s {
    uint16 mcc;
    uint16 mnc;
    uint8  mnc_includes_pcs_digit;
    uint32 csg_id;
    uint8  csg_radio_if;
  } t20;

  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
  boolean t14_valid;
  boolean t15_valid;
  boolean t16_valid;
  boolean t17_valid;
  boolean t18_valid;
  boolean t19_valid;
  boolean t1A_valid;
  boolean t1B_valid; // duplicate TLV; dup of 0x18
  boolean t1C_valid; // duplicate TLV; Dup of 0x19
  boolean t1D_valid;
  boolean t1E_valid;
  boolean t1F_valid;
  boolean t20_valid;
} nas_0033_req_s;

/*---------------------------------------------------------------------------
  QMI_NAS_GET_SYSTEM_SELECTION_PREFERENCE
---------------------------------------------------------------------------*/
#define NAS_0034_RSP_T10      (0x10)
#define NAS_0034_RSP_T11      (0x11)
#define NAS_0034_RSP_T12      (0x12)
#define NAS_0034_RSP_T13      (0x13)
#define NAS_0034_RSP_T14      (0x14)
#define NAS_0034_RSP_T15      (0x15)
#define NAS_0034_RSP_T16      (0x16)
#define NAS_0034_RSP_T18      (0x18)
#define NAS_0034_RSP_T19      (0x19)
#define NAS_0034_RSP_T1A      (0x1A)
#define NAS_0034_RSP_T1B      (0x1B)
#define NAS_0034_RSP_T1C      (0x1C)
#define NAS_0034_RSP_T1D      (0x1D)
#define NAS_0034_RSP_T1E      (0x1E)

#define NAS_0034_ACQ_ORDER_LIST_MAX   10

typedef struct {
  struct nas_0034_rsp_t10_s {
    uint8 emergency_mode;
  } t10;
  
  struct nas_0034_rsp_t11_s {
    uint16 mode_pref;
  } t11;
  
  struct nas_0034_rsp_t12_s {
    uint64 band_pref;
  } t12;
  
  struct nas_0034_rsp_t13_s {
    uint16 prl_pref;
  } t13;
  
  struct nas_0034_rsp_t14_s {
    uint16 roam_pref;
  } t14;
  
  struct nas_0034_rsp_t15_s {
    uint64 lte_band_pref;
  } t15;
  
  struct nas_0034_rsp_t16_s {
    uint8 net_sel_mode_pref;
  } t16;

  // t17 reserved to preserve uniformity across get/set/ind messages

  struct nas_0034_rsp_t18_s {
    uint32 srv_domain_pref;  
  } t18;
  
  struct nas_0034_rsp_t19_s {
    uint32 gw_acq_order_pref;
  } t19;
  
  struct nas_0034_rsp_t1A_s
  {
    uint64 tds_band_pref;
  } t1A;
  
  struct nas_0034_rsp_t1B_s {
    uint16 mcc;
    uint16 mnc;
    uint8  mnc_includes_pcs_digit;
  } t1B;
  
  struct nas_0034_req_t1C_s {
    uint8 acq_order_len;
    uint8 acq_order[NAS_0034_ACQ_ORDER_LIST_MAX];
  } t1C;
  
  struct nas_0034_rsp_t1D_s {
    uint32 srv_reg_restriction;
  } t1D;
  
  struct nas_0034_req_t1E_s {
    uint16 mcc;
    uint16 mnc;
    uint8  mnc_includes_pcs_digit;
    uint32 csg_id;
    uint8  csg_radio_if;
  } t1E;

  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
  boolean t14_valid;
  boolean t15_valid;
  boolean t16_valid;
  boolean t18_valid;
  boolean t19_valid;
  boolean t1A_valid;
  boolean t1B_valid;
  boolean t1C_valid;
  boolean t1D_valid;
  boolean t1E_valid;
} nas_0034_rsp_s;

/*---------------------------------------------------------------------------
  QMI_NAS_SYSTEM_SELECTION_PREFERENCE_IND
---------------------------------------------------------------------------*/
#define NAS_0034_IND_T10      (0x10)
#define NAS_0034_IND_T11      (0x11)
#define NAS_0034_IND_T12      (0x12)
#define NAS_0034_IND_T13      (0x13)
#define NAS_0034_IND_T14      (0x14)
#define NAS_0034_IND_T15      (0x15)
#define NAS_0034_IND_T16      (0x16)
#define NAS_0034_IND_T18      (0x18)
#define NAS_0034_IND_T19      (0x19)
#define NAS_0034_IND_T1A      (0x1A)
#define NAS_0034_IND_T1B      (0x1B)
#define NAS_0034_IND_T1C      (0x1C)
#define NAS_0034_IND_T1D      (0x1D)
#define NAS_0034_IND_T1E      (0x1E)

/*---------------------------------------------------------------------------
  QMI_NAS_GET_3GPP2_SUBSCRIPTION_INFO
---------------------------------------------------------------------------*/

#define NAS_003E_REQ_NAM            (0x01)
#define NAS_003E_REQ_MASK           (0x10)
#define NAS_003E_REQ_CURR_NAM_MASK  (NASI_CURR_NAM_MASK)

#define NAS_003E_RSP_NAM_NAME       (0x10)
#define NAS_003E_RSP_DIR_NUM        (0x11)
#define NAS_003E_RSP_SID_NID        (0x12)
#define NAS_003E_RSP_MIN_IMSI       (0x13)
#define NAS_003E_RSP_TRUE_IMSI      (0x14)
#define NAS_003E_RSP_CDMA_CH        (0x15)
#define NAS_003E_RSP_MDN            (0x16)
#define NAS_003E_RSP_PRL_VERSION    (0x80)

#define NAS_003E_RSP_MCC_LEN        (3)
#define NAS_003E_RSP_11_12_LEN      (2)
#define NAS_003E_RSP_MIN1_LEN       (7)
#define NAS_003E_RSP_MIN2_LEN       (3)
#define NAS_003E_RSP_MDN_LEN        (15)

typedef enum {
  QMI_NAS_GET_3GPP2_SUBS_INFO_NAM_NAME       = 0x01,
  QMI_NAS_GET_3GPP2_SUBS_INFO_DIR_NUM        = 0x02,     
  QMI_NAS_GET_3GPP2_SUBS_INFO_HOME_SID_IND   = 0x04,
  QMI_NAS_GET_3GPP2_SUBS_INFO_MIN_BASED_IMSI = 0x08,
  QMI_NAS_GET_3GPP2_SUBS_INFO_TRUE_IMSI      = 0x10,
  QMI_NAS_GET_3GPP2_SUBS_INFO_CDMA_CHANNEL   = 0x20,
  QMI_NAS_GET_3GPP2_SUBS_INFO_MDN            = 0x40, 
  QMI_NAS_GET_3GPP2_SUBS_INFO_PRL_VERSION     = 0x80
} get_3gpp2_info_mask_e_type;

typedef struct
{
  struct nas_003E_req_t01_s
  {
    uint8 nam;
  } t01;

  struct nas_003E_req_t10_s
  {
    uint32 get_3gpp2_info_mask;
  } t10;
  
  boolean t01_valid;
  boolean t10_valid;
} nas_003E_req_s;

typedef struct
{
  struct nas_003E_rsp_t10_s
  {
    uint8 nam_name_len;
    char nam_name[12];   // 12: NV_MAX_LTRS
  } t10;
  struct nas_003E_rsp_t11_s
  {
    uint8 dir_num_len;
    char dir_num[10];  // 10: NV_DIR_NUMB_SIZ
  } t11;
  struct nas_003E_rsp_t12_s
  {
    uint8             num_instances;
    struct
    {
      uint16           sid;
      uint16           nid;
    } sid_nid_list[20];  // 20: NV_MAX_HOME_SID_NID
  } t12;
  struct nas_003E_rsp_t13_s
  {
    uint8           mcc_m[NAS_003E_RSP_MCC_LEN];
    uint8           imsi_m_11_12[NAS_003E_RSP_11_12_LEN];
    uint8           imsi_m_s1[NAS_003E_RSP_MIN1_LEN];
    uint8           imsi_m_s2[NAS_003E_RSP_MIN2_LEN];
  } t13;
  struct nas_003E_rsp_t14_s
  {
    uint8           mcc_t[NAS_003E_RSP_MCC_LEN];
    uint8           imsi_t_11_12[NAS_003E_RSP_11_12_LEN];
    uint8           imsi_t_s1[NAS_003E_RSP_MIN1_LEN];
    uint8           imsi_t_s2[NAS_003E_RSP_MIN2_LEN];
    uint8           imsi_t_addr_num;
  } t14;
  struct nas_003E_rsp_t15_s
  {
    uint16          pri_ch_a;
    uint16          pri_ch_b;
    uint16          sec_ch_a;
    uint16          sec_ch_b;
  } t15;
  struct nas_003E_rsp_t16_s
  {
    uint8           mdn_len;
    uint8           mdn[NAS_003E_RSP_MDN_LEN];    
  } t16;
  struct nas_003E_rsp_t80_s
  {
    uint16          prl_version;
  } t80;

  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
  boolean t14_valid;
  boolean t15_valid;
  boolean t16_valid;
  boolean t80_valid;
}nas_003E_rsp_s;

//20170215 yjoh add for cell info
#define NAS_0043_RSP_T10        (0x10)
#define NAS_0043_RSP_T11        (0x11)
#define NAS_0043_RSP_T13        (0x13)

//BKS_20131202
/*---------------------------------------------------------------------------
  (0x0044) QMI_NAS_GET_PLMN_NAME_REQ_MSG_ID
---------------------------------------------------------------------------*/
#define NAS_0044_REQ_T01      (0x01)

#define NAS_0044_RSP_T02      (0x02)
#define NAS_0044_RSP_T10      (0x10)

/*---------------------------------------------------------------------------
  (0x004C) QMI_NAS_NETWORK_TIME_IND
---------------------------------------------------------------------------*/
#define NAS_004C_IND_T01                     (0x01)
#define NAS_004C_IND_T10                     (0x10)
#define NAS_004C_IND_T11                     (0x11)
#define NAS_004C_IND_T12                     (0x12)

typedef struct {
  // Universal Time
  struct nas_004C_ind_t01_s {
    uint16 year;
    uint8 month;
    uint8 day;
    uint8 hour;
    uint8 minute;
    uint8 second;
    uint8 day_of_week;
  } t01;

  // Time Zone
  struct nas_004C_ind_t10_s {
    int8 time_zone;
  } t10;

  // Daylight Saving Adjustment
  struct nas_004C_ind_t11_s {
    uint8 daylt_sav_adj;
  } t11;

  // Radio Interface
  struct nas_004C_ind_t12_s {
    uint8 radio_if;
  } t12;

  boolean t01_valid;
  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
} nas_004C_ind_s;

/*---------------------------------------------------------------------------
  (0x004D) QMI_NAS_GET_SYSTEM_SELECTION_PREFERENCE
---------------------------------------------------------------------------*/
#define NAS_004D_RSP_T10                     (0x10)
#define NAS_004D_RSP_T11                     (0x11)
#define NAS_004D_RSP_T12                     (0x12)
#define NAS_004D_RSP_T13                     (0x13)
#define NAS_004D_RSP_T14                     (0x14)
#define NAS_004D_RSP_T15                     (0x15)
#define NAS_004D_RSP_T16                     (0x16)
#define NAS_004D_RSP_T17                     (0x17)
#define NAS_004D_RSP_T18                     (0x18)
#define NAS_004D_RSP_T19                     (0x19)
#define NAS_004D_RSP_T1A                     (0x1A)
#define NAS_004D_RSP_T1B                     (0x1B)
#define NAS_004D_RSP_T1C                     (0x1C)
#define NAS_004D_RSP_T1D                     (0x1D)
#define NAS_004D_RSP_T1E                     (0x1E)
#define NAS_004D_RSP_T1F                     (0x1F)
#define NAS_004D_RSP_T20                     (0x20)
#define NAS_004D_RSP_T21                     (0x21)
#define NAS_004D_RSP_T22                     (0x22)
#define NAS_004D_RSP_T23                     (0x23)
#define NAS_004D_RSP_T24                     (0x24)
#define NAS_004D_RSP_T25                     (0x25)
#define NAS_004D_RSP_T26                     (0x26)
#define NAS_004D_RSP_T27                     (0x27)
#define NAS_004D_RSP_T28                     (0x28)
#define NAS_004D_RSP_T29                     (0x29)
#define NAS_004D_RSP_T2F                     (0x2F)
#define NAS_004D_RSP_T30                     (0x30)
#define NAS_004D_RSP_T31                     (0x31)
#define NAS_004D_RSP_T32                     (0x32)
#define NAS_004D_RSP_T33                     (0x33)
#define NAS_004D_RSP_T34                     (0x34)
#define NAS_004D_RSP_T35                     (0x35)

typedef struct {
  // CDMA Service Status Info
  struct nas_004D_rsp_t10_s {
    uint8 srv_status;
    uint8 is_pref_data_path;    
  } t10;
  
  // HDR Service Status Info
  struct nas_004D_rsp_t11_s {
    uint8 srv_status;
    uint8 is_pref_data_path;   
  } t11;
  
  // GSM Service Status Info
  struct nas_004D_rsp_t12_s {
    uint8 srv_status;
    uint8 true_srv_status;
    uint8 is_pref_data_path; 
  } t12;
  
  // WCDMA Service Status Info
  struct nas_004D_rsp_t13_s {
    uint8 srv_status;
    uint8 true_srv_status;
    uint8 is_pref_data_path; 
  } t13;
  
  // LTE Service Status Info
  struct nas_004D_rsp_t14_s {
    uint8 srv_status;
    uint8 true_srv_status;
    uint8 is_pref_data_path; 
  } t14;
  
  // CDMA System Info
  struct nas_004D_rsp_t15_s {
    uint8 srv_domain_valid; 
    uint8 srv_domain;
    uint8 srv_capability_valid;
    uint8 srv_capability; 
    uint8 roam_status_valid;
    uint8 roam_status;
    uint8 is_sys_forbidden_valid;
    uint8 is_sys_forbidden;
    uint8 is_sys_prl_match_valid;
    uint8 is_sys_prl_match;
    uint8 p_rev_in_use_valid;
    uint8 p_rev_in_use;
    uint8 bs_p_rev_valid;
    uint8 bs_p_rev;
    uint8 ccs_supported_valid;
    uint8 ccs_supported;
    uint8 cdma_sys_id_valid;
    uint16 sid;
    uint16 nid;
    uint8 bs_info_valid;
    uint16 base_id;
    int32 base_lat;
    int32 base_long;
    uint8 packet_zone_valid;
    uint16 packet_zone;
    uint8 network_id_valid;
    uint8  mcc[3];
    uint8  mnc[3];
  } t15;
  
  // HDR System Info
  struct nas_004D_rsp_t16_s {
    uint8 srv_domain_valid; 
    uint8 srv_domain;
    uint8 srv_capability_valid;
    uint8 srv_capability; 
    uint8 roam_status_valid;
    uint8 roam_status;
    uint8 is_sys_forbidden_valid;
    uint8 is_sys_forbidden;
    uint8 is_sys_prl_match_valid;
    uint8 is_sys_prl_match;
    uint8 hdr_personality_valid;
    uint8 hdr_personality;
    uint8 hdr_active_prot_valid;
    uint8 hdr_active_prot;
    uint8 is856_sys_id_valid;
    uint8 is856_sys_id;
  } t16;
  
  // GSM System Info
  struct nas_004D_rsp_t17_s {
    uint8 srv_domain_valid; 
    uint8 srv_domain;
    uint8 srv_capability_valid;
    uint8 srv_capability; 
    uint8 roam_status_valid;
    uint8 roam_status;
    uint8 is_sys_forbidden_valid;
    uint8 is_sys_forbidden;
    uint8 lac_valid;
    uint16 lac;
    uint8 cell_id_valid;
    uint32 cell_id;
    uint8 reg_reject_info_valid;
    uint8 reject_srv_domain;
    uint8 rej_cause;
    uint8 network_id_valid;
    uint8  mcc[3];
    uint8  mnc[3];
    uint8 egprs_supp_valid;
    uint8 egprs_supp;
    uint8 dtm_supp_valid;
    uint8 dtm_supp;
  } t17;
  
  // WCDMA System Info
  struct nas_004D_rsp_t18_s {
    uint8 srv_domain_valid; 
    uint8 srv_domain;
    uint8 srv_capability_valid;
    uint8 srv_capability; 
    uint8 roam_status_valid;
    uint8 roam_status;
    uint8 is_sys_forbidden_valid;
    uint8 is_sys_forbidden;
    uint8 lac_valid;
    uint16 lac;
    uint8 cell_id_valid;
    uint32 cell_id;
    uint8 reg_reject_info_valid;
    uint8 reject_srv_domain;
    uint8 rej_cause;
    uint8 network_id_valid;
    uint8  mcc[3];
    uint8  mnc[3];
    uint8 hs_call_status_valid;
    uint8 hs_call_status;
    uint8 hs_ind_valid;
    uint8 hs_ind;
    uint8 psc_valid;
    uint16 psc;
  } t18;
  
  // LTE System Info
  struct nas_004D_rsp_t19_s {
    uint8 srv_domain_valid; 
    uint8 srv_domain;
    uint8 srv_capability_valid;
    uint8 srv_capability; 
    uint8 roam_status_valid;
    uint8 roam_status;
    uint8 is_sys_forbidden_valid;
    uint8 is_sys_forbidden;
    uint8 lac_valid;
    uint16 lac;
    uint8 cell_id_valid;
    uint32 cell_id;
    uint8 reg_reject_info_valid;
    uint8 reject_srv_domain;
    uint8 rej_cause;
    uint8 network_id_valid;
    uint8  mcc[3];
    uint8  mnc[3];
    uint8 tac_valid;
    uint16 tac;
  } t19;
  
  // Additional CDMA System Info
  struct nas_004D_rsp_t1A_s {
    uint16 geo_sys_idx;
    uint16 reg_prd;
  } t1A;
  
  // Additional HDR System Info
  struct nas_004D_rsp_t1B_s {
    uint16 geo_sys_idx;
  } t1B;
  
  // Additional GSM System Info
  struct nas_004D_rsp_t1C_s {
    uint16 geo_sys_idx;
    uint32 cell_broadcast_cap;
  } t1C;
  
  // Additional WCDMA System Info
  struct nas_004D_rsp_t1D_s {
    uint16 geo_sys_idx;
    uint32 cell_broadcast_cap;
  } t1D;
  
  // Additional LTE System Info
  struct nas_004D_rsp_t1E_s {
    uint16 geo_sys_idx;
  } t1E;
  
  // GSM Call Barring System Info
  struct nas_004D_rsp_t1F_s {
    uint32 cs_bar_status;
    uint32 ps_bar_status;
  } t1F;
  
  // WCDMA Call Barring System Info
  struct nas_004D_rsp_t20_s {
    uint32 cs_bar_status;
    uint32 ps_bar_status;
  } t20;
  
  // LTE Voice Support Sys Info
  struct nas_004D_rsp_t21_s {
    uint8 voice_support_on_lte;
  } t21;
  
  // GSM Cipher Domain Sys Info
  struct nas_004D_rsp_t22_s {
    uint8 gsm_cipher_domain;    
  } t22;
  
  // WCDMA Cipher Domain Sys Info
  struct nas_004D_rsp_t23_s {
    uint8 wcdma_cipher_domain;
  } t23;
  
  // TDSCDMA Service Status Info
  struct nas_004D_rsp_t24_s {
    uint8 srv_status;
    uint8 true_srv_status;
    uint8 is_pref_data_path;
  } t24;
  
  // TDSCDMA System Info
  struct nas_004D_rsp_t25_s {
    uint8 srv_domain_valid; 
    uint8 srv_domain;
    uint8 srv_capability_valid;
    uint8 srv_capability; 
    uint8 roam_status_valid;
    uint8 roam_status;
    uint8 is_sys_forbidden_valid;
    uint8 is_sys_forbidden;
    uint8 lac_valid;
    uint16 lac;
    uint8 cell_id_valid;
    uint32 cell_id;
    uint8 reg_reject_info_valid;
    uint8 reject_srv_domain;
    uint8 rej_cause;
    uint8 network_id_valid;
    uint8  mcc[3];
    uint8  mnc[3];
    uint8 hs_call_status_valid;
    uint8 hs_call_status;
    uint8 hs_ind_valid;
    uint8 hs_ind;
    uint8 cell_parameter_id_valid;
    uint16 cell_parameter_id;
    uint8 cell_broadcast_cap_valid;
    uint8 cell_broadcast_cap;
    uint8 cs_bar_status_valid;
    uint8 cs_bar_status;
    uint8 ps_bar_status_valid;
    uint8 ps_bar_status;
    uint8 cipher_domain_valid;
    uint8 cipher_domain;
  } t25;
  
  // LTE eMBMS Coverage Info
  struct nas_004D_rsp_t26_s {
    uint8 lte_embms_coverage;
  } t26;
  
  // SIM Reject Information
  struct nas_004D_rsp_t27_s {
    uint32 sim_rej_info;    
  } t27;
  
  // WCDMA EUTRA Status Information
  struct nas_004D_rsp_t28_s {
    uint8 wcdma_eutra_status;
  } t28;
  
  // IMS Voice Support Status on LTE
  struct nas_004D_rsp_t29_s {
    uint8 lte_ims_voice_avail;
  } t29;
  
  // LTE Voice Domain
  struct nas_004D_rsp_t2A_s {
    uint32 lte_voice_status;
  } t2A;
  
  // CDMA Reg Zone ID
  struct nas_004D_rsp_t2B_s {
    uint16 cdma_reg_zone;
  } t2B;
  
  // GSM RAC
  struct nas_004D_rsp_t2C_s {
    uint8 gsm_rac;
  } t2C;
  
  // WCDMA RAC
  struct nas_004D_rsp_t2D_s {
    uint8 wcdma_rac;
  } t2D;
  
  // CDMA Resolved Mobile Country Code
  struct nas_004D_rsp_t2E_s {
    uint16 cdma_mcc_resolved_via_sid_lookup;
  } t2E;
  
  // Network Selection Registration Restriction
  struct nas_004D_rsp_t2F_s {
    uint32 srv_reg_restriction;
  } t2F;
  
  // TDSCDMA Registration Domain
  struct nas_004D_rsp_t30_s {
    uint32 tdscdma_reg_domain;
  } t30;
  
  // LTE Registration Domain
  struct nas_004D_rsp_t31_s {
    uint32 lte_reg_domain;
  } t31;
  
  // WCDMA Registration Domain
  struct nas_004D_rsp_t32_s {
    uint32 wcdma_reg_domain;
  } t32;
  
  // GSM Registration Domain
  struct nas_004D_rsp_t33_s {
    uint32 gsm_reg_domain;
  } t33;
  
  // LTE eMBMS Coverage Info Trace ID
  struct nas_004D_rsp_t34_s {
    int16 lte_embms_coverage_trace_id;
  } t34;
  
  // WCDMA CSG Information
  struct nas_004D_rsp_t35_s {
    uint32 id;
    uint8 name_len;
    uint16 name[NAS_CSG_NAME_MAX_LEN];
  } t35;

  struct nas_004D_rsp_t39_s
  {
    uint32 lte_is_eb_supported;
  } t39;

  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
  boolean t14_valid;
  boolean t15_valid;
  boolean t16_valid;
  boolean t17_valid;
  boolean t18_valid;
  boolean t19_valid;
  boolean t1A_valid;
  boolean t1B_valid;
  boolean t1C_valid;
  boolean t1D_valid;
  boolean t1E_valid;
  boolean t1F_valid;
  boolean t20_valid;
  boolean t21_valid;
  boolean t22_valid;
  boolean t23_valid;
  boolean t24_valid;
  boolean t25_valid;
  boolean t26_valid;
  boolean t27_valid;  
  boolean t28_valid;
  boolean t29_valid;
  boolean t2A_valid;
  boolean t2B_valid;
  boolean t2C_valid;
  boolean t2D_valid;
  boolean t2E_valid;
  boolean t2F_valid;
  boolean t30_valid;
  boolean t31_valid;
  boolean t32_valid;
  boolean t33_valid;
  boolean t34_valid;
  boolean t35_valid;
  boolean t39_valid;
} nas_004D_rsp_s;

/*---------------------------------------------------------------------------
  QMI_NAS_SYS_INFO_IND
---------------------------------------------------------------------------*/
#define NAS_004E_IND_T10                     (0x10)
#define NAS_004E_IND_T11                     (0x11)
#define NAS_004E_IND_T12                     (0x12)
#define NAS_004E_IND_T13                     (0x13)
#define NAS_004E_IND_T14                     (0x14)
#define NAS_004E_IND_T15                     (0x15)
#define NAS_004E_IND_T16                     (0x16)
#define NAS_004E_IND_T17                     (0x17)
#define NAS_004E_IND_T18                     (0x18)
#define NAS_004E_IND_T19                     (0x19)
#define NAS_004E_IND_T1A                     (0x1A)
#define NAS_004E_IND_T1B                     (0x1B)
#define NAS_004E_IND_T1C                     (0x1C)
#define NAS_004E_IND_T1D                     (0x1D)
#define NAS_004E_IND_T1E                     (0x1E)
#define NAS_004E_IND_T1F                     (0x1F)
#define NAS_004E_IND_T20                     (0x20)
#define NAS_004E_IND_T21                     (0x21)
#define NAS_004E_IND_T22                     (0x22)
#define NAS_004E_IND_T23                     (0x23)
#define NAS_004E_IND_T24                     (0x24)
#define NAS_004E_IND_T25                     (0x25)
#define NAS_004E_IND_T26                     (0x26)
#define NAS_004E_IND_T27                     (0x27)
#define NAS_004E_IND_T28                     (0x28)
#define NAS_004E_IND_T29                     (0x29)
#define NAS_004E_IND_T2A                     (0x2A)
#define NAS_004E_IND_T2B                     (0x2B)
#define NAS_004E_IND_T2C                     (0x2C)
#define NAS_004E_IND_T2D                     (0x2D)
#define NAS_004E_IND_T2E                     (0x2E)
#define NAS_004E_IND_T2F                     (0x2F)
#define NAS_004E_IND_T30                     (0x30)
#define NAS_004E_IND_T31                     (0x31)
#define NAS_004E_IND_T32                     (0x32)
#define NAS_004E_IND_T33                     (0x33)
#define NAS_004E_IND_T34                     (0x34)
#define NAS_004E_IND_T35                     (0x35)
#define NAS_004E_IND_T36                     (0x36)
#define NAS_004E_IND_T3A                     (0x3A)

typedef struct
{
  struct nas_004E_ind_t10_s
  {
    uint8 srv_status;
    uint8 is_pref_data_path;
  } t10; // cdma_srv_status_info

  struct nas_004E_ind_t11_s
  {
    uint8 srv_status;
    uint8 is_pref_data_path;
  } t11; // hdr_srv_status_info

  struct nas_004E_ind_t12_s
  {
    uint8 srv_status;
    uint8 true_srv_status;
    uint8 is_pref_data_path;
  } t12; // gsm_srv_status_info

  struct nas_004E_ind_t13_s
  {
    uint8 srv_status;
    uint8 true_srv_status;
    uint8 is_pref_data_path;
  } t13; // wcdma_srv_status_info

  struct nas_004E_ind_t14_s
  {
    uint8 srv_status;
    uint8 true_srv_status;
    uint8 is_pref_data_path;
  } t14; // lte_srv_status_info

  struct nas_004E_ind_t15_s
  {
    // nas_common_sys_info_type
    uint8 srv_domain_valid;
    uint8 srv_domain;
    uint8 srv_capability_valid;
    uint8 srv_capability;
    uint8 roam_status_valid;
    uint8 roam_status;
    uint8 is_sys_forbidden_valid;
    uint8 is_sys_forbidden;

    // nas_cdma_hdr_only_sys_info_type
    uint8 is_sys_prl_match_valid;
    uint8 is_sys_prl_match;

    // nas_cdma_only_sys_info_type 
    uint8 p_rev_in_use_valid;
    uint8 p_rev_in_use;
    uint8 bs_p_rev_valid;
    uint8 bs_p_rev;
    uint8 ccs_supported_valid;
    uint8 ccs_supported;
    uint8 cdma_sys_id_valid;
    uint16 sid;
    uint16 nid;
    uint8 bs_info_valid;
    uint16 base_id;
    int32 base_lat;
    int32 base_long;
    uint8 packet_zone_valid;
    uint16 packet_zone;
    uint8  network_id_valid;
    uint8  mcc[3];
    uint8  mnc[3];        
  } t15; // cdma_sys_info

  struct nas_004E_ind_t16_s
  {
    // nas_common_sys_info_type
    uint8 srv_domain_valid;
    uint8 srv_domain;
    uint8 srv_capability_valid;
    uint8 srv_capability;
    uint8 roam_status_valid;
    uint8 roam_status;
    uint8 is_sys_forbidden_valid;
    uint8 is_sys_forbidden;

    // nas_cdma_hdr_only_sys_info_type
    uint8 is_sys_prl_match_valid;
    uint8 is_sys_prl_match;

    // nas_hdr_only_sys_info_type
    uint8 hdr_personality_valid;
    uint8 hdr_personality;
    uint8 hdr_active_prot_valid;
    uint8 hdr_active_prot;
    uint8 is856_sys_id_valid;
    uint8 is856_sys_id[NAS_IS_856_MAX_LEN]; //TODO: Confirm that this is correct
  } t16; // hdr_sys_info

  struct nas_004E_ind_t17_s
  {
    // nas_common_sys_info_type
    uint8 srv_domain_valid;
    uint8 srv_domain;
    uint8 srv_capability_valid;
    uint8 srv_capability;
    uint8 roam_status_valid;
    uint8 roam_status;
    uint8 is_sys_forbidden_valid;
    uint8 is_sys_forbidden;

    // nas_3gpp_only_sys_info_type
    uint8  lac_valid;
    uint16 lac; 
    uint8  cell_id_valid;
    uint32 cell_id;
    uint8  reg_reject_info_valid;      
    uint8  reject_srv_domain;
    uint8  rej_cause;
    uint8  network_id_valid;
    uint8  mcc[3];
    uint8  mnc[3];    

    // nas_gsm_only_sys_info_type
    uint8 egprs_supp_valid;
    uint8 egprs_supp;
    uint8 dtm_supp_valid;
    uint8 dtm_supp;
  } t17; // gsm_sys_info

  struct nas_004E_ind_t18_s
  {
    // nas_common_sys_info_type
    uint8 srv_domain_valid;
    uint8 srv_domain;
    uint8 srv_capability_valid;
    uint8 srv_capability;
    uint8 roam_status_valid;
    uint8 roam_status;
    uint8 is_sys_forbidden_valid;
    uint8 is_sys_forbidden;

    // nas_3gpp_only_sys_info_type
    uint8  lac_valid;
    uint16 lac; 
    uint8  cell_id_valid;
    uint32 cell_id;
    uint8  reg_reject_info_valid;      
    uint8  reject_srv_domain;
    uint8  rej_cause;
    uint8  network_id_valid;
    uint8  mcc[3];
    uint8  mnc[3];    

    // nas_wcdma_only_sys_info_type
    uint8 hs_call_status_valid;
    uint8 hs_call_status;
    uint8 hs_ind_valid;
    uint8 hs_ind;
    uint8 psc_valid;
    uint16 psc;
  } t18; // wcdma_sys_info

  struct nas_004E_ind_t19_s
  {
    // nas_common_sys_info_type
    uint8 srv_domain_valid;
    uint8 srv_domain;
    uint8 srv_capability_valid;
    uint8 srv_capability;
    uint8 roam_status_valid;
    uint8 roam_status;
    uint8 is_sys_forbidden_valid;
    uint8 is_sys_forbidden;

    // nas_3gpp_only_sys_info_type
    uint8  lac_valid;
    uint16 lac; 
    uint8  cell_id_valid;
    uint32 cell_id;
    uint8  reg_reject_info_valid;      
    uint8  reject_srv_domain;
    uint8  rej_cause;
    uint8  network_id_valid;
    uint8  mcc[3];
    uint8  mnc[3];    

    // nas_lte_only_sys_info_type
    uint8 tac_valid;
    uint16 tac;
  } t19; // lte_sys_info

  struct nas_004E_rsp_t1A_s
  {
    uint16 geo_sys_idx;
    uint16 reg_prd;
  } t1A; // additional cdma_sys_info

  struct nas_004E_rsp_t1B_s
  {
    uint16 geo_sys_idx;
  } t1B; // additional hdr_sys_info

  struct nas_004E_rsp_t1C_s
  {
    uint16 geo_sys_idx;
    uint32 cell_broadcast_cap; // enum nas_cell_broadcast_cap_e
  } t1C; // additional gsm_sys_info

  struct nas_004E_rsp_t1D_s
  {
    uint16 geo_sys_idx;
    uint32 cell_broadcast_cap; // enum nas_cell_broadcast_cap_e
  } t1D; // additional cdma_sys_info

  struct nas_004E_rsp_t1E_s
  {
    uint16 geo_sys_idx;
  } t1E; // additional cdma_sys_info

  struct nas_004E_ind_t1F_s
  {
    uint32 cs_bar_status; // enum nas_cell_access_e
    uint32 ps_bar_status; // enum nas_cell_access_e 
  } t1F; // gsm cell access info

  struct nas_004E_ind_t20_s
  {
    uint32 cs_bar_status; // enum nas_cell_access_e
    uint32 ps_bar_status; // enum nas_cell_access_e 
  } t20; // wcdma cell access info

  struct nas_004E_ind_t21_s
  {
    uint8 voice_support_on_lte;
  } t21;

  struct nas_004E_ind_t22_s
  {
    uint8 gsm_cipher_domain;
  } t22; 

  struct nas_004E_ind_t23_s
  {
    uint8 wcdma_cipher_domain;
  } t23;

  struct nas_004E_ind_t24_s
  {
    uint8 sys_info_no_change;
  } t24;

  struct nas_004E_ind_t25_s
  {
    uint8 srv_status;
    uint8 true_srv_status;
    uint8 is_pref_data_path;
  } t25; // tdscdma_srv_status_info

  struct nas_004E_ind_t26_s
  {
    // nas_common_sys_info_type
    uint8 srv_domain_valid;
    uint8 srv_domain;
    uint8 srv_capability_valid;
    uint8 srv_capability;
    uint8 roam_status_valid;
    uint8 roam_status;
    uint8 is_sys_forbidden_valid;
    uint8 is_sys_forbidden;

    // nas_3gpp_only_sys_info_type
    uint8  lac_valid;
    uint16 lac; 
    uint8  cell_id_valid;
    uint32 cell_id;
    uint8  reg_reject_info_valid;      
    uint8  reject_srv_domain;
    uint8  rej_cause;
    uint8  network_id_valid;
    uint8  mcc[3];
    uint8  mnc[3];    

    // nas_tdscdma_only_sys_info_type
    uint8  hs_call_status_valid;
    uint8  hs_call_status;
    uint8  hs_ind_valid;
    uint8  hs_ind;
    uint8  cell_parameter_id_valid;
    uint16 cell_parameter_id;
    uint8  cell_broadcast_cap_valid;
    uint32 cell_broadcast_cap;
    uint8  cs_bar_status_valid;
    uint32 cs_bar_status;
    uint8  ps_bar_status_valid;
    uint32 ps_bar_status;
    uint8  cipher_domain_valid;
    uint8  cipher_domain;
  } t26; // tdscdma_sys_info

  struct nas_004E_rsp_t27_s
  {
    uint8 lte_embms_coverage;
  } t27;

  struct nas_004D_ind_t28_s
  {
    uint32 sim_rej_info; // enum nas_sim_rej_info
  } t28;

  struct nas_004E_ind_t29_s
  {
    uint8 wcdma_eutra_status; // enum nas_eutra_cell_status_e
  } t29;

  struct nas_004E_ind_t2A_s
  {
    uint8 lte_ims_voice_avail;
  } t2A;

  struct nas_004E_ind_t2B_s
  {
    uint32 lte_voice_status;
  } t2B;

  struct nas_004E_ind_t2C_s
  {
    uint16 cdma_reg_zone;
  } t2C;

  struct nas_004E_ind_t2D_s
  {
    uint8  gsm_rac;
  } t2D;

  struct nas_004E_ind_t2E_s
  {
    uint8  wcdma_rac;
  } t2E;

  struct nas_004E_ind_t2F_s
  {
    uint16 cdma_mcc_resolved_via_sid_lookup; // CDMA resolved MCC via SID lookup
  } t2F;

  struct nas_004E_ind_t30_s
  {
    uint32  srv_reg_restriction;
  } t30;

  struct nas_004E_ind_t31_s
  {
    uint32  tdscdma_reg_domain;
  } t31;

  struct nas_004E_ind_t32_s
  {
    uint32  lte_reg_domain;
  } t32;

  struct nas_004E_ind_t33_s
  {
    uint32  wcdma_reg_domain;
  } t33;

  struct nas_004E_ind_t34_s
  {
    uint32  gsm_reg_domain;
  } t34;

  struct nas_004E_ind_t35_s
  {
    int16 lte_embms_coverage_trace_id; // LTE eMBMS Coverage Info trace id. 0 - 32768 represents a valid trace id. -1 represents trace id not used.
  } t35;

  struct nas_004E_ind_t36_s
  {
    uint32 csg_id;
    uint32 name_len;
    uint16 name[NAS_CSG_NAME_MAX_LEN];
  } t36;

  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
  boolean t14_valid;
  boolean t15_valid;
  boolean t16_valid;
  boolean t17_valid;
  boolean t18_valid;
  boolean t19_valid;
  boolean t1A_valid;
  boolean t1B_valid;
  boolean t1C_valid;
  boolean t1D_valid;
  boolean t1E_valid;
  boolean t1F_valid;
  boolean t20_valid;
  boolean t21_valid;
  boolean t22_valid;
  boolean t23_valid;
  boolean t24_valid;
  boolean t25_valid;
  boolean t26_valid;
  boolean t27_valid;  
  boolean t28_valid;
  boolean t29_valid;
  boolean t2A_valid;
  boolean t2B_valid;
  boolean t2C_valid;
  boolean t2D_valid;
  boolean t2E_valid;
  boolean t2F_valid;
  boolean t30_valid;
  boolean t31_valid;
  boolean t32_valid;
  boolean t33_valid;
  boolean t34_valid;
  boolean t35_valid;
  boolean t36_valid;
} nas_004E_ind_s;

/*---------------------------------------------------------------------------
  QMI_NAS_GET_SIG_INFO
---------------------------------------------------------------------------*/
#define NAS_004F_RSP_T10                     (0x10)
#define NAS_004F_RSP_T11                     (0x11)
#define NAS_004F_RSP_T12                     (0x12)
#define NAS_004F_RSP_T13                     (0x13)
#define NAS_004F_RSP_T14                     (0x14)
#define NAS_004F_RSP_T15                     (0x15)
#define NAS_004F_RSP_T16                     (0x16)

typedef struct
{
  // CDMA Signal Strength Info
  struct nas_004F_rsp_t10_s
  {
    int8 rssi;
    int16 ecio;
  } t10;
  
  // HDR Signal Strength Info
  struct nas_004F_rsp_t11_s
  {
    int8 rssi;
    int16 ecio;
    uint8 sinr;
    int32 io;
  } t11;
  
  // GSM Signal Strength Info
  struct nas_004F_rsp_t12_s
  {
    int8 gsm_sig_info;
  } t12;
  
  // WCDMA Signal Strength Info
  struct nas_004F_rsp_t13_s
  {
    int8 rssi;
    int16 ecio;
  } t13;
  
  // LTE Signal Strength Info
  struct nas_004F_rsp_t14_s
  {
    int8 rssi;
    int8 rsrq;
    int16 rsrp;
    int16 snr;
  } t14;
  
  // TDSCDMA Signal Strength Info
  struct nas_004F_rsp_t15_s
  {
    int8 rscp;
  } t15;
  
  // TDSCDMA Signal Strength Info Extended
  struct nas_004F_rsp_t16_s
  {
    float rssi;
    float rscp;
    float ecio;
    float sinr;
  } t16;

  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
  boolean t14_valid;
  boolean t15_valid;
  boolean t16_valid;
} nas_004F_rsp_s;

/*---------------------------------------------------------------------------
  QMI_NAS_CONFIG_SIG_INFO			0x0050
---------------------------------------------------------------------------*/
#define NAS_0050_REQ_T10      (0x10)
#define NAS_0050_REQ_T11      (0x11)
#define NAS_0050_REQ_T12      (0x12)
#define NAS_0050_REQ_T13      (0x13)
#define NAS_0050_REQ_T14      (0x14)
#define NAS_0050_REQ_T15      (0x15)
#define NAS_0050_REQ_T16      (0x16)
#define NAS_0050_REQ_T17      (0x17)
#define NAS_0050_REQ_T18      (0x18) 
#define NAS_0050_REQ_T19      (0x19)

#define NAS_0050_REQ_LIST_MAX		16

typedef struct {
  // RSSI Threshold List
  struct nas_0050_req_t10_s {
    uint8 rssi_threshold_list_len;
    int8 rssi_threshold_list[NAS_0050_REQ_LIST_MAX];
  } t10;

  // ECIO Threshold List
  struct nas_0050_req_t11_s {
    uint8 rssi_threshold_list_len;
    int16 rssi_threshold_list[NAS_0050_REQ_LIST_MAX];
  } t11;

  // HDR SINR Threshold List
  struct nas_0050_req_t12_s {
    uint8 hdr_sinr_threshold_list_len;
    uint8 hdr_sinr_threshold_list[NAS_0050_REQ_LIST_MAX];
  } t12;

  // LTE SNR Threshold List
  struct nas_0050_req_t13_s {
    uint8 lte_snr_threshold_list_len;
    int16 lte_snr_threshold_list[NAS_0050_REQ_LIST_MAX];
  } t13;

  // IO Threshold List
  struct nas_0050_req_t14_s {
    uint8 io_threshold_list_len;
    int32 io_threshold_list[NAS_0050_REQ_LIST_MAX];
  } t14;

  // RSRQ Threshold List
  struct nas_0050_req_t15_s {
    uint8 lte_rsrq_threshold_list_len;
    int8 lte_rsrq_threshold_list[NAS_0050_REQ_LIST_MAX];
  } t15;

  // RSRP Threshold List
  struct nas_0050_req_t16_s {
    uint8 lte_rsrp_threshold_list_len;
    int16 lte_rsrp_threshold_list[NAS_0050_REQ_LIST_MAX];
  } t16;

  // LTE Signal Report Config
  struct nas_0050_req_t17_s {
    uint8 rpt_rate;
    uint8 avg_period;
  } t17;

  // RSCP Threshold List
  struct nas_0050_req_t18_s {
    uint8 rscp_threshold_list_len;
    int8 rscp_threshold_list[NAS_0050_REQ_LIST_MAX];
  } t18; 

  // TDSCDMA SINR Threshold List
  struct nas_0050_req_t19_s {
    uint8 tds_sinr_threshold_list_len;
    float tds_sinr_threshold_list[NAS_0050_REQ_LIST_MAX];
  } t19;      

  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
  boolean t14_valid;
  boolean t15_valid;
  boolean t16_valid;
  boolean t17_valid;
  boolean t18_valid;
  boolean t19_valid;
} nas_0050_req_s;

/*---------------------------------------------------------------------------
  QMI_NAS_SIG_INFO_IND		0x0051
---------------------------------------------------------------------------*/
#define NAS_0051_IND_T10                     (0x10)
#define NAS_0051_IND_T11                     (0x11)
#define NAS_0051_IND_T12                     (0x12)
#define NAS_0051_IND_T13                     (0x13)
#define NAS_0051_IND_T14                     (0x14)
#define NAS_0051_IND_T15                     (0x15)
#define NAS_0051_IND_T16                     (0x16)

typedef struct 
{
  // CDMA Signal Strength Info
  struct nas_0051_ind_t10_s
  {
    int8 rssi;
    int16 ecio;
  } t10;
  
  // HDR Signal Strength Info
  struct nas_0051_ind_t11_s
  {
    int8 rssi;
    int16 ecio;
    uint8 sinr;
    int32 io;
  } t11;
  
  // GSM Signal Strength Info
  struct nas_0051_ind_t12_s
  {
    int8 gsm_sig_info;
  } t12;
  
  // WCDMA Signal Strength Info
  struct nas_0051_ind_t13_s
  {
    int8 rssi;
    int16 ecio;
  } t13;
  
  // LTE Signal Strength Info
  struct nas_0051_ind_t14_s
  {
    int8 rssi;
    int8 rsrq;
    int16 rsrp;
    int16 snr;
  } t14;
  
  // TDSCDMA Signal Strength Info
  struct nas_0051_ind_t15_s
  {
    int8 rscp;
  } t15;
  
  // TDSCDMA Signal Strength Info Extended
  struct nas_0051_ind_t16_s
  {
    float rssi;
    float rscp;
    float ecio;
    float sinr;
  } t16;

  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
  boolean t14_valid;
  boolean t15_valid;
  boolean t16_valid;
} nas_0051_ind_s;

/*---------------------------------------------------------------------------
 QMI_NAS_CURRENT_PLMN_NAME_IND
---------------------------------------------------------------------------*/
#define NAS_0061_IND_T10                     (0x10)
#define NAS_0061_IND_T11                     (0x11)
#define NAS_0061_IND_T12                     (0x12)
#define NAS_0061_IND_T13                     (0x13)
#define NAS_0061_IND_T14                     (0x14)
#define NAS_0061_RSP_T10_NETWORK_NAME_MAX    255
#define NAS_0061_RSP_T10_SPN_LEN_MAX         16

typedef struct {
  struct nas_0061_ind_t10_s
  {
    uint16 mcc;
    uint16 mnc;
    uint8  mnc_includes_pcs_digit;
  } t10; 

  struct nas_0061_ind_t11_s
  {
    uint8 srv_prov_name_encoding;
    uint8 srv_prov_name_len;
    uint8 srv_prov_name_name[NAS_0061_RSP_T10_SPN_LEN_MAX];
  } t11; 

  struct nas_0061_ind_t12_s
  {
    uint8 plmn_name_short_encoding;
    uint8 plmn_name_short_ci;
    uint8 plmn_name_short_spare_bits;
    uint8 plmn_name_short_len;
    uint8 plmn_name_short[NAS_0061_RSP_T10_NETWORK_NAME_MAX];
  } t12; 

  struct nas_0061_ind_t13_s
  {
    uint8 plmn_name_long_encoding;
    uint8 plmn_name_long_ci;
    uint8 plmn_name_long_spare_bits;
    uint8 plmn_name_long_len;
    uint8 plmn_name_long[NAS_0061_RSP_T10_NETWORK_NAME_MAX];
  } t13;   

  struct nas_0061_ind_t14_s
  {
    uint32 csg_id;
  } t14;

  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
  boolean t14_valid;
}nas_0061_ind_s;


/*---------------------------------------------------------------------------
  QMI_NAS_NETWORK_REJECT_IND
---------------------------------------------------------------------------*/
#define NAS_0068_IND_T01                     (0x01)
#define NAS_0068_IND_T02                     (0x02)
#define NAS_0068_IND_T03                     (0x03)
#define NAS_0068_IND_T10                     (0x10)
#define NAS_0068_IND_T11                     (0x11)

typedef struct
{
  // Radio Interface
  struct nas_0068_ind_t01_s
  {
    uint8 radio_if;
  } t01;
  
  // Service Domain
  struct nas_0068_ind_t02_s
  {
    uint8 reject_srv_domain;      
  } t02;
  
  // Registration Rejection Cause
  struct nas_0068_ind_t03_s
  {
    uint8 rej_cause;
  } t03;
  
  // PLMN ID
  struct nas_0068_ind_t10_s
  {
    uint16 mcc;
    uint16 mnc;
    uint8 mnc_includes_pcs_digit;
  } t10;
  
  // CSG ID
  struct nas_0068_ind_t11_s
  {
    uint32 csg_id;
  } t11;

  boolean t10_valid;
  boolean t11_valid;
} nas_0068_ind_s;

/*---------------------------------------------------------------------------
  QMI_NAS_CONFIG_SIG_INFO2
---------------------------------------------------------------------------*/
#define NAS_006C_REQ_T10                     (0x10)
#define NAS_006C_REQ_T11                     (0x11)
#define NAS_006C_REQ_T12                     (0x12)
#define NAS_006C_REQ_T13                     (0x13)
#define NAS_006C_REQ_T14                     (0x14)
#define NAS_006C_REQ_T15                     (0x15)
#define NAS_006C_REQ_T16                     (0x16)
#define NAS_006C_REQ_T17                     (0x17)
#define NAS_006C_REQ_T18                     (0x18)
#define NAS_006C_REQ_T19                     (0x19)
#define NAS_006C_REQ_T1A                     (0x1A)
#define NAS_006C_REQ_T1B                     (0x1B)
#define NAS_006C_REQ_T1C                     (0x1C)
#define NAS_006C_REQ_T1D                     (0x1D)
#define NAS_006C_REQ_T1E                     (0x1E)
#define NAS_006C_REQ_T1F                     (0x1F)
#define NAS_006C_REQ_T20                     (0x20)
#define NAS_006C_REQ_T21                     (0x21)
#define NAS_006C_REQ_T22                     (0x22)
#define NAS_006C_REQ_T23                     (0x23)
#define NAS_006C_REQ_T24                     (0x24)
#define NAS_006C_REQ_T25                     (0x25)
#define NAS_006C_REQ_T26                     (0x26)
#define NAS_006C_REQ_T27                     (0x27)
#define NAS_006C_REQ_T28                     (0x28)
#define NAS_006C_REQ_T29                     (0x29)
#define NAS_006C_REQ_T2A                     (0x2A)
#define NAS_006C_REQ_T2B                     (0x2B)
#define NAS_006C_REQ_T2C                     (0x2C)
#define NAS_006C_REQ_T2D                     (0x2D)
#define NAS_006C_REQ_T2E                     (0x2E)
#define NAS_006C_REQ_T2F                     (0x2F)
#define NAS_006C_REQ_T30                     (0x30)
#define NAS_006C_REQ_T31                     (0x31)
#define NAS_006C_REQ_T32                     (0x32)

#define NAS_006C_MAX_THRESHOLDS              (32)
#define NAS_006C_MIN_DELTA                   (1)

typedef struct {

  struct nas_006C_req_t10_s
  {
    uint8 cdma_rssi_threshold_list_len;
    int16 cdma_rssi_threshold_list[NAS_006C_MAX_THRESHOLDS];
  } t10;

  struct nas_006C_req_t11_s
  {
    uint16 cdma_rssi_delta;
  } t11;

  struct nas_006C_req_t12_s
  {
    uint8 cdma_ecio_threshold_list_len;
    int16 cdma_ecio_threshold_list[NAS_006C_MAX_THRESHOLDS];
  } t12;

  struct nas_006C_req_t13_s
  {
    uint16 cdma_ecio_delta;
  } t13;

  struct nas_006C_req_t14_s
  {
    uint8 hdr_rssi_threshold_list_len;
    int16 hdr_rssi_threshold_list[NAS_006C_MAX_THRESHOLDS];
  } t14; 

  struct nas_006C_req_t15_s
  {
    uint16 hdr_rssi_delta;
  } t15;

  struct nas_006C_req_t16_s
  {
    uint8 hdr_ecio_threshold_list_len;
    int16 hdr_ecio_threshold_list[NAS_006C_MAX_THRESHOLDS];
  } t16;

  struct nas_006C_req_t17_s
  {
    uint16 hdr_ecio_delta;
  } t17;

  struct nas_006C_req_t18_s
  {
    uint8 hdr_sinr_threshold_list_len;
    uint16 hdr_sinr_threshold_list[NAS_006C_MAX_THRESHOLDS];
  } t18;

  struct nas_006C_req_t19_s
  {
    uint16 hdr_sinr_delta;
  } t19;

  struct nas_006C_req_t1A_s
  {
    uint8 hdr_io_threshold_list_len;
    int16 hdr_io_threshold_list[NAS_006C_MAX_THRESHOLDS];
  } t1A;

  struct nas_006C_req_t1B_s
  {
    uint16 hdr_io_delta;
  } t1B;

  struct nas_006C_req_t1C_s
  {
    uint8 gsm_rssi_threshold_list_len;
    int16 gsm_rssi_threshold_list[NAS_006C_MAX_THRESHOLDS];
  } t1C;

  struct nas_006C_req_t1D_s
  {
    uint16 gsm_rssi_delta;
  } t1D;

  struct nas_006C_req_t1E_s
  {
    uint8 wcdma_rssi_threshold_list_len;
    int16 wcdma_rssi_threshold_list[NAS_006C_MAX_THRESHOLDS];
  } t1E;

  struct nas_006C_req_t1F_s
  {
    uint16 wcdma_rssi_delta;
  } t1F;

  struct nas_006C_req_t20_s
  {
    uint8 wcdma_ecio_threshold_list_len;
    int16 wcdma_ecio_threshold_list[NAS_006C_MAX_THRESHOLDS];
  } t20;

  struct nas_006C_req_t21_s
  {
    uint16 wcdma_ecio_delta;
  } t21;

  struct nas_006C_req_t22_s
  {
    uint8 lte_rssi_threshold_list_len;
    int16 lte_rssi_threshold_list[NAS_006C_MAX_THRESHOLDS];
  } t22;

  struct nas_006C_req_t23_s
  {
    uint16 lte_rssi_delta;
  } t23;

  struct nas_006C_req_t124_s
  {
    uint8 lte_snr_threshold_list_len;
    int16 lte_snr_threshold_list[NAS_006C_MAX_THRESHOLDS];
  } t24;

  struct nas_006C_req_t25_s
  {
    uint16 lte_snr_delta;
  } t25;

  struct nas_006C_req_t26_s
  {
    uint8 lte_rsrq_threshold_list_len;
    int16 lte_rsrq_threshold_list[NAS_006C_MAX_THRESHOLDS];
  } t26;

  struct nas_006C_req_t27_s
  {
    uint16 lte_rsrq_delta;
  } t27;

  struct nas_006C_req_t128_s
  {
    uint8 lte_rsrp_threshold_list_len;
    int16 lte_rsrp_threshold_list[NAS_006C_MAX_THRESHOLDS];
  } t28;

  struct nas_006C_req_t29_s
  {
    uint16 lte_rsrp_delta;
  } t29;

  struct nas_006C_req_t2A_s
  {
    uint8 rpt_rate;   // enum nas_lte_sig_rpt_rate_e
    uint8 avg_period; // enum nas_lte_sig_avg_prd_e
  } t2A; // LTE signal reporting config

  struct nas_006C_req_t2B_s
  {
    uint8 tdscdma_rscp_threshold_list_len;
    int16 tdscdma_rscp_threshold_list[NAS_006C_MAX_THRESHOLDS];
  } t2B;

  struct nas_006C_req_t2C_s
  {
    uint16 tdscdma_rscp_delta;
  } t2C;

  struct nas_006C_req_t2D_s
  {
    uint8 tds_rssi_threshold_list_len;
    float tds_rssi_threshold_list[NAS_006C_MAX_THRESHOLDS];
  } t2D;

  struct nas_006C_req_t2E_s
  {
    float tdscdma_rssi_delta;
  } t2E;

  struct nas_006C_req_t2F_s
  {
    uint8 tds_ecio_threshold_list_len;
    float tds_ecio_threshold_list[NAS_006C_MAX_THRESHOLDS];
  } t2F;

  struct nas_006C_req_t30_s
  {
    float tdscdma_ecio_delta;
  } t30;

  struct nas_006C_req_t31_s
  {
    uint8 tds_sinr_threshold_list_len;
    float tds_sinr_threshold_list[NAS_006C_MAX_THRESHOLDS];
  } t31;

  struct nas_006C_req_t32_s
  {
    float tdscdma_sinr_delta;
  } t32;

  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
  boolean t14_valid;
  boolean t15_valid;
  boolean t16_valid;  
  boolean t17_valid;
  boolean t18_valid;
  boolean t19_valid;
  boolean t1A_valid;
  boolean t1B_valid;
  boolean t1C_valid;
  boolean t1D_valid;
  boolean t1E_valid;
  boolean t1F_valid;
  boolean t20_valid;
  boolean t21_valid;
  boolean t22_valid;
  boolean t23_valid;
  boolean t24_valid;
  boolean t25_valid;
  boolean t26_valid;
  boolean t27_valid;
  boolean t28_valid;
  boolean t29_valid;
  boolean t2A_valid;
  boolean t2B_valid;
  boolean t2C_valid;
  boolean t2D_valid;
  boolean t2E_valid;
  boolean t2F_valid;
  boolean t30_valid;
  boolean t31_valid;
  boolean t32_valid;
}nas_006C_req_s;

/*---------------------------------------------------------------------------
 QMI_NAS_GET_PROTOCOL_INFO
---------------------------------------------------------------------------*/
#define NAS_5556_RSP_T10        (0x10)
#define NAS_5556_RSP_T11        (0x11)
#define NAS_5556_RSP_T12        (0x12)
#define NAS_5556_RSP_T13        (0x13)
#define NAS_5556_RSP_T14        (0x14)
#define NAS_5556_RSP_T15        (0x15)
#define NAS_5556_RSP_T16        (0x16)
#define NAS_5556_RSP_T17        (0x17)
#define NAS_5556_RSP_T18        (0x18)

typedef struct {
  struct nas_5556_rsp_t10_s
  {
    uint16 pref_mode;
  } t10;

  struct nas_5556_rsp_t11_s
  {
    uint16 service_domain_pref;
  } t11;

  struct nas_5556_rsp_t12_s
  {
    uint8 security;
    boolean rrc_integrity_enabled;
    boolean rrc_ciphering_enabled;
    boolean rrc_fake_security_enabled;
  } t12;

  struct nas_5556_rsp_t13_s
  {
    byte sms_gw_bearer_pref;
  } t13;

  struct nas_5556_rsp_t14_s
  {
    boolean ipv6_enabled;
  } t14;

  struct nas_5556_rsp_t15_s
  {
    boolean isr_enabled;
  } t15;

  struct nas_5556_rsp_t16_s
  {
    uint16 wcdma_rrc_version;
  } t16;

  struct nas_5556_rsp_t17_s
  {
    boolean wcdma_dl_freq_enabled;
    uint32 wcdma_dl_freq; 
    uint32 forced_freq;
  } t17;

  struct nas_5556_rsp_t18_s
  {
    uint16 gcf_test_mode;
  } t18;

  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
  boolean t14_valid;
  boolean t15_valid;
  boolean t16_valid;
  boolean t17_valid;
  boolean t18_valid;
}nas_5556_rsp_s;

/*---------------------------------------------------------------------------
 (0x5557) QMI_NAS_SET_PROTOCOL_INFO
---------------------------------------------------------------------------*/
#define NAS_5557_REQ_T10        (0x10)
#define NAS_5557_REQ_T11        (0x11)
#define NAS_5557_REQ_T12        (0x12)
#define NAS_5557_REQ_T13        (0x13)
#define NAS_5557_REQ_T14        (0x14)
#define NAS_5557_REQ_T15        (0x15)
#define NAS_5557_REQ_T16        (0x16)
#define NAS_5557_REQ_T17        (0x17)
#define NAS_5557_REQ_T18        (0x18)

typedef struct {
  struct nas_5557_req_t10_s {
    uint16 pref_mode;  
  } t10;
  struct nas_5557_req_t11_s {
    uint16 service_domain_pref;  
  } t11;
  struct nas_5557_req_t12_s {
    uint8 security;
  } t12;
  struct nas_5557_req_t13_s {
    byte sms_gw_bearer_pref;
  } t13;
  struct nas_5557_req_t14_s {
    boolean ipv6_enabled; 
  } t14;
  struct nas_5557_req_t15_s {
    boolean isr_enabled; 
  } t15;
  struct nas_5557_req_t16_s {
    uint16 wcdma_rrc_version; 
  } t16;
  struct nas_5557_req_t17_s {
    boolean wcdma_dl_freq_enabled; 
    uint32 wcdma_dl_freq; 
    uint32 forced_freq;
  } t17;
  struct nas_5557_req_t18_s
  {
    uint16 gcf_test_mode;
  } t18;
  
  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
  boolean t14_valid;
  boolean t15_valid;
  boolean t16_valid;
  boolean t17_valid;
  boolean t18_valid;
}nas_5557_req_s;



/*---------------------------------------------------------------------------
  (0x5558) QMI_NAS_GET_NETWORK_TIME_INFO
---------------------------------------------------------------------------*/
#define NAS_5558_RSP_T01                     (0x01)
#define NAS_5558_RSP_T10                     (0x10)
#define NAS_5558_RSP_T11                     (0x11)
#define NAS_5558_RSP_T12                     (0x12)

typedef struct{
  // Universal Time
  struct nas_5558_rsp_t01_s {
    uint16 year;
    uint8 month;
    uint8 day;
    uint8 hour;
    uint8 minute;
    uint8 second;
    uint8 day_of_week;
  } t01;

  // Time Zone
  struct nas_5558_rsp_t10_s {
    int8 time_zone;
  } t10;

  // Daylight Saving Adjustment
  struct nas_5558_rsp_t11_s {
    uint8 daylt_sav_adj;
  } t11;

  // Radio Interface
  struct nas_5558_rsp_t12_s {
    uint8 radio_if;
  } t12;

  boolean t01_valid;
  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
} nas_5558_rsp_s;

/*---------------------------------------------------------------------------
    (0x5559) QMI_NAS_GET_CURRENT_PLMN_NAME_CACHE_RSP
---------------------------------------------------------------------------*/
#define NAS_5559_RSP_T02  (0x02)
#define NAS_5559_RSP_T12  (0x12)
#define NAS_5559_RSP_T13  (0x13)
#define NAS_5559_RSP_NETWORK_NAME_MAX    255

typedef struct // QMI_NAS_GET_CURRENT_PLMN_NAME_CACHE_RSP
{
  struct nas_5559_rsp_t02_s
  {
    uint16 result_code; // qmi_result_e_type;
    uint16 error_code;  // qmi_error_e_type;
  } t02; // Result Code

  struct nas_5559_rsp_t12_s
  {
    uint8 plmn_name_short_encoding;
    uint8 plmn_name_short_ci;
    uint8 plmn_name_short_spare_bits;
    uint8 plmn_name_short_len;
    uint8 plmn_name_short[NAS_5559_RSP_NETWORK_NAME_MAX];
  } t12;

  struct nas_5559_rsp_t13_s
  {
    uint8 plmn_name_long_encoding;
    uint8 plmn_name_long_ci;
    uint8 plmn_name_long_spare_bits;
    uint8 plmn_name_long_len;
    uint8 plmn_name_long[NAS_5559_RSP_NETWORK_NAME_MAX];
  } t13;

  boolean t02_valid;
  boolean t12_valid;
  boolean t13_valid;
}nas_5559_rsp_s;

/*---------------------------------------------------------------------------
 QMI_NAS_GET_PREFERRED_NETWORK
---------------------------------------------------------------------------*/
#define NAS_555A_RSP_T10        (0x10)
#define NAS_555A_RSP_T11        (0x11)
#define NAS_555A_RSP_T12        (0x12)

typedef struct {
  struct nas_555A_rsp_t10_s
  {
    uint16 pref_mode;
  } t10;

  struct nas_555A_rsp_t11_s {
    uint32 gw_acq_order_pref;
  } t11;
  
  struct nas_555A_rsp_t12_s {
    uint64 lte_band_pref;    
  } t12;

  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
}nas_555A_rsp_s;

/*---------------------------------------------------------------------------
 QMI_NAS_SET_PREFERRED_NETWORK
---------------------------------------------------------------------------*/
#define NAS_555B_REQ_T10        (0x10)
#define NAS_555B_REQ_T11        (0x11)
#define NAS_555B_REQ_T12        (0x12)

typedef struct {
  struct nas_555B_req_t10_s {
    uint16 pref_mode;  
  } t10;
  struct nas_555B_req_t11_s {
    uint32 gw_acq_order_pref;
  } t11;
  struct nas_555B_req_t12_s {
    uint64 lte_band_pref;  
  } t12;

  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
}nas_555B_req_s;


/*---------------------------------------------------------------------------
 QMI_NAS_GET_PREFERRED_MODE
---------------------------------------------------------------------------*/
#define NAS_557D_RSP_T10        (0x10)
#define NAS_557D_RSP_T11        (0x11)


typedef struct {
  struct nas_557D_rsp_t10_s
  {
    uint16 pref_mode;
  } t10;
  
  struct nas_557D_rsp_t11_s {
    uint64 lte_band_pref;    
  } t11;

  boolean t10_valid;
  boolean t11_valid;
}nas_557D_rsp_s;

/*---------------------------------------------------------------------------
 QMI_NAS_SET_PREFERRED_MODE
---------------------------------------------------------------------------*/
#define NAS_557C_REQ_T10        (0x10)
#define NAS_557C_REQ_T11        (0x11)

typedef struct {
  struct nas_557C_req_t10_s {
    uint16 pref_mode;  
  } t10;

  struct nas_557C_req_t11_s {
    uint64 lte_band_pref;  
  } t11;

  boolean t10_valid;
  boolean t11_valid;
}nas_557C_req_s;



/*---------------------------------------------------------------------------
  (0x555C) QMI_NAS_GET_DEBUG_SRCEEN_INFO
---------------------------------------------------------------------------*/
#define QMI_TMSI_MAX_SIZE                    0x04
#define QMI_IP_MAX_SIZE                      0x04
#define QMI_NEIGHBOR_SET_INDEX               0x04
#define QMI_IMSI_MAX_INDEX                   0x20
#define QMI_MSISDN_MAX_INDEX                 0x20
#define QMI_MAX_LTE_CELL_INFO_NUM						8
#define QMI_MAX_LTE_FREQ_INFO_NUM						2
#define QMI_MAX_EUTRA_INFO_NUM								8	

#define NAS_555C_RSP_T01                     0x01

typedef struct
{
	uint16 pci;
	int16 rsrp;
	int16 rsrq;
	int16 rssi;
	int16 sinr;
} lte_cell_info_s;

typedef struct
{
	uint32 earfcn;
	uint8  cell_num;
	lte_cell_info_s cell_info[ QMI_MAX_LTE_CELL_INFO_NUM ];
} lte_freq_info_s;

typedef struct
{
	uint32	eutra_num;
	int32	eutra_wtol[ QMI_MAX_EUTRA_INFO_NUM ];
} sib19_info_s;

typedef struct
{
	uint8 freq_num;
	lte_freq_info_s freq_info[ QMI_MAX_LTE_FREQ_INFO_NUM ];	
} lte_inter_info_s;

typedef struct
{
	uint8  cell_num;
	lte_cell_info_s cell_info[ QMI_MAX_LTE_CELL_INFO_NUM ];
} lte_intra_info_s;
//dsji_20160929 add }

typedef struct {
  struct nas_555C_rsp_t01_s {
    uint16 earfcn_dl;
    uint16 earfcn_ul;
    uint8 band_class;
    uint8 band_width;

    uint16 mnc;
    uint16 mcc;
    uint16 tac;
    uint16 pci;
    uint32 cell_id;

    uint8 esm_cause;

    int16 drx;
    int16 rsrp;
    int16 rsrq;
    int16 rssi;
    int16 l2w;
    uint8 ri;
    uint8 cqi;

    uint8 srv_status;
    uint8 emm_status;
    uint8 sub_status;
    uint8 rrc_state;
    uint8 svc;

    int16 sinr;
    int32 tx_pwr;

    uint8 tmsi[QMI_TMSI_MAX_SIZE];
    uint8 pdn_addr[QMI_IP_MAX_SIZE];

    /*20160621 osk, LTE Debug Screen item added*/
    uint8 emm_cause;
  //  lte_nas_emm_guti_type guti ;
    /*end*/
		
    // WCDMA �׸� �߰�
    uint16 uarfcn_dl;
    uint16 uarfcn_ul;
    uint8 network_type;
    uint8 network_mode;
    uint16 lac;
    uint16 rac;
    uint8 mm_cause;
    uint8 mm_state;
    uint8 mm_substate;
    uint8 gmm_cause;
    uint8 gmm_state;
    uint8 gmm_substate;
    uint8 gmm_update_status;
    uint8 sm_cause;
    uint8 w_rrc_state;
    uint8 pmm_mode;
    uint8 pdp_state;
    uint8 sim_state;
    uint8 cm_call_state;
    uint8 mnc_includes_pcs_digit;
    uint8 oprt_mode;
    uint8 location_update_status;
    uint8 p_tmsi[QMI_TMSI_MAX_SIZE];
    uint8 pdp_addr[QMI_IP_MAX_SIZE];
    uint16 nset_psc[QMI_NEIGHBOR_SET_INDEX];
    int16 nset_rscp[QMI_NEIGHBOR_SET_INDEX];
    int16 nset_ecio[QMI_NEIGHBOR_SET_INDEX];    
    int16 w2l;
    uint8 bler;
    int16 iference;
    int32 rx_pwr;
    int32 tx_adj;
    uint8 imsi[QMI_IMSI_MAX_INDEX];
    uint8 msisdn[QMI_MSISDN_MAX_INDEX];
		
		//dsji_20160929 add {
		sib19_info_s sib19_info;
		lte_inter_info_s lte_inter_info;
		lte_intra_info_s lte_intra_info;
		//dsji_20160929 add }
		
		//GSM
	uint8 bcc;
    uint8 ncc;
		
  } t01;

  boolean t01_valid;
} nas_555C_rsp_s;

/*---------------------------------------------------------------------------
 QMI_NAS_SET_ECALL_ENABLE
 jaeyong1.park 2016-09-28
---------------------------------------------------------------------------*/

typedef enum {
	ECALL_SET_ENABLE_OFF = 0x00,
	ECALL_SET_ENABLE_ON = 0x01
}nas_ecall_setenable_e_type_v02;

typedef struct {
  struct nas_ecallen_req_t1_s {
    uint8 ecall_enabled; 
  } t1;

  uint8_t t1_valid; /*boolean value*/
}nas_ecallen_req_s;

#define NAS_ecallon_REQ_T1        (0x10)


/*---------------------------------------------------------------------------
 QMI_NAS_GET_ECALL_ENABLE  -jaeyong1.park
 ---------------------------------------------------------------------------*/
#define NAS_ECALLEN_RSP_T10    		(0x10) //for test
 
 typedef struct {
   struct nas_ECALLEN_rsp_t10_s
   {
	 uint32 ims_enabled;
   } t10;
 
   boolean t10_valid;
 
 }nas_ECALLEN_rsp_s;
 
 /*---------------------------------------------------------------------------
 QMI_NAS_GET_MODEM_VALUE  -jaeyong1.park
---------------------------------------------------------------------------*/

#define MAX_CDATA_LENGTH 200 //payload max 200byte 

//commands
#define GET_ECALL_ENABLE       		(0x51)
#define GET_ECALL_NUMBER			(0x52)
#define GET_ECALL_VOCCONFIG			(0x53)
#define GET_ECALL_CANNEDMSD			(0x54)
#define GET_ECALL_NUMTODIAL			(0x55)
#define GET_ECALL_GNSS_SESSUPDATETIME (0x56)
#define GET_ECALL_SESSIONTIMEOUT 	(0x57)

#define SET_ECALL_CALLBACK_TIMEOUT	(0x58)
#define GET_ECALL_CONFIG_FILE (0x59)
#define GET_MODEM_VERSION (0x5A)
#define GET_GSM_NETWORK_DTM (0X60)
#define GET_GSM_PATH_LOSS_CRITERIA_C1 (0x61)
#define GET_GSM_PATH_LOSS_CRITERIA_C1_2 (0x62)
#define GET_GSM_PATH_LOSS_CRITERIA_C1_3 (0x63)



typedef struct {
  struct nas_GETVAL_rsp_t1_s
  {
    char pdata[MAX_CDATA_LENGTH];//from tof to modem, from modem to tof
  } t1;

  boolean t1_valid;
}nas_GETVAL_rsp_s;



/*---------------------------------------------------------------------------
 QMI_NAS_ENABLE_ECALL_ONLY_MODE
 mwkim 2016-10-11, InnoJIRA : AS045-670, 672
---------------------------------------------------------------------------*/

typedef struct {
  struct nas_ecallonly_en_req_t1_s {
    uint8 ecallonly_enabled; 
  } t1;

  uint8_t t1_valid; /*boolean value*/
}nas_ecallonly_en_req_s;

#define NAS_ecallonly_en_REQ_T1        (0x10)

/*---------------------------------------------------------------------------
 QMI_NAS_READ_ECALL_OPER_MODE
 mwkim 2016-10-14, InnoJIRA : AS045-671
---------------------------------------------------------------------------*/

typedef struct {
  struct nas_7042_rsp_t1_s {
    uint8 ecallmode_read; 
  } t1;
}nas_7042_rsp_s;

#define NAS_7042_RSP_T1        (0x10)


/*---------------------------------------------------------------------------
 QMI_NAS_SET_ECALL_NUMBER
 jaeyong1.park 2016-09-29
---------------------------------------------------------------------------*/

#define MAX_ECALL_NUMBER_DIGITS 20
#define NAS_ecallnumber_REQ_T1        (0x10)
#define NAS_ecallconfig_REQ_T2        (0x20)
#define NAS_ecallconfig_REQ_T3        (0x30)
#define NAS_ecallconfig_REQ_T4        (0x40)
#define NAS_ecallconfig_REQ_T5        (0x50)
#define NAS_ecallconfig_REQ_T6        (0x60)

typedef struct {
  struct nas_ecallnumber_req_t1_s {
	char ecall_number[MAX_ECALL_NUMBER_DIGITS];
  } t1;
  struct nas_ecall_vocconf_req_t2_s {
    uint8 numdata; 
  } t2;
  struct nas_ecall_cannedmsd_req_t3_s {
    uint8 numdata; 
  } t3;
  struct nas_ecall_numtodial_req_t4_s {
    uint8 numdata; 
  } t4;
  struct nas_ecall_gnsstimeout_req_t5_s {
    uint32 numdata; 
  } t5;
  struct nas_ecall_sestimeout_req_t6_s {
    uint32 numdata; 
  } t6;
  
  boolean t1_valid; //[4] ecall digit number
  boolean t2_valid; //[1] VOC_CONFIG  
  boolean t3_valid; //[2] CANNED_MSD  
  boolean t4_valid; //[3] NUM_TO_DIAL 
  boolean t5_valid; //[5] GNSS_UPDATE_TIME_MS  
  boolean t6_valid; //[6] ECALL_SESSION_TIMEOUT: 
}nas_ecallnumber_req_s;;



/*---------------------------------------------------------------------------
 QMI_NAS_GET_IMS_ENABLE
---------------------------------------------------------------------------*/
#define NAS_555E_RSP_T10        (0x10)

typedef struct {
  struct nas_555E_rsp_t10_s
  {
    uint8 ims_enabled;
  } t10;

  boolean t10_valid;
}nas_555E_rsp_s;


/*---------------------------------------------------------------------------
 QMI_NAS_SET_IMS_ENABLE
---------------------------------------------------------------------------*/
#define NAS_555F_REQ_T10        (0x10)

typedef struct {
  struct nas_555F_req_t10_s {
    uint8 ims_enabled; 
  } t10;

  boolean t10_valid;
}nas_555F_req_s;

/*---------------------------------------------------------------------------
 QMI_NAS_GET_IMS_PDN_ENABLE
---------------------------------------------------------------------------*/
#define NAS_5560_RSP_T10        (0x10)

typedef struct {
  struct nas_5560_rsp_t10_s
  {
    uint16 ims_pdn_enabled;
  } t10;

  boolean t10_valid;
}nas_5560_rsp_s;

/*---------------------------------------------------------------------------
 QMI_NAS_SET_IMS_PDN_ENABLE
---------------------------------------------------------------------------*/
#define NAS_5561_REQ_T10        (0x10)

typedef struct {
  struct nas_5561_req_t10_s {
    uint16 ims_pdn_enabled; 
  } t10;

  boolean t10_valid;
}nas_5561_req_s;

/*---------------------------------------------------------------------------
 QMI_NAS_GET_IMS_TEST_MODE
---------------------------------------------------------------------------*/
#define NAS_5563_RSP_T10        (0x10)

typedef struct
{
  struct nas_5563_rsp_t10_s
  {
    uint16 ims_test_mode;
  } t10;

  boolean t10_valid;
}nas_5563_rsp_s;

/*---------------------------------------------------------------------------
 QMI_NAS_SET_IMS_TEST_MODE
---------------------------------------------------------------------------*/
#define NAS_5564_REQ_T10        (0x10)

typedef struct
{
  struct nas_5564_req_t10_s {
    uint16 ims_test_mode; 
  } t10;

  boolean t10_valid;
}nas_5564_req_s;

/*---------------------------------------------------------------------------
 QMI_NAS_GET_IMS_USER_INFO
---------------------------------------------------------------------------*/
#define NAS_5565_RSP_T10        (0x10)
#define NAS_5565_RSP_T11        (0x11)
#define NAS_5565_RSP_T12        (0x12)
#define NAS_5565_RSP_T13        (0x13)

typedef struct {
  struct nas_5565_rsp_t10_s
  {
    char regConfigUserName[128];
  } t10;
  struct nas_5565_rsp_t11_s
  {
    char regConfigPassword[128];
  } t11;  
  struct nas_5565_rsp_t12_s
  {
    char regConfigPrivateURI[128];
  } t12;  
  struct nas_5565_rsp_t13_s
  {
    char regConfigDomainName[256];
  } t13;    

  boolean t10_valid;
  boolean t11_valid;  
  boolean t12_valid;  
  boolean t13_valid;    
}nas_5565_rsp_s;

/*---------------------------------------------------------------------------
 QMI_NAS_SET_IMS_USER_INFO
---------------------------------------------------------------------------*/
#define NAS_5566_REQ_T10        (0x10)
#define NAS_5566_REQ_T11        (0x11)
#define NAS_5566_REQ_T12        (0x12)
#define NAS_5566_REQ_T13        (0x13)

typedef struct {
  struct nas_5566_req_t10_s {
    char regConfigUserName[128];
  } t10;
  struct nas_5566_req_t11_s {
    char regConfigPassword[128];
  } t11;  
  struct nas_5566_req_t12_s {
    char regConfigPrivateURI[128];
  } t12;  
  struct nas_5566_req_t13_s {
    char regConfigDomainName[256];
  } t13;  

  boolean t10_valid;
  boolean t11_valid;  
  boolean t12_valid;  
  boolean t13_valid;  
}nas_5566_req_s;

/*---------------------------------------------------------------------------
 QMI_NAS_GET_IMS_RCS_AUTO_CONFIG
---------------------------------------------------------------------------*/
#define NAS_556B_RSP_T10        (0x10)
#define NAS_556B_RSP_T11        (0x11)
#define NAS_556B_RSP_T12        (0x12)

typedef struct {
  struct nas_556B_rsp_t10_s
  {
    uint8 DisableAutoConfig;
  } t10;
  struct nas_556B_rsp_t11_s
  {
    char RCSConfigServerAddress[45];
  } t11;  
  struct nas_556B_rsp_t12_s
  {
    char RCSConfigServerPort[5];
  } t12;  

  boolean t10_valid;
  boolean t11_valid;  
  boolean t12_valid;  
}nas_556B_rsp_s;

/*---------------------------------------------------------------------------
 QMI_NAS_SET_IMS_RCS_AUTO_CONFIG
---------------------------------------------------------------------------*/
#define NAS_556C_REQ_T10        (0x10)
#define NAS_556C_REQ_T11        (0x11)
#define NAS_556C_REQ_T12        (0x12)

typedef struct {
  struct nas_556C_req_t10_s {
    uint8 DisableAutoConfig;
  } t10;
  struct nas_556C_req_t11_s {
    char RCSConfigServerAddress[45];
  } t11;  
  struct nas_556C_req_t12_s {
    char RCSConfigServerPort[5];
  } t12;  

  boolean t10_valid;
  boolean t11_valid;  
  boolean t12_valid;  
}nas_556C_req_s;

/*---------------------------------------------------------------------------
 QMI_NAS_GET_IMS_DPL_PARAM
---------------------------------------------------------------------------*/
#define NAS_556D_RSP_T10        (0x10)

typedef struct
{
  struct nas_556D_rsp_t10_s
  {
    uint8 IMSParamSrc;
  } t10;

  boolean t10_valid;
}nas_556D_rsp_s;

/*---------------------------------------------------------------------------
 QMI_NAS_SET_IMS_DPL_PARAM
---------------------------------------------------------------------------*/
#define NAS_556E_REQ_T10        (0x10)

typedef struct {
  struct nas_556E_req_t10_s {
    uint8 IMSParamSrc;
  } t10;

  boolean t10_valid;
}nas_556E_req_s;

typedef enum
{
  REQUEST_PARAM_SRC             = 0
} ims_param_src_request_type;

//hongsg 20140729
/*---------------------------------------------------------------------------
 QMI_NAS_GET_IMS_QIPCALL_CONFIG
---------------------------------------------------------------------------*/
#define NAS_556F_RSP_T10        (0x10)

typedef struct {
  struct nas_556F_rsp_t10_s 
	{
    uint8 EnableRTCPforActiveVOIPCall;
  } t10;

  boolean t10_valid;
}nas_556F_rsp_s;

/*---------------------------------------------------------------------------
 QMI_NAS_SET_IMS_QIPCALL_CONFIG
---------------------------------------------------------------------------*/
#define NAS_5570_REQ_T10        (0x10)

typedef struct {
  struct nas_5570_req_t10_s 
	{
    uint8 EnableRTCPforActiveVOIPCall;
  } t10;

  boolean t10_valid;
}nas_5570_req_s;

/*---------------------------------------------------------------------------
  (0x5573) QMI_NAS_OTA_EVENT_LOG_SAVE_IND_MSG_ID
---------------------------------------------------------------------------*/
#define NAS_5573_IND_T01                     (0x01)

typedef struct {
  struct nas_5573_ind_t01_s {
    int8 message_len;
    char message[100];
  } t01;

  boolean t01_valid;
}nas_5573_ind_s;

/*---------------------------------------------------------------------------
  (0x701A) QMI_NAS_OTA_EVENT_LOG_SAVE_IND_MSG_ID
---------------------------------------------------------------------------*/
#define NAS_701A_IND_T01                     (0x01)

typedef struct {
    uint8 gw_srv_status;
    uint8 cdma_srv_status;
    uint8 hdr_srv_status;
    uint8 lte_srv_status;
} Noti_SignalStrength_Extension;

typedef struct {
  struct nas_701A_ind_t01_s {
    int8 message_len;
    TOF_SignalStrength signal_strength;
    uint8 SignalStrength_Extension_valid;
    Noti_SignalStrength_Extension Service_Status;    
  } t01;

  boolean t01_valid;
}nas_701A_ind_s;

/*---------------------------------------------------------------------------
  (0x701B) QMI_NAS_IND_APN_CHANGED_MSG_ID
---------------------------------------------------------------------------*/
#define NAS_701B_IND_T01                     (0x01)

#define DS_EHRPD_SDM_APN_MAX_LEN 100

typedef struct {
  struct nas_701B_ind_t01_s {
    char   apn[DS_EHRPD_SDM_APN_MAX_LEN + 1];
  } t01;

  boolean t01_valid;
}nas_701B_ind_s;

#define NAS_7043_IND_T01                     (0x01)

typedef struct {
  struct nas_7043_ind_t01_s {
    uint8 sim_state;
  } t01;

  boolean t01_valid;
}nas_7043_ind_s;


/*---------------------------------------------------------------------------
 QMI_NAS_GET_IMS_REG_CONFIG
---------------------------------------------------------------------------*/
#define NAS_5571_RSP_T10        (0x10)

typedef struct nas_5571_rsp_s{
  struct nas_5571_rsp_t10_s
	{
    uint8 RegEventPacket;
  } t10;

  boolean t10_valid;
}nas_5571_rsp_s;

/*---------------------------------------------------------------------------
 QMI_NAS_SET_IMS_REG_CONFIG
---------------------------------------------------------------------------*/
#define NAS_5572_REQ_T10        (0x10)

typedef struct nas_5572_req_s{
  struct nas_5572_req_t10_s
	{
		uint8 RegEventPacket;
  } t10;

  boolean t10_valid;
}nas_5572_req_s;

/*---------------------------------------------------------------------------
 QMI_NAS_GET_IMS_VOIP_CONFIG
---------------------------------------------------------------------------*/
#define NAS_5574_RSP_T10        (0x10)

typedef struct {
  struct nas_5574_rsp_t10_s
  {
    uint16 voipConfigExpires;
  } t10;

  boolean t10_valid;
}nas_5574_rsp_s;

/*---------------------------------------------------------------------------
 QMI_NAS_SET_IMS_VOIP_CONFIG
---------------------------------------------------------------------------*/
#define NAS_5575_REQ_T10        (0x10)

typedef struct {
  struct nas_5575_req_t10_s {
    uint16 voipConfigExpires;
  } t10;

  boolean t10_valid;
}nas_5575_req_s;

//hongsg 20140821
/*---------------------------------------------------------------------------
 QMI_NAS_GET_IMS_USER_AGENT
---------------------------------------------------------------------------*/
#define NAS_557A_RSP_T10        (0x10)

typedef struct {
  struct nas_557A_rsp_t10_s
  {
    char UserAgent[1024];
  } t10;

  boolean t10_valid;
} nas_557A_rsp_s;

/*---------------------------------------------------------------------------
 QMI_NAS_SET_IMS_USER_AGENT
---------------------------------------------------------------------------*/
#define NAS_557B_REQ_T10        (0x10)

typedef struct {
  struct nas_557B_req_t10_s {
    char UserAgent[1024];
  } t10;

  boolean t10_valid;
} nas_557B_req_s;


/* Distinguishes indication message types */

typedef enum
{
  QMI_NAS_SRVC_INVALID_IND_MSG,
  QMI_NAS_SRVC_EVENT_REPORT_IND_MSG,
  QMI_NAS_NETWORK_TIME_INFO_IND_MSG,
  QMI_NAS_SRVC_SERVING_SYSTEM_IND_MSG,
  QMI_NAS_SYSTEM_SELECTION_PREFERENCE_IND_MSG,
  QMI_NAS_SYS_INFO_IND_MSG,
  QMI_NAS_SIG_INFO_IND_MSG,
  QMI_NAS_NETWORK_REJECT_IND_MSG,
  QMI_NAS_CURRENT_PLMN_NAME_IND_MSG,
  QMI_NAS_OTA_EVENT_LOG_SAVE_IND_MSG,
  QMI_NAS_SIGNAL_STRENGTH_IND_MSG,
  QMI_NAS_APN_CHANGED_IND_MSG
  /* To be filled in in future release */
} qmi_nas_indication_id_type;

/* Async notification reporting structure */
typedef union
{
  nas_0002_ind_s nas_0002_ind;
  nas_0024_ind_s nas_0024_ind;
  nas_system_selection_preference_ind_msg_v01 nas_0034_ind;
  nas_004C_ind_s nas_004C_ind;
  nas_sys_info_ind_msg_v01 nas_004E_ind;
  nas_0051_ind_s nas_0051_ind;
  nas_0061_ind_s nas_0061_ind;
  nas_0068_ind_s nas_0068_ind;
  nas_5573_ind_s nas_5573_ind;  
  nas_701A_ind_s nas_701A_ind;
  nas_701B_ind_s nas_701B_ind;
  nas_7043_ind_s nas_7043_ind;	
} qmi_nas_indication_data_type;


typedef void (*qmi_nas_indication_hdlr_type)
( 
  int                           user_handle,
  qmi_service_id_type           service_id,
  void                          *user_data,
  qmi_nas_indication_id_type    ind_id,
  qmi_nas_indication_data_type  *ind_data
);

//BKS_20131107 - start
//--> RIL_REQUEST_HK_GET_CDMA_DEBUG_INFO
/*---------------------------------------------------------------------------
  (0x5562) QMI_NAS_GET_CDMA_DEBUG_SCREEN_INFO_MSG_ID
---------------------------------------------------------------------------*/
#define QMI_HDR_SECTOR_ID_SIZE               16
#define QMI_1X_PSC_SIZE                      3

#define NAS_5562_RSP_T10                     0x10
#define NAS_5562_RSP_T11                     0x11
#define NAS_5562_RSP_T12                     0x12
#define NAS_5562_RSP_T13                     0x13

typedef struct {
  /* command parameters */
  struct nas_5562_rsp_t10_s {
    uint16 reg_zone;
    uint16 packet_zone;
    uint8  bs_p_rev;
    uint8  p_rev_in_use;
    uint8  is_registered;
    uint8  ccs_supported;
    uint16 uz_id;
    uint8  srch_win_n;
    int32 base_lat;
    int32 base_long;
    uint16 base_id;
    
    uint8  reject_srv_domain;
    uint8  reject_cause;
    
    uint8  active_status;
    uint8  service_option;
    uint8  slot_cycle_index;
    uint8  cdma_lock_mode;
    
    uint8  curr_nam;
    uint8  ps_data_suspend;
    uint8  packet_state;
  } t10;

  /* 1x related parameters */
  struct nas_5562_rsp_t11_s {
    uint8  service_status;
    uint16 roam_status;
    uint16 sid;
    uint16 nid;
    uint16 mcc;
    uint8  imsi_11_12;
    uint16 active_band;
    uint16 active_channel;
    uint16 rssi;
    uint16 ecio;
    uint16 tx_pwr;
    uint16 tx_adj;

    struct nas_5562_rsp_t11_psc_s {
      uint16 psc; // Active SET
      uint16 ecio; // ASET ECIO
    } psc[QMI_1X_PSC_SIZE];

    uint16 frame_err_rate;
  } t11;

  /* Evdo related parameters */
  struct nas_5562_rsp_t12_s {
    uint8  hdr_service_status;
    uint16 hdr_roam_status;
    uint16 hdr_sid;
    uint16 hdr_nid;
    uint16 hdr_mcc;
    uint8  hdr_imsi_11_12;
    uint16 hybrid_active_band;
    uint16 hybrid_active_channel;
    uint16 hdr_rssi;
    uint16 hdr_ecio;
    uint8  hdr_sinr;
    uint16 hdr_packet_err_rate;
    /* 20120229, add more items */
    uint16 serving_pn;
    uint8  prot_state;
    uint8  hdr_session_state;
    uint16 uati24;
    uint8  color_code;
    uint8  uati_subnet_mask;
    uint8  sector_color_code;
    uint16 attempts_count;
    uint16 success_count;
    uint16 failure_count;
    uint16 dl_rate;
    uint16 ul_rate;
    uint8  fcp_enabled;
    uint8  sector_id[QMI_HDR_SECTOR_ID_SIZE];
  } t12;

  /* command more... */
  struct nas_5562_rsp_t13_s {
    uint8  rf_mode;
    uint8  ac_state;
  } t13;

  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
}nas_5562_rsp_s;
//<-- RIL_REQUEST_HK_GET_CDMA_DEBUG_INFO
//BKS_20131107 - end


// --> RIL_REQUEST_EVDO_REV
#define HDR_REV0_PROTOCOLS_ONLY   0
#define HDR_REVA_PROTOCOLS_WITH_MFPA  1
#define HDR_REVA_PROTOCOLS_WITH_EHRPD   4

/*---------------------------------------------------------------------------
 QMI_NAS_GET_EVDO_REV
---------------------------------------------------------------------------*/
#define NAS_7001_RSP_T10        (0x10)

typedef struct 
{
  struct nas_7001_rsp_t10_s
  {
    uint8 evdo_rev;
  } t10;

  boolean t10_valid;
}nas_7001_rsp_s;

/*---------------------------------------------------------------------------
 QMI_NAS_SET_EVDO_REV
---------------------------------------------------------------------------*/
#define NAS_7002_REQ_T10        (0x10)

typedef struct  {
  struct nas_7002_req_t10_s {
    uint8 evdo_rev;
  } t10;

  boolean t10_valid;
}nas_7002_req_s;
// <-- RIL_REQUEST_EVDO_REV
// --> RIL_REQUEST_APN_SETTING
#define QMI_NAS_MAX_APN_STR_SIZE              (100 + 1) // Max APN size should be 100

//--> RIL_REQUEST_HK_SET_CDMA_SYS_SEL_PREF //BKS_20140307 add
/*---------------------------------------------------------------------------
  (0x7003) QMI_NAS_SET_SYSTEM_SELECTION_MSG_ID
---------------------------------------------------------------------------*/
#define NAS_7003_REQ_T10        (0x10)

typedef struct {
  struct nas_7003_req_t10_s {
    uint16 sys_sel; 
  } t10;

  boolean t10_valid;
}nas_7003_req_s;
//<-- RIL_REQUEST_HK_SET_CDMA_SYS_SEL_PREF

//--> RIL_REQUEST_HK_GET_CDMA_SYS_SEL_PREF
/*---------------------------------------------------------------------------
  (0x7004) QMI_NAS_GET_SYSTEM_SELECTION_MSG_ID
---------------------------------------------------------------------------*/
#define NAS_7004_RSP_T10        (0x10)

typedef struct{
  struct nas_7004_rsp_t10_s{
    uint16 sys_sel;
  } t10;

  boolean t10_valid;
}nas_7004_rsp_s;
//<-- RIL_REQUEST_HK_GET_CDMA_SYS_SEL_PREF

/*---------------------------------------------------------------------------
 QMI_NAS_SET_APN_INFO
---------------------------------------------------------------------------*/
#define NAS_7005_RSQ_T11        (0x11)
#define NAS_7005_RSQ_T12        (0x12)
#define NAS_7005_RSQ_T13        (0x13)
#define NAS_7005_RSQ_T14        (0x14)
#define NAS_7005_RSQ_T15        (0x15)
#define NAS_7005_RSQ_T16        (0x16)
#define NAS_7005_RSQ_T17        (0x17)
#define NAS_7005_RSQ_T18        (0x18)
#define NAS_7005_RSQ_T19        (0x19)

typedef struct 
{
  struct nas_7005_req_t11_s {  	
	uint16 profile_num; 
	uint16 class_id;
  } t11;
  
  struct nas_7005_req_t12_s {  	
	uint16 profile_num; 
	char apn_name[QMI_NAS_MAX_APN_STR_SIZE];
  } t12;

  struct nas_7005_req_t13_s {
	uint16 profile_num; 
	uint16 iptype;
  } t13;
  
  struct nas_7005_req_t14_s {
	uint16 profile_num; 
	uint16 diabled_flag;
  } t14;
  
  struct nas_7005_req_t15_s {
	uint16 profile_num; 
	uint32 inactivityT;
  } t15;
 
  struct nas_7005_req_t16_s {
  uint16 profile_num; 
  uint16 bearer;
  } t16;

  struct nas_7005_req_t17_s {
	uint16 profile_num; 
	uint16 max_conn;
  } t17;
  
  struct nas_7005_req_t18_s {
	uint16 profile_num; 
	uint16 max_conn_t;
  } t18;
 
  struct nas_7005_req_t19_s {
  uint16 profile_num; 
  uint16 wait_time;
  } t19;

  boolean t11_valid;   
  boolean t12_valid;   
  boolean t13_valid; 
  boolean t14_valid;  
  boolean t15_valid; 
  boolean t16_valid;
  boolean t17_valid;
  boolean t18_valid;  
  boolean t19_valid;
}nas_7005_req_s;


/*---------------------------------------------------------------------------
 QMI_NAS_GET_APN_INFO
---------------------------------------------------------------------------*/
#define NAS_7006_REQ_T10        (0x10)
#define NAS_7006_REQ_T11        (0x11)
#define NAS_7006_RSP_T11        (0x11)
#define NAS_7006_RSP_T12        (0x12)
#define NAS_7006_RSP_T13        (0x13)
#define NAS_7006_RSP_T14        (0x14)
#define NAS_7006_RSP_T15        (0x15)
#define NAS_7006_RSP_T16        (0x16)
#define NAS_7006_RSP_T17        (0x17)
#define NAS_7006_RSP_T18        (0x18)
#define NAS_7006_RSP_T19        (0x19)

typedef struct 
{
  struct nas_7006_req_t10_s {  	
	uint8 info_mask; 
    uint8 profile_num;
  } t10;
  struct nas_7006_req_t11_s {  	
	uint8 sdm_ack;
  } t11;
  
  boolean t10_valid;   
  boolean t11_valid;   
}nas_7006_req_s;


typedef struct 
{
  struct nas_7006_rsp_t11_s{  	
    uint8 classid;
  } t11;
 
  struct nas_7006_rsp_t12_s{
    char apn_name[QMI_NAS_MAX_APN_STR_SIZE];
  } t12;
  
  struct nas_7006_rsp_t13_s{
	uint8 iptype;
  } t13;

  struct nas_7006_rsp_t14_s{
    uint8 enabled;
  } t14;
  
  struct nas_7006_rsp_t15_s{
    uint32 inactivityT;
  } t15;
  
  struct nas_7006_rsp_t16_s{
	uint8 bearer;
  } t16;

  struct nas_7006_rsp_t17_s{
    uint16 max_conn;
  } t17;
  
  struct nas_7006_rsp_t18_s{
    uint16 max_conn_t;
  } t18;
  
  struct nas_7006_rsp_t19_s{
	uint16 wait_time;
  } t19;

  boolean t11_valid;  
  boolean t12_valid;
  boolean t13_valid;
  boolean t14_valid;
  boolean t15_valid;  
  boolean t16_valid;
  boolean t17_valid;
  boolean t18_valid;  
  boolean t19_valid;
}nas_7006_rsp_s;
//<-- RIL_REQUEST_APN_SETTING

// --> RIL_REQUEST_VZW_IMS_SETTING
#define VZW_IMS_SETTING   0
#define ALU_IOT_SETTING  1
#define MD8475A_SETTING   2

/*---------------------------------------------------------------------------
 QMI_NAS_GET_VZW_IMS_SETTING
---------------------------------------------------------------------------*/
#define NAS_7009_RSP_T10        (0x10)

typedef struct
{
  struct nas_7009_rsp_t10_s
  {
    uint8 ims_setting;
  } t10;

  boolean t10_valid;
}nas_7009_rsp_s;

/*---------------------------------------------------------------------------
 QMI_NAS_SET_VZW_IMS_SETTING
---------------------------------------------------------------------------*/
#define NAS_7010_REQ_T10        (0x10)

typedef struct
{
  struct nas_7010_req_t10_s {
    uint8 ims_setting;
  } t10;

  boolean t10_valid;
}nas_7010_req_s;
// <-- RIL_REQUEST_VZW_IMS_SETTING

//--> RIL_REQUEST_EHRPD_IPV6
/*---------------------------------------------------------------------------
 QMI_NAS_GET_EHPRD_IPV6_ENABLED
---------------------------------------------------------------------------*/
#define NAS_7007_RSP_T10        (0x10)

typedef struct 
{
  struct nas_7007_rsp_t10_s
  {
    uint8 ipv6_enabled;
  } t10;

  boolean t10_valid;
}nas_7007_rsp_s;

/*---------------------------------------------------------------------------
 QMI_NAS_SET_EHPRD_IPV6_ENABLED
---------------------------------------------------------------------------*/
#define NAS_7008_REQ_T10        (0x10)

typedef struct  
{
  struct nas_7008_req_t10_s {
    uint8 ipv6_enabled;
  } t10;

  boolean t10_valid;
}nas_7008_req_s;
//<-- RIL_REQUEST_EHRPD_IPV6
//--> RIL_REQUEST_T3402
/*---------------------------------------------------------------------------
 QMI_NAS_GET_T3402
---------------------------------------------------------------------------*/
#define NAS_7011_RSP_T10        (0x10)

typedef struct 
{
  struct nas_7011_rsp_t10_s
  {
    uint32 timer;
  } t10;

  boolean t10_valid;
}nas_7011_rsp_s;

/*---------------------------------------------------------------------------
 QMI_NAS_SET_T3402
---------------------------------------------------------------------------*/
#define NAS_7012_REQ_T10        (0x10)

typedef struct 
{
  struct nas_7012_req_t10_s {
    uint32 timer;
  } t10;

  boolean t10_valid;
}nas_7012_req_s;
//<-- RIL_REQUEST_T3402
//--> RIL_REQUEST_HK_GET_IMS_AUTH
#define NAS_5567_RSP_T10        (0x10)

typedef struct {
  struct nas_5567_rsp_t10_s
  {
    uint8 AuthScheme;
  } t10;

  boolean t10_valid;
}nas_5567_rsp_s;
//<-- RIL_REQUEST_HK_GET_IMS_AUTH

//--> RIL_REQUEST_HK_SET_IMS_AUTH
#define NAS_5568_REQ_T10        (0x10)

typedef struct {
  struct nas_5568_req_t10_s {
    uint8 AuthScheme;
  } t10;

  boolean t10_valid;
}nas_5568_req_s;
//<-- RIL_REQUEST_HK_SET_IMS_AUTH

#define NAS_701CD_T10        (0x10)
#define NAS_701CD_T11        (0x11)
#define NAS_701CD_T12        (0x12)
#define NAS_701CD_T13        (0x13)
#define NAS_701CD_T14        (0x14)
#define NAS_701CD_T15        (0x15)
#define NAS_701CD_T16        (0x16)
#define NAS_701CD_T17        (0x17)
#define NAS_701CD_T18        (0x18)
#define NAS_701CD_T19        (0x19)
#define NAS_701CD_T1A        (0x1A)
#define NAS_701CD_T1B        (0x1B)
#define NAS_701CD_T1C        (0x1C)
#define NAS_701CD_T1D        (0x1D)
#define NAS_701CD_T1E        (0x1E)
#define NAS_701CD_T1F        (0x1F)
#define NAS_701CD_T20        (0x20)
#define NAS_701CD_T21        (0x21)

typedef struct
{  
  struct nas_701C_rsp_t10_s  
   {	
	  uint32 qipcall_codec_mode_set;
   } t10;
  struct nas_701C_rsp_t11_s  
   {	
	  uint32 qipcall_codec_mode_set_amr_wb;
   } t11;
  struct nas_701C_rsp_t12_s  
   {	
	  uint32 Publish_timer;
   } t12;
  struct nas_701C_rsp_t13_s  
   {	
	 uint32 Publish_extended_timer;
   } t13;
  struct nas_701C_rsp_t14_s  
   {	
	 uint32 Capabilites_cache_expiration;
   } t14;
  struct nas_701C_rsp_t15_s  
   {	
	 uint32 Availability_cache_expiration;
   } t15;
  struct nas_701C_rsp_t16_s  
   {	
	 uint32 Capability_poll_interval;
   } t16;
  struct nas_701C_rsp_t17_s  
   {	
	 uint32 Source_throttle_publish_timer;
   } t17;
  struct nas_701C_rsp_t18_s  
   {	
	 uint32 Max_number_of_entries_in_request;
   } t18;
  struct nas_701C_rsp_t19_s  
   {	
	 uint32 Capability_poll_list_subscription_expiry_timer;
   } t19;
  struct nas_701C_rsp_t1A_s  
   {	
	 uint8 Presence_gzip;
   } t1A;  
  struct nas_701C_rsp_t1B_s  
   {	
	 uint16 voipConfigExpires;
   } t1B;    
  struct nas_701C_rsp_t1C_s  
   {	
	  uint16 voipMinSessionExpires;
   } t1C;    
  struct nas_701C_rsp_t1D_s  
   {	
	  uint32 Timer_VZW;
   } t1D;      
  struct nas_701C_rsp_t1E_s  
   {	
	  uint16 Tdelay;
   } t1E;       
  struct nas_701C_rsp_t1F_s  
   {	
	  uint8 voipSilentRedialEnabled;
   } t1F;       
  struct nas_701C_rsp_t20_s  
   {	
	    uint8 volte_disable;
   } t20;        
      
  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
  boolean t14_valid;
  boolean t15_valid;
  boolean t16_valid;
  boolean t17_valid;
  boolean t18_valid;
  boolean t19_valid;
  boolean t1A_valid;
  boolean t1B_valid;
  boolean t1C_valid;
  boolean t1D_valid;
  boolean t1E_valid;
  boolean t1F_valid;
  boolean t20_valid;
}nas_701C_rsp_s;

typedef struct
{  
  struct nas_701D_req_t10_s  
   {	
	  uint32 qipcall_codec_mode_set;
   } t10;
  struct nas_701D_req_t11_s  
   {	
	  uint32 qipcall_codec_mode_set_amr_wb;
   } t11;
  struct nas_701D_req_t12_s  
   {	
	  uint32 Publish_timer;
   } t12;
  struct nas_701D_req_t13_s  
   {	
	 uint32 Publish_extended_timer;
   } t13;
  struct nas_701D_req_t14_s  
   {	
	 uint32 Capabilites_cache_expiration;
   } t14;
  struct nas_701D_req_t15_s  
   {	
	 uint32 Availability_cache_expiration;
   } t15;
  struct nas_701D_req_t16_s  
   {	
	 uint32 Capability_poll_interval;
   } t16;
  struct nas_701D_req_t17_s  
   {	
	 uint32 Source_throttle_publish_timer;
   } t17;
  struct nas_701D_req_t18_s  
   {	
	 uint32 Max_number_of_entries_in_request;
   } t18;
  struct nas_701D_req_t19_s  
   {	
	 uint32 Capability_poll_list_subscription_expiry_timer;
   } t19;
  struct nas_701D_req_t1A_s  
   {	
	 uint8 Presence_gzip;
   } t1A;  
  struct nas_701D_req_t1B_s  
   {	
	 uint16 voipConfigExpires;
   } t1B;    
  struct nas_701D_req_t1C_s  
   {	
	  uint16 voipMinSessionExpires;
   } t1C;    
  struct nas_701D_req_t1D_s  
   {	
	  uint32 Timer_VZW;
   } t1D;      
  struct nas_701D_req_t1E_s  
   {	
	  uint16 Tdelay;
   } t1E;       
  struct nas_701D_req_t1F_s  
   {	
	  uint8 voipSilentRedialEnabled;
   } t1F;       
  struct nas_701D_req_t20_s  
   {	
	    uint8 volte_disable;
   } t20;        
  struct nas_701D_req_t21_s  
   {	
	    uint8 vzw_config_init;
   } t21;   
  
  boolean t10_valid;
  boolean t11_valid;
  boolean t12_valid;
  boolean t13_valid;
  boolean t14_valid;
  boolean t15_valid;
  boolean t16_valid;
  boolean t17_valid;
  boolean t18_valid;
  boolean t19_valid;
  boolean t1A_valid;
  boolean t1B_valid;
  boolean t1C_valid;
  boolean t1D_valid;
  boolean t1E_valid;
  boolean t1F_valid;
  boolean t20_valid;
  boolean t21_valid;  
}nas_701D_req_s;

#define OTADM_CMD_MAX 255

#define NAS_701F_T10        (0x10)

struct nas_701F_req_s
{  
  struct nas_701F_req_t10_s  
   {	
	  char cmd[OTADM_CMD_MAX];
   } t10;   
  
  boolean t10_valid;
};

#if  defined(FEATURE_LGIT_OTADM_FOTA_FUMO_VZW)

#define NAS_7030_REQ_T10        (0x10)
struct nas_7030_req_p_s {	  
	struct nas_7030_req_t10_p_s {		
		int wap_push_num;  	 
	} t10;	  	
};		

struct nas_7030_req_s {	 
	struct nas_7030_req_t10_s {		
		int wap_push_num;  	  
	} t10;		

	boolean t10_valid;	
};	
#endif

#pragma pack()


/*===========================================================================
  FUNCTION  tof_tof_qmi_nas_srvc_init_client
===========================================================================*/
/*!
@brief 
  This function is called to initialize the NAS service.  This function
  must be called prior to calling any other NAS service functions.
  For the time being, the indication handler callback and user data
  should be set to NULL until this is implemented.  Also note that this
  function may be called multiple times to allow for multiple, independent
  clients.   
  
@return 
  0 if abort operation was sucessful, < 0 if not.  If return code is 
  QMI_INTERNAL_ERR, then the qmi_err_code will be valid and will 
  indicate which QMI error occurred.

@note

  - Dependencies
    - qmi_connection_init() must be called for the associated port first.

  - Side Effects
    - Talks to modem processor
*/    
/*=========================================================================*/
EXTERN qmi_client_handle_type
tof_tof_qmi_nas_srvc_init_client
(
   const char                   *dev_id,
  qmi_nas_indication_hdlr_type  user_ind_msg_hdlr,
  void                          *user_ind_msg_hdlr_user_data,
  int                           *qmi_err_code
);



/*===========================================================================
  FUNCTION  tof_qmi_nas_srvc_release_client
===========================================================================*/
/*!
@brief 
  This function is called to release a client created by the 
  tof_qmi_nas_srvc_init_client() function.  This function should be called
  for any client created when terminating a client process, especially
  if the modem processor is not reset.  The modem side QMI server has 
  a limited number of clients that it will allocate, and if they are not
  released, we will run out.  
  
@return 
  0 if operation was sucessful, < 0 if not.  If return code is 
  QMI_INTERNAL_ERR, then the qmi_err_code will be valid and will 
  indicate which QMI error occurred.

@note

  - Dependencies
    - qmi_connection_init() must be called for the associated port first.

  - Side Effects
    - Talks to modem processor
*/    
/*=========================================================================*/
EXTERN int 
tof_qmi_nas_srvc_release_client
(
  int      user_handle,
  int      *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_set_event_report_state
===========================================================================*/
/*!
@brief 
  Set the NAS event reporting state
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
EXTERN int
qmi_nas_set_event_report_state
(
  int                               client_handle,
  nas_0002_req_s             *nas_0002_req,
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_config_sig_info2
===========================================================================*/
/*!
@brief 
  Sets the signal strength reporting thresholds.
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
EXTERN int
qmi_nas_config_sig_info2
(
  int                               client_handle,
  nas_006C_req_s             *nas_006C_req,
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_set_pref_network_auto
===========================================================================*/
/*!
@brief 
    Sets the list of preferred network providers in the SIM/UIM to the list
    provided in the request
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
EXTERN int
qmi_nas_set_network_sel_auto
(
  int                               client_handle,
  nas_0033_req_s             *nas_0033_req,
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_get_serving_system
===========================================================================*/
/*!
@brief 
  This message queries for information on the system that is currently 
  providing service.
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
EXTERN int
qmi_nas_get_serving_system
(
  int                               client_handle,
  nas_0024_rsp_s           *nas_0024_rsp,
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_get_signal_strength
===========================================================================*/
/*!
@brief 
  This message queries for information on the system that is current signal strength measured by the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
EXTERN int
qmi_nas_get_signal_strength
(
  int                               client_handle,
  nas_0020_rsp_s				*nas_0020_rsp,
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_get_pref_network
===========================================================================*/
/*!
@brief 
  Get the prefered network of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
EXTERN int
qmi_nas_get_pref_network
(
  int                               client_handle,
  nas_0034_rsp_s             *nas_0034_rsp, 
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_get_pref_network_type
===========================================================================*/
/*!
@brief 
  Get the prefered network of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
EXTERN int
qmi_nas_get_pref_network_type
(
  int                               client_handle,
  nas_555A_rsp_s             *nas_555A_rsp,
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  get_mode_pref_to_ril
===========================================================================*/
/*!
@brief 
  Convert prefered netowrk mode
     
@return 

@note

  - Side Effects
    - None
*/    
/*=========================================================================*/
uint16
get_mode_pref_to_ril
(
  uint16                               pref_net,
  uint32                               gw_acq_order_pref,
  uint64                               lte_band_pref
);

/*===========================================================================
  FUNCTION  qmi_nas_set_pref_network_type
===========================================================================*/
/*!
@brief 
  Set the prefered network of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
EXTERN int
qmi_nas_set_pref_network_type
(
  int                               client_handle,
  nas_555B_req_s             *nas_555B_req,
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  set_mode_pref_to_ril
===========================================================================*/
/*!
@brief 
  Convert prefered netowrk mode
     
@return 

@note

  - Side Effects
    - None
*/    
/*=========================================================================*/
uint16
set_mode_pref_to_ril
(
  uint16                               mode_pref
);

/*===========================================================================
  FUNCTION  qmi_nas_get_pref_mode_type
===========================================================================*/
/*!
@brief 
  Get the prefered mode of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
EXTERN int
qmi_nas_get_pref_mode_type
(
  int                               client_handle,
  nas_557D_rsp_s             *nas_557D_rsp,
  int                               *qmi_err_code
);


/*===========================================================================
  FUNCTION  qmi_nas_set_pref_network_type
===========================================================================*/
/*!
@brief 
  Set the prefered network of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
EXTERN int
qmi_nas_set_pref_mode_type
(
  int                               client_handle,
  nas_557C_req_s             *nas_557C_req,
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_get_operator
===========================================================================*/
/*!
@brief 
  Returns a list of HOME network providers.
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
EXTERN int
qmi_nas_get_operator
(
  int                               client_handle,
  nas_0025_rsp_s             *nas_0025_rsp, 
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_initiate_ps_attach_detach
===========================================================================*/
/*!
@brief 
  This function is used to initiate a PS domain attach or detach.
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Attach or Detach is initiated
*/    
/*=========================================================================*/
EXTERN int
qmi_nas_initiate_ps_attach_detach
(
  int                         client_handle,
  qmi_nas_ps_attach_state     attach_detach,
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_indication_register
===========================================================================*/
/*!
@brief 
  Set the NAS indication registration state for specified control point.
     
  
@return 

@note

  - Dependencies
    - qmi_qos_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
EXTERN int
qmi_nas_indication_register
(
  int                                     client_handle,
  nas_0003_req_s                  *nas_0003_req,
  int                                    *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_get_sys_info
===========================================================================*/
/*!
@brief 
  Queries information regarding the system that currently provides service.
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_get_sys_info
(
  int                               client_handle,
  nas_004D_rsp_s             *nas_004D_rsp, 
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_ind_network_reject
===========================================================================*/
/*!
@brief 
  Queries information regarding the network reject information.
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_ind_network_reject
(
  unsigned char                     *rx_buf,
  int                               rx_buf_len,
  nas_0068_ind_s            *nas_0068_ind
);

/*===========================================================================
  FUNCTION  qmi_nas_get_sig_info
===========================================================================*/
/*!
@brief 
  Queries information regarding the signal strength.
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
EXTERN int
qmi_nas_get_sig_info
(
  int                               client_handle,
  nas_004F_rsp_s				*nas_004F_rsp,
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_config_sig_info_req
===========================================================================*/
/*!
@brief 
  Sets the signal strength reporting thresholds. (Deprecated)
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_config_sig_info_req
(
  int                               client_handle,
  nas_0050_req_s             *nas_0050_req, 
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_get_protocol_info
===========================================================================*/
/*!
@brief 
  Get the Protocol Information of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_protocol_info
(
  int                               client_handle,
  nas_5556_rsp_s             *nas_5556_rsp, 
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_set_protocol_info
===========================================================================*/
/*!
@brief 
    Sets the list of protocol information
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_protocol_info
(
  int                               client_handle,
  nas_5557_req_s             *nas_5557_req,
  int                               *qmi_err_code
);


//20170215 yjoh add for cell info
int
qmi_nas_get_cell_info
(
  int                              											 client_handle,
  nas_get_cell_location_info_resp_msg_v01 			*cell_info_rsp, 
  int                               											*qmi_err_code
);
/*===========================================================================
  FUNCTION  qmi_nas_get_ims_enable
===========================================================================*/
/*!
@brief 
  Get the IMS enable Information of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_ims_enable
(
  int                               client_handle,
  nas_555E_rsp_s             *nas_555E_rsp, 
  int                               *qmi_err_code
);


/*===========================================================================
  FUNCTION  qmi_nas_get_ecall_enable
===========================================================================*/
/*!
@brief 
  Get the ECALL ENABLE
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/



int
	qmi_nas_get_ecall_enable
(
  int                               client_handle,
  nas_ECALLEN_rsp_s             *nas_ECALLEN_rsp, 
  int                               *qmi_err_code
);


/*===========================================================================
  FUNCTION  qmi_nas_get_modem_value
===========================================================================*/
/*!
@brief 
  Get the MODEM value
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/

int
	qmi_nas_get_modem_value
(
  int                               client_handle,
  nas_GETVAL_rsp_s             *nas_GETVAL_rsp,
  int                               *qmi_err_code,
  int getvalcmd
);

/*===========================================================================
  FUNCTION  qmi_nas_query_available_networks
===========================================================================*/
/*!
@brief 
  Get/Start available network search result (async operation)
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/

int
	qmi_nas_query_available_networks
(
  int                               client_handle,
  int                               *qmi_err_code
);

void qmi_nas_perform_network_scan_command_cb
(
  void*              user_handle,
  unsigned int                 msg_id,
  void                         *resp_c_struct,
  unsigned int                 resp_c_struct_len,
  void                         *resp_cb_data,
  qmi_client_error_type        transp_err
);



/*===========================================================================
  FUNCTION  qmi_nas_set_ims_enable
===========================================================================*/
/*!
@brief 
    Sets the list of ims enable information
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_ims_enable
(
  int                               client_handle,
  nas_555F_req_s             *nas_555F_req,
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_get_ims_pdn_enable
===========================================================================*/
/*!
@brief 
  Get the IMS PDN enable Information of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_ims_pdn_enable
(
  int                               client_handle,
  nas_5560_rsp_s             *nas_5560_rsp, 
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_set_ims_pdn_enable
===========================================================================*/
/*!
@brief 
    Sets the list of ims pdn enable information
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_ims_pdn_enable
(
  int                               client_handle,
  nas_5561_req_s             *nas_5561_req,
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_get_ims_user_config
===========================================================================*/
/*!
@brief 
  Get the IMS USER config Information of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_ims_user_config
(
  int                               client_handle,
  nas_5565_rsp_s             *nas_5565_rsp, 
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_set_ims_user_config
===========================================================================*/
/*!
@brief 
    Sets the list of IMS USER config information
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_ims_user_config
(
  int                               client_handle,
  nas_5566_req_s             *nas_5566_req,
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_get_ims_rcs_auto_config
===========================================================================*/
/*!
@brief 
  Get the IMS RCS Auto config Information of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_ims_rcs_auto_config
(
  int                               client_handle,
  nas_556B_rsp_s             *nas_556B_rsp, 
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_set_ims_rcs_auto_config
===========================================================================*/
/*!
@brief 
    Sets the list of IMS RCS Auto config information
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_ims_rcs_auto_config
(
  int                               client_handle,
  nas_556C_req_s             *nas_556C_req,
  int                               *qmi_err_code
);

//hongsg 20140729
/*===========================================================================
  FUNCTION  qmi_nas_get_ims_qipcall_config
===========================================================================*/
/*!
@brief 
  Get the IMS QIPCALL Config Information of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_ims_qipcall_config
(
  int                               client_handle,
  nas_556F_rsp_s             *nas_556F_rsp, 
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_set_ims_qipcall_config
===========================================================================*/
/*!
@brief 
    Sets the list of IMS QIPCALL Config information
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_ims_qipcall_config
(
  int                               client_handle,
  nas_5570_req_s             *nas_5570_req,
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_get_ims_reg_config
===========================================================================*/
/*!
@brief 
  Get the IMS Reg Config Information of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_ims_reg_config
(
  int                               client_handle,
  nas_5571_rsp_s          *nas_5571_rsp, 
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_set_ims_reg_config
===========================================================================*/
/*!
@brief 
    Sets the list of IMS Reg Config information
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_ims_reg_config
(
  int                               client_handle,
  nas_5572_req_s          *nas_5572_req,
  int                               *qmi_err_code
);


/*===========================================================================
  FUNCTION  qmi_nas_get_ims_voip_config
===========================================================================*/
/*!
@brief 
  Get the IMS VOIP Config Information of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_ims_voip_config
(
  int                               client_handle,
  nas_5574_rsp_s             *nas_5574_rsp, 
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_set_ims_voip_config
===========================================================================*/
/*!
@brief 
    Sets the list of IMS VOIP Config information
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_ims_voip_config
(
  int                               client_handle,
  nas_5575_req_s             *nas_5575_req,
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_get_network_time_info
===========================================================================*/
/*!
@brief 
  Get the network time info
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_network_time_info
(
  int                                          client_handle,
  nas_5558_rsp_s             *nas_5558_rsp, 
  int                                          *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_get_current_plmn_name_cache
===========================================================================*/
/*!
@brief 
  Get the cache plmn name info
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_current_plmn_name_cache
(
  int                               client_handle,
  nas_5559_rsp_s             *nas_5559_rsp, 
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_get_debug_screen_info
===========================================================================*/
/*!
@brief 
  Get the debug screen info
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_debug_screen_info
(
  int                               client_handle,
  nas_555C_rsp_s             *nas_555C_rsp, 
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_delete_stored_cell
===========================================================================*/
/*!
@brief 
  Delete stored cell list information (WCDMA)
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_delete_stored_cell
(
  int                               client_handle,
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_map_mode_pref_qmi_to_ril
===========================================================================*/
/*!
@brief 
  Map QMI mode pref to ril
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
uint16
qmi_nas_map_mode_pref_qmi_to_ril
(
  uint16 qmi_val,
  uint32 gw_acq_order_pref,
  uint64 lte_band_pref
);

/*===========================================================================
  FUNCTION  qmi_nas_map_mode_pref_ril_to_qmi
===========================================================================*/
/*!
@brief 
  Map ril mode pref to QMI
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
uint16
qmi_nas_map_mode_pref_ril_to_qmi
(
  uint16 mode_pref
);

/*===========================================================================
  FUNCTION  qmi_nas_request_set_preferred_network_type
===========================================================================*/
/*!
@brief 
    Handles RIL_REQUEST_SET_PREFERRED_NETWORK_TYPE.
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_request_set_preferred_network_type
(
  int                   client_handle,
  nas_0033_req_s        *nas_0033_req,
  int                   *qmi_err_code
);

//--> RIL_REQUEST_CDMA_SUBSCRIPTION
RIL_Errno qmi_nas_get_3gpp2_subscription_info
(
  int                        client_handle, 
  nas_003E_req_s*            nas_003E_req, 
  nas_003E_rsp_s*            nas_003E_rsp, 
  int*                       qmi_err_code
);
//<-- RIL_REQUEST_CDMA_SUBSCRIPTION

//--> RIL_REQUEST_REGISTRATION_STATE
/*===========================================================================
  FUNCTION  qmi_nas_get_sys_info_process
===========================================================================*/
int
qmi_nas_get_sys_info_process
(
  int                               client_handle,
  nas_get_sys_info_resp_msg_v01     *qmi_response, 
  int                               *qmi_err_code
);
//<-- RIL_REQUEST_REGISTRATION_STATE

//BKS_20131202 //--> RIL_REQUEST_OPERATOR
/*===========================================================================
  FUNCTION  qmi_nas_get_plmn_name
===========================================================================*/
int
qmi_nas_get_plmn_name
(
  int                               client_handle,
  nas_get_plmn_name_req_msg_v01     *qmi_request,
  nas_get_plmn_name_resp_msg_v01    *qmi_response, 
  int                               *qmi_err_code
);
//BKS_20131202 //<-- RIL_REQUEST_OPERATOR

//--> RIL_REQUEST_EXIT_EMERGENCY_CALLBACK_MODE
/*===========================================================================
  FUNCTION  qmi_nas_exit_emergency_callback_mode
===========================================================================*/
/*!
@brief 
    Exit Emergency Callback Mode
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_exit_emergency_callback_mode
(
  int                                             client_handle,
  nas_set_system_selection_preference_req_msg_v01 *qmi_request,
  int                                             *qmi_err_code
);
//<-- RIL_REQUEST_EXIT_EMERGENCY_CALLBACK_MODE

// --> RIL_REQUEST_EVDO_REV
int qmi_nas_get_evdo_rev
(
  int                               client_handle,
  nas_7001_rsp_s             *nas_7001_rsp, 
  int                               *qmi_err_code
);
int qmi_nas_set_evdo_rev
(
  int                               client_handle,
  nas_7002_req_s             *nas_7002_req, 
  int                               *qmi_err_code
);
// <-- RIL_REQUEST_EVDO_REV

//--> RIL_REQUEST_APN_SETTING
int
qmi_nas_get_sdm_apn_info
(
  int                               client_handle,  
  nas_7006_req_s             *qmi_request, 
  nas_7006_rsp_s             *qmi_response, 
  int                               *qmi_err_code
);

int
qmi_nas_set_sdm_apn_info

(
  int                               client_handle,
  nas_7005_req_s                    *qmi_req,
  int                               *qmi_err_code
);
//<-- RIL_REQUEST_APN_SETTING

//--> RIL_REQUEST_EHRPD_IPV6
uint8 qmi_nas_get_ehrpd_ipv6_enabled
(
  int                               client_handle,
  nas_7007_rsp_s                    *qmi_rsp, 
  int                               *qmi_err_code
);
uint8 qmi_nas_set_ehrpd_ipv6_enabled
(
  int                               client_handle,
  nas_7008_req_s             *qmi_req, 
  int                               *qmi_err_code
);
//<-- RIL_REQUEST_EHRPD_IPV6

//--> RIL_REQUEST_T3402
uint8 qmi_nas_get_t3402
(
  int                               client_handle,
  nas_7011_rsp_s                    *qmi_rsp, 
  int                               *qmi_err_code
);
uint8 qmi_nas_set_t3402
(
  int                               client_handle,
  nas_7012_req_s                    *qmi_req, 
  int                               *qmi_err_code
);
//<-- RIL_REQUEST_T3402

//--> RIL_REQUEST_HK_GET_IMS_AUTH
int qmi_nas_get_ims_sip_extended_config
(
  int                               client_handle,
  nas_5567_rsp_s             				*nas_5567_rsp, 
  int                               *qmi_err_code
);
// <-- RIL_REQUEST_HK_GET_IMS_AUTH

// --> RIL_REQUEST_HK_SET_IMS_AUTH
int qmi_nas_set_ims_sip_extended_config
(
  int                               client_handle,
  nas_5568_req_s             *nas_5568_req,
  int                               *qmi_err_code
);
//<-- RIL_REQUEST_HK_SET_IMS_AUTH

// --> RIL_REQUEST_VZW_IMS_SETTING
uint8 qmi_nas_get_vzw_ims_setting
(
  int                               client_handle,
  nas_7009_rsp_s             *nas_7009_rsp, 
  int                               *qmi_err_code
);
uint8 qmi_nas_set_vzw_ims_setting
(
  int                               client_handle,
  nas_7010_req_s             *nas_7010_req, 
  int                               *qmi_err_code
);
// <-- RIL_REQUEST_VZW_IMS_SETTING

//-->RIL_REQUEST_HK_SET_CDMA_SYS_SEL_PREF
int
qmi_nas_set_system_selection
(
  int                               client_handle,
  nas_7003_req_s*  nas_7003_req,
  int*                           qmi_err_code
);

//-->RIL_REQUEST_HK_GET_CDMA_SYS_SEL_PREF
int
qmi_nas_get_system_selection
(
  int                               client_handle,
  nas_7004_rsp_s             *nas_7004_rsp, 
  int                               *qmi_err_code
);

//--> RIL_REQUEST_HK_USIM_ONCHIP
/*---------------------------------------------------------------------------
 QMI_NAS_CLEAR_MRU
---------------------------------------------------------------------------*/
uint8 qmi_nas_clear_mru
(
  int                               client_handle,
  int                               *qmi_err_code
);
//<-- RIL_REQUEST_HK_USIM_ONCHIP

int 
qmi_nas_get_sdm_dcmo_info
(
  int								client_handle,	
  nas_701C_rsp_s 			*qmi_response, 
  int								*qmi_err_code
);

int
qmi_nas_set_sdm_dcmo_info

(
  int                               client_handle,
  nas_701D_req_s             *qmi_req,
  int                               *qmi_err_code
);
int qmi_nas_get_ims_test_mode
(
  int                               client_handle,
  nas_5563_rsp_s             *nas_5563_rsp, 
  int                               *qmi_err_code
);

int qmi_nas_set_ims_test_mode
(
  int                               client_handle,
  nas_5564_req_s             *nas_5564_req, 
  int                               *qmi_err_code
);

//hongsg 20140814
/*===========================================================================
  FUNCTION  qmi_nas_get_ims_user_agent
===========================================================================*/
/*!
@brief 
  Get the IMS User Agent Information of the device
     
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - None
*/    
/*=========================================================================*/
int
qmi_nas_get_ims_user_agent
(
  int                               client_handle,
  nas_557A_rsp_s             				*nas_557A_rsp, 
  int                               *qmi_err_code
);

/*===========================================================================
  FUNCTION  qmi_nas_set_ims_user_agent
===========================================================================*/
/*!
@brief 
    Sets the IMS User Agent information
     
  
@return 

@note

  - Dependencies
    - tof_qmi_nas_srvc_init_client() must be called before calling this.

  - Side Effects
    - Starts event reporting
*/    
/*=========================================================================*/
int
qmi_nas_set_ims_user_agent
(
  int                               client_handle,
  nas_557B_req_s             				*nas_557B_req,
  int                               *qmi_err_code
);

#if  defined(FEATURE_LGIT_OTADM_FOTA_FUMO_VZW)
//#error FEATURE_LGIT_OTADM_FOTA_FUMO_VZW
/*=========================================================================== 
FUNCTION  qmi_nas_set_fota_wap_push_test
===========================================================================*/
int qmi_nas_set_fota_wap_push_test
(  
	int                               client_handle,   
	struct nas_7030_req_s             *nas_7030_req,   
	int                               *qmi_err_code
	);
#endif

/*===========================================================================
  FUNCTION  qmi_nas_set_vzw_test_menu
===========================================================================*/
int
qmi_nas_set_vzw_test_menu
(
  int                               client_handle,
  struct nas_701F_req_s             *qmi_req,
  int                               *qmi_err_code
);

#ifdef __cplusplus
}
#endif

#endif   /*QMI_NAS_SRVC.H*/
