/******************************************************************************
  @file    qmi_nas.c
  @brief   The QMI TOF API

  DESCRIPTION

  INITIALIZATION AND SEQUENCING REQUIREMENTS

  ---------------------------------------------------------------------------
  Copyright (c) 2016 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/
#include <string.h>

#include <string.h>

//Qmi header
#include <qmi.h>
#include "qmi_platform.h"
#include "qmi_nas.h"

#include "qmi_nas_srvc.h"

#include "wmmdiag_packet_common.h"

#include "TOF_API.h"
#include "Debug_string.h"

/* Log assertion level message */
#define QCRIL_ASSERT( xx_exp )                                         \
  if ( !( xx_exp ) )                                                       \
  {                                                                        \
    MSG_FATAL( "*****ASSERTION FAILED*****",0,0,0); \
  } 
  
qmi_client_handle_type nas_client_handle = QMI_INVALID_CLIENT_HANDLE;

#define QMI_NAS_EVENT_REPORT_IND_MSG_ID                0x0002 
#define QMI_NAS_SERVING_SYSTEM_IND_MSG_ID              0x0024
#define QMI_NAS_SYSTEM_SELECTION_PREFERENCE_IND_MSG_ID 0x0034
#define QMI_NAS_NETWORK_TIME_IND_MSG_ID                0x004C
#define QMI_NAS_SYS_INFO_IND_MSG_ID                    0x004E
#define QMI_NAS_SIG_INFO_IND_MSG_ID                    0x0051
#define QMI_NAS_NETWORK_REJECT_IND_MSG_ID              0x0068
#define QMI_NAS_OTA_EVENT_LOG_SAVE_IND_MSG_ID          0x5573
#define QMI_NAS_SIGNAL_STRENGTH_IND_MSG_ID          0x701A
#define QMI_NAS_APN_CHANGED_IND_MSG_ID          0x701B

#define QMI_NAS_SKT_FREQUENCY_MAX_INDEX             6
#define QMI_NAS_KT_FREQUENCY_MAX_INDEX              4

#define NAS_NITZ_STR_BUF_MAX                        (30) //RIL_UNSOL_NITZ_TIME_RECEIVED

//BKS_20131202 //--> RIL_REQUEST_OPERATOR
#define NAS_MCC_MNC_MAX_SIZE     (4)
#define NAS_3GPP2_MCC_MAX_SIZE   (5)

#define NAS_MCC_WILDCARD_ENTRY 0x33
#define NAS_MNC_WILDCARD_ENTRY 0x37
#define NAS_MCC_MNC_WILDCARD_ENTRY 0xFF
#define NAS_PLACEHOLDER_MCC_STR "311" //any 3 digit entry would suffice
#define NAS_PLACEHOLDER_MNC_STR "480" //any 3 digit entry would suffice

//--> VOLTE_CALL_TYPE
#define NAS_VAL_ROAMING_ROAMING                       (0)
#define NAS_VAL_ROAMING_HOME                          (1)
#define NAS_VAL_ROAMING_FLASHING                      (2)
#define NAS_VAL_ROAMING_HOME_EX                       (64)

#define RIL_VAL_REG_UNKNOWN                                 4
#define RIL_VAL_REG_REGISTERED_HOME_NET                     1
#define RIL_VAL_REG_NOT_REGISTERED_SEARCHING                2
#define RIL_VAL_REG_NOT_REGISTERED_NOT_SEARCHING            0
#define RIL_VAL_REG_REGISTRATION_DENIED                     3
#define RIL_VAL_REG_REGISTERED_ROAMING                      5
#define RIL_VAL_REG_NOT_REGISTERED_SEARCHING_LTD_SRV        12
#define RIL_VAL_REG_REGISTRATION_DENIED_LTD_SRV             13

#define NAS_SYS_INFO_IS_EMPTY                           ( (uint32_t) 0 )
#define NAS_SYS_INFO_IS_3GPP                            ( (uint32_t) 1 << 0 )
#define NAS_SYS_INFO_IS_DATA                            ( (uint32_t) 1 << 1 )
#define NAS_SYS_INFO_IS_HDR                             ( (uint32_t) 1 << 2 )

#define NAS_SET_BIT( flag_variable, value)              flag_variable |= value;
#define NAS_IS_BIT_SET( flag_variable, value)           ((flag_variable & value)? TRUE: FALSE)
//<-- VOLTE_CALL_TYPE

wmm_registartion_status_type registration_status;
RIL_Operator_Info  operator_status;
uint8 network_selection_mode_status;

// 130718 jgkim, for debug information
qmi_nas_avg_rf_data_type avg_rsrp;  // FOR LTE

// 20130830 jgkim - skt frequency setting
int skt_wcdma_dl_freq[QMI_NAS_SKT_FREQUENCY_MAX_INDEX] = 
{
	10664, 10689, 10713, 10737, 10639, 10614
};

// 20130830 jgkim - kt frequency setting
int kt_wcdma_dl_freq[QMI_NAS_SKT_FREQUENCY_MAX_INDEX] = 
{
	10763, 10787, 10812, 10836
};

//--> RIL_REQUEST_REGISTRATION_STATE
struct nas_cached_info_type nas_cached_info;

typedef struct
{
  int is_reject_case;
  int reject_cause;
  int is_managed_roaming;
} qmi_nas_srv_status_convertion_extra_results_type;

typedef struct
{
  nas_3gpp2_srv_status_info_type_v01 * threegpp2_srv_status;
  nas_3gpp_srv_status_info_type_v01 * threegpp_srv_status;
  nas_common_sys_info_type_v01 * common_sys_info;
  nas_cdma_hdr_only_sys_info_type_v01 * cdma_hdr_only_sys_info;
  nas_cdma_only_sys_info_type_v01 * cdma_only_sys_info;
  nas_hdr_only_sys_info_type_v01 * hdr_only_sys_info;
  nas_3gpp_only_sys_info_type_v01 * threegpp_only_sys_info;
  nas_gsm_only_sys_info_type_v01 * gsm_only_sys_info;
  nas_wcdma_only_sys_info_type_v01 * wcdma_only_sys_info;
  nas_lte_only_sys_info_type_v01 * lte_only_sys_info;
  uint8 * voice_support_on_lte;
  qmi_nas_srv_status_convertion_extra_results_type * extra_results;
}nas_sys_info_helper_type;
//<-- RIL_REQUEST_REGISTRATION_STATE

//BKS_20131202 - start //--> RIL_REQUEST_OPERATOR
typedef struct
{
  char * mcc_str;                          /* Mobile Network Code */
  char * mnc_str;                          /* Mobile Country Code */
  uint16_t sid;                            /* System ID */
  uint16_t nid;                            /* Network ID */
  char *short_name_ptr;                /* Pointer to a null terminated string containing the network's short name */
  char *full_name_ptr;                 /* Pointer to a null terminated string containing the network's full name */
} qmi_ons_3gpp2_memory_entry_type;

static const qmi_ons_3gpp2_memory_entry_type qmi_ons_3gpp2_memory_list[] =  //3gpp2 static operator table - arranged in ascending order of MCC,
{                                                                                 //then MNC, then SID, then NID
  /***********************
   **** Test PLMN 1-1 ****
   ***********************/
  { "001",   "01", 1,   1,  "Test1-1", "Test PLMN 1-1" },
  { "310",   "00", 331,   1,  "Test1-2", "Test PLMN 1-2" },
  { "310",   "099", 331,   1,  "Test1-3", "Test PLMN 1-3" },
   
}; // qmi_ons_3gpp2_memory_list  
//BKS_20131202 - end //<-- RIL_REQUEST_OPERATOR

#ifdef FEATURE_LGIT_TIME
nitz_time_manager_s			g_nitz_time_manager;
#else
//--> RIL_UNSOL_NITZ_TIME_RECEIVED
void qmi_nas_network_time_ind_conv_qmi2ril(nas_004C_ind_s* ind_msg, char* ril_nitz_time_msg);
//<-- RIL_UNSOL_NITZ_TIME_RECEIVED
#endif

uint16 convert_mcc_ota_to_hpcd( uint16  ota_mcc);//BKS_20131129
void qmi_nas_decode_3gpp2_imsi_11_12(uint8 *decoded_imsi_11_12, uint16 encoded_imsi_11_12);

int _internal_TOF_GSM_PathLossCriteria_list_search(TOF_GSM_PathLossCriteria_list *list, int arfcn);
void _internal_parse_pathlosscriteria_itemadd(char* resstr, TOF_GSM_PathLossCriteria_list* criteria, int startindex, int numofitems);
boolean request_get_gsm_pathhloss_criteria(TOF_GSM_PathLossCriteria_list* criteria);



//--> VOLTE_CALL_TYPE
/*=========================================================================
  FUNCTION:  qmi_nas_get_nw_selection_mode

===========================================================================*/
RIL_Errno qmi_nas_get_nw_selection_mode(nas_net_sel_pref_enum_v01 * mode)
{
  RIL_Errno res = RIL_E_GENERIC_FAILURE;

  if ( mode )
  {
    if ( NAS_CACHE_IS_ENTRY_VALID(nas_cached_info.net_sel_pref) )
    {
      *mode = (nas_net_sel_pref_enum_v01)nas_cached_info.net_sel_pref;
      //MSG_HIGH("returning pref %d ", (int) *mode, 0, 0);
      res = RIL_E_SUCCESS;
    }
  }

  return res;
} /* qmi_nas_get_nw_selection_mode */

/*=========================================================================
  FUNCTION:  qmi_util_retrieve_srv_status

===========================================================================*/
nas_service_status_enum_type_v01 qmi_util_retrieve_srv_status(nas_sys_info_helper_type * nas_sys_info_helper, int is_3gpp)
{
  nas_service_status_enum_type_v01 nas_srv_status;

  nas_srv_status = NAS_SYS_SRV_STATUS_NO_SRV_V01;
  if( NULL != nas_sys_info_helper )
  {
    if( is_3gpp )
    {
      if( nas_sys_info_helper->threegpp_srv_status )
      {
        nas_srv_status = nas_sys_info_helper->threegpp_srv_status->srv_status;
      }
      else
      {
        MSG_HIGH("3gpp srv status info absent", 0, 0, 0);
      }
    }
    else
    {
      if( nas_sys_info_helper->threegpp2_srv_status )
      {
        nas_srv_status = nas_sys_info_helper->threegpp2_srv_status->srv_status;
      }
      else
      {
        MSG_HIGH("3gpp2 srv status info absent", 0, 0, 0);
      }
    }
  }
  else
  {
    MSG_ERROR("CHECK FAILED - nas_sys_info_helper is NULL", 0, 0, 0);
  }

  return nas_srv_status;
} /* qmi_util_retrieve_srv_status */

/*=========================================================================
  FUNCTION:  qmi_nas_util_convert_nas_srv_status_to_ril_reg_status

===========================================================================*/
int qmi_nas_util_convert_nas_srv_status_to_ril_reg_status
(
  uint32_t nas_sys_info_flag,
  nas_sys_info_helper_type * nas_sys_info_helper
)
{
  int res,is_data,is_3gpp,is_hdr;

  nas_net_sel_pref_enum_v01 nw_sel_pref;
  nas_service_status_enum_type_v01 nas_srv_status;
  nas_common_sys_info_type_v01 * common_sys_info;
  nas_3gpp_only_sys_info_type_v01 * threegpp_sys_info;
  uint8_t * is_voice_supported_on_lte;
  nas_3gpp_srv_status_info_type_v01 * threegpp_status_info;
  nas_hdr_only_sys_info_type_v01 * hdr_only_sys_info;
  // TODO:qmi_nas_srv_status_convertion_extra_results_type * extra_results;

  //MSG_HIGH("qmi_nas_util_convert_nas_srv_status_to_ril_reg_status()", 0, 0, 0);

  res = RIL_VAL_REG_UNKNOWN;

  if( NULL != nas_sys_info_helper )
  {
    is_data = NAS_IS_BIT_SET(nas_sys_info_flag, NAS_SYS_INFO_IS_DATA);
    is_3gpp = NAS_IS_BIT_SET(nas_sys_info_flag, NAS_SYS_INFO_IS_3GPP);
    is_hdr = NAS_IS_BIT_SET(nas_sys_info_flag, NAS_SYS_INFO_IS_HDR);

    nas_srv_status = qmi_util_retrieve_srv_status(nas_sys_info_helper, is_3gpp);
    common_sys_info = nas_sys_info_helper->common_sys_info;
    threegpp_sys_info = nas_sys_info_helper->threegpp_only_sys_info;
    is_voice_supported_on_lte = nas_sys_info_helper->voice_support_on_lte;
    threegpp_status_info = nas_sys_info_helper->threegpp_srv_status;
    hdr_only_sys_info = nas_sys_info_helper->hdr_only_sys_info;
    // TODO:extra_results = nas_sys_info_helper->extra_results;

    //MSG_HIGH("... nas_srv_status %d, is_data %d", (int) nas_srv_status, is_data, 0 );
	//MSG_HIGH("... is_3gpp %d, is_hdr %d", is_3gpp, is_hdr, 0 );

    // 1st run
    switch ( nas_srv_status )
    {
      case NAS_SYS_SRV_STATUS_NO_SRV_V01:
        res = RIL_VAL_REG_NOT_REGISTERED_SEARCHING;
        break;

      case NAS_SYS_SRV_STATUS_LIMITED_V01:            // fallthrough
      case NAS_SYS_SRV_STATUS_LIMITED_REGIONAL_V01:
        res = RIL_VAL_REG_NOT_REGISTERED_SEARCHING_LTD_SRV;
        break;

      case NAS_SYS_SRV_STATUS_SRV_V01:
        if ( NULL == common_sys_info || 
             (common_sys_info->roam_status_valid && 
              (NAS_SYS_ROAM_STATUS_OFF_V01 == common_sys_info->roam_status || (nas_roam_status_enum_type_v01)NAS_VAL_ROAMING_HOME_EX == common_sys_info->roam_status ) )
        )
        {
          res = RIL_VAL_REG_REGISTERED_HOME_NET;
        }
        else
        {
          res = RIL_VAL_REG_REGISTERED_ROAMING;
        }
        break;

      case NAS_SYS_SRV_STATUS_PWR_SAVE_V01:
        res = RIL_VAL_REG_NOT_REGISTERED_NOT_SEARCHING;
        break;

      default:
        res = RIL_VAL_REG_UNKNOWN;
        break;
    }

    MSG_HIGH("nas_srv_status REG : %d[%s]", (int) res, registration_status_str(res), 0  );
    
    // caps check
    //MSG_HIGH("... common_sys_info %d", (int) common_sys_info, 0, 0 );
    if ( NULL != common_sys_info )
    {
      //MSG_HIGH("... srv_capability_valid, srv_capability %d, %d", (int) common_sys_info->srv_capability_valid, (int) common_sys_info->srv_capability, 0 );
      //MSG_HIGH("... srv_domain_valid, srv_domain %d, %d", (int) common_sys_info->srv_domain_valid, (int) common_sys_info->srv_domain, 0 );
      MSG_HIGH("... is_voice_supported_on_lte %d", nas_cached_info.voice_support_on_lte, 0, 0);
    
      if ( RIL_VAL_REG_REGISTERED_HOME_NET == res || RIL_VAL_REG_REGISTERED_ROAMING == res || RIL_VAL_REG_NOT_REGISTERED_SEARCHING_LTD_SRV == res )
      {
        if ( !is_data )
        { // voice
          if ( (common_sys_info->srv_capability_valid && SYS_SRV_DOMAIN_CS_ONLY_V01 != common_sys_info->srv_capability && SYS_SRV_DOMAIN_CS_PS_V01 != common_sys_info->srv_capability
               && !(SYS_SRV_DOMAIN_PS_ONLY_V01 == common_sys_info->srv_capability && NULL != is_voice_supported_on_lte && TRUE == *is_voice_supported_on_lte))
               || (common_sys_info->srv_domain_valid && SYS_SRV_DOMAIN_CS_ONLY_V01 != common_sys_info->srv_domain && SYS_SRV_DOMAIN_CS_PS_V01 != common_sys_info->srv_domain && RIL_VAL_REG_NOT_REGISTERED_SEARCHING_LTD_SRV != res)
          )
          {
            res = RIL_VAL_REG_NOT_REGISTERED_NOT_SEARCHING;
          }
        }
        else
        { // data
          if ( is_3gpp )
          {
            if ( (common_sys_info->srv_capability_valid && common_sys_info->srv_capability != SYS_SRV_DOMAIN_PS_ONLY_V01 && common_sys_info->srv_capability != SYS_SRV_DOMAIN_CS_PS_V01)
                 ||
                 (common_sys_info->srv_domain_valid && common_sys_info->srv_domain != SYS_SRV_DOMAIN_PS_ONLY_V01 && common_sys_info->srv_domain != SYS_SRV_DOMAIN_CS_PS_V01 && RIL_VAL_REG_NOT_REGISTERED_SEARCHING_LTD_SRV != res)
            )
            {
              res = RIL_VAL_REG_NOT_REGISTERED_SEARCHING;
            }
          }
        }
      }
    }
    MSG_HIGH("srv_capability_valid CS/PS REG : %d[%s]", (int) res, registration_status_str(res), 0  );

    //MSG_HIGH("... hdr_only_sys_info %d", (int) hdr_only_sys_info, 0, 0 );
    if( is_hdr )
    {
      if( RIL_VAL_REG_REGISTERED_HOME_NET == res || RIL_VAL_REG_REGISTERED_ROAMING == res || RIL_VAL_REG_NOT_REGISTERED_SEARCHING_LTD_SRV == res )
      {
        if( NULL != hdr_only_sys_info )
        {
          //MSG_HIGH("... hdr_active_prot_valid, hdr_personality_valid %d, %d", (int) hdr_only_sys_info->hdr_active_prot_valid, (int) hdr_only_sys_info->hdr_personality_valid, 0 );
          if( FALSE == hdr_only_sys_info->hdr_active_prot_valid || FALSE == hdr_only_sys_info->hdr_personality_valid )
          {
            res = RIL_VAL_REG_NOT_REGISTERED_NOT_SEARCHING;
          }
        }
        else
        {
          res = RIL_VAL_REG_NOT_REGISTERED_NOT_SEARCHING;
        }
      }
    }
    MSG_HIGH("hdr_only_sys_info REG : %d[%s]", (int) res, registration_status_str(res), 0  );
    
    // reg reject check
    if ( NULL != common_sys_info )
    {
      MSG_HIGH("... is_sys_forbidden_valid, is_sys_forbidden %d, %d", (int) common_sys_info->is_sys_forbidden_valid, (int) common_sys_info->is_sys_forbidden, 0 );
    }
    if ( NULL != threegpp_sys_info )
    {
      MSG_HIGH("... reg_reject_info_valid, reg_reject_info.dmn, reg_reject_info.cause %d, %d, %d",
                   (int) threegpp_sys_info->reg_reject_info_valid,
                   (int) threegpp_sys_info->reg_reject_info.reject_srv_domain,
                   (int) threegpp_sys_info->reg_reject_info.rej_cause );
    }
    if ( threegpp_status_info != NULL )
    {
      //MSG_HIGH("... true srv status %d", (int) threegpp_status_info->true_srv_status, 0, 0);
    }
    if ( is_3gpp )
    {
      if( RIL_VAL_REG_NOT_REGISTERED_SEARCHING == res || RIL_VAL_REG_NOT_REGISTERED_NOT_SEARCHING == res || RIL_VAL_REG_NOT_REGISTERED_SEARCHING_LTD_SRV == res )
      {
        if ( !is_data &&
             ( RIL_E_SUCCESS == qmi_nas_get_nw_selection_mode( &nw_sel_pref ) && NAS_NET_SEL_PREF_MANUAL_V01 == nw_sel_pref ) // manual selection
             &&
             NULL != threegpp_status_info // sanity check
             &&
             (  // either limited service
               ( SYS_SRV_STATUS_LIMITED_V01 == threegpp_status_info->true_srv_status )
               ||
               ( // or full service on ps only
                ( NAS_SYS_SRV_STATUS_SRV_V01 == threegpp_status_info->true_srv_status || NAS_SYS_SRV_STATUS_PWR_SAVE_V01 == threegpp_status_info->true_srv_status )
                &&
                ( NULL != common_sys_info &&  SYS_SRV_DOMAIN_PS_ONLY_V01 == common_sys_info->srv_domain )
               )
             )
        )
        {   // managed roaming
          res = RIL_VAL_REG_REGISTRATION_DENIED_LTD_SRV;
#if 0 // TODO:
          if ( extra_results )
          {
            extra_results->is_reject_case      = TRUE;
            extra_results->is_managed_roaming  = TRUE;
            extra_results->reject_cause        = RIL_VAL_REG_MANAGED_ROAMING_CAUSE; // dedicated cause for managed roaming
          }
#endif
        }
        else
        {   // common reg reject
          if ( NULL != common_sys_info && common_sys_info->is_sys_forbidden_valid && common_sys_info->is_sys_forbidden )
          {
            res = (RIL_VAL_REG_NOT_REGISTERED_SEARCHING_LTD_SRV == res) ? RIL_VAL_REG_REGISTRATION_DENIED_LTD_SRV : RIL_VAL_REG_REGISTRATION_DENIED;
#if 0 // TODO:
            if ( extra_results )
            {
              extra_results->is_reject_case      = TRUE;
              extra_results->is_managed_roaming  = FALSE;
              extra_results->reject_cause        = NAS_NIL;
            }
#endif
          }
          if ( NULL != threegpp_sys_info && threegpp_sys_info->reg_reject_info_valid )
          {
            // TODO:qmi_nas_util_process_nas_threegpp_reg_reject_info(is_data, &res, &threegpp_sys_info->reg_reject_info, extra_results);
          }
        }
      }
      else if( RIL_VAL_REG_REGISTERED_HOME_NET == res || RIL_VAL_REG_REGISTERED_ROAMING == res )
      {
        if ( NULL != threegpp_sys_info && threegpp_sys_info->reg_reject_info_valid &&
             ( 
               ( !is_data && 
                  (SYS_SRV_DOMAIN_CS_ONLY_V01 == threegpp_sys_info->reg_reject_info.reject_srv_domain || 
                   SYS_SRV_DOMAIN_CS_PS_V01 == threegpp_sys_info->reg_reject_info.reject_srv_domain )
               ) ||
               ( is_data && 
                 ( SYS_SRV_DOMAIN_CS_PS_V01 == threegpp_sys_info->reg_reject_info.reject_srv_domain || 
                   SYS_SRV_DOMAIN_PS_ONLY_V01 == threegpp_sys_info->reg_reject_info.reject_srv_domain )
                 )
               )
        )
        {
          res = RIL_VAL_REG_NOT_REGISTERED_SEARCHING_LTD_SRV;
          // TODO:qmi_nas_util_process_nas_threegpp_reg_reject_info(is_data, &res, &threegpp_sys_info->reg_reject_info, extra_results);
        }
      }
    }
    }
  else
  {
    MSG_FATAL("CHECK FAILED - nas_sys_info_helper is NULL", 0, 0, 0);
  }

  return res;
}

/*=========================================================================
  FUNCTION:  qmi_sys_info_roll_details

===========================================================================*/
void qmi_sys_info_roll_details
(
  int * rte_reg_status,
  int is_data
)
{
  nas_sys_info_helper_type sys_info_helper;
  int data_mask = is_data ? NAS_SYS_INFO_IS_DATA : NAS_SYS_INFO_IS_EMPTY;

  MSG_HIGH( " .. prep CDMA", 0, 0, 0 );
  if ( NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.cdma_srv_status_info ) )
  {
    memset(&sys_info_helper, 0 ,sizeof(sys_info_helper));
    sys_info_helper.threegpp2_srv_status = nas_cached_info.cdma_srv_status_info;
    sys_info_helper.common_sys_info = NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.cdma_sys_info ) ? &nas_cached_info.cdma_sys_info->common_sys_info : NULL;
    rte_reg_status[ QMI_RIL_RTE_1x ] = qmi_nas_util_convert_nas_srv_status_to_ril_reg_status(data_mask, &sys_info_helper);
  }

  MSG_HIGH( " .. prep LTE", 0, 0, 0 );
  if ( NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.lte_srv_status_info ) )
  {
    memset(&sys_info_helper, 0 ,sizeof(sys_info_helper));
    sys_info_helper.threegpp_srv_status = nas_cached_info.lte_srv_status_info;
    sys_info_helper.common_sys_info = NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.lte_sys_info ) ? &nas_cached_info.lte_sys_info->common_sys_info : NULL;
    sys_info_helper.threegpp_only_sys_info = NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.lte_sys_info ) ? &nas_cached_info.lte_sys_info->threegpp_specific_sys_info : NULL;
    sys_info_helper.voice_support_on_lte = NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.voice_support_on_lte ) ? &nas_cached_info.voice_support_on_lte : NULL;
    rte_reg_status[ QMI_RIL_RTE_SUB_LTE ] = qmi_nas_util_convert_nas_srv_status_to_ril_reg_status(data_mask | NAS_SYS_INFO_IS_3GPP, &sys_info_helper);
  }

  MSG_HIGH( " .. prep EVDO", 0, 0, 0 );
  if ( NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.hdr_srv_status_info ) )
  {
    memset(&sys_info_helper, 0 ,sizeof(sys_info_helper));
    sys_info_helper.threegpp2_srv_status = nas_cached_info.hdr_srv_status_info;
    sys_info_helper.common_sys_info = NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.hdr_sys_info ) ? &nas_cached_info.hdr_sys_info->common_sys_info : NULL;
    sys_info_helper.hdr_only_sys_info = NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.hdr_sys_info ) ? &nas_cached_info.hdr_sys_info->hdr_specific_sys_info : NULL;
    rte_reg_status[ QMI_RIL_RTE_SUB_DO ] = qmi_nas_util_convert_nas_srv_status_to_ril_reg_status(data_mask | NAS_SYS_INFO_IS_HDR, &sys_info_helper);
  }
}/* qmi_sys_info_roll_details */

/*=========================================================================
  FUNCTION:  qmi_ril_nw_reg_get_status_overview

===========================================================================*/
uint32 qmi_ril_nw_reg_get_status_overview( void )
{
  uint32_t res = QMI_RIL_ZERO;
  int rte_reg_status[ QMI_RIL_RTE_CAP ];
  int idx_rte;

  //MSG_HIGH("qmi_ril_nw_reg_get_status_overview()", 0, 0, 0);

  memset( &rte_reg_status, 0, sizeof( rte_reg_status ) );
  //NAS_CACHE_LOCK();
  qmi_sys_info_roll_details( rte_reg_status, FALSE );
  //NAS_CACHE_UNLOCK();

  //MSG_HIGH( ".. 1x reg %d", rte_reg_status[ QMI_RIL_RTE_1x ], 0, 0 );
  //MSG_HIGH( ".. gsm reg %d", rte_reg_status[ QMI_RIL_RTE_GSM ], 0, 0 );
  //MSG_HIGH( ".. wcdma reg %d", rte_reg_status[ QMI_RIL_RTE_WCDMA ], 0, 0 );
  MSG_HIGH( ".. lte reg %d", rte_reg_status[ QMI_RIL_RTE_SUB_LTE ], 0, 0 );
  //MSG_HIGH( ".. hdr reg %d", rte_reg_status[ QMI_RIL_RTE_SUB_DO ], 0, 0 );

  for ( idx_rte = 1; idx_rte <= 5 ; idx_rte++)
  {
    switch ( rte_reg_status[ idx_rte ] )
    {
      case RIL_VAL_REG_REGISTERED_HOME_NET:
      case RIL_VAL_REG_REGISTERED_ROAMING:
        res |= QMI_RIL_NW_REG_FULL_SERVICE;
        switch ( idx_rte )
        {
          case QMI_RIL_RTE_GSM:
          case QMI_RIL_RTE_WCDMA:
            res |= QMI_RIL_NW_REG_VOICE_CALLS_AVAILABLE;
            break;

          case QMI_RIL_RTE_SUB_LTE:
            if(nas_cached_info.voice_support_on_lte)
            {
              res |= QMI_RIL_NW_REG_VOIP_CALLS_AVAILABLE;
            }
            break;

          default:
            // nothing
            break;
        }
        break;

      case RIL_VAL_REG_NOT_REGISTERED_SEARCHING_LTD_SRV:
      case RIL_VAL_REG_REGISTRATION_DENIED_LTD_SRV:
        res |= QMI_RIL_NW_REG_LIMITED_SERVICE | QMI_RIL_NW_REG_VOICE_CALLS_AVAILABLE;
        break;

      deafult:
        // nothing
        break;
    }
#ifdef BOGUS
    if ( RIL_VAL_REG_REGISTERED_HOME_NET == rte_reg_status[ idx_rte ] || RIL_VAL_REG_REGISTERED_ROAMING == rte_reg_status[ idx_rte ] )
    {
      res = TRUE;
    }
#endif
  }

  if ( QMI_RIL_ZERO == res )
  { // voice calls available by default
    res |= QMI_RIL_NW_REG_VOICE_CALLS_AVAILABLE; 
  }

  return res;
}/* qmi_ril_nw_reg_get_status_overview */

//<-- VOLTE_CALL_TYPE
/*=========================================================================

  FUNCTION:  qcril_nas_indication_cb

===========================================================================*/
/*!
    @brief
    Callback for QMI indications.

    @return
    None
*/
/*=========================================================================*/
void qmi_nas_indication_cb
(
  int                            user_handle,
  qmi_service_id_type            service_id,
  void                         * user_data,
  qmi_nas_indication_id_type     ind_id,
  qmi_nas_indication_data_type * ind_data_ptr
)
{
  nas_701B_ind_s *nas_701B_ind;

  switch(ind_id)
  {
      case QMI_NAS_SIGNAL_STRENGTH_IND_MSG:
      //printf("NAS_STRENGTH_IND_MSG\r\n");
        MSG_HIGH( "NAS_STRENGTH_IND_MSG", 0, 0, 0 );
      break;

      case QMI_NAS_APN_CHANGED_IND_MSG:
      {
        //char *response = NULL;
        nas_701B_ind = (nas_701B_ind_s *)ind_data_ptr;
        
        //printf("APN changed ind : %s", nas_701B_ind->t01.apn , 0, 0);
        MSG_HIGH( "APN changed ind : %s", nas_701B_ind->t01.apn, 0, 0 );
        //asprintf(&response, "%s", nas_701B_ind->t01.apn);				
        //Send_UnsolicitedResponse (RIL_UNSOL_HK_LTE_VZW_APN_CHANGED, response, strlen(response));
        //free(response);
      }
      break;	  

      default:
        break;
    }
}

/*===========================================================================

  FUNCTION  tof_qmi_nas_init
  
===========================================================================*/
boolean tof_qmi_nas_init()
{
  int rc = QMI_INTERNAL_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;

  nas_0003_req_s nas_0003_req;

  if(nas_client_handle != QMI_INVALID_CLIENT_HANDLE) RESULT_SUCCESS;
  
  /* Bring up NAS service for second port */
  if ((nas_client_handle = tof_tof_qmi_nas_srvc_init_client (QMI_PORT_RMNET_0,
                                                 qmi_nas_indication_cb, // callback function. 
                                                 NULL, 
                                                 &qmi_err_code)) < 0)
  {
    printf("Unable to start NAS service nas_client_handle= %x, qmi_err_code=%x\n", 
           nas_client_handle, 
           qmi_err_code);
    return RESULT_FAILURE;
  }
  else
  {
    printf("Opened NAS Client. nas_client_handle= %x \r\n", nas_client_handle);
  }  

  // get registration status
  memset(&registration_status, 0x0, sizeof(wmm_registartion_status_type));
  if(get_registration_status_info()!= RESULT_SUCCESS)
  {
    printf("get_registration_status_info() Failed \r\n");
  }
  
  memset(&nas_0003_req, 1, sizeof(nas_0003_req_s));
  rc = qmi_nas_indication_register((int)nas_client_handle,
                                              &nas_0003_req,
                                              &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    printf("[NAS]qmi_nas_indication_register!! rc: %d err_code : %d",rc,qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  if(qmi_nas_set_config_sig_info2() != RIL_E_SUCCESS)
  {
    printf("qmi_nas_set_config_sig_info2() Failed \r\n");
  }
  
  network_selection_mode_status = 0;
  get_network_selection_mode_status();
  
  return RESULT_SUCCESS;
}

/*===========================================================================

  FUNCTION  tof_qmi_nas_release
  
===========================================================================*/
boolean tof_qmi_nas_release()
{
   int qmi_err_code = QMI_NO_ERR;
   int rc = QMI_NO_ERR;

   if(nas_client_handle == QMI_INVALID_CLIENT_HANDLE) return RESULT_SUCCESS;
   
  if(nas_client_handle != QMI_INVALID_CLIENT_HANDLE)
  {
    rc = tof_qmi_nas_srvc_release_client(nas_client_handle, &qmi_err_code);
    if(rc != QMI_NO_ERR)
    {
      printf("tof_qmi_nas_srvc_release_client rc = %d, qmi_err_code \n", rc, qmi_err_code);
      return RESULT_FAILURE;
    } 
  }
  else
  {
    printf("tof_qmi_release nas_client_handle= %x\r\n", nas_client_handle);
  }

  return RESULT_SUCCESS;
}

#if 0
/*===========================================================================

  FUNCTION  tof_qmi_nas_srvc_init
  
===========================================================================*/
bool tof_qmi_nas_srvc_init()
{
  int rc = QMI_INTERNAL_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_0003_req_s nas_0003_req;
  nas_0002_req_s nas_0002_req; 

  nas_client_handle = tof_qmi_nas_srvc_init_client(qmi_nas_indication_cb,&qmi_err_code);

  if(nas_client_handle == INVALID_HANDLE_VALUE)
  {
    MSG_ERROR("[NAS]error on tof_qmi_nas_srvc_init_client",0 ,0, 0);
    return FALSE;
  }

  /* Register for events first */

  memset(&nas_0003_req, 1, sizeof(nas_0003_req_s));
  
  rc = qmi_nas_indication_register((int)nas_client_handle,
                                              &nas_0003_req,
                                              &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_indication_register!! rc: %d err_code : %d",rc,qmi_err_code, 0);
    return FALSE;
  }

  // 130718 jgkim, for debug information
  memset(&avg_rsrp, 0, sizeof(qmi_nas_avg_rf_data_type));
  memset(&operator_status, 0x0, sizeof(RIL_Operator_Info));

  // get registration status
  memset(&registration_status, 0x0, sizeof(wmm_registartion_status_type));
  get_registration_status_info();

  if (wmm_get_vendor_type() == WMM_VENDOR_NONE)
  {
    extern BOOL wmm_init_vendor_type();

    (void) wmm_init_vendor_type();
    if(wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW)
    {
      qmi_nas_cleanup();
      qmi_nas_vzw_fetch_sys_info();
      qmi_nas_query_avail_radio_tech(FALSE);
    }
   }

  memset(&nas_0002_req, 0, sizeof(nas_0002_req_s));

  nas_0002_req.t10_valid = FALSE;
  //nas_0002_req.t10.report_signal_strength = NAS_0002_REQ_T10_REPORT_SIGNAL_STRENGTH_REPORT;
  //nas_0002_req.t10.num_signal_strength_thresholds = 5; // vaild : 1 ~ 5
  //nas_0002_req.t10.report_signal_strength_threshold_list[0] = ;

  nas_0002_req.t11_valid = TRUE;
  nas_0002_req.t11.report_rf_band_info = NAS_0002_REQ_T11_REPORT_RF_BAND_INFO_REPORT;

  nas_0002_req.t12_valid = TRUE;
  nas_0002_req.t12.report_reg_reject = NAS_0002_REQ_T12_REGISTRATION_REJECT_REASONS_REPORT;

  if(wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW)
  {
    #if 0
    if(qmi_nas_set_vzw_config_sig_info2() != RIL_E_SUCCESS)
    {

      MSG_ERROR("[NAS]qmi_nas_set_vzw_config_sig_info2 error!!",0,0, 0);
      return FALSE;
    } 
    #else
    #endif
    
  }
  else
  {    
  #if 0
  nas_0002_req.t13_valid = TRUE;
  nas_0002_req.t13.report_rssi = NAS_0002_REQ_T13_REPORT_RSSI_REPORT;
  nas_0002_req.t13.rssi_delta  = NAS_0002_REQ_T13_REPORT_RSSI_DELTA;

  nas_0002_req.t14_valid = TRUE;
  nas_0002_req.t14.report_ecio = NAS_0002_REQ_T14_REPORT_ECIO_REPORT;
  nas_0002_req.t14.ecio_delta  = NAS_0002_REQ_T14_REPORT_ECIO_DELTA;

  nas_0002_req.t15_valid = FALSE;
  //nas_0002_req.t15.report_io = NAS_0002_REQ_T15_REPORT_IO_REPORT;
  //nas_0002_req.t15.io_delta  = NAS_0002_REQ_T15_REPORT_IO_REPORT;

  nas_0002_req.t16_valid = FALSE;
  //nas_0002_req.t16.report_sinr = NAS_0002_REQ_T16_REPORT_SINR_REPORT;
  //nas_0002_req.t16.sinr_delta  = NAS_0002_REQ_T16_REPORT_SINR_REPORT;
  
  nas_0002_req.t17_valid = FALSE;
  //nas_0002_req.t17.report_error_rate = NAS_0002_REQ_T17_REPORT_ERROR_RATE_REPORT;

  nas_0002_req.t18_valid = TRUE;
  nas_0002_req.t18.report_rsrq = NAS_0002_REQ_T18_REPORT_RSRQ_REPORT;
  nas_0002_req.t18.rsrq_delta = NAS_0002_REQ_T18_REPORT_RSRQ_DELTA;

  nas_0002_req.t19_valid = FALSE;
  //nas_0002_req.t19.report_ecio = NAS_0002_REQ_T19_REPORT_ECIO_REPORT;
  //nas_0002_req.t19.num_thresholds = 10; // vaild : 1 ~ 10

  nas_0002_req.t1A_valid = FALSE;
  //nas_0002_req.t1A.report_sinr = NAS_0002_REQ_T1A_REPORT_SINR_REPORT;
  //nas_0002_req.t1A.num_thresholds = 5; // vaild : 1 ~ 5

  nas_0002_req.t1B_valid = TRUE;
  nas_0002_req.t1B.report_lte_snr = NAS_0002_REQ_T1B_REPORT_LTE_SNR_REPORT;
  nas_0002_req.t1B.lte_snr_delta = NAS_0002_REQ_T1B_REPORT_LTE_SNR_DELTA;

  nas_0002_req.t1C_valid = TRUE;
  nas_0002_req.t1C.report_lte_rsrp = NAS_0002_REQ_T1C_REPORT_LTE_RSRP_REPORT;
  nas_0002_req.t1C.lte_rsrp_delta = NAS_0002_REQ_T1C_REPORT_LTE_RSRP_DELTA;
  #else
    if(qmi_nas_set_config_sig_info2() != RIL_E_SUCCESS)
    {

      MSG_ERROR("[NAS]qmi_nas_set_config_sig_info2 error!!",0,0, 0);
      return FALSE;
    }
  #endif
  }

  rc = qmi_nas_set_event_report_state((int)nas_client_handle,
                                           &nas_0002_req,
                                           &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_set_event_report_state!! rc: %d err_code : %d",rc,qmi_err_code, 0);
    return FALSE;
  }

  network_selection_mode_status = 0;
  get_network_selection_mode_status();

  return TRUE;
} /* tof_qmi_nas_srvc_init */
#endif

/*===========================================================================

  FUNCTION  tof_qmi_nas_srvc_release
  
===========================================================================*/
int tof_qmi_nas_srvc_release()
{
  int ret = QMI_INTERNAL_ERR;
  int qmi_err_code = QMI_INTERNAL_ERR;

  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return ret;

  if((wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ) || ( wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ))
  {
    qmi_nas_cleanup();
  }

  ret = tof_qmi_nas_srvc_release_client((int)nas_client_handle, &qmi_err_code);

  if(ret == QMI_NO_ERR)
    nas_client_handle = INVALID_HANDLE_VALUE;
  
  return ret;
}


//--> RIL_REQUEST_REGISTRATION_STATE
/*=========================================================================
  FUNCTION:  qmi_arb_query_voice_tech_modem_id

===========================================================================*/
/*!
    @brief
    Find the modem ids for voice techologies based on the underlying modem 
    architecture and network preference. 

    @return
    None
*/
/*=========================================================================*/
void qmi_arb_query_voice_tech_modem_id
(
  uint16                 mode_pref,
  qmi_modem_id_e_type    *cdma_modem_id,
  qmi_modem_id_e_type    *gw_modem_id
)
{
  /*-----------------------------------------------------------------------*/

  QCRIL_ASSERT( cdma_modem_id != NULL );
  QCRIL_ASSERT( gw_modem_id != NULL );

  /*-----------------------------------------------------------------------*/

  //QCRIL_MUTEX_LOCK( &qcril_arb.mutex, "qcril_arb.mutex" );

  *cdma_modem_id = QMI_MAX_MODEM_ID;
  *gw_modem_id = QMI_MAX_MODEM_ID;

  MSG_HIGH("mode_pref %s(%d)", mode_pref_type_str(mode_pref), mode_pref, 0);

  switch( mode_pref )
  {
    case QMI_NAS_RAT_MODE_PREF_CDMA:
    case QMI_NAS_RAT_MODE_PREF_CDMA_HRPD:
    case QMI_NAS_RAT_MODE_PREF_HRPD:
      *cdma_modem_id = QMI_DEFAULT_MODEM_ID;
      break;
        
    case QMI_NAS_RAT_MODE_PREF_GSM:
    case QMI_NAS_RAT_MODE_PREF_UMTS:
    case QMI_NAS_RAT_MODE_PREF_GSM_UMTS:
    case QMI_NAS_RAT_MODE_PREF_LTE:
    case QMI_NAS_RAT_MODE_PREF_GSM_UMTS_LTE:
      *gw_modem_id = QMI_DEFAULT_MODEM_ID;
      break;

    case QMI_NAS_RAT_MODE_PREF_GSM_UMTS_CDMA_HRPD:
    case QMI_NAS_RAT_MODE_PREF_CDMA_HRPD_LTE:
    case QMI_NAS_RAT_MODE_PREF_GSM_UMTS_CDMA_HRPD_LTE:
      *cdma_modem_id = QMI_DEFAULT_MODEM_ID;
      *gw_modem_id = QMI_SECOND_MODEM_ID; // TODO: VZW
      break;

    default:
      break;
  } /* end switch */

  //QCRIL_MUTEX_UNLOCK( &qcril_arb.mutex, "qcril_arb.mutex" );

} /* qmi_arb_query_voice_tech_modem_id */

/*=========================================================================
  FUNCTION:  qmi_srv_query_lte_full_srv

===========================================================================*/
boolean qmi_srv_query_lte_full_srv()
{
  boolean is_lte_full_srv = FALSE;

  if ( QMI_SRV_STATUS_INDICATES_LTE_FULL_SRV( nas_cached_info.lte_srv_status_info->srv_status,  nas_cached_info.lte_srv_status_info_valid) )
  {
    /* LTE is the available radio technology */
    MSG_HIGH("LTE System\n", 0, 0, 0); 
    is_lte_full_srv = TRUE;
  }

  return is_lte_full_srv;
}

//BKS_20141029 
/*=========================================================================
  FUNCTION:  qmi_srv_query_lte_full_srv

===========================================================================*/
boolean qmi_srv_query_cdma_full_srv()
{
  boolean is_cdma_full_srv = FALSE;

  if ( QMI_SRV_STATUS_INDICATES_CDMA_FULL_SRV( nas_cached_info.cdma_srv_status_info->srv_status,  nas_cached_info.cdma_srv_status_info_valid))
  {
    /* CDMA is the available radio technology */
    MSG_HIGH("CDMA System\n", 0, 0, 0); 
    is_cdma_full_srv = TRUE;
  }

  return is_cdma_full_srv;
}
/*=========================================================================
  FUNCTION:  qmi_srv_sys_info_to_reg_state

===========================================================================*/
/*!
    @brief
    Convert the serving status and roaming status to registration state info.

    @return
    None.
*/
/*=========================================================================*/
void qmi_srv_sys_info_to_reg_state
(
  boolean reporting_data_reg_state,
  qmi_nas_registration_state_resp_helper_type *resp_ptr
)
{
  int val_int;

  /*-----------------------------------------------------------------------*/

  QCRIL_ASSERT( resp_ptr != NULL );

  /*-----------------------------------------------------------------------*/

  MSG_HIGH("qmi_srv_sys_info_to_reg_state()", 0, 0, 0);

  /* Initialize reg_state to Unknown */
  val_int = 4;

#ifdef BOGUS //VZW
  if ( reporting_data_reg_state )
  {
    MSG_ERROR( "NO SERVICE\n", 0, 0, 0 );
    val_int = 2;
    snprintf(resp_ptr->registration_state, sizeof(resp_ptr->registration_state), "%d", val_int);
    return;
  }
#endif

  /* Non-hybrid, powersave or no service */
  if ( ( ( nas_cached_info.mode_pref == QMI_NAS_RAT_MODE_PREF_GSM_UMTS ) ||
         ( nas_cached_info.mode_pref == QMI_NAS_RAT_MODE_PREF_GSM ) ||
         ( nas_cached_info.mode_pref == QMI_NAS_RAT_MODE_PREF_UMTS ) ||
         ( nas_cached_info.mode_pref == QMI_NAS_RAT_MODE_PREF_LTE )
       ) ||
       ( nas_cached_info.mode_pref == QMI_NAS_RAT_MODE_PREF_CDMA ) ||
       ( ( ( nas_cached_info.mode_pref == QMI_NAS_RAT_MODE_PREF_GSM_UMTS_CDMA_HRPD ) ||
           ( nas_cached_info.mode_pref == QMI_NAS_RAT_MODE_PREF_CDMA_HRPD_LTE ) ||
           ( nas_cached_info.mode_pref == QMI_NAS_RAT_MODE_PREF_GSM_UMTS_CDMA_HRPD_LTE ) ||
           ( nas_cached_info.mode_pref == QMI_NAS_RAT_MODE_PREF_CDMA_HRPD ) ||
           ( nas_cached_info.mode_pref == QMI_NAS_RAT_MODE_PREF_HRPD )
         ) && !nas_cached_info.hdr_hybrid ) )
  {
    //if ( ssi_ptr->srv_status == SYS_SRV_STATUS_PWR_SAVE )
    if( ( nas_cached_info.cdma_srv_status_info_valid && (nas_cached_info.cdma_srv_status_info->srv_status == SYS_SRV_STATUS_PWR_SAVE) ) &&
        ( nas_cached_info.hdr_srv_status_info_valid && (nas_cached_info.hdr_srv_status_info->srv_status == SYS_SRV_STATUS_PWR_SAVE)) &&
        ( nas_cached_info.lte_srv_status_info_valid && (nas_cached_info.lte_srv_status_info->srv_status == SYS_SRV_STATUS_PWR_SAVE))
      )
    {
      /* Not registered, MT is not currently searching a new operator to register to */
      MSG_HIGH("Power Save Mode\n", 0, 0, 0);
      val_int = 0;
      snprintf(resp_ptr->registration_state, sizeof(resp_ptr->registration_state), "%d", val_int);
      return;
    }
    
    //if ( ssi_ptr->srv_status == SYS_SRV_STATUS_NO_SRV )
    if( ( nas_cached_info.cdma_srv_status_info_valid && (nas_cached_info.cdma_srv_status_info->srv_status == SYS_SRV_STATUS_NO_SRV) ) &&
        ( nas_cached_info.hdr_srv_status_info_valid && (nas_cached_info.hdr_srv_status_info->srv_status == SYS_SRV_STATUS_NO_SRV)) &&
        ( nas_cached_info.lte_srv_status_info_valid && (nas_cached_info.lte_srv_status_info->srv_status == SYS_SRV_STATUS_NO_SRV))
      )
    {
      /* Not registered, but MT is currently searching a new operator to register to*/
      MSG_HIGH("NO SERVICE\n", 0, 0, 0);
      val_int = 2;
      snprintf(resp_ptr->registration_state, sizeof(resp_ptr->registration_state), "%d", val_int);
      return;
    }
  }

  /* Hybrid, powersave or no service */
  if ( ( ( nas_cached_info.mode_pref == QMI_NAS_RAT_MODE_PREF_CDMA_HRPD ) || 
         ( nas_cached_info.mode_pref == QMI_NAS_RAT_MODE_PREF_HRPD ) || 
         ( nas_cached_info.mode_pref == QMI_NAS_RAT_MODE_PREF_GSM_UMTS_CDMA_HRPD ) ||
         ( nas_cached_info.mode_pref == QMI_NAS_RAT_MODE_PREF_CDMA_HRPD_LTE ) ||
         ( nas_cached_info.mode_pref == QMI_NAS_RAT_MODE_PREF_GSM_UMTS_CDMA_HRPD_LTE )
       ) && nas_cached_info.hdr_hybrid ) 
  {
    if( ( nas_cached_info.cdma_srv_status_info_valid && (nas_cached_info.cdma_srv_status_info->srv_status == SYS_SRV_STATUS_PWR_SAVE) ) &&
        ( ( nas_cached_info.hdr_srv_status_info_valid && (nas_cached_info.hdr_srv_status_info->srv_status == SYS_SRV_STATUS_PWR_SAVE) ) &&
          ( nas_cached_info.lte_srv_status_info_valid && (nas_cached_info.lte_srv_status_info->srv_status == SYS_SRV_STATUS_PWR_SAVE) ) )
      )
    {
      /* Not registered, MT is not currently searching a new operator to register to */
      MSG_HIGH("Power Save Mode\n", 0, 0, 0);
      val_int = 0;
      snprintf(resp_ptr->registration_state, sizeof(resp_ptr->registration_state), "%d", val_int);
      return;
    }

    if( ( ( nas_cached_info.cdma_srv_status_info_valid && (nas_cached_info.cdma_srv_status_info->srv_status == SYS_SRV_STATUS_NO_SRV) ) &&
        ( ( nas_cached_info.hdr_srv_status_info_valid && (nas_cached_info.hdr_srv_status_info->srv_status == SYS_SRV_STATUS_NO_SRV) ) &&
          ( nas_cached_info.lte_srv_status_info_valid && (nas_cached_info.lte_srv_status_info->srv_status == SYS_SRV_STATUS_NO_SRV) ) )
        ) ||
        ( ( nas_cached_info.cdma_srv_status_info_valid && (nas_cached_info.cdma_srv_status_info->srv_status == SYS_SRV_STATUS_NO_SRV) ) &&
        ( ( nas_cached_info.hdr_srv_status_info_valid && (nas_cached_info.hdr_srv_status_info->srv_status == SYS_SRV_STATUS_PWR_SAVE) ) &&
          ( nas_cached_info.lte_srv_status_info_valid && (nas_cached_info.lte_srv_status_info->srv_status == SYS_SRV_STATUS_PWR_SAVE) ) )
        ) ||
        ( ( nas_cached_info.cdma_srv_status_info_valid && (nas_cached_info.cdma_srv_status_info->srv_status == SYS_SRV_STATUS_PWR_SAVE) ) &&
        ( ( nas_cached_info.hdr_srv_status_info_valid && (nas_cached_info.hdr_srv_status_info->srv_status == SYS_SRV_STATUS_NO_SRV) ) &&
          ( nas_cached_info.lte_srv_status_info_valid && (nas_cached_info.lte_srv_status_info->srv_status == SYS_SRV_STATUS_NO_SRV) ) )
        )
      )
    {
      /* Not registered, but MT is currently searching a new operator to register to*/
      MSG_HIGH("NO SERVICE\n", 0, 0, 0);
      val_int = 2;
      snprintf(resp_ptr->registration_state, sizeof(resp_ptr->registration_state), "%d", val_int);
      return;
    }
  }

  // TODO: GSM/WCDMA
  /* Full service - GSM, WCDMA or LTE */
  if ( QMI_SRV_STATUS_INDICATES_GWL_FULL_SRV( nas_cached_info.lte_srv_status_info->srv_status, nas_cached_info.lte_srv_status_info_valid ) )
  {
    /* Data registration reporting, not registered on PS domain */
    if ( reporting_data_reg_state && nas_cached_info.lte_srv_status_info_valid &&
              ( ( nas_cached_info.lte_sys_info->common_sys_info.srv_capability == SYS_SRV_DOMAIN_CS_ONLY ) ||
              ( ( nas_cached_info.lte_sys_info->common_sys_info.srv_capability == SYS_SRV_DOMAIN_CS_PS ) &&
              !QMI_SRV_DOMAIN_SUPPORT_PS( nas_cached_info.lte_sys_info->common_sys_info.srv_domain ) ) ) )
    {
      /* Not registered, but MT is currently searching a new operator to register to*/
      MSG_HIGH("Not in PS domain, No Service\n", 0, 0, 0);
      val_int = 2;
    }
    /* Data registration reporting, registered on PS domain */
    else if ( reporting_data_reg_state && nas_cached_info.lte_srv_status_info_valid &&
              ( ( nas_cached_info.lte_sys_info->common_sys_info.srv_capability == SYS_SRV_DOMAIN_PS_ONLY ) ||
              ( ( nas_cached_info.lte_sys_info->common_sys_info.srv_capability == SYS_SRV_DOMAIN_CS_PS ) &&
              QMI_SRV_DOMAIN_SUPPORT_PS( nas_cached_info.lte_sys_info->common_sys_info.srv_domain ) ) ) )
    {
      if ( nas_cached_info.lte_sys_info->common_sys_info.roam_status == SYS_ROAM_STATUS_OFF )
      {
        /* Registered, home network */
        MSG_HIGH("Registered on Home network\n", 0, 0, 0);
        val_int = 1;
      }
      else
      {
        /* Registered, roaming */
        MSG_HIGH("Roaming\n", 0, 0, 0);
        val_int = 5;
      }
    }
    /* Voice registration reporting, Registered on PS domain but registration rejected 4 times in a row for CS domain */
    else if ( !reporting_data_reg_state && nas_cached_info.lte_srv_status_info_valid &&
              ( nas_cached_info.lte_sys_info->common_sys_info.srv_capability == SYS_SRV_DOMAIN_CS_PS ) && 
              ( nas_cached_info.lte_sys_info->common_sys_info.srv_domain == SYS_SRV_DOMAIN_PS_ONLY ) &&
              ( // TODO: ( reg_reject_info_ptr->managed_roaming_enabled ) ||
                ( nas_cached_info.lte_sys_info->threegpp_specific_sys_info.reg_reject_info.rej_cause > 0 ) ) )
    {
      /* Registration Denied */
      MSG_HIGH("Registration Denied: LIMITED SERVICE MODE\n", 0, 0, 0);
      val_int = 3;
    }
    /* For voice registration reporting, if not in CS domain, NO SERVICE */
    else if ( !reporting_data_reg_state && nas_cached_info.lte_srv_status_info_valid &&
              ( // TODO: !qcril_arb_voip_is_supported() &&
                ( !QMI_SRV_DOMAIN_SUPPORT_CS( nas_cached_info.lte_sys_info->common_sys_info.srv_domain ) ||
                  !QMI_SRV_CAPABILITY_SUPPORT_CS( nas_cached_info.lte_sys_info->common_sys_info.srv_capability ) ) ) )
    {
      /* Not registered, but MT is currently searching a new operator to register to*/
      MSG_HIGH("Not in CS domain, No Service\n", 0, 0, 0);
      val_int = 2;
    }
    /* For voice registration reporting, Registered on CS domain */
    else if ( !reporting_data_reg_state && nas_cached_info.lte_srv_status_info_valid &&
              ( // TODO: qcril_arb_voip_is_supported() ||
                ( ( nas_cached_info.lte_sys_info->common_sys_info.srv_capability == SYS_SRV_DOMAIN_CS_ONLY ) ||
                  ( ( nas_cached_info.lte_sys_info->common_sys_info.srv_capability == SYS_SRV_DOMAIN_CS_PS ) && 
                    ( nas_cached_info.lte_sys_info->common_sys_info.srv_domain == SYS_SRV_DOMAIN_CS_ONLY ) ) ||
                  ( ( nas_cached_info.lte_sys_info->common_sys_info.srv_capability == SYS_SRV_DOMAIN_CS_PS ) &&
                    ( nas_cached_info.lte_sys_info->common_sys_info.srv_domain == SYS_SRV_DOMAIN_CS_PS ) ) ) ) )
    {
      if ( nas_cached_info.lte_sys_info->common_sys_info.roam_status == SYS_ROAM_STATUS_OFF )
      {
        /* Registered, home network */
        MSG_HIGH("Registered on Home network\n", 0, 0, 0);
        val_int = 1;
      }
      else
      {
        /* Registered, roaming */
        MSG_HIGH("Roaming\n", 0, 0, 0);
        val_int = 5;
      }
    }
    else
    {
      MSG_HIGH("Invalid combination of fields.\n", 0, 0, 0);
      val_int = 4;
    }

    snprintf(resp_ptr->registration_state, sizeof(resp_ptr->registration_state), "%d", val_int);
    return;
  }

  /* Full service, non-hybrid, CDMA */
  if ( !nas_cached_info.hdr_hybrid &&
       QMI_SRV_STATUS_INDICATES_CDMA_FULL_SRV( nas_cached_info.cdma_srv_status_info->srv_status, nas_cached_info.cdma_srv_status_info_valid)  )
  {
    if ( nas_cached_info.cdma_sys_info->common_sys_info.roam_status == SYS_ROAM_STATUS_OFF )
    {
      /* Registered, home network */
      MSG_HIGH("Registered on Home network\n", 0, 0, 0);
      val_int = 1;
    }
    else
    {
      /* Registered, roaming */
      MSG_HIGH("Roaming\n", 0, 0, 0);
      val_int = 5;
    }

    snprintf(resp_ptr->registration_state, sizeof(resp_ptr->registration_state), "%d", val_int);
    return;
  }

  /* Full service, non-hybrid DO scenario */
  /* DO applicable only for data */
  if ( !nas_cached_info.hdr_hybrid &&
       QMI_SRV_STATUS_INDICATES_HDR_FULL_SRV( nas_cached_info.hdr_srv_status_info->srv_status, nas_cached_info.hdr_srv_status_info_valid ) 
      /* && reporting_data_reg_state */)
  {
    if ( nas_cached_info.hdr_sys_info->common_sys_info.roam_status == SYS_ROAM_STATUS_OFF )
    {
      /* Registered, home network */
      MSG_HIGH("Registered on Home network\n", 0, 0, 0);
      val_int = 1;
    }
    else
    {
      /* Registered, roaming */
      MSG_HIGH("Roaming\n", 0, 0, 0);
      val_int = 5;
    }

    snprintf(resp_ptr->registration_state, sizeof(resp_ptr->registration_state), "%d", val_int);
    return;
  }

  MSG_HIGH("hdr hybrid [%d]", nas_cached_info.hdr_hybrid, 0, 0);
  /* Full service, hybrid, CDMA or DO scenario */
  if ( nas_cached_info.hdr_hybrid )
  {
    /* Full service on HDR (both voice and data), IDM is only meaningful for SVDO */
    if ( QMI_SRV_STATUS_INDICATES_FULL_SRV( nas_cached_info.hdr_srv_status_info->srv_status ) &&
         ( ( nas_cached_info.mode_pref != QMI_NAS_RAT_MODE_PREF_CDMA_HRPD ) || 
           nas_cached_info.hdr_srv_status_info_valid)/* &&
         reporting_data_reg_state */) //BKS_20131125 
    {
      /* Use hdr_roam_status to determine if AT is roaming */
      if ( nas_cached_info.hdr_sys_info->common_sys_info.roam_status == SYS_ROAM_STATUS_OFF )
      {
        /* Registered, home network */
        MSG_HIGH("Registered on Home network(Hybrid)\n", 0, 0, 0);
        val_int = 1;
      }
      else
      {
        /* Registered, roaming */
        MSG_HIGH("Roaming(Hybrid)\n", 0, 0, 0);
        val_int = 5;
      }

      snprintf(resp_ptr->registration_state, sizeof(resp_ptr->registration_state), "%d", val_int);
      return;
    }

    /* Full service on CDMA (both voice and data), IDM is only meaning for standalone SVDO */
    if ( QMI_SRV_STATUS_INDICATES_CDMA_FULL_SRV( nas_cached_info.cdma_srv_status_info->srv_status, nas_cached_info.cdma_srv_status_info_valid) &&
         ( ( nas_cached_info.mode_pref != QMI_NAS_RAT_MODE_PREF_CDMA_HRPD ) || 
           nas_cached_info.cdma_srv_status_info_valid ) )
    {
      if ( nas_cached_info.cdma_sys_info->common_sys_info.roam_status == SYS_ROAM_STATUS_OFF )
      {
        /* Registered, home network */
        MSG_HIGH("Registered on Home network(Main)\n", 0, 0, 0);
        val_int = 1;
      }
      else
      {
        /* Registered, roaming */
        MSG_HIGH("Roaming(Main)\n", 0, 0, 0);
        val_int = 5;
      }

      snprintf(resp_ptr->registration_state, sizeof(resp_ptr->registration_state), "%d", val_int);
      return;
    }

    /* DO acquisition still in progress, not registered for Data Registration State */
    if ( QMI_SRV_STATUS_INDICATES_CDMA_FULL_SRV( nas_cached_info.cdma_srv_status_info->srv_status, nas_cached_info.cdma_srv_status_info_valid ) &&  
         ( nas_cached_info.mode_pref == QMI_NAS_RAT_MODE_PREF_CDMA_HRPD ) && !reporting_data_reg_state )
    {
      if ( nas_cached_info.cdma_sys_info->common_sys_info.roam_status == SYS_ROAM_STATUS_OFF )
      {
        /* Registered, home network */
        MSG_HIGH("Registered on Home network(Main)\n", 0, 0, 0);
        val_int = 1;
      }
      else
      {
        /* Registered, roaming */
        MSG_HIGH("Roaming(Main)\n", 0, 0, 0);
        val_int = 5;
      }

      snprintf(resp_ptr->registration_state, sizeof(resp_ptr->registration_state), "%d", val_int);
      return;
    }
// TODO:
/*
    else if ( !QCRIL_CM_SYS_MODE_IS_GW( ssi_ptr->sys_mode ) )
    {
      MSG_HIGH("NO SERVICE - Hybrid, DO acquisition in progress\n", 0, 0, 0);
      val_int = 2;
      snprintf(resp_ptr->registration_state, sizeof(resp_ptr->registration_state), "%d", val_int);
      return;
    }
*/
  }

  // TODO: GSM / WCDMA
  /* Limited service, GSM, WCDMA or LTE */
  if ( ( ( nas_cached_info.lte_srv_status_info->srv_status == SYS_SRV_STATUS_LIMITED ) ||
         ( nas_cached_info.lte_srv_status_info->srv_status == SYS_SRV_STATUS_LIMITED_REGIONAL ) ) &&
       nas_cached_info.lte_srv_status_info_valid )
  {
    if ( reporting_data_reg_state && ( nas_cached_info.lte_sys_info->common_sys_info.srv_capability != SYS_SRV_DOMAIN_CAMPED ) )
    {
      MSG_HIGH("NO SERVICE\n", 0, 0, 0);
      val_int = 2;
    }
    else if ( !reporting_data_reg_state && QMI_SRV_CAPABILITY_SUPPORT_CS( nas_cached_info.lte_sys_info->common_sys_info.srv_capability ) )
    {
      if ( // TODO: ( reg_reject_info_ptr->managed_roaming_enabled ) || 
           ( nas_cached_info.lte_sys_info->threegpp_specific_sys_info.reg_reject_info.rej_cause > 0 ) )
      {
        /* Registration Denied */
        MSG_HIGH("Registration Denied: LIMITED SERVICE MODE\n", 0, 0, 0);
        val_int = 3;
      }
      else
      {
        /* Not registered, but MT is currently searching a new operator to register to*/
        MSG_HIGH("NO SERVICE\n", 0, 0, 0);
        val_int = 2;
      }
    }
    else if ( !reporting_data_reg_state && ( nas_cached_info.lte_sys_info->common_sys_info.srv_capability == SYS_SRV_DOMAIN_PS_ONLY ) )
    {
      MSG_HIGH("NO SERVICE\n", 0, 0, 0);
      val_int = 2;
    }
    else
    {
      MSG_HIGH("Invalid srv capability with srv status limited.\n", 0, 0, 0);
      val_int = 4;
    }

    snprintf(resp_ptr->registration_state, sizeof(resp_ptr->registration_state), "%d", val_int);
    return;
  }

  /* Limited service, CDMA or HDR scenario */
  if ( ( ( nas_cached_info.cdma_srv_status_info->srv_status == SYS_SRV_STATUS_LIMITED ) ||
         ( nas_cached_info.cdma_srv_status_info->srv_status == SYS_SRV_STATUS_LIMITED_REGIONAL ) ||
         ( nas_cached_info.hdr_srv_status_info->srv_status == SYS_SRV_STATUS_LIMITED ) ||
         ( nas_cached_info.hdr_srv_status_info->srv_status == SYS_SRV_STATUS_LIMITED_REGIONAL ) ) &&
       (nas_cached_info.cdma_srv_status_info_valid || nas_cached_info.hdr_srv_status_info_valid) )
  {
    /* No service */
    MSG_HIGH("NO SERVICE\n", 0, 0, 0);
    val_int = 2;
    snprintf(resp_ptr->registration_state, sizeof(resp_ptr->registration_state), "%d", val_int);
    return;
  }
         
  if ( val_int == 4 )
  {
    /* Unknown */
    MSG_HIGH("Unknown Registration State\n", 0, 0, 0);
  }

} /* qmi_srv_sys_info_to_reg_state */

/*=========================================================================
  FUNCTION:  qmi_srv_sys_info_to_gw_sys_info

===========================================================================*/
/*!
    @brief
    Convert the LAC and CID to GW system info

    @return
    None.
*/
/*=========================================================================*/
void qmi_srv_sys_info_to_gw_sys_info
(
  qmi_nas_registration_state_resp_helper_type *resp_ptr
)
{
  nas_sys_info_helper_type sys_info_helper;
  int len;

  /*-----------------------------------------------------------------------*/

  QCRIL_ASSERT( resp_ptr != NULL );

  /*-----------------------------------------------------------------------*/

  memset(&sys_info_helper, 0x0, sizeof(nas_sys_info_helper_type));

  /* Only if registered on network, we report GW system info */
  if ( ( strcmp( resp_ptr->registration_state, "1" ) == 0 ) || ( strcmp( resp_ptr->registration_state, "5" ) == 0 ) )
  {
    MSG_HIGH( " qmi_srv_sys_info_to_gw_sys_info : LTE", 0, 0, 0 );
    if ( NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.lte_srv_status_info ) )
    {
      sys_info_helper.threegpp_srv_status  = nas_cached_info.lte_srv_status_info;
    }

    if ( NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.lte_sys_info ) )
    {
      sys_info_helper.common_sys_info  = &nas_cached_info.lte_sys_info->common_sys_info;
      sys_info_helper.threegpp_only_sys_info = &nas_cached_info.lte_sys_info->threegpp_specific_sys_info;
    }

// TODO: GSM / WCDMA
#if 0
    /* LAC and CID are only available if current operator is GSM/WCDMA */
    if ( QCRIL_CM_SRV_STATUS_INDICATES_GW_FULL_SRV( ssi_ptr->srv_status, ssi_ptr->sys_mode ) )
    {
      len = QCRIL_SNPRINTF( buf_lac_ptr, QCRIL_CM_LAC_ASCII_MAX_LEN, "%04x", ssi_ptr->sys_id.id.plmn_lac.lac );
      QCRIL_ASSERT( len <= QCRIL_CM_LAC_ASCII_MAX_LEN );
      *lac_ptr = buf_lac_ptr;

      /* Android only takes CID from 0x00000000 - 0x7fffffff*/
      if ( ssi_ptr->cell_info.cell_id > 0x7FFFFFFF )
      {
        len = QCRIL_SNPRINTF( buf_cid_ptr, QCRIL_CM_CID_ASCII_MAX_LEN, "%08x", 0x7FFFFFFF );
      }
      else
      {
        len = QCRIL_SNPRINTF( buf_cid_ptr, QCRIL_CM_CID_ASCII_MAX_LEN, "%08lx", ssi_ptr->cell_info.cell_id );
      }
      QCRIL_ASSERT( len <= QCRIL_CM_CID_ASCII_MAX_LEN );
      *cid_ptr = buf_cid_ptr;

      if ( QCRIL_CM_SRV_STATUS_INDICATES_WCDMA_FULL_SRV( ssi_ptr->srv_status, ssi_ptr->sys_mode ) )
      {
        if ( ssi_ptr->cell_info.psc > 0 )
        {
          len = QCRIL_SNPRINTF( buf_psc_ptr, QCRIL_CM_PSC_HEX_MAX_LEN, "%03x", ssi_ptr->cell_info.psc );
          QCRIL_ASSERT( len <= QCRIL_CM_PSC_HEX_MAX_LEN );
          *psc_ptr = buf_psc_ptr;
        }
      }
    }
    else
#endif
    /* TAC is only available if current operator is LTE */
    if ( QMI_SRV_STATUS_INDICATES_LTE_FULL_SRV( nas_cached_info.lte_srv_status_info->srv_status, nas_cached_info.lte_srv_status_info_valid) )
    {
      if( nas_cached_info.lte_sys_info->lte_specific_sys_info.tac_valid )
      {   
        len = snprintf( resp_ptr->lac, 7, "%04x", (unsigned int) nas_cached_info.lte_sys_info->lte_specific_sys_info.tac );
        QCRIL_ASSERT( len <= 7 );
      }
    }
  }
} /* qmi_srv_sys_info_to_gw_sys_info */

/*=========================================================================
  FUNCTION:  qmi_srv_sys_info_to_rej_cause

===========================================================================*/
/*!
    @brief
    Function returns the registration reject cause

    @return
    registration reject cause when in limited service 
    
*/
/*=========================================================================*/
void qmi_srv_sys_info_to_rej_cause
(
  qmi_nas_registration_state_resp_helper_type *resp_ptr,
  boolean reporting_data_reg_state
)
{
  uint8 reg_reject_cause;

  /*-----------------------------------------------------------------------*/

  QCRIL_ASSERT( resp_ptr != NULL );
  
  /*-----------------------------------------------------------------------*/

  /* Default Reject Cause */
  reg_reject_cause = 0; /* Unspecified failure */

#if 0 // TODO: VZW
  /* only when the registration state is limited and reject cause is availabe
       send the reject cause */
  if ( ( ssi_ptr != NULL ) && QMI_SYS_MODE_IS_GW( ssi_ptr->sys_mode ) )
  {
    MSG_HIGH( "Reject cause value = %d, Registration status = %s\n", reg_reject_info_ptr->cm_reg_reject_info.reject_cause,
               qmi_lookup_reg_status( *reg_state_ptr ) );
     
    /* reporting reject cause only when reject cause is valid and it is not already reported even once */
    if ( strcmp( resp_ptr->registration_state, "3" ) == 0 )
    {
      if ( reg_reject_info_ptr->managed_roaming_enabled )
      {
        reg_reject_cause = 10; /*Managed Roaming Specific Cause*/
        MSG_HIGH( "Reject cause value sent to UI = %d\n", reg_reject_cause );
        reg_reject_info_ptr->managed_roaming_enabled = FALSE;
        return;
      }
       
      if ( reg_reject_info_ptr->cm_reg_reject_info.reject_cause > 0 )
      {
        if ( !reg_reject_info_ptr->reg_reject_reported )
        {
          if ( !reporting_data_reg_state &&
               ( ( reg_reject_info_ptr->cm_reg_reject_info.reject_srv_domain == SYS_SRV_DOMAIN_CS_ONLY ) ||
                 ( reg_reject_info_ptr->cm_reg_reject_info.reject_srv_domain == SYS_SRV_DOMAIN_CS_PS ) ) )
          {
            MSG_HIGH( "Reject cause reported to UI = %d, data_reg_state = %d\n",
                                      reg_reject_info_ptr->cm_reg_reject_info.reject_cause, reporting_data_reg_state, 0 );
      
            switch ( reg_reject_info_ptr->cm_reg_reject_info.reject_cause )
            {
              case 255 : /*Authentication rejected*/
                reg_reject_cause = 1;
                break;
              case 2 :  /*IMSI unknown in HLR*/
              case 3 :  /*Illegal MS*/
              case 4 :  /*IMSI unknown in VLR*/
              case 5 :  /*IMEI not accepted*/
              case 6:   /*Illegal ME*/
              case 11:  /*PLMN not allowed*/
              case 12:  /*Location Area not allowed*/
              case 13:  /*Roaming not allowed in this location area*/
              case 15:  /*No Suitable Cells in this Location Area*/
              case 17:  /*Network failure */
              case 20:  /*MAC Failure*/
              case 21:  /*Sync Failure */
              case 22:  /*Congestion */
              case 23:  /*GSM Authentication unacceptable */
              case 25:  /*Not Authorized for this CSG*/
              case 32:  /*Service option not supported */
              case 33:  /*Requested service option not subscribed */
              case 34:  /*Service option temporarily out of order */
              case 38:  /*Call cannot be identified */
                reg_reject_cause = reg_reject_info_ptr->cm_reg_reject_info.reject_cause;
                break;
              case 48 ... 63:  /*Retry upon entry into a new cell */
                reg_reject_cause = 48;
                break;
              case 95:  /*Semantically incorrect message */
              case 96:  /*Network failure */
              case 97:  /*Network failure */
              case 98:  /*Network failure */
              case 99:  /*Network failure */
              case 100: /*Network failure */
              case 101: /*Message not compatible with protocol state */
              case 111: /* Protocol error, unspecified */
                reg_reject_cause = reg_reject_info_ptr->cm_reg_reject_info.reject_cause;
                break;
              default:  /*Unspecified failure*/
                reg_reject_cause = 0;
                break;
            }

            if ( reg_reject_info_ptr->cm_reg_reject_info.reject_srv_domain == SYS_SRV_DOMAIN_CS_ONLY )
            {
              reg_reject_info_ptr->reg_reject_reported = TRUE;              
            }
          }
          else if ( reporting_data_reg_state &&
                    ( ( reg_reject_info_ptr->cm_reg_reject_info.reject_srv_domain == SYS_SRV_DOMAIN_PS_ONLY ) ||
                      ( reg_reject_info_ptr->cm_reg_reject_info.reject_srv_domain == SYS_SRV_DOMAIN_CS_PS ) ) )
          {
            switch ( reg_reject_info_ptr->cm_reg_reject_info.reject_cause )
            {
              case 7 :  /*Illegal MS*/
              case 8 :  /*IMSI unknown in VLR*/
              case 9 :  /*IMEI not accepted*/
              case 10:  /*Illegal ME*/
              case 14:  /*Roaming not allowed in this location area*/
              case 16:  /*No Suitable Cells in this Location Area*/
              case 40:  /*Call cannot be identified */
                reg_reject_cause = reg_reject_info_ptr->cm_reg_reject_info.reject_cause;
                break;
              default:  /*Unspecified failure*/
                reg_reject_cause = 0;
                break;
            }
            reg_reject_info_ptr->reg_reject_reported = TRUE;
          }
        }
        else
        {
          reg_reject_cause = 0; /*Unspecified failure*/
        }
      }
    }/* resetting the reject cause on full service */
    else if ( ( ( strcmp( resp_ptr->registration_state, "1" ) == 0 ) || ( strcmp( resp_ptr->registration_state, "5" ) == 0 ) ) &&
              ( reg_reject_info_ptr->cm_reg_reject_info.reject_cause > 0 ) )
    {
      reg_reject_info_ptr->cm_reg_reject_info.reject_cause = 0;
      reg_reject_info_ptr->cm_reg_reject_info.reject_srv_domain = SYS_SRV_DOMAIN_NONE;
      reg_reject_info_ptr->reg_reject_reported = FALSE;
    }
  }
#endif

  snprintf( resp_ptr->reg_reject_cause, sizeof(resp_ptr->reg_reject_cause), "%d", reg_reject_cause );
  
  MSG_HIGH( "Reject cause value sent to UI = %s\n", resp_ptr->reg_reject_cause, 0, 0);

}/* qmi_srv_sys_info_to_rej_cause */

/*=========================================================================
  FUNCTION:  qmi_nas_query_avail_radio_tech

===========================================================================*/
int qmi_nas_query_avail_radio_tech(boolean reporting_data_reg_state)
{
  int avail_radio_tech = 0;

  LOGD("[qmi_nas_query_avail_radio_tech]");
  if ( QMI_SRV_STATUS_INDICATES_LTE_FULL_SRV( nas_cached_info.lte_srv_status_info->srv_status,  nas_cached_info.lte_srv_status_info_valid) )
  {
    /* LTE is the available radio technology */
    LOGD("LTE System\n"); 
    avail_radio_tech = 14;
  } 

  /* HDR only or HDR hybrid */
  else if ( ( !nas_cached_info.hdr_hybrid &&
              QMI_SRV_STATUS_INDICATES_HDR_FULL_SRV( nas_cached_info.hdr_srv_status_info->srv_status, nas_cached_info.hdr_srv_status_info_valid) ) ||  
            ( QMI_SRV_STATUS_INDICATES_HYBRID_HDR_FULL_SRV( nas_cached_info.hdr_hybrid, nas_cached_info.hdr_srv_status_info->srv_status ) && 
              ( ( nas_cached_info.mode_pref != QMI_NAS_RAT_MODE_PREF_CDMA_HRPD ) || nas_cached_info.hdr_srv_status_info_valid ) ) ) 
  {
    /* HDR only, or Hybrid and HDR is available */
    LOGD ( "HDR System : HDR active prot %d, HDR srv_status %d\n", 
                      nas_cached_info.hdr_sys_info->hdr_specific_sys_info.hdr_active_prot,
                      nas_cached_info.hdr_srv_status_info->srv_status );

    LOGD ( "HDR System : HDR personality %d\n", nas_cached_info.hdr_sys_info->hdr_specific_sys_info.hdr_personality ); 
    if ( nas_cached_info.hdr_sys_info->hdr_specific_sys_info.hdr_personality == NAS_SYS_PERSONALITY_EHRPD_V01 )
    {
      /* eHRPD is the available radio technology */
      LOGD( "eHRPD System\n" ); 
      avail_radio_tech = 13;
    }
    else if ( nas_cached_info.hdr_sys_info->hdr_specific_sys_info.hdr_active_prot == NAS_SYS_ACTIVE_PROT_HDR_RELA_V01 ) 
    {
      /* EVDO Rev. A is the available radio technology */
      LOGD( "EVDO Rel A System\n" ); 
      avail_radio_tech = 8;
    }
    else if ( nas_cached_info.hdr_sys_info->hdr_specific_sys_info.hdr_active_prot == NAS_SYS_ACTIVE_PROT_HDR_REL0_V01 ) 
    {
      /* Default to EVDO Rev. 0 as the available radio technology */
      LOGD( "EVDO Rel 0 System\n" ); 
      avail_radio_tech = 7;
    }
    else
    {
      LOGD( "EVDO System, personality negotiation in progress\n" ); 
      avail_radio_tech = 7; // TODO: VZW 0;

      // change data registration state to unknown, for the time personality negotiation in progress.
      if( reporting_data_reg_state )
      {
        //avail_radio_tech = 4;
      }
    }
  } /* end if HDR */

  /* CDMA only or CDMA hybrid */
  else if ( QMI_SRV_STATUS_INDICATES_CDMA_FULL_SRV( nas_cached_info.cdma_srv_status_info->srv_status, nas_cached_info.cdma_srv_status_info_valid) )
  {
    /* CDMA only or hybrid and only CDMA is available */
    LOGD ( "1X System : CDMA prev %d, srv_status %d, HDR srv_status %d\n", 
                      nas_cached_info.cdma_sys_info->cdma_specific_sys_info.bs_p_rev,
                      nas_cached_info.cdma_srv_status_info->srv_status,
                      nas_cached_info.hdr_srv_status_info->srv_status );

    if ( nas_cached_info.cdma_sys_info->cdma_specific_sys_info.bs_p_rev >= 6 )
    { 
      /* 1xRTT is the available radio technology */
      avail_radio_tech = 6;
    }
    else if ( nas_cached_info.cdma_sys_info->cdma_specific_sys_info.bs_p_rev >= 4 )
    {
      /* IS95B is the available radio technology */
      avail_radio_tech = 5;
    }
    else
    {
      /* IS95A is the available radio technology */
      avail_radio_tech = 4;
    }
  }

  LOGD("[qmi_nas_query_avail_radio_tech]nas_cached_info.radio_tech = %d , avail_radio_tech=%d", nas_cached_info.radio_tech,avail_radio_tech);

  if( nas_cached_info.radio_tech != avail_radio_tech )
  {
    LOGD("[qmi_nas_query_avail_radio_tech]RIL_UNSOL_RESPONSE_NETWORK_STATE_CHANGED");
    //Send_UnsolicitedResponse( RIL_UNSOL_RESPONSE_NETWORK_STATE_CHANGED, NULL, 0 );
  }
  nas_cached_info.radio_tech = avail_radio_tech;

  return avail_radio_tech;
}

/*=========================================================================
  FUNCTION:  qmi_srv_sys_info_to_avail_radio_tech

===========================================================================*/
/*!
    @brief
    Convert the serving status, system mode, service domain and EGPRS 
    support info to available radio technology info.

    @return
    None.
*/
/*=========================================================================*/
void qmi_srv_sys_info_to_avail_radio_tech
(
  boolean reporting_data_reg_state,
  qmi_nas_registration_state_resp_helper_type *resp_ptr
)
{
  int avail_radio_tech;

  /*-----------------------------------------------------------------------*/

  QCRIL_ASSERT( resp_ptr != NULL );

  /*-----------------------------------------------------------------------*/

  MSG_HIGH("qmi_srv_sys_info_to_avail_radio_tech()", 0, 0, 0);

  /* Default to unknown available radio technology */
  avail_radio_tech = 0;

  /* Only if registered on network, we report radio tech */
  if ( ( strcmp( resp_ptr->registration_state, "1" ) == 0 ) || ( strcmp( resp_ptr->registration_state, "5" ) == 0 ) )
  {
    avail_radio_tech = qmi_nas_query_avail_radio_tech(reporting_data_reg_state);
  }

  snprintf(resp_ptr->radio_tech, sizeof(resp_ptr->radio_tech), "%d", avail_radio_tech);
  MSG_HIGH("resp_ptr->radio_tech %s", resp_ptr->radio_tech, 0, 0);
} /* qmi_srv_sys_info_to_avail_radio_tech */

/*=========================================================================
  FUNCTION:  qmi_srv_sys_info_to_1xevdo_sys_info

===========================================================================*/
/*!
    @brief
    Convert the 1XEVDO system info

    @return
    None.
*/
/*=========================================================================*/
void qmi_srv_sys_info_to_1xevdo_sys_info
(
  qmi_nas_registration_state_resp_helper_type *resp_ptr
)
{
  nas_sys_info_helper_type sys_info_helper;
  int len;
  uint8 val_int;
  

  /*-----------------------------------------------------------------------*/

  QCRIL_ASSERT( resp_ptr != NULL );

  /*-----------------------------------------------------------------------*/

  memset(&sys_info_helper, 0, sizeof(sys_info_helper));

  if ( ( strcmp( resp_ptr->registration_state, "1" ) == 0 ) || ( strcmp( resp_ptr->registration_state, "5" ) == 0 ) )
  {
    if ( QMI_SRV_STATUS_INDICATES_1XEVDO_FULL_SRV( nas_cached_info.cdma_srv_status_info->srv_status,
                                                   nas_cached_info.cdma_srv_status_info_valid,
                                                   nas_cached_info.hdr_srv_status_info_valid,
                                                   nas_cached_info.hdr_hybrid, 
                                                   nas_cached_info.hdr_srv_status_info->srv_status ) ) 
    {  
      /* Set BSID, BS Latitude, BS Longuitude, ccs supported, SID and NID for CDMA only */
      if ( QMI_SRV_STATUS_INDICATES_CDMA_FULL_SRV( nas_cached_info.cdma_srv_status_info->srv_status, nas_cached_info.cdma_srv_status_info_valid ) ) 
      {
        /* Set base_id */
        len = snprintf( resp_ptr->base_id, sizeof(resp_ptr->base_id), "%d", nas_cached_info.cdma_sys_info->cdma_specific_sys_info.bs_info.base_id );
        QCRIL_ASSERT( len <= 6 );

        /* Set base_latitude */
        len = snprintf( resp_ptr->base_latitude, sizeof(resp_ptr->base_latitude), "%ld", 
                         (long int)nas_cached_info.cdma_sys_info->cdma_specific_sys_info.bs_info.base_lat );
        QCRIL_ASSERT( len <= 12 );

        /* Set base_longitude */
        len = snprintf( resp_ptr->base_longitude, sizeof(resp_ptr->base_longitude), "%ld", 
                         (long int)nas_cached_info.cdma_sys_info->cdma_specific_sys_info.bs_info.base_long );
        QCRIL_ASSERT( len <= 12 );
        MSG_HIGH( "Base id: %d; Base latitude: %ld; Base longitude : %ld\n",
                         nas_cached_info.cdma_sys_info->cdma_specific_sys_info.bs_info.base_id,
                        (int32)nas_cached_info.cdma_sys_info->cdma_specific_sys_info.bs_info.base_lat,
                        (int32)nas_cached_info.cdma_sys_info->cdma_specific_sys_info.bs_info.base_long ); 

        /* Set ccs_supported */
        len = snprintf( resp_ptr->ccs, sizeof(resp_ptr->base_longitude), "%ld", 
                         (long int)nas_cached_info.cdma_sys_info->cdma_specific_sys_info.ccs_supported );
        QCRIL_ASSERT( len <= 4 );

        /* Set system_id */
        MSG_HIGH( "qmi_srv_sys_info_to_1xevdo_sys_info : 1xEVDO", 0, 0, 0 );
        if ( NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.cdma_sys_info ) )
        {                          
          sys_info_helper.common_sys_info = &nas_cached_info.cdma_sys_info->common_sys_info;
          sys_info_helper.cdma_only_sys_info = &nas_cached_info.cdma_sys_info->cdma_specific_sys_info;
          sys_info_helper.cdma_hdr_only_sys_info = &nas_cached_info.cdma_sys_info->cdma_hdr_only_sys_info;
        }

        if ( NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.hdr_sys_info ) )
        {
          sys_info_helper.common_sys_info = &nas_cached_info.hdr_sys_info->common_sys_info;
          sys_info_helper.cdma_hdr_only_sys_info = &nas_cached_info.hdr_sys_info->cdma_hdr_only_sys_info;
          sys_info_helper.hdr_only_sys_info = &nas_cached_info.hdr_sys_info->hdr_specific_sys_info;
        }

        if ( NULL != sys_info_helper.cdma_only_sys_info && sys_info_helper.cdma_only_sys_info->cdma_sys_id_valid  )
        {    
          NAS_CACHE_STORE_TINY_ENTRY( nas_cached_info.cdma_sys_id, sys_info_helper.cdma_only_sys_info->cdma_sys_id );
        }
        
        if ( NULL != sys_info_helper.cdma_hdr_only_sys_info && sys_info_helper.cdma_hdr_only_sys_info->is_sys_prl_match_valid )
        {
          NAS_CACHE_STORE_TINY_ENTRY( nas_cached_info.is_sys_prl_match, sys_info_helper.cdma_hdr_only_sys_info->is_sys_prl_match );                          
        }

        /* Set sid */
        len = snprintf( resp_ptr->sid, sizeof(resp_ptr->sid), "%d", (int) nas_cached_info.cdma_sys_id.sid );
        QCRIL_ASSERT( len <= 6 );

        /* Set nid */
        len = snprintf( resp_ptr->nid, sizeof(resp_ptr->nid), "%d", (int) nas_cached_info.cdma_sys_id.nid );
        QCRIL_ASSERT( len <= 6 );
      }

      /* Set Roam Status for HDR only or CDMA only */
      if ( NULL != sys_info_helper.common_sys_info && sys_info_helper.common_sys_info->roam_status_valid )
      {
        NAS_CACHE_STORE_TINY_ENTRY( nas_cached_info.roam_status, sys_info_helper.common_sys_info->roam_status );
        nas_cached_info.voice_roam_status_reported = TRUE;
      }

      if ( !nas_cached_info.hdr_hybrid &&
           ( QMI_SRV_STATUS_INDICATES_CDMA_FULL_SRV( nas_cached_info.cdma_srv_status_info->srv_status, nas_cached_info.cdma_srv_status_info_valid ) ||
             QMI_SRV_STATUS_INDICATES_HDR_FULL_SRV( nas_cached_info.hdr_srv_status_info->srv_status, nas_cached_info.hdr_srv_status_info_valid ) ) )
      {
        /* Always check if CDMA service is available first.  If it is, roam_status should be based on 1X. */
        if ( nas_cached_info.roam_status == SYS_ROAM_STATUS_OFF ) 
        {
          val_int = 1;
        }
        else if ( nas_cached_info.roam_status == SYS_ROAM_STATUS_ON ) 
        {
          val_int = 0;
        }
        else
        {
          val_int = nas_cached_info.roam_status;
        }
        MSG_HIGH( "Roam Status : %d\n", nas_cached_info.roam_status, 0, 0 );
        len = snprintf( resp_ptr->roam_status, sizeof(resp_ptr->roam_status), "%d", val_int );
        QCRIL_ASSERT( len <= 4 );
      }

      /* Set Roam Status for Hybrid and HDR only */
      else if( nas_cached_info.hdr_hybrid )
      {
        if( QMI_SRV_STATUS_INDICATES_FULL_SRV( nas_cached_info.hdr_srv_status_info->srv_status ) && 
            ( ( nas_cached_info.mode_pref != QMI_NAS_RAT_MODE_PREF_CDMA_HRPD ) || 
              nas_cached_info.hdr_srv_status_info_valid) ) 
        {
          if ( nas_cached_info.hdr_sys_info->common_sys_info.roam_status == SYS_ROAM_STATUS_OFF ) 
          {
            val_int = 1;
          }
          else if ( nas_cached_info.hdr_sys_info->common_sys_info.roam_status == SYS_ROAM_STATUS_ON ) 
          {
            val_int = 0;
          }
          else
          {
            val_int = nas_cached_info.hdr_sys_info->common_sys_info.roam_status;
          }
          MSG_HIGH( "HDR roam Status : %d\n", nas_cached_info.hdr_sys_info->common_sys_info.roam_status, 0, 0 );
          len = snprintf( resp_ptr->roam_status, sizeof(resp_ptr->roam_status), "%d", val_int );
          QCRIL_ASSERT( len <= 4 );
        }
        else
        {
          if( nas_cached_info.cdma_sys_info->common_sys_info.roam_status == SYS_ROAM_STATUS_OFF )
          {
            val_int = 1;
          }
          else if( nas_cached_info.cdma_sys_info->common_sys_info.roam_status == SYS_ROAM_STATUS_ON )
          {
            val_int = 0;
          }
          else
          {
            val_int = nas_cached_info.cdma_sys_info->common_sys_info.roam_status;
          }
          MSG_HIGH( "Roam Status : %d\n", nas_cached_info.cdma_sys_info->common_sys_info.roam_status, 0, 0 );
          len = snprintf( resp_ptr->roam_status, sizeof(resp_ptr->roam_status), "%d", nas_cached_info.cdma_sys_info->common_sys_info.roam_status );
          QCRIL_ASSERT( len <= 4 );
        }
      }

      /* Set PRL indicator */
        len = snprintf( resp_ptr->prl_ind, sizeof(resp_ptr->prl_ind), "%d", nas_cached_info.is_sys_prl_match );
        QCRIL_ASSERT( len <= 4 );
          
      /* Set Default Roaming Indicator */
      len = snprintf( resp_ptr->def_roam_ind, sizeof(resp_ptr->roam_status), "%d", nas_cached_info.def_roam_ind );
      QCRIL_ASSERT( len <= 4 );
      MSG_HIGH( "Is in PRL : %d; Default Roam Indicator : %d\n", nas_cached_info.is_sys_prl_match, nas_cached_info.def_roam_ind, 0 ); 
    }
  }
} /* qmi_srv_sys_info_to_1xevdo_sys_info */

/*=========================================================================
  FUNCTION:  qmi_prep_registration_state_report

===========================================================================*/
/*!
    @brief
    Prepare registration state report.

    @return
    None.
*/
/*=========================================================================*/
void qmi_prep_registration_state_report
(
  boolean                                     reporting_data_reg_state,
  qmi_nas_registration_state_resp_helper_type *payload_ptr
)
{
  /*-----------------------------------------------------------------------*/

  QCRIL_ASSERT( payload_ptr != NULL );

  /*-----------------------------------------------------------------------*/
  MSG_HIGH("qmi_prep_registration_state_report()", 0, 0, 0);

  qmi_srv_sys_info_to_reg_state( reporting_data_reg_state, payload_ptr );

  qmi_srv_sys_info_to_gw_sys_info( payload_ptr );

  qmi_srv_sys_info_to_rej_cause( payload_ptr, reporting_data_reg_state );

  qmi_srv_sys_info_to_avail_radio_tech ( reporting_data_reg_state, payload_ptr );

  qmi_srv_sys_info_to_1xevdo_sys_info( payload_ptr );
} /* qmi_prep_registration_state_report */

void qmi_nas_cleanup()
{
//BKS_20131202 
  // TODO: VZW NAS_CACHE_LOCK();
  NAS_CACHE_INVALIDATE_ENTRY(nas_cached_info.plmn_id);
  NAS_CACHE_INVALIDATE_ENTRY(nas_cached_info.short_name);
  NAS_CACHE_INVALIDATE_ENTRY(nas_cached_info.long_name);
  NAS_CACHE_INVALIDATE_ENTRY(nas_cached_info.cdma_srv_status_info);
  NAS_CACHE_INVALIDATE_ENTRY(nas_cached_info.hdr_srv_status_info);
  NAS_CACHE_INVALIDATE_ENTRY(nas_cached_info.lte_srv_status_info);
  NAS_CACHE_INVALIDATE_ENTRY(nas_cached_info.cdma_sys_info);
  NAS_CACHE_INVALIDATE_ENTRY(nas_cached_info.hdr_sys_info);
  NAS_CACHE_INVALIDATE_ENTRY(nas_cached_info.lte_sys_info);

  NAS_CACHE_INVALIDATE_TINY_ENTRY(nas_cached_info.cdma_sys_id);
  NAS_CACHE_INVALIDATE_TINY_ENTRY(nas_cached_info.is_sys_prl_match);
  NAS_CACHE_INVALIDATE_TINY_ENTRY(nas_cached_info.roam_status);
  NAS_CACHE_INVALIDATE_TINY_ENTRY(nas_cached_info.voice_support_on_lte);
  NAS_CACHE_INVALIDATE_TINY_ENTRY(nas_cached_info.emergency_mode);
  NAS_CACHE_INVALIDATE_TINY_ENTRY(nas_cached_info.mode_pref);
  NAS_CACHE_INVALIDATE_TINY_ENTRY(nas_cached_info.band_pref);
  NAS_CACHE_INVALIDATE_TINY_ENTRY(nas_cached_info.prl_pref);
  NAS_CACHE_INVALIDATE_TINY_ENTRY(nas_cached_info.roam_pref);
  NAS_CACHE_INVALIDATE_TINY_ENTRY(nas_cached_info.lte_band_pref);
  NAS_CACHE_INVALIDATE_TINY_ENTRY(nas_cached_info.net_sel_pref);
  // TODO: VZW NAS_CACHE_UNLOCK();

  qmi_ril_nwr_set_eme_cbm( QMI_RIL_EME_CBM_NOT_ACTIVE );
}

/*===========================================================================

  FUNCTION  qmi_nas_vzw_fetch_sys_info
  
===========================================================================*/
RIL_Errno qmi_nas_vzw_fetch_sys_info()
{
  RIL_Errno ril_req_res = RIL_E_GENERIC_FAILURE;
  
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_get_sys_info_resp_msg_v01 * qmi_response = NULL;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RIL_E_GENERIC_FAILURE;

  qmi_response = (nas_get_sys_info_resp_msg_v01 *)malloc( sizeof( *qmi_response ) );

  if( qmi_response )
  {
    rc = qmi_nas_get_sys_info_process((int)nas_client_handle, qmi_response, &qmi_err_code);
  
    if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
    {
      MSG_ERROR("[NAS]qmi_nas_get_regi_status!! rc: %d err_code : %d", rc, qmi_err_code, 0);
      ril_req_res = RIL_E_GENERIC_FAILURE;
    }
    else
    {
      ril_req_res = RIL_E_SUCCESS;
  
      NAS_CACHE_STORE_ENTRY( nas_cached_info.cdma_srv_status_info, qmi_response->cdma_srv_status_info, nas_3gpp2_srv_status_info_type_v01 );
      NAS_CACHE_STORE_ENTRY( nas_cached_info.hdr_srv_status_info, qmi_response->hdr_srv_status_info, nas_3gpp2_srv_status_info_type_v01 );
      // TODO: GSM / WCDMA srv status info
      NAS_CACHE_STORE_ENTRY( nas_cached_info.lte_srv_status_info, qmi_response->lte_srv_status_info, nas_3gpp_srv_status_info_type_v01 );
      NAS_CACHE_STORE_ENTRY( nas_cached_info.cdma_sys_info, qmi_response->cdma_sys_info, nas_cdma_sys_info_type_v01 );
      NAS_CACHE_STORE_ENTRY( nas_cached_info.hdr_sys_info, qmi_response->hdr_sys_info, nas_hdr_sys_info_type_v01 );
      // TODO: GSM / WCDMA sys info
      NAS_CACHE_STORE_ENTRY( nas_cached_info.lte_sys_info, qmi_response->lte_sys_info, nas_lte_sys_info_type_v01 );
      NAS_CACHE_STORE_TINY_ENTRY( nas_cached_info.voice_support_on_lte, qmi_response->voice_support_on_lte );

      MSG_HIGH("CDMA : is_pref_data_path %d", qmi_response->cdma_srv_status_info.is_pref_data_path , 0, 0);
    }

    if( qmi_response )
    {
      free(qmi_response);
    }
  }

  return ril_req_res;
}

/*===========================================================================

  FUNCTION  qmi_nas_vzw_request_registration_state
  
===========================================================================*/
void qmi_nas_vzw_request_registration_state(qmi_nas_registration_state_resp_helper_type *ril_resp_helper)
{
  int qmi_request_need1 = 0;
  RIL_Errno ril_req_res = RIL_E_GENERIC_FAILURE;

  qmi_modem_id_e_type cdma_modem_id, gw_modem_id, modem_id;
  qmi_nas_registration_state_resp_helper_type payload1_ptr, payload2_ptr;
  char *reg1_state_ptr, *reg2_state_ptr;
  int cnt;
  uint8 num_reg_state_records = 0;

  //BKS_20141203 recovery according to Mobis req. int avail_radio_tech; //BKS_20141001 add

  MSG_HIGH("qmi_nas_vzw_request_registration_state() start", 0, 0, 0);

  // ** response holder init
  memset( ril_resp_helper, 0, sizeof( qmi_nas_registration_state_resp_helper_type ) );

  //BKS_20141001 add
  /* Default to unknown available radio technology */
  //BKS_20141203 recovery according to Mobis req. avail_radio_tech = 0;
  //BKS_20141203 recovery according to Mobis req. avail_radio_tech = qmi_nas_query_avail_radio_tech(TRUE);

  {
    qmi_request_need1 = 
        (
        NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.cdma_srv_status_info ) &&
        NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.hdr_srv_status_info ) &&
        // TODO: NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.gsm_srv_status_info ) &&
        // TODO: NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.wcdma_srv_status_info ) &&
        NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.lte_srv_status_info ) &&
        NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.cdma_sys_info ) &&
        NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.hdr_sys_info ) &&
        // TODO: NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.gsm_sys_info ) &&
        // TODO: NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.wcdma_sys_info ) &&
        NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.lte_sys_info ) &&
        NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.voice_support_on_lte )
        ) ? FALSE : TRUE;

    MSG_HIGH("[NAS]qmi_nas_get_sys_info_process needed? %d", (int)qmi_request_need1, 0, 0);
    if(qmi_request_need1)
    {
      ril_req_res = qmi_nas_vzw_fetch_sys_info();
    }
    else
    {
      ril_req_res = RIL_E_SUCCESS;
    }

    if( RIL_E_SUCCESS == ril_req_res)
    {
      MSG_HIGH(" [NAS] srv_status cdma:%d, hdr:%d, lte:%d", NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.cdma_srv_status_info ), NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.hdr_srv_status_info ), 
                        NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.lte_srv_status_info ) );
#if 0 // TODO:
      MSG_HIGH(" ... gsm_srv_status_info val %d", NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.gsm_srv_status_info ), 0, 0 );
      MSG_HIGH(" ... wcdma_srv_status_info val %d", NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.wcdma_srv_status_info ), 0, 0 );
#endif
      MSG_HIGH_4(" [NAS] sys_info cdma: %d, hdr:%d, lte:%d, voice_support_on_lte:%d", NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.cdma_sys_info ), NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.hdr_sys_info ), 
                            NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.lte_sys_info ), NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.voice_support_on_lte ));
#if 0 // TODO:
      MSG_HIGH(" ... gsm_sys_info val %d", NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.gsm_sys_info ), 0, 0 );
      MSG_HIGH(" ... wcdma_sys_info val %d", NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.wcdma_sys_info ), 0, 0 );
#endif

      /* Lookup modem id for configured to serve voice service */
      qmi_arb_query_voice_tech_modem_id( nas_cached_info.mode_pref, &cdma_modem_id, &gw_modem_id );

      /* Report registration state */
      if ( cdma_modem_id != QMI_MAX_MODEM_ID ) 
      {
        modem_id = cdma_modem_id;
        memset(&payload1_ptr, 0, sizeof(qmi_nas_registration_state_resp_helper_type));
        qmi_prep_registration_state_report( FALSE, &payload1_ptr );
        num_reg_state_records = num_reg_state_records + 1;
        memcpy(ril_resp_helper, &payload1_ptr, sizeof(qmi_nas_registration_state_resp_helper_type));
      }

      if ( ( gw_modem_id != QMI_MAX_MODEM_ID ) && ( gw_modem_id != cdma_modem_id ) )
      {
        modem_id = gw_modem_id;
        memset(&payload2_ptr, 0, sizeof(qmi_nas_registration_state_resp_helper_type));
        qmi_prep_registration_state_report( TRUE, &payload2_ptr );
        num_reg_state_records = num_reg_state_records + 1;
        memcpy(ril_resp_helper, &payload2_ptr, sizeof(qmi_nas_registration_state_resp_helper_type));
      }

      MSG_HIGH("cdma_modem_id %d, gw_modem_id %d", cdma_modem_id, gw_modem_id, 0);
            
      /* Global device, split modem */
      if ( num_reg_state_records == 2 )
      {
        reg1_state_ptr = payload1_ptr.registration_state;
        reg2_state_ptr = payload2_ptr.registration_state;
    
        /*  for the following scenarios report MSM service state,
            Both MSM and MDM has no service,
            CDMA has full service, GW has no service,
            Both CDMA and GW has full service */

        memcpy(ril_resp_helper, &payload1_ptr, sizeof(qmi_nas_registration_state_resp_helper_type));
  
        /* GW has full service, CDMA has no service */
        if ( ( ( strcmp( reg2_state_ptr, "0" ) == 1 ) ||  ( strcmp( reg2_state_ptr, "5" ) == 0 ) ) &&
               ( ( strcmp( reg1_state_ptr, "0" ) == 0 ) ||  ( strcmp( reg1_state_ptr, "2" ) == 0 ) || 
               ( strcmp( reg1_state_ptr, "3" ) == 0 ) ) ) 
        {
          memcpy(ril_resp_helper, &payload2_ptr, sizeof(qmi_nas_registration_state_resp_helper_type));
        }
      }
#ifdef BOGUS
      else 
      {
        if ( cdma_modem_id != QMI_MAX_MODEM_ID ) 
        {
          memcpy(ril_resp_helper->registration_info_array, payload1_ptr->registration_info_array, sizeof(payload1_ptr->registration_info_array));
          //ril_resp_helper->registration_info_array = payload1_ptr->registration_info_array;
        }
        else
        {
          memcpy(ril_resp_helper->registration_info_array, payload2_ptr->registration_info_array, sizeof(payload2_ptr->registration_info_array));
          //ril_resp_helper->registration_info_array = payload2_ptr->registration_info_array;
        }
      }
#endif
    }
  }

#if 0 //BKS_20141203 recovery according to Mobis req.//BKS_20141001 modify RSSI Bar display according to Mobis requirement.
  MSG_HIGH("avail_radio_tech %d", avail_radio_tech, 0, 0);

  if(
  	(avail_radio_tech == 13) || // eHRPD
  	(avail_radio_tech == 8) ||   //EVDO Rel A
  	(avail_radio_tech == 7)       //EVDO Rel 0 
    )
   {
     int temp = 0;
   
     if(QMI_SRV_STATUS_INDICATES_HDR_FULL_SRV( nas_cached_info.hdr_srv_status_info->srv_status, nas_cached_info.hdr_srv_status_info_valid))// EVDO in service
     {
          if(nas_cached_info.cdma_srv_status_info_valid && 
		  	(nas_cached_info.cdma_srv_status_info->srv_status == SYS_SRV_STATUS_PWR_SAVE))//CDMA in power save
          {
              MSG_HIGH("power save!!!", 0, 0, 0);
          
               temp = 0;//power save
               snprintf(ril_resp_helper->registration_state, sizeof(ril_resp_helper->registration_state), "%d", temp);
          }

           if(nas_cached_info.cdma_srv_status_info_valid && 
		  	(nas_cached_info.cdma_srv_status_info->srv_status == SYS_SRV_STATUS_NO_SRV))//CDMA in no service
          {
            MSG_HIGH("searching state!!!", 0, 0, 0);
          
            temp = 2;//searching state 
            snprintf(ril_resp_helper->registration_state, sizeof(ril_resp_helper->registration_state), "%d", temp);
          }
     }
    }
#endif

  ril_resp_helper->registration_info_array[0] = ril_resp_helper->registration_state;
  ril_resp_helper->registration_info_array[1] = ril_resp_helper->lac;
  ril_resp_helper->registration_info_array[2] = ril_resp_helper->cid;
  ril_resp_helper->registration_info_array[3] = ril_resp_helper->radio_tech;
  ril_resp_helper->registration_info_array[4] = ril_resp_helper->base_id;
  ril_resp_helper->registration_info_array[5] = ril_resp_helper->base_latitude;
  ril_resp_helper->registration_info_array[6] = ril_resp_helper->base_longitude;
  ril_resp_helper->registration_info_array[7] = ril_resp_helper->ccs;
  ril_resp_helper->registration_info_array[8] = ril_resp_helper->sid;
  ril_resp_helper->registration_info_array[9] = ril_resp_helper->nid;
  ril_resp_helper->registration_info_array[10] = ril_resp_helper->roam_status;
  ril_resp_helper->registration_info_array[11] = ril_resp_helper->prl_ind;
  ril_resp_helper->registration_info_array[12] = ril_resp_helper->def_roam_ind;
  ril_resp_helper->registration_info_array[13] = ril_resp_helper->reg_reject_cause;
  // TODO:VZW ril_resp_helper->registration_info_array[14] = ril_resp_helper->primary_scrambling_code;

  // ** respond
  if ( RIL_E_SUCCESS == ril_req_res )
  {
    static char rg_log[255] = {0,};

    for ( cnt = 0; cnt < NAS_REG_STATE_RESP_MAX_ARR_SIZE ; cnt++ )
    {
      if ( ril_resp_helper->registration_info_array[cnt] )
      {
        //MSG_HIGH(".. rg %d - %s", (int) cnt, ril_resp_helper->registration_info_array[cnt], 0);
        
        if ( ! *ril_resp_helper->registration_info_array[cnt] )
        {
          ril_resp_helper->registration_info_array[cnt] = NULL;
        }
      }
    }
    sprintf(rg_log,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",
                          ril_resp_helper->registration_info_array[0],
                          ril_resp_helper->registration_info_array[1],
                          ril_resp_helper->registration_info_array[2],
                          ril_resp_helper->registration_info_array[3],
                          ril_resp_helper->registration_info_array[4],
                          ril_resp_helper->registration_info_array[5],
                          ril_resp_helper->registration_info_array[6],
                          ril_resp_helper->registration_info_array[7],
                          ril_resp_helper->registration_info_array[8],
                          ril_resp_helper->registration_info_array[9],
                          ril_resp_helper->registration_info_array[10],
                          ril_resp_helper->registration_info_array[11],
                          ril_resp_helper->registration_info_array[12],
                          ril_resp_helper->registration_info_array[13]);
    
    MSG_HIGH("REGISTRATION{%s}", rg_log, 0, 0);
  }

  //MSG_HIGH("qmi_nas_vzw_request_registration_state() end", 0, 0, 0);
}

/*===========================================================================

  FUNCTION  qmi_nas_set_vzw_config_sig_info2
  
===========================================================================*/
RIL_Errno qmi_nas_set_vzw_config_sig_info2()
{  
  RIL_Errno ril_req_res = RIL_E_GENERIC_FAILURE;
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  
  nas_006C_req_s nas_006C_req; 

 if(nas_client_handle == INVALID_HANDLE_VALUE)
  return RIL_E_GENERIC_FAILURE;
  
  memset(&nas_006C_req, 0, sizeof(nas_006C_req_s));

  //CDMA
  nas_006C_req.t11_valid = TRUE;
  nas_006C_req.t11.cdma_rssi_delta = 20; //RSSI delta (in units of 0.1 dBm),10 means 1dBm
  
  nas_006C_req.t13_valid = TRUE;
  nas_006C_req.t13.cdma_ecio_delta = 20; //ECIO delta (in units of 0.1 dBm),10 means 1dBm

  //HDR
  nas_006C_req.t15_valid = TRUE;
  nas_006C_req.t15.hdr_rssi_delta = 20; //HDR RSSI delta (in units of 0.1 dBm),10 means 1dBm

  nas_006C_req.t17_valid = TRUE;
  nas_006C_req.t17.hdr_ecio_delta = 20; //HDR ECIO delta (in units of 0.1 dBm),10 means 1dBm

  nas_006C_req.t19_valid = TRUE;
  nas_006C_req.t19.hdr_sinr_delta = 2; //HDR SINR delta (in units of 1 SINR level),1 means 1SINR Level

  //LTE
  nas_006C_req.t23_valid = TRUE;
  nas_006C_req.t23.lte_rssi_delta = 20; //RSSI delta (in units of 0.1 dBm),10 means 1dBm

  nas_006C_req.t25_valid = TRUE;
  nas_006C_req.t25.lte_snr_delta = 200; //SNR delta,100 means 1dBm
  
  nas_006C_req.t27_valid = TRUE;
  nas_006C_req.t27.lte_rsrq_delta = 20; //RSRQ delta (in units of 0.1 dBm),10 means 1dBm
  
  nas_006C_req.t29_valid = TRUE;
  nas_006C_req.t29.lte_rsrp_delta = 20; //RSRP delta (in units of 0.1 dBm),10 means 1dBm
  
  rc = qmi_nas_config_sig_info2((int)nas_client_handle,
                                           &nas_006C_req,
                                           &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_config_sig_info2!! rc: %d err_code : %d",rc,qmi_err_code, 0);
    ril_req_res = RIL_E_GENERIC_FAILURE;
  }
  else
  {
    ril_req_res = RIL_E_SUCCESS;
  }

  return ril_req_res;
}

/*===========================================================================

  FUNCTION  qmi_nas_set_config_sig_info2
  
===========================================================================*/
RIL_Errno qmi_nas_set_config_sig_info2()
{  
  RIL_Errno ril_req_res = RIL_E_GENERIC_FAILURE;
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  
  nas_006C_req_s nas_006C_req; 

 if(nas_client_handle == INVALID_HANDLE_VALUE)
  return RIL_E_GENERIC_FAILURE;
  
  memset(&nas_006C_req, 0, sizeof(nas_006C_req_s));
  if((wmm_get_vendor_type() == WMM_VENDOR_B_CHN ))  //Bosch Project
  {
    //GSM
    nas_006C_req.t1D_valid = TRUE;
    nas_006C_req.t1D.gsm_rssi_delta = 20; //RSSI delta (in units of 0.1 dBm),10 means 1dBm

    //WCDMA
    nas_006C_req.t1F_valid = TRUE;
    nas_006C_req.t1F.wcdma_rssi_delta = 20; //RSSI delta (in units of 0.1 dBm),10 means 1dBm

    nas_006C_req.t21_valid = TRUE;
    nas_006C_req.t21.wcdma_ecio_delta = 20; //ECIO delta (in units of 0.1 dBm),10 means 1dBm

    //LTE    
    nas_006C_req.t27_valid = TRUE;
    nas_006C_req.t27.lte_rsrq_delta = 20; //RSRQ delta (in units of 0.1 dBm),10 means 1dBm
    
    nas_006C_req.t29_valid = TRUE;
    nas_006C_req.t29.lte_rsrp_delta = 20; //RSRP delta (in units of 0.1 dBm),10 means 1dBm

    //TD-SCDMA    
    nas_006C_req.t2C_valid = TRUE;
    nas_006C_req.t2C.tdscdma_rscp_delta = 20; //RSCP delta (in units of 0.1 dBm),10 means 1dBm
  }
  else
  {
  /*****************************************  
  1. change NAS message to indicate Signal information. 
  2. But, don't change the delta value.
  NAS_0002_REQ_T13_REPORT_RSSI_DELTA=2
  NAS_0002_REQ_T14_REPORT_ECIO_DELTA=2
  NAS_0002_REQ_T18_REPORT_RSRQ_DELTA=2
  NAS_0002_REQ_T1B_REPORT_LTE_SNR_DELTA=2
  NAS_0002_REQ_T1C_REPORT_LTE_RSRP_DELTA=2
 *****************************************/
  //WCDMA
  nas_006C_req.t1F_valid = TRUE;
  nas_006C_req.t1F.wcdma_rssi_delta = 20; //RSSI delta (in units of 0.1 dBm),10 means 1dBm

  nas_006C_req.t21_valid = TRUE;
  nas_006C_req.t21.wcdma_ecio_delta = 20; //ECIO delta (in units of 0.1 dBm),10 means 1dBm

  //LTE
  nas_006C_req.t23_valid = TRUE;
  nas_006C_req.t23.lte_rssi_delta = 20; //RSSI delta (in units of 0.1 dBm),10 means 1dBm

  nas_006C_req.t25_valid = TRUE;
  nas_006C_req.t25.lte_snr_delta = 200; //SNR delta (in units of 0.1 dBm),10 means 1dBm
  
  nas_006C_req.t27_valid = TRUE;
  nas_006C_req.t27.lte_rsrq_delta = 20; //RSRQ delta (in units of 0.1 dBm),10 means 1dBm
  
  nas_006C_req.t29_valid = TRUE;
  nas_006C_req.t29.lte_rsrp_delta = 20; //RSRP delta (in units of 0.1 dBm),10 means 1dBm
  } 
  
  rc = qmi_nas_config_sig_info2((int)nas_client_handle,
                                           &nas_006C_req,
                                           &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_config_sig_info2!! rc: %d err_code : %d",rc,qmi_err_code, 0);
    ril_req_res = RIL_E_GENERIC_FAILURE;
  }
  else
  {
    ril_req_res = RIL_E_SUCCESS;
  }

  return ril_req_res;
}

/*===========================================================================

  FUNCTION  ril_request_vzw_get_registration_status
  
===========================================================================*/
uint8 ril_request_vzw_get_registration_status(int request, qmi_nas_registration_state_resp_helper_type *ril_resp_helper)
{
  if (request == REQ_REGI_STATE_FROM_CACHE)
  {
    qmi_nas_vzw_request_registration_state(ril_resp_helper);
  }
  else if(request == REQ_DATA_REGI_STATE_FROM_CACHE)
  {
  }

  return RESULT_SUCCESS;
}

/*===========================================================================

  FUNCTION  ril_request_get_registration_status
  
===========================================================================*/
uint8 ril_request_get_registration_status(int request, tof_registration_status_type *response)
{
#if 1
   // RIL_REQUEST_REGISTRATION_STATE
  if (request == REQ_REGI_STATE_FROM_CACHE)
  {
    response->reg_status   = registration_status.reg_status;
    response->lac          = registration_status.lac;
    response->cell_id      = registration_status.cell_id;
    response->rat          = registration_status.rat;
    response->reject_cause = registration_status.reject_cause;
  }
  // RIL_REQUEST_GPRS_REGISTRATION_STATE
  else if(request == REQ_DATA_REGI_STATE_FROM_CACHE)
  {
    response->reg_status   = registration_status.gprs_status;
    response->lac          = registration_status.lac;
    response->cell_id      = registration_status.cell_id;
    response->rat          = registration_status.rat;
    response->reject_cause = registration_status.reject_cause;
  }
  else
  {
    response->reg_status   = registration_status.reg_status;
    response->lac          = registration_status.lac;
    response->cell_id      = registration_status.cell_id;
    response->rat          = registration_status.rat;
    response->reject_cause = registration_status.reject_cause;
  }
#else
  // RIL_REQUEST_VOICE_REGISTRATION_STATE
  if (request == REQ_REGI_STATE_FROM_CACHE)
  {
    MSG_HIGH_4("gprs_status =%d, lac =%x, cell_id =%x, rat =%d \n",registration_status.reg_status, registration_status.lac,
                                                registration_status.cell_id,registration_status.rat);
    asprintf(&response[0],  "%d", registration_status.reg_status);
    asprintf(&response[1],  "%x", registration_status.lac);
    asprintf(&response[2],  "%x", registration_status.cell_id);
    asprintf(&response[3],  "%d", registration_status.rat);
    asprintf(&response[13], "%d", registration_status.reject_cause);
    
    *rsp_count = 14;
  }
  // RIL_REQUEST_DATA_REGISTRATION_STATE
  else if(request == REQ_DATA_REGI_STATE_FROM_CACHE)
  {
    MSG_HIGH_4("gprs_status =%d, lac =%x, cell_id =%x, rat =%d \n",registration_status.gprs_status, registration_status.lac,
                                                registration_status.cell_id,registration_status.rat);
    asprintf(&response[0],  "%d", registration_status.gprs_status);
    asprintf(&response[1],  "%x", registration_status.lac);
    asprintf(&response[2],  "%x", registration_status.cell_id);
    asprintf(&response[3],  "%d", registration_status.rat);

    *rsp_count = 4;
  }
  else
  {
    asprintf(&response[0],  "%d", registration_status.reg_status);
    asprintf(&response[1],  "%x", registration_status.lac);
    asprintf(&response[2],  "%x", registration_status.cell_id);
    asprintf(&response[3],  "%d", registration_status.rat);
    asprintf(&response[13], "%d", registration_status.reject_cause);

    *rsp_count = 14;
  }
#endif  
  return RESULT_SUCCESS;
}


//<-- RIL_REQUEST_REGISTRATION_STATE

/*===========================================================================

  FUNCTION  qmi_nas_get_signal_strength
  
===========================================================================*/
uint8 ril_request_get_signal_strength(int response[2])
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_0020_rsp_s nas_0020_rsp;

  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_0020_rsp, 0x0, sizeof(nas_0020_rsp_s));

  rc = qmi_nas_get_signal_strength((int)nas_client_handle, &nas_0020_rsp, &qmi_err_code);
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {	  
    MSG_ERROR("[NAS]ril_request_get_signal_strength!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    MSG_HIGH("(NAS) ril_request_get_signal_strength   (0x0020)",	0, 0, 0);
    MSG_HIGH("   nas_0020_rsp.t01.sig_strength = %d", nas_0020_rsp.t01.sig_strength, 0, 0);
    MSG_HIGH("   nas_0020_rsp.t01.radio_if = %d", nas_0020_rsp.t01.radio_if, 0, 0);

    response[0] = nas_0020_rsp.t01.sig_strength;
    response[1] = nas_0020_rsp.t01.radio_if;

    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  ril_request_get_sig_info
  
===========================================================================*/
uint8 ril_request_get_sig_info(TOF_SignalStrength* tof_signal_strength)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_004F_rsp_s nas_004F_rsp;
  nas_get_sys_info_resp_msg_v01 nas_004D_rsp;  

  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_004F_rsp, 0x0, sizeof(nas_004F_rsp_s));
  memset(&nas_004D_rsp, 0x0, sizeof(nas_004D_rsp));

  rc = qmi_nas_get_sig_info((int)nas_client_handle, &nas_004F_rsp, &qmi_err_code);
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {	  
    MSG_ERROR("[NAS]ril_request_get_signal_strength!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    if((wmm_get_vendor_type() == WMM_VENDOR_B_CHN ))  //Bosch Project
    {
      memset(tof_signal_strength, 0x0, sizeof(tof_signal_strength));
      
      // GSM Signal Strength Info
      if (nas_004F_rsp.t12_valid)
      {
        tof_signal_strength->GSM_SignalStrength.signalStrength	= dsatetsime_gsm_convert_rssi(nas_004F_rsp.t12.gsm_sig_info * (-1), 0);
        tof_signal_strength->GSM_SignalStrength.signalStrengt_dBm	= nas_004F_rsp.t12.gsm_sig_info;
        
        MSG_HIGH("[BOSCH] GSM RSSI Level= %d, RSSI dBm = %d", tof_signal_strength->GW_SignalStrength.signalStrength, 
                                                                                          tof_signal_strength->GSM_SignalStrength.signalStrengt_dBm ,0);
      }
      
      // WCDMA Signal Strength Info
      if (nas_004F_rsp.t13_valid)
      {
        tof_signal_strength->GW_SignalStrength.signalStrength	= nas_004F_rsp.t13.rssi ;
        tof_signal_strength->GW_SignalStrength.bitErrorRate	= (nas_004F_rsp.t13.ecio/2) *(-1);

        MSG_HIGH("[BOSCH] WCDMA RSSI = %d BER = %d", tof_signal_strength->GW_SignalStrength.signalStrength, 
                                                   tof_signal_strength->GW_SignalStrength.bitErrorRate, 0);
      }

      // LTE Signal Strength Info
      if (nas_004F_rsp.t14_valid)
      {
        tof_signal_strength->LTE_SignalStrength.signalStrength = nas_004F_rsp.t14.rssi;
        tof_signal_strength->LTE_SignalStrength.rsrq = nas_004F_rsp.t14.rsrq;
        tof_signal_strength->LTE_SignalStrength.rsrp = nas_004F_rsp.t14.rsrp;
        tof_signal_strength->LTE_SignalStrength.rssnr = nas_004F_rsp.t14.snr;
        tof_signal_strength->LTE_SignalStrength.cqi = 0;  // [need_update] cqi??

        MSG_HIGH("[BOSCH] LTE RSSI = %d RSRQ = %d RSRP = %d", tof_signal_strength->LTE_SignalStrength.signalStrength, 
                                                            tof_signal_strength->LTE_SignalStrength.rsrq, 
                                                            tof_signal_strength->LTE_SignalStrength.rsrp);
        }

        // TD-SCDMA Signal Strength Info
        if (nas_004F_rsp.t15_valid)
        {
          tof_signal_strength->TD_SCDMA_SignalStrength.rscp	= nas_004F_rsp.t15.rscp;

          MSG_HIGH("[BOSCH] TD-SCDMA RSCP = %d", tof_signal_strength->TD_SCDMA_SignalStrength.rscp, 0, 0);
        }
    }
    else
    {
    // WCDMA Signal Strength Info
    if (nas_004F_rsp.t13_valid)
    {
      tof_signal_strength->GW_SignalStrength.signalStrength	= dsatetsime_convert_rssi(nas_004F_rsp.t13.rssi * (-1), DSAT_CSQ_MAX_SIGNAL);
      //tof_signal_strength->GW_SignalStrength.signalStrength	= nas_004F_rsp.t13.rssi * (-1);
      tof_signal_strength->GW_SignalStrength.bitErrorRate	= nas_004F_rsp.t13.ecio;

      MSG_HIGH("[NAS] WCDMA RSSI = %d BER = %d", tof_signal_strength->GW_SignalStrength.signalStrength, 
                                                 tof_signal_strength->GW_SignalStrength.bitErrorRate, 0);
    }

    // LTE Signal Strength Info
    if (nas_004F_rsp.t14_valid)
    {
      tof_signal_strength->LTE_SignalStrength.signalStrength = dsatetsime_convert_rssi(nas_004F_rsp.t14.rssi * (-1), DSAT_CSQ_MAX_SIGNAL);
      //tof_signal_strength->LTE_SignalStrength.signalStrength = nas_004F_rsp.t14.rssi * (-1);
      tof_signal_strength->LTE_SignalStrength.rsrq = nas_004F_rsp.t14.rsrq * -1;
      tof_signal_strength->LTE_SignalStrength.rsrp = nas_004F_rsp.t14.rsrp * -1;
      tof_signal_strength->LTE_SignalStrength.rssnr = nas_004F_rsp.t14.snr;
      tof_signal_strength->LTE_SignalStrength.cqi = 0;  // [need_update] cqi??

      MSG_HIGH("[NAS] LTE RSSI = %d RSRQ = %d RSRP = %d", tof_signal_strength->LTE_SignalStrength.signalStrength, 
                                                          tof_signal_strength->LTE_SignalStrength.rsrq, 
                                                          tof_signal_strength->LTE_SignalStrength.rsrp);
      }
    }
   
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  ril_request_get_pref_network
  
===========================================================================*/
uint8 ril_request_get_pref_network(uint16 *mode_pref)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_555A_rsp_s nas_555A_rsp;

  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_555A_rsp, 0x0, sizeof(nas_555A_rsp_s));
    
  rc = qmi_nas_get_pref_network_type((int)nas_client_handle, &nas_555A_rsp, &qmi_err_code);
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]ril_request_get_pref_network!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    *mode_pref = get_mode_pref_to_ril(nas_555A_rsp.t10.pref_mode, nas_555A_rsp.t11.gw_acq_order_pref, nas_555A_rsp.t12.lte_band_pref);
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  qmi_nas_set_preferred_network
  
===========================================================================*/
uint8 ril_request_set_pref_network(uint16 mode_pref)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_555B_req_s nas_555B_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_555B_req, 0, sizeof(nas_555B_req_s));

  nas_555B_req.t10_valid = TRUE;
  nas_555B_req.t10.pref_mode = set_mode_pref_to_ril(mode_pref);

  if (nas_555B_req.t10.pref_mode == 17)
  {
    nas_555B_req.t11_valid = TRUE;
	if (mode_pref == PREF_NET_TYPE_GSM_WCDMA)
	  nas_555B_req.t11.gw_acq_order_pref = 0x0002;
	else if (mode_pref == PREF_NET_TYPE_GSM_WCDMA_AUTO)
	  nas_555B_req.t11.gw_acq_order_pref = 0x0000;  
  }
  
  if (nas_555B_req.t10.pref_mode == 30)
  {
    nas_555B_req.t12_valid = TRUE;
    if (mode_pref == PREF_NET_TYPE_LTE_850)
	  nas_555B_req.t12.lte_band_pref = 16;  
    else if (mode_pref == PREF_NET_TYPE_LTE_1800)
     nas_555B_req.t12.lte_band_pref = 4;  
    else
    {
      if(wmm_get_vendor_type() == WMM_VENDOR_I_LTE_SKT)
        nas_555B_req.t12.lte_band_pref = 20; 
      else
        nas_555B_req.t12.lte_band_pref = 4; 
    }
  }

  if ((mode_pref == PREF_NET_TYPE_LTE_CDMA_EVDO) || (mode_pref == PREF_NET_TYPE_LTE_GSM_WCDMA) || 
    (mode_pref == PREF_NET_TYPE_LTE_CMDA_EVDO_GSM_WCDMA) || (mode_pref == PREF_NET_TYPE_LTE_ONLY))
  {
    nas_555B_req.t12_valid = TRUE;
    if(wmm_get_vendor_type() == WMM_VENDOR_I_LTE_SKT)
      nas_555B_req.t12.lte_band_pref = 20; 
    else
      nas_555B_req.t12.lte_band_pref = 4;     
  }
  
  rc = qmi_nas_set_pref_network_type((int)nas_client_handle,
                                                &nas_555B_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_set_pref_network_type!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}

/*===========================================================================

  FUNCTION  ril_request_get_pref_mode
  
===========================================================================*/
uint8 ril_request_get_pref_mode(uint16 *mode_pref, uint64 *band_mode_pref)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_557D_rsp_s nas_557D_rsp;

  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_557D_rsp, 0x0, sizeof(nas_557D_rsp_s));
    
  rc = qmi_nas_get_pref_mode_type((int)nas_client_handle, &nas_557D_rsp, &qmi_err_code);
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]ril_request_get_pref_network!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    *mode_pref = nas_557D_rsp.t10.pref_mode;
	  *band_mode_pref = nas_557D_rsp.t11.lte_band_pref;
    return RESULT_SUCCESS;
  }
}

boolean isValidModePref(uint16 mode_pref,uint64 mode_band_pref)
{
	switch(mode_pref)
	{
		case PREF_NET_MODE_CDMA_ONLY:
		case PREF_NET_MODE_EVDO_ONLY:
		case PREF_NET_MODE_GSM_ONLY:
		case PREF_NET_MODE_WCDMA_ONLY:
		case PREF_NET_MODE_GSM_WCDMA:
		case PREF_NET_MODE_CDMA_EVDO_AUTO:	
				if(mode_band_pref == SYS_BAND_MASK_LTE_EMPTY)
				{
					return TRUE;
				}
				else
				{
					return FALSE;				
				}
			break;

		case PREF_NET_MODE_LTE_CMDA_EVDO_GSM_WCDMA:			
		case PREF_NET_MODE_LTE_ONLY:
		case PREF_NET_MODE_LTE_WCDMA:
		case PREF_NET_MODE_LTE_CDMA_EVDO:
			if(mode_band_pref != SYS_BAND_MASK_LTE_EMPTY)
			{
				return TRUE;
			}
			else
			{
				return FALSE;
			}
		break;

		default:
			return FALSE;
		break;
	}
}

/*===========================================================================

  FUNCTION  qmi_nas_set_preferred_mode
  
===========================================================================*/
uint8 ril_request_set_pref_mode(uint16 mode_pref, uint64 mode_band_pref)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_557C_req_s nas_557C_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_557C_req, 0, sizeof(nas_557C_req_s));

  if(!isValidModePref(mode_pref, mode_band_pref))
  {
    printf("ril_request_set_pref_mode + RESULT_FAILURE\r\n");   
    return RESULT_FAILURE;
  }

  nas_557C_req.t10_valid = TRUE;
  nas_557C_req.t10.pref_mode = mode_pref;

  nas_557C_req.t11_valid = TRUE;
  nas_557C_req.t11.lte_band_pref = mode_band_pref;

  rc = qmi_nas_set_pref_mode_type((int)nas_client_handle,
                                                &nas_557C_req,
                                                &qmi_err_code);

  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_set_pref_network_type!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}

/*===========================================================================

  FUNCTION  request_set_service_domain
  
===========================================================================*/
uint8 request_set_service_doamin(uint16 tof_service_domain)
{
  int rc = QMI_NO_ERR, frequency=0;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5557_req_s nas_5557_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  MSG_HIGH("[NAS] ril_request_set_protocol_info()", 0, 0, 0);

  memset(&nas_5557_req, 0, sizeof(nas_5557_req_s));

  nas_5557_req.t11_valid = TRUE;
  nas_5557_req.t11.service_domain_pref = tof_service_domain;  
 
  rc = qmi_nas_set_protocol_info((int)nas_client_handle,
                                                          &nas_5557_req,
                                                          &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS] qmi_nas_set_protocol_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;
}


/*===========================================================================

  FUNCTION  request_get_sercie_domain
  
===========================================================================*/
uint8 request_get_service_domain(uint16 *tof_service_domain)
{
  int rc = QMI_NO_ERR, index=0;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5556_rsp_s nas_5556_rsp;

  memset(&nas_5556_rsp, 0, sizeof(nas_5556_rsp_s));

  MSG_HIGH("[NAS] ril_request_get_protocol_info()", 0, 0, 0);
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_protocol_info((int)nas_client_handle, &nas_5556_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS] ril_request_get_protocol_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    if (nas_5556_rsp.t11_valid)
    {
      *tof_service_domain = nas_5556_rsp.t11.service_domain_pref;  
    }
    else
    {    
      return RESULT_FAILURE;
    }

    return RESULT_SUCCESS;
  }
}


/*===========================================================================

  FUNCTION  request_set_wcdma_rrc_version
  
===========================================================================*/
uint8 request_set_wcdma_rrc_version(uint16 tof_rrc_version)
{
  int rc = QMI_NO_ERR, frequency=0;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5557_req_s nas_5557_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  MSG_HIGH("[NAS] ril_request_set_protocol_info()", 0, 0, 0);

  memset(&nas_5557_req, 0, sizeof(nas_5557_req_s));

  nas_5557_req.t16_valid = TRUE;
  nas_5557_req.t16.wcdma_rrc_version = tof_rrc_version;
  
  rc = qmi_nas_set_protocol_info((int)nas_client_handle,
                                                          &nas_5557_req,
                                                          &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS] qmi_nas_set_protocol_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;
}


/*===========================================================================

  FUNCTION  request_get_wcdma_rrc_version
  
===========================================================================*/
uint8 request_get_wcdma_rrc_version(uint16* tof_rrc_version)
  {
  int rc = QMI_NO_ERR, index=0;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5556_rsp_s nas_5556_rsp;

  memset(&nas_5556_rsp, 0, sizeof(nas_5556_rsp_s));

  MSG_HIGH("[NAS] ril_request_get_protocol_info()", 0, 0, 0);
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_protocol_info((int)nas_client_handle, &nas_5556_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS] ril_request_get_protocol_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    if (nas_5556_rsp.t16_valid)
    {
      *tof_rrc_version = (uint8)nas_5556_rsp.t16.wcdma_rrc_version;
    }
    else
    {    
      return RESULT_FAILURE;
    }
    return RESULT_SUCCESS;
  }
}


/*===========================================================================

  FUNCTION  request_set_wcdma_sms_mo_doamin
  
===========================================================================*/
uint8 request_set_wcdma_sms_mo_domain(byte tof_mo_domain)
{
  int rc = QMI_NO_ERR, frequency=0;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5557_req_s nas_5557_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  MSG_HIGH("[NAS] ril_request_set_protocol_info()", 0, 0, 0);

  memset(&nas_5557_req, 0, sizeof(nas_5557_req_s));

  nas_5557_req.t13_valid = TRUE;
  nas_5557_req.t13.sms_gw_bearer_pref = tof_mo_domain;  
  
  rc = qmi_nas_set_protocol_info((int)nas_client_handle,
                                                          &nas_5557_req,
                                                          &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS] qmi_nas_set_protocol_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}


/*===========================================================================

  FUNCTION  request_get_wcdma_sms_mo_domain
  
===========================================================================*/
uint8 request_get_wcdma_sms_mo_domain(byte* tof_mo_domain)
{
  int rc = QMI_NO_ERR, index=0;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5556_rsp_s nas_5556_rsp;

  memset(&nas_5556_rsp, 0, sizeof(nas_5556_rsp_s));

  MSG_HIGH("[NAS] ril_request_get_protocol_info()", 0, 0, 0);
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_protocol_info((int)nas_client_handle, &nas_5556_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS] ril_request_get_protocol_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    if (nas_5556_rsp.t13_valid)
    {
      *tof_mo_domain = nas_5556_rsp.t13.sms_gw_bearer_pref;      
    }
    else
    {    
      return RESULT_FAILURE;
    }

    return RESULT_SUCCESS;
  }
}


/*===========================================================================

  FUNCTION  request_set_isr_enable
  
===========================================================================*/
uint8 request_set_isr_enable(boolean tof_isr_enable)
{
  int rc = QMI_NO_ERR, frequency=0;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5557_req_s nas_5557_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  MSG_HIGH("[NAS] ril_request_set_protocol_info()", 0, 0, 0);

  memset(&nas_5557_req, 0, sizeof(nas_5557_req_s));

  nas_5557_req.t15_valid = TRUE;
  nas_5557_req.t15.isr_enabled = tof_isr_enable;
  
  rc = qmi_nas_set_protocol_info((int)nas_client_handle,
                                                          &nas_5557_req,
                                                          &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS] qmi_nas_set_protocol_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}


/*===========================================================================

  FUNCTION  request_get_isr_enable
  
===========================================================================*/
uint8 request_get_isr_enable(boolean* tof_isr_enable)
{
  int rc = QMI_NO_ERR, index=0;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5556_rsp_s nas_5556_rsp;

  memset(&nas_5556_rsp, 0, sizeof(nas_5556_rsp_s));

  MSG_HIGH("[NAS] ril_request_get_protocol_info()", 0, 0, 0);
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_protocol_info((int)nas_client_handle, &nas_5556_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS] ril_request_get_protocol_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    if (nas_5556_rsp.t15_valid)
    {
      *tof_isr_enable = (uint8)nas_5556_rsp.t15.isr_enabled;    
    }
    else
    {    
      return RESULT_FAILURE;
    }

    return RESULT_SUCCESS;
  }
}



/*===========================================================================

FUNCTION  request_delete_stored_cell

===========================================================================*/
uint8 request_delete_stored_cell()
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;

  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;


  rc = qmi_nas_delete_stored_cell((int)nas_client_handle, &qmi_err_code);
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]request_delete_stored_cell!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  ril_request_get_network_selection_mode
  
===========================================================================*/
uint8 request_get_network_selection_mode(uint8* net_sel_mode)
{

  *net_sel_mode = network_selection_mode_status;    

  return RESULT_SUCCESS;
}

/*===========================================================================

  FUNCTION  ril_request_get_network_selection_mode
  
===========================================================================*/
uint8 get_network_selection_mode_status()
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_0034_rsp_s nas_0034_rsp;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_0034_rsp, 0x0, sizeof(nas_0034_rsp_s));
    
  rc = qmi_nas_get_pref_network((int)nas_client_handle, &nas_0034_rsp, &qmi_err_code);
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]ril_request_get_pref_network!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  network_selection_mode_status = nas_0034_rsp.t16.net_sel_mode_pref;

  if((wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ) || ( wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ))
  {
    nas_cached_info.mode_pref_valid = TRUE;
    nas_cached_info.mode_pref = nas_0034_rsp.t11.mode_pref;

    nas_cached_info.emergency_mode_valid = TRUE;
    nas_cached_info.emergency_mode = nas_0034_rsp.t10.emergency_mode;

    if( 0x01 == nas_cached_info.emergency_mode ) //NAS_CMN_EMERGENCY_MODE_ON
    {
      qmi_ril_nwr_set_eme_cbm( QMI_RIL_EME_CBM_ACTIVE );
    }
  }

  MSG_HIGH("[NAS] network_selection_mode_status = %d(%s)", network_selection_mode_status, pref_mode_e_type_str(network_selection_mode_status), 0);

  return RESULT_SUCCESS;
}

/*===========================================================================

  FUNCTION  qmi_nas_set_network_selection_auto
  
===========================================================================*/
uint8 request_set_auto_mode()
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_0033_req_s nas_0033_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_0033_req, 0, sizeof(nas_0033_req_s));

  nas_0033_req.t16_valid = TRUE;
  nas_0033_req.t16.net_sel_pref = NAS_0033_NET_SEL_PREF_AUTOMATIC;
  
  rc = qmi_nas_set_network_sel_auto((int)nas_client_handle,
                                                &nas_0033_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_set_pref_network_auto!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    network_selection_mode_status = NAS_0033_NET_SEL_PREF_AUTOMATIC;
  }

  return RESULT_SUCCESS;

}

/*===========================================================================

  FUNCTION  qmi_nas_get_operator
  
===========================================================================*/
uint8 request_get_operator_status(TOF_Operator_Info *Tof_Operator)
{
  int i, j, rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_0025_rsp_s nas_0025_rsp;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_0025_rsp, 0x0, sizeof(nas_0025_rsp_s));
    
  rc = qmi_nas_get_operator((int)nas_client_handle, &nas_0025_rsp, &qmi_err_code); 

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {    
    MSG_ERROR("[NAS]qmi_nas_get_operator!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    Tof_Operator->mcc = nas_0025_rsp.t01.mobile_country_code;
    Tof_Operator->mnc = nas_0025_rsp.t01.mobile_network_code;
    strncpy(Tof_Operator->network_name, (char*)nas_0025_rsp.t01.network_description, nas_0025_rsp.t01.network_description_length);

    return RESULT_SUCCESS;
  }

}


/*===========================================================================

  FUNCTION  qmi_nas_get_operator
  
===========================================================================*/
uint8 ril_request_get_operator(char *response[3])
{
#if 0//BKS_20131129 modify
  memset(response, 0x0, sizeof(response));

  if(registration_status.srv_status == SYS_SRV_STATUS_SRV)
  {
    // ysgwak 20131114 temporary code
    if(wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW)
    {
      if(operator_status.mcc == 0)
      {
        strcpy(operator_status.plmn_name_long, "Verizon Wireless");
        operator_status.mcc = 311;
        operator_status.mnc = 480;
      }
    }
  
    asprintf(&response[0], "%s",  operator_status.plmn_name_long);
    asprintf(&response[1], "%s",  operator_status.plmn_name_short);
    asprintf(&response[2], "%03lu %02lu", operator_status.mcc, operator_status.mnc);
  }

//BKS_20131107
   if (wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW)
   {
     if(registration_status.srv_status == SYS_SRV_STATUS_NO_SRV)// out of service
    {
     asprintf(&response[0], "%s","NO SVC");
     asprintf(&response[1], "%s","NO SVC");
     asprintf(&response[2], "%03lu %02lu", operator_status.mcc, operator_status.mnc);
    }
    else if(registration_status.srv_status == SYS_SRV_STATUS_LIMITED)
    {
     asprintf(&response[0], "%s","Limited Svc");
     asprintf(&response[1], "%s","Limited Svc");
     asprintf(&response[2], "%03lu %02lu", operator_status.mcc, operator_status.mnc);
    }
    else if(registration_status.srv_status == SYS_SRV_STATUS_LIMITED_REGIONAL)
    {
     asprintf(&response[0], "%s","Limited Svc");
     asprintf(&response[1], "%s","Limited Svc");
     asprintf(&response[2], "%03lu %02lu", operator_status.mcc, operator_status.mnc);
     }
    else//PWR SAVE
    {
     asprintf(&response[0], "%s",  operator_status.plmn_name_long);
     asprintf(&response[1], "%s",  operator_status.plmn_name_short);
     asprintf(&response[2], "%03lu %02lu", operator_status.mcc, operator_status.mnc);
     }
   }
#else
   memset(response, 0x0, sizeof(response));

   if ((wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ) || ( wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ))
   {
     uint8 decoded_mnc;
     qmi_nas_registration_state_resp_helper_type ril_resp_helper;
//     ril_request_vzw_get_registration_status(RIL_REQUEST_REGISTRATION_STATE, &ril_resp_helper);

     if(nas_cached_info.radio_tech == 6)//CDMA
     {
        if(nas_cached_info.cdma_srv_status_info->srv_status == SYS_SRV_STATUS_SRV)
        {
          strcpy(operator_status.plmn_name_long, "Verizon Wireless");
          strcpy(operator_status.plmn_name_short, "VZW");

          asprintf(&response[0], "%s", operator_status.plmn_name_long);
          asprintf(&response[1],  "%s",operator_status.plmn_name_short);
		  
          qmi_nas_decode_3gpp2_imsi_11_12(&decoded_mnc, operator_status.mnc);
          //asprintf(&response[2], "%03lu %03lu", convert_mcc_ota_to_hpcd(operator_status.mcc), decoded_mnc);
         LOGD("[ril_request_get_operator]MCC =  %s  MNC = %s", nas_cached_info.cdma_sys_info->cdma_specific_sys_info.network_id.mcc, nas_cached_info.cdma_sys_info->cdma_specific_sys_info.network_id.mnc, 0);
         asprintf(&response[2], "%s %s", nas_cached_info.cdma_sys_info->cdma_specific_sys_info.network_id.mcc,nas_cached_info.cdma_sys_info->cdma_specific_sys_info.network_id.mnc);
        }
        else 
        {
         asprintf(&response[0],  "%s", service_status_str(nas_cached_info.cdma_srv_status_info->srv_status));
         asprintf(&response[1],  "%s", service_status_str(nas_cached_info.cdma_srv_status_info->srv_status));
         asprintf(&response[2], "%03lu %03lu", operator_status.mcc, operator_status.mnc);
        }
     }
     else if(nas_cached_info.radio_tech == 4 || nas_cached_info.radio_tech == 7 || 
   	         nas_cached_info.radio_tech == 8 || nas_cached_info.radio_tech == 13)//EVDO_Rel0/EVDO_RelA/eHRPD
    {
         if(nas_cached_info.hdr_srv_status_info->srv_status == SYS_SRV_STATUS_SRV)
         {
           if(operator_status.mcc == 0)
           {
             operator_status.mcc = 311;
             operator_status.mnc = 480; 

             strcpy(operator_status.plmn_name_long, "Verizon Wireless");
             strcpy(operator_status.plmn_name_short, "VZW");
           }
           asprintf(&response[0],  "%s", operator_status.plmn_name_long);
           asprintf(&response[1],  "%s", operator_status.plmn_name_short);
           asprintf(&response[2], "%03lu %03lu", operator_status.mcc, operator_status.mnc);
           }
           else 
           {
             asprintf(&response[0],  "%s", service_status_str(nas_cached_info.hdr_srv_status_info->srv_status));
             asprintf(&response[1],  "%s", service_status_str(nas_cached_info.hdr_srv_status_info->srv_status));
             asprintf(&response[2], "%03lu %03lu", operator_status.mcc, operator_status.mnc);
           }
    }	 
    else if(nas_cached_info.radio_tech == 14)//LTE
    {
          if(nas_cached_info.lte_srv_status_info->srv_status == SYS_SRV_STATUS_SRV)
          {
          	if(operator_status.mcc == 0)//for test
     	      {
              operator_status.mcc = 311;
     	        operator_status.mnc = 480; 
     
              strcpy(operator_status.plmn_name_long, "Verizon Wireless");
              strcpy(operator_status.plmn_name_short, "VZW");
     	      }
     
           asprintf(&response[0],  "%s", operator_status.plmn_name_long);
           asprintf(&response[1],  "%s", operator_status.plmn_name_short);
           asprintf(&response[2], "%03lu %03lu", operator_status.mcc, operator_status.mnc);
     
          }
          else
          {
           asprintf(&response[0],  "%s", service_status_str(nas_cached_info.lte_srv_status_info->srv_status));
           asprintf(&response[1],  "%s", service_status_str(nas_cached_info.lte_srv_status_info->srv_status));
           asprintf(&response[2], "%03lu %03lu", operator_status.mcc, operator_status.mnc);
          }
    }    	 
    else//No Service.
    {
       asprintf(&response[0],  "%s", service_status_str(nas_cached_info.cdma_srv_status_info->srv_status));
       asprintf(&response[1],  "%s", service_status_str(nas_cached_info.cdma_srv_status_info->srv_status));
       asprintf(&response[2], "%03lu %03lu", operator_status.mcc, operator_status.mnc);
    }
   }//WMM_VENDOR_I_LTE_VZW
   else
   {
     if(registration_status.srv_status == SYS_SRV_STATUS_SRV)
     {
       asprintf(&response[0], "%s",  operator_status.plmn_name_long);
       asprintf(&response[1], "%s",  operator_status.plmn_name_short);
       asprintf(&response[2], "%03lu %02lu", operator_status.mcc, operator_status.mnc);
     }
   }
#endif
  return RESULT_SUCCESS;
  }

/*===========================================================================

  FUNCTION  qmi_nas_get_operator
  
===========================================================================*/
uint8 get_operator_status()
{
  int i, j, rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_0025_rsp_s nas_0025_rsp;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_0025_rsp, 0x0, sizeof(nas_0025_rsp_s));
    
  rc = qmi_nas_get_operator((int)nas_client_handle, &nas_0025_rsp, &qmi_err_code); 

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {    
    MSG_ERROR("[NAS]qmi_nas_get_operator!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    operator_status.mcc = nas_0025_rsp.t01.mobile_country_code;
    operator_status.mnc = nas_0025_rsp.t01.mobile_network_code;
    //strcpy(operator_status.network_description, (char*)nas_0025_rsp.t01.network_description);

    return RESULT_SUCCESS;
  }

}

//BKS_20131202 - start
#if 1 //--> RIL_REQUEST_OPERATOR
/*===========================================================================

  FUNCTION  qmi_nas_find_3gpp2_static_operator_name
  
===========================================================================*/
int qmi_nas_find_3gpp2_static_operator_name
(
  char * mcc_str,
  char * mnc_str,
  uint16_t sid,
  uint16_t nid,  
  char **long_ons_ptr,
  char **short_ons_ptr
)
{
  const int number_of_entries = sizeof( qmi_ons_3gpp2_memory_list ) / sizeof( qmi_ons_3gpp2_memory_entry_type );
  int i = 0,res = FALSE;
  boolean continue_search = TRUE;
  const qmi_ons_3gpp2_memory_entry_type *ons_mem_ptr = NULL;

  if(long_ons_ptr != NULL && short_ons_ptr != NULL)
  {
    /* Search the table for the MCC and MNC */
    while ( continue_search && ( i < number_of_entries ) )
    {
      if ( !strcmp(mcc_str, qmi_ons_3gpp2_memory_list[ i ].mcc_str) )
      {
        if ( !strcmp(mnc_str, qmi_ons_3gpp2_memory_list[ i ].mnc_str) )
        {
            if(sid == qmi_ons_3gpp2_memory_list[ i ].sid)
            {
                if(nid == qmi_ons_3gpp2_memory_list[ i ].nid)
                {
                    ons_mem_ptr = &qmi_ons_3gpp2_memory_list[ i ];
                    continue_search = FALSE;
                    res = TRUE;
                }
                else if(nid < qmi_ons_3gpp2_memory_list[ i ].nid)
                {
                    /*
                    ** Terminate the search because the NIDs are stored in ascending
                    ** order in the table and the NID being searched is less than the
                    ** current NID in the table.
                    */
                    continue_search = FALSE;
                }
            }
            else if(sid < qmi_ons_3gpp2_memory_list[ i ].sid)
            {
                /*
                ** Terminate the search because the SIDs are stored in ascending
                ** order in the table and the SID being searched is less than the
                ** current SID in the table.
                */
                continue_search = FALSE;
            }
        }
        else if ( atoi(mnc_str) < atoi(qmi_ons_3gpp2_memory_list[ i ].mnc_str) )
        {
          /*
          ** Terminate the search because the MNCs are stored in ascending
          ** order in the table and the MNC being searched is less than the
          ** current MNC in the table.
          */
          continue_search = FALSE;
        }
      }
  
      else if ( atoi(mcc_str) < atoi(qmi_ons_3gpp2_memory_list[ i ].mcc_str) )
      {
        /*
        ** Terminate the search because the MCCs are stored in ascending
        ** order in the table and the MCC being searched is less than the
        ** current MCC in the table.
        */
        continue_search = FALSE;
      }
  
      i++;
  
    } /* end while */
  
    if ( ons_mem_ptr == NULL )
    {
      MSG_ERROR( "UE Memory List does not contain the specified operator", 0, 0, 0 );
    }
    else
    {
      *long_ons_ptr = ons_mem_ptr->full_name_ptr;
      *short_ons_ptr = ons_mem_ptr->short_name_ptr;
      MSG_ERROR( "ONS info from UE Memory List", 0, 0, 0 );
    }
  }
  else
  {
    MSG_FATAL("FATAL : CHECK FAILED", 0, 0, 0);
  }

  return res;
} /* qcril_qmi_nas2_find_3gpp2_static_operator_name */

/*===========================================================================

  FUNCTION  qmi_nas_fill_up_3gpp2_operator_name
  
===========================================================================*/
int qmi_nas_fill_up_3gpp2_operator_name
(
  char * mcc_str,
  char * mnc_str,  
  uint16_t sid,
  uint16_t nid,
  char *long_ons_ptr,
  size_t long_ons_ptr_size,
  char *short_ons_ptr,
  size_t short_ons_ptr_size
)
{
  int res = FALSE;
  char * op_name_short;
  char * op_name_long;
  nas_plmn_network_name_type_v01* plmn_nw_name_ptr;

  if( NULL != mcc_str && NULL != mnc_str )
  {
    MSG_HIGH("mcc %s mnc %s", mcc_str, mnc_str, 0);
    MSG_HIGH("sid %d nid %d", sid, nid, 0);
    // look up for operator name in static table
    op_name_short = NULL;
    op_name_long = NULL;
    res = qmi_nas_find_3gpp2_static_operator_name(mcc_str,
                                                  mnc_str,
                                                  sid,
                                                  nid,
                                                  &op_name_long,
                                                  &op_name_short
                                                  );
    if ( NULL != op_name_long )
    {
        snprintf( long_ons_ptr, long_ons_ptr_size, "%s", op_name_long);
    }
    if ( NULL != op_name_short )
    {
        snprintf( short_ons_ptr, short_ons_ptr_size, "%s", op_name_short);
    }
    MSG_HIGH("..will return static %s, %s", long_ons_ptr, short_ons_ptr, 0 );   
  }
  else
  {
    MSG_FATAL("CHECK FAILED", 0, 0, 0);
  }

  MSG_HIGH("completed with %d", res, 0, 0);
  return res;
} /* qmi_nas_fill_up_3gpp2_operator_name */

/*===========================================================================

  FUNCTION  qmi_nas_fillup_wildcard_mcc_mnc_helper
  
===========================================================================*/
void qmi_nas_fillup_wildcard_mcc_mnc_helper(char *mcc, char *mnc)
{
  memcpy( mcc, NAS_PLACEHOLDER_MCC_STR, NAS_MCC_MNC_MAX_SIZE );
  memcpy( mnc, NAS_PLACEHOLDER_MNC_STR, NAS_MCC_MNC_MAX_SIZE );
  MSG_HIGH("mcc %s mnc %s", mcc, mnc, 0);
}/* qmi_nas_fillup_wildcard_mcc_mnc_helper */

/*===========================================================================

  FUNCTION  qmi_nas_is_mcc_mnc_wildcard_entry
  
===========================================================================*/
int qmi_nas_is_mcc_mnc_wildcard_entry(char mcc[], char mnc[])
{
  int ret = FALSE;

//  MSG_HIGH("mcc 0 = %x, 1 = %ld, 2 = %d", mcc[0], mcc[1], mcc[2]);
//  MSG_HIGH("mnc 0 = %x, 1 = %x, 2 = %x", mnc[0], mnc[1], mnc[2]);
  if( (NAS_MCC_WILDCARD_ENTRY == mcc[0] && NAS_MCC_MNC_WILDCARD_ENTRY == mcc[1] && NAS_MCC_MNC_WILDCARD_ENTRY == mcc[2]) &&
      (NAS_MNC_WILDCARD_ENTRY == mnc[0] && NAS_MCC_MNC_WILDCARD_ENTRY == mnc[1] && NAS_MCC_MNC_WILDCARD_ENTRY == mnc[2]) )
  {
    ret = TRUE;
  }

  MSG_HIGH("[mcc_mnc_wildcard] ret = %d", ret, 0, 0);
  
  return ret;
}/* qmi_nas_is_mcc_mnc_wildcard_entry */

/*===========================================================================

  FUNCTION  qmi_nas_fillup_mcc_mnc_helper
  
===========================================================================*/
void qmi_nas_fillup_mcc_mnc_helper(char *src_arr, char *dest_str)
{
  int iter_i = 0, len = 0;

  if( NULL != src_arr && NULL != dest_str )
  {
    for( iter_i=0; iter_i<NAS_MCC_MNC_MAX_V01; iter_i++ )
    {
      if(isdigit(src_arr[iter_i]))
      {
        dest_str[iter_i] = src_arr[iter_i];
        len++;
      }
    }
    dest_str[len] = '\0';
  }
  else
  {
    MSG_HIGH("CHECK FAILED", 0, 0, 0);
  }
} /* qmi_nas_fillup_mcc_mnc_helper */

/*===========================================================================

  FUNCTION  qmi_nas_find_current_mcc_mnc
  
===========================================================================*/
int qmi_nas_find_current_mcc_mnc(char * mcc_str_ptr, char * mnc_str_ptr)
{
  int res = FALSE;

  if( NULL != mcc_str_ptr && NULL != mnc_str_ptr)
  {
    memset(mcc_str_ptr,0,NAS_MCC_MNC_MAX_SIZE);
    memset(mnc_str_ptr,0,NAS_MCC_MNC_MAX_SIZE);

    if( NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.lte_sys_info )
        && nas_cached_info.lte_sys_info->threegpp_specific_sys_info.network_id_valid )
    {
      qmi_nas_fillup_mcc_mnc_helper(nas_cached_info.lte_sys_info->threegpp_specific_sys_info.network_id.mcc, mcc_str_ptr);
      qmi_nas_fillup_mcc_mnc_helper(nas_cached_info.lte_sys_info->threegpp_specific_sys_info.network_id.mnc, mnc_str_ptr);
      res = TRUE;
      MSG_HIGH("qmi_nas_find_current_mcc_mnc : using sys_info_ind - LTE mcc %s mnc %s", mcc_str_ptr, mnc_str_ptr, 0);
    }
  }
  else
  {
    MSG_HIGH("qmi_nas_find_current_mcc_mnc : res %d", res, 0, 0);
  }

  return res;
} /* qmi_nas_find_current_mcc_mnc */

/*===========================================================================

  FUNCTION  qmi_nas_is_mcc_mnc_info_available
  
===========================================================================*/
static int qmi_nas_is_mcc_mnc_info_available()
{
  int res = TRUE;
  
  //MSG_HIGH("qmi_nas_is_mcc_mnc_info_available", 0, 0, 0);

  {
    if( ( FALSE == NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.lte_sys_info ) ) ||
        ( FALSE == nas_cached_info.lte_sys_info->threegpp_specific_sys_info.network_id_valid ) )
    {
      res = FALSE;
    }
  }
  
  MSG_HIGH("qmi_nas_is_mcc_mnc_info_available, LTE result %d", res, 0, 0);
  
  return res;
} /* qmi_nas_is_mcc_mnc_info_available */

/*===========================================================================

  FUNCTION  ril_request_vzw_get_operator
  
===========================================================================*/
uint8 ril_request_vzw_get_operator(qmi_operator_resp_helper_type *ril_resp_helper)
{
  RIL_Errno ril_req_res = RIL_E_GENERIC_FAILURE;

  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  int everything_cached;
  char mcc_str[NAS_MCC_MNC_MAX_SIZE];
  char mnc_str[NAS_MCC_MNC_MAX_SIZE];
  int mcc, mnc;
  char mcc_3gpp2_str[NAS_3GPP2_MCC_MAX_SIZE];
  char mnc_3gpp2_str[NAS_MCC_MNC_MAX_SIZE];
  uint16_t sid_3gpp2, nid_3gpp2;
  int used_nam_name_len;
  int res;

  nas_get_plmn_name_req_msg_v01  get_plmn_req;
  nas_get_plmn_name_resp_msg_v01 get_plmn_resp;

  nas_003E_req_s	cdma_subscription_info_req;
  nas_003E_rsp_s cdma_subscription_info_resp;
  
  MSG_HIGH("ril_request_vzw_get_operator() start", 0, 0, 0);

  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  // ** response holder init
  memset( ril_resp_helper, 0, sizeof( qmi_operator_resp_helper_type ) );

  {
    /* Fill in info for the current operator */
    ril_resp_helper->operator_info_array[ 0 ] = ril_resp_helper->long_eons;
    ril_resp_helper->operator_info_array[ 1 ] = ril_resp_helper->short_eons;
    ril_resp_helper->operator_info_array[ 2 ] = ril_resp_helper->mcc_mnc_ascii;

    /* If LTE service is available, lookup the current operator name */
    if ( (NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.lte_srv_status_info )) && QMI_SRV_STATUS_INDICATES_LTE_FULL_SRV( nas_cached_info.lte_srv_status_info->srv_status, nas_cached_info.lte_srv_status_info_valid) )
    {
      *ril_resp_helper->long_eons        = QMI_RIL_ZERO;
      *ril_resp_helper->short_eons       = QMI_RIL_ZERO;
      *ril_resp_helper->mcc_mnc_ascii    = QMI_RIL_ZERO;
  
      // TODO: NAS_CACHE_LOCK();
      MSG_HIGH( "LTE Service available cached plmn_id %d short_name %d long_name %d", NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.plmn_id ), 
                        NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.short_name ), 
                        NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.long_name ) );
  
      everything_cached = ( NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.plmn_id ) &&
                            NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.short_name ) &&
                            NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.long_name ) );
      // TODO: NAS_CACHE_UNLOCK();

      if( TRUE == everything_cached )
      {
        // TODO: NAS_CACHE_LOCK();
        if( NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.plmn_id ) )
        {
          snprintf( mcc_str, NAS_MCC_MNC_MAX_SIZE, "%03d", nas_cached_info.plmn_id->mcc );
          if ( nas_cached_info.plmn_id->mnc > 99 || TRUE == nas_cached_info.plmn_id->mnc_includes_pcs_digit )
          {
		     sprintf( mnc_str, NAS_MCC_MNC_MAX_SIZE, "%03d", (int) nas_cached_info.plmn_id->mnc );

          }
          else
          {
            sprintf( mnc_str, NAS_MCC_MNC_MAX_SIZE, "%02d", (int) nas_cached_info.plmn_id->mnc );
          }
        }
           snprintf( ril_resp_helper->mcc_mnc_ascii, sizeof(ril_resp_helper->mcc_mnc_ascii), "%s%s", mcc_str, mnc_str );

        if( NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.short_name ) )
        {
          strcpy( ril_resp_helper->short_eons, (char*) nas_cached_info.short_name->plmn_name);
        }
        
        if( NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.long_name ) )
        {
          strcpy( ril_resp_helper->long_eons, (char*) nas_cached_info.long_name->plmn_name);
        }
        // TODO: NAS_CACHE_UNLOCK();
      }
      else
      {
        // TODO: NAS_CACHE_LOCK()
        everything_cached = ( TRUE == qmi_nas_is_mcc_mnc_info_available() );
        // TODO: NAS_CACHE_UNLOCK()

        if( FALSE == everything_cached )
        {
          qmi_nas_vzw_fetch_sys_info();
        }

        // TODO: NAS_CACHE_LOCK();
        if( NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.lte_sys_info ) )
        {
          MSG_HIGH("..lte network id valid %d", nas_cached_info.lte_sys_info->threegpp_specific_sys_info.network_id_valid, 0, 0);
        }

        res = qmi_nas_find_current_mcc_mnc(mcc_str, mnc_str);
        // TODO: NAS_CACHE_UNLOCK();

        if( res )
        {
          mcc = atoi(mcc_str);
          mnc = atoi(mnc_str);
          memset(&get_plmn_resp, 0, sizeof(get_plmn_resp));
          get_plmn_req.plmn.mcc = mcc;
          get_plmn_req.plmn.mnc = mnc;

          rc = qmi_nas_get_plmn_name((int)nas_client_handle, &get_plmn_req, &get_plmn_resp, &qmi_err_code);

          if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
          {
            MSG_ERROR("[NAS] qmi_nas_get_plmn_name!! rc: %d err_code : %d", rc, qmi_err_code, 0);
            return RESULT_FAILURE;
          }
          else
          {
            ril_req_res = RIL_E_SUCCESS;
            if( TRUE == get_plmn_resp.eons_plmn_name_3gpp_valid )
            {
              snprintf( ril_resp_helper->mcc_mnc_ascii, sizeof(ril_resp_helper->mcc_mnc_ascii), "%s%s", mcc_str, mnc_str );
              strcpy( ril_resp_helper->short_eons, get_plmn_resp.eons_plmn_name_3gpp.plmn_short_name );
              strcpy( ril_resp_helper->long_eons, get_plmn_resp.eons_plmn_name_3gpp.plmn_long_name); 

            }
          }
        }
        else
        {
          ril_req_res = RIL_E_GENERIC_FAILURE;
        }
      }
    }
    /* Current operator is 1xEvDo */
    else if ( (NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.cdma_srv_status_info ) || NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.hdr_srv_status_info )) && QMI_SRV_STATUS_INDICATES_1XEVDO_FULL_SRV( nas_cached_info.cdma_srv_status_info->srv_status,
                                                        nas_cached_info.cdma_srv_status_info_valid,
                                                        nas_cached_info.hdr_srv_status_info_valid,
                                                        nas_cached_info.hdr_hybrid, 
                                                        nas_cached_info.hdr_srv_status_info->srv_status ) ) 
    {
		int temp_mnc = 0;
		
      MSG_HIGH("1xEVDO Service available", 0, 0, 0);

      // get MCC / MNC 
      memset(mcc_3gpp2_str, 0, sizeof(mcc_3gpp2_str));
      memset(mnc_3gpp2_str, 0, sizeof(mnc_3gpp2_str));
      sid_3gpp2 = 0;
      nid_3gpp2 = 0;

      ril_req_res = qmi_nas_vzw_fetch_sys_info();

      if ( RIL_E_SUCCESS == ril_req_res )
      {
        // TODO: NAS_CACHE_LOCK()
        if ( NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.cdma_sys_info ) && nas_cached_info.cdma_sys_info->cdma_specific_sys_info.network_id_valid )
        {
          if( TRUE == qmi_nas_is_mcc_mnc_wildcard_entry(nas_cached_info.cdma_sys_info->cdma_specific_sys_info.network_id.mcc, 
                                                        nas_cached_info.cdma_sys_info->cdma_specific_sys_info.network_id.mnc) )
          {
            qmi_nas_fillup_wildcard_mcc_mnc_helper(mcc_3gpp2_str, mnc_3gpp2_str);
          }
          else
          {
            //MCC
            qmi_nas_fillup_mcc_mnc_helper( nas_cached_info.cdma_sys_info->cdma_specific_sys_info.network_id.mcc, mcc_3gpp2_str);
  
            //MNC         
  	       //nas_cached_info.cdma_sys_info->cdma_specific_sys_info.network_id.mnc[3] = NULL;
            temp_mnc = atoi(nas_cached_info.cdma_sys_info->cdma_specific_sys_info.network_id.mnc);
  
            if(temp_mnc>= 100) //3digits
            {
              nas_cached_info.cdma_sys_info->cdma_specific_sys_info.network_id.mnc[3]= NULL;
            }
            else
            {
              nas_cached_info.cdma_sys_info->cdma_specific_sys_info.network_id.mnc[2]= NULL;
            }
            qmi_nas_fillup_mcc_mnc_helper( nas_cached_info.cdma_sys_info->cdma_specific_sys_info.network_id.mnc, mnc_3gpp2_str);
          }

          snprintf( ril_resp_helper->mcc_mnc_ascii, sizeof(ril_resp_helper->mcc_mnc_ascii), "%s%s", mcc_3gpp2_str, mnc_3gpp2_str );
          MSG_HIGH("..mcc %s, mnc %s ascii %s", nas_cached_info.cdma_sys_info->cdma_specific_sys_info.network_id.mcc, nas_cached_info.cdma_sys_info->cdma_specific_sys_info.network_id.mnc, ril_resp_helper->mcc_mnc_ascii);
        }
        
        if ( NAS_CACHE_IS_ENTRY_VALID( nas_cached_info.cdma_sys_info ) && nas_cached_info.cdma_sys_info->cdma_specific_sys_info.cdma_sys_id_valid )
        {
          sid_3gpp2 = nas_cached_info.cdma_sys_info->cdma_specific_sys_info.cdma_sys_id.sid;
          nid_3gpp2 = nas_cached_info.cdma_sys_info->cdma_specific_sys_info.cdma_sys_id.nid;
        }

#if 0
       MSG_HIGH("[EVOD Only!!!] cdma_srv_status=%d cdma_srv_status_info_valid=%d",nas_cached_info.cdma_srv_status_info->srv_status, nas_cached_info.cdma_srv_status_info_valid, 0);
	   if((NAS_CACHE_IS_ENTRY_VALID(nas_cached_info.hdr_sys_info ) && nas_cached_info.hdr_sys_info->hdr_specific_sys_info.is856_sys_id_valid && nas_cached_info.hdr_srv_status_info->srv_status == NAS_SYS_SRV_STATUS_SRV_V01) 
	  	&& (nas_cached_info.cdma_srv_status_info->srv_status != NAS_SYS_SRV_STATUS_SRV_V01))//EVDO Only
	  {
          MSG_HIGH("[EVOD Only!!!]",0, 0, 0);

          memcpy( ril_resp_helper->operator_info_array[ 0 ], (char*) "NO SVC" , NAS_OPERATOR_RESP_MAX_MCC_MNC_LEN);
          memcpy( ril_resp_helper->operator_info_array[ 1 ], (char*) "NO SVC" , NAS_OPERATOR_RESP_MAX_MCC_MNC_LEN);
          memcpy( ril_resp_helper->operator_info_array[ 2 ], (char*) "00000" , sizeof(ril_resp_helper->mcc_mnc_ascii));
	  }
#endif	   
        // TODO: NAS_CACHE_UNLOCK()
      }

      res = qmi_nas_fill_up_3gpp2_operator_name(mcc_3gpp2_str,
                                                mnc_3gpp2_str,  
                                                sid_3gpp2,
                                                nid_3gpp2,
                                                ril_resp_helper->long_eons,
                                                sizeof(ril_resp_helper->long_eons),
                                                ril_resp_helper->short_eons,
                                                sizeof(ril_resp_helper->short_eons) );

      if( RIL_E_SUCCESS != ril_req_res || FALSE == res )
      {

        //fetch nam_name (for filling the long_eons) by sending QMI_NAS_GET_3GPP2_SUBSCRIPTION_INFO_REQ_MSG_V01
        ril_req_res = RIL_E_GENERIC_FAILURE;
        memset(&cdma_subscription_info_req,0,sizeof(cdma_subscription_info_req));

        cdma_subscription_info_req.t01_valid = TRUE;
        cdma_subscription_info_req.t01.nam = 0xFF; // current NAM
        cdma_subscription_info_req.t10_valid = TRUE;
        cdma_subscription_info_req.t10.get_3gpp2_info_mask = QMI_NAS_GET_3GPP2_SUBS_INFO_NAM_NAME_V01;

        rc = qmi_nas_get_3gpp2_subscription_info((int)nas_client_handle, &cdma_subscription_info_req, &cdma_subscription_info_resp, &qmi_err_code);

        if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
        {
          MSG_ERROR("[NAS] qmi_nas_get_plmn_name!! rc: %d err_code : %d", rc, qmi_err_code, 0);
          return RESULT_FAILURE;
        }
        else
        {
          MSG_HIGH("nam name valid %d, len %d", (int)cdma_subscription_info_resp.t10_valid, (int) cdma_subscription_info_resp.t10.nam_name_len, 0);
          ril_req_res = RIL_E_SUCCESS;
          if ( cdma_subscription_info_resp.t10_valid )
          {
            used_nam_name_len = MIN(cdma_subscription_info_resp.t10.nam_name_len,
                                    MIN(NAS_MAX_NAM_NAME_LEN_V01,
                                       (NAS_OPERATOR_RESP_MAX_EONS_LEN - 1) )
                                   );
            MSG_HIGH(".. used_nam_name_len %d nam_name=%s", (int)cdma_subscription_info_resp.t10.nam_name_len, cdma_subscription_info_resp.t10.nam_name, 0 );
            MSG_HIGH("[EVOD Only!!!] cdma_srv_status=%d cdma_srv_status_info_valid=%d",nas_cached_info.cdma_srv_status_info->srv_status, nas_cached_info.cdma_srv_status_info_valid, 0);

	     if((NAS_CACHE_IS_ENTRY_VALID(nas_cached_info.hdr_sys_info ) && nas_cached_info.hdr_sys_info->hdr_specific_sys_info.is856_sys_id_valid && nas_cached_info.hdr_srv_status_info->srv_status == NAS_SYS_SRV_STATUS_SRV_V01) 
	  	&& (nas_cached_info.cdma_srv_status_info->srv_status != NAS_SYS_SRV_STATUS_SRV_V01))//EVDO Only
            {
      
            }
            else
            {
              memcpy(ril_resp_helper->long_eons, cdma_subscription_info_resp.t10.nam_name, used_nam_name_len );
              ril_resp_helper->long_eons[ used_nam_name_len ]  = 0;
              MSG_HIGH(".. nam %s", ril_resp_helper->long_eons, 0, 0 );
            } 
          }
        }

        if ( *ril_resp_helper->long_eons && !*ril_resp_helper->short_eons ) // TODO: && TRUE == nas_common_info.fill_eons)
        {
          MSG_HIGH("Filling short eons with long eons", 0, 0, 0);
          memcpy( ril_resp_helper->short_eons, ril_resp_helper->long_eons , sizeof(ril_resp_helper->short_eons));
        }

        if ( *ril_resp_helper->short_eons && !*ril_resp_helper->long_eons ) // TODO: && TRUE == nas_common_info.fill_eons)
        {
          MSG_HIGH("Filling long eons with short eons", 0, 0, 0);
          memcpy( ril_resp_helper->long_eons, ril_resp_helper->short_eons , sizeof(ril_resp_helper->long_eons));
        }

        if ( QMI_SRV_STATUS_INDICATES_CDMA_FULL_SRV( nas_cached_info.cdma_srv_status_info->srv_status, nas_cached_info.cdma_srv_status_info_valid)
             && (!*ril_resp_helper->long_eons) )
        {
          strcpy(ril_resp_helper->long_eons, ril_resp_helper->mcc_mnc_ascii); 
        }
      }
        
    }
    else
    { // No Service
      ril_resp_helper->operator_info_array[ 0 ] = "Verizon Wireless";
      ril_resp_helper->operator_info_array[ 1 ] = "Verizon Wireless";
      ril_resp_helper->operator_info_array[ 2 ] = "311480";
    }

    MSG_HIGH("[NAS].. res long %s short %s mcc_mnc %s", ril_resp_helper->long_eons, ril_resp_helper->short_eons, ril_resp_helper->mcc_mnc_ascii);
  }

  //MSG_HIGH("ril_request_vzw_get_operator() end", 0, 0, 0);

  return RESULT_SUCCESS;
}/* ril_request_vzw_get_operator */
#endif //<-- RIL_REQUEST_OPERATOR

//BKS_20131202 - end
/*===========================================================================

  FUNCTION  ril_request_get_sys_info
  
===========================================================================*/
uint8 ril_request_get_sys_info()
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_004D_rsp_s nas_004D_rsp;

  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_004D_rsp, 0x0, sizeof(nas_004D_rsp_s));

  rc = qmi_nas_get_sys_info((int)nas_client_handle, &nas_004D_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_get_regi_status!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    if(nas_004D_rsp.t18.reg_reject_info_valid)
    {
      registration_status.reject_cause = nas_004D_rsp.t18.rej_cause;

      MSG_HIGH("   WCDMA reject_srv_domain = %d rej_cause = %d(%s)", nas_004D_rsp.t18.reject_srv_domain, 
                                                                     registration_status.reject_cause, 
                                                                     reject_cause_string(registration_status.reject_cause));
    }
    

    if(nas_004D_rsp.t19.reg_reject_info_valid)
    {
      registration_status.reject_cause = nas_004D_rsp.t19.rej_cause;

      MSG_HIGH("   LTE reject_srv_domain = %d rej_cause = %d(%s)", nas_004D_rsp.t19.reject_srv_domain, 
                                                                     registration_status.reject_cause, 
                                                                     reject_cause_string(registration_status.reject_cause));
    }

  }

  return RESULT_SUCCESS;
}

/*===========================================================================

  FUNCTION  ril_nas_config_sig_info_req
  
===========================================================================*/
uint8 ril_nas_config_sig_info_req()
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_0050_req_s nas_0050_req;

  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_0050_req, 0x0, sizeof(nas_0050_req_s));

  rc = qmi_nas_config_sig_info_req((int)nas_client_handle, &nas_0050_req, &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_config_sig_info_req!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;
}

/*===========================================================================

  FUNCTION  get_registration_status_info
  
===========================================================================*/
uint8 get_registration_status_info()
{
  int rc = QMI_NO_ERR, i=0;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_0024_rsp_s nas_0024_rsp;

  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_0024_rsp, 0x0, sizeof(nas_0024_rsp_s));

  rc = qmi_nas_get_serving_system((int)nas_client_handle, &nas_0024_rsp, &qmi_err_code);
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS] qmi_nas_get_regi_status!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    // Roaming Indicator Value
    if (nas_0024_rsp.t10_valid)
    {
      //MSG_HIGH("   roaming_indicator = %d", nas_0024_rsp.t10.roaming_indicator, 0, 0);
    }
/*
    // Data Service Capability
    if (nas_0024_rsp.t11_valid)
    {
      for (i = 0; (i < nas_0024_rsp.t11.data_capability_list_len); i++ )
      {
        MSG_HIGH("   data_capabilities[%d] = %d", i, nas_0024_rsp.t11.data_capabilities[i], 0);
      }
    }
*/
    // Current PLMN
    if (nas_0024_rsp.t12_valid)
    {
      MSG_HIGH("[NAS] mobile_country_code = %d mobile_network_code = %d", nas_0024_rsp.t12.mobile_country_code, 
                                                                          nas_0024_rsp.t12.mobile_network_code, 0);
    }

    // CDMA System ID
    if (nas_0024_rsp.t13_valid)
    {
      MSG_HIGH("[NAS] CDMA sid = %d nid = %d", nas_0024_rsp.t13.sid, nas_0024_rsp.t13.nid, 0);
    }

    // CDMA Base Station Information
    if (nas_0024_rsp.t14_valid)
    {
      MSG_HIGH("[NAS] CDMA base_id = %d base_lat = %d base_long = %d", nas_0024_rsp.t14.base_id, nas_0024_rsp.t14.base_lat, nas_0024_rsp.t14.base_long);
    }
/*
    // Roaming Indicator List
    if (nas_0024_rsp.t15_valid)
    {
      for (i = 0; (i < nas_0024_rsp.t15.num_instances) && (i < NAS_0024_RSP_T15_ROAM_RSP_MAX); i++ )
      {
        MSG_HIGH("   roam_ind[%d] radio_if = %s roaming_indicator = %d", i, radio_interface_str(nas_0024_rsp.t15.roam_ind[i].radio_if), 
                                                                            nas_0024_rsp.t15.roam_ind[i].roaming_indicator);
      }
    }
*/
    // Default Roaming Indicator
    if (nas_0024_rsp.t16_valid)
    {
      // MSG_HIGH("   def_roam_ind = %d", nas_0024_rsp.t16.def_roam_ind, 0, 0);

      nas_cached_info.def_roam_ind_valid = TRUE;
      nas_cached_info.def_roam_ind = nas_0024_rsp.t16.def_roam_ind;
    }

    // 3GGP2 Time Zone
    if (nas_0024_rsp.t17_valid)
    {
      MSG_HIGH("[NAS] 3GPP2 lp_sec = %d ltm_offset = %d daylt_savings = %d", nas_0024_rsp.t17.lp_sec, nas_0024_rsp.t17.ltm_offset, nas_0024_rsp.t17.daylt_savings);
    }

    // CDMA P_Rev in Use
    if (nas_0024_rsp.t18_valid)
    {
      //MSG_HIGH("   CDMA p_rev_in_use = %d", nas_0024_rsp.t18.p_rev_in_use, 0, 0);
    }

    // 3GPP Time Zone
    if (nas_0024_rsp.t1A_valid)
    {
      //MSG_HIGH("   3GPP time_zone = %d", nas_0024_rsp.t1A.time_zone, 0, 0);
    }

    // 3GPP Network Daylight Saving Adjustment
    if (nas_0024_rsp.t1B_valid)
    {
      //MSG_HIGH("   3GPP adj = %d", nas_0024_rsp.t1B.adj, 0, 0);
    }

    // 3GPP Location Area Code
    if (nas_0024_rsp.t1C_valid)
    {
      registration_status.lac = (int) nas_0024_rsp.t1C.lac;
      //MSG_HIGH("[NAS] 3GPP LAC = %x", registration_status.lac, 0, 0);
    }

    // 3GPP Cell ID
    if (nas_0024_rsp.t1D_valid)
    {
      if((nas_0024_rsp.t01.registration_state != WMM_ATTACH_STATE_ATTACHED) ||
         (nas_0024_rsp.t1D.cell_id != -1))
      {
        registration_status.cell_id = (int) nas_0024_rsp.t1D.cell_id;
        //MSG_HIGH("[NAS] 3GPP cell_id = %x", registration_status.cell_id, 0, 0);
      }
    }

    // 3GPP2 Concurrent Service Info
    if (nas_0024_rsp.t1E_valid)
    {
      //MSG_HIGH("   3GPP2 ccs = %d", nas_0024_rsp.t1E.ccs, 0, 0);
    }

    // 3GPP2 PRL Indicator
    if (nas_0024_rsp.t1F_valid)
    {
      //MSG_HIGH("   3GPP2 prl_ind = %d", nas_0024_rsp.t1F.prl_ind, 0, 0);
    }

    // Dual Transfer Mode Indication (GSM Only)
    if (nas_0024_rsp.t20_valid)
    {
      //MSG_HIGH("   GSM dtm_ind = %d", nas_0024_rsp.t20.dtm_ind, 0, 0);
    }

    // Detailed Service Information
    if (nas_0024_rsp.t21_valid)
    {
      registration_status.srv_status = nas_0024_rsp.t21.srv_status;
      MSG_HIGH("   srv_capability = %s is_sys_forbidden = %d", sys_srv_domain_e_type_str(nas_0024_rsp.t21.srv_capability), nas_0024_rsp.t21.is_sys_forbidden, 0);
      //MSG_HIGH("   hdr_srv_status = %d hdr_hybrid = %d", nas_0024_rsp.t21.hdr_srv_status, nas_0024_rsp.t21.hdr_hybrid, 0);
      nas_cached_info.hdr_hybrid = nas_0024_rsp.t21.hdr_hybrid;
    }

    // CDMA System Info
    if (nas_0024_rsp.t22_valid)
    {
      //MSG_HIGH("   CDMA mcc = %d imsi_11_12 = %d", nas_0024_rsp.t22.mcc, nas_0024_rsp.t22.imsi_11_12, 0);
    }

    // HDR Personality
    if (nas_0024_rsp.t23_valid)
    {
      //MSG_HIGH("   hdr_personality = %d", nas_0024_rsp.t23.hdr_personality, 0, 0);
    }

    // TAC Information for LTE
    if (nas_0024_rsp.t24_valid)
    {
      //MSG_HIGH("   LTE tac = %d", nas_0024_rsp.t24.tac, 0, 0);
    }

    // TAC Information for LTE
    if (nas_0024_rsp.t25_valid)
    {
      //MSG_HIGH("   LTE cs_bar_status = %d ps_bar_status = %d", nas_0024_rsp.t25.cs_bar_status, nas_0024_rsp.t25.ps_bar_status, 0);
    }

    // UMTS Primary Scrambling Code
    if (nas_0024_rsp.t26_valid)
    {
      //MSG_HIGH("   umts_psc = %d", nas_0024_rsp.t26.umts_psc, 0, 0);
    }

    // MNC PCS Digit Include Status
    if (nas_0024_rsp.t27_valid)
    {
      //MSG_HIGH("   mcc = %d mnc = %d mnc_includes_pcs_digit = %d", nas_0024_rsp.t27.mcc, nas_0024_rsp.t27.mnc, nas_0024_rsp.t27.mnc_includes_pcs_digit);
    }

    // HS Call Status
    if (nas_0024_rsp.t28_valid)
    {
      registration_status.hs_call_status = (int) nas_0024_rsp.t28.hs_call_status;
      MSG_HIGH("[NAS] hs_call_status = %d", registration_status.hs_call_status, 0, 0);
    }

    // 20150129 reg_state�� denied�� �ø� ��� SET���� �ܸ��� ��ȣ�� �ʱ�ȭ ��
	  // ������ Reject ���� �ʰ� �� ���ο��� Denied�� �ø��� ��� Searching ���·� ���� ��
	  if((nas_0024_rsp.t21.is_sys_forbidden == 1) && (nas_0024_rsp.t01.registration_state == NET_REG_DENIED))
	  {
	    nas_0024_rsp.t01.registration_state = NET_REG_SEARCHING;
      MSG_HIGH("[NAS] chnage the reg_state from NET_REG_DENIED to NET_REG_SEARCHING", 0,0,0);
	  }

    // if denied, get reject cause
    if(nas_0024_rsp.t01.registration_state == NET_REG_DENIED)
    { 
      if(registration_status.reject_cause == 0)
      {
        ril_request_get_sys_info();
      }
      MSG_HIGH("[NAS] reject_cause = %d(%s)", registration_status.reject_cause, reject_cause_string(registration_status.reject_cause), 0);
    }
    else
    {
      registration_status.reject_cause = 0;
    }

    // 2013-08-14 jgkim No Service ������ �� gprs_status ���� ����
    if(registration_status.srv_status == SYS_SRV_STATUS_NO_SRV)
    {
      registration_status.reg_status =  0;
      registration_status.gprs_status = 0;
      registration_status.rat = 0;
    }
    else
    {
      registration_status.reg_status =  get_registration_status(registration_status.srv_status, nas_0024_rsp.t01.registration_state);
      registration_status.gprs_status = (int) nas_0024_rsp.t01.ps_attach_state;
      registration_status.rat = get_radio_access_technology(nas_0024_rsp.t01.radio_if[0], registration_status.hs_call_status);
    }
	
    if(operator_status.initialized_plmn_name==FALSE && registration_status.srv_status==SYS_SRV_STATUS_SRV)
    {
      if(get_operator_status() == RESULT_SUCCESS)
      {
        get_current_plmn_name_cache();
      }
    }

    MSG_HIGH("[NAS] srv_status = %d registration_state = %s gprs_state = %s", registration_status.srv_status, 
                                                                              registration_status_str(registration_status.reg_status), 
                                                                              attach_status_str(registration_status.gprs_status));
    MSG_HIGH("[NAS] rat = %s cell_id = %x lac = %x", ril_act_e_type_str(registration_status.rat), 
                                                     registration_status.cell_id,
                                                     registration_status.lac); 
  }     

  return RESULT_SUCCESS;
}

/*===========================================================================

  FUNCTION  get_radio_access_technology
  
===========================================================================*/
int get_registration_status(uint8 service_status, uint8 reg_status)
{
  if (service_status == SYS_SRV_STATUS_LIMITED)
  {
    if ((reg_status == NET_REG_NONE) ||        // NOT_REGISTERED
        (reg_status == NET_REG_SEARCHING) ||   // NOT_REGISTERED_SEARCHING
        (reg_status == NET_REG_DENIED) ||      // REGISTRATION_DENIED
        (reg_status == NET_REG_UNKNOWN))       // REGISTRATION_UNKNOWN
    {
      return ((int)reg_status)+10;
    }
  }

  return ((int)reg_status);
}

/*===========================================================================

  FUNCTION  get_radio_access_technology
  
===========================================================================*/
int get_radio_access_technology(uint8 radio_if, uint8 hs_call_status)
{
  int irat = 0;

  // RADIO_IF_UMTS
  if (radio_if == RADIO_IF_UMTS)
  {
    switch (hs_call_status)
    {
      case SYS_HS_IND_HSDPA_SUPP_CELL:
        irat = RIL_ACT_HSDPA;
        break;
      case SYS_HS_IND_HSUPA_SUPP_CELL:
        irat = RIL_ACT_HSUPA;
        break;
      case SYS_HS_IND_HSDPA_HSUPA_SUPP_CELL:
        irat = RIL_ACT_HSPA;
        break;
      case SYS_HS_IND_HSDPAPLUS_SUPP_CELL:
      case SYS_HS_IND_HSDPAPLUS_HSUPA_SUPP_CELL:
      case SYS_HS_IND_DC_HSDPAPLUS_SUPP_CELL:
      case SYS_HS_IND_DC_HSDPAPLUS_HSUPA_SUPP_CELL:
      case SYS_HS_IND_HSDPAPLUS_64QAM_HSUPA_SUPP_CELL:
      case SYS_HS_IND_HSDPAPLUS_64QAM_SUPP_CELL:
        irat = RIL_ACT_HSPAP;
        break;
      default:
        irat = RIL_ACT_UMTS;
        break;
    }
  }
  // RADIO_IF_GSM
  else if (radio_if == RADIO_IF_GSM)
  {
    switch (hs_call_status)
    {
      case SYS_HS_IND_HSDPA_SUPP_CELL: irat = RIL_ACT_EDGE;      break;
      default: irat = RIL_ACT_GPRS;      break;
    }
  }
  // temporary code - check please!!
  // RADIO_IF_CDMA_1X
  else if (radio_if == RADIO_IF_CDMA_1X)
  {
    irat = RIL_ACT_1XRTT; // temporary code
  }
  // RADIO_IF_CDMA_1XEVDO
  else if (radio_if == RADIO_IF_CDMA_1XEVDO)
  {
    irat = RIL_ACT_EVDO0; // temporary code
  }
  // RADIO_IF_CDMA_1XEVDO
  else if (radio_if == RADIO_IF_LTE)
  {
    irat = RIL_ACT_LTE; // temporary code
  }      
  // DEFAULT
  else
  {
    irat = RIL_ACT_UNKNOWN;
  }

  return irat;
}

/*===========================================================================

  FUNCTION  ril_request_get_protocol_info
  
===========================================================================*/
uint8 ril_request_get_protocol_info(RIL_Protocol_Info *protocol_info)
{
  int rc = QMI_NO_ERR, index=0;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5556_rsp_s nas_5556_rsp;

  memset(&nas_5556_rsp, 0, sizeof(nas_5556_rsp_s));

  MSG_HIGH("[NAS] ril_request_get_protocol_info()", 0, 0, 0);
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_protocol_info((int)nas_client_handle, &nas_5556_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS] ril_request_get_protocol_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {

    if (nas_5556_rsp.t10_valid)
    {
      if (nas_5556_rsp.t10.pref_mode == 14)
        protocol_info->pref_mode = 1; // WCDMA only
      else if (nas_5556_rsp.t10.pref_mode == 30)
        protocol_info->pref_mode = 2; // LTE only
      else if ((nas_5556_rsp.t10.pref_mode == 35) || (nas_5556_rsp.t10.pref_mode == 4))
        protocol_info->pref_mode = 0; // Automatic
      else
        protocol_info->pref_mode = -1; // Others
        
      MSG_HIGH("     protocol_info->pref_mode  = %d", protocol_info->pref_mode, 0, 0);
    }

    if (nas_5556_rsp.t11_valid)
    {
      protocol_info->service_domain_pref = nas_5556_rsp.t11.service_domain_pref;  
      MSG_HIGH("     protocol_info->service_domain_pref = %d", protocol_info->service_domain_pref, 0, 0);
    }

    if (nas_5556_rsp.t12_valid)
    {
      protocol_info->security_info.security = nas_5556_rsp.t12.security;      
      MSG_HIGH("     protocol_info->security_info.security = %d", protocol_info->security_info.security, 0, 0);
    }

    if (nas_5556_rsp.t13_valid)
    {
      protocol_info->sms_gw_bearer_pref = nas_5556_rsp.t13.sms_gw_bearer_pref;      
      MSG_HIGH("     protocol_info->sms_gw_bearer_pref = %d", protocol_info->sms_gw_bearer_pref, 0, 0);
    }

    if (nas_5556_rsp.t15_valid)
    {
      protocol_info->isr_enabled = (uint8)nas_5556_rsp.t15.isr_enabled;    
      MSG_HIGH("     protocol_info->isr_enabled = %d", protocol_info->isr_enabled, 0, 0);
    }

    if (nas_5556_rsp.t16_valid)
    {
      protocol_info->rrc_version = (uint8)nas_5556_rsp.t16.wcdma_rrc_version;
      MSG_HIGH("     protocol_info->rrc_version = %d", protocol_info->rrc_version, 0, 0);
    }

    if (nas_5556_rsp.t17_valid)
    {
      convert_frequency_to_ril_Index(nas_5556_rsp.t17.wcdma_dl_freq_enabled,
                                                         nas_5556_rsp.t17.wcdma_dl_freq,
                                                         nas_5556_rsp.t17.forced_freq,
                                                         &protocol_info->wcdma_dl_freq,
                                                         &protocol_info->user_freq);
      
      MSG_HIGH("     protocol_info->wcdma_dl_freq = %d user_freq = %d",
                                    protocol_info->wcdma_dl_freq,
                                    protocol_info->user_freq,
                                    0);
    }

    if (nas_5556_rsp.t18_valid)
    {
      protocol_info->gcf_test_mode = (uint16)nas_5556_rsp.t18.gcf_test_mode;
      MSG_HIGH("     protocol_info->gcf_test_mode = %d", protocol_info->gcf_test_mode
        , 0, 0);
    }

    return RESULT_SUCCESS;
  }

}

/*===========================================================================

  FUNCTION  qmi_nas_set_preferred_network
  
===========================================================================*/
uint8 ril_request_set_protocol_info(RIL_Protocol_Info protocol_info)
{
  int rc = QMI_NO_ERR, frequency=0;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5557_req_s nas_5557_req;
  boolean freq_enable=FALSE;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  MSG_HIGH("[NAS] ril_request_set_protocol_info()", 0, 0, 0);

  memset(&nas_5557_req, 0, sizeof(nas_5557_req_s));

  nas_5557_req.t10_valid = TRUE;
  if (protocol_info.pref_mode == 0)
    nas_5557_req.t10.pref_mode = 35;  
  else if (protocol_info.pref_mode == 1)
    nas_5557_req.t10.pref_mode = 14;  
  else if (protocol_info.pref_mode == 2)
    nas_5557_req.t10.pref_mode = 30;  
  else
    nas_5557_req.t10.pref_mode = 4;  

  nas_5557_req.t11_valid = TRUE;
  nas_5557_req.t11.service_domain_pref = protocol_info.service_domain_pref;  

  nas_5557_req.t12_valid = TRUE;
  nas_5557_req.t12.security = protocol_info.security_info.security;

  nas_5557_req.t13_valid = TRUE;
  nas_5557_req.t13.sms_gw_bearer_pref = protocol_info.sms_gw_bearer_pref;  

  nas_5557_req.t15_valid = TRUE;
  nas_5557_req.t15.isr_enabled = protocol_info.isr_enabled;
  
  nas_5557_req.t16_valid = TRUE;
  nas_5557_req.t16.wcdma_rrc_version = protocol_info.rrc_version;
  
  nas_5557_req.t17_valid = TRUE;
  if(RESULT_FAILURE == convert_ril_Index_to_frequency( protocol_info.wcdma_dl_freq, 
                                                                                        protocol_info.user_freq,
                                                                                        &nas_5557_req.t17.wcdma_dl_freq_enabled,
                                                                                        &nas_5557_req.t17.wcdma_dl_freq,
                                                                                        &nas_5557_req.t17.forced_freq))
  {
    MSG_ERROR("[NAS] qmi_nas_set_protocol_info!! only use SKT or KT", 0, 0, 0);
    return RESULT_FAILURE;
  }  
  
  nas_5557_req.t18_valid = TRUE;
  nas_5557_req.t18.gcf_test_mode = protocol_info.gcf_test_mode;

  MSG_HIGH("     protocol_info.pref_mode = %d", protocol_info.pref_mode,0,0);
  MSG_HIGH("     protocol_info.service_domain_pref = %d", protocol_info.service_domain_pref,0,0);
  MSG_HIGH("     protocol_info.security_info.security = %d", protocol_info.security_info.security,0,0);
  MSG_HIGH("     protocol_info.sms_gw_bearer_pref = %d", protocol_info.sms_gw_bearer_pref,0,0);
  MSG_HIGH("     protocol_info.isr_enabled = %d", protocol_info.isr_enabled,0,0);
  MSG_HIGH("     protocol_info.rrc_version = %d", protocol_info.rrc_version,0,0);
  MSG_HIGH("     protocol_info.wcdma_dl_freq = %d", protocol_info.wcdma_dl_freq,0,0);
  MSG_HIGH("     protocol_info.user_freq = %d", protocol_info.user_freq,0,0);
  MSG_HIGH("     protocol_info.gcf_test_mode = %d", protocol_info.gcf_test_mode,0,0);
  
  rc = qmi_nas_set_protocol_info((int)nas_client_handle,
                                                          &nas_5557_req,
                                                          &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS] qmi_nas_set_protocol_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}

/*===========================================================================

  FUNCTION  ril_request_get_hd_mode
  
===========================================================================*/
uint8 ril_request_get_hd_mode(uint8 *hd_mode)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_555E_rsp_s nas_555E_rsp;

  memset(&nas_555E_rsp, 0, sizeof(nas_555E_rsp_s));
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_ims_enable((int)nas_client_handle, &nas_555E_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]ril_request_get_hd_mode!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    *hd_mode = nas_555E_rsp.t10.ims_enabled;
    return RESULT_SUCCESS;
  }

}


/*===========================================================================

  FUNCTION  ril_request_get_ecall_mode
  
===========================================================================*/
//jaeyong1.park
uint8 ril_request_get_ecall_mode(uint32 *ecall_mode)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_ECALLEN_rsp_s nas_ECALLEN_rsp;

  memset(&nas_ECALLEN_rsp, 0, sizeof(nas_ECALLEN_rsp_s));
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_ecall_enable((int)nas_client_handle, &nas_ECALLEN_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]ril_request_get_ecall_mode!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    *ecall_mode = nas_ECALLEN_rsp.t10.ims_enabled;
    return RESULT_SUCCESS;
  }

}


/*===========================================================================

  FUNCTION  ril_request_get_network_scan
  
===========================================================================*/
uint8 ril_request_get_network_scan()
{
    int rc = QMI_NO_ERR;
	int qmi_err_code = QMI_SERVICE_ERR_NONE;
	
	if(nas_client_handle == INVALID_HANDLE_VALUE)
	{
	  printf("ril_request_get_network_scan() INVALID_HANDLE_VALUE\n");
	  return RESULT_FAILURE;
	}

	if (qmi_nas_query_available_networks((int)nas_client_handle,&qmi_err_code) == QMI_NO_ERR );	
	{
		return RESULT_SUCCESS;
	}

	return RESULT_FAILURE;
}



/*===========================================================================

  FUNCTION  ril_request_get_modem_value
  
===========================================================================*/
//jaeyong1.park
uint8 ril_request_get_modem_value(int getvalcmd, char* reqstr, char *rspstr)
{
/*
* [PARAM]
*  - getvalcmd : defined in QMI_NAS_SRVC.H 
*  - reqstr : string. from tof to modem 
*  - rspstr : string. from modem to tof
*/

  MSG_HIGH("[jaeyong1.park]start ril_request_get_modem_value : CMD = %x", getvalcmd,0,0);  


  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_GETVAL_rsp_s nas_GETVAL_rsp;

  memset(&nas_GETVAL_rsp, 0, sizeof(nas_ECALLEN_rsp_s));

  // ready
  strcpy(nas_GETVAL_rsp.t1.pdata, reqstr);    
  
  MSG_HIGH("[jaeyong1.park]ril_request_get_modem_value : nas pdata = %s", nas_GETVAL_rsp.t1.pdata,0,0);	
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  //send & waiting response
  rc = qmi_nas_get_modem_value((int)nas_client_handle, &nas_GETVAL_rsp, &qmi_err_code, getvalcmd);

  //process return string value
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {  
    MSG_ERROR("[NAS]qmi_nas_get_modem_value!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    MSG_HIGH("[jaeyong1.park]ril_request_get_modem_value :  no qmi error, no qmi service error.. normal finished. OK", 0,0,0);		
    MSG_HIGH("[jaeyong1.park]ril_request_get_modem_value : array size of struct: %d, received strlen : %d ", sizeof(nas_GETVAL_rsp.t1.pdata), strlen(nas_GETVAL_rsp.t1.pdata),0);		

	strncpy (rspstr, (char*)nas_GETVAL_rsp.t1.pdata,  strlen(nas_GETVAL_rsp.t1.pdata));

    MSG_HIGH("[jaeyong1.park]ril_request_get_modem_value : copy finished", 0,0,0);		
    return RESULT_SUCCESS;
  }
}


/*===========================================================================

  FUNCTION  request_set_ecall_enable   

===========================================================================*/
// jaeyong1.park 2016-09-28
uint8 request_set_ecall_enable(nas_ecall_setenable_e_type_v02 on_off)
{
	int rc = QMI_NO_ERR;
	int qmi_err_code = QMI_SERVICE_ERR_NONE;
	nas_ecallen_req_s nas_ecallen_req;
	
	if(nas_client_handle == INVALID_HANDLE_VALUE)
	  return RESULT_FAILURE;

	printf("request_set_ecall_enable() nas_client_handle = %d\n", nas_client_handle);
	memset(&nas_ecallen_req, 0, sizeof(nas_ecallen_req));
	
	nas_ecallen_req.t1_valid = TRUE;
	nas_ecallen_req.t1.ecall_enabled = on_off;
	
	rc = qmi_nas_set_ecall_enable((int)nas_client_handle,
												  &nas_ecallen_req,
												  &qmi_err_code);

	if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
	{
		MSG_ERROR("[NAS] request_set_ecall_enable!! rc: %d err_code : %d", rc, qmi_err_code, 0);
		return RESULT_FAILURE;
	}
	
	MSG_HIGH("[NAS] request_set_ecall_enable success : %d", on_off, 0, 0);
	return RESULT_SUCCESS;
}



/*===========================================================================

  FUNCTION  request_set_ecall_config   

===========================================================================*/

uint8 request_set_ecall_config(int index, int numdata)
{
		int rc = QMI_NO_ERR;
		int qmi_err_code = QMI_SERVICE_ERR_NONE;
		nas_ecallnumber_req_s nas_ecallconf_req;
		
		if(nas_client_handle == INVALID_HANDLE_VALUE)
		  return RESULT_FAILURE;
		
		memset(&nas_ecallconf_req, 0, sizeof(nas_ecallconf_req));

		if (index == 1)
	 	{ nas_ecallconf_req.t2_valid = TRUE;
		  nas_ecallconf_req.t2.numdata = numdata;//copy data
		  
		}
		else if (index == 2)
	 	{ nas_ecallconf_req.t3_valid = TRUE;
		  nas_ecallconf_req.t3.numdata = numdata;//copy data
		  
		}
		else if (index == 3)
	 	{ nas_ecallconf_req.t4_valid = TRUE;
		  nas_ecallconf_req.t4.numdata = numdata;//copy data
		  
		}
		else if (index == 4)
	 	{ nas_ecallconf_req.t5_valid = TRUE;
		  nas_ecallconf_req.t5.numdata = numdata;//copy data
		  
		}
		else if (index == 5)
	 	{ nas_ecallconf_req.t5_valid = TRUE;
		  nas_ecallconf_req.t5.numdata = numdata;//copy data
			MSG_ERROR("[jaeyong1] index 5, in num %d, str num %d", numdata, nas_ecallconf_req.t5.numdata, 0);
		  
		}
		else if (index == 6)
	 	{ nas_ecallconf_req.t6_valid = TRUE;
		  nas_ecallconf_req.t6.numdata = numdata;//copy data
		  
		}			
	
		rc = qmi_nas_set_ecall_configfile((int)nas_client_handle,
													  &nas_ecallconf_req,
													  &qmi_err_code);
	
		if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
		{
			MSG_ERROR("[NAS] request_set_ecall_config!! rc: %d err_code : %d", rc, qmi_err_code, 0);
			return RESULT_FAILURE;
		}
		
		MSG_HIGH("[NAS] request_set_ecall_config success : %s", nas_ecallconf_req, 0, 0);
		return RESULT_SUCCESS;

	
}


/*===========================================================================
  FUNCTION  request_set_ecall_callback_timeout2

===========================================================================*/
// jaeyong1.park 2016-10-18
boolean request_set_ecall_callback_timeout2(uint32 numdata)
{
  // This function for RETURN ENUM VALUE convert...
  char reqstr[50]={0,};
  char resstr[50]={0,};
  
  sprintf(reqstr, "%d", numdata);
  if(ril_request_get_modem_value(SET_ECALL_CALLBACK_TIMEOUT, reqstr, resstr) == RESULT_FAILURE)
  {
    MSG_ERROR("[NAS]request_set_ecall_callback_timeout2() Fail to process!! ",0,0,0);

    return RESULT_FAILURE;
  }
  
  //printf("[NAS]request_set_ecall_session_timeout() on_off =%s\n", resstr);
  MSG_HIGH("[NAS] request_set_ecall_callback_timeout2 success. return true", 0, 0, 0);
  return RESULT_SUCCESS;
}


/*===========================================================================
  FUNCTION  request_set_ecall_number 

===========================================================================*/
// jaeyong1.park 2016-09-28
uint8 request_set_ecall_number(char* ecallnumber)
{
	int rc = QMI_NO_ERR;
	int qmi_err_code = QMI_SERVICE_ERR_NONE;
	nas_ecallnumber_req_s nas_ecallnumber_req;
	
	if(nas_client_handle == INVALID_HANDLE_VALUE)
	  return RESULT_FAILURE;
	
	memset(&nas_ecallnumber_req, 0, sizeof(nas_ecallnumber_req));
	
	nas_ecallnumber_req.t1_valid = TRUE;
	strcpy(nas_ecallnumber_req.t1.ecall_number, ecallnumber); //copy tel number
	
	rc = qmi_nas_set_ecall_number((int)nas_client_handle,
												  &nas_ecallnumber_req,
												  &qmi_err_code);

	if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
	{
		MSG_ERROR("[NAS] request_set_ecall_number!! rc: %d err_code : %d", rc, qmi_err_code, 0);
		return RESULT_FAILURE;
	}
	
	MSG_HIGH("[NAS] request_set_ecall_number success : %s", ecallnumber, 0, 0);
	return RESULT_SUCCESS;
}

// 2016-10-11 mwkim, InnoJIRA : AS045-673
/*===========================================================================

  FUNCTION  request_enable_ecall_only_mode   

===========================================================================*/
// mwkim 2016-10-11
uint8 request_set_ecall_only_mode(uint8 on_off)
{
	int rc = QMI_NO_ERR;
	int qmi_err_code = QMI_SERVICE_ERR_NONE;
	nas_ecallonly_en_req_s nas_ecallonly_en_req;
	
	if(nas_client_handle == INVALID_HANDLE_VALUE)
	  return RESULT_FAILURE;
	
	memset(&nas_ecallonly_en_req, 0, sizeof(nas_ecallonly_en_req));
	
	nas_ecallonly_en_req.t1_valid = TRUE;
	nas_ecallonly_en_req.t1.ecallonly_enabled = on_off;
	
	rc = qmi_nas_set_ecall_only_mode((int)nas_client_handle,
												  &nas_ecallonly_en_req,
												  &qmi_err_code);

	if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
	{
		MSG_ERROR("[NAS] request_enable_ecall_only_mode!! rc: %d err_code : %d", rc, qmi_err_code, 0);
		return RESULT_FAILURE;
	}
	
	MSG_HIGH("[NAS] request_set_ecall_enable success : %d", on_off, 0, 0);
	return RESULT_SUCCESS;
}

// 2016-10-14 mwkim, InnoJIRA : AS045-671
/*===========================================================================

  FUNCTION  request_read_ecall_oper_mode   

===========================================================================*/
uint8 request_get_ecall_oper_mode(uint8 * ecall_mode_value)
{
	int							 	rc = QMI_NO_ERR;
	int 							qmi_err_code = QMI_SERVICE_ERR_NONE;
	nas_7042_rsp_s   	nas_7042_rsp;

	if(nas_client_handle == INVALID_HANDLE_VALUE)
	return RESULT_FAILURE;
	
	rc = qmi_nas_get_ecall_oper_mode( (int)nas_client_handle,
																			&nas_7042_rsp,
																			&qmi_err_code );	

	if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
	{
		MSG_ERROR("[NAS] qmi_nas_read_ecall_oper_mode!! rc: %d err_code : %d", rc, qmi_err_code, 0);
		return RESULT_FAILURE;
	}
	else
	{
		*ecall_mode_value = nas_7042_rsp.t1.ecallmode_read;
		return RESULT_SUCCESS;
	}
}


/*===========================================================================

  FUNCTION  ril_request_set_hd_mode
  
===========================================================================*/
uint8 ril_request_set_hd_mode(uint8 hd_mode)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_555F_req_s nas_555F_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_555F_req, 0, sizeof(nas_555F_req_s));

  nas_555F_req.t10_valid = TRUE;
  nas_555F_req.t10.ims_enabled = hd_mode;  	

  rc = qmi_nas_set_ims_enable((int)nas_client_handle,
                                                &nas_555F_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS] ril_request_set_hd_mode!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  MSG_HIGH("[NAS] ril_request_set_hd_mode success : %d", hd_mode, 0, 0);
  return RESULT_SUCCESS;

}

/*===========================================================================

  FUNCTION  ril_request_get_ims_pdn
  
===========================================================================*/
uint8 ril_request_get_ims_pdn(uint16 *ims_pdn)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5560_rsp_s nas_5560_rsp;

  memset(&nas_5560_rsp, 0, sizeof(nas_5560_rsp_s));
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_ims_pdn_enable((int)nas_client_handle, &nas_5560_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]ril_request_get_ims_pdn!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    if(nas_5560_rsp.t10.ims_pdn_enabled == 1)
      *ims_pdn = 0;
    else
      *ims_pdn = 1;
    
    return RESULT_SUCCESS;
  }

}

/*===========================================================================

  FUNCTION  ril_request_set_ims_pdn
  
===========================================================================*/
uint8 ril_request_set_ims_pdn(uint16 ims_pdn)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5561_req_s nas_5561_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_5561_req, 0, sizeof(nas_5561_req_s));

  nas_5561_req.t10_valid = TRUE;
  nas_5561_req.t10.ims_pdn_enabled = ims_pdn+1;  	

  rc = qmi_nas_set_ims_pdn_enable((int)nas_client_handle,
                                                &nas_5561_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_set_ims_pdn!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}

/*===========================================================================

  FUNCTION  ril_request_get_ims_param_config
  
===========================================================================*/
uint8 ril_request_get_ims_param_config(RIL_Ims_Param_Config *ims_param)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5565_rsp_s nas_5565_rsp;

  memset(&nas_5565_rsp, 0, sizeof(nas_5565_rsp_s));
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_ims_user_config((int)nas_client_handle, &nas_5565_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[IMS] qmi_nas_get_ims_user_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    strcpy(ims_param->regConfigUserName, nas_5565_rsp.t10.regConfigUserName);
    strcpy(ims_param->regConfigPassword, nas_5565_rsp.t11.regConfigPassword);
    strcpy(ims_param->regConfigPrivateURI, nas_5565_rsp.t12.regConfigPrivateURI);
    strcpy(ims_param->regConfigDomainName, nas_5565_rsp.t13.regConfigDomainName);
    return RESULT_SUCCESS;
  }

}

/*===========================================================================

  FUNCTION  ril_request_set_ims_param_config
  
===========================================================================*/
uint8 ril_request_set_ims_param_config(RIL_Ims_Param_Config ims_param)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5566_req_s nas_5566_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_5566_req, 0, sizeof(nas_5566_req_s));

  nas_5566_req.t10_valid = TRUE;
  strcpy(nas_5566_req.t10.regConfigUserName, ims_param.regConfigUserName);

  nas_5566_req.t11_valid = TRUE;
  strcpy(nas_5566_req.t11.regConfigPassword, ims_param.regConfigPassword);

  nas_5566_req.t12_valid = TRUE;
  strcpy(nas_5566_req.t12.regConfigPrivateURI, ims_param.regConfigPrivateURI);

  nas_5566_req.t13_valid = TRUE;
  strcpy(nas_5566_req.t13.regConfigDomainName, ims_param.regConfigDomainName);

  rc = qmi_nas_set_ims_user_config((int)nas_client_handle,
                                                &nas_5566_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_set_ims_user_config!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}

/*===========================================================================

  FUNCTION  ril_request_get_ims_rcs_auto_config
  
===========================================================================*/
uint8 ril_request_get_ims_rcs_auto_config(RIL_Ims_Rcs_Auto_Config *ims_rcs_auto_config)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_556B_rsp_s nas_556B_rsp;

  memset(&nas_556B_rsp, 0, sizeof(nas_556B_rsp_s));
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_ims_rcs_auto_config((int)nas_client_handle, &nas_556B_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[IMS] qmi_nas_get_ims_rcs_auto_config!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    ims_rcs_auto_config->DisableAutoConfig = nas_556B_rsp.t10.DisableAutoConfig;
    strcpy(ims_rcs_auto_config->RCSConfigServerAddress, nas_556B_rsp.t11.RCSConfigServerAddress);
    strcpy(ims_rcs_auto_config->RCSConfigServerPort, nas_556B_rsp.t12.RCSConfigServerPort);
    
    MSG_HIGH("[IMS] RCSConfigServerAddress : %s, RCSConfigServerPort : %s", ims_rcs_auto_config->RCSConfigServerAddress, ims_rcs_auto_config->RCSConfigServerPort, 0);
    
    return RESULT_SUCCESS;
  }

}

/*===========================================================================

  FUNCTION  ril_request_set_ims_rcs_auto_config
  
===========================================================================*/
uint8 ril_request_set_ims_rcs_auto_config(RIL_Ims_Rcs_Auto_Config ims_rcs_auto_config)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_556C_req_s nas_556C_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_556C_req, 0, sizeof(nas_556C_req_s));

  nas_556C_req.t11_valid = TRUE;
  strcpy(nas_556C_req.t11.RCSConfigServerAddress, ims_rcs_auto_config.RCSConfigServerAddress);

  nas_556C_req.t12_valid = TRUE;
  strcpy(nas_556C_req.t12.RCSConfigServerPort, ims_rcs_auto_config.RCSConfigServerPort);

  MSG_HIGH("[IMS] RCSConfigServerAddress : %s, RCSConfigServerPort : %s", nas_556C_req.t11.RCSConfigServerAddress, nas_556C_req.t12.RCSConfigServerPort, 0);

  rc = qmi_nas_set_ims_rcs_auto_config((int)nas_client_handle,
                                                &nas_556C_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_set_ims_rcs_auto_config!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}

/*===========================================================================

  FUNCTION  ril_request_get_ims_dpl_param
  
===========================================================================*/
uint8 ril_request_get_ims_dpl_param(int request, RIL_Ims_Dpl_Param *ims_dpl_param)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_556D_rsp_s nas_556D_rsp;

  memset(&nas_556D_rsp, 0, sizeof(nas_556D_rsp_s));
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_ims_dpl_param((int)nas_client_handle, &nas_556D_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[IMS] qmi_nas_get_ims_dpl_param!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    switch(request)
    {
      case REQUEST_PARAM_SRC:
        ims_dpl_param->IMSParamSrc = nas_556D_rsp.t10.IMSParamSrc;
      break;

      default:
      break;
    }

    return RESULT_SUCCESS;
  }

}

/*===========================================================================

  FUNCTION  ril_request_set_ims_dpl_param
  
===========================================================================*/
uint8 ril_request_set_ims_dpl_param(int request, RIL_Ims_Dpl_Param ims_dpl_param)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_556E_req_s nas_556E_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_556E_req, 0, sizeof(nas_556E_req_s));

  switch(request)
  {
    case REQUEST_PARAM_SRC:
      nas_556E_req.t10_valid = TRUE;
      nas_556E_req.t10.IMSParamSrc = ims_dpl_param.IMSParamSrc;
    break;

    default:
    break;  
  }

  rc = qmi_nas_set_ims_dpl_param((int)nas_client_handle,
                                                &nas_556E_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_set_ims_dpl_param!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}

/*===========================================================================

  FUNCTION  ril_request_get_ims_acs_disable
  
===========================================================================*/
uint8 ril_request_get_ims_acs_disable(uint8 *acs_disable)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_556B_rsp_s nas_556B_rsp;

  memset(&nas_556B_rsp, 0, sizeof(nas_556B_rsp_s));
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_ims_rcs_auto_config((int)nas_client_handle, &nas_556B_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[IMS] qmi_nas_get_ims_rcs_auto_config!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    *acs_disable = nas_556B_rsp.t10.DisableAutoConfig;
    MSG_HIGH("[IMS] DisableAutoConfig : %d", *acs_disable, 0, 0);
    
    return RESULT_SUCCESS;
  }

}

/*===========================================================================

  FUNCTION  ril_request_set_ims_acs_disable
  
===========================================================================*/
uint8 ril_request_set_ims_acs_disable(uint8 acs_disable)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_556C_req_s nas_556C_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_556C_req, 0, sizeof(nas_556C_req_s));

  nas_556C_req.t10_valid = TRUE;
  nas_556C_req.t10.DisableAutoConfig = acs_disable;

  MSG_HIGH("[IMS] DisableAutoConfig : %d", nas_556C_req.t10.DisableAutoConfig, 0, 0);

  rc = qmi_nas_set_ims_rcs_auto_config((int)nas_client_handle,
                                                &nas_556C_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_set_ims_rcs_auto_config!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}
//hongsg 20140729
/*===========================================================================

  FUNCTION  ril_request_get_ims_qipcall_config
  
===========================================================================*/
uint8 ril_request_get_ims_qipcall_config(int request, RIL_Ims_Qipcall_Config *ims_qipcall_config)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_556F_rsp_s nas_556F_rsp;

  memset(&nas_556F_rsp, 0, sizeof(nas_556F_rsp_s));
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_ims_qipcall_config((int)nas_client_handle, &nas_556F_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[IMS] qmi_nas_get_ims_qipcall_config!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    switch(request)
    {
      case REQUEST_RTCP:
        ims_qipcall_config->rtcp = nas_556F_rsp.t10.EnableRTCPforActiveVOIPCall;
      break;

      default:
      break;
    }

    return RESULT_SUCCESS;
  }

}

/*===========================================================================

  FUNCTION  ril_request_set_ims_qipcall_config
  
===========================================================================*/
uint8 ril_request_set_ims_qipcall_config(int request, RIL_Ims_Qipcall_Config ims_qipcall_config)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5570_req_s nas_5570_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_5570_req, 0, sizeof(nas_5570_req_s));

  switch(request)
  {
    case REQUEST_RTCP:
      nas_5570_req.t10_valid = TRUE;
      nas_5570_req.t10.EnableRTCPforActiveVOIPCall = ims_qipcall_config.rtcp;
    break;

    default:
    break;  
  }

  rc = qmi_nas_set_ims_qipcall_config((int)nas_client_handle,
                                                &nas_5570_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_set_ims_qipcall_config!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}


/*===========================================================================

  FUNCTION  ril_request_get_ims_reg_config
  
===========================================================================*/
uint8 ril_request_get_ims_reg_config(uint8 request, RIL_Ims_Reg_Config *ims_reg_config)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5571_rsp_s nas_5571_rsp;

  memset(&nas_5571_rsp, 0, sizeof(nas_5571_rsp_s));
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_ims_reg_config((int)nas_client_handle, &nas_5571_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[IMS] qmi_nas_get_ims_reg_config!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    switch(request)
    {
      case REQUEST_REG_EVENT:
        ims_reg_config->reg_event_packet = nas_5571_rsp.t10.RegEventPacket;
      break;

      default:
      break;
    }

    return RESULT_SUCCESS;
  }

}

/*===========================================================================

  FUNCTION  ril_request_set_ims_reg_config
  
===========================================================================*/
uint8 ril_request_set_ims_reg_config(uint8 request, RIL_Ims_Reg_Config ims_reg_config)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5572_req_s nas_5572_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_5572_req, 0, sizeof(nas_5572_req_s));

  switch(request)
  {
    case REQUEST_REG_EVENT:
      nas_5572_req.t10_valid = TRUE;
      nas_5572_req.t10.RegEventPacket = ims_reg_config.reg_event_packet;
    break;

    default:
    break;  
  }

  rc = qmi_nas_set_ims_reg_config((int)nas_client_handle,
                                                &nas_5572_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_set_ims_reg_config!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}


/*===========================================================================

  FUNCTION  ril_request_get_ims_voip_config
  
===========================================================================*/
uint8 ril_request_get_ims_voip_config(uint16 *session_timer)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5574_rsp_s nas_5574_rsp;

  memset(&nas_5574_rsp, 0, sizeof(nas_5574_rsp_s));
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_ims_voip_config((int)nas_client_handle, &nas_5574_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[IMS] qmi_nas_get_ims_voip_config!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    *session_timer = nas_5574_rsp.t10.voipConfigExpires;
    MSG_HIGH("[IMS] volte session timer : %d", *session_timer, 0, 0);

    return RESULT_SUCCESS;
  }

}

/*===========================================================================

  FUNCTION  ril_request_set_ims_voip_config
  
===========================================================================*/
uint8 ril_request_set_ims_voip_config(uint16 session_timer)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5575_req_s nas_5575_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_5575_req, 0, sizeof(nas_5575_req_s));

  nas_5575_req.t10_valid = TRUE;
  nas_5575_req.t10.voipConfigExpires = session_timer;

  if (nas_5575_req.t10.voipConfigExpires < 90)
  {
    return RESULT_FAILURE;
  }

  rc = qmi_nas_set_ims_voip_config((int)nas_client_handle,
                                                &nas_5575_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_set_ims_voip_config!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}


//chad_20160602 start>>>
/*===========================================================================

  FUNCTION  request_set_ims_enable
  
===========================================================================*/
boolean request_set_ims_enable(uint8 on_off)
{
  if(ril_request_set_hd_mode(on_off) == RESULT_FAILURE)
  {
    MSG_ERROR("[NAS]request_set_ims_enable() Fail to process!! ",0,0,0);

    return FALSE;
  }

  return TRUE;
}

/*===========================================================================

  FUNCTION  request_get_ims_enable
  
===========================================================================*/
boolean request_get_ims_enable(uint8 *on_off)
{
  if(ril_request_get_hd_mode(on_off) == RESULT_FAILURE)
  {
    MSG_ERROR("[NAS]request_get_ims_enable() Fail to process!! ",0,0,0);

    return FALSE;
  }

  printf("[TOF]request_get_ims_enable() on_off =%d\n",*on_off);
  
  return TRUE;
}


/*===========================================================================

  FUNCTION  request_get_ecall_enable
  
===========================================================================*/
boolean request_get_ecall_enable(uint32 *on_off)
{
  // This function for RETURN ENUM VALUE convert...
  char *reqstr="abcc"; //dummy for test
  char resstr[50]={0,};
  if(ril_request_get_modem_value(GET_ECALL_ENABLE, reqstr, resstr) == RESULT_FAILURE)
  {
    MSG_ERROR("[NAS]request_get_ecall_enable() Fail to process!! ",0,0,0);

    return RESULT_FAILURE;
  }
  
  printf("[NAS]request_get_ecall_enable() on_off =%s\n", resstr);

  //convert to return type
  *on_off = atoi(resstr);
  
  return RESULT_SUCCESS;
}



/*===========================================================================

  FUNCTION request_get_ecall_config
  
===========================================================================*/
boolean request_get_ecall_config(int index, char* ecallnumber)
{
  // This function for RETURN ENUM VALUE convert...
  char reqstr[10]={0,};
  char resstr[180]={0,};

  if(ril_request_get_modem_value(GET_ECALL_CONFIG_FILE, reqstr, resstr) == RESULT_FAILURE)
  {
    MSG_ERROR("[NAS]request_get_ecall_config() Fail to process!! ",0,0,0);

    return RESULT_FAILURE;
  }

//  printf("[NAS]request_get_ecall_config() index %d, value =%s\n", index,  resstr);

  //token 
  int it = 0;
  char sep[] = {0x0d, 0x0a,' ', '\n',  0x00};

	char * pch;
	//printf ("Splitting string \"%s\" into tokens:\n",resstr);
	pch = strtok (resstr, sep); //space, newline
	while (pch != NULL)
	{
	  //printf ("[%d]%s\n",it, pch);

		if (it==((index*2)-1))
			{
			  strcpy(ecallnumber, pch); //return value
			}
	  pch = strtok (NULL, sep);		
	  it++;
	}
  
  return RESULT_SUCCESS;
}



/*===========================================================================

  FUNCTION  request_set_volte_session_timer
  
===========================================================================*/
boolean request_set_volte_session_timer(uint16 sess_time)
{
  if(ril_request_set_ims_voip_config(sess_time) == RESULT_FAILURE)
  {
    MSG_ERROR("[NAS]request_set_volte_session_timer() Fail to process!! ",0,0,0);

    return FALSE;
  }

  return TRUE;
}

/*===========================================================================

  FUNCTION  request_get_volte_session_timer
  
===========================================================================*/
boolean request_get_volte_session_timer(uint16 *sess_time)
{
  if(ril_request_get_ims_voip_config(sess_time) == RESULT_FAILURE)
  {
    MSG_ERROR("[NAS]request_get_volte_session_timer() Fail to process!! ",0,0,0);

    return FALSE;
  }

  printf("[TOF]request_get_volte_session_timer() sess_time =%d\n",*sess_time);
  
  return TRUE;
}




/*===========================================================================

  FUNCTION request_get_modem_version
  
===========================================================================*/
boolean request_get_modem_version(char* modem_version)
{
	// This function for RETURN ENUM VALUE convert...
	char reqstr[10]={0,};
	char resstr[180]={0,};
	if(ril_request_get_modem_value(GET_MODEM_VERSION, reqstr, resstr) == RESULT_FAILURE)
	{
		MSG_ERROR("[NAS]request_get_modem_version() Fail to process!! ",0,0,0);
		return RESULT_FAILURE;
	}

	printf("[NAS]request_get_modem_version() %s\n", resstr);
	strcpy(modem_version, resstr);
	return RESULT_SUCCESS;
}


/*===========================================================================

  FUNCTION request_get_is_roaming
  
===========================================================================*/

boolean request_get_is_roaming(uint8* data)
{

// if SIM is not Active 
//	then, return RESULT_FAILURE;
// Compare current PLMN == SIM HPLMN
	*data = 3; //return true
	return RESULT_SUCCESS;
}
	

//chad_20160602 end <<<


//20170215 yjoh add for cell info
/*===========================================================================

  FUNCTION request_get_cell_info
  
===========================================================================*/

boolean request_get_cell_info(TOF_cellinfo *cell_info)
{
  int rc = QMI_NO_ERR, index=0;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_get_cell_location_info_resp_msg_v01 info_rsp;
  nas_555C_rsp_s nas_555c_rsp;
  int c1_index = -1;
  TOF_GSM_PathLossCriteria_list criteria_list;//path loss criteria struct array
  TOF_GSM_PathLossCriteria criteria;
 char temp[4]={0,}; //QMI max IMSI 33


  memset(&info_rsp, 0, sizeof(info_rsp));

  MSG_HIGH("[NAS] request_get_cell_info()", 0, 0, 0);
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_cell_info((int)nas_client_handle, &info_rsp, &qmi_err_code);

  rc = qmi_nas_get_debug_screen_info((int)nas_client_handle, &nas_555c_rsp, &qmi_err_code);

//temporary value for Java API, need to check Neighbor cell information
//GSM
	cell_info->gsm_info_valid=info_rsp.geran_info_valid;
	cell_info->gsm_cellinfo.arfcn=info_rsp.geran_info.arfcn;
	cell_info->gsm_cellinfo.bsic=info_rsp.geran_info.bsic;
	cell_info->gsm_cellinfo.cell_id=info_rsp.geran_info.cell_id;
	cell_info->gsm_cellinfo.lac=info_rsp.geran_info.lac;
	//memcpy(cell_info->gsm_cellinfo.plmn, info_rsp.geran_info.plmn, 3);
	cell_info->gsm_cellinfo.rx_lev=info_rsp.geran_info.rx_lev;
    cell_info->gsm_cellinfo.rx_lev_dBm=(int16_t)info_rsp.geran_info.rx_lev -111;
	cell_info->gsm_cellinfo.timing_advance=info_rsp.geran_info.timing_advance;

	cell_info->gsm_cellinfo.bsic_ncc = nas_555c_rsp.t01.ncc;//(info_rsp.geran_info.bsic >> 3);
   cell_info->gsm_cellinfo.bsic_bcc  = nas_555c_rsp.t01.bcc;//(info_rsp.geran_info.bsic & 0x07);
	 
	//cell_info->gsm_cellinfo.nmr_cell_info_len=info_rsp.geran_info.nmr_cell_info_len;

	for (index=0; index<4;index++)
	{
				cell_info->gsm_cellinfo.nmr_cell_info[index].nmr_cell_id=info_rsp.geran_info.nmr_cell_info[index].nmr_cell_id;
				cell_info->gsm_cellinfo.nmr_cell_info[index].nmr_lac=info_rsp.geran_info.nmr_cell_info[index].nmr_lac;
				cell_info->gsm_cellinfo.nmr_cell_info[index].nmr_bsic=info_rsp.geran_info.nmr_cell_info[index].nmr_bsic;
              cell_info->gsm_cellinfo.nmr_cell_info[index].nmr_rx_lev=info_rsp.geran_info.nmr_cell_info[index].nmr_rx_lev;
              cell_info->gsm_cellinfo.nmr_cell_info_rx_lev_dBm[index]=(int16_t)info_rsp.geran_info.nmr_cell_info[index].nmr_rx_lev-111;
			  //cell_info->gsm_cellinfo.nmr_cell_info[index].pathlosscriteria
			  
	}

//WCDMA
 	cell_info->wcdma_info_valid=info_rsp.umts_info_valid;
 	cell_info->wcdma_cellinfo.cell_id=info_rsp.umts_info.cell_id;
	cell_info->wcdma_cellinfo.ecio=info_rsp.umts_info.ecio;
	cell_info->wcdma_cellinfo.lac=info_rsp.umts_info.lac;
	//memcpy(cell_info->wcdma_cellinfo.plmn, info_rsp.umts_info.plmn, 3 );
	cell_info->wcdma_cellinfo.psc=info_rsp.umts_info.psc;
	cell_info->wcdma_cellinfo.rscp=info_rsp.umts_info.rscp;
	cell_info->wcdma_cellinfo.uarfcn=info_rsp.umts_info.uarfcn;
	cell_info->wcdma_cellinfo.rac=nas_555c_rsp.t01.rac;
	//cell_info->wcdma_cellinfo.umts_monitored_cell_len=info_rsp.umts_info.umts_monitored_cell_len;

	for (index=0; index<4;index++)
		
{
				//cell_info->wcdma_cellinfo.umts_monitored_cell[index].umts_uarfcn=info_rsp.umts_info.umts_monitored_cell[index].umts_uarfcn;
				cell_info->wcdma_cellinfo.umts_monitored_cell[index].umts_psc=nas_555c_rsp.t01.nset_psc[index];
				cell_info->wcdma_cellinfo.umts_monitored_cell[index].umts_rscp=nas_555c_rsp.t01.nset_rscp[index];
				cell_info->wcdma_cellinfo.umts_monitored_cell[index].umts_ecio=nas_555c_rsp.t01.nset_ecio[index];
	}
	
//LTE
	cell_info->lte_info_valid=info_rsp.lte_intra_valid;
	//cell_info->lte_cellinfo.cells_len=info_rsp.lte_intra.cells_len;
	cell_info->lte_cellinfo.cell_resel_priority=info_rsp.lte_intra.cell_resel_priority;
	cell_info->lte_cellinfo.earfcn=info_rsp.lte_intra.earfcn;
	cell_info->lte_cellinfo.global_cell_id=info_rsp.lte_intra.global_cell_id;
	//memcpy(cell_info->lte_cellinfo.plmn, info_rsp.lte_intra.plmn,3 );
	cell_info->lte_cellinfo.serving_cell_id=info_rsp.lte_intra.serving_cell_id;
	cell_info->lte_cellinfo.s_intra_search=info_rsp.lte_intra.s_intra_search;
	cell_info->lte_cellinfo.s_non_intra_search=info_rsp.lte_intra.s_non_intra_search;
	cell_info->lte_cellinfo.tac=info_rsp.lte_intra.tac;
	cell_info->lte_cellinfo.thresh_serving_low=info_rsp.lte_intra.thresh_serving_low;
	cell_info->lte_cellinfo.rsrp=nas_555c_rsp.t01.rsrp;
	cell_info->lte_cellinfo.rsrq=nas_555c_rsp.t01.rsrq;

for (index=0; index<4;index++)
	
{
			cell_info->lte_cellinfo.cells[index].pci=nas_555c_rsp.t01.lte_inter_info.freq_info[0].cell_info[index].pci;
			cell_info->lte_cellinfo.cells[index].rsrp=nas_555c_rsp.t01.lte_inter_info.freq_info[0].cell_info[index].rsrp;
			cell_info->lte_cellinfo.cells[index].rsrq=nas_555c_rsp.t01.lte_inter_info.freq_info[0].cell_info[index].rsrq;
}	
//temporary value for Java API, need to check Neighbor cell information

  memcpy(temp, nas_555c_rsp.t01.p_tmsi, sizeof(nas_555c_rsp.t01.p_tmsi));


  //[JIRA:AS057-737]	2017.02.20 - jaeyong1.park -PathLossCriteria getPathLossCriteria() for tof java api [start]
  MSG_ERROR("[NAS] try to get path loss criteria ", 0, 0, 0);  
  memset(&criteria_list, 0, sizeof(TOF_GSM_PathLossCriteria_list));
  request_get_gsm_pathhloss_criteria(&criteria_list);

  c1_index = _internal_TOF_GSM_PathLossCriteria_list_search(&criteria_list,	(cell_info->gsm_cellinfo.arfcn));
  // gsm serving cell
  if (c1_index != -1)
  {
	  memcpy( 
	  	&(cell_info->gsm_cellinfo.pathlosscriteria) ,
	  	&(criteria_list.info[c1_index]), 
	  	sizeof(TOF_GSM_PathLossCriteria)
	  	);
	  MSG_ERROR("[NAS] criteria scell info is founded. arfcn %d", (cell_info->gsm_cellinfo.arfcn), 0, 0);  
  }
	  cell_info->p_tmsi = lgit_atol(temp);

  // gsm nei cells
  for (index=0; index<4;index++)
  {
    c1_index = _internal_TOF_GSM_PathLossCriteria_list_search(&criteria_list,  info_rsp.geran_info.nmr_cell_info[index].nmr_arfcn);
	if (c1_index != -1)
	  {
	    memcpy( 
			&(cell_info->gsm_cellinfo.nmr_cell_info[index].pathlosscriteria) , 
			&(criteria_list.info[c1_index]), 
			sizeof(TOF_GSM_PathLossCriteria)
			);
	    MSG_ERROR("[NAS] criteria ncell info is founded. arfcn %d", info_rsp.geran_info.nmr_cell_info[index].nmr_arfcn, 0, 0);  		

	  }//if			  
  }//for
  //[JIRA:AS057-737]  2017.02.20 - jaeyong1.park -PathLossCriteria getPathLossCriteria() for tof java api [end]

  cell_info->network_mode=nas_555c_rsp.t01.network_mode;
  cell_info->mnc=nas_555c_rsp.t01.mnc;
  cell_info->mcc=nas_555c_rsp.t01.mcc;
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS] request_get_cell_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {

    return RESULT_SUCCESS;
  }
}



/*===========================================================================
  FUNCTION (_internal_TOF_GSM_PathLossCriteria_list_search)  only for request_get_cell_info  
===========================================================================*/
int _internal_TOF_GSM_PathLossCriteria_list_search(TOF_GSM_PathLossCriteria_list *list, int arfcn)
{
	int i;
	for(i=0; i<g_c1_MAX ; i++)
	{
		if ( list->info[i].arfcn_num == arfcn)
			{
				return i;
			}
	}
	
	MSG_ERROR("[NAS] _internal_TOF_GSM_PathLossCriteria_list_search() in table not found arfcn = %d", arfcn, 0, 0);
	return -1; //Search FAIL
}


/*===========================================================================

  FUNCTION (request_get_network_scan
  
===========================================================================*/

boolean request_get_network_scan()
{

	char reqstr[10]={0,};
	char resstr[180]={0,};
	if(ril_request_get_network_scan() == RESULT_FAILURE)
	{
		MSG_ERROR("[NAS]request_get_network_scan() Fail to process!! ",0,0,0);
		return RESULT_FAILURE;
	}

	printf("[NAS]request_get_network_scan() success\n");
	return RESULT_SUCCESS;
}


/*===========================================================================

  FUNCTION  request_get_gsm_dtm_supported
  
===========================================================================*/

boolean request_get_gsm_dtm_supported(uint32* dtmsupported)	
{
	char reqstr[10]={0,};
	char resstr[180]={0,};

	if(ril_request_get_modem_value(GET_GSM_NETWORK_DTM, reqstr, resstr) == RESULT_FAILURE)
	  {
		MSG_ERROR("[NAS]request_get_gsm_dtm_supported() Fail to process!! ",0,0,0);
	
		return RESULT_FAILURE;
	  }
	
	//convert to return type
	*dtmsupported = atoi(resstr);

	printf("[NAS]request_get_gsm_dtm_supported() success %d \n", *dtmsupported);
	return RESULT_SUCCESS;


}




/*===========================================================================

  FUNCTION  request_get_gsm_pathhloss_criteria
  
===========================================================================*/

boolean request_get_gsm_pathhloss_criteria(TOF_GSM_PathLossCriteria_list* criteria)
{
	char reqstr[10]={0,};
	char resstr[180]={0,};

	if(ril_request_get_modem_value(GET_GSM_PATH_LOSS_CRITERIA_C1, reqstr, resstr) == RESULT_FAILURE)
	  {
		MSG_ERROR("[NAS]request_get_gsm_pathhloss_criteria() Fail to process!! ",0,0,0);	
		return RESULT_FAILURE;
	  }
	MSG_HIGH("[QMI_NAS] request_get_gsm_pathhloss_criteria() %s", resstr, 0, 0);
	_internal_parse_pathlosscriteria_itemadd(resstr, criteria, 0, 3);	

	
	if(ril_request_get_modem_value(GET_GSM_PATH_LOSS_CRITERIA_C1_2, reqstr, resstr) == RESULT_FAILURE)
	  {
		MSG_ERROR("[NAS]request_get_gsm_pathhloss_criteria() Fail to process!! ",0,0,0);	
		return RESULT_FAILURE;
	  }
	MSG_HIGH("[QMI_NAS] request_get_gsm_pathhloss_criteria() %s", resstr, 0, 0);
	_internal_parse_pathlosscriteria_itemadd(resstr, criteria, 3, 3);


	if(ril_request_get_modem_value(GET_GSM_PATH_LOSS_CRITERIA_C1_3, reqstr, resstr) == RESULT_FAILURE)
	  {
		MSG_ERROR("[NAS]request_get_gsm_pathhloss_criteria() Fail to process!! ",0,0,0);	
		return RESULT_FAILURE;
	  }
	MSG_HIGH("[QMI_NAS] request_get_gsm_pathhloss_criteria() %s", resstr, 0, 0);
	_internal_parse_pathlosscriteria_itemadd(resstr, criteria, 6, 3);

	return RESULT_SUCCESS;
}

void _internal_parse_pathlosscriteria_itemadd(char* resstr, TOF_GSM_PathLossCriteria_list* criteria, int startindex, int numofitems)
{
	//parse string -> int array
	int i;
	char *ptr;
	int cnt=0;
	int tmpint[200]={0,};
	ptr = strtok(resstr, "|");
	while(ptr != NULL ){
		  tmpint[cnt] = atoi(ptr);
		  cnt++;		  	
          ptr = strtok(NULL, "|");
    }

	for (i=0; i< numofitems; i++)
	{
		criteria->info[i+startindex].calculated_c1 = tmpint[(13*i)+0];
		criteria->info[i+startindex].arfcn_num = tmpint[(13*i)+1];
		criteria->info[i+startindex].arfcn_bandtype = tmpint[(13*i)+2];
		criteria->info[i+startindex].received_level_average =tmpint[(13*i)+3];
		criteria->info[i+startindex].RXLEV_ACCESS_MIN_DBM = tmpint[(13*i)+4];
		criteria->info[i+startindex].MS_TXPWR_MAX_CCH_DBM=tmpint[(13*i)+5];

		criteria->info[i+startindex].POWER_OFFSET=tmpint[(13*i)+6];
		criteria->info[i+startindex].maximum_rf_power_output=tmpint[(13*i)+7];
		criteria->info[i+startindex].calculated_c2 =tmpint[(13*i)+8];
		criteria->info[i+startindex].CELL_RESELECT_PARAM_IND =tmpint[(13*i)+9];
		criteria->info[i+startindex].PENALTY_TIME =tmpint[(13*i)+10];

		criteria->info[i+startindex].CELL_RESELECT_OFFSET_DB =tmpint[(13*i)+11];
		criteria->info[i+startindex].TEMPORARY_OFFSET_DB =tmpint[(13*i)+12];

		printf("[%d] arfcn %d, c1 %d test data :%d, %d\n", i+startindex, criteria->info[i].calculated_c1, criteria->info[i].calculated_c1
			,criteria->info[i+startindex].CELL_RESELECT_OFFSET_DB
			,criteria->info[i+startindex].TEMPORARY_OFFSET_DB
			);
		MSG_HIGH("[%d] arfcn %d, c1 %d\n", i+startindex, criteria->info[i].calculated_c1, criteria->info[i].calculated_c1);
	}


}

	

/*===========================================================================

  FUNCTION  ril_request_get_network_time_info
  
===========================================================================*/
#ifdef FEATURE_LGIT_TIME
#else
uint8 ril_request_get_network_time_info(wmm_nitz_time_info_type *nitz_time_info)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5558_rsp_s nas_5558_rsp;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
  {
    return RESULT_FAILURE;
  }

  memset(&nas_5558_rsp, 0x0, sizeof(nas_5558_rsp_s));

  rc = qmi_nas_get_network_time_info((int)nas_client_handle, &nas_5558_rsp, &qmi_err_code);
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {	  
    MSG_ERROR("[NAS]ril_request_get_network_time_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    //MSG_HIGH("(NAS) ril_request_get_network_time_info   (0x5558)",			0, 0, 0);

    // Universal Time
    if (nas_5558_rsp.t01_valid)
    {
      nitz_time_info->year = nas_5558_rsp.t01.year-2000;
      nitz_time_info->month = nas_5558_rsp.t01.month;
      nitz_time_info->day = nas_5558_rsp.t01.day;
      nitz_time_info->hour = nas_5558_rsp.t01.hour;
      nitz_time_info->minute = nas_5558_rsp.t01.minute;
      nitz_time_info->second = nas_5558_rsp.t01.second;
      
      MSG_HIGH("   date = %02d%02d%02d", nitz_time_info->year, nitz_time_info->month, nitz_time_info->day);
      MSG_HIGH("   time = %02d%02d%02d", nitz_time_info->hour, nitz_time_info->minute, nitz_time_info->second);
    }

    // Time Zone
    if (nas_5558_rsp.t10_valid)
    {
      nitz_time_info->time_zone = nas_5558_rsp.t10.time_zone;
      MSG_HIGH("   time_zone = %d", nitz_time_info->time_zone, 0, 0);
    }

    // Daylight Saving Adjustment
    if (nas_5558_rsp.t11_valid)
    {
      nitz_time_info->daylt_sav_adj = nas_5558_rsp.t11.daylt_sav_adj;
      //MSG_HIGH("   daylt_sav_adj = %d", nitz_time_info->daylt_sav_adj, 0, 0);
    }

    // Radio Interface
    if (nas_5558_rsp.t12_valid)
    {
      nitz_time_info->radio_if = nas_5558_rsp.t12.radio_if;
      //MSG_HIGH("   radio_if = %d", nitz_time_info->radio_if, 0, 0);
    }

    return RESULT_SUCCESS;
  }
}
#endif

/*===========================================================================

  FUNCTION  get_current_plmn_name_cache
  
===========================================================================*/
uint8 get_current_plmn_name_cache()
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5559_rsp_s nas_5559_rsp;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
  {
    return RESULT_FAILURE;
  }

  memset(&nas_5559_rsp, 0x0, sizeof(nas_5559_rsp_s));

  rc = qmi_nas_get_current_plmn_name_cache((int)nas_client_handle, &nas_5559_rsp, &qmi_err_code);
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {	  
    MSG_ERROR("[NAS]qmi_nas_get_current_plmn_name_cache!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    if (nas_5559_rsp.t12_valid)
    {
      strcpy(operator_status.plmn_name_short, (char*)nas_5559_rsp.t12.plmn_name_short);
      //MSG_HIGH("   plmn_name_short_encoding = %d plmn_name_short_ci = %d plmn_name_short_spare_bits = %d", nas_5559_rsp->t12.plmn_name_short_encoding, nas_5559_rsp->t12.plmn_name_short_ci, nas_5559_rsp->t12.plmn_name_short_spare_bits);
      //MSG_HIGH("   plmn_name_short_len = %d plmn_name_short = %s", nas_5559_rsp->t12.plmn_name_short_len, nas_5559_rsp->t12.plmn_name_short, 0);
    }  

    if (nas_5559_rsp.t13_valid)
    {
      strcpy(operator_status.plmn_name_long, (char*)nas_5559_rsp.t13.plmn_name_long);
      //MSG_HIGH("   plmn_name_long_encoding = %d plmn_name_long_ci = %d plmn_name_long_spare_bits = %d", nas_5559_rsp->t13.plmn_name_long_encoding, nas_5559_rsp->t13.plmn_name_long_ci, nas_5559_rsp->t13.plmn_name_long_spare_bits);
      //MSG_HIGH("   plmn_name_long_len = %d plmn_name_long = %s", nas_5559_rsp->t13.plmn_name_long_len, nas_5559_rsp->t13.plmn_name_long, 0);
    }

    if (!nas_5559_rsp.t12_valid && !nas_5559_rsp.t13_valid)
    {
      if(operator_status.mcc<100) //MNC wll be 2 digits
        sprintf(operator_status.plmn_name_short, "%03d %02d", operator_status.mcc, operator_status.mnc);
      else //MNC will be 3 digits
        sprintf(operator_status.plmn_name_short, "%03d %03d", operator_status.mcc, operator_status.mnc);
    } 

    operator_status.initialized_plmn_name = TRUE;

    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  ril_request_get_debug_screen_info
  
===========================================================================*/
uint8 ril_request_get_debug_screen_info(qmi_nas_debug_info_type *lte_debug_info)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_555C_rsp_s nas_555C_rsp;
  int i=0;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
  {
    return RESULT_FAILURE;
  }

  memset(&nas_555C_rsp, 0x0, sizeof(nas_555C_rsp_s));

  rc = qmi_nas_get_debug_screen_info((int)nas_client_handle, &nas_555C_rsp, &qmi_err_code);
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {	  
    MSG_ERROR("[NAS]ril_request_get_debug_screen_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    if (nas_555C_rsp.t01_valid)
    {
      lte_debug_info->earfcn_dl = (int) nas_555C_rsp.t01.earfcn_dl;
      lte_debug_info->earfcn_ul = (int) nas_555C_rsp.t01.earfcn_ul;
      lte_debug_info->band_class = (int) nas_555C_rsp.t01.band_class;
      lte_debug_info->band_class = (int) nas_555C_rsp.t01.band_class;

      switch(nas_555C_rsp.t01.band_width)
      {
         case LTE_BW_IDX_NRB_6    : lte_debug_info->band_width = 1.4;    break;
         case LTE_BW_IDX_NRB_15   : lte_debug_info->band_width = 3;      break;
         case LTE_BW_IDX_NRB_25   : lte_debug_info->band_width = 5;      break;
         case LTE_BW_IDX_NRB_50   : lte_debug_info->band_width = 10;     break;
         case LTE_BW_IDX_NRB_75   : lte_debug_info->band_width = 15;     break;
         case LTE_BW_IDX_NRB_100  : lte_debug_info->band_width = 20;     break;
         default :                  lte_debug_info->band_width = 99;     break;
      }

      lte_debug_info->mnc = (int) nas_555C_rsp.t01.mnc;
      lte_debug_info->mcc = (int) nas_555C_rsp.t01.mcc;
      lte_debug_info->tac = (int) nas_555C_rsp.t01.tac;
      lte_debug_info->cell_id = (int) nas_555C_rsp.t01.cell_id;
      lte_debug_info->pci = (int) nas_555C_rsp.t01.pci;
      lte_debug_info->drx = (int) nas_555C_rsp.t01.drx;
      lte_debug_info->l2w = (int) nas_555C_rsp.t01.l2w;
      lte_debug_info->ri = (int) nas_555C_rsp.t01.ri;

      if(nas_555C_rsp.t01.cqi == 255)
      {
        lte_debug_info->cqi = 0;
      }     
      else
      {
        lte_debug_info->cqi = (int) nas_555C_rsp.t01.cqi;
      }

      lte_debug_info->sinr = (int) nas_555C_rsp.t01.sinr;

      if(nas_555C_rsp.t01.tx_pwr == -32768)
      {
        lte_debug_info->tx_pwr = 0;
      }
      else
      {
        lte_debug_info->tx_pwr = (int) nas_555C_rsp.t01.tx_pwr;
      }
      
      lte_debug_info->avg_rsrp = avg_rsrp.avg;
      //lte_debug_info->avg_antbar = (int) nas_555C_rsp.t01.avg_antbar; antbar�� set���� ǥ�� ��

      lte_debug_info->rsrq = (int) nas_555C_rsp.t01.rsrq;
      lte_debug_info->rsrp = (int) nas_555C_rsp.t01.rsrp;
      lte_debug_info->rssi = (int) nas_555C_rsp.t01.rssi* -1;

      lte_debug_info->srv_status = (int) nas_555C_rsp.t01.srv_status;
      lte_debug_info->emm_status = (int) nas_555C_rsp.t01.emm_status;
      lte_debug_info->sub_status = (int) nas_555C_rsp.t01.sub_status;
      lte_debug_info->rrc_state = (int) nas_555C_rsp.t01.rrc_state;
      lte_debug_info->svc = (int) nas_555C_rsp.t01.svc;

      memcpy(&lte_debug_info->tmsi, &nas_555C_rsp.t01.tmsi, sizeof(nas_555C_rsp.t01.tmsi));
      memcpy(&lte_debug_info->pdn_addr, &nas_555C_rsp.t01.pdn_addr, sizeof(nas_555C_rsp.t01.pdn_addr));

      // WCDMA �׸� �߰�
      lte_debug_info->uarfcn_dl = (int) nas_555C_rsp.t01.uarfcn_dl;
      lte_debug_info->uarfcn_ul = (int) nas_555C_rsp.t01.uarfcn_ul;
      lte_debug_info->network_type = (int) nas_555C_rsp.t01.network_type;
      lte_debug_info->network_mode = (int) nas_555C_rsp.t01.network_mode;
      lte_debug_info->lac = (int) nas_555C_rsp.t01.lac;
      lte_debug_info->rac = (int) nas_555C_rsp.t01.rac;
      lte_debug_info->mm_cause = (int) nas_555C_rsp.t01.mm_cause;
      lte_debug_info->mm_state = (int) nas_555C_rsp.t01.mm_state;
      lte_debug_info->mm_substate = (int) nas_555C_rsp.t01.mm_substate;
      lte_debug_info->gmm_cause = (int) nas_555C_rsp.t01.gmm_cause;
      lte_debug_info->gmm_state = (int) nas_555C_rsp.t01.gmm_state;
      lte_debug_info->gmm_substate = (int) nas_555C_rsp.t01.gmm_substate;
      lte_debug_info->gmm_update_status = (int) nas_555C_rsp.t01.gmm_update_status;
      lte_debug_info->sm_cause = (int) nas_555C_rsp.t01.sm_cause;
      lte_debug_info->w_rrc_state = (int) nas_555C_rsp.t01.w_rrc_state;
      lte_debug_info->pmm_mode = (int) nas_555C_rsp.t01.pmm_mode;
      lte_debug_info->pdp_state = (int) nas_555C_rsp.t01.pdp_state;
      lte_debug_info->sim_state = (int) nas_555C_rsp.t01.sim_state;
      lte_debug_info->cm_call_state = (int) nas_555C_rsp.t01.cm_call_state;
      lte_debug_info->mnc_includes_pcs_digit = (int) nas_555C_rsp.t01.mnc_includes_pcs_digit;
      lte_debug_info->oprt_mode = (int) nas_555C_rsp.t01.oprt_mode;
      lte_debug_info->location_update_status = (int) nas_555C_rsp.t01.location_update_status;
      lte_debug_info->w2l = (int) nas_555C_rsp.t01.w2l;
      lte_debug_info->bler = (int) nas_555C_rsp.t01.bler;
      lte_debug_info->iference = (int) nas_555C_rsp.t01.iference;
      lte_debug_info->rx_pwr = (int) nas_555C_rsp.t01.rx_pwr;
      lte_debug_info->tx_adj = (int) nas_555C_rsp.t01.tx_adj;

      for(i=0; i<4; i++)
      {
        lte_debug_info->nset_psc[i] = (int) nas_555C_rsp.t01.nset_psc[i];
        lte_debug_info->nset_rscp[i] = (int) nas_555C_rsp.t01.nset_rscp[i];
        lte_debug_info->nset_ecio[i] = (int) nas_555C_rsp.t01.nset_ecio[i];
      }
      
      memcpy(&lte_debug_info->p_tmsi, &nas_555C_rsp.t01.p_tmsi, sizeof(nas_555C_rsp.t01.p_tmsi));
      memcpy(&lte_debug_info->pdp_addr, &nas_555C_rsp.t01.pdp_addr, sizeof(nas_555C_rsp.t01.pdp_addr));

      memcpy(&lte_debug_info->imsi, &nas_555C_rsp.t01.imsi, sizeof(lte_debug_info->imsi));
      memcpy(&lte_debug_info->msisdn, &nas_555C_rsp.t01.msisdn, sizeof(lte_debug_info->msisdn));
    }

    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  get_lte_debug_screen_info
  
===========================================================================*/
#define IPV6_ADDRESS "0:0:0:0:0:0:0:0" 
uint8 get_lte_debug_screen_info(char *response[20], int *index_count)
{

  int i=0, itemp=0, iband=0;
  uint8 ret = RESULT_SUCCESS, call_ret = RESULT_SUCCESS;
  qmi_nas_debug_info_type lte_debug_info;
  char ip_address[32] = {0, };  
  char ipv6_address[64] = {0, }; 
//	pdp_ril_status_type pdp_ril_status_info;

  memset(&lte_debug_info, 0x0, sizeof(qmi_nas_debug_info_type));
  //memset(&pdp_ril_status_info, 0, sizeof(pdp_ril_status_type));

  //call_ret = qmi_wds_get_curr_call_info_request(&pdp_ril_status_info);
  ret = ril_request_get_debug_screen_info(&lte_debug_info);
  if(ret == RESULT_SUCCESS)
  {
    // 120 - SYS_BAND_LTE_EUTRAN_BAND1, 162 - SYS_BAND_LTE_EUTRAN_BAND43
    if((lte_debug_info.band_class >= SYS_BAND_LTE_EUTRAN_BAND1) && (lte_debug_info.band_class <= SYS_BAND_LTE_EUTRAN_BAND43))
    {
      iband = lte_debug_info.band_class - SYS_BAND_LTE_EUTRAN_BAND1 + 1;
    }

    asprintf(&response[i++], "EARFCN(DL/UL): %d/%d", lte_debug_info.earfcn_dl, lte_debug_info.earfcn_ul);
    asprintf(&response[i++], "BAND: %d BW: %0.1f MHz", iband, lte_debug_info.band_width);
    asprintf(&response[i++], "PLMN: %d %d TAC: %d", lte_debug_info.mcc, lte_debug_info.mnc, lte_debug_info.tac);
    asprintf(&response[i++], "eNB ID(PCI): %d(%d)", lte_debug_info.cell_id>>8, lte_debug_info.pci);
    asprintf(&response[i++], "ESM CAUSE: %d DRX: %dms", lte_debug_info.esm_cause, lte_debug_info.drx);
    asprintf(&response[i++], "RSRP: %d RSRQ: %d RSSI: %d", lte_debug_info.rsrp, lte_debug_info.rsrq, lte_debug_info.rssi);
    asprintf(&response[i++], "L2W: %d RI: %d CQI: %d", lte_debug_info.l2w, lte_debug_info.ri, lte_debug_info.cqi);
    asprintf(&response[i++], "STATUS: %s/%s", service_status_str(lte_debug_info.srv_status), emm_state_type_str(lte_debug_info.emm_status));

    // get emm_sub_state
    if(lte_debug_info.emm_status == EMM_DEREGISTERED)
    {
      asprintf(&response[i++], "SUB STATUS: %s", emm_deregistered_substate_type_str(lte_debug_info.sub_status));
    }
    else if(lte_debug_info.emm_status == EMM_REGISTERED_INITIATED)
    {
      asprintf(&response[i++], "SUB STATUS: %s", emm_registered_initiated_substate_type_str(lte_debug_info.sub_status));
    }
    else if(lte_debug_info.emm_status == EMM_REGISTERED)
    {
      asprintf(&response[i++], "SUB STATUS: %s", emm_registered_substate_type_str(lte_debug_info.sub_status));
    }
    else
    {
      asprintf(&response[i++], "SUB STATUS: UNKONWN");
    }

    asprintf(&response[i++], "RRC: %s", emm_connection_state_type_str(lte_debug_info.rrc_state));
    asprintf(&response[i++], "SVC: %s SINR: %d", sys_srv_domain_e_type_str(lte_debug_info.svc), lte_debug_info.sinr);
    asprintf(&response[i++], "Tx Pwr: %d", lte_debug_info.tx_pwr);

    itemp =  (unsigned int)(lte_debug_info.tmsi[0] << 24) & 0xff000000;
    itemp += (unsigned int)(lte_debug_info.tmsi[1] << 16) & 0x00ff0000;
    itemp += (unsigned int)(lte_debug_info.tmsi[2] << 8) & 0x0000ff00;
    itemp += (unsigned int)(lte_debug_info.tmsi[3]) & 0x000000ff;
    asprintf(&response[i++], "TMSI: %u", itemp);

#if 0
    
    if(call_ret == RESULT_SUCCESS)
    {
       nipaddr2str_addr64( pdp_ril_status_info.ipv6_addr.in6_u.u6_addr64 ,ipv6_address);
      	if(!(strcmp(ipv6_address,IPV6_ADDRESS)==0) )
    	{
            asprintf(&response[i++], "IP: %s", ipv6_address);
    	}
        else 
        {
            nipaddr2str(pdp_ril_status_info.ip_addr, ip_address);
            asprintf(&response[i++], "IP: %s", ip_address);
        }
    }
    else
    {
        asprintf(&response[i++], "IP: %d.%d.%d.%d", lte_debug_info.pdn_addr[0], lte_debug_info.pdn_addr[1], lte_debug_info.pdn_addr[2], lte_debug_info.pdn_addr[3]);
     }
#endif

    asprintf(&response[i++], "AVG RSRP: %d", avg_rsrp.avg);
    *index_count = i;

    return RESULT_SUCCESS;
  }
  else
  {
    return RESULT_FAILURE;
  }
}

/*===========================================================================

  FUNCTION  get_wcdma_debug_screen_info
  
===========================================================================*/
uint8 get_wcdma_debug_screen_info(RIL_WCDMA_DEBUG_INFO *wcdma_debug_info)
{
  uint8 ret = RESULT_SUCCESS;
  qmi_nas_debug_info_type lte_debug_info;
  uint8 imsi[33], number[33];

  memset(&lte_debug_info, 0x0, sizeof(qmi_nas_debug_info_type));

  ret = ril_request_get_debug_screen_info(&lte_debug_info);
  if(ret == RESULT_SUCCESS)
  {
    // RF
    if((lte_debug_info.band_class >= SYS_BAND_WCDMA_I_IMT_2000) && (lte_debug_info.band_class <= SYS_BAND_WCDMA_XIX_850))
    {
      wcdma_debug_info->band = lte_debug_info.band_class - SYS_BAND_WCDMA_I_IMT_2000 + 1;
    }

    //wcdma_debug_info->band = lte_debug_info.band_class;
    wcdma_debug_info->chan = lte_debug_info.uarfcn_dl;
    wcdma_debug_info->rssi = lte_debug_info.rssi;
    wcdma_debug_info->psc1 = lte_debug_info.nset_psc[0];
    wcdma_debug_info->ecio1 = lte_debug_info.nset_ecio[0];
    wcdma_debug_info->rscp1 = lte_debug_info.nset_rscp[0];
    wcdma_debug_info->psc2 = lte_debug_info.nset_psc[1];
    wcdma_debug_info->ecio2 = lte_debug_info.nset_ecio[1];
    wcdma_debug_info->rscp2 = lte_debug_info.nset_rscp[1];
    wcdma_debug_info->psc3 = lte_debug_info.nset_psc[2];
    wcdma_debug_info->ecio3 = lte_debug_info.nset_ecio[2];
    wcdma_debug_info->rscp3 = lte_debug_info.nset_rscp[2];
    wcdma_debug_info->psc4 = lte_debug_info.nset_psc[3];
    wcdma_debug_info->ecio4 = lte_debug_info.nset_ecio[3];
    wcdma_debug_info->rscp4 = lte_debug_info.nset_rscp[3];
    wcdma_debug_info->cqi = lte_debug_info.cqi;
    wcdma_debug_info->rx = lte_debug_info.rssi;   // IBOX ������� �����ϰ� ����
    wcdma_debug_info->tx_pwr = lte_debug_info.tx_pwr;
    wcdma_debug_info->tx_adj = lte_debug_info.tx_adj;
    wcdma_debug_info->bler = lte_debug_info.bler;
    wcdma_debug_info->drx = lte_debug_info.drx;
    wcdma_debug_info->cell_id = (unsigned int)lte_debug_info.cell_id;

    // NETWORK
    wcdma_debug_info->mcc = lte_debug_info.mcc;
    wcdma_debug_info->mnc = lte_debug_info.mnc;
    wcdma_debug_info->mnc_includes_pcs_digit = (unsigned char) lte_debug_info.mnc_includes_pcs_digit;
    wcdma_debug_info-> net_type = (unsigned char) lte_debug_info.network_type;
    wcdma_debug_info->network_op_mode = (unsigned char)lte_debug_info.network_mode;
    wcdma_debug_info->lac = lte_debug_info.lac;
    wcdma_debug_info->rac = (unsigned char)lte_debug_info.rac;
    wcdma_debug_info->ms_op_mode = (unsigned char)lte_debug_info.svc;

    // CM/SYSTEM
    wcdma_debug_info->cm_call_state = (unsigned char)lte_debug_info.cm_call_state;
    wcdma_debug_info->srv_status = (unsigned char)lte_debug_info.srv_status;
    wcdma_debug_info->last_mm_cause = (unsigned char)lte_debug_info.mm_cause;
    wcdma_debug_info->last_gmm_cause = (unsigned char)lte_debug_info.gmm_cause;    
    wcdma_debug_info->cm_oprt_mode = (unsigned char)lte_debug_info.oprt_mode;

    // MM/GMM Status
    wcdma_debug_info->mm_state = (unsigned char)lte_debug_info.mm_state;
    wcdma_debug_info->mm_idle_substate = (unsigned char)lte_debug_info.mm_substate;
    wcdma_debug_info->location_update_status = (unsigned char)lte_debug_info.location_update_status;
    wcdma_debug_info->gmm_state = (unsigned char)lte_debug_info.gmm_state;
    wcdma_debug_info->gmm_substate = (unsigned char)lte_debug_info.gmm_substate;
    wcdma_debug_info->sm_cause = (unsigned char)lte_debug_info.sm_cause;
    wcdma_debug_info->gmm_update_status = (unsigned char)lte_debug_info.gmm_update_status;
    wcdma_debug_info->pmm_mode = (unsigned char)lte_debug_info.pmm_mode;
    wcdma_debug_info->pdp_state = (unsigned char)lte_debug_info.pdp_state;

    // RRC
    wcdma_debug_info->rrc_state = (unsigned char)lte_debug_info.w_rrc_state;

    // USIM
    wcdma_debug_info->sim_state = (unsigned char)lte_debug_info.sim_state;

    if(ril_request_get_imsi((char *) imsi) == RESULT_SUCCESS)
      memcpy(wcdma_debug_info->imsi_p, imsi, sizeof(wcdma_debug_info->imsi_p));

    wcdma_debug_info->tmsi =  (unsigned int)(lte_debug_info.tmsi[0] << 24) & 0xff000000;
    wcdma_debug_info->tmsi += (unsigned int)(lte_debug_info.tmsi[1] << 16) & 0x00ff0000;
    wcdma_debug_info->tmsi += (unsigned int)(lte_debug_info.tmsi[2] << 8) & 0x0000ff00;
    wcdma_debug_info->tmsi += (unsigned int)(lte_debug_info.tmsi[3]) & 0x000000ff;

    wcdma_debug_info->ptmsi =  ((int)lte_debug_info.p_tmsi[0] << 24) & 0xff000000;
    wcdma_debug_info->ptmsi += ((int)lte_debug_info.p_tmsi[1] << 16) & 0x00ff0000;
    wcdma_debug_info->ptmsi += ((int)lte_debug_info.p_tmsi[2] << 8) & 0x0000ff00;
    wcdma_debug_info->ptmsi += ((int)lte_debug_info.p_tmsi[3]) & 0x000000ff;

    if(ril_request_get_phone_number((char *) number) == RESULT_SUCCESS)
      memcpy(wcdma_debug_info->msisdn, number, sizeof(wcdma_debug_info->msisdn));

    return RESULT_SUCCESS;
  }
  else
  {
    return RESULT_FAILURE;
  }
}

//BKS_20131107 - start
/*===========================================================================

  FUNCTION  get_cdma_debug_screen_info
  
===========================================================================*/
uint8 get_cdma_debug_screen_info(RIL_CDMA_DEBUG_INFO *cdma_debug_info)
{
  nas_5562_rsp_s nas_5562_rsp;
  uint8 ret = RESULT_SUCCESS;
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  int i = 0;

  if(nas_client_handle == INVALID_HANDLE_VALUE)
  {
    return RESULT_FAILURE;
  }

  memset(&nas_5562_rsp, 0x0, sizeof(nas_5562_rsp_s));

  rc = qmi_nas_request_hk_get_cdma_debug_info((int)nas_client_handle, &nas_5562_rsp, &qmi_err_code);
    if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {	  
    MSG_ERROR("[NAS]ril_request_get_cdma_debug_screen_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    ret = RESULT_FAILURE;
  }
  else
  {
    if (nas_5562_rsp.t10_valid)
    {
     cdma_debug_info->reg_zone = nas_5562_rsp.t10.reg_zone;
     cdma_debug_info->packet_zone = nas_5562_rsp.t10.packet_zone;
     cdma_debug_info->bs_p_rev = nas_5562_rsp.t10.bs_p_rev;;
     cdma_debug_info->p_rev_in_use = nas_5562_rsp.t10.p_rev_in_use;
     cdma_debug_info->is_registered = nas_5562_rsp.t10.is_registered;
     cdma_debug_info->ccs_supported = nas_5562_rsp.t10.ccs_supported;
     cdma_debug_info->uz_id = nas_5562_rsp.t10.uz_id;
     cdma_debug_info->srch_win_n = nas_5562_rsp.t10.srch_win_n;

     if(nas_cached_info.cdma_srv_status_info->srv_status == NAS_SYS_SRV_STATUS_NO_SRV_V01 ||
	  	     nas_cached_info.cdma_srv_status_info->srv_status == NAS_SYS_SRV_STATUS_PWR_SAVE_V01)
     {
       cdma_debug_info->base_lat = 0;
       cdma_debug_info->base_long= 0;
       cdma_debug_info->service_option= 0;

     }
     else
     {
       cdma_debug_info->base_lat = nas_5562_rsp.t10.base_lat;
       cdma_debug_info->base_long= nas_5562_rsp.t10.base_long;
       cdma_debug_info->service_option= nas_5562_rsp.t10.service_option;
     } 
     cdma_debug_info->base_id= nas_5562_rsp.t10.base_id;
     cdma_debug_info->reject_srv_domain= nas_5562_rsp.t10.reject_srv_domain;
     cdma_debug_info->reject_cause= nas_5562_rsp.t10.reject_cause;
     cdma_debug_info->active_status= nas_5562_rsp.t10.active_status;
     cdma_debug_info->slot_cycle_index= nas_5562_rsp.t10.slot_cycle_index;
     cdma_debug_info->cdma_lock_mode = nas_5562_rsp.t10.cdma_lock_mode;
     cdma_debug_info->curr_nam  = nas_5562_rsp.t10.curr_nam;
     cdma_debug_info->ps_data_suspend  = nas_5562_rsp.t10.ps_data_suspend;
     cdma_debug_info->packet_state  = nas_5562_rsp.t10.packet_state;
    }

    if (nas_5562_rsp.t11_valid)
    {
    
//     cdma_debug_info->service_status = nas_5562_rsp.t11.service_status ;
      if(nas_cached_info.cdma_srv_status_info->srv_status == NAS_SYS_SRV_STATUS_NO_SRV_V01 ||
	  	     nas_cached_info.cdma_srv_status_info->srv_status == NAS_SYS_SRV_STATUS_PWR_SAVE_V01)
      {
      
        cdma_debug_info->service_status = 0;
        cdma_debug_info->sid  = 0;
        cdma_debug_info->nid  = 0;

        cdma_debug_info->active_band = 0;
        cdma_debug_info->active_channel = 0;

        cdma_debug_info->rssi  = 0;
        cdma_debug_info->ecio  = 0;

        cdma_debug_info->tx_adj  = 0;
        cdma_debug_info->frame_err_rate= 0;
      }
	else
	{
        cdma_debug_info->service_status = nas_cached_info.cdma_srv_status_info->srv_status;
        cdma_debug_info->sid  = nas_5562_rsp.t11.sid;
        cdma_debug_info->nid  = nas_5562_rsp.t11.nid;

        cdma_debug_info->active_band = nas_5562_rsp.t11.active_band;
        cdma_debug_info->active_channel = nas_5562_rsp.t11.active_channel;

        cdma_debug_info->rssi  = (int)nas_5562_rsp.t11.rssi * -1;
        cdma_debug_info->ecio  = nas_5562_rsp.t11.ecio;

        cdma_debug_info->tx_adj  = nas_5562_rsp.t11.tx_adj;
        cdma_debug_info->frame_err_rate= nas_5562_rsp.t11.frame_err_rate;
  	}
     cdma_debug_info->roam_status  = nas_5562_rsp.t11.roam_status;
     cdma_debug_info->mcc  = nas_5562_rsp.t11.mcc ;
     cdma_debug_info->imsi_11_12  = nas_5562_rsp.t11.imsi_11_12 ;
     cdma_debug_info->tx_pwr  = nas_5562_rsp.t11.tx_pwr;

     for(i = 0; i < 	3 ; i++)
     {
       cdma_debug_info->psc[i].ecio = nas_5562_rsp.t11.psc[i].ecio;
       cdma_debug_info->psc[i].psc = nas_5562_rsp.t11.psc[i].psc;
     	}

    }

    if (nas_5562_rsp.t12_valid) 
    {

//     cdma_debug_info->hdr_service_status  = nas_5562_rsp.t12.hdr_service_status;
      if(nas_cached_info.hdr_srv_status_info->srv_status == NAS_SYS_SRV_STATUS_NO_SRV_V01 ||
	  	     nas_cached_info.hdr_srv_status_info->srv_status == NAS_SYS_SRV_STATUS_PWR_SAVE_V01)
     {
        cdma_debug_info->hdr_service_status = 0;
        cdma_debug_info->hybrid_active_band  = 0;
        cdma_debug_info->hybrid_active_channel  = 0;

        cdma_debug_info->hdr_rssi  = 0;
        cdma_debug_info->hdr_ecio  = 0;

        cdma_debug_info->hdr_packet_err_rate  = 0;
        cdma_debug_info->serving_pn  = 0;

        cdma_debug_info->color_code  = 0;
        cdma_debug_info->dl_rate  = 0;
        cdma_debug_info->ul_rate  = 0;
     	}
	else 
      {
        cdma_debug_info->hdr_service_status = nas_cached_info.hdr_srv_status_info->srv_status;
        cdma_debug_info->hybrid_active_band  = nas_5562_rsp.t12.hybrid_active_band;
        cdma_debug_info->hybrid_active_channel  = nas_5562_rsp.t12.hybrid_active_channel;

        cdma_debug_info->hdr_rssi  = (int)nas_5562_rsp.t12.hdr_rssi * -1;
        cdma_debug_info->hdr_ecio  = nas_5562_rsp.t12.hdr_ecio;

        cdma_debug_info->hdr_packet_err_rate  = nas_5562_rsp.t12.hdr_packet_err_rate;
        cdma_debug_info->serving_pn  = nas_5562_rsp.t12.serving_pn;

        cdma_debug_info->color_code  = nas_5562_rsp.t12.color_code;
        cdma_debug_info->dl_rate  = nas_5562_rsp.t12.dl_rate;
        cdma_debug_info->ul_rate  = nas_5562_rsp.t12.ul_rate;
	 }

      cdma_debug_info->hdr_roam_status  = nas_5562_rsp.t12.hdr_roam_status;
      cdma_debug_info->hdr_sid  = nas_5562_rsp.t12.hdr_sid;
      cdma_debug_info->hdr_nid  = nas_5562_rsp.t12.hdr_nid;
      cdma_debug_info->hdr_mcc  = nas_5562_rsp.t12.hdr_mcc;
      cdma_debug_info->hdr_imsi_11_12  = nas_5562_rsp.t12.hdr_imsi_11_12;
      cdma_debug_info->hdr_sinr  = nas_5562_rsp.t12.hdr_sinr;
      cdma_debug_info->prot_state  = nas_5562_rsp.t12.prot_state;
      cdma_debug_info->hdr_session_state  = nas_5562_rsp.t12.hdr_session_state;
      cdma_debug_info->uati24  = nas_5562_rsp.t12.uati24;
      cdma_debug_info->uati_subnet_mask  = nas_5562_rsp.t12.uati_subnet_mask;
      cdma_debug_info->sector_color_code  = nas_5562_rsp.t12.sector_color_code;
      cdma_debug_info->attempts_count  = nas_5562_rsp.t12.attempts_count;
      cdma_debug_info->success_count  = nas_5562_rsp.t12.success_count;
      cdma_debug_info->failure_count  = nas_5562_rsp.t12.failure_count;
	  
      cdma_debug_info->fcp_enabled  = nas_5562_rsp.t12.fcp_enabled;

	   for(i = 0; i < 16; i++)
	   {
        cdma_debug_info->sector_id[i]  = nas_5562_rsp.t12.sector_id[i];
	   }
    }

    if (nas_5562_rsp.t13_valid)
    {
      cdma_debug_info->rf_mode  = nas_5562_rsp.t13.rf_mode;
      cdma_debug_info->ac_state  = nas_5562_rsp.t13.ac_state;
    }
    ret = RESULT_SUCCESS;
  }
  return ret; 
}
//BKS_20131107 - end

/*===========================================================================

  FUNCTION  ril_request_delete_stored_cell
  
===========================================================================*/
uint8 ril_request_delete_stored_cell(void)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
  {
    return RESULT_FAILURE;
  }

  rc = qmi_nas_delete_stored_cell((int)nas_client_handle, &qmi_err_code);
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {	  
    MSG_ERROR("[NAS]ril_request_delete_stored_cell!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  add_avg_rf_data
  
===========================================================================*/
uint8 add_avg_rf_data(qmi_nas_avg_rf_data_type *avg_rf_data, int value)
{
  int i=0, isum=0, icount=0, ivalue=0;;

  if(value == 0)
  {
    ivalue = -125;
  }

  memmove(&avg_rf_data->value[1], &avg_rf_data->value[0], sizeof(int)*(MAX_AVG_RF_DATA_INDEX-1));
  avg_rf_data->value[0] = value;

  for(i=0; i<MAX_AVG_RF_DATA_INDEX; i++)
  {
    if(avg_rf_data->value[i] != 0)
    {
      isum = isum + avg_rf_data->value[i];
      icount++;
    }
  }

  //Block division by zero case
  if(icount == 0)
    return RESULT_SUCCESS;

  avg_rf_data->avg = (int) isum / icount;

  return RESULT_SUCCESS;
}

/*===========================================================================

  FUNCTION  convert_frequency_to_ril_Index
  
===========================================================================*/
uint8 convert_frequency_to_ril_Index
(
  boolean freq_enable,
  uint32  freq, 
  uint32  forced_freq,
  uint8   *p_index, 
  uint32  *p_frequency
)
{
  int i=0;

  switch ( wmm_get_vendor_type() )
  {
    case WMM_VENDOR_I_LTE_SKT:
    {
      if(forced_freq == 0)
      {
        if(freq_enable == FALSE)
        {
          *p_index = SKT_PREQ_FULL;
          *p_frequency = freq;
        }
        else
        {
          *p_index = SKT_PREQ_PREF;
          *p_frequency = freq;
        }
      }
      else
      {
        for(i=0; i<QMI_NAS_SKT_FREQUENCY_MAX_INDEX; i++)
        {
          if(skt_wcdma_dl_freq[i] == forced_freq)
          {
            *p_index = i+1;
            *p_frequency = 0;
            break;
          }
        }

        if(i >= QMI_NAS_SKT_FREQUENCY_MAX_INDEX)
        {
          *p_index = SKT_PREQ_USER;
          *p_frequency = forced_freq;
        }        
      }
    }
    break;

    case WMM_VENDOR_I_LTE_KT:
    {
      if(forced_freq == 0)
      {
        if(freq_enable == FALSE)
        {
          *p_index = KT_PREQ_FULL;
          *p_frequency = freq;
        }
        else
        {
          *p_index = KT_PREQ_PREF;
          *p_frequency = freq;
        }
      }
      else
      {
        for(i=0; i<QMI_NAS_KT_FREQUENCY_MAX_INDEX; i++)
        {
          if(kt_wcdma_dl_freq[i] == forced_freq)
          {
            *p_index = i+1;
            *p_frequency = 0;
            break;
          }
        }

        if(i >= QMI_NAS_KT_FREQUENCY_MAX_INDEX)
        {
          *p_index = KT_PREQ_USER;
          *p_frequency = forced_freq;
        }        
      }
    }
    break;

    default:
    {
      return RESULT_FAILURE;
    }
    break;
  }

  return RESULT_SUCCESS;
}

/*===========================================================================

  FUNCTION  convert_ril_Index_to_frequency
  
===========================================================================*/
uint8 convert_ril_Index_to_frequency
(
  uint8 p_index, 
  uint32 p_frequency, 
  boolean *freq_enable, 
  uint32 *freq, 
  uint32 *forced_freq
)
{
  switch ( wmm_get_vendor_type() )
  {
    case WMM_VENDOR_I_LTE_SKT:
    {
      // check index no
      if(p_index >= SKT_PREQ_MAX)
      {
        return RESULT_FAILURE;
      }

      // full scan mode
      if(p_index == SKT_PREQ_FULL)
      {
        *freq_enable = FALSE;
        *freq = 0;
        *forced_freq = 0;
      }
      // preferred scan mode
      else if(p_index == SKT_PREQ_PREF)
      {
        *freq_enable = TRUE;
        *freq = p_frequency;
        *forced_freq = 0;
      }
      // user input mode
      else if(p_index == SKT_PREQ_USER)
      {
        *freq_enable = FALSE;
        *freq = 0;
        *forced_freq = p_frequency;
      }
      // forced scan mode
      else
      {
        *freq_enable = FALSE;
        *freq = 0;
        *forced_freq = skt_wcdma_dl_freq[p_index-1];
      }
    }
    break;

    case WMM_VENDOR_I_LTE_KT:
    {
      // check index no
      if(p_index >= KT_PREQ_MAX)
      {
        return RESULT_FAILURE;
      }

      // full scan mode
      if(p_index == KT_PREQ_FULL)
      {
        *freq_enable = FALSE;
        *freq = 0;
        *forced_freq = 0;
      }
      // preferred scan mode
      else if(p_index == KT_PREQ_PREF)
      {
        *freq_enable = TRUE;
        *freq = p_frequency;
        *forced_freq = 0;
      }
      // user input mode
      else if(p_index == KT_PREQ_USER)
      {
        *freq_enable = FALSE;
        *freq = 0;
        *forced_freq = p_frequency;
      }
      // forced scan mode
      else
      {
        *freq_enable = FALSE;
        *freq = 0;
        *forced_freq = kt_wcdma_dl_freq[p_index-1];
      }
    }
    break;

    // SKT or KT�� �ƴϸ� Error ó�� ��
    default:
    {
      return RESULT_FAILURE;
    }
    break;
  }

  return RESULT_SUCCESS;
}

#ifdef FEATURE_LGIT_TIME
#else
//--> RIL_UNSOL_NITZ_TIME_RECEIVED
/*===========================================================================

  FUNCTION  qmi_nas_network_time_ind_conv_qmi2ril
  
===========================================================================*/
void qmi_nas_network_time_ind_conv_qmi2ril(nas_004C_ind_s* ind_msg, char* ril_nitz_time_msg)
{
  int time_zone = 0, time_zone_west = FALSE, daylight = 0;

  if(ind_msg->t10_valid)
  {
    time_zone = ind_msg->t10.time_zone;
    if(0 > time_zone) //time_zone
    {
      time_zone *= -1;
      time_zone_west = TRUE;
    }
  }

  if(ind_msg->t11_valid) //daylt_sav_adj
  {
    daylight = ind_msg->t11.daylt_sav_adj;
  }

  // accroding to ril.h the NITZ time string is in the form "yy/mm/dd,hh:mm:ss(+/-)tz,dt"
  snprintf(ril_nitz_time_msg, NAS_NITZ_STR_BUF_MAX, "%02d/%02d/%02d,%02d:%02d:%02d%c%02d,%02d",
           (int) ind_msg->t01.year%100,
           (int) ind_msg->t01.month,
           (int) ind_msg->t01.day,
           (int) ind_msg->t01.hour,
           (int) ind_msg->t01.minute,
           (int) ind_msg->t01.second,
           time_zone_west ? '-' : '+',
           (int) time_zone,
           (int) daylight);
  
  MSG_HIGH("[NITZ] ril_nitz_time_msg: %s", ril_nitz_time_msg, 0, 0);
}/* qmi_nas_network_time_ind_conv_qmi2ril */
//<-- RIL_UNSOL_NITZ_TIME_RECEIVED
#endif

/*===========================================================================

  FUNCTION  ril_request_get_preferred_network_type
  
===========================================================================*/
uint8 ril_request_get_preferred_network_type(uint16 *mode_pref)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  int ret = RESULT_SUCCESS;

  nas_0034_rsp_s nas_0034_rsp;

  MSG_HIGH("[NAS] ril_request_get_preferred_network_type()", 0, 0, 0);
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_0034_rsp, 0x0, sizeof(nas_0034_rsp_s));
  rc = qmi_nas_get_pref_network((int)nas_client_handle, &nas_0034_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]ril_request_get_preferred_network_type!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    ret = RESULT_FAILURE;
  }
  else
  {
    MSG_HIGH("mode_pref [%d], gw_acq_order_pref [%d], lte_band_pref [%x]", nas_0034_rsp.t11.mode_pref, nas_0034_rsp.t19.gw_acq_order_pref, nas_0034_rsp.t15.lte_band_pref);

    *mode_pref = qmi_nas_map_mode_pref_qmi_to_ril(nas_0034_rsp.t11.mode_pref, nas_0034_rsp.t19.gw_acq_order_pref, nas_0034_rsp.t15.lte_band_pref);
    ret = RESULT_SUCCESS;
  }

  return ret;
}

/*===========================================================================

  FUNCTION  ril_request_set_preferred_network_type
  
===========================================================================*/
uint8 ril_request_set_preferred_network_type(uint16 mode_pref)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_0033_req_s nas_0033_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
  
  memset(&nas_0033_req, 0, sizeof(nas_0033_req_s));
  
  nas_0033_req.t11_valid = TRUE;
  nas_0033_req.t11.mode_pref = qmi_nas_map_mode_pref_ril_to_qmi(mode_pref);
  
  nas_0033_req.t15_valid = TRUE;
  switch(mode_pref)
  {
    case PREF_NET_TYPE_GSM_WCDMA:
      nas_0033_req.t19_valid = TRUE;
      nas_0033_req.t19.gw_acq_order_pref = 0x0002;//Acquisition order is  WCDMA followed by GSM
      break;
    case PREF_NET_TYPE_GSM_WCDMA_AUTO:
      nas_0033_req.t19_valid = TRUE;
      nas_0033_req.t19.gw_acq_order_pref = 0x0000; //Determine mode automatically from the PRL order.
      break;
    case PREF_NET_TYPE_LTE_850: //BAND5
      nas_0033_req.t15.lte_band_pref = 16;
      break;
    case PREF_NET_TYPE_LTE_1800: //BAND3
      nas_0033_req.t15.lte_band_pref = 4;
      break;
    case PREF_NET_TYPE_LTE_BAND4: //BAND4
      nas_0033_req.t15.lte_band_pref = 8;
      break;
    case PREF_NET_TYPE_LTE_BAND13: //BAND13
      nas_0033_req.t15.lte_band_pref = 4096;
      break;
    default:
      nas_0033_req.t15.lte_band_pref = 4104;
      break;
  }    
  
  rc = qmi_nas_request_set_preferred_network_type((int)nas_client_handle,
                                                  &nas_0033_req,
                                                  &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_request_set_preferred_network_type!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  
  return RESULT_SUCCESS;
}

//--> RIL_REQUEST_CDMA_SUBSCRIPTION
/*===========================================================================

  FUNCTION  qmi_nas_request_cdma_subscription
  
===========================================================================*/
uint8 qmi_nas_request_cdma_subscription(qmi_nas_cdma_subscription_type *ril_response_data)
{
  nas_get_3gpp2_subscription_info_req_msg_v01 qmi_request;
  nas_get_3gpp2_subscription_info_resp_msg_v01 qmi_response;

  nas_003E_req_s	 nas_003E_req;
  nas_003E_rsp_s   nas_003E_rsp;

  RIL_Errno prl_fetch_ril_req_res = RIL_E_GENERIC_FAILURE;
  RIL_Errno sub_info_fetch_ril_req_res = RIL_E_GENERIC_FAILURE;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  uint8 result = RESULT_FAILURE;
  uint16 prl_version;
  uint32 iter = 0;
  int sid_ptr = 0, nid_ptr = 0;

  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&qmi_request, 0, sizeof(qmi_request));
  memset(&qmi_response, 0, sizeof(qmi_response));

  memset(&nas_003E_req, 0, sizeof(nas_003E_req));
  memset(&nas_003E_rsp, 0, sizeof(nas_003E_rsp));

  if(ril_response_data)
  {
    memset( ril_response_data, 0, sizeof( *ril_response_data ) );
    ril_response_data->cdma_subscription[ NAS_CDMA_SUBSCRIPTION_INFO_MDN ] = ril_response_data->mob_dir_number;
    ril_response_data->cdma_subscription[ NAS_CDMA_SUBSCRIPTION_INFO_H_SID ] = ril_response_data->home_sid;
    ril_response_data->cdma_subscription[ NAS_CDMA_SUBSCRIPTION_INFO_H_NID ] = ril_response_data->home_nid;
    ril_response_data->cdma_subscription[ NAS_CDMA_SUBSCRIPTION_INFO_MIN ] = ril_response_data->min_s;
    ril_response_data->cdma_subscription[ NAS_CDMA_SUBSCRIPTION_INFO_PRL_VER ] = ril_response_data->prl_version;

    prl_fetch_ril_req_res = qmi_nas_dms_fetch_cur_prl_version( &prl_version, &qmi_err_code );

    if( RIL_E_SUCCESS == prl_fetch_ril_req_res )
    {
      snprintf( ril_response_data->prl_version, sizeof(ril_response_data->prl_version), "%d", (int)prl_version );
      MSG_HIGH("qmi PRL version %s", ril_response_data->prl_version, 0, 0 );
      result = RESULT_SUCCESS;
    }
    else
    {
      ril_response_data->cdma_subscription[ NAS_CDMA_SUBSCRIPTION_INFO_PRL_VER ] = NULL;
      MSG_HIGH("fetch current PRL version failed %d", prl_fetch_ril_req_res, 0, 0);
    }

    nas_003E_req.t01_valid = TRUE;
    nas_003E_req.t01.nam = 0xFF; // current NAM

    nas_003E_req.t10_valid = TRUE;
    nas_003E_req.t10.get_3gpp2_info_mask = QMI_NAS_GET_3GPP2_SUBS_INFO_MDN_V01
                                           | QMI_NAS_GET_3GPP2_SUBS_INFO_HOME_SID_IND_V01
                                           | QMI_NAS_GET_3GPP2_SUBS_INFO_MIN_BASED_IMSI_V01;

    sub_info_fetch_ril_req_res = qmi_nas_get_3gpp2_subscription_info((int) nas_client_handle, &nas_003E_req, &nas_003E_rsp, &qmi_err_code);

    MSG_HIGH("sub_info_fetch_ril_req_res %d", sub_info_fetch_ril_req_res, 0, 0);
    if( RIL_E_SUCCESS == sub_info_fetch_ril_req_res )
    {
      if( nas_003E_rsp.t16_valid ) //mdn
      {
        strlcpy(ril_response_data->mob_dir_number, nas_003E_rsp.t16.mdn, sizeof(nas_003E_rsp.t16.mdn_len));
      }

      if( nas_003E_rsp.t12_valid ) //cdma_sys_id
      {
        for( iter = 0 ; iter < nas_003E_rsp.t12.num_instances ; iter++ )
        {
          sid_ptr += snprintf( &ril_response_data->home_sid[sid_ptr], NAS_SID_NID_ELEMENT_MAX_SIZE+1, "%u,", (unsigned int)nas_003E_rsp.t12.sid_nid_list[iter].sid );
          nid_ptr += snprintf( &ril_response_data->home_nid[nid_ptr], NAS_SID_NID_ELEMENT_MAX_SIZE+1, "%u,", (unsigned int)nas_003E_rsp.t12.sid_nid_list[iter].nid );
        }

        if( sid_ptr > 0 )
        {
          ril_response_data->home_sid[sid_ptr-1] = '\0';
        }
        if( nid_ptr > 0 )
        {
          ril_response_data->home_nid[nid_ptr-1] = '\0';
        }
      }

      if( nas_003E_rsp.t13_valid) //min
      {
        strlcpy( ril_response_data->min_s, nas_003E_rsp.t13.imsi_m_s2, NAS_IMSI_MIN2_LEN_V01 + 1);
        strlcpy( &ril_response_data->min_s[NAS_IMSI_MIN2_LEN_V01], nas_003E_rsp.t13.imsi_m_s1, NAS_IMSI_MIN1_LEN_V01 + 1 );
      }

      MSG_HIGH("qmi MIN2 %s, MIN1 %s", nas_003E_rsp.t13.imsi_m_s2, nas_003E_rsp.t13.imsi_m_s1, 0);
      MSG_HIGH("qmi MDN %s MIN %s", ril_response_data->mob_dir_number, ril_response_data->min_s, 0);
      MSG_HIGH("qmi SID %s NID %s", ril_response_data->home_sid, ril_response_data->home_nid, 0);
    }
  }

  return result;
}
//<-- RIL_REQUEST_CDMA_SUBSCRIPTION

//BKS_20131129- start
/*===========================================================================

FUNCTION  convert_mcc_ota_to_hpcd

DESCRIPTION
  Converts MCC from OTA format to Handset based Plus Code Dialing ( HPCD).

DEPENDENCIES

RETURN VALUE
   MCC in PRL/HPCD format

SIDE EFFECTS

===========================================================================*/
uint16 convert_mcc_ota_to_hpcd(

    uint16  ota_mcc
      /* OTA MCC that needs to converted to HPCD */
)
{
  /* Convert MCC from OTA format to HPCD same as PRL format MCC.
  ** As defined in IS-2000 section 2.3.1.3
  **  1. Represent the 3-digit Mobile Country Code as D1 D2 D3
  **     with the digit equal to zero being given the value of ten.
  **  2. Compute 100 * D1 + 10 * D2 + D3 - 111.
  **  3. Convert the result in step (2) to binary by
  ** a standard decimal-to-binary conversion as described in Table 2.3.1.1-1.
  ** So the follwing code is to reverse this processing
  */

  uint16 prl_mcc;
  byte                 conv_arr[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 };

  //if (!BETWEEN(ota_mcc, 0, CM_MAX_MOBILE_COUNTRY_CODE_VAL))
  //{
  //  return CM_INVALID_MOBILE_COUNTRY_CODE;
  //}
  MSG_HIGH ("OTA MCC = %d  ", ota_mcc, 0, 0);

  prl_mcc =  conv_arr[ ota_mcc%10 ];
  ota_mcc /= 10;
  prl_mcc += conv_arr[ ota_mcc%10 ] * 10;
  ota_mcc /= 10;
  prl_mcc += conv_arr[ ota_mcc%10 ] * 100;
  
  MSG_HIGH ("PRL MCC=%d", prl_mcc, 0,0);

  return prl_mcc;
}

/*===========================================================================
  FUNCTION DECODE_3GPP2_IMSI_11_12()

  DESCRIPTION
    This message is used to encode 3GPP2 subscription related information; imsi_m/t_11_12. 
    
  PARAMETERS
    decoded_mcc
    encoded_mcc  

  RETURN VALUE
    void    
    
  DEPENDENCIES
    None

  SIDE EFFECTS
    None
===========================================================================*/
void qmi_nas_decode_3gpp2_imsi_11_12(uint8 *decoded_imsi_11_12, uint16 encoded_imsi_11_12)
{
  uint16 d1, d2, temp_encoded;
  temp_encoded = encoded_imsi_11_12;

  temp_encoded += 11;
  d2 = temp_encoded % 10;
  if( d2 == 0)
  {
    temp_encoded =(temp_encoded - 10)/10;
  }
  else
  {
    temp_encoded /= 10;
  }
 
  if( temp_encoded == 10)
  {
    d1 =0;
  }
  else
  {
    d1 = temp_encoded;
  }
  *decoded_imsi_11_12 = d1*10 + d2;
  MSG_HIGH ("OTA MNC = %d  PRL MNC=%d", encoded_imsi_11_12, *decoded_imsi_11_12, 0);

}
//BKS_20131129 - end

//--> EMERGENCY_CALLBACK_MODE
/*=========================================================================

  FUNCTION:  qmi_ril_nwr_get_eme_cbm

===========================================================================*/
qmi_ril_emergency_callback_mode_state_type qmi_ril_nwr_get_eme_cbm()
{
  qmi_ril_emergency_callback_mode_state_type res;

  //NAS_CACHE_LOCK();
  res = nas_cached_info.eme_cbm;
  //NAS_CACHE_UNLOCK();

  return res;
} /* qmi_ril_nwr_get_eme_cbm */

/*=========================================================================

  FUNCTION:  qmi_ril_nwr_set_eme_cbm

===========================================================================*/
void qmi_ril_nwr_set_eme_cbm(qmi_ril_emergency_callback_mode_state_type new_mode)
{
  qmi_ril_emergency_callback_mode_state_type cur;
  qmi_ril_emergency_callback_mode_state_type rule;
  int go_on;
  int evt;

  //NAS_CACHE_LOCK();
  cur = nas_cached_info.eme_cbm;
  //NAS_CACHE_UNLOCK();
  rule = cur;
  MSG_HIGH( "entered, mode requested %d(%s --> %s)", new_mode, emcb_e_type_str(cur), emcb_e_type_str(new_mode));  

  evt = QMI_RIL_ZERO;
  if ( new_mode != cur )
  {
    switch ( new_mode )
    {
      case QMI_RIL_EME_CBM_NOT_ACTIVE:
        rule    = QMI_RIL_EME_CBM_NOT_ACTIVE;
        go_on   = TRUE;
        if ( QMI_RIL_EME_CBM_ACTIVE == cur )
        {
          // TODO: evt   = RIL_UNSOL_EXIT_EMERGENCY_CALLBACK_MODE;
        }
        break;

      case QMI_RIL_EME_CBM_ACTIVE:
        rule    = QMI_RIL_EME_CBM_ACTIVE;
        go_on   = TRUE;
//        evt     = RIL_UNSOL_ENTER_EMERGENCY_CALLBACK_MODE;
        break;

      default:
        go_on = FALSE;
        break;
    }
  }
  else
  {
    go_on = FALSE;
  }

  MSG_HIGH( "RIL_UNSOL_ENTER_EMERGENCY_CALLBACK_MODE, noti %d, mode %s", (int) go_on, emcb_e_type_str(rule), 0 );
  if ( go_on )
  {
    //NAS_CACHE_LOCK();
    nas_cached_info.eme_cbm = rule;
    //NAS_CACHE_UNLOCK();
    if ( QMI_RIL_ZERO != evt )
    {
      //Send_UnsolicitedResponse (evt,  NULL, 0 );
    }
  }

  //MSG_HIGH( "completed, new mode %d", (int) rule, 0, 0 );
} /* qmi_ril_nwr_set_eme_cbm */
//<-- EMERGENCY_CALLBACK_MODE

//--> RIL_REQUEST_EXIT_EMERGENCY_CALLBACK_MODE
/*===========================================================================

  FUNCTION  ril_request_exit_emergency_callback_mode
  
===========================================================================*/
uint8 ril_request_exit_emergency_callback_mode()
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_set_system_selection_preference_req_msg_v01 qmi_request;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  MSG_HIGH("ril_request_exit_emergency_callback_mode()", 0, 0, 0);

  // ** prepare qmi req and exec
  memset( &qmi_request, 0, sizeof( qmi_request ) );
  
  qmi_request.emergency_mode_valid = TRUE;
  qmi_request.emergency_mode       = 0x00; //NAS_CMN_EMERGENCY_MODE_OFF;	

  rc = qmi_nas_exit_emergency_callback_mode((int)nas_client_handle,
                                             &qmi_request,
                                             &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS] ril_request_exit_emergency_callback_mode!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;
} /* ril_request_exit_emergency_callback_mode */
//<-- RIL_REQUEST_EXIT_EMERGENCY_CALLBACK_MODE

// --> RIL_REQUEST_EVDO_REV
/*===========================================================================

  FUNCTION  ril_request_get_evdo_rev
  
===========================================================================*/
uint8 ril_request_get_evdo_rev(uint8 *evdo_rev)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_7001_rsp_s nas_7001_rsp; 

  memset(&nas_7001_rsp, 0, sizeof(nas_7001_rsp_s));
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_evdo_rev((int)nas_client_handle, &nas_7001_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]ril_request_get_evdo_rev!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    nas_7001_rsp.t10_valid = TRUE;
    switch(nas_7001_rsp.t10.evdo_rev)
    {
      case HDR_REV0_PROTOCOLS_ONLY:
        *evdo_rev = 0;
        break;
      case HDR_REVA_PROTOCOLS_WITH_MFPA:
        *evdo_rev = 1;
        break;
      case HDR_REVA_PROTOCOLS_WITH_EHRPD:
        *evdo_rev = 2;
        break;
      default:
      nas_7001_rsp.t10_valid = FALSE;
      rc = QMI_INTERNAL_ERR;
      qmi_err_code = QMI_SERVICE_ERR_INTERNAL;
      MSG_ERROR("[NAS] ril_request_set_evdo_rev!!evdo_rev: %d,  rc: %d err_code : %d", evdo_rev, rc, qmi_err_code);
      return RESULT_FAILURE;
    }

    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  ril_request_set_evod_rev
  
===========================================================================*/
uint8 ril_request_set_evod_rev(uint8 evdo_rev)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_7002_req_s nas_7002_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_7002_req, 0, sizeof(nas_7002_req_s));

  nas_7002_req.t10_valid = TRUE;
  switch(evdo_rev)
  {
    case 0: // EVDO Rev.o
      nas_7002_req.t10.evdo_rev = HDR_REV0_PROTOCOLS_ONLY;    
      break;
    
    case 1: // EVDO Rev.A
      nas_7002_req.t10.evdo_rev = HDR_REVA_PROTOCOLS_WITH_MFPA;
      break;
      
    case 2: // eHRPD
      nas_7002_req.t10.evdo_rev = HDR_REVA_PROTOCOLS_WITH_EHRPD;    
      break;
    default:
      nas_7002_req.t10_valid = FALSE;
      rc = QMI_INTERNAL_ERR;
      qmi_err_code = QMI_SERVICE_ERR_INTERNAL;
      MSG_ERROR("[NAS] ril_request_set_evdo_rev!!evdo_rev: %d,  rc: %d err_code : %d", evdo_rev, rc, qmi_err_code);
      return RESULT_FAILURE;
  }
  
  rc = qmi_nas_set_evdo_rev((int)nas_client_handle,
                                                &nas_7002_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]ril_request_set_evdo_rev!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;
}
// <-- RIL_REQUEST_EVDO_REV

//--> RIL_REQUEST_APN_SETTING
uint8 ril_request_get_sdm_apn_info(int request_info ,uint8 profile_num, RIL_Apn_Info *apninfo)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  int i =0;

  nas_7006_req_s qmi_rsq;
  nas_7006_rsp_s qmi_rsp;

  memset(&qmi_rsq, 0, sizeof(nas_7006_req_s));
  memset(&qmi_rsp, 0, sizeof(nas_7006_rsp_s));

  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
  

  qmi_rsq.t10_valid = TRUE;
  qmi_rsq.t10.profile_num = profile_num;
  qmi_rsq.t10.info_mask = request_info;

  rc = qmi_nas_get_sdm_apn_info((int)nas_client_handle ,&qmi_rsq, &qmi_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]ril_request_get_ims_pdn!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {  
      switch(request_info)
      {
        case REQUEST_CLASS_ID:			
		    apninfo->class_id = qmi_rsp.t11.classid ;
		   // MSG_HIGH ("ril_request_get_sdm_apn_info: classid =%d\n",qmi_rsp.t11.classid , 0, 0);			
		    break;
	
        case REQUEST_APN_NAME:			
			  apninfo->apn_length = strlen(qmi_rsp.t12.apn_name); 
  			for(i=0; i<apninfo->apn_length; i++)
  			{
  			  apninfo->apn[i] = (unsigned char)qmi_rsp.t12.apn_name[i];
  			}
	  		apninfo->apn[apninfo->apn_length] = '\0';
		  //  MSG_HIGH ("ril_request_get_sdm_apn_info: name =%s  length=%d\n",qmi_rsp.t12.apn_name, apninfo->apn_length, 0);						
        break;
  
        case REQUEST_IP_TYPE:			
			  apninfo->iptype = qmi_rsp.t13.iptype;
		  //  MSG_HIGH ("ril_request_get_sdm_apn_info: iptype =%d\n",qmi_rsp.t13.iptype, 0, 0);						
        break;

        case REQUEST_APN_ENABLED:			
			  apninfo->apn_disabled_flag = qmi_rsp.t14.enabled;
		 //   MSG_HIGH ("ril_request_get_sdm_apn_info: enabled =%d\n",qmi_rsp.t14.enabled, 0, 0);						
        break;

        case REQUEST_INACTIVITY_TIMER:			
			  apninfo->inactivity_timer = qmi_rsp.t15.inactivityT;
		  //  MSG_HIGH ("ril_request_get_sdm_apn_info: inactivity Timer =%d\n",qmi_rsp.t15.inactivityT, 0, 0);						
        break;
		
        case REQUEST_BEARER_TYPE:			
			apninfo->bearer = qmi_rsp.t16.bearer;
		    //MSG_HIGH ("ril_request_get_sdm_apn_info: bearer =%d\n",qmi_rsp.t16.bearer, 0, 0);						
        break;

        case REQUEST_MAX_CONN:     
          apninfo->max_conn = qmi_rsp.t17.max_conn;
          //MSG_HIGH ("ril_request_get_sdm_apn_info: max_conn =%d\n",qmi_rsp.t17.max_conn, 0, 0);           
          break;

        case REQUEST_MAX_CONN_T:     
          apninfo->max_conn_t = qmi_rsp.t18.max_conn_t;
          //MSG_HIGH ("ril_request_get_sdm_apn_info: max_conn_t =%d\n",qmi_rsp.t18.max_conn_t, 0, 0);           
          break;

        case REQUEST_WAIT_TIME:     
          apninfo->wait_time = qmi_rsp.t19.wait_time;
          //MSG_HIGH ("ril_request_get_sdm_apn_info: wait_time =%d\n",qmi_rsp.t19.wait_time, 0, 0);           
          break;

        default:
          break;
       }

     return RESULT_SUCCESS;
  }
}

uint8 ril_request_get_sdm_apn_info_ack(int request_info ,uint8 profile_num, RIL_Apn_Info *apninfo)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  int i =0;

  nas_7006_req_s qmi_req;
  nas_7006_rsp_s qmi_rsp;

  memset(&qmi_req, 0, sizeof(nas_7006_req_s));
  memset(&qmi_rsp, 0, sizeof(nas_7006_rsp_s));

  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;
  

  qmi_req.t10_valid = TRUE;
  qmi_req.t10.profile_num = profile_num;
  qmi_req.t10.info_mask = request_info;
  qmi_req.t11_valid = TRUE;
  
  rc = qmi_nas_get_sdm_apn_info((int)nas_client_handle ,&qmi_req, &qmi_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]ril_request_get_ims_pdn!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {  
      switch(request_info)
      {
        case REQUEST_CLASS_ID:			
		    apninfo->class_id = qmi_rsp.t11.classid ;
		   // MSG_HIGH ("ril_request_get_sdm_apn_info: classid =%d\n",qmi_rsp.t11.classid , 0, 0);			
		    break;
	
        case REQUEST_APN_NAME:			
			  apninfo->apn_length = strlen(qmi_rsp.t12.apn_name); 
  			for(i=0; i<apninfo->apn_length; i++)
  			{
  			  apninfo->apn[i] = (unsigned char)qmi_rsp.t12.apn_name[i];
  			}
	  		apninfo->apn[apninfo->apn_length] = '\0';
		  //  MSG_HIGH ("ril_request_get_sdm_apn_info: name =%s  length=%d\n",qmi_rsp.t12.apn_name, apninfo->apn_length, 0);						
        break;
  
        case REQUEST_IP_TYPE:			
			  apninfo->iptype = qmi_rsp.t13.iptype;
		  //  MSG_HIGH ("ril_request_get_sdm_apn_info: iptype =%d\n",qmi_rsp.t13.iptype, 0, 0);						
        break;

        case REQUEST_APN_ENABLED:			
			  apninfo->apn_disabled_flag = qmi_rsp.t14.enabled;
		 //   MSG_HIGH ("ril_request_get_sdm_apn_info: enabled =%d\n",qmi_rsp.t14.enabled, 0, 0);						
        break;

        case REQUEST_INACTIVITY_TIMER:			
			  apninfo->inactivity_timer = qmi_rsp.t15.inactivityT;
		  //  MSG_HIGH ("ril_request_get_sdm_apn_info: inactivity Timer =%d\n",qmi_rsp.t15.inactivityT, 0, 0);						
        break;
		
        case REQUEST_BEARER_TYPE:			
			apninfo->bearer = qmi_rsp.t16.bearer;
		    //MSG_HIGH ("ril_request_get_sdm_apn_info: bearer =%d\n",qmi_rsp.t16.bearer, 0, 0);						
        break;

        case REQUEST_MAX_CONN:     
          apninfo->max_conn = qmi_rsp.t17.max_conn;
          //MSG_HIGH ("ril_request_get_sdm_apn_info: max_conn =%d\n",qmi_rsp.t17.max_conn, 0, 0);           
          break;

        case REQUEST_MAX_CONN_T:     
          apninfo->max_conn_t = qmi_rsp.t18.max_conn_t;
          //MSG_HIGH ("ril_request_get_sdm_apn_info: max_conn_t =%d\n",qmi_rsp.t18.max_conn_t, 0, 0);           
          break;

        case REQUEST_WAIT_TIME:     
          apninfo->wait_time = qmi_rsp.t19.wait_time;
          //MSG_HIGH ("ril_request_get_sdm_apn_info: wait_time =%d\n",qmi_rsp.t19.wait_time, 0, 0);           
          break;

        default:
          break;
       }

     return RESULT_SUCCESS;
  }
}

uint8 ril_request_set_sdm_apn_info(int request_info ,RIL_Apn_Info apninfo)
{
	int rc = QMI_NO_ERR,i=0;;
    int qmi_err_code = QMI_SERVICE_ERR_NONE;
	
	 nas_7005_req_s qmi_req;
	
	if(nas_client_handle == INVALID_HANDLE_VALUE)
	  return RESULT_FAILURE;
	
	memset(&qmi_req, 0, sizeof(nas_7005_req_s));
	
	switch(request_info)
	{
		
      case REQUEST_CLASS_ID:
		qmi_req.t11_valid  = TRUE;
		qmi_req.t11.class_id = apninfo.class_id;
		qmi_req.t11.profile_num = apninfo.profile_num;		  	
	  break; 

	  case REQUEST_APN_NAME:
		qmi_req.t12_valid  = TRUE;
		qmi_req.t12.profile_num = apninfo.profile_num;		
		for(i=0; i<apninfo.apn_length; i++)
		{
		 qmi_req.t12.apn_name[i] =(char)apninfo.apn[i];
		}		
	  break;

	  case REQUEST_IP_TYPE:
		qmi_req.t13_valid  = TRUE;
		qmi_req.t13.iptype = apninfo.iptype;
		qmi_req.t13.profile_num = apninfo.profile_num;	  
	  break;

	  case REQUEST_APN_ENABLED:
		qmi_req.t14_valid  = TRUE;
		qmi_req.t14.diabled_flag = apninfo.apn_disabled_flag;
		qmi_req.t14.profile_num = apninfo.profile_num;	  
	  break;
		
	  case REQUEST_INACTIVITY_TIMER:
		qmi_req.t15_valid  = TRUE;
		qmi_req.t15.inactivityT = apninfo.inactivity_timer;
		qmi_req.t15.profile_num = apninfo.profile_num;	
	  break;
	  
	  case REQUEST_BEARER_TYPE:
		qmi_req.t16_valid  = TRUE;
		qmi_req.t16.bearer = apninfo.bearer;
		qmi_req.t16.profile_num = apninfo.profile_num;	  
	  break;

	  case REQUEST_MAX_CONN:
		qmi_req.t17_valid  = TRUE;
		qmi_req.t17.max_conn = apninfo.max_conn;
		qmi_req.t17.profile_num = apninfo.profile_num;	  
	  break;
		
	  case REQUEST_MAX_CONN_T:
		qmi_req.t18_valid  = TRUE;
		qmi_req.t18.max_conn_t = apninfo.max_conn_t;
		qmi_req.t18.profile_num = apninfo.profile_num;	
        MSG_ERROR("[NAS] ril_request_set_sdm_apn_info!! qmi_req.t18.max_conn_t = %d, apninfo.max_conn_t=%d", qmi_req.t18.max_conn_t, apninfo.max_conn_t, 0);
	  break;
	  
	  case REQUEST_WAIT_TIME:
		qmi_req.t19_valid  = TRUE;
		qmi_req.t19.wait_time = apninfo.wait_time;
		qmi_req.t19.profile_num = apninfo.profile_num;	  
	  break;

	  default:
		MSG_ERROR("[NAS] ril_request_set_sdm_apn_info!! request = %d", request_info, 0, 0);
		return RESULT_FAILURE;
		break;
	}
	
	rc = qmi_nas_set_sdm_apn_info((int)nas_client_handle,
										&qmi_req,
										&qmi_err_code);
	if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
	{
	  MSG_ERROR("[NAS] qmi_nas_set_protocol_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
	  return RESULT_FAILURE;
	}
	
	return RESULT_SUCCESS;
}
//<-- RIL_REQUEST_APN_SETTING

//--> RIL_REQUEST_EHRPD_IPV6
/*===========================================================================

  FUNCTION  ril_request_get_ehrpd_ipv6_enabled
  
===========================================================================*/
uint8 ril_request_get_ehrpd_ipv6_enabled(uint8 *ehprd_ipv6)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_7007_rsp_s qmi_rsp;

  memset(&qmi_rsp, 0, sizeof(nas_7007_rsp_s));
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_ehrpd_ipv6_enabled((int)nas_client_handle, &qmi_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]ril_request_get_ehrpd_ipv6_enabled!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
     *ehprd_ipv6 = qmi_rsp.t10.ipv6_enabled ;
    return RESULT_SUCCESS;
  }

}

/*===========================================================================

  FUNCTION  ril_request_set_ehrpd_ipv6_enabled
  
===========================================================================*/
uint8 ril_request_set_ehrpd_ipv6_enabled(uint8 ehprd_ipv6)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_7008_req_s qmi_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&qmi_req, 0, sizeof(nas_7008_req_s));

  qmi_req.t10_valid = TRUE;
  qmi_req.t10.ipv6_enabled = ehprd_ipv6;  	

  //MSG_HIGH ("ril_request_set_ehrpd_ipv6_enabled:=%d\n",ehprd_ipv6 , 0, 0);			  

  rc = qmi_nas_set_ehrpd_ipv6_enabled((int)nas_client_handle,
                                                &qmi_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]ril_request_set_ehrpd_ipv6_enabled!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}
//--> RIL_REQUEST_EHRPD_IPV6

//--> RIL_REQUEST_T3402
uint8 ril_request_get_t3402(uint32 * timer)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_7011_rsp_s qmi_rsp;

  memset(&qmi_rsp, 0, sizeof(nas_7011_rsp_s));
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_t3402((int)nas_client_handle, &qmi_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]ril_request_get_t3402!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
     *timer = qmi_rsp.t10.timer ;
    return RESULT_SUCCESS;
  }

}

uint8 ril_request_set_t3402(uint32 timer)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_7012_req_s qmi_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&qmi_req, 0, sizeof(nas_7012_req_s));

  qmi_req.t10_valid = TRUE;
  qmi_req.t10.timer = timer;  	

  //MSG_HIGH ("ril_request_set_t3402:=%d\n",timer , 0, 0);			  

  rc = qmi_nas_set_t3402((int)nas_client_handle,
                                                &qmi_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]ril_request_set_t3402!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}
//<-- RIL_REQUEST_T3402

//--> RIL_REQUEST_HK_GET_IMS_AUTH
uint8 ril_request_get_ims_sip_extended_config(uint8 *ims_auth)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5567_rsp_s nas_5567_rsp;

  memset(&nas_5567_rsp, 0, sizeof(nas_5567_rsp_s));
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_ims_sip_extended_config((int)nas_client_handle, &nas_5567_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[IMS] qmi_nas_get_ims_user_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    *ims_auth = nas_5567_rsp.t10.AuthScheme;
    return RESULT_SUCCESS;
  }
}
//<-- RIL_REQUEST_HK_GET_IMS_AUTH

//--> RIL_REQUEST_HK_SET_IMS_AUTH
uint8 ril_request_set_ims_sip_extended_config(uint8 ims_auth)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5568_req_s nas_5568_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_5568_req, 0, sizeof(nas_5568_req_s));

  nas_5568_req.t10_valid = TRUE;
  nas_5568_req.t10.AuthScheme = ims_auth;

  rc = qmi_nas_set_ims_sip_extended_config((int)nas_client_handle,
                                                &nas_5568_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_set_ims_user_config!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}
//<-- RIL_REQUEST_HK_SET_IMS_AUTH


//BKS_20140307 start
//-->RIL_REQUEST_HK_SET_LTE_BAND_PREF
uint8 ril_request_set_lte_band_pref(int lte_band_pref)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_0033_req_s nas_0033_req;

  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_0033_req, 0, sizeof(nas_0033_req_s));

  if ((wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ) || ( wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ))
  {
    if(lte_band_pref == 0)
    {
      nas_0033_req.t15_valid = TRUE;
      nas_0033_req.t15.lte_band_pref = 0x000000000000008;   // Band 4
    }
    else if(lte_band_pref == 1)
    {
      nas_0033_req.t15_valid = TRUE;
      nas_0033_req.t15.lte_band_pref = 0x000000000001000;   // Band 13
    }
    else
    {
      nas_0033_req.t15_valid = TRUE;
      nas_0033_req.t15.lte_band_pref = 0x000000000001008;   // Band 4, Band 13
    }
  }
  else
  {
    if(lte_band_pref == 0)
    {
      nas_0033_req.t15_valid = TRUE;
      nas_0033_req.t15.lte_band_pref = 0x000000000000004;   // Band 3
    }
    else if(lte_band_pref == 1)
    {
      nas_0033_req.t15_valid = TRUE;
      nas_0033_req.t15.lte_band_pref = 0x000000000000010;   // Band 5
    }
    else
    {
      nas_0033_req.t15_valid = TRUE;
      nas_0033_req.t15.lte_band_pref = 0x000000000000014;   // Band 3, Band 5
    }
  }

  // Acquisition Order Preference
  nas_0033_req.t1E_valid = FALSE;
  nas_0033_req.t1E.acq_order_len = 2;
  nas_0033_req.t1E.acq_order[1] = 0x05;
  nas_0033_req.t1E.acq_order[0] = 0x08;
  
  rc = qmi_nas_set_network_sel_auto((int)nas_client_handle,
                                         &nas_0033_req,
                                         &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]ril_request_set_lte_band_pref!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;
}
//<--RIL_REQUEST_HK_SET_LTE_BAND_PREF

//--> RIL_REQUEST_HK_SET_CDMA_SYS_SEL_PREF
/*===========================================================================

  FUNCTION  ril_request_set_system_selection
  
===========================================================================*/
uint8 ril_request_set_system_selection(uint16 sys_sel)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;

  nas_7003_req_s nas_7003_req;

  if(nas_client_handle == INVALID_HANDLE_VALUE)
	  return RESULT_FAILURE;
	
  memset(&nas_7003_req, 0, sizeof(nas_7003_req));

  MSG_HIGH( "[ril_request_set_system_seletion]  entered!!! sys_sel = %d", (int) sys_sel, 0, 0 );

  nas_7003_req.t10_valid = TRUE;
  nas_7003_req.t10.sys_sel = sys_sel;

  rc = qmi_nas_set_system_selection((int)nas_client_handle,
                                               &nas_7003_req,
                                                &qmi_err_code);

  return RESULT_SUCCESS;
}
//<-- RIL_REQUEST_HK_SET_CDMA_SYS_SEL_PREF

//--> RIL_REQUEST_HK_GET_CDMA_SYS_SEL_PREF
/*===========================================================================

  FUNCTION  ril_request_query_system_selection
  
===========================================================================*/
uint8 ril_request_query_system_selection(int *sys_sel)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
   nas_7004_rsp_s nas_7004_rsp;

  memset(&nas_7004_rsp, 0, sizeof(nas_7004_rsp_s));

  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_system_selection((int)nas_client_handle, 
  	                                                &nas_7004_rsp, 
  	                                                 &qmi_err_code);
  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[ril_request_query_system_selection]Fail!!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
      MSG_HIGH( "[ril_request_query_system_selection]  sys_sel = %d", (int) nas_7004_rsp.t10.sys_sel, 0, 0 );
     *sys_sel = nas_7004_rsp.t10.sys_sel;

    return RESULT_SUCCESS;
  }
}
//<-- RIL_REQUEST_HK_GET_CDMA_SYS_SEL_PREF
//BKS_20140307 end

// --> RIL_REQUEST_VZW_IMS_SETTING
uint8 ril_request_get_vzw_ims_setting(uint8 * ims_setting)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_7009_rsp_s nas_7009_rsp; 

  memset(&nas_7009_rsp, 0, sizeof(nas_7009_rsp_s));
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_vzw_ims_setting((int)nas_client_handle, &nas_7009_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]ril_request_get_vzw_ims_setting!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    nas_7009_rsp.t10_valid = TRUE;
    switch(nas_7009_rsp.t10.ims_setting)
    {
      case VZW_IMS_SETTING:
        *ims_setting = 0;
        break;
      case ALU_IOT_SETTING:
        *ims_setting = 1;
        break;
      case MD8475A_SETTING:
        *ims_setting = 2;
        break;
      default:
      nas_7009_rsp.t10_valid = FALSE;
      rc = QMI_INTERNAL_ERR;
      qmi_err_code = QMI_SERVICE_ERR_INTERNAL;
      MSG_ERROR("[NAS] ril_request_get_vzw_ims_setting!!ims_setting: %d,  rc: %d err_code : %d", ims_setting, rc, qmi_err_code);
      return RESULT_FAILURE;
    }

    return RESULT_SUCCESS;
  }
}

uint8 ril_request_set_vzw_ims_setting(uint8 ims_setting)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_7010_req_s nas_7010_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_7010_req, 0, sizeof(nas_7010_req_s));

  nas_7010_req.t10_valid = TRUE;
  switch(ims_setting)
  {
    case 0: //VZW IMS
      nas_7010_req.t10.ims_setting = VZW_IMS_SETTING;  	
      break;
    
    case 1: // ALU IOT
      nas_7010_req.t10.ims_setting = ALU_IOT_SETTING;
      break;
      
    case 2: // MD8475A
      nas_7010_req.t10.ims_setting = MD8475A_SETTING;  	
      break;
    default:
      nas_7010_req.t10_valid = FALSE;
      rc = QMI_INTERNAL_ERR;
      qmi_err_code = QMI_SERVICE_ERR_INTERNAL;
      MSG_ERROR("[NAS] ril_request_set_vzw_ims_setting!!ims_setting: %d,  rc: %d err_code : %d", ims_setting, rc, qmi_err_code);
      return RESULT_FAILURE;
  }
  
  rc = qmi_nas_set_vzw_ims_setting((int)nas_client_handle,
                                                &nas_7010_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]ril_request_set_vzw_ims_setting!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;
}
// <-- RIL_REQUEST_VZW_IMS_SETTING

//--> RIL_REQUEST_HK_USIM_ONCHIP
/*===========================================================================

  FUNCTION  ril_request_clear_mru
  
===========================================================================*/
uint8 ril_request_clear_mru( void )
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  {
    rc = qmi_nas_clear_mru((int)nas_client_handle, &qmi_err_code);
    if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
    {
      MSG_ERROR("[NAS]qmi_nas_clear_mru!! rc: %d err_code : %d", rc, qmi_err_code, 0);
       return RESULT_FAILURE;
    }
    else
    {
#ifdef FEATURE_LGIT_DEFAULT_PRL_FACTORY_CMD    
      set_rtre_value(1); // for factory command
#endif
//	(void)request_set_oprt_mode(0x04); //DMS_OP_MODE_RESETTING_V01
    }
  }

  return RESULT_SUCCESS;
}
//<-- RIL_REQUEST_HK_USIM_ONCHIP

/*===========================================================================

  FUNCTION  qmi_check_cdma_roaming
  
===========================================================================*/
bool qmi_check_cdma_roaming(void)
{  
  if((wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ) || ( wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ))
  {
    if(((nas_cached_info.radio_tech == RIL_ACT_IS95A) ||
       (nas_cached_info.radio_tech == RIL_ACT_IS95B) ||
       (nas_cached_info.radio_tech == RIL_ACT_1XRTT))
       && (nas_cached_info.cdma_sys_info->common_sys_info.roam_status == NAS_SYS_ROAM_STATUS_ON_V01
      || nas_cached_info.cdma_sys_info->common_sys_info.roam_status == NAS_SYS_ROAM_STATUS_BLINK_V01))
    {
      return TRUE;
    }
  }
  return FALSE;
}

/*===========================================================================

  FUNCTION  ril_request_get_ims_test_mode
  
===========================================================================*/
uint8 ril_request_get_ims_test_mode(uint16 *ims_test_mode)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5563_rsp_s nas_5563_rsp;

  memset(&nas_5563_rsp, 0, sizeof(nas_5563_rsp_s));
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_ims_test_mode((int)nas_client_handle, &nas_5563_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]ril_request_get_ims_pdn!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    *ims_test_mode = nas_5563_rsp.t10.ims_test_mode ;

    return RESULT_SUCCESS;
  }
}

/*===========================================================================

  FUNCTION  ril_request_set_ims_test_mode
  
===========================================================================*/
uint8 ril_request_set_ims_test_mode(uint16 ims_test_mode)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_5564_req_s nas_5564_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_5564_req, 0, sizeof(nas_5564_req_s));

  nas_5564_req.t10_valid = TRUE;
  nas_5564_req.t10.ims_test_mode = ims_test_mode;  	

  rc = qmi_nas_set_ims_test_mode((int)nas_client_handle,
                                                &nas_5564_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_set_ims_pdn!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}

//hongsg 20140821
/*===========================================================================

  FUNCTION  ril_request_get_ims_user_agent
  
===========================================================================*/
uint8 ril_request_get_ims_user_agent(int request, RIL_Ims_User_Agent *ims_user_agent)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_557A_rsp_s nas_557A_rsp;

  memset(&nas_557A_rsp, 0, sizeof(nas_557A_rsp_s));
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_nas_get_ims_user_agent((int)nas_client_handle, &nas_557A_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[IMS] qmi_nas_get_ims_user_agent!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    switch(request)
    {
      case REQUEST_IMS_USER_AGENT:
        strcpy(ims_user_agent->UserAgent, nas_557A_rsp.t10.UserAgent);
      break;

      default:
      break;
    }

    return RESULT_SUCCESS;
  }

}

/*===========================================================================

  FUNCTION  ril_request_set_ims_user_agent
  
===========================================================================*/
uint8 ril_request_set_ims_user_agent(int request, RIL_Ims_User_Agent ims_user_agent)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  nas_557B_req_s nas_557B_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_557B_req, 0, sizeof(nas_557B_req_s));

  switch(request)
  {
    case REQUEST_IMS_USER_AGENT:
      nas_557B_req.t10_valid = TRUE;
      strcpy(nas_557B_req.t10.UserAgent, ims_user_agent.UserAgent);
    break;

    default:
    break;  
  }

  rc = qmi_nas_set_ims_user_agent((int)nas_client_handle,
                                                &nas_557B_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_set_ims_user_agent!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}

uint8 ril_request_set_sdm_dcmo_vzw_config_init(void)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  int i =0;

  nas_701D_req_s qmi_req;

  memset(&qmi_req, 0, sizeof(nas_701D_req_s));

  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  qmi_req.t21_valid = 1;
  qmi_req.t21.vzw_config_init = 1;
  
  rc = qmi_nas_set_sdm_dcmo_info((int)nas_client_handle , &qmi_req, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]ril_request_set_sdm_dcmo_vzw_config_init!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {  
     return RESULT_SUCCESS;
  }
}

uint8 ril_request_set_vzw_test_menu(char * cmd)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  struct nas_701F_req_s nas_701F_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_701F_req, 0, sizeof(nas_701F_req));

  nas_701F_req.t10_valid = TRUE;
  strcpy(nas_701F_req.t10.cmd, cmd);
  
  rc = qmi_nas_set_vzw_test_menu((int)nas_client_handle,
                                                &nas_701F_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_nas_set_vzw_test_menu!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}

#if defined(FEATURE_LGIT_OTADM_FOTA_FUMO_VZW)

/*===========================================================================

  FUNCTION  ril_request_set_fota_wap_push_test
  
===========================================================================*/
uint8 ril_request_set_fota_wap_push_test(uint16 wappushpkg)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  struct nas_7030_req_s nas_7030_req;
  
  if(nas_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&nas_7030_req, 0, sizeof(nas_7030_req));

  nas_7030_req.t10_valid = TRUE;
  nas_7030_req.t10.wap_push_num = wappushpkg;

 MSG_HIGH("[FOTA] ril_request_set_fota_wap_push_test : %d", wappushpkg, 0,0);
 LOGD("[FOTA] ril_request_set_fota_wap_push_test %d", wappushpkg);
				   
  rc = qmi_nas_set_fota_wap_push_test((int)nas_client_handle,
                                                &nas_7030_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]ril_request_set_evdo_rev!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;
}
#endif



#ifdef FEATURE_LGIT_TIME
void	init_nitz_time()
{
  memset( &(g_nitz_time_manager.qmi_nitz_time), 0x0, sizeof( qmi_nitz_time_s ) );
  set_nitz_time_manager_state( NITZ_TIME_MANAGER_STATE_WAIT_FOR_TRY_UPDATE );
  set_nitz_time_manager_state( NITZ_TIME_MANAGER_STATE_TRY_UPDATE );

  MSG_HIGH( "init_nitz_time()", 0, 0, 0 );
}



bool	get_qmi_nitz_time( qmi_nitz_time_s* qmi_nitz_time )
{
  int r = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
	
  if ( INVALID_HANDLE_VALUE == nas_client_handle )
  {
    MSG_ERROR( "get_qmi_nitz_time() invalid nas client handle", 0, 0, 0 );
    return FALSE;
  }
	
  r = qmi_nas_get_network_time_info( (int)nas_client_handle, (nas_5558_rsp_s*)qmi_nitz_time, &qmi_err_code );

	if ( r != QMI_NO_ERR )
	{
    MSG_ERROR( "get_qmi_nitz_time() qmi_nas_get_network_time_info() fail, r:%d", r, 0, 0 );
	  return FALSE;
	}

	if ( QMI_SERVICE_ERR_NONE != qmi_err_code )
	{
    MSG_ERROR( "get_qmi_nitz_time() qmi_nas_get_network_time_info() fail, qmi_err_code:%d", qmi_err_code, 0, 0 );
	  return FALSE;
	}

  if ( FALSE == check_qmi_nitz_time_valid( qmi_nitz_time ) )
	{
    MSG_ERROR( "get_qmi_nitz_time() check_qmi_nitz_time_valid() fail", 0, 0, 0 );
	  return FALSE;
	}

	MSG_HIGH( "get_qmi_nitz_time() success", 0, 0, 0 );

	return TRUE;
}



bool	update_nitz_time( qmi_nitz_time_s* qmi_nitz_time )
{
  if ( FALSE == check_qmi_nitz_time_valid( qmi_nitz_time ) )
	{
    MSG_ERROR( "update_nitz_time() check_qmi_nitz_time_valid() fail", 0, 0, 0 );
	  return FALSE;
	}
	
  memcpy( &(g_nitz_time_manager.qmi_nitz_time), qmi_nitz_time, sizeof( qmi_nitz_time_s ) );
  set_nitz_time_manager_state( NITZ_TIME_MANAGER_STATE_UPDATED );

	MSG_HIGH( "update_nitz_time() success", 0, 0, 0 );

	return TRUE;
}



void	uninit_nitz_time( void )
{
  memset( &(g_nitz_time_manager.qmi_nitz_time), 0x0, sizeof( qmi_nitz_time_s ) );
	set_nitz_time_manager_state( NITZ_TIME_MANAGER_STATE_WAIT_FOR_TRY_UPDATE );

	MSG_HIGH( "uninit_nitz_time()", 0, 0, 0 );
}



nitz_time_manager_state_e	get_nitz_time_manager_state()
{
  return g_nitz_time_manager.state;
}



void set_nitz_time_manager_state( nitz_time_manager_state_e state )
{
  if ( NITZ_TIME_MANAGER_STATE_TRY_UPDATE == state )
  {
	  if ( NITZ_TIME_MANAGER_STATE_UPDATED == get_nitz_time_manager_state() )
	  {
			MSG_HIGH( "set_nitz_time_manager_state() already updated. no need to update", 0, 0, 0 );

			return;
  	}
  }
	
  g_nitz_time_manager.state = state;
  
  MSG_HIGH( "set_nitz_time_manager_state() state:%d(%s)", g_nitz_time_manager.state, nitz_state_e_type_str(g_nitz_time_manager.state), 0 );
}



qmi_nitz_time_s* get_nitz_time_manager_qmi_nitz_time()
{
  return &g_nitz_time_manager.qmi_nitz_time;
}



bool	check_qmi_nitz_time_valid( qmi_nitz_time_s* qmi_nitz_time )
{
	log_qmi_nitz_time( qmi_nitz_time );

	if ( FALSE == qmi_nitz_time->t01_valid )
	{
    MSG_ERROR( "check_qmi_nitz_time_valid() t01_valid(date_time) is not valid", 0, 0, 0 );
	  return FALSE;
	}

	if ( qmi_nitz_time->year < 2015 )
	{
	  MSG_ERROR( "check_qmi_nitz_time_valid() system time is not valid", 0, 0, 0 );
	  LOGD( "check_qmi_nitz_time_valid() system time is not valid", 0, 0, 0 );
		return FALSE;
	}

	if ( FALSE == qmi_nitz_time->t10_valid )
	{
    MSG_ERROR( "check_qmi_nitz_time_valid() t10_valid(time_zone) is not valid", 0, 0, 0 );
	  return FALSE;
	}

	if ( FALSE == qmi_nitz_time->t11_valid )
	{
    MSG_ERROR( "check_qmi_nitz_time_valid() t11_valid(daylt_sav_adj) is not valid", 0, 0, 0 );
	  return FALSE;
	}

	if ( FALSE == qmi_nitz_time->t12_valid )
	{
    MSG_ERROR( "check_qmi_nitz_time_valid() t12_valid(radio_if) is not valid", 0, 0, 0 );
		//return FALSE;
	}

	return TRUE;
}



void	log_qmi_nitz_time( qmi_nitz_time_s* qmi_nitz_time )
{
	char temp_str[ 256 ];
	
	sprintf( temp_str, "log_qmi_nitz_time() %04d/%02d/%02d-%02d:%02d:%02d day_of_week:%d(%d), time_zone:%d(%d), daylt_sav_adj:%d(%d), radio_if:%d(%d)",
																qmi_nitz_time->year,
																qmi_nitz_time->month,
																qmi_nitz_time->day,
																qmi_nitz_time->hour,
																qmi_nitz_time->minute,
																qmi_nitz_time->second,
																qmi_nitz_time->day_of_week,
																qmi_nitz_time->t01_valid,
																qmi_nitz_time->time_zone,
																qmi_nitz_time->t10_valid,
																qmi_nitz_time->daylt_sav_adj,
																qmi_nitz_time->t11_valid,
																qmi_nitz_time->radio_if,
																qmi_nitz_time->t12_valid );

	MSG_HIGH( "%s", temp_str, 0, 0 );
}
#endif


