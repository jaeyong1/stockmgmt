#ifndef WMMDBG_H
#define WMMDBG_H

typedef enum {
    GSDI_SIM_INSERTED = 0,
    GSDI_SIM_REMOVED,
    GSDI_DRIVER_ERROR,
    GSDI_CARD_ERROR,
    GSDI_MEMORY_WARNING,
    GSDI_NO_SIM_EVENT,
    GSDI_NO_SIM,
    GSDI_SIM_INIT_COMPLETED,
    GSDI_SIM_INIT_COMPLETED_NO_PROV,
    GSDI_PIN1_VERIFIED,

    GSDI_PIN1_BLOCKED,
    GSDI_PIN1_UNBLOCKED,
    GSDI_PIN1_ENABLED,
    GSDI_PIN1_DISABLED,
    GSDI_PIN1_CHANGED,
    GSDI_PIN1_PERM_BLOCKED,
    GSDI_PIN2_VERIFIED,
    GSDI_PIN2_BLOCKED,
    GSDI_PIN2_UNBLOCKED,
    GSDI_PIN2_ENABLED,

    GSDI_PIN2_DISABLED,
    GSDI_PIN2_CHANGED,
    GSDI_PIN2_PERM_BLOCKED,
    GSDI_NO_EVENT,
    GSDI_OK_FOR_TERMINAL_PROFILE_DL,
    GSDI_NOT_OK_FOR_TERMINAL_PROFILE_DL,
    GSDI_REFRESH_SIM_RESET,
    GSDI_REFRESH_SIM_INIT,
    GSDI_FDN_ENABLE,
    GSDI_FDN_DISABLE,

    GSDI_SIM_INSERTED_2,
    GSDI_SIM_REMOVED_2,
    GSDI_CARD_ERROR_2,
    GSDI_MEMORY_WARNING_2,
    GSDI_NO_SIM_EVENT_2,
    GSDI_SIM_INIT_COMPLETED_2,
    GSDI_SIM_INIT_COMPLETED_NO_PROV_2,
    GSDI_PIN1_VERIFIED_2,
    GSDI_PIN1_BLOCKED_2,
    GSDI_PIN1_UNBLOCKED_2,

    GSDI_PIN1_ENABLED_2,
    GSDI_PIN1_DISABLED_2,
    GSDI_PIN1_CHANGED_2,
    GSDI_PIN1_PERM_BLOCKED_2,
    GSDI_PIN2_VERIFIED_2,
    GSDI_PIN2_BLOCKED_2,
    GSDI_PIN2_UNBLOCKED_2,
    GSDI_PIN2_ENABLED_2,
    GSDI_PIN2_DISABLED_2,
    GSDI_PIN2_CHANGED_2,

    GSDI_PIN2_PERM_BLOCKED_2,
    GSDI_REFRESH_SIM_RESET_2,
    GSDI_REFRESH_SIM_INIT_2,
    GSDI_FDN_ENABLE_2,
    GSDI_FDN_DISABLE_2,
    GSDI_OK_FOR_TERMINAL_PROFILE_DL_2,
    GSDI_NOT_OK_FOR_TERMINAL_PROFILE_DL_2,
    GSDI_REFRESH_SIM_INIT_FCN,
    GSDI_REFRESH_SIM_INIT_FCN_2,
    GSDI_REFRESH_FCN,

    GSDI_REFRESH_FCN_2,
    GSDI_REFRESH_FAILED,
    GSDI_START_SWITCH_SLOT,
    GSDI_FINISH_SWITCH_SLOT,
    GSDI_PERSO_INIT_COMPLETED,
    GSDI_PERSO_EVENT_GEN_PROP1,
    GSDI_SIM_ILLEGAL,
    GSDI_SIM_ILLEGAL_2,
    GSDI_SIM_UHZI_V2_COMPLETE,
    GSDI_SIM_UHZI_V1_COMPLETE,

    GSDI_PERSO_EVENT_GEN_PROP2,
    GSDI_INTERNAL_SIM_RESET,
    GSDI_CARD_ERR_POLL_ERROR,
    GSDI_CARD_ERR_NO_ATR_RECEIVED_WITH_MAX_VOLTAGE,
    GSDI_CARD_ERR_NO_ATR_RECEIVED_AFTER_INT_RESET,
    GSDI_CARD_ERR_CORRUPT_ATR_RCVD_MAX_TIMES,
    GSDI_CARD_ERR_PPS_TIMED_OUT_MAX_TIMES,
    GSDI_CARD_ERR_VOLTAGE_MISMATCH,
    GSDI_CARD_ERR_INT_CMD_TIMED_OUT_AFTER_PPS,
    GSDI_CARD_ERR_INT_CMD_ERR_EXCEED_MAX_ATTEMPTS,

    GSDI_CARD_ERR_MAXED_PARITY_ERROR,
    GSDI_CARD_ERR_MAXED_RX_BREAK_ERROR,
    GSDI_CARD_ERR_MAXED_OVERRUN_ERROR,
    GSDI_CARD_ERR_TRANSACTION_TIMER_EXPIRED,
    GSDI_CARD_ERR_POWER_DOWN_CMD_NOTIFICATION,
    GSDI_CARD_ERR_INT_CMD_ERR_IN_PASSIVE_MODE,
    GSDI_CARD_ERR_CMD_TIMED_OUT_IN_PASSIVE_MODE,
    GSDI_CARD_ERR_MAX_PARITY_IN_PASSIVE,
    GSDI_CARD_ERR_MAX_RXBRK_IN_PASSIVE,
    GSDI_CARD_ERR_MAX_OVERRUN_IN_PASSIVE,

    GSDI_CARD_ERR_POLL_ERROR_2,
    GSDI_CARD_ERR_NO_ATR_RECEIVED_WITH_MAX_VOLTAGE_2,
    GSDI_CARD_ERR_NO_ATR_RECEIVED_AFTER_INT_RESET_2,
    GSDI_CARD_ERR_CORRUPT_ATR_RCVD_MAX_TIMES_2,
    GSDI_CARD_ERR_PPS_TIMED_OUT_MAX_TIMES_2,
    GSDI_CARD_ERR_VOLTAGE_MISMATCH_2,
    GSDI_CARD_ERR_INT_CMD_TIMED_OUT_AFTER_PPS_2,
    GSDI_CARD_ERR_INT_CMD_ERR_EXCEED_MAX_ATTEMPTS_2,
    GSDI_CARD_ERR_MAXED_PARITY_ERROR_2,
    GSDI_CARD_ERR_MAXED_RX_BREAK_ERROR_2,

    GSDI_CARD_ERR_MAXED_OVERRUN_ERROR_2,
    GSDI_CARD_ERR_TRANSACTION_TIMER_EXPIRED_2,
    GSDI_CARD_ERR_POWER_DOWN_CMD_NOTIFICATION_2,
    GSDI_CARD_ERR_INT_CMD_ERR_IN_PASSIVE_MODE_2,
    GSDI_CARD_ERR_CMD_TIMED_OUT_IN_PASSIVE_MODE_2,
    GSDI_CARD_ERR_MAX_PARITY_IN_PASSIVE_2,
    GSDI_CARD_ERR_MAX_RXBRK_IN_PASSIVE_2,
    GSDI_CARD_ERR_MAX_OVERRUN_IN_PASSIVE_2,
    GSDI_REFRESH_APP_RESET,
    GSDI_REFRESH_3G_SESSION_RESET,

    GSDI_REFRESH_APP_RESET_2,
    GSDI_REFRESH_3G_SESSION_RESET_2,
    GSDI_APP_SELECTED,
    GSDI_APP_SELECTED_2,
#if 1
    GSDI_LGIT_NOT_SUPPORT_ERROR,
#endif
#if 1 //#ifdef FEATURE_KTFT_MDMDIAG_NAM
#if 1//#ifdef FEATURE_KTF_UICC_LOCK_APPLET
    GSDI_KTF_LOCK_APP_STARTED,
    GSDI_KTF_LOCK_APP_IN_RESET,
#endif  /*FEATURE_KTF_UICC_LOCK_APPLET*/
#endif  /*FEATURE_KTFT_MDMDIAG_NAM*/
    GSDI_MAX_SIM_EVENTS
}gsdi_sim_events_T;

typedef enum
{
  SYS_SRV_DOMAIN_NONE = -1,
    /**< FOR INTERNAL USE ONLY!                 */

  /* 0 */
  SYS_SRV_DOMAIN_NO_SRV,
    /**< No service                             */

  SYS_SRV_DOMAIN_CS_ONLY,
    /**< Circuit Switched Only Capable          */

  SYS_SRV_DOMAIN_PS_ONLY,
    /**< Packet Switched Only Capable           */

  SYS_SRV_DOMAIN_CS_PS,
    /**< Circuit and Packet Switched Capable    */

  /* 4 */
  SYS_SRV_DOMAIN_CAMPED,
    /**< MS found the right system but not yet
    ** registered/attached.                  */

  SYS_SRV_DOMAIN_MAX
    /**< FOR INTERNAL USE ONLY!                 */

  #ifdef FEATURE_RPC
#error code not present
  #endif /* FEATURE_RPC */
} sys_srv_domain_e_type;

#define MM_NULL                                       0
#define MM_IDLE                                       19
#define MM_WAIT_FOR_RR_ACTIVE                         18
#define MM_WAIT_FOR_RR_CONNECTION_LU                  13
#define MM_LOCATION_UPDATE_REJECTED                   10
#define MM_LOCATION_UPDATE_INITIATED                  3
#define MM_WAIT_FOR_RR_CONNECTION_IMSI_DETACH         15
#define MM_IMSI_DETACH_INITIATED                      7
#define MM_WAIT_FOR_NETWORK_COMMAND                   9
#define MM_WAIT_FOR_RR_CONNECTION_MM                  14
#define MM_WAIT_FOR_OUTGOING_MM_CONNECTION            5
#define MM_WAIT_FOR_ADDITIONAL_OUTGOING_MM_CONNECTION 20
#define MM_WAIT_FOR_REESTABLISH_DECISION              22
#define MM_WAIT_FOR_RR_CONNECTION_REESTABLISHMENT     21
#define MM_REESTABLISHMENT_INITIATED                  17
#define MM_CONNECTION_ACTIVE                          6
#define MM_LOCATION_UPDATING_PENDING                  23
#define MM_RR_CONNECTION_RELEASE_NOT_ALLOWED          25
#define MM_PROCESS_CM_SERVICE_PROMPT                  8

 /*
 * Definitions for idle substates
 */

#define MM_NULL_SUBSTATE                              0
#define MM_NO_IMSI                                    1
#define MM_PLMN_SEARCH                                2
#define MM_LIMITED_SERVICE                            3
#define MM_ATTEMPTING_TO_UPDATE                       4
#define MM_LOCATION_UPDATE_NEEDED                     5
#define MM_NO_CELL_AVAILABLE                          6
#define MM_PLMN_SEARCH_NORMAL_SERVICE                 7
#define MM_NORMAL_SERVICE                             8

/* --------------------------------------
** GMM States (see 3GPP TS 24.008 4.1.3 )
** -------------------------------------- */
typedef enum
{
  GMM_NULL,
  GMM_DEREGISTERED,
  GMM_REGISTERED_INITIATED,
  GMM_REGISTERED,
  GMM_DEREGISTERED_INITIATED,
  GMM_ROUTING_AREA_UPDATING_INITIATED,
  GMM_SERVICE_REQUEST_INITIATED
} gmm_state_type;

/* -------------------------------------------------------
** Substates of GMM-DEREGISTERED and GMM_REGISTERED states
** (3GPP TS 24.008 4.1.3.1.2 and 4.1.3.1.3)
** ------------------------------------------------------- */
typedef enum
{
  GMM_NORMAL_SERVICE,
  GMM_LIMITED_SERVICE,
  GMM_ATTACH_NEEDED,
  GMM_ATTEMPTING_TO_ATTACH,
  GMM_NO_IMSI,
  GMM_NO_CELL_AVAILABLE,
  GMM_PLMN_SEARCH,
  GMM_SUSPENDED,
  GMM_UPDATE_NEEDED,
  GMM_ATTEMPTING_TO_UPDATE,
  GMM_ATTEMPTING_TO_UPDATE_MM,
  GMM_IMSI_DETACH_INITIATED,
  GMM_NULL_SUBSTATE
} gmm_substate_type;

typedef enum
{
  RRC_STATE_DISCONNECTED,
  RRC_STATE_CONNECTING,
  RRC_STATE_CELL_FACH,
  RRC_STATE_CELL_DCH,
  RRC_STATE_CELL_PCH,
  RRC_STATE_URA_PCH,
  RRC_STATE_WILDCARD,   /* This is used only for the purposes of state
                        change notification. When a procedure needs to
                        receive state change notification for a transition
                        from any state or to any state, it needs to use
                        this wild card state while registering with state
                        change manager. */
  RRC_STATE_MAX
}rrc_state_e_type;

/*****************/
/* Reject causes */
/*****************/
#define REG_NONE                                    0x00
#define REG_NONE2                                  0x00
#define REG_SUCCESS                                  0x01
#define REG_DCK_PERM_BLOCKED  0xFB
#define REG_DCK_BLOCKED       0xFC
#define REG_NW_PERSO_FAIL   0xFD
#define NO_SIM_IDLE_MODE                  0xFE      /// osh 2008.03.18
#define REG_REGISTERING                     0xFF      // daejang 20070217
#define IMSI_UNKNOWN_IN_HLR                             0x02
#define ILLEGAL_MS                                      0x03
#define IMSI_UNKNOWN_IN_VLR                             0x04
#define IMEI_NOT_ACCEPTED                               0x05
#define ILLEGAL_ME                                      0x06
#define GPRS_SERVICES_NOT_ALLOWED                       0x07
#define GPRS_SERVICES_AND_NON_GPRS_SERVICES_NOT_ALLOWED 0x08
#define MS_IDENTITY_CANNOT_BE_DERIVED_BY_THE_NETWORK    0x09
#define IMPLICITLY_DETACHED                             0x0A
#define PLMN_NOT_ALLOWED                                0x0B
#define LA_NOT_ALLOWED                                  0x0C
#define NATIONAL_ROAMING_NOT_ALLOWED                    0x0D
#define GPRS_SERVICES_NOT_ALLOWED_IN_THIS_PLMN          0x0E
#define NO_SUITABLE_CELLS_IN_LA                         0x0F
#define MSC_TEMPORARILY_NOT_REACHABLE                   0x10
#define NETWORK_FAILURE                                 0x11
#define MAC_FAILURE                                     0x14
#define SYNCH_FAILURE                                   0x15
#define CONGESTTION                                     0x16
#define GSM_AUTH_UNACCEPTED                             0x17
#define SERVICE_OPTION_NOT_SUPPORTED                    0x20
#define REQ_SERV_OPT_NOT_SUBSCRIBED                     0x21
#define SERVICE_OPT__OUT_OF_ORDER                       0x22
#define CALL_CANNOT_BE_IDENTIFIED                       0x26
#define NO_PDP_CONTEXT_ACTIVATED                        0x28
#define RETRY_UPON_ENTRY_INTO_A_NEW_CELL_MIN_VALUE      0x30
#define RETRY_UPON_ENTRY_INTO_A_NEW_CELL_MAX_VALUE      0x3F
#define SEMANTICALLY_INCORRECT_MSG                      0x5F
#define INVALID_MANDATORY_INFO                          0x60
#define MESSAGE_TYPE_NON_EXISTANT                       0x61
#define MESSAGE_TYPE_NOT_COMP_PRT_ST                    0x62
#define IE_NON_EXISTANT                                 0x63
#define MSG_NOT_COMPATIBLE_PROTOCOL_STATE               0x65

/* MN internal error for WMS in case of CNM timer expiry */
#define NO_RESPONSE_FROM_NEWTWORK      126

typedef enum
{
   NETWORK_OP_MODE_1,
   NETWORK_OP_MODE_2,
   NETWORK_OP_MODE_3,
   PS_DOMAIN_SYS_INFO_UNAVAILABLE
} network_op_mode_type;

typedef enum
{
  PMM_DETACHED,
  PMM_IDLE,
  PMM_CONNECTED
} pmm_mode_type;

typedef enum
{
  PDP_INACTIVE,
  PDP_ACTIVE_PENDING,
  PDP_ACTIVE,
  PDP_MODIFY_PENDING,
  PDP_INACTIVE_PENDING
  #ifdef FEATURE_MODEM_MBMS
#error code not present
  #endif
} pdp_state_T;

typedef enum
{
  SM_UNKNOWN_CAUSE = 0x01,    /* For SM internal use only, not to be used in OTA*/
  SM_OPERATOR_DETERMINED_BARRING = 0x08,
  SM_MBMS_BEARER_CAP_INSUFFICIENT = 0x18,
  SM_LLC_SNDCP_FAILURE          = 0x19,
  SM_INSUFFICIENT_RESOURCES,
  SM_MISSING_OR_UNKNOWN_APN,
  SM_UNKNOWN_PDP_ADDRESS_OR_TYPE,
  SM_USER_AUTHENTICATION_FAILED,
  SM_ACTIVATION_REJECTED_BY_GGSN,
  SM_ACTIVATION_REJECTED_UNSPECIFIED,
  SM_SERVICE_OPTION_NOT_SUPPORTED,
  SM_SERVICE_NOT_SUBSCRIBED,
  SM_SERVICE_OUT_OR_ORDER,
  SM_NSAPI_ALREADY_USED,
  SM_REGULAR_DEACTIVATION,
  SM_QOS_NOT_ACCEPTED,
  SM_NETWORK_FAILURE,
  SM_REACTIVATION_REQUIRED,
  SM_FEATURE_NOT_SUPPORTED,
  SM_SEMANTIC_ERR_IN_TFT,
  SM_SYNTACTIC_ERR_IN_TFT,
  SM_UNKNOWN_PDP_CONTEXT,
  SM_SEMANTIC_ERR_IN_FILTER,
  SM_SYNTACTIC_ERR_IN_FILTER,
  SM_PDP_WITHOUT_TFT_ACTIVE,
  SM_MBMS_GROUP_MEMBERSHIP_TIMEOUT,
  SM_INVALID_TRANS_ID = 0x51,
  SM_SEMANTIC_INCORRECT_MESG = 0x5F,
  SM_INVALID_MANDATORY_INFO = 0x60,
  SM_MESG_TYPE_NON_EXISTENT,
  SM_MESG_TYPE_NOT_COMPATIBLE,
  SM_IE_NON_EXISTENT,
  SM_CONDITIONAL_IE_ERR,
  SM_MESG_NOT_COMPATIBLE,
  SM_PROTOCOL_ERR = 0x6F,
  SM_APN_TYPE_CONFLICT
} sm_status_T;

/*
** Enumeration of service status.  Indicates whether service is
** available or not available.
*/
typedef enum
{
  SYS_SRV_STATUS_NONE = -1,
    /* FOR INTERNAL USE ONLY!                 */

  SYS_SRV_STATUS_NO_SRV,
    /* No service                             */

  SYS_SRV_STATUS_LIMITED,
    /* Limited service                        */

  SYS_SRV_STATUS_SRV,
    /* Service available                      */

  SYS_SRV_STATUS_LIMITED_REGIONAL,
    /* Limited regional service               */

  SYS_SRV_STATUS_PWR_SAVE,
    /* MS is in power save or deep sleep      */

  SYS_SRV_STATUS_MAX
    /* FOR INTERNAL USE OF CM ONLY!           */

#ifdef FEATURE_RPC
#error code not present
#endif /* FEATURE_RPC */

} sys_srv_status_e_type;

typedef enum reg_status
{
  NET_REG_NONE        = 0,      /* Not registered, not searching */
  NET_REG_HOME        = 1,      /* Registered on home network */
  NET_REG_SEARCHING   = 2,      /* Not registered, searching */
  NET_REG_DENIED      = 3,      /* Registration denied */
  NET_REG_UNKNOWN     = 4,      /* Unknown registration state */
  NET_REG_ROAMING     = 5,      /* Registered on roaming network */
  REG_REGISTERED_MAX            /* Internal use only! */
} reg_status_e_type; //cs_state, gprs_state �� �� 

typedef enum
{
  SYS_BAND_CLASS_NONE        = -1,
    /* FOR INTERNAL USE OF CM ONLY! */
  /** @endcond
  */

  SYS_BAND_BC0               = 0,
    /**< Band Class 0: U.S. Cellular band (800 MHz). */

  SYS_BAND_BC1               = 1,
    /**< Band Class 1: U.S. */

  SYS_BAND_BC3               = 3,
    /**< Band Class 3: Japanese Cellular band (800 MHz). */

  SYS_BAND_BC4               = 4,
    /**< Band Class 4: Korean PCS band (1800 MHz). */

  SYS_BAND_BC5               = 5,
    /**< Band Class 5 (450 MHz). */

  SYS_BAND_BC6               = 6,
    /**< Band Class 6 (2 GHz). */

  SYS_BAND_BC7               = 7,
    /**< Band Class 7 (Upper 700 MHz). */

  SYS_BAND_BC8               = 8,
    /**< Band Class 8 (1800 MHz). */

  SYS_BAND_BC9               = 9,
    /**< Band Class 9 (900 MHz). */

  SYS_BAND_BC10              = 10,
    /**< Band Class 10 (Second 800 MHz). */

  SYS_BAND_BC11              = 11,
    /**< Band Class 11: European PAMR Band (400 MHz). */

  SYS_BAND_BC12              = 12,
  /**< Band Class 12: PAMR Band (800 MHz). */

  SYS_BAND_BC13              = 13,
  /**< Band Class 13: currently undefined. */

  SYS_BAND_BC14              = 14,
  /**< Band Class 14 (U.S. PCS 1.9 GHz Band). */

  SYS_BAND_BC15              = 15,
  /**< Band Class 15 (1700-2100 MHz -AWS). */

  SYS_BAND_BC16              = 16,
  /**< Band Class 16 (U.S. 2.5 GHz). */

  SYS_BAND_BC17              = 17,
  /**< Band Class 17 (U.S. 2.5 GHz Forward Link only band). */

  SYS_BAND_BC18              = 18,
  /**< Band Class 18 (700 MHz Public Safety Broadband). */

  SYS_BAND_BC19              = 19,
  /**< Band Class 19 (Lower 700 MHz band).*/

  SYS_BAND_BC_MAX            = 20,
  /**< Upper boundary for CDMA band classes.  */

  /* Reserved 20-39 for CDMA band classes. */

  SYS_BAND_GSM_450           = 40,
    /**< GSM 450 band (450 MHz). */

  SYS_BAND_GSM_480           = 41,
    /**< GSM 480 band (480 MHz). */

  SYS_BAND_GSM_750           = 42,
    /**< GSM 750 band (750 MHz). */

  SYS_BAND_GSM_850           = 43,
    /**< GSM 850 band (850 MHz). */

  SYS_BAND_GSM_EGSM_900      = 44,
    /**< GSM Extended GSM (E-GSM) 900 band (900 MHz). */

  SYS_BAND_GSM_PGSM_900      = 45,
    /**< GSM Primary GSM (P-GSM) 900 band (900 MHz). */

  SYS_BAND_GSM_RGSM_900      = 46,
    /**< GSM Railways GSM (R-GSM) 900 band (900 MHz). */

  SYS_BAND_GSM_DCS_1800      = 47,
    /**< GSM DCS band (1800 MHz). */

  SYS_BAND_GSM_PCS_1900      = 48,
    /**< GSM PCS band (1900 MHz). */

  /* Reserved 49-79 for GSM band classes. */

  SYS_BAND_WCDMA_I_IMT_2000  = 80,
    /**< WCDMA Europe, Japan, and China IMT 2100 band. */

  SYS_BAND_WCDMA_II_PCS_1900 = 81,
    /**< WCDMA U.S. PCS 1900 band. */

  SYS_BAND_WCDMA_III_1700    = 82,
    /**< WCDMA Europe and China DCS 1800 band. */

  SYS_BAND_WCDMA_IV_1700     = 83,
    /**< WCDMA U.S. 1700 band. */

  SYS_BAND_WCDMA_V_850       = 84,
    /**< WCDMA U.S. 850 band. */

  SYS_BAND_WCDMA_VI_800      = 85,
    /**< WCDMA Japan 800 band. */

  SYS_BAND_WCDMA_VII_2600    = 86,
    /**< WCDMA Europe 2600 band. */

  SYS_BAND_WCDMA_VIII_900    = 87,
    /**< WCDMA Europe and China 900 band. */

  SYS_BAND_WCDMA_IX_1700     = 88,
    /**< WCDMA Japan 1700 band. */

  /* Reserved 89 for WCDMA BC10-1700 band classes. */

  SYS_BAND_WCDMA_XI_1500     = 90,
    /**< WCDMA 1500 band. */

  SYS_BAND_WCDMA_XIX_850     = 91,
    /**< WCDMA Japan 850 band. */

  /* Reserved 85-109 for WCDMA band classes. */

  SYS_BAND_WLAN_US_2400    = 110,
    /**< WLAN U.S. 2400 MHz band. */

  SYS_BAND_WLAN_JAPAN_2400 = 111,
    /**< WLAN Japan 2400 MHz band. */

  SYS_BAND_WLAN_EUROPE_2400 = 112,
    /**< WLAN Europe 2400 MHz band. */

  SYS_BAND_WLAN_FRANCE_2400 = 113,
    /**< WLAN France 2400 MHz band. */

  SYS_BAND_WLAN_SPAIN_2400 = 114,
    /**< WLAN Spain 2400 MHz band. */

  SYS_BAND_WLAN_US_5000    = 115,
    /**< WLAN U.S. 5000 MHz band. */

  SYS_BAND_WLAN_JAPAN_5000 = 116,
    /**< WLAN Japan 5000 MHz band. */

  SYS_BAND_WLAN_EUROPE_5000 = 117,
    /**< WLAN Europe 5000 MHz band. */

  SYS_BAND_WLAN_FRANCE_5000 = 118,
    /**< WLAN France 5000 MHz band. */

  SYS_BAND_WLAN_SPAIN_5000 = 119,
    /**< WLAN Spain 5000 MHz band. */

  /* LTE bands*/  
    
  SYS_BAND_LTE_EUTRAN_BAND1 = 120,
  /**< UL:1920-1980; DL:2110-2170. */

  SYS_BAND_LTE_EUTRAN_BAND2 = 121,
  /**< UL:1850-1910; DL:1930-1990. */

  SYS_BAND_LTE_EUTRAN_BAND3 = 122,
  /**< UL:1710-1785; DL:1805-1880. */

  SYS_BAND_LTE_EUTRAN_BAND4 = 123,
  /**< UL:1710-1755; DL:2110-2155. */

  SYS_BAND_LTE_EUTRAN_BAND5 = 124,
  /**< UL: 824-849; DL: 869- 894. */

  SYS_BAND_LTE_EUTRAN_BAND6 = 125,
  /**< UL: 830-840; DL: 875-885. */

  SYS_BAND_LTE_EUTRAN_BAND7 = 126,
  /**< UL:2500-2570; DL:2620-2690. */

  SYS_BAND_LTE_EUTRAN_BAND8 = 127,
  /**< UL: 880-915; DL: 925-960. */

  SYS_BAND_LTE_EUTRAN_BAND9 = 128,
  /**< UL:1749.9-1784.9; DL:1844.9-1879.9. */

  SYS_BAND_LTE_EUTRAN_BAND10 = 129,
  /**< UL:1710-1770; DL:2110-2170. */

  SYS_BAND_LTE_EUTRAN_BAND11 = 130,
  /**< UL:1427.9-1452.9; DL:1475.9-1500.9. */

  SYS_BAND_LTE_EUTRAN_BAND12 = 131,
  /**< UL:698-716; DL:728-746. */

  SYS_BAND_LTE_EUTRAN_BAND13 = 132,
  /**< UL: 777-787; DL: 746-756. */

  SYS_BAND_LTE_EUTRAN_BAND14 = 133,
  /**< UL: 788-798; DL: 758-768. */

  /* Reserved for BAND 15, 16 */

  SYS_BAND_LTE_EUTRAN_BAND17 = 136,
  /**< UL: 704-716; DL: 734-746. */

  SYS_BAND_LTE_EUTRAN_BAND18 = 137,
  /**< UL: 815-830; DL: 860-875. */

  SYS_BAND_LTE_EUTRAN_BAND19 = 138,
  /**< UL: 830-845; DL: 875-890. */

  SYS_BAND_LTE_EUTRAN_BAND20 = 139,
  /**< UL: 832-862; DL: 791-821. */

  SYS_BAND_LTE_EUTRAN_BAND21 = 140,
  /**< UL: 1447.9-1462.9; DL: 1495.9-1510.9. */

  SYS_BAND_LTE_EUTRAN_BAND23 = 142,
  /**< UL: 2000-2020; DL: 2180-2200 */

  SYS_BAND_LTE_EUTRAN_BAND24 = 143,
  /**< UL: 1626.5-1660.5; DL: 1525 -1559. */

  SYS_BAND_LTE_EUTRAN_BAND25 = 144,
  /**< UL: 1850-1915; DL: 1930 -1995 . */

  SYS_BAND_LTE_EUTRAN_BAND26 = 145,
  /**< UL: 814-849; DL: 859 -894 . */

  SYS_BAND_LTE_EUTRAN_BAND33 = 152,
  /**< UL: 1900-1920; DL: 1900-1920. */

  SYS_BAND_LTE_EUTRAN_BAND34 = 153,
  /**< UL: 2010-2025; DL: 2010-2025. */

  SYS_BAND_LTE_EUTRAN_BAND35 = 154,
  /**< UL: 1850-1910; DL: 1850-1910. */

  SYS_BAND_LTE_EUTRAN_BAND36 = 155,
  /**< UL: 1930-1990; DL: 1930-1990. */

  SYS_BAND_LTE_EUTRAN_BAND37 = 156,
  /**< UL: 1910-1930; DL: 1910-1930. */

  SYS_BAND_LTE_EUTRAN_BAND38 = 157,
  /**< UL: 2570-2620; DL: 2570-2620. */

  SYS_BAND_LTE_EUTRAN_BAND39 = 158,
  /**< UL: 1880-1920; DL: 1880-1920. */

  SYS_BAND_LTE_EUTRAN_BAND40 = 159,
  /**< UL: 2300-2400; DL: 2300-2400. */

  SYS_BAND_LTE_EUTRAN_BAND41 = 160,
  /**< UL: 2496-2690; DL: 2496-2690. */

  SYS_BAND_LTE_EUTRAN_BAND42 = 161,
  /**< UL: 3400-3600; DL: 3400-3600. */

  SYS_BAND_LTE_EUTRAN_BAND43 = 162,
  /**< UL: 3600-3800; DL: 3600-3800. */

      /* TD-SCDMA bands */    
  SYS_BAND_TDS_BANDA = 163,
  /**< TDS Band A 1900-1920 MHz, 2010-2020 MHz */

  SYS_BAND_TDS_BANDB = 164,
  /**< TDS Band B 1850-1910 MHz, 1930-1990 MHz */

  SYS_BAND_TDS_BANDC = 165,
  /**< TDS Band C 1910-1930 MHz */

  SYS_BAND_TDS_BANDD = 166,
  /**< TDS Band D 2570-2620 MHz */

  SYS_BAND_TDS_BANDE = 167,
  /**< TDS Band E 2300-2400 MHz */

  SYS_BAND_TDS_BANDF = 168,
  /**< TDS Band F 1880-1920 MHz */

  /** @cond
  */
  SYS_BAND_CLASS_MAX   /* FOR INTERNAL USE ONLY! */
} sys_band_class_e_type;

typedef enum
{

  SYS_ROAM_STATUS_NONE = -1,
    /**< FOR INTERNAL USE ONLY!                      */

  /* 0 */
  SYS_ROAM_STATUS_OFF,
    /**< Roaming Indicator off                       */

  SYS_ROAM_STATUS_ON,
    /**< Roaming Indicator on                        */

  SYS_ROAM_STATUS_BLINK,
    /**< Roaming Indicator flashing                  */

  SYS_ROAM_STATUS_OUT_OF_NEIGHBORHOOD,
    /**< Out of neighborhood                         */
  
  /* 4 */
  SYS_ROAM_STATUS_OUT_OF_BLDG,
    /**< Out of building                             */

  SYS_ROAM_STATUS_PREF_SYS,
    /**< Roaming - preferred system                  */

  SYS_ROAM_STATUS_AVAIL_SYS,
    /**< Roaming - available system                  */

  SYS_ROAM_STATUS_ALLIANCE_PARTNER,
    /**< Roaming - alliance partner                  */

  /* 8 */
  SYS_ROAM_STATUS_PREMIUM_PARTNER,
    /**< Roaming - premium partner                   */

  SYS_ROAM_STATUS_FULL_SVC,
    /**< Roaming - full service functionality        */

  SYS_ROAM_STATUS_PARTIAL_SVC,
    /**< Roaming - partial service functionality     */

  SYS_ROAM_STATUS_BANNER_ON,
    /**< Roaming banner on                           */

  /* 12 */
  SYS_ROAM_STATUS_BANNER_OFF,
    /**< Roaming banner off                          */

  SYS_ROAM_STATUS_MAX  = 0xFF+1
    /**< FOR INTERNAL USE ONLY!                      */
    /**< Values 0x00 - 0xFF are used in the standard */

}sys_roam_status_e_type;

typedef enum
{
  SKT_GWCFG_FSCAN_MODE_FULL, //Qualcomm Original..
  SKT_GWCFG_FSCAN_MODE_SKT1_10664,
  SKT_GWCFG_FSCAN_MODE_SKT2_10689,
  SKT_GWCFG_FSCAN_MODE_SKT3_10713,
  SKT_GWCFG_FSCAN_MODE_SKT4_10737,
  // shpark, add channels from SKT SBSM spec v2.8 2011.02.18
  SKT_GWCFG_FSCAN_MODE_SKT5_10639,
  SKT_GWCFG_FSCAN_MODE_SKT6_10614,
  SKT_GWCFG_FSCAN_MODE_SKT_PREF_1,
  SKT_GWCFG_FSCAN_MODE_USER_INPUT, //<=���� �Ʒ��� USER Input..
  SKT_GWCFG_FSCAN_MODE_MAX
} skt_ch_search_mode_e_type;  //jisim_080725

typedef enum
{
  KT_GWCFG_FSCAN_MODE_FULL, //Qualcomm Original..
  KT_GWCFG_FSCAN_MODE_KTF1_10763,
  KT_GWCFG_FSCAN_MODE_KTF2_10787,
  KT_GWCFG_FSCAN_MODE_KTF3_10812,
  KT_GWCFG_FSCAN_MODE_KTF4_10836,
  KT_GWCFG_FSCAN_MODE_KTF_PREF_1,
  KT_GWCFG_FSCAN_MODE_USER_INPUT, //<=���� �Ʒ��� USER Input..
  KT_GWCFG_FSCAN_MODE_MAX
} kt_ch_search_mode_e_type;  //jisim_080725

typedef enum
{
  GWCFG_FSCAN_MODE_FULL, //Qualcomm Original..
  GWCFG_FSCAN_MODE_USER_INPUT, //<=���� �Ʒ��� USER Input..
  GWCFG_FSCAN_MODE_MAX
} ch_search_mode_e_type;  //jisim_080725

typedef enum
{
  NAND_UNKNOWN, 
  NAND_512M, 
  NAND_1G,
  NAND_MAX
} nand_type_e_type;  

typedef enum
{
  CM_CDMA_LOCK_MODE_NONE=-1,
  CM_CDMA_LOCK_MODE_OFF,
  CM_CDMA_LOCK_MODE_ON,
  CM_CDMA_LOCK_MODE_MAX
} cm_cdma_lock_mode_e_type;

typedef enum
{
  CM_PACKET_STATE_NONE=-1,
  CM_PACKET_STATE_NULL,
  CM_PACKET_STATE_CONNECT,
  CM_PACKET_STATE_DORMANT,
  CM_PACKET_STATE_MAX
} cm_packet_state_e_type;

typedef enum {
  WMM_ATTACH_STATE_UNKNOWN = 0,
  WMM_ATTACH_STATE_ATTACHED,
  WMM_ATTACH_STATE_DETACHED,
  WMM_ATTACH_STATE_MAX
} wmm_attach_state_type;

typedef enum
{
  EMM_NULL,
  EMM_DEREGISTERED,
  EMM_REGISTERED_INITIATED,
  EMM_REGISTERED,
  EMM_TRACKING_AREA_UPDATING_INITIATED,
  EMM_SERVICE_REQUEST_INITIATED,
  EMM_DEREGISTERED_INITIATED,
  EMM_INVALID_STATE // FOR INTRNAL USE ONLY
} emm_state_type;

typedef enum
{
  EMM_DEREGISTERED_NO_IMSI,
  EMM_DEREGISTERED_PLMN_SEARCH,
  EMM_DEREGISTERED_ATTACH_NEEDED,
  EMM_DEREGISTERED_NO_CELL_AVAILABLE,
  EMM_DEREGISTERED_ATTEMPTING_TO_ATTACH,
  EMM_DEREGISTERED_NORMAL_SERVICE,
  EMM_DEREGISTERED_LIMITED_SERVICE,
  EMM_DEGEGISTERED_WAITING_PDN_CONN_REQ
} emm_deregistered_substate_type; 

typedef enum
{
  EMM_WAITING_FOR_NW_RESPONSE, 
  EMM_WAITING_FOR_ESM_RESPONSE
} emm_registered_initiated_substate_type ;

typedef enum
{
  EMM_REGISTERED_NORMAL_SERVICE,
  EMM_REGISTERED_UPDATE_NEEDED,
  EMM_REGISTERED_ATTEMPTING_TO_UPDATE,
  EMM_REGISTERED_NO_CELL_AVAILABLE,
  EMM_REGISTERED_PLMN_SEARCH,
  EMM_REGISTERED_LIMITED_SERVICE,
  EMM_REGISTERED_ATTEMPTING_TO_UPDATE_MM,
  EMM_REGISTERED_IMSI_DETACH_INITIATED,
  EMM_REGISTERED_WAITING_FOR_ESM_ISR_STATUS
} emm_registered_substate_type; 

typedef enum
{
  EMM_IDLE_STATE,
  EMM_WAITING_FOR_RRC_CONFIRMATION_STATE,
  EMM_CONNECTED_STATE,
  EMM_RELEASING_RRC_CONNECTION_STATE
} emm_connection_state_type ;

//extern char *gsdi_sim_events_T_str(int value);
//extern char *wmm_main_state_enum_type_str(int value);
//extern char *service_domain_str(int value);
//extern char *mm_state_str(int value);
//extern char *mm_substate_str(int value);
//extern char *gmm_state_str(int value);
//extern char *gmm_substate_str(int value);
//extern char *rrc_state_string(int value);
extern char *reject_cause_string(int value);
//extern char *sm_cause_string(int value);
extern char *service_status_str(int value);
extern char *EVENT_E_TYPE_str(int32 value);
//extern char *pmm_mode_type_str(int value);
//extern char *pdp_state_T_str(int value);
//extern char *sys_band_class_e_type_str(int value);
//extern char *sys_roam_status_e_type_str(int value);
//extern char *cm_cdma_lock_mode_e_type_str(int value);
//extern char *cm_packet_state_e_type_str(int value);
//extern char *wmmdbg_vendor_type_str(int value);
//extern char *wmmdbg_fscan_mode_type_str(int value);
//extern char *wmmdbg_nand_type_str(int value);
extern char *registration_status_str(uint8 value);
extern char *attach_status_str(uint8 value);
extern char *radio_interface_str(uint8 value);
//extern char *pdp_type_str(uint8 value);
//extern char *data_link_status_type_str(uint8 value);
extern char *ril_act_e_type_str(uint8 value);
extern char *emm_state_type_str(uint8 value);
extern char *emm_deregistered_substate_type_str(uint8 value);
extern char *emm_registered_initiated_substate_type_str(uint8 value);
extern char *emm_registered_substate_type_str(uint8 value);
extern char *emm_connection_state_type_str(uint8 value);
extern char *sys_srv_domain_e_type_str(uint8 value);
//extern char* fs_op_str(int32 value);
extern char *emcb_e_type_str(uint8 value);
extern char *pref_mode_e_type_str(uint8 value);
extern char *nitz_state_e_type_str(uint8 value);
extern char *mode_pref_type_str(uint16 value);
//extern char *wmmdbg_vzw_ota_result_type_str(int value);

#endif /* WMMDBG_H */