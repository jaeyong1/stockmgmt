/******************************************************************************
	FILE:
		 TOF_voice.c
	
	DESCRIPTION:
		Function implementation to help the voice call function in Used only TOF layer.

  ---------------------------------------------------------------------------
  Copyright (c) 2016 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/

/*======================================================================*/
/// Include Files	
/*======================================================================*/
#include "TOF_voice.h"

extern voice_all_TOF_call_info_s		g_voice_all_TOF_call_info;	

/*======================================================================

FUNCTION update_g_voice_all_TOF_call_info
 
DESCRIPTION
	
======================================================================*/

void	update_g_voice_all_TOF_call_info( TOF_Current_Call_Info* TOF_call, int TOF_call_info_len )
{
	int i;

	g_voice_all_TOF_call_info.TOF_call_info_len = TOF_call_info_len;

	MSG_MED( "[VOICE] update_g_voice_all_TOF_call_info() TOF_call_info_len:%d", g_voice_all_TOF_call_info.TOF_call_info_len, 0, 0 );

	for ( i = 0; i < g_voice_all_TOF_call_info.TOF_call_info_len; ++i )
	{
		g_voice_all_TOF_call_info.TOF_call[ i ].index = TOF_call->call_info[i].index;
		g_voice_all_TOF_call_info.TOF_call[ i ].state = TOF_call->call_info[i].state;
		
		MSG_MED( "TOF_call[%d] - call_id:%d, state:%s", i, g_voice_all_TOF_call_info.TOF_call[ i ].index, getCallStateString( g_voice_all_TOF_call_info.TOF_call[ i ].state ) );
	}
}
/*======================================================================

FUNCTION getCallStateString
 
DESCRIPTION
	
======================================================================*/
const char* getCallStateString( int state )
{
  switch ( state )
  {
    case TOF_CALL_ACTIVE:			return "CALL_ACTIVE";
    case TOF_CALL_HOLDING:		return "CALL_HOLDING";
    case TOF_CALL_DIALING:		return "CALL_DIALING";
    case TOF_CALL_ALERTING:		return "CALL_ALERTING";
    case TOF_CALL_INCOMING:		return "CALL_INCOMING";
    case TOF_CALL_WAITING:		return "CALL_WAITING";
    default:									return "CALL_UNKNOWN";
  }
}

