/******************************************************************************
  @file    tof_api.c
  @brief   The QMI TOF API

  DESCRIPTION

  INITIALIZATION AND SEQUENCING REQUIREMENTS

  ---------------------------------------------------------------------------
  Copyright (c) 2016 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/

#include <stdio.h>
#include <signal.h>

#include "TOF_API.h"
#include "qmi_dms.h"
#include "qmi_nas.h"
#include "qmi_uim.h"
#include "qmi_ims.h"
#include "qmi_voice.h"
#include "TOF_voice.h"
#include "qcmap_tof.h"
#include "qmi_loc_lgit.h"
#include "ap_lib.h"
#include "wlan_tof.h"
#include "qmi_imsa.h"
#include "qmi_wds.h"

// TOF API version
// Change this string when new release
#define TOF_API_VERSION "V1.15"

#define TOF_DMS_SUPPORT
#define TOF_UIM_SUPPORT
#define TOF_NAS_SUPPORT
#define TOF_VOICE_SUPPORT
#define TOF_WMS_SUPPORT
#define TOF_DATA_SUPPORT
#define TOF_LOC_SUPPORT
#define TOF_IMS_SUPPORT
#define TOF_IMSA_SUPPORT

//Global Variable
extern TOF_MODEM_CB qmi_event_notify_call_back;
extern void* qmi_event_notify_user_data;
wmmdiag_vendor_type    vendor_type = WMM_VENDOR_NONE;  
extern TOF_SignalStrength tof_signal_strength;
extern voice_all_TOF_call_info_s    g_voice_all_TOF_call_info;  

/* Need to check if IMS Service is usable or not */
boolean enable_IMS_Service =0;

RIL_CardStatus_v6 tof_card_status;
boolean tof_card_init = FALSE;

#define MAX_REGISTRATION_STATUS_INDEX 14

/*qmi message library handle*/
int qmi_handle = QMI_INVALID_CLIENT_HANDLE;

/*===========================================================================
  FUNCTION  tof_init_vendor_type
===========================================================================*/
/* Functions */
boolean    tof_init_vendor_type();

/*===========================================================================
  FUNCTION  tof_init_vendor_type
===========================================================================*/
boolean    tof_init_vendor_type()
{
  uint8 local_vender =0;
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_get_vendorID : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }
  
  if(request_get_vendor(&local_vender) == RESULT_SUCCESS)
  {
    printf("[TOF]request_get_vendor success 0x%x \r\n", local_vender);   
  }
  else
  {
    printf("[TOF]request_get_vendor failed\r\n");
    return FALSE;
  }

  vendor_type = local_vender;
  printf("[TOF]request_get_vendor success 0x%x, vendor_type =0x%x \r\n", local_vender,vendor_type);   
  
  return TRUE;
}

wmmdiag_vendor_type    wmm_get_vendor_type()  //dsji_20110127
{
  return vendor_type;
}

/*===========================================================================
  FUNCTION  lgit_atol
===========================================================================*/
uint64 lgit_atol(char *str)
{
  uint32 high,low, cnt = 0;
  
  char upstr[10] = {0,};
  char lowstr[10] = {0,};

  uint64 total = 0;

  //More than 32 bits
  if(atol(str) == 2147483647) //max
  {
    cnt = strlen(str);

    memcpy(lowstr, &str[cnt-9], 9);    
    memcpy(upstr, str, cnt-9);
    low = atoi(lowstr);
    high = atoi(upstr);

    total = low;
    total += (uint64)((uint64)high * (uint64)(1000000000));
      
    return total;
  }
  else //32 bits
    return (uint64)atoi(str);
}

boolean ims_service_enable()
{
  uint8 enable_ims = 0;
  if(request_get_ims_enable(&enable_ims) == FALSE)
  {
    printf("ims_service_enable() fail to read enable_ims =%d\n",enable_ims);
    return FALSE;
  }
  enable_IMS_Service = (boolean)enable_ims;
  printf("ims_service_enable() enable_ims =%d, enable_IMS_Service =%d\n",enable_ims,enable_IMS_Service);
  return TRUE; 
}

boolean get_ims_service_enable()
{
  return enable_IMS_Service;
}

int lgit_uim_present(void)
{
  //Init tof_card_status for PIN operation
  if(!tof_card_init)
  {
    if(ril_request_get_sim_status(&tof_card_status) == RESULT_SUCCESS)
    {
      tof_card_init = TRUE;
      printf("[TOF]TOF_request_get_sim_status success +\r\n");
    }
    else
      return TOF_SIM_FAIL;
  }

  if((tof_card_status.card_state == RIL_CARDSTATE_ABSENT)
    ||(tof_card_status.card_state == RIL_CARDSTATE_ERROR))
  {
    printf("[TOF]card_state ABSENT or ERROR --> %d\n",tof_card_status.card_state);
    
    return TOF_NO_SIM_FAIL;
  }

  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  tof_qmi_init
===========================================================================*/
int tof_qmi_init(void)
{
  int qmi_err_code = QMI_NO_ERR;
  int rc = QMI_NO_ERR;

  enable_IMS_Service = FALSE;
  
  qmi_handle = qmi_init(NULL, NULL);

  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("Unable to acquire qmi handle \n");
    return QMI_INTERNAL_ERR;
  }

  if ((rc = qmi_connection_init (QMI_PORT_RMNET_0, &qmi_err_code)) < 0) 
  {
    printf("Unable to open QMI RMNET_1 port rc=%d, "
                  "qmi_err_code=%x\r\n",rc,qmi_err_code);
    return QMI_INTERNAL_ERR;
  }

  //dms service initialize.
  if (tof_qmi_dms_init() != RESULT_SUCCESS)
  {
    printf("DMS service init failed\n");
    return QMI_INTERNAL_ERR;
  }
  
  //UIM service initialize.
  if (tof_qmi_uim_init() != RESULT_SUCCESS)
  {
    printf("UIM service init failed");
    return QMI_INTERNAL_ERR;
  }
  
  //nas service initialize.
  if (tof_qmi_nas_init() != RESULT_SUCCESS)
  {
    printf("NAS service init failed\n");
    return QMI_INTERNAL_ERR;
  }
  
  //voice service initialize
  if (tof_qmi_voice_init() != RESULT_SUCCESS)
  {
    printf("Voice service init failed\n");
    return QMI_INTERNAL_ERR;
  }

  tof_init_vendor_type(); //chad_20160616
  if(ims_service_enable() != TRUE)
  {
    printf("ims_service_enable() init failed\n");
  }
  
  //GPS service initialize
  if (tof_qmi_loc_init() != RESULT_SUCCESS)
  {
    printf("LOC service init failed\n");
    return QMI_INTERNAL_ERR;
  }

  if ( (wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ) || (wmm_get_vendor_type() == WMM_VENDOR_H_LTE_VZW ) ||
        (wmm_get_vendor_type() == WMM_VENDOR_C_TCU_VZW ) || (wmm_get_vendor_type() == WMM_VENDOR_A_VZW ))
  {
    //ims service initialize
    if (qmi_ims_init() != RESULT_SUCCESS)
    {
      printf("IMS service init failed. But Do Not Return Error. Because when IMS is disabled, IMS Task cannot alive!! \n");
      if(get_ims_service_enable() == FALSE)
      {
        MSG_FATAL("get_ims_service_enable() IMS Service is Disabled \n",0,0,0);
      }
      else
        return QMI_INTERNAL_ERR;
    }

    //imsa service initialize
    if (qmi_imsa_srvc_init() != RESULT_SUCCESS)
    {
      printf("IMSA service init failed. But Do Not Return Error. Because when IMS is disabled, IMS Task cannot alive!! \n");
      if(get_ims_service_enable() == FALSE)
      {
        MSG_FATAL("get_ims_service_enable() IMS Service is Disabled \n",0,0,0);
      }
      else
        return QMI_INTERNAL_ERR;
    }
  }
  else
  {
    printf("Module is not a VZW Module vender =%x \n",vendor_type);
  }
  
  //WDS service initialize
  if (tof_qmi_wds_init() != RESULT_SUCCESS)
  {
    printf("WDS service init failed");
    return QMI_INTERNAL_ERR;
  }

  return rc;
}


/*===========================================================================
  FUNCTION  tof_qmi_release
===========================================================================*/
int tof_qmi_release(void)
{ 
  int rc = QMI_NO_ERR;

  //dms service release.
  if (tof_qmi_dms_release() != RESULT_SUCCESS)
  {
    printf("tof_qmi_dms_srvc_release failed");
    return QMI_INTERNAL_ERR;
  }

  //uim service release.
  if (tof_qmi_uim_release() != RESULT_SUCCESS)
  {
    printf("tof_qmi_uim_srvc_release failed");
    return QMI_INTERNAL_ERR;
  }
  
  //nas service release.
  if (tof_qmi_nas_release() != RESULT_SUCCESS)
  {
    printf("tof_qmi_nas_srvc_release failed");
    return QMI_INTERNAL_ERR;
  }

  //voice service release.
  if (tof_qmi_voice_release() != RESULT_SUCCESS)
  {
    printf("tof_qmi_voice_srvc_release failed");
    return QMI_INTERNAL_ERR;
  }

  //loc service release.
  if (tof_qmi_loc_release() != RESULT_SUCCESS)
  {
    printf("tof_qmi_loc_srvc_release failed");
    return QMI_INTERNAL_ERR;
  }

  //ims service release
  if (qmi_ims_release() != RESULT_SUCCESS)
  {
    printf("qmi_ims_srvc_release failed");
    return QMI_INTERNAL_ERR;
  }

  //WDS service release
  if (tof_qmi_wds_release() != RESULT_SUCCESS)
  {
    printf("tof_qmi_wds_release failed");
    return QMI_INTERNAL_ERR;
  }

  if (qmi_handle >=0 )
  { 
    rc = qmi_release(qmi_handle);
    if(rc != QMI_NO_ERR)
    {
      printf("tof_qmi_release qmi_release rc = %d, qmi_handle= %x \n", rc, qmi_handle);
    }  
  }
  else
  {
    printf("tof_qmi_release qmi_handle= %x \n", qmi_handle);
  }

  return rc;
}

/*===========================================================================
  FUNCTION  TOF_API_version
===========================================================================*/
int TOF_API_version(char *ver)
{
	memcpy(ver, TOF_API_VERSION, strlen(TOF_API_VERSION));
	MSG_LOW("TOF version : %s\n", ver, 0, 0);
	
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_API_init
===========================================================================*/
int TOF_API_init(void)
{
  printf("[TOF]TOF_API_init\n");
  TOF_SetLogPrint(TRUE);

  if(tof_qmi_init() != QMI_NO_ERR)
  {
    tof_qmi_release();
    
    return TOF_FAIL;
  }

  if(TRUE != qcmap_client_init())
  {
    qcmap_client_release();
    
    return TOF_FAIL;
  }

#ifdef FEATURE_TOF_UI
	if( FALSE == TOF_init() )
	{
	}
#endif

  switch(vendor_type)
  {
  case WMM_VENDOR_C_TCU_JPN: // 0x50 - Clarion_TCU_JPN
      printf("TOF_API_init : Vendor = Clarion_TCU_JPN\n");
      gpio_check = gpio_check_clarion;
      gpio_trans = gpio_trans_clarion;
      print_supported_gpios = print_supported_gpios_clarion;
      break;
  case WMM_VENDOR_B_CHN: // 0x71 - Bosch_CT_CHN
      printf("TOF_API_init : Vendor = Bosch_CT_CHN\n");
      gpio_check = gpio_check_bosch;
      gpio_trans = gpio_trans_bosch;
      print_supported_gpios = print_supported_gpios_bosch;
      break;
  default:
      printf("TOF_API_init : Unknown vendor ID = 0x%x\n", vendor_type);
      return TOF_FAIL;
  }
    
//  tof_init_vendor_type(); //move to tof_qmi_init() for checking vender to use IMS service

  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_API_release
===========================================================================*/
int TOF_API_release(void)
{
  printf("[TOF]TOF_API_release\n");

  EndEventNotifyThread();

#ifdef FEATURE_TOF_UI
  TOF_release();
#endif

  if(tof_qmi_release() != QMI_NO_ERR)
    return TOF_FAIL;

  TOF_SetLogPrint(FALSE);
  printf("LOG Print Stop\n");

  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_SetEventHandle
===========================================================================*/
int TOF_SetEventHandle(TOF_MODEM_CB pFunc, void *pUserData)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_SetEventHandle : Unable to acquire qmi handle \n");
    return TOF_FAIL;
  }
  
  printf("TOF_SetEventHandle() pFunc:0x%08X pUserData:0x%08X\r\n", pFunc, pUserData, 0);  

  qmi_event_notify_call_back = pFunc;
  qmi_event_notify_user_data = pUserData;

  StartEventNotifyThread();
}

/*===========================================================================
  FUNCTION  TOF_request_set_audio_volume
===========================================================================*/
int TOF_request_set_audio_volume(int volume)
{
  printf("Not work yet\n");
  printf("volume = %d\n", volume);
  
  return 0;
}

/*===========================================================================
  FUNCTION  TOF_request_get_audio_volume
===========================================================================*/
int TOF_request_get_audio_volume(int *volume)
{
  printf("Not work yet\n");
  
  return 0;
}

/*===========================================================================
  FUNCTION  TOF_gpio_config
===========================================================================*/
int TOF_gpio_config(int gpio_num, int flag)
{
  printf("TOF_gpio_config : GPIO %d = %d\n", gpio_num, flag);
  if(1 == gpio_check(gpio_num))
    {
      if(0 == gpio_is_exported(gpio_trans(gpio_num)))
        if(gpio_export(gpio_trans(gpio_num)))
          {
            printf("TOF_gpio_config : Error! Exporting is failed for GPIO %d\n",gpio_num);
            return TOF_FAIL;
          }
      gpio_set_dir(gpio_trans(gpio_num),flag);
    }
  else
    {
      printf("TOF_gpio_config : Error! Not supported PAD number %d\n",gpio_num);
      print_supported_gpios();
      return TOF_FAIL;
    }  
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_gpio_get_direction
===========================================================================*/
int TOF_gpio_get_direction(int gpio_num, char* dir)
{
    if(1 == gpio_check(gpio_num))
    {
        if(1 == gpio_is_exported(gpio_trans(gpio_num)))
        {
            gpio_get_dir(gpio_trans(gpio_num),dir);
        }
        else
        {
            printf("TOF_gpio_get_direction :Error! Please config first for GPIO %d\n",gpio_num);
            return TOF_FAIL;
        }
    }
    else
    {
        printf("TOF_gpio_get_direction : Error! Not supported PAD number %d\n",gpio_num);
        print_supported_gpios();
        return TOF_FAIL;
    }

    printf("TOF_gpio_get_direction : GPIO %d = %s\n", gpio_num, dir);
    
    return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_gpio_fd_open
===========================================================================*/
int TOF_gpio_fd_open(int gpio_num, int *gpio_fd)
{
  printf("TOF_gpio_fd_open for GPIO %d \n", gpio_num);
  if(1 == gpio_check(gpio_num))
    {
      if(0 == gpio_is_exported(gpio_trans(gpio_num)))
        {
          printf("TOF_gpio_fd_open : Error! Export and set edge first!\n");
          return TOF_FAIL;
        }
      else
        {
          *gpio_fd = gpio_fd_open(gpio_trans(gpio_num));
          if(*gpio_fd < 0)
            {
              printf("TOF_gpio_fd_open : Error! Not supported PAD number %d\n",gpio_num);
              return TOF_FAIL;
            }
        }
    }
  else
    {
      printf("TOF_gpio_fd_open : Error! Not supported PAD number %d\n",gpio_num);
      print_supported_gpios();
      return TOF_FAIL;
    }  
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_gpio_fd_close
===========================================================================*/
int TOF_gpio_fd_close(int gpio_fd)
{
  printf("TOF_gpio_fd_close \n");
  gpio_fd_close(gpio_fd);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_gpio_set_edge
===========================================================================*/
int TOF_gpio_set_edge(int gpio_num, char* edge)
{
  printf("TOF_gpio_set_edge : GPIO %d edge = %s\n", gpio_num, edge);
  if(1 == gpio_check(gpio_num))
    {
      if(0 == gpio_is_exported(gpio_trans(gpio_num)))
        gpio_export(gpio_trans(gpio_num));
      if(gpio_set_dir(gpio_trans(gpio_num),0))
        {
          printf("TOF_gpio_set_edge : Error! gpio_set_dir is failed for GPIO %d\n",gpio_num);
          return TOF_FAIL;
        }
      if(gpio_set_edge(gpio_trans(gpio_num),edge))
        {
          printf("TOF_gpio_set_edge : Error! gpio_set_edge is failed for GPIO %d\n",gpio_num);
          return TOF_FAIL;
        }
    }
  else
    {
      printf("TOF_gpio_config : Error! Not supported PAD number %d\n",gpio_num);
      print_supported_gpios();
      return TOF_FAIL;
    }  
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_gpio_get_edge
===========================================================================*/
int TOF_gpio_get_edge(int gpio_num, char* edge)
{
    printf("TOF_gpio_get_edge : GPIO %d\n", gpio_num);

    if(1 == gpio_check(gpio_num))
    {
        if(1 == gpio_is_exported(gpio_trans(gpio_num)))
        {
            gpio_get_edge(gpio_trans(gpio_num), edge);
        }
        else
        {
            printf("TOF_gpio_get_edge :Error! Please config first for GPIO %d\n",gpio_num);
            return TOF_FAIL;
        }
    }
    else
    {
        printf("TOF_gpio_get_edge : Error! Not supported PAD number %d\n",gpio_num);
        print_supported_gpios();
        return TOF_FAIL;
    }

    printf("TOF_gpio_get_edge : GPIO %d EDGE is %s\n",gpio_num, edge);

    return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_gpio_set
===========================================================================*/
int TOF_gpio_set(int gpio_num, int status)
{
  printf("TOF_gpio_set : GPIO SET %d = %d\n", gpio_num, status);
  if(1 == gpio_check(gpio_num))
    {
      if(1 == gpio_is_exported(gpio_trans(gpio_num)))
        {
          if(gpio_set_val(gpio_trans(gpio_num),status))
            {
              printf("TOF_gpio_set : Error! gpio_set_val is failed for GPIO %d\n",gpio_num);
              return TOF_FAIL;
            }
        }
      else
        {
          printf("TOF_gpio_set : Error! Please config first for GPIO %d\n",gpio_num);
          return TOF_FAIL;
        }
    }
  else
    {
      printf("TOF_gpio_set : Error! Not supported PAD number %d\n",gpio_num);
      print_supported_gpios();
      return TOF_FAIL;
    }  
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_gpio_get
===========================================================================*/
int TOF_gpio_get(int gpio_num, int *status)
{
  printf("TOF_gpio_get : GPIO GET %d \n", gpio_num);
   if(1 == gpio_check(gpio_num))
    {
      if(1 == gpio_is_exported(gpio_trans(gpio_num)))
        gpio_get_val(gpio_trans(gpio_num),status);
      else
        {
          printf("TOF_gpio_get :Error! Please config first for GPIO %d\n",gpio_num);
          return TOF_FAIL;
        }
    }
  else
    {
      printf("TOF_gpio_get : Error! Not supported PAD number %d\n",gpio_num);
      print_supported_gpios();
      return TOF_FAIL;
    }  
  printf("TOF_gpio_get : GPIO %d status is %d (0:LOW, 1:HIGH) \n",gpio_num,*status);
    
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_SetLogPrint
===========================================================================*/
int TOF_SetLogPrint(boolean state)
{
    SetLogPrint(state);

    if(state ==GetLogPrintState()) return TOF_SUCCESS;
    else TOF_FAIL;
}

#ifdef TOF_DMS_SUPPORT
/*===========================================================================
  FUNCTION  TOF_request_get_basebandversion
===========================================================================*/
int TOF_request_get_basebandversion(tof_dms_get_modem_sw_version_resp_msg *get_modem_sw_version)
{   
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_get_basebandversion : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }
  
  if(request_get_modem_sw_version(get_modem_sw_version) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_REQUEST_GET_BASEBANDVERSION success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_REQUEST_GET_BASEBANDVERSION failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_get_vendorID
===========================================================================*/
int TOF_request_get_vendorID(uint8 *vendorID)
{   
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_get_vendorID : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }
  
  if(request_get_vendor(vendorID) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_get_vendorID success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_get_vendorID failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_set_vendorID
===========================================================================*/
int TOF_request_set_vendorID(uint8 vendorID)
{   
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_set_vendorID : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }
  
  if(request_set_vendor(vendorID) == RESULT_SUCCESS)
  {
    printf("[TOF]request_set_vendor success +\r\n");   
  }
  else
  {
    printf("[TOF]request_set_vendor failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_set_maxpwr
===========================================================================*/
int TOF_request_set_maxpwr(tof_dms_max_power_type_v01 max_pwr)
{   
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_set_maxpwr : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }
  
  if(request_set_maxpwr(max_pwr) == RESULT_SUCCESS)
  {
    printf("[TOF]request_set_maxpwr success +\r\n");   
  }
  else
  {
    printf("[TOF]request_set_maxpwr failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_set_modem_mode
===========================================================================*/
int TOF_request_set_modem_mode(uint8 mode)
{   
  UINT32 ret = RESULT_SUCCESS;
  
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_Request_set_modem_mode : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

/* ((int *)data)[0] is 0 : modem reset
  * ((int *)data)[0] is 1 : modem offline
  * ((int *)data)[0] is 2 : modem normal mode (disable uart debugging)
  * ((int *)data)[0] is 3 : modem debug mode (enable uart debugging)
  * ((int *)data)[0] is 4 : modem debug mode (enable Call debug msg)
  * ((int *)data)[0] is 5 : modem audio loop back mode (enable audio loop back mode)
  * ((int *)data)[0] is 6 : modem audio loop back mode (disable audio loop back mode)
  * ((int *)data)[0] is 7 : modem factory test mode(FTM)
  * ((int *)data)[0] is 8 : modem low power mode(LPM)
  * ((int *)data)[0] is 9 : modem online
  * ((int *)data)[0] is 10 : UIM power down
  * ((int *)data)[0] is 11 : UIM power up  
 */
  switch(mode)
  {
    case MODEM_RESET:
                  ret = ril_request_hk_modem_reset();      
    break;

    case MODEM_OFFLINE:
      ret = request_set_oprt_mode(DMS_OP_MODE_OFFLINE_V01);
    break;

    case MODEM_FTM:
      ret = request_set_oprt_mode(DMS_OP_MODE_FACTORY_TEST_MODE_V01);      
    break;

    case MODEM_LPM:
      ret = request_set_oprt_mode(DMS_OP_MODE_LOW_POWER_V01);            
    break;

    case MODEM_ONLINE:
      ret = request_set_oprt_mode(DMS_OP_MODE_ONLINE_V01);      
    break;

    case UIM_POWERDOWN:
      ret = uicc_power_down();      
    break;

    case UIN_POWERUP:
      ret = uicc_power_up();      
    break;    

    default:
      ret = RESULT_FAILURE;
    break;    
      
  }
    
  
  if (ret != RESULT_SUCCESS)
  {
    printf("[TOF]request_set_modem_mode failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION TOF_request_modem_reset
===========================================================================*/
int TOF_request_modem_reset(void)
{
  int ret;
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_modem_reset : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  ret = ril_request_hk_modem_reset();
  printf("TOF_request_modem_reset retval = %d \n",ret );

  return ret;
}

/*===========================================================================
  FUNCTION TOF_request_modem_init
===========================================================================*/
int TOF_request_modem_init(void)
{
  int ret = RESULT_SUCCESS;

  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_modem_init : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  ret=HK_MDM_MODEM_INIT();
  printf("MODEM INIT result = %d \n",ret );

  if(ret == RESULT_SUCCESS)
  {     /*modem rebooting*/
    ret = ril_request_hk_modem_reset();
  }

  return ret; 
}

/*===========================================================================
  FUNCTION  TOF_request_get_imei
===========================================================================*/
int TOF_request_get_imei(char* imei)
{  
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)  
  {
    printf("TOF_request_set_vendorID : Unable to acquire qmi handle \n");   
    
    return TOF_HANDLE_FAIL;
   } 

  if(ril_request_get_imei(imei) == RESULT_SUCCESS) 
  { 
    printf("[TOF]TOF_request_get_imei success +\r\n");    
  }
  else
  {
    printf("[TOF]TOF_request_get_imei failed\r\n");   
    return TOF_FAIL;
  }
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_get_imsi
===========================================================================*/

int TOF_request_get_imsi(char* imsi)
{
  int tof_error = TOF_SUCCESS;
    
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_Request_get_imsi : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  tof_error = lgit_uim_present();

  if(tof_error != TOF_SUCCESS)
  {
    printf("[TOF]lgit_uim_present fail %d +\r\n",tof_error);   
    return tof_error;
  }
  
  if(ril_request_get_imsi(imsi) == RESULT_SUCCESS)
  {
    printf("[TOF]request_get_imsi success +\r\n");   
  }
  else
  {
    printf("[TOF]request_get_imsi failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

int TOF_getIMSI(uint64 *imsi)
{
  char temp[33]={0,}; //QMI max IMSI 33
  char *end;
  int tof_error = TOF_SUCCESS;
    
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_getIMSI : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  tof_error = lgit_uim_present();

  if(tof_error != TOF_SUCCESS)
  {
    printf("[TOF]lgit_uim_present fail %d +\r\n",tof_error);   
    return tof_error;
  }
  
  if(ril_request_get_imsi(temp) == RESULT_SUCCESS)
  {
    *imsi = lgit_atol(temp);
    printf("[TOF]TOF_getIMSI success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_getIMSI failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}  

uint16 getmcc(char *imsi)
{
  uint16 mcc;
  
  mcc = (imsi[0] - '0')*100;
  mcc += (imsi[1] - '0')*10;
  mcc += (imsi[2] - '0');

  return mcc;
}

boolean ismnclong(char *imsi)
{
  boolean ret = FALSE;
  uint16                mnc_3digit_mcc_list[] = {302, 310, 311, 312, 313, 314,
                                             315, 316, 334, 348, 405, 344,
                                             365, 722, 342, 350, 346, 732,
                                             366, 750, 352, 358, 354, 708,
                                             338, 356, 360, 374, 376};
  uint16 mcc = 0;
  int i=0;
           
  mcc = getmcc(imsi);

  for (i = 0; i < sizeof(mnc_3digit_mcc_list) / sizeof(uint16); i++)
  {
    if (mcc == mnc_3digit_mcc_list[i])
    {
      ret = TRUE;
      break;
    }
  }

  return ret;
}

uint16 getmnc(char *imsi)
{
  uint16 mnc = 0;

  if(ismnclong(imsi))
  {
    mnc = (imsi[3] - '0')*100;
    mnc += (imsi[4] - '0')*10;
    mnc += (imsi[5] - '0');
  }
  else
  {
    mnc += (imsi[3] - '0')*10;
    mnc += (imsi[4] - '0');
  }

  return mnc;
}

int TOF_getMSIN(uint64 *msin)
{
  char temp[33]={0,}; //QMI max IMSI 33
  int tof_error = TOF_SUCCESS;
  
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_getMSIN : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  tof_error = lgit_uim_present();

  if(tof_error != TOF_SUCCESS)
  {
    printf("[TOF]lgit_uim_present fail %d +\r\n",tof_error);   
    return tof_error;
  }
  
  if(ril_request_get_imsi(temp) == RESULT_SUCCESS)
  {
    if(ismnclong(temp))
      *msin = lgit_atol(&temp[6]);
    else
      *msin = lgit_atol(&temp[5]);
    
    printf("[TOF]TOF_getMSIN success %llu +\r\n", *msin);   
  }
  else
  {
    printf("[TOF]TOF_getMSIN failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
} 

int TOF_getMSINString(char *msin)
{
  char temp[33]={0,}; //QMI max IMSI 33
  uint64 lmsin = 0;
  int i =0;
  int tof_error = TOF_SUCCESS;
  
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_getMSIN : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  tof_error = lgit_uim_present();

  if(tof_error != TOF_SUCCESS)
  {
    printf("[TOF]lgit_uim_present fail %d +\r\n",tof_error);   
    return tof_error;
  }
  
  if(ril_request_get_imsi(temp) == RESULT_SUCCESS)
  {
    if(ismnclong(temp))
    {
      lmsin = lgit_atol(&temp[6]);
      sprintf(msin,"%09llu",lmsin);
    }
    else
    {
      lmsin = lgit_atol(&temp[5]);
      sprintf(msin,"%10llu",lmsin);
    }
    
    for(i=0;i<9;i++)
    {
      if(msin[i] == 0x20)
        msin[i] = 0x30; //'0'
    }
    
    printf("[TOF]TOF_getMSIN success %s +\r\n", msin);   
  }
  else
  {
    printf("[TOF]TOF_getMSIN failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
} 

int TOF_getMCC(void)
{
  char temp[33]={0,}; //QMI max IMSI 33
  int tof_error = TOF_SUCCESS;
  
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_getMCC : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  tof_error = lgit_uim_present();

  if(tof_error != TOF_SUCCESS)
  {
    printf("[TOF]lgit_uim_present fail %d +\r\n",tof_error);   
    return tof_error;
  }
  
  if(ril_request_get_imsi(temp) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_getMCC success +\r\n");   
    
    return getmcc(temp);
  }
  else
  {
    printf("[TOF]TOF_getMCC failed\r\n");
    return 0;
  }
} 

int TOF_getMCCString(char *mcc)
{
  char temp[33]={0,}; //QMI max IMSI 33
  int tof_error = TOF_SUCCESS;
  
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_getMCCString : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  tof_error = lgit_uim_present();

  if(tof_error != TOF_SUCCESS)
  {
    printf("[TOF]lgit_uim_present fail %d +\r\n",tof_error);   
    return tof_error;
  }
  
  if(ril_request_get_imsi(temp) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_getMCCString success +\r\n");   

    sprintf(mcc,"%03d",getmcc(temp));
  }
  else
  {
    printf("[TOF]TOF_getMCCString failed\r\n");
    return TOF_FAIL;
  }

  return TOF_SUCCESS;
} 

int TOF_getMNC(void)
{
  char temp[33]={0,}; //QMI max IMSI 33
  int tof_error = TOF_SUCCESS;
  
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_getMNC : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  tof_error = lgit_uim_present();

  if(tof_error != TOF_SUCCESS)
  {
    printf("[TOF]lgit_uim_present fail %d +\r\n",tof_error);   
    return tof_error;
  }
  
  if(ril_request_get_imsi(temp) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_getMNC success +\r\n");   
    
    return getmnc(temp);
  }
  else
  {
    printf("[TOF]TOF_getMNC failed\r\n");
    return 0;
  }
} 

int TOF_getMNCString(char *mnc)
{
  char temp[33]={0,}; //QMI max IMSI 33
  int tof_error = TOF_SUCCESS;
  
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_getMCCString : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  tof_error = lgit_uim_present();

  if(tof_error != TOF_SUCCESS)
  {
    printf("[TOF]lgit_uim_present fail %d +\r\n",tof_error);   
    return tof_error;
  }
  
  if(ril_request_get_imsi(temp) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_getMNCString success +\r\n");   

    if(ismnclong(temp))      
      sprintf(mnc,"%03d",getmnc(temp));
    else
      sprintf(mnc,"%02d",getmnc(temp));
  }
  else
  {
    printf("[TOF]TOF_getMNCString failed\r\n");
    return TOF_FAIL;
  }

  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_get_imeisv
===========================================================================*/

int TOF_request_get_imeisv(char* imeisv)
{   
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_Request_get_imeisv : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }
  
  if(ril_request_get_imeisv(imeisv) == RESULT_SUCCESS)
  {
    printf("[TOF]request_get_imeisv success +\r\n");   
  }
  else
  {
    printf("[TOF]request_get_imeisv failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_get_phone_number
===========================================================================*/
int TOF_request_get_phone_number(char* phone_number)
{
  int tof_error = TOF_SUCCESS;
  
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_get_phone_number : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  tof_error = lgit_uim_present();

  if(tof_error != TOF_SUCCESS)
  {
    printf("[TOF]lgit_uim_present fail %d +\r\n",tof_error);   
    return tof_error;
  }
  
  if(ril_request_get_phone_number(phone_number) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_get_phone_number : %s success +\r\n", phone_number);   
  }
  else
  {
    printf("[TOF]TOF_request_get_phone_number failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;  

}

/*===========================================================================
  FUNCTION  TOF_request_get_iccid
===========================================================================*/
int TOF_request_get_iccid(char* iccid)
{
  int tof_error = TOF_SUCCESS;
  
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_get_iccid : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  tof_error = lgit_uim_present();

  if(tof_error != TOF_SUCCESS)
  {
    printf("[TOF]lgit_uim_present fail %d +\r\n",tof_error);   
    return tof_error;
  }
  
  if(ril_request_get_iccid(iccid) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_get_iccid : %s success +\r\n", iccid);   
  }
  else
  {
    printf("[TOF]TOF_request_get_iccid failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;  

}

/*===========================================================================
  FUNCTION  TOF_request_get_exception_count
===========================================================================*/
int TOF_request_get_exception_count(uint8 *count)
{
  uint8 exception_count=0;
  
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_get_exception_count : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(ril_request_get_exception_count(&exception_count) == RESULT_SUCCESS)
  {
    printf("[TOF]ril_request_get_exception_count : success + count=%d\r\n", exception_count);
    *count = exception_count;
  }
  else
  {
    printf("[TOF]ril_request_get_exception_count failed\r\n");
    return TOF_FAIL;
  }

  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_get_exception_info
===========================================================================*/
int TOF_request_get_exception_info(uint8 index, tof_dms_get_exception_info *exception_info)
{
  dms_modem_exception_info_type_v01 excep_info;

  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_get_exception_info : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  memset(&excep_info, 0x0, sizeof(dms_modem_exception_info_type_v01));

  if(ril_request_get_exception_info(index, &excep_info) == RESULT_SUCCESS)
  {
    printf("[TOF]ril_request_get_exception_info : success +\r\n");

    #if 0
      printf("[TOF_request_get_exception_info data] ==============\n");
      printf("%s\n", excep_info.modem_sw_version);
      printf("%s\n", excep_info.exception_date);
      printf("%s\n", excep_info.exception_time);
      printf("%d\n", excep_info.exception_line);
      printf("%s\n", excep_info.exception_file);
      printf("%s\n", excep_info.exception_msg);
      printf("=========================\n");
    #endif

    #if 0
      // shpark, �Ʒ��� ���� memcpy�ϸ� ���� ��´� exception_line �δ� gabage data�� ���Ͽ� ���� ����� �ȵ�. ??
      memcpy(&exception_info->modem_sw_version, &excep_info.modem_sw_version, sizeof(dms_modem_exception_info_type_v01));
    #else
      memcpy(&exception_info->modem_sw_version, &excep_info.modem_sw_version, TOF_DMSI_EXCEPTION_SW_VERSION_LEN);
      memcpy(&exception_info->exception_date, &excep_info.exception_date, TOF_DMSI_EXCEPTION_BUILD_DATE_LEN);
      memcpy(&exception_info->exception_time, &excep_info.exception_time, TOF_DMSI_EXCEPTION_BUILD_TIME_LEN);
      exception_info->exception_line = excep_info.exception_line;
      memcpy(&exception_info->exception_file, &excep_info.exception_file, TOF_DMSI_EXCEPTION_SW_VERSION_LEN);
      memcpy(&exception_info->exception_msg, &excep_info.exception_msg, TOF_DMSI_EXCEPTION_MESSAGE_LEN);
    #endif
  }
  else
  {
    printf("[TOF]ril_request_get_exception_info failed\r\n");
    return TOF_FAIL;
  }

  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_delete_exception_info
===========================================================================*/
int TOF_request_delete_exception_info(void)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_delete_exception_info : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(ril_request_delete_exception_info() == RESULT_SUCCESS)
  {
    printf("[TOF]ril_request_delete_exception_info : success +\r\n");   
  }
  else
  {
    printf("[TOF]ril_request_delete_exception_info failed\r\n");
    return TOF_FAIL;
  }

  return TOF_SUCCESS;
}

#endif /* TOF_DMS_SUPPORT */

#ifdef TOF_UIM_SUPPORT
/*===========================================================================
  FUNCTION  TOF_request_get_sim_status
===========================================================================*/
int TOF_request_get_sim_status(RIL_CardStatus_v6 *pcard_status)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_get_sim_status : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }
  
  if(ril_request_get_sim_status(pcard_status) == RESULT_SUCCESS)
  {
    memcpy(&tof_card_status, pcard_status, sizeof(tof_card_status));
    tof_card_init = TRUE;
    printf("[TOF]TOF_request_get_sim_status success +\r\n");
  }
  else
  {
    printf("[TOF]TOF_request_get_sim_status failed\r\n");
    return TOF_SIM_FAIL;
  }
 
  return TOF_SUCCESS;  
}

/*===========================================================================
  FUNCTION  TOF_request_get_pin_status
===========================================================================*/
int TOF_request_get_pin_status(RIL_PinStatus *pin_status)
{
  uint8 result;
  Card_PinStatus temp_Pin_Status;
  int tof_error = TOF_SUCCESS;

  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_change_sim_pin : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  tof_error = lgit_uim_present();

  if(tof_error != TOF_SUCCESS)
  {
    printf("[TOF]lgit_uim_present fail %d +\r\n",tof_error);   
    return tof_error;
  }

  memset(&temp_Pin_Status, 0x0, sizeof(Card_PinStatus));
  
  result = request_get_pin_status(&temp_Pin_Status);
  memcpy(pin_status, &temp_Pin_Status, sizeof(Card_PinStatus));

  if(result == RESULT_SUCCESS)
    return TOF_SUCCESS;
  else
    return TOF_PIN_AUTH_FAIL;
}


/*===========================================================================
  FUNCTION  TOF_request_enter_sim_pin
===========================================================================*/
int TOF_request_enter_sim_pin(uint8 pin_id, uint8 *pin_value, uint8 pin_operation)
{
  int app_num= 0;
  uint8 result;
  Card_PinStatus Pin_Status;
  qmi_uim_set_pin_protection_params_type params;
  int tof_error = TOF_SUCCESS;
  
  const char *PIN_STATUS_STRINGS[] = 
  {
   "Pin Not Initialized",
   "Pin Enabled, Not Verified",
   "Pin Enabled, Verified",
   "Pin Disabled",
   "Pin Blocked",
   "Pin Permanently Blocked",
   "Pin Unblocked",
   "Pin Changed"
  };
  
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_enter_sim_pin : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  tof_error = lgit_uim_present();

  if(tof_error != TOF_SUCCESS)
  {
    printf("[TOF]lgit_uim_present fail %d +\r\n",tof_error);   
    return tof_error;
  }
  
  request_get_pin_status(&Pin_Status);
  if(pin_id == 1)
  {
    if(((Pin_Status.pin1_state == RIL_PINSTATE_ENABLED_VERIFIED) && (pin_operation == 1)) ||
      ((Pin_Status.pin1_state == RIL_PINSTATE_DISABLED) && (pin_operation == 0)))
    {
      printf("PIN%d Already %s\n", pin_id, PIN_STATUS_STRINGS[Pin_Status.pin1_state]);
      printf("Change your PIN%d Status\n", pin_id);
      return TOF_SIM_FAIL;
    }
  }
  else
  {
    if(((Pin_Status.pin2_state == RIL_PINSTATE_ENABLED_VERIFIED) && (pin_operation == 1)) ||
      ((Pin_Status.pin2_state == RIL_PINSTATE_DISABLED) && (pin_operation == 0)))
    {
      printf("PIN%d Already %s\n", pin_id, PIN_STATUS_STRINGS[Pin_Status.pin2_state]);
      printf("Change your PIN%d Status\n", pin_id);
      return TOF_SIM_FAIL;
    }
  }
  
  for(app_num = 0; app_num<RIL_CARD_MAX_APPS; app_num++)
  {
    if(tof_card_status.applications[app_num].app_type == RIL_APPTYPE_USIM)
      break;
    else
     continue;
  }
 
  params.pin_data.data_ptr = (unsigned char *)malloc(sizeof(unsigned char *)*strlen(pin_value));
  params.session_info.aid.data_ptr = (unsigned char *)malloc(sizeof(unsigned char *)*strlen(tof_card_status.applications[app_num].aid_ptr));

  memset(params.pin_data.data_ptr, 0x0, sizeof(unsigned char *)*strlen(pin_value));
  memset(params.session_info.aid.data_ptr, 0x0, sizeof(unsigned char *)*strlen(tof_card_status.applications[app_num].aid_ptr));

  //copy session type
  params.session_info.session_type = QMI_UIM_SESSION_TYPE_PRI_GW_PROV;
  //memcpy aid data
  params.session_info.aid.data_len = strlen(tof_card_status.applications[app_num].aid_ptr);
  memcpy(params.session_info.aid.data_ptr, tof_card_status.applications[app_num].aid_ptr, params.session_info.aid.data_len);
  //set pin operation
  params.pin_id = pin_id;
  params.pin_operation = pin_operation;
  //memcpy pin data
  params.pin_data.data_len = strlen(pin_value);
  memcpy(params.pin_data.data_ptr, pin_value, params.pin_data.data_len);

  result = set_pin_protection(&params);
  if(result == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_enter_sim_pin success +\r\n");
  }
  else
  {
    printf("[TOF]TOF_request_enter_sim_pin failed\r\n");
    printf("Check your PIN Code\n"); 
  }

  request_get_pin_status(&Pin_Status);
  if(pin_id == 1)
  {
    printf("PIN%d Status : %s\n", pin_id, PIN_STATUS_STRINGS[Pin_Status.pin1_state]);
    printf("Verify Retries Left: : %d\n", Pin_Status.pin1_num_retries);
    printf("Unblock Retries Left : %d\n", Pin_Status.puk1_num_retries);
  }
  else
  {
    printf("PIN%d Status : %s\n", pin_id, PIN_STATUS_STRINGS[Pin_Status.pin2_state]);
    printf("Verify Retries Left: : %d\n", Pin_Status.pin2_num_retries);
    printf("Unblock Retries Left : %d\n", Pin_Status.puk2_num_retries);
  }

  free(params.session_info.aid.data_ptr);
  free(params.pin_data.data_ptr);

  if(result == RESULT_SUCCESS)
    return TOF_SUCCESS;
  else
    return TOF_PIN_AUTH_FAIL;
  
}

/*===========================================================================
  FUNCTION  TOF_request_enter_sim_pin2
===========================================================================*/
int TOF_request_enter_sim_pin2(uint8 pin_id, uint8 *pin_value, uint8 pin_operation)
{
  printf("TOF_request_enter_sim_pin2 \n");
  
  TOF_request_enter_sim_pin(pin_id, pin_value, pin_operation);
}

/*===========================================================================
  FUNCTION  TOF_request_enter_sim_puk
===========================================================================*/
int TOF_request_enter_sim_puk(uint8 pin_id, uint8 *puk_value, uint8 *new_pin_value)
{ 
  int app_num= 0;
  uint8 result;
  Card_PinStatus Pin_Status;
  qmi_uim_unblock_pin_params_type params;
  int tof_error = TOF_SUCCESS;
  
  const char *PIN_STATUS_STRINGS[] = 
  {
   "Pin Not Initialized",
   "Pin Enabled, Not Verified",
   "Pin Enabled, Verified",
   "Pin Disabled",
   "Pin Blocked",
   "Pin Permanently Blocked",
   "Pin Unblocked",
   "Pin Changed"
  }; 
  
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_enter_sim_puk : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  tof_error = lgit_uim_present();

  if(tof_error != TOF_SUCCESS)
  {
    printf("[TOF]lgit_uim_present fail %d +\r\n",tof_error);   
    return tof_error;
  }
  
  for(app_num = 0; app_num<RIL_CARD_MAX_APPS; app_num++)
  {
    if(tof_card_status.applications[app_num].app_type == RIL_APPTYPE_USIM)
      break;
    else
     continue;
  }

  params.puk_data.data_ptr = (unsigned char *)malloc(sizeof(unsigned char *)*strlen(puk_value));
  params.new_pin_data.data_ptr = (unsigned char *)malloc(sizeof(unsigned char *)*strlen(new_pin_value));
  params.session_info.aid.data_ptr = (unsigned char *)malloc(sizeof(unsigned char *)*strlen(tof_card_status.applications[app_num].aid_ptr));

  memset(params.puk_data.data_ptr, 0x0, sizeof(unsigned char *)*strlen(puk_value));
  memset(params.new_pin_data.data_ptr, 0x0, sizeof(unsigned char *)*strlen(new_pin_value));
  memset(params.session_info.aid.data_ptr, 0x0, sizeof(unsigned char *)*strlen(tof_card_status.applications[app_num].aid_ptr));

  //copy session type
  params.session_info.session_type = QMI_UIM_SESSION_TYPE_PRI_GW_PROV;
  //memcpy aid data
  params.session_info.aid.data_len = strlen(tof_card_status.applications[app_num].aid_ptr);
  memcpy(params.session_info.aid.data_ptr, tof_card_status.applications[app_num].aid_ptr, params.session_info.aid.data_len);
  //set pin id
  params.pin_id = pin_id;
  //memcpy puk data
  params.puk_data.data_len = strlen(puk_value);
  memcpy(params.puk_data.data_ptr, puk_value, params.puk_data.data_len);
  //memcpy new pin data
  params.new_pin_data.data_len = strlen(new_pin_value);
  memcpy(params.new_pin_data.data_ptr, new_pin_value, params.new_pin_data.data_len);

  result = unbloock_pin(&params);
  if(result== RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_enter_puk success +\r\n");
  }
  else
  {
    printf("[TOF]TOF_request_enter_puk failed\r\n");
    printf("Check your PUK Code\n");
  }
  
  request_get_pin_status(&Pin_Status);
  if(pin_id == 1)
  {
    printf("PIN%d Status : %s\n", pin_id, PIN_STATUS_STRINGS[Pin_Status.pin1_state]);
    printf("Verify Retries Left: : %d\n", Pin_Status.pin1_num_retries);
    printf("Unblock Retries Left : %d\n", Pin_Status.puk1_num_retries);
  }
  else
  {
    printf("PIN%d Status : %s\n", pin_id, PIN_STATUS_STRINGS[Pin_Status.pin2_state]);
    printf("Verify Retries Left: : %d\n", Pin_Status.pin2_num_retries);
    printf("Unblock Retries Left : %d\n", Pin_Status.puk2_num_retries);
  }

  free(params.session_info.aid.data_ptr);
  free(params.puk_data.data_ptr);
  free(params.new_pin_data.data_ptr);

  if(result == RESULT_SUCCESS)
    return TOF_SUCCESS;
  else
    return TOF_PIN_AUTH_FAIL;
  
}

/*===========================================================================
  FUNCTION  TOF_request_enter_sim_puk2
===========================================================================*/
int TOF_request_enter_sim_puk2(uint8 pin_id, uint8 *puk_value, uint8 *new_pin_value)
{ 
  printf("TOF_request_enter_sim_puk2 \n");
  
  TOF_request_enter_sim_puk(pin_id, puk_value, new_pin_value);
}

/*===========================================================================
  FUNCTION  TOF_request_change_sim_pin
===========================================================================*/
int TOF_request_change_sim_pin(uint8 pin_id, uint8 *old_pin_value, uint8 *new_pin_value)
{
  int app_num= 0;
  uint8 result;
  Card_PinStatus Pin_Status;
  qmi_uim_change_pin_params_type params;
  int tof_error = TOF_SUCCESS;
  
  const char *PIN_STATUS_STRINGS[] = 
  {
   "Pin Not Initialized",
   "Pin Enabled, Not Verified",
   "Pin Enabled, Verified",
   "Pin Disabled",
   "Pin Blocked",
   "Pin Permanently Blocked",
   "Pin Unblocked",
   "Pin Changed"
  }; 

  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_change_sim_pin : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  tof_error = lgit_uim_present();

  if(tof_error != TOF_SUCCESS)
  {
    printf("[TOF]lgit_uim_present fail %d +\r\n",tof_error);   
    return tof_error;
  }
  
  request_get_pin_status(&Pin_Status);
  if(pin_id == 1)
  {
    if(Pin_Status.pin1_state == RIL_PINSTATE_DISABLED)
    {
      printf("PIN%d Status : Pin Disabled\n", pin_id);
      printf("Change your PIN%d Status\n", pin_id);
      return TOF_SIM_FAIL;
    }  
  }
  else
  {
    if(Pin_Status.pin2_state == RIL_PINSTATE_DISABLED)
    {
      printf("PIN%d Status : Pin Disabled\n", pin_id);
      printf("Change your PIN%d Status\n", pin_id);
      return TOF_SIM_FAIL;
    }  
  }    

  for(app_num = 0; app_num<RIL_CARD_MAX_APPS; app_num++)
  {
    if(tof_card_status.applications[app_num].app_type == RIL_APPTYPE_USIM)
      break;
    else
     continue;
  }

  params.old_pin_data.data_ptr = (unsigned char *)malloc(sizeof(unsigned char *)*strlen(old_pin_value));
  params.new_pin_data.data_ptr = (unsigned char *)malloc(sizeof(unsigned char *)*strlen(new_pin_value));
  params.session_info.aid.data_ptr = (unsigned char *)malloc(sizeof(unsigned char *)*strlen(tof_card_status.applications[app_num].aid_ptr));

  memset(params.old_pin_data.data_ptr, 0x0, sizeof(unsigned char *)*strlen(old_pin_value));
  memset(params.new_pin_data.data_ptr, 0x0, sizeof(unsigned char *)*strlen(new_pin_value));
  memset(params.session_info.aid.data_ptr, 0x0, sizeof(unsigned char *)*strlen(tof_card_status.applications[app_num].aid_ptr));

  //copy session type
  params.session_info.session_type = QMI_UIM_SESSION_TYPE_PRI_GW_PROV;
  //memcpy aid data
  params.session_info.aid.data_len = strlen(tof_card_status.applications[app_num].aid_ptr);
  memcpy(params.session_info.aid.data_ptr, tof_card_status.applications[app_num].aid_ptr, params.session_info.aid.data_len);
  //set pin id
  params.pin_id = pin_id;
  //memcpy old pin data
  params.old_pin_data.data_len = strlen(old_pin_value);
  memcpy(params.old_pin_data.data_ptr, old_pin_value, params.old_pin_data.data_len);
  //memcpy new pin data
  params.new_pin_data.data_len = strlen(new_pin_value);
  memcpy(params.new_pin_data.data_ptr, new_pin_value, params.new_pin_data.data_len);

  result = change_pin(&params);
  if(result == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_change_sim_pin success +\r\n");
    printf("PIN%d Status : PIN Changed\n", pin_id);
  }
  else
  {
    printf("[TOF]TOF_request_change_sim_pin failed\r\n");
    printf("Check your old PIN Code\n");
  }

  request_get_pin_status(&Pin_Status);
  if(pin_id == 1)
  {
    printf("PIN%d Status : %s\n", pin_id, PIN_STATUS_STRINGS[Pin_Status.pin1_state]);
    printf("Verify Retries Left: : %d\n", Pin_Status.pin1_num_retries);
    printf("Unblock Retries Left : %d\n", Pin_Status.puk1_num_retries);
  }
  else
  {
    printf("PIN%d Status : %s\n", pin_id, PIN_STATUS_STRINGS[Pin_Status.pin2_state]);
    printf("Verify Retries Left: : %d\n", Pin_Status.pin2_num_retries);
    printf("Unblock Retries Left : %d\n", Pin_Status.puk2_num_retries);
  }

  free(params.session_info.aid.data_ptr);
  free(params.old_pin_data.data_ptr);
  free(params.new_pin_data.data_ptr);

  if(result == RESULT_SUCCESS)
    return TOF_SUCCESS;
  else
    return TOF_PIN_AUTH_FAIL;

}

/*===========================================================================
  FUNCTION  TOF_request_change_sim_pin2
===========================================================================*/
int TOF_request_change_sim_pin2(uint8 pin_id, uint8 *old_pin_value, uint8 *new_pin_value)
  {
  printf("TOF_request_change_sim_pin2 \n");
    
  TOF_request_change_sim_pin(pin_id, old_pin_value, new_pin_value);
}

//For Bosch JAVA
/*===========================================================================
  FUNCTION  TOF_unlock_sim
===========================================================================*/
int TOF_unlock_sim(char *pin)
{
  int app_num= 0;
  uint8 result;
  Card_PinStatus Pin_Status;
  qmi_uim_verify_pin_params_type params;
  int tof_error = TOF_SUCCESS;
  
  const char *PIN_STATUS_STRINGS[] = 
  {
   "Pin Not Initialized",
   "Pin Enabled, Not Verified",
   "Pin Enabled, Verified",
   "Pin Disabled",
   "Pin Blocked",
   "Pin Permanently Blocked",
   "Pin Unblocked",
   "Pin Changed"
  };

  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_unlock_sim : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  tof_error = lgit_uim_present();

  if(tof_error != TOF_SUCCESS)
  {
    printf("[TOF]lgit_uim_present fail %d +\r\n",tof_error);   
    return tof_error;
  }
      
  if(tof_card_status.applications[0].pin1 == RIL_PINSTATE_DISABLED)
  {
    printf("PIN1 Already %s\n", PIN_STATUS_STRINGS[tof_card_status.applications[0].pin1]);
    printf("Change your PIN1 Status\n");
    return TOF_SIM_FAIL;
  }

  for(app_num = 0; app_num<RIL_CARD_MAX_APPS; app_num++)
  {
    if(tof_card_status.applications[app_num].app_type == RIL_APPTYPE_USIM)
      break;
    else
     continue;
  }
 
  params.pin_data.data_ptr = (unsigned char *)malloc(sizeof(unsigned char *)*strlen(pin));
  params.session_info.aid.data_ptr = (unsigned char *)malloc(sizeof(unsigned char *)*strlen(tof_card_status.applications[app_num].aid_ptr));

  memset(params.pin_data.data_ptr, 0x0, sizeof(unsigned char *)*strlen(pin));
  memset(params.session_info.aid.data_ptr, 0x0, sizeof(unsigned char *)*strlen(tof_card_status.applications[app_num].aid_ptr));

  //copy session type
  params.session_info.session_type = QMI_UIM_SESSION_TYPE_PRI_GW_PROV;
  //memcpy aid data
  params.session_info.aid.data_len = strlen(tof_card_status.applications[app_num].aid_ptr);
  memcpy(params.session_info.aid.data_ptr, tof_card_status.applications[app_num].aid_ptr, params.session_info.aid.data_len);
  
  //set pin operation
  params.pin_id = QMI_UIM_PIN_ID_PIN1;
  //memcpy pin data
  params.pin_data.data_len = strlen(pin);
  memcpy(params.pin_data.data_ptr, pin, params.pin_data.data_len);

  params.is_pin1_encrypted = QMI_UIM_FALSE;

  result = verify_pin(&params);
  if(result == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_unlock_sim success +\r\n");
  }
  else
  {
    printf("[TOF]TOF_unlock_sim failed\r\n");
    printf("Check your PIN Code\n"); 
  }

  free(params.session_info.aid.data_ptr);
  free(params.pin_data.data_ptr);

  if(result == RESULT_SUCCESS)
    return TOF_SUCCESS;
  else
    return TOF_PIN_AUTH_FAIL;
  
}

/*===========================================================================
  FUNCTION  TOF_is_locked
===========================================================================*/
int TOF_is_locked(boolean *lock)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_is_locked : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }
  
  //Init tof_card_status for PIN operation
  if(!tof_card_init)
  {
    if(ril_request_get_sim_status(&tof_card_status) == RESULT_SUCCESS)
    {
      tof_card_init = TRUE;
      printf("[TOF]TOF_request_get_sim_status success +\r\n");
    }
    else
      return TOF_SIM_FAIL;
  }
  else //update tof_card_status
    ril_request_get_sim_status(&tof_card_status);

  if((tof_card_status.card_state == RIL_CARDSTATE_ABSENT)
    ||(tof_card_status.card_state == RIL_CARDSTATE_ERROR))
  {
    printf("[TOF]card_state ABSENT or ERROR --> %d\n",tof_card_status.card_state);
    *lock = FALSE;
    return TOF_NO_SIM_FAIL;
  }
  
  if((tof_card_status.applications[0].pin1 == RIL_PINSTATE_DISABLED)||
    (tof_card_status.applications[0].pin1 == RIL_PINSTATE_ENABLED_VERIFIED))
  {
    printf("PIN1 DISABLED\n");
    *lock = FALSE;
    
    return TOF_SUCCESS;
  }
  else
  {
    printf("PIN1 ENABLED\n");
    *lock = TRUE;
    
    return TOF_SUCCESS;
  }
}

/*===========================================================================
  FUNCTION  TOF_is_enabled
===========================================================================*/
int TOF_is_enabled(boolean *enabled)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_is_enabled : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }
  
  //Init tof_card_status for PIN operation
  if(!tof_card_init)
  {
    if(ril_request_get_sim_status(&tof_card_status) == RESULT_SUCCESS)
    {
      tof_card_init = TRUE;
      printf("[TOF]TOF_request_get_sim_status success +\r\n");
    }
    else
      return TOF_SIM_FAIL;
  }
  else //update tof_card_status
    ril_request_get_sim_status(&tof_card_status);

  if((tof_card_status.card_state == RIL_CARDSTATE_ABSENT)
    ||(tof_card_status.card_state == RIL_CARDSTATE_ERROR))
  {
    printf("[TOF]card_state ABSENT or ERROR --> %d\n",tof_card_status.card_state);
    *enabled = FALSE;
    return TOF_NO_SIM_FAIL;
  }
  
  if(tof_card_status.applications[0].pin1 == RIL_PINSTATE_DISABLED)
  {
    printf("PIN1 UNLOCKED\n");
    *enabled = FALSE;
    
    return TOF_SUCCESS;
  }
  else
  {
    printf("PIN1 LOCKED\n");
    *enabled = TRUE;
    
    return TOF_SUCCESS;
  }
}

/*===========================================================================
  FUNCTION  TOF_GetSubscriberId
===========================================================================*/
int TOF_GetSubscriberId(uint8 *subsid)
{
  char imsi[9] = {0,};
  
  int tof_error = TOF_SUCCESS;
  
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_GetSubscriberId : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  tof_error = lgit_uim_present();

  if(tof_error != TOF_SUCCESS)
  {
    printf("[TOF]lgit_uim_present fail %d +\r\n",tof_error);   
    return tof_error;
  }
  
  if(ril_request_get_imsi_hex(imsi) == RESULT_SUCCESS) 
  { 
    printf("[TOF]ril_request_get_imsi_hex success \n");    
    memcpy(subsid, imsi, 9);
    
    printf("%02X %02X %02X %02X %02X %02X %02X %02X %02X \n", 
      subsid[0], subsid[1], subsid[2], subsid[3], subsid[4], subsid[5],
      subsid[6], subsid[7], subsid[8]);
  }
  else
  {
    printf("[TOF]ril_request_get_imsi_hex failed\r\n");   
    return TOF_FAIL;
  }
  
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_GetICCIdentification
===========================================================================*/
int TOF_GetICCIdentification(uint8 *iccid)
{
  char temp[10] = {0,};
  int tof_error = TOF_SUCCESS;
    
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_GetICCIdentification : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  tof_error = lgit_uim_present();
  
  if(tof_error != TOF_SUCCESS)
  {
    printf("[TOF]lgit_uim_present fail %d +\r\n",tof_error);   
    return tof_error;
  }
  
  if(ril_request_get_iccid_hex(temp) == RESULT_SUCCESS) 
  { 
    printf("[TOF]ril_request_get_iccid_hex success \n");    
    memcpy(iccid, temp, 10);
    
    printf("%02X %02X %02X %02X %02X %02X %02X %02X %02X %02X\n", 
      iccid[0], iccid[1], iccid[2], iccid[3], iccid[4], iccid[5],
      iccid[6], iccid[7], iccid[8], iccid[9]);
  }
  else
  {
    printf("[TOF]ril_request_get_iccid_hex failed\r\n");   
    return TOF_SIM_FAIL;
  }
  
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_IsPresent
===========================================================================*/
boolean TOF_IsPresent(void)
{
  char temp[10] = {0,};
    
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_IsPresent : Unable to acquire qmi handle \n");
    return FALSE;
  }

  //Init tof_card_status for PIN operation
  if(!tof_card_init)
  {
    if(ril_request_get_sim_status(&tof_card_status) == RESULT_SUCCESS)
    {
      tof_card_init = TRUE;
      printf("[TOF]TOF_request_get_sim_status success +\r\n");
    }
    else
      return FALSE;
  }

  if((tof_card_status.card_state == RIL_CARDSTATE_ABSENT)
    ||(tof_card_status.card_state == RIL_CARDSTATE_ERROR))
  {
    printf("[TOF]card_state ABSENT or ERROR --> %d\n",tof_card_status.card_state);
    
    return FALSE;
  }
  else
    return TRUE;
}

/*===========================================================================
  FUNCTION  TOF_ReadFPLMN
===========================================================================*/
int TOF_ReadFPLMN(uint8 *fplmn)
{
  char temp[10] = {0,};
  int tof_error = TOF_SUCCESS;
    
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_ReadFPLMN : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  tof_error = lgit_uim_present();
  
  if(tof_error != TOF_SUCCESS)
  {
    printf("[TOF]lgit_uim_present fail %d +\r\n",tof_error);   
    return tof_error;
  }
  
  if(ril_request_get_fplmn_hex(temp) == RESULT_SUCCESS) 
  { 
    printf("[TOF]ril_request_get_iccid_hex success \n");    
    memcpy(fplmn, temp, 12);
    
    printf("%02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X\n", 
      fplmn[0], fplmn[1], fplmn[2], fplmn[3], fplmn[4], fplmn[5],
      fplmn[6], fplmn[7], fplmn[8], fplmn[9], fplmn[10], fplmn[11]);
  }
  else
  {
    printf("[TOF]ril_request_get_iccid_hex failed\r\n");   
    return TOF_FAIL;
  }
  
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_WriteFPLMN
===========================================================================*/
int TOF_WriteFPLMN(uint8 *fplmn)
{
  int tof_error = TOF_SUCCESS;
    
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_WriteFPLMN : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  tof_error = lgit_uim_present();
  
  if(tof_error != TOF_SUCCESS)
  {
    printf("[TOF]lgit_uim_present fail %d +\r\n",tof_error);   
    return tof_error;
  }
  
  if(ril_request_set_fplmn_hex(fplmn) == RESULT_SUCCESS) 
  { 
    printf("[TOF]ril_request_get_iccid_hex success \n");    
  }
  else
  {
    printf("[TOF]ril_request_get_iccid_hex failed\r\n");   
    return TOF_FAIL;
  }
  
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_setFieldsChangedEvent
===========================================================================*/
int TOF_setFieldsChangedEvent(void)
{
  int tof_error = TOF_SUCCESS;
    
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_setFieldsChangedEvent : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  tof_error = lgit_uim_present();
  
  if(tof_error != TOF_SUCCESS)
  {
    printf("[TOF]lgit_uim_present fail %d +\r\n",tof_error);   
    return tof_error;
  }

  if(ril_request_register_refresh_all(tof_card_status.applications[0].aid_ptr) == RESULT_SUCCESS) 
  { 
    printf("[TOF]ril_request_register_refresh_all success \n");    
  }
  else
  {
    printf("[TOF]ril_request_register_refresh_all failed\r\n");   
    return TOF_FAIL;
  }

  return TOF_SUCCESS;
}

#endif /* TOF_UIM_SUPPORT */

#ifdef TOF_NAS_SUPPORT
//chad_20160304 --->
/* TOF_REQUEST_DATA_REGISTRATION_STATE */
int TOF_request_data_registration_state(tof_registration_status_type *t_data_regi_status)
{
//  char *responseStr[NAS_REG_STATE_RESP_MAX_ARR_SIZE];
  boolean is_vzw_lte = FALSE;
  int rsp_count=0;
  qmi_nas_registration_state_resp_helper_type ril_resp_helper;
  
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_get_basebandversion : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  } 

  if ((wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ) || ( wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ))
  {
    is_vzw_lte = TRUE;
    memset(&ril_resp_helper, 0x0, sizeof(qmi_nas_registration_state_resp_helper_type));
  }

  if( is_vzw_lte )
  {
    if (ril_request_vzw_get_registration_status(REQ_DATA_REGI_STATE_FROM_CACHE, &ril_resp_helper) == RESULT_SUCCESS)
    {
      t_data_regi_status->reg_status = (int)atoi(ril_resp_helper.registration_state);
      t_data_regi_status->lac = (int)atoi(ril_resp_helper.lac);
      t_data_regi_status->cell_id = (int)atoi(ril_resp_helper.cid);
      t_data_regi_status->rat = (int)atoi(ril_resp_helper.radio_tech);
      t_data_regi_status->reject_cause = (int)atoi(ril_resp_helper.reg_reject_cause);
    }
    else
    {
      MSG_LOW("ril_request_vzw_get_registration_status : Failed to operate a Function!! \n",0,0,0);
    }
  }
  else
  {
    if (ril_request_get_registration_status(REQ_DATA_REGI_STATE_FROM_CACHE, t_data_regi_status) == RESULT_SUCCESS)
    {
      MSG_LOW_4("Reg_Status =%d, lac =%x, Cell_id =%x, RAT =%d \n",
                    t_data_regi_status->reg_status,t_data_regi_status->lac,t_data_regi_status->cell_id,
                    t_data_regi_status->rat);
      MSG_LOW("ril_request_get_registration_status() Success!! \n",0,0,0);
    }
    else
    {
      MSG_LOW("ril_request_get_registration_status() Failed t_data_regi_status =%s \n",t_data_regi_status,0,0);
      return TOF_HANDLE_FAIL;
    }

  }

  return TOF_SUCCESS;
}

/* TOF_REQUEST_VOICE_REGISTRATION_STATE */
int TOF_request_voice_registration_state(tof_registration_status_type *t_voice_regi_status)
{
//  char *responseStr[NAS_REG_STATE_RESP_MAX_ARR_SIZE];
  boolean is_vzw_lte = FALSE;
  int rsp_count=0;
  qmi_nas_registration_state_resp_helper_type ril_resp_helper;
  
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_get_basebandversion : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  } 

  if ((wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ) || ( wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ))
  {
    is_vzw_lte = TRUE;
    memset(&ril_resp_helper, 0x0, sizeof(qmi_nas_registration_state_resp_helper_type));
  }

  if( is_vzw_lte )
  {
    if (ril_request_vzw_get_registration_status(REQ_REGI_STATE_FROM_CACHE, &ril_resp_helper) == RESULT_SUCCESS)
    {
      t_voice_regi_status->reg_status = (int)atoi(ril_resp_helper.registration_state);
      t_voice_regi_status->lac = (int)atoi(ril_resp_helper.lac);
      t_voice_regi_status->cell_id = (int)atoi(ril_resp_helper.cid);
      t_voice_regi_status->rat = (int)atoi(ril_resp_helper.radio_tech);
      t_voice_regi_status->reject_cause = (int)atoi(ril_resp_helper.reg_reject_cause);
    }
    else
    {
      MSG_LOW("ril_request_vzw_get_registration_status : Failed to operate a Function!! \n",0,0,0);
    }
  }
  else
  {
    if (ril_request_get_registration_status(REQ_REGI_STATE_FROM_CACHE, t_voice_regi_status) == RESULT_SUCCESS)
    {
      MSG_LOW_4("Reg_Status =%d, lac =%x, Cell_id =%x, RAT =%d \n",
                    t_voice_regi_status->reg_status,t_voice_regi_status->lac,t_voice_regi_status->cell_id,
                    t_voice_regi_status->rat);
      MSG_LOW("ril_request_get_registration_status() Success!! \n",0,0,0);
    }
    else
    {
      MSG_LOW("ril_request_get_registration_status() Failed t_voice_regi_status =%s \n",t_voice_regi_status,0,0);
      return TOF_HANDLE_FAIL;
    }

  }

  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_signal_strength
===========================================================================*/
int TOF_request_signal_strength(TOF_SignalStrength* tof_signal_strength)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_get_sim_status : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }
  
  if(ril_request_get_sig_info(tof_signal_strength) != RESULT_SUCCESS)
  {
    MSG_LOW("ril_request_get_sig_info : Failed to operate a Function!! \n",0,0,0);
    return TOF_FAIL;
  }
  return TOF_SUCCESS;
}
//chad_20160304 <---

/*======================================================================

FUNCTION TOF_request_set_pref_network
 
DESCRIPTION
  
======================================================================*/

int TOF_request_set_pref_network(uint16 tof_mode_pref)
{   
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_get_pref_network : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if((wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ) || ( wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ))
  {  
    if(ril_request_set_preferred_network_type(tof_mode_pref) == RESULT_SUCCESS)
    {
      printf("[TOF]TOF_REQUEST_SET_PREFERRED_NETWORK_TYPE success +\r\n");   
    }
    else
    {
      printf("[TOF]TOF_REQUEST_SET_PREFERRED_NETWORK_TYPE failed\r\n");
      return TOF_FAIL;
    }
  }
  else
  {
    if(ril_request_set_pref_network(tof_mode_pref) == RESULT_SUCCESS)
    {
      printf("[TOF]TOF_REQUEST_SET_PREFERRED_NETWORK_TYPE success +\r\n");   
    }
    else
    {
      printf("[TOF]TOF_REQUEST_SET_PREFERRED_NETWORK_TYPE failed\r\n");
      return TOF_FAIL;
    }
  }
 
  return TOF_SUCCESS;
}


/*======================================================================

FUNCTION TOF_request_get_pref_network
 
DESCRIPTION
  
======================================================================*/

int TOF_request_get_pref_network(uint16 *tof_mode_pref)
{   
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_get_pref_network : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if((wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ) || ( wmm_get_vendor_type() == WMM_VENDOR_I_LTE_VZW ))
  {
    if(ril_request_get_preferred_network_type(tof_mode_pref) == RESULT_SUCCESS)
    {
      printf("[TOF][VZW]TOF_REQUEST_GET_PREFERRED_NETWORK_TYPE success +\r\n");   
    }
    else
    {
      printf("[TOF][VZW]TOF_REQUEST_GET_PREFERRED_NETWORK_TYPE failed\r\n");
      return TOF_FAIL;
    }
  }
  else
  {
    if(ril_request_get_pref_network(tof_mode_pref) == RESULT_SUCCESS)
    {
      printf("[TOF]TOF_REQUEST_GET_PREFERRED_NETWORK_TYPE success +\r\n");   
    }
    else
    {
      printf("[TOF]TOF_REQUEST_GET_PREFERRED_NETWORK_TYPE failed\r\n");
      return TOF_FAIL;
    }
  }
 
  return TOF_SUCCESS;
}

/*======================================================================

FUNCTION TOF_request_set_pref_mode
 
DESCRIPTION
  
======================================================================*/

int TOF_request_set_pref_mode(uint16 tof_mode_pref, uint64 tof_mode_band_pref )
{   
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_set_pref_mode : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(ril_request_set_pref_mode(tof_mode_pref,tof_mode_band_pref) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_REQUEST_SET_PREFERRED_MODE_TYPE success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_REQUEST_SET_PREFERRED_MODE_TYPE failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}


/*======================================================================

FUNCTION TOF_request_get_pref_mode
 
DESCRIPTION
  
======================================================================*/

int TOF_request_get_pref_mode(uint16 *tof_mode_pref, uint64 *tof_mode_band_pref)
{   
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_get_pref_mode : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(ril_request_get_pref_mode(tof_mode_pref, tof_mode_band_pref) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_REQUEST_GET_PREFERRED_MODE_TYPE success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_REQUEST_GET_PREFERRED_MODE_TYPE failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}


/*======================================================================

FUNCTION TOF_request_set_service_domain
 
DESCRIPTION
  
======================================================================*/

int TOF_request_set_service_domain(uint16 tof_service_domain)
{   
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_set_service_doamin : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_set_service_doamin(tof_service_domain) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_REQUEST_SET_SERVICE_DOMAIN success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_REQUEST_SET_SERVICE_DOMAIN failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}


/*======================================================================

FUNCTION TOF_request_get_service_domain
 
DESCRIPTION
  
======================================================================*/

int TOF_request_get_service_domain(uint16 *tof_service_domain)
{   
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_get_service_doamin : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_get_service_domain(tof_service_domain) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_REQUEST_GET_SERVICE_DOMAIN success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_REQUEST_GET_SERVICE_DOMAIN failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}


/*======================================================================

FUNCTION TOF_request_set_wcdma_rrc_version
 
DESCRIPTION
  
======================================================================*/

int TOF_request_set_wcdma_rrc_version(uint16 tof_rrc_version)
{   
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_set_wcdma_rrc_version : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_set_wcdma_rrc_version(tof_rrc_version) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_REQUEST_SET_WCDMA_RRC_VERSION success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_REQUEST_SET_WCDMA_RRC_VERSION failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}


/*======================================================================

FUNCTION TOF_request_get_wcdma_rrc_version
 
DESCRIPTION
  
======================================================================*/

int TOF_request_get_wcdma_rrc_version(uint16 *tof_rrc_version)
{   
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_get_wcdma_rrc_version : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_get_wcdma_rrc_version(tof_rrc_version) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_REQUEST_GET_SERVICE_DOMAIN success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_REQUEST_GET_SERVICE_DOMAIN failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}


/*======================================================================

FUNCTION TOF_request_set_wcdma_sms_mo_domain
 
DESCRIPTION
  
======================================================================*/

int TOF_request_set_wcdma_sms_mo_domain(byte tof_mo_domain)
{   
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_set_wcdma_sms_mo_domain : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_set_wcdma_sms_mo_domain(tof_mo_domain) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_REQUEST_SET_WCDMA_SMS_MO_DOMAIN success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_REQUEST_SET_WCDMA_SMS_MO_DOMAIN failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}


/*======================================================================

FUNCTION TOF_request_get_wcdma_sms_domain
 
DESCRIPTION
  
======================================================================*/

int TOF_request_get_wcdma_sms_mo_domain(byte *tof_mo_domain)
{   
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_get_wcdma_sms_mo_domain : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_get_wcdma_sms_mo_domain(tof_mo_domain) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_REQUEST_GET_WCDMA_SMS_MO_DOMAIN success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_REQUEST_GET_WCDMA_SMS_MO_DOMAIN failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}


/*======================================================================

FUNCTION TOF_request_set_isr_enable
 
DESCRIPTION
  
======================================================================*/

int TOF_request_set_isr_enable(boolean tof_isr_enable)
{   
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_set_isr_enable : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_set_isr_enable(tof_isr_enable) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_REQUEST_SET_ISR_ENABLE success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_REQUEST_SET_ISR_ENABLE failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}


/*======================================================================

FUNCTION TOF_request_get_isr_enable
 
DESCRIPTION
  
======================================================================*/

int TOF_request_get_isr_enable(boolean *tof_isr_enable)
{   
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_get_isr_enable : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_get_isr_enable(tof_isr_enable) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_get_isr_enable success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_get_isr_enable failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*======================================================================
  
FUNCTION TOF_request_delete_stored_cell
   
DESCRIPTION
    
======================================================================*/
  
int TOF_request_delete_stored_cell()
{   
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_delete_stored_cell : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }
  
  if(request_delete_stored_cell() == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_delete_stored_cell success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_delete_stored_cell failed\r\n");
    return TOF_FAIL;
  }
   
  return TOF_SUCCESS;
}

/*======================================================================
  
FUNCTION TOF_request_get_network_selection_mode
   
DESCRIPTION
    
======================================================================*/
  
int TOF_request_get_network_selection_mode(uint8* net_sel_mode)
{   
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_get_network_selection_mode : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }
  
  if(request_get_network_selection_mode(net_sel_mode) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_get_network_selection_mode success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_get_network_selection_mode failed\r\n");
    return TOF_FAIL;
  }
   
  return TOF_SUCCESS;
}

/*======================================================================
  
FUNCTION TOF_request_set_network_selection_auto
   
DESCRIPTION
    
======================================================================*/
  
int TOF_request_set_network_selection_auto()
{   
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_set_network_selection_auto : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }
  
  if(request_set_auto_mode() == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_set_network_selection_auto success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_set_network_selection_auto failed\r\n");
    return TOF_FAIL;
  }
   
  return TOF_SUCCESS;
}

/*======================================================================
  
FUNCTION TOF_request_get_operator
   
DESCRIPTION
    
======================================================================*/
  
int TOF_request_get_operator(TOF_Operator_Info *Tof_Operator)
{   
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_get_operator : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }
  
  memset(Tof_Operator, 0x0, sizeof(TOF_Operator_Info));
  
  if(request_get_operator_status(Tof_Operator) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_get_operator success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_get_operator failed\r\n");
    return TOF_FAIL;
  }
   
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_set_ims_auth_scheme
===========================================================================*/
int TOF_request_set_ims_auth_scheme(uint8 auth_scheme)
{
  if(ril_request_set_ims_sip_extended_config(auth_scheme) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_set_ims_auth_scheme : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  printf("[TOF]TOF_request_set_ims_auth_scheme() auth_scheme =%d\n",auth_scheme);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_get_ims_auth_scheme
===========================================================================*/
int TOF_request_get_ims_auth_scheme(uint8 *auth_scheme)
{
  uint8 ims_auth =0;

  if(ril_request_get_ims_sip_extended_config(&ims_auth) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_get_ims_auth_scheme : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  *auth_scheme = ims_auth;
  printf("[TOF]TOF_request_get_ims_auth_scheme() auth_scheme =%d, ims_auth =%d\n",*auth_scheme,ims_auth);

  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_set_ims_dpl_param_src
===========================================================================*/
int TOF_request_set_ims_dpl_param_src(uint8 ims_param_src)
{
  RIL_Ims_Dpl_Param ims_dpl_param;  

  memset(&ims_dpl_param, 0x0, sizeof(RIL_Ims_Dpl_Param));
  ims_dpl_param.IMSParamSrc = ims_param_src;
  if(ril_request_set_ims_dpl_param(REQUEST_PARAM_SRC, ims_dpl_param) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_set_ims_dpl_param_src : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  printf("[TOF]TOF_request_set_ims_dpl_param_src() IMSParamSrc =%d\n",ims_dpl_param.IMSParamSrc);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_get_ims_dpl_param_src
===========================================================================*/
int TOF_request_get_ims_dpl_param_src(uint8 *ims_param_src)
{
  RIL_Ims_Dpl_Param ims_dpl_param;  

  memset(&ims_dpl_param, 0x0, sizeof(RIL_Ims_Dpl_Param));

  if(ril_request_get_ims_dpl_param(REQUEST_PARAM_SRC, &ims_dpl_param) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_get_ims_dpl_param_src : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  *ims_param_src = ims_dpl_param.IMSParamSrc;
  printf("[TOF]TOF_request_get_ims_dpl_param_src() ims_param_src =%d, IMSParamSrc =%d\n",*ims_param_src,ims_dpl_param.IMSParamSrc);

  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_set_reg_event
===========================================================================*/
int TOF_request_set_reg_event(uint8 ims_reg_event_en)
{
  RIL_Ims_Reg_Config ims_reg_config;

  memset(&ims_reg_config, 0x0, sizeof(RIL_Ims_Reg_Config));
  ims_reg_config.reg_event_packet = ims_reg_event_en;

  if(ril_request_set_ims_reg_config(REQUEST_REG_EVENT, ims_reg_config) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_set_reg_event : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  printf("[TOF]TOF_request_set_reg_event() reg_event_packet =%d\n",ims_reg_config.reg_event_packet);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_get_reg_event
===========================================================================*/
int TOF_request_get_reg_event(uint8 *ims_reg_event_en)
{
  RIL_Ims_Reg_Config ims_reg_config;

  memset(&ims_reg_config, 0x0, sizeof(RIL_Ims_Reg_Config));

  if(ril_request_get_ims_reg_config(REQUEST_REG_EVENT, &ims_reg_config) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_get_reg_event : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  *ims_reg_event_en = ims_reg_config.reg_event_packet;
  printf("[TOF]TOF_request_get_reg_event() ims_reg_event_en =%d, reg_event_packet =%d\n",*ims_reg_event_en,ims_reg_config.reg_event_packet);

  return TOF_SUCCESS;
}

#endif /* TOF_NAS_SUPPORT */



#ifdef TOF_VOICE_SUPPORT

/*===========================================================================
  FUNCTION  TOF_request_dial
===========================================================================*/
/*ohsk_20160309 Function Struct Modify*/
int TOF_request_dial(TOF_Dial *dial)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    MSG_ERROR("TOF_requestDial : Unable to acquire qmi handle \n",0,0,0);
    return TOF_HANDLE_FAIL;
  }

  if ( FALSE == request_dial(dial))
  {
    MSG_ERROR("TOF_requestDial : Dial Failed \n",0,0,0);
    return TOF_FAIL;    
  }

  MSG_HIGH("TOF_request_dial : Dial Success \n",0,0,0);
  return TOF_SUCCESS;
}


/*======================================================================

FUNCTION TOF_requestGetCurrentCalls
 
DESCRIPTION
  
======================================================================*/
/*ohsk_20160309 Function Struct Modify*/
int TOF_request_get_current_calls(TOF_Current_Call_Info *TOF_call_info)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    MSG_ERROR("TOF_requestGetCurrentCalls : Unable to acquire qmi handle \n",0,0,0);
    return TOF_HANDLE_FAIL;
  }

  boolean unsol_response_call_state_changed = FALSE;
  voice_get_all_call_info_resp_msg_v02 clone_g_voice_all_call_info;
  int reset_index= 0;

  /*Reset TOF_call_info*/

  memset( &TOF_call_info->call_count, 0, sizeof( int ) );

  for ( reset_index = 0; reset_index < VOICE_CALL_COUNT_MAX; ++reset_index )
  {
    memset( &TOF_call_info->call_info[ reset_index ], 0, sizeof( TOF_Call ) );
  }  

  /*End*/
  
  memcpy( &clone_g_voice_all_call_info, &g_voice_all_call_info, sizeof( clone_g_voice_all_call_info ) );
  
  if ( TRUE == request_get_current_calls() )
  {
    int i, j ,k;  

    TOF_call_info->call_count = g_voice_all_call_info.call_info_len;

    MSG_HIGH( "[VOICE] request_get_current_calls(), current call num:%d", get_voice_call_current_num(), 0, 0 );    //dsji_20141030 add

    for ( i = 0; i < g_voice_all_call_info.call_info_len; ++i )
    {
      memset( &TOF_call_info->call_info[ i ], 0, sizeof( TOF_Call ) );

      // call state
      switch ( g_voice_all_call_info.call_info[ i ].call_state )
      {
        //dsji_20130514 modify {
        case CALL_STATE_ORIGINATING_V02:
          TOF_call_info->call_info[ i ].state = TOF_CALL_DIALING;
          break;

        case CALL_STATE_CC_IN_PROGRESS_V02:
        case CALL_STATE_SETUP_V02:
          {
            if ( CALL_DIRECTION_MT_V02 == g_voice_all_call_info.call_info[ i ].direction )  //MT call
            TOF_call_info->call_info[ i ].state = TOF_CALL_INCOMING;
            else  //MO call
            TOF_call_info->call_info[ i ].state = TOF_CALL_DIALING;
          }
          break;
          //dsji_20130514 modify }

        case CALL_STATE_CONVERSATION_V02:
/*          
        case CALL_STATE_DISCONNECTING_V02:
        case CALL_STATE_END_V02:*/  //dsji_20150330 disable
          {
            TOF_call_info->call_info[ i ].state = TOF_CALL_ACTIVE;

            //dsji_20150323 add {
            if ( 1 == g_voice_all_call_info.call_info_len )
            {
              for ( k = 0; k < clone_g_voice_all_call_info.call_info_len; ++k )
              {
                if ( g_voice_all_call_info.call_info[ i ].call_id == clone_g_voice_all_call_info.call_info[ k ].call_id )
                {
                  if ( CALL_STATE_WAITING_V02 == clone_g_voice_all_call_info.call_info[ k ].call_state )
                  {
                    TOF_call_info->call_info[ i ].state = TOF_CALL_INCOMING;
                    
                    unsol_response_call_state_changed = TRUE;

                    MSG_HIGH( "[VOICE] to show history of waiting -> incoming -> active, send dummy incoming call state", 0, 0, 0 );
                  }
                }
              }
            }
            //dsji_20150323 add }
          }
          break;

        //dsji_20150330 add {
        case CALL_STATE_DISCONNECTING_V02:
        case CALL_STATE_END_V02:
          {
            boolean keep_state = FALSE;
            
            for ( k = 0; k < g_voice_all_TOF_call_info.TOF_call_info_len; ++k )
            {
              if ( g_voice_all_call_info.call_info[ i ].call_id == g_voice_all_TOF_call_info.TOF_call[ k ].index )
              {
                keep_state = TRUE;

                TOF_call_info->call_info[ i ].state = g_voice_all_TOF_call_info.TOF_call[ k ].state;

                MSG_HIGH( "[VOICE] in disconnecting or end state, keep state. call_id:%d, state:%s",
                                                g_voice_all_TOF_call_info.TOF_call[ k ].index,
                                                getCallStateString( g_voice_all_TOF_call_info.TOF_call[ k ].state ),
                                                0 );
                
              }
            }

            if ( FALSE == keep_state )
            {
              if ( CALL_DIRECTION_MT_V02 == g_voice_all_call_info.call_info[ i ].direction )  //MT call
              {
                if ( 1 == g_voice_all_call_info.call_info_len )
                  TOF_call_info->call_info[ i ].state = TOF_CALL_INCOMING;
                else
                  TOF_call_info->call_info[ i ].state = TOF_CALL_WAITING;
              }
              else
                TOF_call_info->call_info[ i ].state = TOF_CALL_DIALING;
              
              MSG_ERROR( "[VOICE] can't find previous call, call_id:%d, so set state to %s",
                                          g_voice_all_call_info.call_info[ i ].call_id,
                                          getCallStateString( TOF_call_info->call_info[ i ].state ),
                                          0 );
            }
          }
          break;
        //dsji_20150330 add }

        case CALL_STATE_INCOMING_V02:
          TOF_call_info->call_info[ i ].state = TOF_CALL_INCOMING;
          break;

        case CALL_STATE_ALERTING_V02:
          TOF_call_info->call_info[ i ].state = TOF_CALL_ALERTING;
          break;

        case CALL_STATE_HOLD_V02:
          TOF_call_info->call_info[ i ].state = TOF_CALL_HOLDING;
          break;

        case CALL_STATE_WAITING_V02:
          TOF_call_info->call_info[ i ].state = TOF_CALL_WAITING;
          break;
      }
      
      TOF_call_info->call_info[ i ].index = g_voice_all_call_info.call_info[ i ].call_id;
      TOF_call_info->call_info[ i ].toa = 129;  //145
      TOF_call_info->call_info[ i ].isMpty = g_voice_all_call_info.call_info[ i ].is_mpty;

      // call direction
      if ( CALL_DIRECTION_MT_V02 == g_voice_all_call_info.call_info[ i ].direction )
        TOF_call_info->call_info[ i ].isMT = TRUE;
      else
        TOF_call_info->call_info[ i ].isMT = FALSE;

      TOF_call_info->call_info[ i ].als = g_voice_all_call_info.call_info[ i ].als;

      // call type
      TOF_call_info->call_info[ i ].isVoice = convert_call_state(g_voice_all_call_info.call_info[ i ].direction,
                                                                      g_voice_all_call_info.call_info[ i ].call_type,
                                                                      g_voice_all_call_info.call_info[ i ].call_state,
                                                                      g_voice_speech_codec);
/*      
      if ( CALL_TYPE_VOICE_V02 == g_voice_all_call_info.call_info[ i ].call_type )
        RILCall[ i ]->isVoice = TRUE;
      else if ( CALL_TYPE_VOICE_IP_V02 == g_voice_all_call_info.call_info[ i ].call_type )
        RILCall[ i ]->isVoice = CALL_TYPE_VOICE_IP_V02;
      else
        RILCall[ i ]->isVoice = FALSE;
*/

      TOF_call_info->call_info[ i ].isVoicePrivacy = FALSE;

      g_voice_all_call_info.remote_party_number_valid = TRUE;

      if ( TRUE == g_voice_all_call_info.remote_party_number_valid )
      {
        for ( j = 0; j < g_voice_all_call_info.remote_party_number_len; ++j )
        {
          if ( g_voice_all_call_info.call_info[ i ].call_id == g_voice_all_call_info.remote_party_number[ j ].call_id )
          {
            //RIL_call_info->call_info[ i ]->number = (char*)malloc( g_voice_all_call_info.remote_party_number[ j ].number_len + 1 );
            memset( TOF_call_info->call_info[ i ].number, 0, g_voice_all_call_info.remote_party_number[ j ].number_len + 1 );

            convert_phone_number(g_voice_all_call_info.remote_party_number[ j ].number, TOF_call_info->call_info[ i ].number);
            
            //memcpy( RILCall[ i ]->number, RILCall[ i ]->number, g_voice_all_call_info.remote_party_number[ j ].number_len );
            
            //dsji_20130620 add {
            if ( TOF_CALL_ACTIVE == TOF_call_info->call_info[ i ].state )
            {
              switch ( g_colp_n )
              {
                case 0: TOF_call_info->call_info[ i ].numberPresentation = g_voice_all_call_info.remote_party_number[ j ].number_pi;    break;  //from network
                case 1: TOF_call_info->call_info[ i ].numberPresentation = 0;    break;  //presentation invocation(1) = allowed(0)
                case 2: TOF_call_info->call_info[ i ].numberPresentation = 1;    break;  //presentation suppression(2) = restricted(1)
                default: TOF_call_info->call_info[ i ].numberPresentation = 2;    break;  //not specified
              }
            }
            else
            {
              switch ( g_clip_n )
              {
                case 0: TOF_call_info->call_info[ i ].numberPresentation = g_voice_all_call_info.remote_party_number[ j ].number_pi;    break;  //from network
                case 1: TOF_call_info->call_info[ i ].numberPresentation = 0;    break;  //presentation invocation(1) = allowed(0)
                case 2: TOF_call_info->call_info[ i ].numberPresentation = 1;    break;  //presentation suppression(2) = restricted(1)
                default: TOF_call_info->call_info[ i ].numberPresentation = 2;    break;  //not specified
              }
            }
          //dsji_20130620 add }
          }
        }
      }

      if ( TRUE == g_voice_all_call_info.remote_party_name_valid )
      {
        for ( j = 0; j < g_voice_all_call_info.remote_party_name_len; ++j )
        {
          if ( g_voice_all_call_info.call_info[ i ].call_id == g_voice_all_call_info.remote_party_name[ j ].call_id )
          {
            //RIL_call_info->call_info[ i ]->name = (char*)malloc( g_voice_all_call_info.remote_party_name[ j ].name_len + 1 );
            memset( TOF_call_info->call_info[ i ].name, 0, g_voice_all_call_info.remote_party_name[ j ].name_len + 1 );
            memcpy( TOF_call_info->call_info[ i ].name, g_voice_all_call_info.remote_party_name[ j ].name, g_voice_all_call_info.remote_party_name[ j ].name_len );
            TOF_call_info->call_info[ i ].namePresentation = g_voice_all_call_info.remote_party_name[ j ].name_pi;
          }
        }
      }

      if ( TRUE == g_voice_all_call_info.uus_info_valid )
      {
        for ( j = 0; j < g_voice_all_call_info.uus_info_len; ++j )
        {
          if ( g_voice_all_call_info.uus_info[ j ].call_id == g_voice_all_call_info.call_info[ i ].call_id )
          {
            //RIL_call_info->call_info[ i ]->uusInfo = (RIL_UUS_Info*)malloc( sizeof( RIL_UUS_Info ) );
            memset( &TOF_call_info->call_info[ i ].uusInfo, 0, sizeof( TOF_UUS_Info ) );
            TOF_call_info->call_info[ i ].uusInfo.uusType = g_voice_all_call_info.uus_info[ j ].uus_type;
            TOF_call_info->call_info[ i ].uusInfo.uusDcs = g_voice_all_call_info.uus_info[ j ].uus_dcs;
            TOF_call_info->call_info[ i ].uusInfo.uusLength = g_voice_all_call_info.uus_info[ j ].uus_data_len;
            //RIL_call_info->call_info[ i ]->uusInfo->uusData = (char*)malloc( g_voice_all_call_info.uus_info[ j ].uus_data_len );
            memcpy( TOF_call_info->call_info[ i ].uusInfo.uusData, g_voice_all_call_info.uus_info[ j ].uus_data, g_voice_all_call_info.uus_info[ j ].uus_data_len );
          }
        }
      }
    }

    #if 0 //ohsk_20160308 Disable hkmc spec
    //dsji_20141111 modify {
    if ( 1 == g_voice_all_call_info.call_info_len && CALL_STATE_HOLD_V02 == g_voice_all_call_info.call_info[ 0 ].call_state )
    {
      MSG_HIGH( "[VOICE] () : change HOLD call to CONVERSATION manually, call_id:%d", g_voice_all_call_info.call_info[ 0 ].call_id, 0, 0 );
      
      if ( FALSE == request_switch_waiting_or_holding_and_active() )
      {
        MSG_ERROR( "[VOICE] () : fail request_switch_waiting_or_holding_and_active()", 0, 0, 0 );
      }
    }
    //dsji_20141111 modify }
    #endif

    update_g_voice_all_TOF_call_info( TOF_call_info, g_voice_all_call_info.call_info_len );  //dsji_20150330 add

    MSG_HIGH("TOF_requestGetCurrentCalls : Success \n",0,0,0);
    return TOF_SUCCESS;
  }
  else
  {
    MSG_ERROR("TOF_requestGetCurrentCalls : Failed \n",0,0,0);
    return TOF_FAIL;
  }
}

/*======================================================================

FUNCTION TOF_request_dial
 
DESCRIPTION
  
======================================================================*/

int TOF_request_hangup(uint8 call_id)
{
  if ( TRUE == request_hangup( call_id ) )
  {
    MSG_HIGH("TOF_request_hangup : Hangup Success \n",0,0,0);
    return TOF_SUCCESS;
  }
  else
  {
     MSG_ERROR("TOF_request_hangup : Hangup Failed \n",0,0,0);
    return TOF_FAIL;
  }
}

/*======================================================================

FUNCTION TOF_request_answer
 
DESCRIPTION
  
======================================================================*/

int TOF_request_answer()
{
  if ( TRUE == request_answer() )
  {
    MSG_HIGH("TOF_request_answer : Answer Success \n",0,0,0);
    return TOF_SUCCESS;
  }
  else
  {
     MSG_ERROR("TOF_request_answer : Answer Failed \n",0,0,0);
    return TOF_FAIL;
  }
}

/*======================================================================

FUNCTION TOF_request_last_call_fail_cause
 
DESCRIPTION
  
======================================================================*/

int TOF_request_last_call_fail_cause(int* cause)
{
  if ( TRUE == request_last_call_fail_cause((call_end_reason_enum_v02 *)cause)) 
  {
    MSG_HIGH("TOF_request_last_call_fail_cause : Success \n",0,0,0);
    return TOF_SUCCESS;
  }
  else
  {
     MSG_ERROR("TOF_request_last_call_fail_cause : Failed \n",0,0,0);
    return TOF_FAIL;
  }
}

/*======================================================================

FUNCTION TOF_request_switch_waiting_or_holding_and_active
 
DESCRIPTION
  
======================================================================*/

int TOF_request_switch_waiting_or_holding_and_active(void)
{
  if ( TRUE == request_switch_waiting_or_holding_and_active()) 
  {
    MSG_HIGH("TOF_request_switch_waiting_or_holding_and_active : Success \n",0,0,0);
    return TOF_SUCCESS;
  }
  else
  {
     MSG_ERROR("TOF_request_switch_waiting_or_holding_and_active : Failed \n",0,0,0);
    return TOF_FAIL;
  }
}

/*======================================================================

FUNCTION TOF_request_hangup_foreground_resume_background
 
DESCRIPTION
  
======================================================================*/

int TOF_request_hangup_foreground_resume_background(void)
{
  if ( TRUE == request_hangup_foreground_resume_background()) 
  {
    MSG_HIGH("TOF_request_hangup_foreground_resume_background : Success \n",0,0,0);
    return TOF_SUCCESS;
  }
  else
  {
     MSG_ERROR("TOF_request_hangup_foreground_resume_background : Failed \n",0,0,0);
    return TOF_FAIL;
  }
}

/*======================================================================

FUNCTION TOF_request_hangup_waiting_or_background
 
DESCRIPTION
  
======================================================================*/

int TOF_request_hangup_waiting_or_background(void)
{
  if ( TRUE == request_hangup_waiting_or_background()) 
  {
    MSG_HIGH("TOF_request_hangup_waiting_or_background : Success \n",0,0,0);
    return TOF_SUCCESS;
  }
  else
  {
     MSG_ERROR("TOF_request_hangup_waiting_or_background : Failed \n",0,0,0);
    return TOF_FAIL;
  }
}

/*======================================================================

FUNCTION TOF_request_dtmf_start
 
DESCRIPTION
  
======================================================================*/

int TOF_request_dtmf_start(char* key)
{
  if ( TRUE == request_dtmf_start(key)) 
  {
    MSG_HIGH("TOF_request_dtmf_start : Success \n",0,0,0);
    return TOF_SUCCESS;
  }
  else
  {
     MSG_ERROR("TOF_request_dtmf_start : Failed \n",0,0,0);
    return TOF_FAIL;
  }
}

/*======================================================================

FUNCTION TOF_request_dtmf_stop
 
DESCRIPTION
  
======================================================================*/

int TOF_request_dtmf_stop(void)
{
  if ( TRUE == request_dtmf_stop()) 
  {
    MSG_HIGH("TOF_request_dtmf_stop : Success \n",0,0,0);
    return TOF_SUCCESS;
  }
  else
  {
     MSG_ERROR("TOF_request_dtmf_stop : Failed \n",0,0,0);
    return TOF_FAIL;
  }
}

/*======================================================================

FUNCTION TOF_request_dtmf
 
DESCRIPTION
  
======================================================================*/

int TOF_request_dtmf(char* dtmf_data)
{

  /*char * containing a single character with one of 12 values: 0-9,*,# */

  if ( TRUE == request_dtmf(dtmf_data)) 
  {
    MSG_HIGH("TOF_request_dtmf : Success \n",0,0,0);
    return TOF_SUCCESS;
  }
  else
  {
     MSG_ERROR("TOF_request_dtmf : Failed \n",0,0,0);
    return TOF_FAIL;
  }
}

/*=========================================================
	FUNCTION	: TOF_REQUEST_ECALL_DIAL [TOF_request_ecall_dial]

	DESCRIPTION
	  Initiate a eCall according to given mode. 
       0 : test call
       1 : reconfiguration call
       2 : manually initiated eCall
       3 : automatically initiated eCall

	DEPENDENCIES

	RETURN VALUES

	SIDE EFFECTS

	NOTES
		20160921	SH.Lee		Created.
=========================================================*/
int TOF_request_ecall_dial(int mode)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    MSG_ERROR("TOF_request_ecall_dial : Unable to acquire qmi handle \n",0,0,0);
    return TOF_HANDLE_FAIL;
  }

  if(mode < 0 || mode > 3)
  {
    MSG_ERROR("TOF_request_ecall_dial : Invalid argument[%d] \n",mode,0,0);
    return TOF_FAIL;
  }

  if ( FALSE == request_ecall_dial(mode))
  {
    MSG_ERROR("TOF_request_ecall_dial : Dial Failed \n",0,0,0);
    return TOF_FAIL;    
  }

  MSG_HIGH("TOF_request_ecall_dial : Dial Success \n",0,0,0);
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_set_ecall_enable
  	DESCRIPTION
	  Initiate a eCall according to given mode. 
       0 : ecall disable
       1 : ecall enable

	DEPENDENCIES

	RETURN VALUES
	TOF_HANDLE_FAIL, TOF_FAIL, TOF_SUCCESS
	
	SIDE EFFECTS

	NOTES
		20160928	jaeyong1.park		Created.
===========================================================================*/
int TOF_request_set_ecall_enable(int mode)
{
	MSG_HIGH("TOF_request_set_ecall_enable(%d) \n",mode,0,0);

  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
	MSG_ERROR("TOF_request_ecall_dial : Unable to acquire qmi handle \n",0,0,0);
	return TOF_HANDLE_FAIL;
  }

  if(mode < 0 || mode > 1)
  {
	MSG_ERROR("TOF_request_set_ecall_enable : Invalid argument[%d] \n",mode,0,0);
	return TOF_FAIL;
  }

  if ( RESULT_FAILURE == request_set_ecall_enable(mode))
  {
	MSG_ERROR("TOF_request_set_ecall_enable : Setting Failed \n",0,0,0);
	return TOF_FAIL;	
  }

  MSG_HIGH("TOF_request_set_ecall_enable : Setting Success \n",0,0,0);
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_set_ecall_enable
  	DESCRIPTION
	  Initiate a eCall according to given mode. 
       0 : ecall disable
       1 : ecall enable

	DEPENDENCIES

	RETURN VALUES
	TOF_HANDLE_FAIL, TOF_FAIL, TOF_SUCCESS
	
	SIDE EFFECTS

	NOTES
		20160928	jaeyong1.park		Created.
===========================================================================*/
int TOF_request_set_ecall_only_mode(int mode)
{
	MSG_HIGH("TOF_request_enable_ecall_only_mode(%d) \n",mode,0,0);

  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
	MSG_ERROR("TOF_request_enable_ecall_only_mode : Unable to acquire qmi handle \n",0,0,0);
	return TOF_HANDLE_FAIL;
  }

  if(mode < 0 || mode > 1)
  {
	MSG_ERROR("TOF_request_enable_ecall_only_mode : Invalid argument[%d] \n",mode,0,0);
	return TOF_FAIL;
  }

  if ( RESULT_FAILURE == request_set_ecall_only_mode(mode))
  {
	MSG_ERROR("TOF_request_enable_ecall_only_mode : Setting Failed \n",0,0,0);
	return TOF_FAIL;	
  }

  MSG_HIGH("TOF_request_enable_ecall_only_mode : Setting Success \n",0,0,0);
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_read_ecall_oper_mode
  	DESCRIPTION
	  Read eCall operation mode. 

	DEPENDENCIES

	RETURN VALUES
	TOF_HANDLE_FAIL, TOF_FAIL, TOF_SUCCESS
	
	SIDE EFFECTS

	NOTES
		20161014	mwkim		Created.
===========================================================================*/
int TOF_request_get_ecall_oper_mode(uint8 * ecall_mode_value)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
	MSG_ERROR("TOF_request_enable_ecall_only_mode : Unable to acquire qmi handle \n",0,0,0);
	return TOF_HANDLE_FAIL;
  }

  if ( RESULT_FAILURE == request_get_ecall_oper_mode(ecall_mode_value))  	
  {
	MSG_ERROR("TOF_request_enable_ecall_only_mode : Getting Failed \n",0,0,0);
	return TOF_FAIL;	
  }

  MSG_HIGH("TOF_request_enable_ecall_only_mode : Getting Success \n",0,0,0);
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_set_ecall_number
  	DESCRIPTION
	  MAX length for ecall number is 19 digits
	 
	DEPENDENCIES

	RETURN VALUES
	TOF_HANDLE_FAIL, TOF_FAIL, TOF_SUCCESS
	
	SIDE EFFECTS

	NOTES
		20160928	jaeyong1.park		Created.
===========================================================================*/
int TOF_request_set_ecall_number(char* ecallnumber)
{
	MSG_HIGH("TOF_request_set_ecall_number(%s) \n",ecallnumber,0,0);

  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
	MSG_ERROR("TOF_request_set_ecall_number : Unable to acquire qmi handle \n",0,0,0);
	return TOF_HANDLE_FAIL;
  }

  if ( RESULT_FAILURE == request_set_ecall_number(ecallnumber))
  {
	MSG_ERROR("TOF_request_set_ecall_number : Setting Failed \n",0,0,0);
	return TOF_FAIL;	
  }

  MSG_HIGH("TOF_request_set_ecall_number : Setting Success \n",0,0,0);
  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_set_ecall_vocconf
  	DESCRIPTION
	  VOC_CONFIG  : 0(FALSE), 1(TRUE)
	 
	DEPENDENCIES

	RETURN VALUES
	TOF_HANDLE_FAIL, TOF_FAIL, TOF_SUCCESS
	
	SIDE EFFECTS

	NOTES
		20161012	jaeyong1.park		Created.
===========================================================================*/

int TOF_request_set_ecall_vocconf(int vocconf)
{
	MSG_HIGH("TOF_request_set_ecall_vocconf(%d) \n",vocconf,0,0);

  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
	MSG_ERROR("TOF_request_set_ecall_vocconf : Unable to acquire qmi handle \n",0,0,0);
	return TOF_HANDLE_FAIL;
  }

  if ( RESULT_FAILURE == request_set_ecall_config(1,vocconf))
  {
	MSG_ERROR("TOF_request_set_ecall_vocconf : Setting Failed \n",0,0,0);
	return TOF_FAIL;	
  }

  MSG_HIGH("TOF_request_set_ecall_vocconf : Setting Success \n",0,0,0);
  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_set_ecall_cannedmsd
  	DESCRIPTION
	  CANNED_MSD  : 0(FALSE), 1(TRUE)
	 
	DEPENDENCIES

	RETURN VALUES
	TOF_HANDLE_FAIL, TOF_FAIL, TOF_SUCCESS
	
	SIDE EFFECTS

	NOTES
		20161012	jaeyong1.park		Created.
===========================================================================*/

int TOF_request_set_ecall_cannedmsd(int num)
{
	MSG_HIGH("TOF_request_set_ecall_cannedmsd(%d) \n",num,0,0);

  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
	MSG_ERROR("TOF_request_set_ecall_cannedmsd : Unable to acquire qmi handle \n",0,0,0);
	return TOF_HANDLE_FAIL;
  }

  if ( RESULT_FAILURE == request_set_ecall_config(2,num))
  {
	MSG_ERROR("TOF_request_set_ecall_cannedmsd : Setting Failed \n",0,0,0);
	return TOF_FAIL;	
  }

  MSG_HIGH("TOF_request_set_ecall_cannedmsd : Setting Success \n",0,0,0);
  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_set_ecall_numtodial
  	DESCRIPTION
	 NUM_TO_DIAL : 0(NORMAL), 1(OVERRIDE)
	 
	DEPENDENCIES

	RETURN VALUES
	TOF_HANDLE_FAIL, TOF_FAIL, TOF_SUCCESS
	
	SIDE EFFECTS

	NOTES
		20161012	jaeyong1.park		Created.
===========================================================================*/


int TOF_request_set_ecall_numtodial(int num)
{
	MSG_HIGH("TOF_request_set_ecall_vocconf(%d) \n",num,0,0);

  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
	MSG_ERROR("TOF_request_set_ecall_vocconf : Unable to acquire qmi handle \n",0,0,0);
	return TOF_HANDLE_FAIL;
  }

  if ( RESULT_FAILURE == request_set_ecall_config(3,num))
  {
	MSG_ERROR("TOF_request_set_ecall_vocconf : Setting Failed \n",0,0,0);
	return TOF_FAIL;	
  }

  MSG_HIGH("TOF_request_set_ecall_vocconf : Setting Success \n",0,0,0);
  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_set_ecall_gnsssestimeout
  	DESCRIPTION
	  GNSS_UPDATE_TIME_MS  : [Second]
	 
	DEPENDENCIES

	RETURN VALUES
	TOF_HANDLE_FAIL, TOF_FAIL, TOF_SUCCESS
	
	SIDE EFFECTS

	NOTES
		20161012	jaeyong1.park		Created.
===========================================================================*/

int TOF_request_set_ecall_gnsssestimeout(int num)
{
	MSG_HIGH("TOF_request_set_ecall_vocconf(%d) \n",num,0,0);

  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
	MSG_ERROR("TOF_request_set_ecall_vocconf : Unable to acquire qmi handle \n",0,0,0);
	return TOF_HANDLE_FAIL;
  }

  if ( RESULT_FAILURE == request_set_ecall_config(5,num))
  {
	MSG_ERROR("TOF_request_set_ecall_vocconf : Setting Failed \n",0,0,0);
	return TOF_FAIL;	
  }

  MSG_HIGH("TOF_request_set_ecall_vocconf : Setting Success \n",0,0,0);
  return TOF_SUCCESS;
}



/*===========================================================================
  FUNCTION  TOF_request_set_ecall_callback_timeout
  	DESCRIPTION
	  ECALL_CALLBACK_TIMEOUT: [Hour]
	 
	DEPENDENCIES

	RETURN VALUES
	TOF_HANDLE_FAIL, TOF_FAIL, TOF_SUCCESS
	
	SIDE EFFECTS

	NOTES
		20161012	jaeyong1.park		Created.
===========================================================================*/

int TOF_request_set_ecall_callback_timeout(int num)
{
	MSG_HIGH("TOF_request_set_ecall_callback_timeout(%d) \n",num,0,0);

  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
	MSG_ERROR("TOF_request_set_ecall_callback_timeout : Unable to acquire qmi handle \n",0,0,0);
	return TOF_HANDLE_FAIL;
  }

  if ( RESULT_FAILURE == request_set_ecall_callback_timeout2(num))
  {
	MSG_ERROR("TOF_request_set_ecall_callback_timeout : Setting Failed \n",0,0,0);
	return TOF_FAIL;	
  }

  MSG_HIGH("TOF_request_set_ecall_callback_timeout : Setting Success \n",0,0,0);
  return TOF_SUCCESS;
}



/*===========================================================================
  FUNCTION  TOF_request_get_ecall_enable //jaeyong1.park
===========================================================================*/
int TOF_request_get_ecall_enable(uint32 *enable)
{
  if(request_get_ecall_enable(enable) == RESULT_FAILURE)
  {
    MSG_ERROR("TOF_request_get_ecall_enable : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  printf("[TOF] TOF_request_get_ecall_enable() value =%d\n", *enable);
  
  return TOF_SUCCESS;
}



int TOF_request_get_ecall_vocconf (char* strdata){
  if(request_get_ecall_config(1, strdata) == RESULT_FAILURE)
  {
	MSG_ERROR("TOF_request_get_ecall_vocconf : Failed \n",0,0,0);
	return TOF_FAIL;
  }
  return TOF_SUCCESS;
}
int TOF_request_get_ecall_cannedmsd (char* strdata){
  if(request_get_ecall_config(2, strdata) == RESULT_FAILURE)
  {
	MSG_ERROR("TOF_request_get_ecall_cannedmsd : Failed \n",0,0,0);
	return TOF_FAIL;
  }
  return TOF_SUCCESS;
}
int TOF_request_get_ecall_numtodial (char* strdata){
  if(request_get_ecall_config(3, strdata) == RESULT_FAILURE)
  {
	MSG_ERROR("TOF_request_get_ecall_numtodial : Failed \n",0,0,0);
	return TOF_FAIL;
  }
  return TOF_SUCCESS;
}
int TOF_request_get_ecall_number(char* strdata)
{
  if(request_get_ecall_config(4, strdata) == RESULT_FAILURE)
  {
	MSG_ERROR("TOF_request_get_ecall_number : Failed \n",0,0,0);
	return TOF_FAIL;
  }
  return TOF_SUCCESS;
}

int TOF_request_get_ecall_gnsssestimeout (char* strdata){
  if(request_get_ecall_config(5, strdata) == RESULT_FAILURE)
  {
	MSG_ERROR("TOF_request_get_ecall_gnsssestimeout : Failed \n",0,0,0);
	return TOF_FAIL;
  }
  return TOF_SUCCESS;
}
int TOF_request_get_ecall_callback_timeout (char* strdata){
  if(request_get_ecall_config(6, strdata) == RESULT_FAILURE)
  {
	MSG_ERROR("TOF_request_get_ecall_ecallsession_timeout : Failed \n",0,0,0);
	return TOF_FAIL;
  }
  return TOF_SUCCESS;
}



/*===========================================================================
  FUNCTION  TOF_request_get_gsm_dtm_supported
===========================================================================*/

int TOF_request_get_gsm_dtm_supported(uint32* dtmsupported)
{
	if(request_get_gsm_dtm_supported(dtmsupported) == RESULT_FAILURE)
	{
	  MSG_ERROR("TOF_request_get_gsm_dtm_supported : Failed \n",0,0,0);
	  return TOF_FAIL;
	}
	return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_get_gsm_pathhloss_criteria
===========================================================================*/
int TOF_request_get_gsm_pathhloss_criteria(TOF_GSM_PathLossCriteria_list* criteria)
{
	memset(criteria,0,sizeof(TOF_GSM_PathLossCriteria_list));
	if(request_get_gsm_pathhloss_criteria(criteria) == RESULT_FAILURE)
	{
	  MSG_ERROR("TOF_request_get_gsm_pathhloss_criteria : Failed \n",0,0,0);
	  return TOF_FAIL;
	}
	
	return TOF_SUCCESS;
}




/*===========================================================================
  FUNCTION  TOF_getModemVersion
===========================================================================*/

int TOF_getModemVersion(char* strdata)
{
  char ap_version[20];
  char tof_version[20]={NULL,};
  char version_info[50];
  tof_dms_get_modem_sw_version_resp_msg modem_version_info;

  if(TOF_request_get_basebandversion(&modem_version_info) ||
      TOF_getApVersion(ap_version) ||
      TOF_API_version(tof_version))
  {
	  MSG_ERROR("TOF_getModemVersion : Failed \n",0,0,0);
    return TOF_FAIL;
  }
  sprintf(version_info,"%s_%s_%s_%s",modem_version_info.modem_boot_version, 
                                    modem_version_info.modem_sw_version,
                                    ap_version, tof_version);
  strcpy(strdata,version_info);
  MSG_HIGH("TOF_getModemVersion : Success \n",0,0,0);
  
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_getApVersion
===========================================================================*/

int TOF_getApVersion(char* strdata)
{
  if(request_get_ap_version(strdata) == RESULT_FAILURE)
  {
    MSG_ERROR("TOF_getApVersion : Failed \n",0,0,0);
    return TOF_FAIL;
  }
  return TOF_SUCCESS;

}
	

/*===========================================================================
  FUNCTION  TOF_get_is_roaming
===========================================================================*/

int TOF_get_is_roaming(uint8* data)
{
  if(request_get_is_roaming(data) == RESULT_FAILURE)
  {
	MSG_ERROR("TOF_getModemVersion : Failed \n",0,0,0);
	return TOF_FAIL;
  }
  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_get_networkscan
===========================================================================*/

int TOF_get_networkscan()
{
  if(request_get_network_scan() == RESULT_FAILURE)
  {
	MSG_ERROR("TOF_get_networkscan : Failed \n",0,0,0);
	return TOF_FAIL;
  }
  return TOF_SUCCESS;
}


	

	


/*===========================================================================
  FUNCTION  TOF_request_ecall_set_msd
===========================================================================*/
boolean TOF_request_ecall_set_msd
(
int mode,
char* msd_data
)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    MSG_ERROR("TOF_request_ecall_set_msd : Unable to acquire qmi handle \n",0,0,0);
    return TOF_HANDLE_FAIL;
  }

  if ( FALSE == request_ecall_set_msd(mode, msd_data))
  {
    MSG_ERROR("TOF_request_ecall_set_msd : Failed \n",0,0,0);
    return TOF_FAIL;    
  }

  MSG_HIGH("TOF_request_ecall_set_msd : Success \n",0,0,0);
  return TOF_SUCCESS;

}

#endif /* TOF_VOICE_SUPPORT */


#ifdef TOF_WMS_SUPPORT
#endif /* TOF_WMS_SUPPORT */

#ifdef TOF_DATA_SUPPORT
/*===========================================================================
  FUNCTION  TOF_setup_data_call
===========================================================================*/
int TOF_request_setup_data_call(int profile, tof_qcmap_msgr_ip_family_enum_v01 ip_family)
{
  boolean ret = FALSE;

  qcmap_store_preference(profile, ip_family);
  qcmap_set_wwan_policy(profile);

  // Try IPv6 in qcmap_msgr_qmi_qcmap_ind() in IP family is TOF_QCMAP_MSGR_IP_FAMILY_V4V6_V01
  ret = qcmap_connect_backhaul(ip_family);
  
  MSG_ERROR("qcmap_connect_backhaul ret: %d\n",ret,0,0);

  return (ret == TRUE ? TOF_SUCCESS : TOF_FAIL);
}

/*===========================================================================
  FUNCTION  TOF_request_deactivate_data_call
===========================================================================*/
int TOF_request_deactivate_data_call(void)
{
  if(FALSE == qcmap_disconnect_backhaul())
  {
    MSG_ERROR("qcmap_disconnect_backhaul : Failed \n",0,0,0);
    return TOF_FAIL;  
  }
    
  MSG_HIGH("qcmap_disconnect_backhaul : Success \n",0,0,0);
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_data_call_list
===========================================================================*/
int TOF_request_data_call_list(tof_data_call_response* call_resp)
{ 
  if(FALSE == qcmap_get_data_call_list(call_resp))
  {
    MSG_ERROR("get_data_call_list : Failed \n",0,0,0);
    return TOF_FAIL;  
  }

  MSG_HIGH("get_data_call_list : Success \n",0,0,0);
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_last_data_call_fail_cause
===========================================================================*/
int TOF_request_last_data_call_fail_cause(int32_t* reason_code)
{ 
  if(FALSE == qcmap_call_end_reason(reason_code))
  {
    MSG_ERROR("qcmap_call_end_reason : Failed \n",0,0,0);
    return TOF_FAIL;  
  }

  MSG_HIGH("qcmap_call_end_reason : Success \n",0,0,0);
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_enable_data_auto_connect
===========================================================================*/
int TOF_request_enable_data_auto_connect(int profile)
{
  qcmap_store_preference(profile, 0);
  qcmap_set_wwan_policy(profile);

  if(FALSE == qcmap_set_auto_connect(TRUE, TRUE))
  {
    MSG_ERROR("qcmap_set_auto_connect enable : Failed \n",0,0,0);
    return TOF_FAIL;  
  }

  MSG_HIGH("qcmap_set_auto_connect enable : Success \n",0,0,0);
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_disable_data_auto_connect
===========================================================================*/
int TOF_request_disable_data_auto_connect(void)
{
  if(FALSE == qcmap_set_auto_connect(FALSE, TRUE))
  {
    MSG_ERROR("qcmap_set_auto_connect disable : Failed \n",0,0,0);
    return TOF_FAIL;  
  }

  MSG_HIGH("qcmap_set_auto_connect disable : Success \n",0,0,0);
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_get_data_auto_connect
===========================================================================*/
int TOF_request_get_data_auto_connect(boolean* enable)
{
  MSG_HIGH("qcmap_get_auto_connect_from_preference\n",0,0,0);
  qcmap_get_auto_connect_from_preference(enable);

  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_set_data_profile_info
===========================================================================*/
int TOF_request_set_data_profile_info(int profile, char* apn_name, tof_qcmap_msgr_ip_family_enum_v01 ip_family)
{
  uint64_t                  param_mask;
  qmi_wds_profile_info_type profile_info = {0};
  int                       retry_count;
  boolean                   rc = FALSE;

  param_mask  = 0x0;
  param_mask |= QMI_WDS_UMTS_PROFILE_PDP_TYPE_PARAM_MASK;
  param_mask |= QMI_WDS_UMTS_PROFILE_APN_NAME_PARAM_MASK;

  profile_info.profile_num = profile;
  profile_info.pdp_type    = qmi_wds_convert_pdp_type_qcmap_to_wds(ip_family);
  strncpy(profile_info.apn, apn_name, sizeof(profile_info.apn));

  retry_count = 0;
  while(FALSE == (rc = qmi_wds_set_profile_info(profile, param_mask, &profile_info)))
  {
    if(retry_count > 0)
      break;
    
    if(FALSE == qmi_wds_add_profile_info(profile))
    {
      MSG_HIGH("qmi_wds_add_profile_info : Failed \n",0,0,0);
      break;
    }

    retry_count++;
  }

  if(FALSE == rc)
  {
    MSG_HIGH("qmi_wds_set_profile_info : Failed \n",0,0,0);
    return TOF_FAIL;  
  }

  MSG_HIGH("qmi_wds_set_profile_info : Success \n",0,0,0);
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_get_data_profile_info
===========================================================================*/
int TOF_request_get_data_profile_info(int profile, char* apn_name, int apn_name_buf_len, tof_qcmap_msgr_ip_family_enum_v01* ip_family)
{
  qmi_wds_profile_info_type profile_info = {0};

  if(FALSE == qmi_wds_get_profile_info(profile, &profile_info))
  {
    MSG_ERROR("qmi_wds_get_profile_info : Failed \n",0,0,0);
    return TOF_FAIL;  
  }

  strncpy(apn_name, profile_info.apn, apn_name_buf_len);
  *ip_family = qmi_wds_convert_pdp_type_wds_to_qcmap(profile_info.pdp_type);

  MSG_HIGH("qmi_wds_get_profile_info : Success \n",0,0,0);
  return TOF_SUCCESS;
}

//20170215 yjoh add for cell info
int TOF_request_get_cell_info(TOF_cellinfo *cellinfo)
{
  if(request_get_cell_info(cellinfo) == RESULT_FAILURE)
  {
	MSG_ERROR("TOF_request_get_cell_info : Failed \n",0,0,0);
	return TOF_FAIL;
  }
  return TOF_SUCCESS;
}

#endif /* TOF_DATA_SUPPORT */

#ifdef TOF_LOC_SUPPORT
/*===========================================================================
  FUNCTION  TOF_request_gps_reg_event
  < Parameters >
  output_type : A Type of display. i.e NMEA or Position Report
  Position Report : 0x00000001ull
  NMEA : 0x00000004ull
  Loc Server Conn Req : 0x00002000ull   //It must be used for A-GPS  
===========================================================================*/
int TOF_request_gps_reg_event(TOF_Loc_Event_Reg_Mask_type output_type)
{
  loc_local_reg_event_mask_type local_type;
  
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    QMI_ERR_MSG_0("TOF_request_gps_reg_event : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  } 

  QMI_ERR_MSG_1("TOF_request_gps_reg_event : qmi_loc_client_register_event() start output_type =%d\n",output_type);
  qmi_loc_client_register_event(output_type);
  
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_start
===========================================================================*/
int TOF_request_gps_start(void)
{
  
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    QMI_ERR_MSG_0("TOF_request_gps_start : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  } 

  qmi_loc_get_position_start(QMI_GPS_FIX_TIMEOUT); 
  
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_stop
===========================================================================*/
int TOF_request_gps_stop(void)
  {
    
    if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
    {
      QMI_ERR_MSG_0("TOF_request_gps_start : Unable to acquire qmi handle \n");
      return TOF_HANDLE_FAIL;
    } 
  
    qmi_loc_get_position_stop();  
    
    return TOF_SUCCESS;
  }

/*===========================================================================
  FUNCTION  TOF_request_gps_set_operation_mode
===========================================================================*/
int TOF_request_gps_set_operation_mode(uint16 mode)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_st_operation_mode : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if((mode < eQMI_LOC_OPER_MODE_DEFAULT_V02) || (mode > eQMI_LOC_OPER_MODE_STANDALONE_V02))
  {
    printf("[TOF]TOF_request_gps_set_operation_mode failed\r\n");

    return TOF_FAIL;
  }
  
  if(request_loc_set_operation_mode(mode) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_gps_set_operation_mode success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_gps_set_operation_mode failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_get_operation_mode
===========================================================================*/
int TOF_request_gps_get_operation_mode()
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_get_operation_mode : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_loc_get_operation_mode() == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_REQUEST_GET_SERVICE_DOMAIN success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_REQUEST_GET_SERVICE_DOMAIN failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_set_nmea_type
===========================================================================*/
int TOF_request_gps_set_nmea_type(uint32 type)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_st_operation_mode : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_loc_set_nmea_type(type) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_gps_set_nmea_type success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_gps_set_nmea_type failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_get_nmea_type
===========================================================================*/
int TOF_request_gps_get_nmea_type()
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_get_operation_mode : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_loc_get_nmea_type() == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_REQUEST_GET_SERVICE_DOMAIN success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_REQUEST_GET_SERVICE_DOMAIN failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_gps_get_reg_event
===========================================================================*/
int TOF_request_gps_get_reg_event(void)
{
  
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    QMI_ERR_MSG_0("TOF_request_gps_reg_event : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  } 
  
  if(request_loc_get_reg_event() == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_REQUEST_GET_REG_EVENT success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_REQUEST_GET_REG_EVENT failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_set_spl_server_info
===========================================================================*/
int TOF_request_gps_set_spl_server_info(tof_loc_spl_server_info_type t_supl_info)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_set_spl_server_info : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  printf("urlAddr was set urlAddr_size =%d, urlAddr =%s!!!!!!!\r\n",strlen(t_supl_info.urlAddr),t_supl_info.urlAddr);
  if(request_loc_set_supl_server_info(t_supl_info) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_gps_set_spl_server_info success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_gps_set_spl_server_info failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_get_spl_server_info
===========================================================================*/
int TOF_request_gps_get_spl_server_info(int server_type)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_get_spl_server_info : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_loc_get_supl_server_info(server_type) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_gps_get_spl_server_info success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_gps_get_spl_server_info failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_spl_server_open
===========================================================================*/
int TOF_request_gps_spl_server_conn_handle(UINT8 open_close)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_spl_server_conn_handle : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if((open_close != 1) && (open_close != 2))
  {
    printf("[TOF]TOF_request_gps_spl_server_conn_handle() Invalid input parameter =%d\r\n",open_close);
    return TOF_HANDLE_FAIL;
  }
  
  if(request_loc_set_handle_server_conn(open_close) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_gps_spl_server_conn_handle success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_gps_spl_server_conn_handle failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_del_assist_data
===========================================================================*/
int TOF_request_gps_del_assist_data(UINT8 all_data)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_del_assist_data : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if((all_data != 0) && (all_data != 1))
  {
    printf("[TOF]TOF_request_gps_del_assist_data() Invalid input parameter =%d\r\n",all_data);
    return TOF_HANDLE_FAIL;
  }
  
  if(request_loc_set_delete_assist_data(all_data) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_gps_del_assist_data success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_gps_del_assist_data failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_getLatitude
===========================================================================*/
int TOF_request_gps_getLatitude(double* lat)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_getLatitude : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_loc_get_Latitude(lat) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_gps_getLatitude success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_gps_getLatitude failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_getLongitude
===========================================================================*/
int TOF_request_gps_getLongitude(double* lon)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_getLongitude : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_loc_get_Longitude(lon) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_gps_getLongitude success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_gps_getLongitude failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_getAltitude
===========================================================================*/
int TOF_request_gps_getAltitude(float* alt)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_getAltitude : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_loc_get_Altitude(alt) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_gps_getAltitude success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_gps_getAltitude failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_getHeading
===========================================================================*/
int TOF_request_gps_getHeading(float* heading)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_getHeading : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_loc_get_Heading(heading) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_gps_getHeading success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_gps_getHeading failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_getSpeed
===========================================================================*/
int TOF_request_gps_getSpeed(float* speed)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_getSpeed : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_loc_get_Speed(speed) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_gps_getSpeed success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_gps_getSpeed failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_getVerticalSpeed
===========================================================================*/
int TOF_request_gps_getVerticalSpeed(float* vspeed)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_getVerticalSpeed : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_loc_get_VerticalSpeed(vspeed) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_gps_getVerticalSpeed success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_gps_getVerticalSpeed failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_getVDOP
===========================================================================*/
int TOF_request_gps_getVDOP(float* vdop)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_getVDOP : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_loc_get_VDOP(vdop) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_gps_getVDOP success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_gps_getVDOP failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_getHDOP
===========================================================================*/
int TOF_request_gps_getHDOP(float* hdop)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_getHDOP : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_loc_get_HDOP(hdop) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_gps_getHDOP success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_gps_getHDOP failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_PDOP
===========================================================================*/
int TOF_request_gps_getPDOP(float* pdop)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_getPDOP : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_loc_get_PDOP(pdop) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_gps_getPDOP success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_gps_getPDOP failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_getSpeedAccuracy
===========================================================================*/
int TOF_request_gps_getSpeedAccuracy(float* sacc)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_getSpeedAccuracy : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_loc_get_SpeedAccuracy(sacc) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_gps_getSpeedAccuracy success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_gps_getSpeedAccuracy failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_getAltitudeMSL
===========================================================================*/
int TOF_request_gps_getAltitudeMSL(float* altmsl)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_getAltitudeMSL : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_loc_get_AltitudeMSL(altmsl) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_gps_getAltitudeMSL success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_gps_getAltitudeMSL failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_getHorizontalAccuracy
===========================================================================*/
int TOF_request_gps_getHorizontalAccuracy(float* hacc)
{
  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_getHorizontalAccuracy : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_loc_get_HorizontalAccuracy(hacc) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_gps_getHorizontalAccuracy success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_gps_getHorizontalAccuracy failed\r\n");
    return TOF_FAIL;
  }
 
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_getGnssSVInfo
===========================================================================*/
int TOF_request_gps_getGnssSVInfo(tof_qmiLocEventGnssSvInfoIndMsgT_v02  *SvInfo)
{

  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_getGnssSVInfo : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_loc_get_getGnssSVInfo(SvInfo) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_gps_getGnssSVInfo success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_gps_getGnssSVInfo failed\r\n");
    return TOF_FAIL;
  }

  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_gps_getPositionInfo
===========================================================================*/
int TOF_request_gps_getPositionInfo(tof_qmiLocEventPositionReportIndMsgT_v02  *poInfo)
{

  if (qmi_handle == QMI_INVALID_CLIENT_HANDLE)
  {
    printf("TOF_request_gps_getPositionInfo : Unable to acquire qmi handle \n");
    return TOF_HANDLE_FAIL;
  }

  if(request_loc_get_getPositionInfo(poInfo) == RESULT_SUCCESS)
  {
    printf("[TOF]TOF_request_gps_getPositionInfo success +\r\n");   
  }
  else
  {
    printf("[TOF]TOF_request_gps_getPositionInfo failed\r\n");
    return TOF_FAIL;
  }

  return TOF_SUCCESS;
}
#endif /* TOF_LOC_SUPPORT */

#ifdef FEATURE_TOF_WIFI
/*===========================================================================
  FUNCTION  TOF_wifi_connect
===========================================================================*/
int TOF_wifi_connect(char* ssid, char* pw, int encryption)
{
  if(connect_wifi(ssid,pw,encryption))
    {
      printf("[TOF]TOF_wifi_connect success \n");    
    }
  else
    {
      printf("[TOF]TOF_wifi_connect fail \n");  
      return TOF_FAIL;      
    }
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_wifi_disconnect
===========================================================================*/
int TOF_wifi_disconnect()
{
  if(disconnect_wifi())
    {
      printf("[TOF]TOF_wifi_disconnect success \n");         
    }
  else
    {
      printf("[TOF] WiFi was already disconnected.\n"); 
      return TOF_FAIL;      
    }

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_wifi_unload
===========================================================================*/
int TOF_wifi_module_unload()
{
	if(unload_wifimodule())
	{
		printf("[TOF]TOF_wifi_module_unload success \n");   			
	}
	else
	{
		printf("[TOF]TOF_wifi_module_unload failed\n"); 
		return TOF_FAIL;			
	}

	return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_wifi_load
===========================================================================*/
int TOF_wifi_module_load()
{
	if(load_wifimodule())
	{
		printf("[TOF]TOF_wifi_module_load success \n"); 				
	}
	else
	{
		printf("[TOF]TOF_wifi_module_load failed\n"); 
		return TOF_FAIL;			
	}

	return TOF_SUCCESS;
}
#endif

#ifdef TOF_IMS_SUPPORT
/*======================================================================

FUNCTION TOF_request_set_volte
 
DESCRIPTION

======================================================================*/

int TOF_request_set_volte(boolean on_off)
{
  if(request_set_volte(on_off) != TRUE)
  {
    MSG_ERROR("TOF_request_set_volte : Failed \n",0,0,0);

    return TOF_FAIL;
  }

  return TOF_SUCCESS;
}

/*======================================================================

FUNCTION TOF_request_get_volte
 
DESCRIPTION

======================================================================*/

int TOF_request_get_volte(uint8 *on_off)
{
  *on_off = request_get_volte();

  if(on_off == 0xFF)
  {
    MSG_ERROR("TOF_request_set_volte : Failed \n",0,0,0);
    return TOF_FAIL;
  }
  
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_ims_enable
===========================================================================*/
int TOF_request_set_ims_enable(uint8 enable)
{
  if(request_set_ims_enable(enable) == FALSE)
  {
    MSG_ERROR("TOF_request_set_ims_enable : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_ims_enable
===========================================================================*/
int TOF_request_get_ims_enable(uint8 *enable)
{
  if(request_get_ims_enable(enable) == FALSE)
  {
    MSG_ERROR("TOF_request_get_ims_enable : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  printf("[TOF]TOF_request_get_ims_enable() enable =%d\n",*enable);
  return TOF_SUCCESS;
}




/*===========================================================================
  FUNCTION  TOF_request_set_volte_session_timer
===========================================================================*/
int TOF_request_set_volte_session_timer(uint16 sess_time)
{
  if(request_set_volte_session_timer(sess_time) == FALSE)
  {
    MSG_ERROR("TOF_request_set_volte_session_timer : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_get_volte_session_timer
===========================================================================*/
int TOF_request_get_volte_session_timer(uint16 *sess_time)
{
  if(request_get_volte_session_timer(sess_time) == FALSE)
  {
    MSG_ERROR("TOF_request_get_volte_session_timer : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  printf("[TOF]TOF_request_get_volte_session_timer() sess_time =%d\n",*sess_time);
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_set_amr_payload_format
===========================================================================*/
int TOF_request_set_amr_payload_format(boolean amr_octet_alian)
{
  RIL_Ims_Voip_Info voip_info;

  memset(&voip_info,0,sizeof(RIL_Ims_Voip_Info));

  voip_info.amr_octet_align = amr_octet_alian;
  if(ril_request_set_ims_voip_info(REQUEST_AMR_PAYLOAD_FORMAT, voip_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_set_amr_payload_format : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  printf("[TOF]TOF_request_set_amr_payload_format() octet_alian =%d, amr_octet_align =%d\n",amr_octet_alian,voip_info.amr_octet_align);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_get_amr_payload_format
===========================================================================*/
int TOF_request_get_amr_payload_format(boolean *amr_octet_alian)
{
  RIL_Ims_Voip_Info voip_info;

  memset(&voip_info,0,sizeof(RIL_Ims_Voip_Info));
  
  if(ril_request_get_ims_voip_info(REQUEST_AMR_PAYLOAD_FORMAT, &voip_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_get_amr_payload_format : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  *amr_octet_alian = voip_info.amr_octet_align;
  printf("[TOF]TOF_request_get_amr_payload_format() octet_alian =%d, amr_octet_align =%d\n",*amr_octet_alian,voip_info.amr_octet_align);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_set_amr_wb_payload_format
===========================================================================*/
int TOF_request_set_amr_wb_payload_format(boolean amr_wb_octet_align)
{
  RIL_Ims_Voip_Info voip_info;

  memset(&voip_info,0,sizeof(RIL_Ims_Voip_Info));

  voip_info.amr_wb_octet_align = amr_wb_octet_align;
  
  if(ril_request_set_ims_voip_info(REQUEST_AMR_WB_PAYLOAD_FORMAT, voip_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_set_amr_wb_payload_format : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  printf("[TOF]TOF_request_set_amr_wb_payload_format() amr_wb_octet_align =%d, info.amr_wb_octet_align=%d\n",amr_wb_octet_align,voip_info.amr_wb_octet_align);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_get_amr_wb_payload_format
===========================================================================*/
int TOF_request_get_amr_wb_payload_format(boolean *amr_wb_octet_align)
{
  RIL_Ims_Voip_Info voip_info;

  memset(&voip_info,0,sizeof(RIL_Ims_Voip_Info));
  
  if(ril_request_get_ims_voip_info(REQUEST_AMR_WB_PAYLOAD_FORMAT, &voip_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_get_amr_wb_payload_format : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  *amr_wb_octet_align = voip_info.amr_wb_octet_align;
  printf("[TOF]TOF_request_get_amr_wb_payload_format() amr_wb_octet_align =%d, info.amr_wb_octet_align=%d\n",*amr_wb_octet_align,voip_info.amr_wb_octet_align);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_set_amr_codec_mode_set
===========================================================================*/
int TOF_request_set_amr_codec_mode_set(uint8 amr_codec_mode)
{
  RIL_Ims_Voip_Info voip_info;

  memset(&voip_info,0,sizeof(RIL_Ims_Voip_Info));

  voip_info.amr_mode = amr_codec_mode;
  
  if(ril_request_set_ims_voip_info(REQUEST_AMR_CODEC_MODE_SET, voip_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_set_amr_codec_mode_set : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  printf("[TOF]TOF_request_set_amr_codec_mode_set() amr_mode =%d, info.amr_mode =%d\n",amr_codec_mode,voip_info.amr_mode);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_get_amr_codec_mode_set
===========================================================================*/
int TOF_request_get_amr_codec_mode_set(uint8 *amr_codec_mode)
{
  RIL_Ims_Voip_Info voip_info;

  memset(&voip_info,0,sizeof(RIL_Ims_Voip_Info));
  if(ril_request_get_ims_voip_info(REQUEST_AMR_CODEC_MODE_SET, &voip_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_get_amr_codec_mode_set : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  *amr_codec_mode = voip_info.amr_mode;
  printf("[TOF]TOF_request_get_amr_codec_mode_set() amr_mode =%d, info.amr_mode =%d\n",*amr_codec_mode,voip_info.amr_mode);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_set_amr_wb_codec_mode_set
===========================================================================*/
int TOF_request_set_amr_wb_codec_mode_set(uint16 amr_wb_codec_mode)
{
  RIL_Ims_Voip_Info voip_info;

  memset(&voip_info,0,sizeof(RIL_Ims_Voip_Info));

  voip_info.amr_wb_mode = amr_wb_codec_mode;
  if(ril_request_set_ims_voip_info(REQUEST_AMR_WB_CODEC_MODE_SET, voip_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_set_amr_wb_codec_mode_set : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  printf("[TOF]TOF_request_set_amr_wb_codec_mode_set() amr_wb_codec_mode =%d, info.amr_wb_mode =%d\n",amr_wb_codec_mode,voip_info.amr_wb_mode);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_get_amr_wb_codec_mode_set
===========================================================================*/
int TOF_request_get_amr_wb_codec_mode_set(uint16 *amr_wb_codec_mode)
{
  RIL_Ims_Voip_Info voip_info;

  memset(&voip_info,0,sizeof(RIL_Ims_Voip_Info));
  if(ril_request_get_ims_voip_info(REQUEST_AMR_WB_CODEC_MODE_SET, &voip_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_get_amr_wb_codec_mode_set : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  *amr_wb_codec_mode = voip_info.amr_wb_mode;
  printf("[TOF]TOF_request_get_amr_wb_codec_mode_set() amr_wb_codec_mode =%d, info.amr_wb_mode =%d\n",*amr_wb_codec_mode,voip_info.amr_wb_mode);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_set_amr_wb_enable
===========================================================================*/
int TOF_request_set_amr_wb_enable(boolean amr_wb_enable)
{
  RIL_Ims_Voip_Info voip_info;

  memset(&voip_info,0,sizeof(RIL_Ims_Voip_Info));

  voip_info.amr_wb_enable = amr_wb_enable;
  if(ril_request_set_ims_voip_info(REQUEST_AMR_WB_ENABLE, voip_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_set_amr_wb_enable : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  printf("[TOF]TOF_request_set_amr_wb_enable() amr_wb_enable =%d, info.amr_wb_enable =%d\n",amr_wb_enable,voip_info.amr_wb_enable);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_get_amr_wb_enable
===========================================================================*/
int TOF_request_get_amr_wb_enable(boolean *amr_wb_enable)
{
  RIL_Ims_Voip_Info voip_info;

  memset(&voip_info,0,sizeof(RIL_Ims_Voip_Info));
  if(ril_request_get_ims_voip_info(REQUEST_AMR_WB_ENABLE, &voip_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_get_amr_wb_enable : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  *amr_wb_enable = voip_info.amr_wb_enable;
  printf("[TOF]TOF_request_get_amr_wb_enable() amr_wb_enable =%d, info.amr_wb_enable =%d\n",*amr_wb_enable,voip_info.amr_wb_enable);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_set_rtcp_enable
===========================================================================*/
int TOF_request_set_rtcp_enable(uint8 rtcp_enable)
{
  RIL_Ims_Qipcall_Config t_qpi_config;

  memset(&t_qpi_config,0,sizeof(RIL_Ims_Qipcall_Config));

  t_qpi_config.rtcp = rtcp_enable;
  if(ril_request_set_ims_qipcall_config(REQUEST_RTCP, t_qpi_config) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_set_rtcp_enable : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  printf("[TOF]TOF_request_set_rtcp_enable() rtcp =%d\n",t_qpi_config.rtcp);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_get_rtcp_enable
===========================================================================*/
int TOF_request_get_rtcp_enable(uint8 *rtcp_enable)
{
  RIL_Ims_Qipcall_Config t_qpi_config;
  
  memset(&t_qpi_config,0,sizeof(RIL_Ims_Qipcall_Config));  

  if(ril_request_get_ims_qipcall_config(REQUEST_RTCP, &t_qpi_config) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_set_rtcp_enable : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  *rtcp_enable = t_qpi_config.rtcp;  
  printf("[TOF]TOF_request_set_rtcp_enable() rtcp_enable =%d, rtcp =%d\n",*rtcp_enable,t_qpi_config.rtcp);

  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_set_pcscf_port
===========================================================================*/
int TOF_request_set_pcscf_port(uint16 pcscf_port)
{
  RIL_Ims_Reg_Info  ims_req_info;
  memset(&ims_req_info,0,sizeof(RIL_Ims_Reg_Info));

  ims_req_info.pcscf_port = pcscf_port;
  if(ril_request_set_ims_reg_info(REQUEST_PCSCF_PORT, ims_req_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_set_pcscf_port : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  printf("[TOF]TOF_request_set_pcscf_port() pcscf_port =%d\n",ims_req_info.pcscf_port);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_get_pcscf_port
===========================================================================*/
int TOF_request_get_pcscf_port(uint16 *pcscf_port)
{
  RIL_Ims_Reg_Info  ims_req_info;
  memset(&ims_req_info,0,sizeof(RIL_Ims_Reg_Info)); 

  if(ril_request_get_ims_reg_info(REQUEST_PCSCF_PORT, &ims_req_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_get_pcscf_port : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  *pcscf_port = ims_req_info.pcscf_port;  
  printf("[TOF]TOF_request_get_pcscf_port() pcscf_port =%d, req_pcscf_port =%d\n",*pcscf_port,ims_req_info.pcscf_port);

  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_set_pcscf_domain
===========================================================================*/
int TOF_request_set_pcscf_domain(char *pcscf_domain)
{
  RIL_Ims_Reg_Info  ims_req_info;
  memset(&ims_req_info,0,sizeof(RIL_Ims_Reg_Info));

  strcpy((char*)ims_req_info.pcscf_domain,pcscf_domain);

  if(ril_request_set_ims_reg_info(REQUEST_PCSCF_DOMAIN, ims_req_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_set_pcscf_domain : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  printf("[TOF]TOF_request_set_pcscf_domain() pcscf_domain =%s\n",ims_req_info.pcscf_domain);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_get_pcscf_domain
===========================================================================*/
int TOF_request_get_pcscf_domain(char *pcscf_domain)
{
  RIL_Ims_Reg_Info  ims_req_info;
  memset(&ims_req_info,0,sizeof(RIL_Ims_Reg_Info)); 

  if(ril_request_get_ims_reg_info(REQUEST_PCSCF_DOMAIN, &ims_req_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_get_pcscf_domain : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  strcpy((char*)pcscf_domain,ims_req_info.pcscf_domain);
  printf("[TOF]TOF_request_get_pcscf_domain() pcscf_domain =%s, req_pcscf_domain =%s\n",pcscf_domain,ims_req_info.pcscf_domain);

  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_set_ims_test_mode
===========================================================================*/
int TOF_request_set_ims_test_mode(boolean ims_test_mode)
{
  RIL_Ims_Reg_Info  ims_req_info;
  memset(&ims_req_info,0,sizeof(RIL_Ims_Reg_Info));

  ims_req_info.ims_test_mode = ims_test_mode;
  if(ril_request_set_ims_reg_info(REQUEST_IMS_TEST_MODE, ims_req_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_set_ims_test_mode : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  printf("[TOF]TOF_request_set_ims_test_mode() ims_test_mode =%d\n",ims_req_info.ims_test_mode);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_get_ims_test_mode
===========================================================================*/
int TOF_request_get_ims_test_mode(boolean *ims_test_mode)
{
  RIL_Ims_Reg_Info  ims_req_info;
  memset(&ims_req_info,0,sizeof(RIL_Ims_Reg_Info)); 

  if(ril_request_get_ims_reg_info(REQUEST_IMS_TEST_MODE, &ims_req_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_get_ims_test_mode : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  *ims_test_mode = ims_req_info.ims_test_mode;  
  printf("[TOF]TOF_request_get_ims_test_mode() ims_test_mode =%d, req_ims_test_mode =%d\n",*ims_test_mode,ims_req_info.ims_test_mode);

  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_set_sip_local_port
===========================================================================*/
int TOF_request_set_sip_local_port(uint16 local_port)
{
  RIL_Ims_Sip_Info  ims_sip_req_info;
  memset(&ims_sip_req_info,0,sizeof(RIL_Ims_Sip_Info));

  ims_sip_req_info.sip_local_port = local_port;
  if(ril_request_set_ims_sip_info(REQUEST_LOCAL_PORT, ims_sip_req_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_set_sip_local_port : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  printf("[TOF]TOF_request_set_sip_local_port() sip_local_port =%d\n",ims_sip_req_info.sip_local_port);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_get_sip_local_port
===========================================================================*/
int TOF_request_get_sip_local_port(uint16 *local_port)
{
  RIL_Ims_Sip_Info  ims_sip_req_info;
  memset(&ims_sip_req_info,0,sizeof(RIL_Ims_Sip_Info)); 

  if(ril_request_get_ims_sip_info(REQUEST_LOCAL_PORT, &ims_sip_req_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_get_sip_local_port : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  *local_port = ims_sip_req_info.sip_local_port;  
  printf("[TOF]TOF_request_get_sip_local_port() local_port =%d, sip_local_port =%d\n",*local_port,ims_sip_req_info.sip_local_port);

  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_set_sip_reg_timer
===========================================================================*/
int TOF_request_set_sip_reg_timer(uint32 reg_timer)
{
  RIL_Ims_Sip_Info  ims_sip_req_info;
  memset(&ims_sip_req_info,0,sizeof(RIL_Ims_Sip_Info));

  ims_sip_req_info.timer_sip_reg = reg_timer;
  if(ril_request_set_ims_sip_info(REQUEST_REG_TIMER, ims_sip_req_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_set_sip_reg_timer : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  printf("[TOF]TOF_request_set_sip_reg_timer() timer_sip_reg =%d\n",ims_sip_req_info.timer_sip_reg);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_get_sip_reg_timer
===========================================================================*/
int TOF_request_get_sip_reg_timer(uint32 *reg_timer)
{
  RIL_Ims_Sip_Info  ims_sip_req_info;
  memset(&ims_sip_req_info,0,sizeof(RIL_Ims_Sip_Info)); 

  if(ril_request_get_ims_sip_info(REQUEST_REG_TIMER, &ims_sip_req_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_get_sip_reg_timer : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  *reg_timer = ims_sip_req_info.timer_sip_reg;  
  printf("[TOF]TOF_request_get_sip_reg_timer() reg_timer =%d, timer_sip_reg =%d\n",*reg_timer,ims_sip_req_info.timer_sip_reg);

  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_set_sip_subscribe_timer
===========================================================================*/
int TOF_request_set_sip_subscribe_timer(uint32 subsc_timer)
{
  RIL_Ims_Sip_Info  ims_sip_req_info;
  memset(&ims_sip_req_info,0,sizeof(RIL_Ims_Sip_Info));

  ims_sip_req_info.subscribe_timer = subsc_timer;
  if(ril_request_set_ims_sip_info(REQUEST_SUBSCRIBE_TIMER, ims_sip_req_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_set_sip_subscribe_timer : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  printf("[TOF]TOF_request_set_sip_subscribe_timer() subscribe_timer =%d\n",ims_sip_req_info.subscribe_timer);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_request_get_sip_subscribe_timer
===========================================================================*/
int TOF_request_get_sip_subscribe_timer(uint32 *subsc_timer)
{
  RIL_Ims_Sip_Info  ims_sip_req_info;
  memset(&ims_sip_req_info,0,sizeof(RIL_Ims_Sip_Info)); 

  if(ril_request_get_ims_sip_info(REQUEST_SUBSCRIBE_TIMER, &ims_sip_req_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_get_sip_subscribe_timer : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  *subsc_timer = ims_sip_req_info.subscribe_timer;  
  printf("[TOF]TOF_request_get_sip_subscribe_timer() subsc_timer =%d, subscribe_timer =%d\n",*subsc_timer,ims_sip_req_info.subscribe_timer);

  return TOF_SUCCESS;
}

#endif /* TOF_IMS_SUPPORT */

#ifdef TOF_IMSA_SUPPORT
/*===========================================================================
  FUNCTION  TOF_request_get_voip_srv_status
===========================================================================*/
int TOF_request_get_voip_srv_status(uint8 *voip_srv_status)
{
  RIL_Imsa_Service_Status_Info imsa_service_status_info;
  
  memset(&imsa_service_status_info,0,sizeof(RIL_Imsa_Service_Status_Info));  

  if(ril_request_get_service_status_info((int)REQUEST_VOIP_SERVICE_STATUS, &imsa_service_status_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_get_voip_srv_status : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  *voip_srv_status = imsa_service_status_info.voip_service_status;  
  printf("[TOF]TOF_request_get_voip_srv_status() voip_srv_status =%d, voip_service_status =%d\n",
                                            *voip_srv_status,imsa_service_status_info.voip_service_status);

  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_request_get_ims_srv_status
===========================================================================*/
int TOF_request_get_ims_srv_status(tof_Imsa_Reg_Status_Info *ims_reg_stat)
{
  RIL_Imsa_Reg_Status_Info imsa_reg_status_info;  

  memset(&imsa_reg_status_info, 0x0, sizeof(RIL_Imsa_Reg_Status_Info));

  if(ril_request_get_ims_reg_status_info(&imsa_reg_status_info) != RESULT_SUCCESS)
  {
    MSG_ERROR("TOF_request_get_ims_srv_status : Failed \n",0,0,0);
    return TOF_FAIL;
  }

  ims_reg_stat->ims_registered = imsa_reg_status_info.ims_registered;
  ims_reg_stat->ims_registration_failure_error_code = imsa_reg_status_info.ims_registration_failure_error_code;
 
  printf("[TOF]TOF_request_get_ims_srv_status() ims_registered =%d, failure_error_code =%d\n",
                                            ims_reg_stat->ims_registered,ims_reg_stat->ims_registration_failure_error_code);

  return TOF_SUCCESS;
}

#endif /* TOF_IMSA_SUPPORT */

#ifdef FEATURE_TOF_AUDIO_CONTROL
int TOF_START_VOICE_CALL(void)
{
	system(START_VOICE_CALL);
	return TOF_SUCCESS;
}

int TOF_END_VOICE_CALL(void)
{
	system(END_VOICE_CALL);
	return TOF_SUCCESS;
}

int TOF_AUDIO_LOOBACK(void)
{
	system(AUDIO_LOOPBACK);
	return TOF_SUCCESS;
}

int TOF_TONE_PLAY(void)
{
	system(TONE_PLAY);
	return TOF_SUCCESS;
}
#endif /* FEATURE_TOF_AUDIO_CONTROL */

/*===========================================================================
  FUNCTION  TOF_setRingIndicatorLow
===========================================================================*/
void TOF_setRingIndicatorLow(void)
{
  printf("TOF_setRingIndicatorLow\n");

  if(0 == gpio_is_exported(TOF_RING_GPIO))
    {
    if(gpio_export(TOF_RING_GPIO))
      {
        printf("TOF_gpio_config : Error! Exporting is failed for GPIO %d\n",TOF_RING_GPIO);
      }
    }
  gpio_set_dir(TOF_RING_GPIO,GPIO_OUTPUT);
  gpio_set_val(TOF_RING_GPIO,GPIO_LOW);
}

int TOF_change_usb_composition(char *idproduct)
{
	printf("Change USB composition : %s\n", idproduct);
	return change_usb_composition(idproduct, 0);
}

int TOF_get_enabled_usb_composition(void)
{
	printf("get enable usb composition\n");
	return get_enabled_usb_composition();
}

int TOF_disable_usb_composition(void)
{
	printf("disable usb composition\n");
	return disable_usb_composition();
}

int TOF_get_usb_mode(char *buf)
{
	printf("get_usb_mode\n");
	return get_usb_mode(buf);
}

int TOF_change_usb_mode(char *mode)
{
	printf("change_usb_mode\n");
	return change_usb_mode(mode);
}

int TOF_get_usb_storage_state(char *state)
{
	printf("get_usb_storage_state\n");
	return get_usb_storage_state(state);
}

/*===========================================================================
  FUNCTION  TOF_request_get_thermal_management_info
===========================================================================*/
int TOF_request_get_thermal_management_info(tof_thermal_info *info)
{
  FILE* pinfo;
  FILE* ptemp;
  
  printf("DEBUG\n");
  if((ptemp = fopen(THERMAL_TEMP_FILE, "r")) == NULL)//Get current temperature from /sys/class/thermal/thermal_zone2/temp
  {
    return TOF_FAIL;
  }
  fscanf(ptemp,"%d",&info->cur_temperature);

  if((pinfo = fopen(THERMAL_INFO_FILE, "r")) == NULL)//Get Thermal information from /var/volatile/tmp/thermal_info
  {
    return TOF_FAIL;
  }
  fscanf(pinfo,"%d:%d:%d",&info->cur_action_lvl, &info->thresh_trig, &info->thresh_clr);

  fclose(pinfo);
  fclose(ptemp);

  return TOF_SUCCESS;
}


/*===========================================================================
  FUNCTION  TOF_setClockConfig
===========================================================================*/
int TOF_setClockConfig(boolean nitzEnable,
                            boolean gnssEnable,
                            boolean ntpEnable,
                            char* ntpServerUrl)
{
  int pid = -1;
  FILE *fp = NULL;  
  int check_param,int_nitz, int_gnss, int_ntp = 0;
      
  printf("TOF_setConfigClock %d,%d,%d,%s\n",nitzEnable,gnssEnable,ntpEnable,ntpServerUrl);
  int_nitz = nitzEnable;
  int_gnss = gnssEnable;
  int_ntp = ntpEnable;
  check_param = int_nitz + int_gnss + int_ntp;
  if(check_param != 1)
  { 
    printf("Invalid paramter input!\n");
    printf("Please choose just one clocksource to be enabled\n");
    return TOF_FAIL;
  }

	if(int_gnss == 1)
	{
		printf("GNSS time is not supported for now\n");
		return TOF_FAIL;
	}

  //Get PID of time_daemon
  pid = GetPIDbyName(TIME_DAEMON_NAME);  
  if(-1 != pid)
    {
      //Kill Currently running time_daemon
      kill(pid, SIGKILL);
    }

  if(TRUE == nitzEnable)
    {
      //Save clock configuration
      write_clock_config(CLK_NITZ, DEFAULT_GMT);
      fp = popen("start-stop-daemon -S -b -a /usr/bin/time_daemon", "r");
      if (fp == NULL)
        {
          printf("failed to popen, run system cmd\n");
          system("start-stop-daemon -S -b -a /usr/bin/time_daemon");
        }
      else
        {          
          pclose(fp);
        }
    }
  else if(TRUE == gnssEnable)
    {
      write_clock_config(CLK_GNSS, DEFAULT_GMT);
      fp = popen("start-stop-daemon -S -b -a /usr/bin/time_daemon -- 2", "r");
      if (fp == NULL)
        {
          printf("failed to popen, run system cmd\n");
          system("start-stop-daemon -S -b -a /usr/bin/time_daemon -- 2");
        }
      else
        {          
          pclose(fp);
        }
    }
  else if(TRUE == ntpEnable)
    {
      write_ntp_config(ntpServerUrl,DEFAULT_NTP_PORT);
      write_clock_config(CLK_NTP, DEFAULT_GMT);
      fp = popen("start-stop-daemon -S -b -a /usr/bin/time_daemon -- 3", "r");
      if (fp == NULL)
        {
          printf("failed to popen, run system cmd\n");
          system("start-stop-daemon -S -b -a /usr/bin/time_daemon -- 3");
        }
      else
        {
          pclose(fp);
        }
    }
  return TOF_SUCCESS;
}

/*===========================================================================
  FUNCTION  TOF_getCurrentClock
===========================================================================*/
int TOF_getCurrentClock(int *clk_source)
{
  int rc, gmt =0;
  rc = read_clock_config(clk_source, &gmt);
  if(rc == 0)
    return TOF_SUCCESS;
  else
    return TOF_FAIL;
}

int TOF_set_reboot(char *reason)
{
  int ret = TOF_FAIL;
  printf("TOF_set_reboot : %s \n",reason);

  if(0 == write_reboot_reason(reason))
    {
      ret = ril_request_hk_modem_reset();
    }
  return ret;
}

int TOF_get_reboot(char *reason)
{
  if(0 != read_reboot_reason(reason))
    return TOF_FAIL;
  else
    return TOF_SUCCESS;
}

