#ifndef	LGIT_TOF_DEFINITION_H
#define	LGIT_TOF_DEFINITION_H
/******************************************************************************
  @file    LGIT_TOF_DEFINITION_H
  @brief   lgit tof_api lib

  DESCRIPTION
  Define infomation for app layer
  
  ---------------------------------------------------------------------------
  Copyright (c) 2016 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/
#include "comdef.h"
#include "stdint.h"


#ifdef __cplusplus
  extern "C" {
#endif

/*=========================================================================*/
// Common Definitions
/*=========================================================================*/

#ifndef TRUE
#define TRUE                              (1)
#endif
#ifndef FALSE
#define FALSE                            (0)
#endif

#ifndef HIGH
#define HIGH                              (1)
#endif
#ifndef LOW
#define LOW                            (0)
#endif

/* TOF API Return Value */
#define TOF_SUCCESS               (0)
#define TOF_FAIL                      (1)
#define TOF_HANDLE_FAIL        (2)

//Error Code for SIM API +100 START
#define TOF_NO_SIM_FAIL        (101) //NoSIMPresentException
#define TOF_PIN_AUTH_FAIL        (102) //PINAuthenticationFailedException
#define TOF_SIM_IO_FAIL        (103) //SIMIOException
#define TOF_SIM_FAIL        (104) //SIMException
//Error Code for SIM API +150 END

#define TOF_RING_GPIO        (43)



/*=========================================================================*/
// Common Type Definition
/*=========================================================================*/

/* This group are the deprecated types.	Their use should be
** discontinued and new code should use the types above
*/
typedef	unsigned char     BOOL;      /* Unsigned 8	bit value */
#ifndef QCMAP_TOF_H
typedef	unsigned char     bool;      /* Unsigned 8	bit value */
#endif
typedef	unsigned char     UINT8; /* Boolean value type. */
typedef	unsigned short    UINT16;    /* Unsigned 16 bit value */
typedef	unsigned int        UINT; /* Unsigned 32 bit value type. */
typedef	unsigned long int UINT32;    /* Unsigned 32 bit value */

typedef	signed char        INT8;        /* Signed 8bit value */
typedef	signed short       INT16;      /* Signed 16 bit value */
typedef	signed long int	    INT32;      /* Signed 32 bit value */

typedef	unsigned char    CHAR;        /* Unsigned 8	bit value type. */
typedef	unsigned char    BYTE;        /* Unsigned 8	bit value type. */
typedef	unsigned short   WORD;       /* Unsinged 16 bit value type. */
typedef	unsigned long    DWORD;     /* Unsigned 32 bit value type. */

typedef unsigned long qword[ 2 ];

typedef char *PCHAR;
typedef unsigned long ULONG;
typedef ULONG *PULONG;

typedef int HANDLE;
#define INVALID_HANDLE_VALUE QMI_INVALID_CLIENT_HANDLE

//Main CallBack
typedef struct
{
	DWORD dwEvent;

	uint32 wParam;
	boolean wParam_malloc;
	
	uint32 lParam;
	boolean lParam_malloc;
	
} TOF_EVENT_NOTIFY_TYPE;

typedef uint64                sys_band_mask_type;

/*=========================================================================*/
// Device Information API
/*=========================================================================*/
/*---------------------------------------------------------------------------
  TOF_request_get_basebandversion
---------------------------------------------------------------------------*/
#define TOF_DMSI_SW_VERSION_LEN           (20)
#define TOF_DMSI_ASIC_NAME_LEN            (20)
#define TOF_DMSI_MODEL_NAME_LEN           (30)
#define TOF_DMSI_SW_BUILD_DATE_LEN        (6) // yymmdd
#define TOF_DMSI_SW_BUILD_TIME_LEN        (8) // hh:mm:ss
#define TOF_DMSI_BOOT_VERSION_LEN         (10)
#define TOF_DMSI_CAL_INFORMATION_LEN    (30)
#define TOF_DMSI_HW_VERSION_LEN         (10)

#define TOF_DMSI_EXCEPTION_SW_VERSION_LEN   (20)
#define TOF_DMSI_EXCEPTION_BUILD_DATE_LEN   (15) // yyyy/mm/dd
#define TOF_DMSI_EXCEPTION_BUILD_TIME_LEN   (10) // hh:mm:ss
#define TOF_DMSI_EXCEPTION_FILE_NAME_LEN    (50)
#define TOF_DMSI_EXCEPTION_MESSAGE_LEN       (80)
#define TOF_DMSI_EXCEPTION_INFO_MAX_CNT     (3)


/** @addtogroup dms_qmi_messages
    @{
  */
/** Response Message; Queries the current operating mode of the device. */
typedef struct {
  /* Mandatory */
  /*  Operating Mode */
  char modem_sw_version[TOF_DMSI_SW_VERSION_LEN+1];

  /* Optional */
  /* Chip Solution Name */
  uint8_t chip_solution_name_valid;   
  char chip_solution_name[TOF_DMSI_ASIC_NAME_LEN+1];

  /* Optional */
  /* Model Name */
  uint8_t model_name_valid;   
  char model_name[TOF_DMSI_MODEL_NAME_LEN+1];

  /* Optional */
  /* Build Date */ 
  uint8_t build_date_valid;     
  char build_date[TOF_DMSI_SW_BUILD_DATE_LEN+1]; 

  /* Optional */
  /* Build Time */
  uint8_t build_time_valid;   
  char build_time[TOF_DMSI_SW_BUILD_TIME_LEN+1];

  /* Mandatory */
  /*  modem_boot_version */
  char modem_boot_version[TOF_DMSI_BOOT_VERSION_LEN+1];

  /* Mandatory */
  /*  cal_info_version */
  char cal_info_version[TOF_DMSI_CAL_INFORMATION_LEN+1];

    /* Mandatory */
  /*  modem_hw_version */
  char modem_hw_version[TOF_DMSI_HW_VERSION_LEN+1];
  
}tof_dms_get_modem_sw_version_resp_msg;  /* Message */

/*---------------------------------------------------------------------------
  TOF_wifi_connect
---------------------------------------------------------------------------*/
#define FEATURE_TOF_WIFI
#ifdef FEATURE_TOF_WIFI
#define WIFI_BUFFER_MAX_LEN 64
#endif



/*---------------------------------------------------------------------------
  TOF_request_set_modem_mode
---------------------------------------------------------------------------*/
typedef enum
{
  MODEM_RESET = 0,
  MODEM_OFFLINE,
  MODEM_FTM = 7,
  MODEM_LPM,
  MODEM_ONLINE,
  UIM_POWERDOWN,
  UIN_POWERUP
} MODEM_MODE_TYPE;

/*---------------------------------------------------------------------------
  TOF_request_set_maxpwr
---------------------------------------------------------------------------*/
typedef struct {
  uint8_t on_off;
  uint8_t rat;
  uint32_t channel_freq;
  uint8_t tx_power;  
}tof_dms_max_power_type_v01;  /* Type */

/*=========================================================================*/
// USIM(User Identity Module) API
/*=========================================================================*/

/*---------------------------------------------------------------------------
  TOF_request_get_sim_status
---------------------------------------------------------------------------*/

#define RIL_CARD_MAX_APPS     8

typedef enum {
    RIL_CARDSTATE_ABSENT   = 0,
    RIL_CARDSTATE_PRESENT  = 1,
    RIL_CARDSTATE_ERROR    = 2
} RIL_CardState;

typedef enum {
    RIL_PERSOSUBSTATE_UNKNOWN                   = 0, /* initial state */
    RIL_PERSOSUBSTATE_IN_PROGRESS               = 1, /* in between each lock transition */
    RIL_PERSOSUBSTATE_READY                     = 2, /* when either SIM or RUIM Perso is finished
                                                        since each app can only have 1 active perso
                                                        involved */
    RIL_PERSOSUBSTATE_SIM_NETWORK               = 3,
    RIL_PERSOSUBSTATE_SIM_NETWORK_SUBSET        = 4,
    RIL_PERSOSUBSTATE_SIM_CORPORATE             = 5,
    RIL_PERSOSUBSTATE_SIM_SERVICE_PROVIDER      = 6,
    RIL_PERSOSUBSTATE_SIM_SIM                   = 7,
    RIL_PERSOSUBSTATE_SIM_NETWORK_PUK           = 8, /* The corresponding perso lock is blocked */
    RIL_PERSOSUBSTATE_SIM_NETWORK_SUBSET_PUK    = 9,
    RIL_PERSOSUBSTATE_SIM_CORPORATE_PUK         = 10,
    RIL_PERSOSUBSTATE_SIM_SERVICE_PROVIDER_PUK  = 11,
    RIL_PERSOSUBSTATE_SIM_SIM_PUK               = 12,
    RIL_PERSOSUBSTATE_RUIM_NETWORK1             = 13,
    RIL_PERSOSUBSTATE_RUIM_NETWORK2             = 14,
    RIL_PERSOSUBSTATE_RUIM_HRPD                 = 15,
    RIL_PERSOSUBSTATE_RUIM_CORPORATE            = 16,
    RIL_PERSOSUBSTATE_RUIM_SERVICE_PROVIDER     = 17,
    RIL_PERSOSUBSTATE_RUIM_RUIM                 = 18,
    RIL_PERSOSUBSTATE_RUIM_NETWORK1_PUK         = 19, /* The corresponding perso lock is blocked */
    RIL_PERSOSUBSTATE_RUIM_NETWORK2_PUK         = 20,
    RIL_PERSOSUBSTATE_RUIM_HRPD_PUK             = 21,
    RIL_PERSOSUBSTATE_RUIM_CORPORATE_PUK        = 22,
    RIL_PERSOSUBSTATE_RUIM_SERVICE_PROVIDER_PUK = 23,
    RIL_PERSOSUBSTATE_RUIM_RUIM_PUK             = 24
} RIL_PersoSubstate;

typedef struct {
    RIL_PersoSubstate depersonalizationType;
    char             *depersonalizationCode;
} RIL_Depersonalization;


typedef enum {
    RIL_APPSTATE_ILLEGAL               = -1,
    RIL_APPSTATE_UNKNOWN               = 0,
    RIL_APPSTATE_DETECTED              = 1,
    RIL_APPSTATE_PIN                   = 2, /* If PIN1 or UPin is required */
    RIL_APPSTATE_PUK                   = 3, /* If PUK1 or Puk for UPin is required */
    RIL_APPSTATE_SUBSCRIPTION_PERSO    = 4, /* perso_substate should be look at
                                               when app_state is assigned to this value */
    RIL_APPSTATE_READY                 = 5
} RIL_AppState;

typedef enum {
    RIL_PINSTATE_UNKNOWN              = 0,
    RIL_PINSTATE_ENABLED_NOT_VERIFIED = 1,
    RIL_PINSTATE_ENABLED_VERIFIED     = 2,
    RIL_PINSTATE_DISABLED             = 3,
    RIL_PINSTATE_ENABLED_BLOCKED      = 4,
    RIL_PINSTATE_ENABLED_PERM_BLOCKED = 5
} RIL_PinState;

typedef enum {
  RIL_APPTYPE_UNKNOWN = 0,
  RIL_APPTYPE_SIM     = 1,
  RIL_APPTYPE_USIM    = 2,
  RIL_APPTYPE_RUIM    = 3,
  RIL_APPTYPE_CSIM    = 4,
  RIL_APPTYPE_ISIM    = 5
} RIL_AppType;

typedef struct
{
  RIL_AppType      app_type;
  RIL_AppState     app_state;
  RIL_PersoSubstate perso_substate; /* applicable only if app_state ==
                                       RIL_APPSTATE_SUBSCRIPTION_PERSO */
  char             *aid_ptr;        /* null terminated string, e.g., from 0xA0, 0x00 -> 0x41,
                                       0x30, 0x30, 0x30 */
  char             *app_label_ptr;  /* null terminated string */
  int              pin1_replaced;   /* applicable to USIM, CSIM & ISIM */
  RIL_PinState     pin1;
  RIL_PinState     pin2;
} RIL_AppStatus;

/* Deprecated, use RIL_CardStatus_v6 */
typedef struct
{
  RIL_CardState card_state;
  RIL_PinState  universal_pin_state;             /* applicable to USIM and CSIM: RIL_PINSTATE_xxx */
  int           gsm_umts_subscription_app_index; /* value < RIL_CARD_MAX_APPS, -1 if none */
  int           cdma_subscription_app_index;     /* value < RIL_CARD_MAX_APPS, -1 if none */
  int           num_applications;                /* value <= RIL_CARD_MAX_APPS */
  RIL_AppStatus applications[RIL_CARD_MAX_APPS];
} RIL_CardStatus_v5;

typedef struct
{
  RIL_CardState card_state;
  RIL_PinState  universal_pin_state;             /* applicable to USIM and CSIM: RIL_PINSTATE_xxx */
  int           gsm_umts_subscription_app_index; /* value < RIL_CARD_MAX_APPS, -1 if none */
  int           cdma_subscription_app_index;     /* value < RIL_CARD_MAX_APPS, -1 if none */
  int           ims_subscription_app_index;      /* value < RIL_CARD_MAX_APPS, -1 if none */
  int           num_applications;                /* value <= RIL_CARD_MAX_APPS */
  RIL_AppStatus applications[RIL_CARD_MAX_APPS];
} RIL_CardStatus_v6;

typedef struct
{
  RIL_PinState     pin1_state;
  unsigned char      pin1_num_retries;
  unsigned char      puk1_num_retries;
  RIL_PinState     pin2_state;
  unsigned char      pin2_num_retries;
  unsigned char      puk2_num_retries;
} RIL_PinStatus;

/*=========================================================================*/
// Network Infortation API
/*=========================================================================*/

#define PREF_NET_MODE_LTE_CMDA_EVDO_GSM_WCDMA	4		/* Determine Mode Automatically */
#define PREF_NET_MODE_CDMA_ONLY  									9		/* CDMA Only */
#define PREF_NET_MODE_EVDO_ONLY  									10	/* HDR Only */
#define PREF_NET_MODE_GSM_ONLY  									13	/* GSM Only */
#define PREF_NET_MODE_WCDMA_ONLY  								14	/* WCDMA Only */
#define PREF_NET_MODE_GSM_WCDMA 									17	/* GSM And WCDMA Only */
#define PREF_NET_MODE_CDMA_EVDO_AUTO							19	/* CDMA And HDR Only */
#define PREF_NET_MODE_LTE_ONLY										30	/* LTE Only */
#define PREF_NET_MODE_LTE_WCDMA 									35	/*WCDMA And LTE Only */
#define PREF_NET_MODE_LTE_CDMA_EVDO  							36	/* CDMA HDR And LTE Only */ 

#define SYS_BM_64BIT( val )   ((uint64)1<<(int)(val))

/* If there is a new band class, append to the end of list.
   per 3GPP 36101-830.
*/
/** LTE system band classes.
*/
typedef enum {
  SYS_SBAND_LTE_EUTRAN_BAND1 = 0,
  /**< UL:1920-1980; DL:2110-2170. */

  SYS_SBAND_LTE_EUTRAN_BAND2 = 1,
  /**< UL:1850-1910; DL:1930-1990. */

  SYS_SBAND_LTE_EUTRAN_BAND3 = 2,
  /**< UL:1710-1785; DL:1805-1880. */

  SYS_SBAND_LTE_EUTRAN_BAND4 = 3,
  /**< UL:1710-1755; DL:2110-2155. */

  SYS_SBAND_LTE_EUTRAN_BAND5 = 4,
  /**< UL: 824-849; DL: 869-894. */

  SYS_SBAND_LTE_EUTRAN_BAND6 = 5,
  /**< UL: 830-840; DL: 875-885. */

  SYS_SBAND_LTE_EUTRAN_BAND7 = 6,
  /**< UL:2500-2570; DL:2620-2690. */

  SYS_SBAND_LTE_EUTRAN_BAND8 = 7,
  /**< UL: 880-915; DL: 925-960. */

  SYS_SBAND_LTE_EUTRAN_BAND9 = 8,
  /**< UL:1749.9-1784.9; DL:1844.9-1879.9. */

  SYS_SBAND_LTE_EUTRAN_BAND10 = 9,
  /**< UL:1710-1770; DL:2110-2170. */

  SYS_SBAND_LTE_EUTRAN_BAND11 = 10,
  /**< UL:1427.9-1452.9; DL:1475.9-1500.9. */

  SYS_SBAND_LTE_EUTRAN_BAND12 = 11,
  /**< UL:698-716; DL:728-746. */

  SYS_SBAND_LTE_EUTRAN_BAND13 = 12,
  /**< UL: 777-787; DL: 746-756. */
} sys_sband_lte_e_type;

#define SYS_BAND_MASK_LTE_EMPTY             0     /**< No LTE band selected. */
#define SYS_BAND_MASK_LTE_BAND1             ((sys_band_mask_type) SYS_BM_64BIT(SYS_SBAND_LTE_EUTRAN_BAND1))
    /**< Acquire UL: 1920-1980; DL: 2110-2170. */
#define SYS_BAND_MASK_LTE_BAND2             ((sys_band_mask_type) SYS_BM_64BIT(SYS_SBAND_LTE_EUTRAN_BAND2))
    /**< Acquire UL: 1850-1910; DL: 1930-1990. */
#define SYS_BAND_MASK_LTE_BAND3             ((sys_band_mask_type) SYS_BM_64BIT(SYS_SBAND_LTE_EUTRAN_BAND3))
    /**< Acquire UL: 1710-1785; DL: 1805-1880. */
#define SYS_BAND_MASK_LTE_BAND4             ((sys_band_mask_type) SYS_BM_64BIT(SYS_SBAND_LTE_EUTRAN_BAND4))
    /**< Acquire UL: 1710-1755; DL: 2110-2115. */
#define SYS_BAND_MASK_LTE_BAND5             ((sys_band_mask_type) SYS_BM_64BIT(SYS_SBAND_LTE_EUTRAN_BAND5))
    /**< Acquire UL: 824-849; DL: 869-894. */
#define SYS_BAND_MASK_LTE_BAND8             ((sys_band_mask_type) SYS_BM_64BIT(SYS_SBAND_LTE_EUTRAN_BAND8))
    /**< Acquire UL: 880-915; DL: 925-960. */
#define SYS_BAND_MASK_LTE_BAND13             ((sys_band_mask_type) SYS_BM_64BIT(SYS_SBAND_LTE_EUTRAN_BAND13))
    /**< Acquire UL: 777-787; DL: 746-756. */

typedef struct{
  int reg_status;  
  int lac;
  int cell_id;
  int rat;
  int reject_cause;
} tof_registration_status_type;

typedef struct {
    int signalStrength;  /* Valid values are (0-63) as defined in 3gpp TS 45.008 Section 8.1.4 */
    int signalStrengt_dBm;  /*Receive Level in dbm. [-109..-48] */
} TOF_GSM_SignalStrength;

typedef struct {
    int signalStrength;  /* Valid values are (0-31, 99) as defined in TS 27.007 8.5 */
    int bitErrorRate;  /*ECIO value representing negative 0.5 dB
                                  increments, i.e., 2 means -1 dB (14 means -7 dB, 63 means -31.5 dB).
                                */
} TOF_GW_SignalStrength;


typedef struct {
    int dbm;  /* Valid values are positive integers.  This value is the actual RSSI value
               * multiplied by -1.  Example: If the actual RSSI is -75, then this response
               * value will be 75.
               * shpark, modem dbm value * -1
               */
    int ecio; /* Valid values are positive integers.  This value is the actual Ec/Io multiplied
               * by -10.  Example: If the actual Ec/Io is -12.5 dB, then this response value
               * will be 125.
               * shpark, modem ecio value range: 0(0 db) ~ 63(-31.5db)
               *             modem ecio value * 5
               */
} TOF_CDMA_SignalStrength;


typedef struct {
    int dbm;  /* Valid values are positive integers.  This value is the actual RSSI value
               * multiplied by -1.  Example: If the actual RSSI is -75, then this response
               * value will be 75.
               * shpark, modem dbm value * -1
               */
    int ecio; /* Valid values are positive integers.  This value is the actual Ec/Io multiplied
               * by -10.  Example: If the actual Ec/Io is -12.5 dB, then this response value
               * will be 125.
               * shpark, modem ecio value range: 0(0 db) ~ 63(-31.5db)
               *             modem ecio value * 5
               */
    int signalNoiseRatio; /* Valid values are 0-8.  8 is the highest signal to noise ratio. */
} TOF_EVDO_SignalStrength;

typedef struct {
    int signalStrength;  /* Valid values are (0-31, 99) as defined in TS 27.007 8.5 */
    int rsrp;            /* The current Reference Signal Receive Power in dBm multipled by -1.
                          * Range: 44 to 140 dBm
                          * INT_MAX: 0x7FFFFFFF denotes invalid value.
                          * Reference: 3GPP TS 36.133 9.1.4 */
    int rsrq;            /* The current Reference Signal Receive Quality in dB multiplied by -1.
                          * Range: 20 to 3 dB.
                          * INT_MAX: 0x7FFFFFFF denotes invalid value.
                          * Reference: 3GPP TS 36.133 9.1.7 */
    int rssnr;           /* The current reference signal signal-to-noise ratio in 0.1 dB units.
                          * Range: -200 to +300 (-200 = -20.0 dB, +300 = 30dB).
                          * INT_MAX : 0x7FFFFFFF denotes invalid value.
                          * Reference: 3GPP TS 36.101 8.1.1 */
    int cqi;             /* The current Channel Quality Indicator.
                          * Range: 0 to 15.
                          * INT_MAX : 0x7FFFFFFF denotes invalid value.
                          * Reference: 3GPP TS 36.101 9.2, 9.3, A.4 */
} TOF_LTE_SignalStrength;

typedef struct {
    int rscp;    /* The Received Signal Code Power in dBm multipled by -1.
                  * Range : 25 to 120
                  * INT_MAX: 0x7FFFFFFF denotes invalid value.
                  * Reference: 3GPP TS 25.123, section 9.1.1.1 */
} TOF_TD_SCDMA_SignalStrength;

typedef struct {
    TOF_GSM_SignalStrength   GSM_SignalStrength;
    TOF_GW_SignalStrength   GW_SignalStrength;
    TOF_CDMA_SignalStrength CDMA_SignalStrength;
    TOF_EVDO_SignalStrength EVDO_SignalStrength;
    TOF_LTE_SignalStrength  LTE_SignalStrength;
    TOF_TD_SCDMA_SignalStrength TD_SCDMA_SignalStrength;
} TOF_SignalStrength;

TOF_SignalStrength tof_signal_strength;

typedef struct {
	uint16 mcc;
	uint16 mnc;
	char network_name[255];
} TOF_Operator_Info;


//[JIRA:AS057-737]	2017.02.20 - jaeyong1.park -PathLossCriteria getPathLossCriteria() for tof java api 
typedef struct{

 	int calculated_c1;
	/** computed C1 value,  invalid value is -1000. */	
	
	int arfcn_num;
	/** ARFCN number of the cell, invalid value is -1. 
	  This value is used to calculate the c1 value. */
	
	int arfcn_bandtype;
	/** ARFCN band of the cell, invalid value is -1 
		<band type>
		BAND_EGSM_900=0, BAND_PGSM_900=1, 	
		BAND_PCS_1900=2,  BAND_DCS_1800=3, 
		BAND_GSM_850=4, 
		MAXNO_BANDS=5, BAND_NONE=0xFF .
		This value is used to calculate the c1 value.
	*/

	int received_level_average;
	/** signal strength (RXLEV) for cell. invalid value is -1.  expressed in dBm. 
	  This value is used to calculate the c1 value. */
	
	int RXLEV_ACCESS_MIN_DBM;
	/** minimum signal strength (in RXLEV) to access cell, invalid value is -1. expressed in dBm.  
	  This value is used to calculate the c1 value. */
	
	int MS_TXPWR_MAX_CCH_DBM;
	/** max power level, valid range 0 to  31, invalid value is -1.  expressed in dBm.  
	  This value is used to calculate the c1 value.*/
	
	int POWER_OFFSET;
	/** power offset for cell, invalid value is -1. This value is used to calculate the c1 value.  */
	
	int maximum_rf_power_output;
	/** maximum power output of the mobile. Max output power in dBm.  invalid value is -1.
	  This value is used to calculate the c1 value.  */

	int calculated_c2;
	/** Disabled.	Not use anymore.
	computed C2 value. invalid value is -1000.
	Computed C2 value for a surrounding cell using the given C1 value and system information */	
	
	int CELL_RESELECT_PARAM_IND;
	/** Disabled.	Not use anymore.
	candicate cell has the cell reselection parameters present(from SI 3/4/7/8)    .
	True, if value>0, 0 is False.
	This value is used to calculate the c2 value.
	*/
	int PENALTY_TIME;
	/** Disabled.	Not use anymore.
	The additional cell reselection parameters are present for candicate cell.
	valid, if CELL_RESELECT_PARAM_IND is True.
	invalid value is -1. This value is used to calculate the c2 value.  
	*/
	
	int CELL_RESELECT_OFFSET_DB;	
	/** Disabled.	Not use anymore.
	The additional cell reselection parameters are present for candicate cell.
	valid, if CELL_RESELECT_PARAM_IND is True.
	invalid value is -1. This value is used to calculate the c2 value.  
	*/
	
	int TEMPORARY_OFFSET_DB;
	/** Disabled.	Not use anymore.
	The additional cell reselection parameters are present for candicate cell.
	valid, if CELL_RESELECT_PARAM_IND is True.
	invalid value is -1. This value is used to calculate the c2 value.  
	*/
	
}TOF_GSM_PathLossCriteria;

#define g_c1_MAX 9

typedef struct{
	TOF_GSM_PathLossCriteria info[g_c1_MAX]; /* g_c1_MAX from modem side */
} TOF_GSM_PathLossCriteria_list;

#define NAS_NMR_MAX_NUM		5
#define NAS_PLMN_LEN 3
typedef struct {
  /*  Cell id */
  uint32_t nmr_cell_id;
  /**<   Cell ID (0xFFFFFFFF indicates cell ID information is not present).
   */
  /*  PLMN */
  char nmr_plmn[NAS_PLMN_LEN];
  /**<   MCC/MNC information coded as octet 3, 4, and 5 in [S5, Section 10.5.1.3].
       (This field is ignored when nmr_cell_id is not present.)
   */
  /*  LAC */
  uint16_t nmr_lac;
  /**<   Location area code. (This field is ignored when nmr_cell_id is not present.)
   */
  /*  ARFCN */
  uint16_t nmr_arfcn;
  /**<   Absolute RF channel number.
   */
  /*  BSIC */
  uint8_t nmr_bsic;
  /**<   Base station identity code.
   */
  /*  Rx Lev */
  uint16_t nmr_rx_lev;
  /**<   Cell Rx measurement. Values range between 0 and 63, which is 
       mapped to a measured signal level: \n

       - Rxlev 0 is a signal strength less than -110 dBm \n
       - Rxlev 1 is -110 dBm to -109 dBm    \n
       - Rxlev 2 is -109 dBm to -108 dBm    \n
       - ...                                \n
       - Rxlev 62 is -49 dBm to -48 dBm     \n
       - Rxlev 63 is greater than -48 dBm
   */

  /* Path loss critera */
  TOF_GSM_PathLossCriteria pathlosscriteria;
  /**< Cell selection and reselection criteria. This structure has C1 and releated parameters for calcurating.
    */
  
}nas_nmr_cell_info_type;  /* Type */

typedef struct {
  /*  Cell id */
  uint32_t cell_id;
  /**<   Cell ID (0xFFFFFFFF indicates cell ID information is not present).
  */
  /*  PLMN */
  char plmn[NAS_PLMN_LEN];
  /**<   MCC/MNC information coded as octet 3, 4, and 5 in 
       \hyperref[STD-24008]{3GPP TS 24.008} Section 10.5.1.3. 
       (This field is ignored when cell_id is not present.)
  */
  /*  LAC */
  uint16_t lac;
  /**<   Location area code. (This field is ignored when cell_id is not present.)
  */
  /*  ARFCN */
  uint16_t arfcn;
  /**<   Absolute RF channel number.
  */
  /*  BSIC */
  uint8_t bsic;
  /**<   Base station identity code.
  */
    /*  BSIC NCC */
  uint8_t bsic_ncc;
  /**<   Base station identity code network color code
       (0xFF indicates information is not present).
  */

  /*  BSIC BCC */
  uint8_t bsic_bcc;
  /**<   Base station identity code base station color code
       (0xFF indicates information is not present).
  */
  
  /*  Timing Advance */
  uint32_t timing_advance;
  /**<   Measured delay (in bit periods; 1 bit period = 48/13 microsecond) of 
       an access burst transmission on the RACH or PRACH to the expected signal 
       from an MS at zero distance under static channel conditions.
       (0xFFFFFFFF indicates timing advance information is not present.)
  */
  /*  Rx Lev */
  uint16_t rx_lev;
  /**<   Serving cell Rx measurement. Values range between 0 and 63, which is 
       mapped to a measured signal level: \n
       - Rxlev 0 is a signal strength less than -110 dBm \n
       - Rxlev 1 is -110 dBm to -109 dBm    \n
       - Rxlev 2 is -109 dBm to -108 dBm    \n
       - ...                               \n
       - Rxlev 62 is -49 dBm to -48 dBm     \n
       - Rxlev 63 is greater than -48 dBm
  */
  /*  Rx Lev dBm*/
  int16_t rx_lev_dBm;
   /**
      - rx_lev -111 = rx_lev_dBm
   */

  /* Path loss critera */ 
  TOF_GSM_PathLossCriteria pathlosscriteria;
  /**< Cell selection and reselection criteria. 
  This structure has C1 and releated parameters for calcurating.
    */   
  
  /*  Neighbor cell information  */
  uint32_t nmr_cell_info_len;  /**< Must be set to # of elements in nmr_cell_info */
  nas_nmr_cell_info_type nmr_cell_info[NAS_NMR_MAX_NUM];
  /**<   Contains information only if neighbors are present; 
       includes: \n
       - nmr_cell_id \n
       - nmr_plmn \n
       - nmr_lac \n
       - nmr_arfcn \n
       - nmr_bsic \n
       - nmr_rx_lev
  */
  /*  Rx Lev dBm*/
  int16_t nmr_cell_info_rx_lev_dBm[NAS_NMR_MAX_NUM];
   /**
      - rx_lev -111 = nmr_cell_info_rx_lev_dBm
   */
} TOF_GSM_cellinfo;

typedef struct {
  /*  UARFCN */
  uint16_t umts_uarfcn;
  /**<   UTRA absolute RF channel number.
   */
  /*  PSC */
  uint16_t umts_psc;
  /**<   Primary scrambling code.
   */
  /*  RSCP */
  int16_t umts_rscp;
  /**<   Received signal code power.
   */
  /*  Ec/Io */
  int16_t umts_ecio;
  /**<   ECIO.
   */
}nas_umts_monitored_cell_set_info_type;  /* Type */

typedef struct {
/*  Cell id */
  uint16_t cell_id;
  /**<   Cell ID (0xFFFFFFFF indicates cell ID information is not present).
  */
  /*  PLMN */
  char plmn[NAS_PLMN_LEN];
  /**<   MCC/MNC information coded as octet 3, 4, and 5 in 
       \hyperref[STD-24008]{3GPP TS 24.008} Section 10.5.1.3. 
  */
  /*  LAC */
  uint16_t lac;
  /**<   Location area code.
    /*  RAC */
  uint16_t rac;
  /**<   Routing area code.
  */
  /*  UARFCN */
  uint16_t uarfcn;
  /**<   UTRA absolute RF channel number.
  */
  /*  PSC */
  uint16_t psc;
  /**<   Primary scrambling code.
  */
  /*  RSCP */
  int16_t rscp;
  /**<   Received signal code power; the received power on one code measured in
       dBm on the primary CPICH channel of the serving cell.
  */
  /*  Ec/Io */
  int16_t ecio;
  /**<   ECIO; the received energy per chip divided by the power density in the
       band measured in dBm on the primary CPICH channel of the serving cell.
  */
  /*  UMTS Monitored Cell info set */
  uint32_t umts_monitored_cell_len;  /**< Must be set to # of elements in umts_monitored_cell */
  nas_umts_monitored_cell_set_info_type umts_monitored_cell[NAS_NMR_MAX_NUM];
} TOF_WCDMA_cellinfo;

typedef struct {
  uint16_t pci;
  /**<   Physical cell ID. Range: 0 to 503.  */
  int16_t rsrq;
  /**<   Current RSRQ in 1/10 dB as measured by L1.  
    Range: -200 to -30 (e.g., -200 means -20.0 dB).  */
  int16_t rsrp;
  /**<   Current RSRP in 1/10 dBm as measured by L1. 
    Range: -1400 to -440 (e.g., -440 means -44.0 dBm).  */
  int16_t rssi;
  /**<   Current RSSI in 1/10 dBm as measured by L1.
    Range: -1200 to 0 (e.g., -440 means -44.0 dBm).  */
  int16_t srxlev;
  /**<   Cell selection Rx level (Srxlev) value. Range: -128 to 128. 
    (This field is only valid when ue_in_idle is TRUE.)  */
}nas_lte_ngbr_cell_type;  /* Type */

typedef struct {
 uint8_t plmn[NAS_PLMN_LEN];
  /**<   PLMN ID coded as octet 3, 4, and 5 in 
     \hyperref[STD-24008]{3GPP TS 24.008} Section 10.5.1.3. */
  uint16_t tac;
  /**<   Tracking area code. */
  uint32_t global_cell_id;
  /**<   Global cell ID in the system information block. */
  uint16_t earfcn;
  /**<   E-UTRA absolute radio frequency channel number of the serving cell. 
     Range: 0 to 65535. */
  uint16_t serving_cell_id;
  /**<   LTE serving cell ID. Range: 0 to 503. This is the cell ID of the 
    serving cell and can be found in the cell list. */
   int16_t rsrq;
  /**<   Current RSRQ in 1/10 dB as measured by L1.  
    Range: -200 to -30 (e.g., -200 means -20.0 dB).  */
  int16_t rsrp;
  /**<   Current RSRP in 1/10 dBm as measured by L1. 
    Range: -1400 to -440 (e.g., -440 means -44.0 dBm).  */
   uint8_t cell_resel_priority;
  /**<   Priority for serving frequency. Range: 0 to 7. (This field is only 
    valid when ue_in_idle is TRUE.) */
  uint8_t s_non_intra_search;
  /**<   S non-intra search threshold to control non-intrafrequency searches. 
    Range: 0 to 31. (This field is only valid when ue_in_idle is TRUE.) */
  uint8_t thresh_serving_low;
  /**<   Serving cell low threshold. Range: 0 to 31. (This field is only 
    valid when ue_in_idle is TRUE.) */
  uint8_t s_intra_search;
  /**<   S intra search threshold. Range: 0 to 31. The current cell 
    measurement must fall below this threshold to consider intrafrequency 
    for reselection. (This field is only valid when ue_in_idle is TRUE.) */

  uint32_t cells_len;  /**< Must be set to # of elements in cells, 20170222 mwkim changed uint8_t to uint32_t */ 
  nas_lte_ngbr_cell_type cells[NAS_NMR_MAX_NUM]; 
} TOF_LTE_cellinfo;

typedef struct {
	 uint8_t gsm_info_valid; 
    TOF_GSM_cellinfo   gsm_cellinfo;
	 uint8_t wcdma_info_valid;
    TOF_WCDMA_cellinfo   wcdma_cellinfo;
	 uint8_t lte_info_valid; 
    TOF_LTE_cellinfo lte_cellinfo;

//add for debug screen
	uint32_t p_tmsi;
	uint8_t network_mode;
	uint16_t mnc;
    int16_t mcc;
		
} TOF_cellinfo;

/*=========================================================================*/
// Voice Call API
/*=========================================================================*/

#define CDMA_ALPHA_INFO_BUFFER_LENGTH 64
#define CDMA_NUMBER_INFO_BUFFER_LENGTH 81

#define VOICE_NUMBER_MAX 81
#define VOICE_UUS_DATA_MAX 128
#define VOICE_CALLER_NAME_MAX 182
#define VOICE_CALL_COUNT_MAX 15


#define TOF_CDMA_MAX_NUMBER_OF_INFO_RECS 10

#define ECALL_MSD_MAX_LEN 140

typedef enum {
    TOF_CALL_ACTIVE = 0,
    TOF_CALL_HOLDING = 1,
    TOF_CALL_DIALING = 2,    /* MO call only */
    TOF_CALL_ALERTING = 3,   /* MO call only */
    TOF_CALL_INCOMING = 4,   /* MT call only */
    TOF_CALL_WAITING = 5,     /* MT call only */
    TOF_CALL_DISCONNECTING = 6,
	TOF_CALL_END = 7
} TOF_CallState;

typedef struct {
	int 						status; 		
	/*
   * For RIL_REQUEST_QUERY_CALL_FORWARD_STATUS
   * status 1 = active, 0 = not active
   *
   * For RIL_REQUEST_SET_CALL_FORWARD:
   * status is:
   * 0 = disable
   * 1 = enable
   * 2 = interrogate
   * 3 = registeration
   * 4 = erasure
   */

    int             reason;      
	/* from TS 27.007 7.11 "reason" 
    *0 = CFU
    * 1 = CFBusy
    * 2 = CFNry
    * 3 = CFNrc
    * 4 = All CF
    * 5 = All conditional CF
	 */
																 
    int             serviceClass;
	/* From 27.007 +CCFC/+CLCK "class"
       See table for Android mapping from
       MMI service code 0 means user doesn't input class 
    *SERVICE_CLASS_NONE     		= 0; // no user input
    *SERVICE_CLASS_VOICE    		= (1 << 0);
    *SERVICE_CLASS_DATA     		= (1 << 1); //synoym for 16+32+64+128
    *SERVICE_CLASS_FAX      		= (1 << 2);
    *SERVICE_CLASS_SMS      		= (1 << 3);
    *SERVICE_CLASS_DATA_SYNC 	= (1 << 4);
    *SERVICE_CLASS_DATA_ASYNC 	= (1 << 5);
    *SERVICE_CLASS_PACKET   		= (1 << 6);
    *SERVICE_CLASS_PAD      		= (1 << 7);
    *SERVICE_CLASS_MAX      		= (1 << 7); // Max SERVICE_CLASS value
    */

                                 
    int             toa;         
	/* "type" from TS 27.007 7.11 
	*129 = normal number
	*145 = international number
	*/

    char *          number;      
	/* "number" from TS 27.007 7.11. May be NULL */
	
    int             timeSeconds; 
	/* for CF no reply only 
	waiting time before call forwarded in CFNry or All conditional CF
	1 ~ 30 (sec)
	default = 20
 	*/

}TOF_CallForwardInfo;

#define TOF_USSD_MAX_DATA_LENGTH 160

/* Thermal mitigation information structure */
#define THERMAL_INFO_FILE "/var/volatile/tmp/thermal_info"
#define THERMAL_TEMP_FILE "/sys/class/thermal/thermal_zone2/temp"
typedef struct
{ 
  int cur_temperature; 
  int cur_action_lvl;
  int thresh_trig;
  int thresh_clr; 
}tof_thermal_info;


typedef struct
{
	unsigned char ussd_id;
	unsigned char dcs;
	unsigned char data_len;
	unsigned char data_buf[ TOF_USSD_MAX_DATA_LENGTH + 1 ];
} TOF_USSD_CONTEXT_INFO;

typedef struct
{
	TOF_USSD_CONTEXT_INFO	ussd_context_info;
	int		event_id;
	int		event_param;
} TOF_USSD_NOTIFY_INFO;

/* CDMA Signal Information Record as defined in C.S0005 section 3.7.5.5 */
typedef struct {
  char isPresent;    /* non-zero if signal information record is present */
  char signalType;   /* as defined 3.7.5.5-1 */
  char alertPitch;   /* as defined 3.7.5.5-2 */
  char signal;       /* as defined 3.7.5.5-3, 3.7.5.5-4 or 3.7.5.5-5 */
} TOF_CDMA_SignalInfoRecord;

/* User-to-User signaling Info activation types derived from 3GPP 23.087 v8.0 */
typedef enum {
    TOF_UUS_TYPE1_IMPLICIT = 0,
    TOF_UUS_TYPE1_REQUIRED = 1,
    TOF_UUS_TYPE1_NOT_REQUIRED = 2,
    TOF_UUS_TYPE2_REQUIRED = 3,
    TOF_UUS_TYPE2_NOT_REQUIRED = 4,
    TOF_UUS_TYPE3_REQUIRED = 5,
    TOF_UUS_TYPE3_NOT_REQUIRED = 6
} TOF_UUS_Type;

/* User-to-User Signaling Information data coding schemes. Possible values for
 * Octet 3 (Protocol Discriminator field) in the UUIE. The values have been
 * specified in section 10.5.4.25 of 3GPP TS 24.008 */
typedef enum {
    TOF_UUS_DCS_USP = 0,          /* User specified protocol */
    TOF_UUS_DCS_OSIHLP = 1,       /* OSI higher layer protocol */
    TOF_UUS_DCS_X244 = 2,         /* X.244 */
    TOF_UUS_DCS_RMCF = 3,         /* Reserved for system mangement convergence function */
    TOF_UUS_DCS_IA5c = 4          /* IA5 characters */
} TOF_UUS_DCS;

/* User-to-User Signaling Information defined in 3GPP 23.087 v8.0
 * This data is passed in TOF_ExtensionRecord and rec contains this
 * structure when type is TOF_UUS_INFO_EXT_REC */
typedef struct {
  TOF_UUS_Type    uusType;    /* UUS Type */
  TOF_UUS_DCS     uusDcs;     /* UUS Data Coding Scheme */
  int             uusLength;  /* Length of UUS Data */
  char            uusData[VOICE_UUS_DATA_MAX];    /* UUS Data */
} TOF_UUS_Info;

/** Used by TOF_REQUEST_DIAL */
typedef struct {
    char   address[VOICE_NUMBER_MAX+1];
    int clir;
        /* (same as 'n' paremeter in TS 27.007 7.7 "+CLIR"
             * clir == 0 on "use subscription default value"
             * clir == 1 on "CLIR invocation" (restrict CLI presentation)
             * clir == 2 on "CLIR suppression" (allow CLI presentation)
             */
    TOF_UUS_Info  * uusInfo;    /* NULL or Pointer to User-User Signaling Information */
} TOF_Dial;

typedef struct {
    TOF_CallState   state;
    int             index;      /* Connection Index for use with, eg, AT+CHLD */
    int             toa;        /* type of address, eg 145 = intl */
    char            isMpty;     /* nonzero if is mpty call */
    char            isMT;       /* nonzero if call is mobile terminated */
    char            als;        /* ALS line indicator if available (0 = line 1) */
    char            isVoice;    /* nonzero if this is is a voice call */
    char            isVoicePrivacy;     /* nonzero if CDMA voice privacy mode is active */
    char            number[VOICE_NUMBER_MAX+1];     /* Remote party number */
    int             numberPresentation; /* 0=Allowed, 1=Restricted, 2=Not Specified/Unknown 3=Payphone */
    char            name[VOICE_CALLER_NAME_MAX];       /* Remote party name */
    int             namePresentation; /* 0=Allowed, 1=Restricted, 2=Not Specified/Unknown 3=Payphone */
    TOF_UUS_Info    uusInfo;    /* NULL or Pointer to User-User Signaling Information */
} TOF_Call;

typedef struct {
    TOF_Call        call_info[VOICE_CALL_COUNT_MAX];
    int             call_count;      /* Current Call Count*/
} TOF_Current_Call_Info;


/* See TOF_REQUEST_LAST_CALL_FAIL_CAUSE */
typedef enum {
    CALL_FAIL_UNOBTAINABLE_NUMBER = 1,
    CALL_FAIL_NORMAL = 16,
    CALL_FAIL_BUSY = 17,
    CALL_FAIL_CONGESTION = 34,
    CALL_FAIL_ACM_LIMIT_EXCEEDED = 68,
    CALL_FAIL_CALL_BARRED = 240,
    CALL_FAIL_FDN_BLOCKED = 241,
    CALL_FAIL_IMSI_UNKNOWN_IN_VLR = 242,
    CALL_FAIL_IMEI_NOT_ACCEPTED = 243,
    CALL_FAIL_DIAL_MODIFIED_TO_USSD = 244, /* STK Call Control */
    CALL_FAIL_DIAL_MODIFIED_TO_SS = 245,
    CALL_FAIL_DIAL_MODIFIED_TO_DIAL = 246,
    CALL_FAIL_CDMA_LOCKED_UNTIL_POWER_CYCLE = 1000,
    CALL_FAIL_CDMA_DROP = 1001,
    CALL_FAIL_CDMA_INTERCEPT = 1002,
    CALL_FAIL_CDMA_REORDER = 1003,
    CALL_FAIL_CDMA_SO_REJECT = 1004,
    CALL_FAIL_CDMA_RETRY_ORDER = 1005,
    CALL_FAIL_CDMA_ACCESS_FAILURE = 1006,
    CALL_FAIL_CDMA_PREEMPTED = 1007,
    CALL_FAIL_CDMA_NOT_EMERGENCY = 1008, /* For non-emergency number dialed during emergency callback mode */
    CALL_FAIL_CDMA_ACCESS_BLOCKED = 1009, /* CDMA network access probes blocked */
    CALL_FAIL_REMOTE_REJECTED = 2001, //jaeyong1.park 2017-01-31
    CALL_FAIL_NO_NETWORK = 2002, //jaeyong1.park 2017-01-31
    CALL_FAIL_NO_ANSWER = 2003, //jaeyong1.park 2017-01-31
    CALL_FAIL_ERROR_UNSPECIFIED = 0xffff
} TOF_LastCallFailCause;

/* Display Info Rec as defined in C.S0005 section 3.7.5.1
   Extended Display Info Rec as defined in C.S0005 section 3.7.5.16
   Note: the Extended Display info rec contains multiple records of the
   form: display_tag, display_len, and display_len occurrences of the
   chari field if the display_tag is not 10000000 or 10000001.
   To save space, the records are stored consecutively in a byte buffer.
   The display_tag, display_len and chari fields are all 1 byte.
*/

typedef struct {
  char alpha_len;
  char alpha_buf[CDMA_ALPHA_INFO_BUFFER_LENGTH];
} TOF_CDMA_DisplayInfoRecord;

/* Called Party Number Info Rec as defined in C.S0005 section 3.7.5.2
   Calling Party Number Info Rec as defined in C.S0005 section 3.7.5.3
   Connected Number Info Rec as defined in C.S0005 section 3.7.5.4
*/

typedef struct {
  char len;
  char buf[CDMA_NUMBER_INFO_BUFFER_LENGTH];
  char number_type;
  char number_plan;
  char pi;
  char si;
} TOF_CDMA_NumberInfoRecord;

/* Redirecting Number Information Record as defined in C.S0005 section 3.7.5.11 */
typedef enum {
  TOF_REDIRECTING_REASON_UNKNOWN = 0,
  TOF_REDIRECTING_REASON_CALL_FORWARDING_BUSY = 1,
  TOF_REDIRECTING_REASON_CALL_FORWARDING_NO_REPLY = 2,
  TOF_REDIRECTING_REASON_CALLED_DTE_OUT_OF_ORDER = 9,
  TOF_REDIRECTING_REASON_CALL_FORWARDING_BY_THE_CALLED_DTE = 10,
  TOF_REDIRECTING_REASON_CALL_FORWARDING_UNCONDITIONAL = 15,
  TOF_REDIRECTING_REASON_RESERVED
} TOF_CDMA_RedirectingReason;

typedef struct {
  TOF_CDMA_NumberInfoRecord redirectingNumber;
  /* redirectingReason is set to TOF_REDIRECTING_REASON_UNKNOWN if not included */
  TOF_CDMA_RedirectingReason redirectingReason;
} TOF_CDMA_RedirectingNumberInfoRecord;

/* Line Control Information Record as defined in C.S0005 section 3.7.5.15 */
typedef struct {
  char lineCtrlPolarityIncluded;
  char lineCtrlToggle;
  char lineCtrlReverse;
  char lineCtrlPowerDenial;
} TOF_CDMA_LineControlInfoRecord;

/* T53 CLIR Information Record */
typedef struct {
  char cause;
} TOF_CDMA_T53_CLIRInfoRecord;

/* T53 Audio Control Information Record */
typedef struct {
  char upLink;
  char downLink;
} TOF_CDMA_T53_AudioControlInfoRecord;


/* Names of the CDMA info records (C.S0005 section 3.7.5) */
typedef enum {
  TOF_CDMA_DISPLAY_INFO_REC,
  TOF_CDMA_CALLED_PARTY_NUMBER_INFO_REC,
  TOF_CDMA_CALLING_PARTY_NUMBER_INFO_REC,
  TOF_CDMA_CONNECTED_NUMBER_INFO_REC,
  TOF_CDMA_SIGNAL_INFO_REC,
  TOF_CDMA_REDIRECTING_NUMBER_INFO_REC,
  TOF_CDMA_LINE_CONTROL_INFO_REC,
  TOF_CDMA_EXTENDED_DISPLAY_INFO_REC,
  TOF_CDMA_T53_CLIR_INFO_REC,
  TOF_CDMA_T53_RELEASE_INFO_REC,
  TOF_CDMA_T53_AUDIO_CONTROL_INFO_REC
} TOF_CDMA_InfoRecName;

/* The status for an OTASP/OTAPA session */
typedef enum {
    CDMA_OTA_PROVISION_STATUS_SPL_UNLOCKED,
    CDMA_OTA_PROVISION_STATUS_SPC_RETRIES_EXCEEDED,
    CDMA_OTA_PROVISION_STATUS_A_KEY_EXCHANGED,
    CDMA_OTA_PROVISION_STATUS_SSD_UPDATED,
    CDMA_OTA_PROVISION_STATUS_NAM_DOWNLOADED,
    CDMA_OTA_PROVISION_STATUS_MDN_DOWNLOADED,
    CDMA_OTA_PROVISION_STATUS_IMSI_DOWNLOADED,
    CDMA_OTA_PROVISION_STATUS_PRL_DOWNLOADED,
    CDMA_OTA_PROVISION_STATUS_COMMITTED,
    CDMA_OTA_PROVISION_STATUS_OTAPA_STARTED,
    CDMA_OTA_PROVISION_STATUS_OTAPA_STOPPED,
    CDMA_OTA_PROVISION_STATUS_OTAPA_ABORTED,
    CDMA_OTA_PROVISION_STATUS_OTA_FAILED 
} TOF_CDMA_OTA_ProvisionStatus;

typedef struct {

  TOF_CDMA_InfoRecName name;

  union {
    /* Display and Extended Display Info Rec */
    TOF_CDMA_DisplayInfoRecord           display;

    /* Called Party Number, Calling Party Number, Connected Number Info Rec */
    TOF_CDMA_NumberInfoRecord            number;

    /* Signal Info Rec */
    TOF_CDMA_SignalInfoRecord            signal;

    /* Redirecting Number Info Rec */
    TOF_CDMA_RedirectingNumberInfoRecord redir;

    /* Line Control Info Rec */
    TOF_CDMA_LineControlInfoRecord       lineCtrl;

    /* T53 CLIR Info Rec */
    TOF_CDMA_T53_CLIRInfoRecord          clir;

    /* T53 Audio Control Info Rec */
    TOF_CDMA_T53_AudioControlInfoRecord  audioCtrl;
  } rec;
} TOF_CDMA_InformationRecord;

typedef struct {
  char numberOfInfoRecs;
  TOF_CDMA_InformationRecord infoRec[TOF_CDMA_MAX_NUMBER_OF_INFO_RECS];
} TOF_CDMA_InformationRecords;


/*=========================================================================*/
// I2S Audio Control API
/*=========================================================================*/
#define FEATURE_TOF_AUDIO_CONTROL
#ifdef FEATURE_TOF_AUDIO_CONTROL
#define START_VOICE_CALL	"amix 'PRI_MI2S_RX_Voice Mixer CSVoice' 1;\
							amix 'Voice_Tx Mixer PRI_MI2S_TX_Voice' 1;\
							(aplay -D hw:0,2 -P &);\
							(arec -D hw:0,2 -P -R 8000 -C 1 &)"
#define END_VOICE_CALL		"pkill aplay; pkill arec"
#define AUDIO_LOOPBACK      "amix 'PRI_MI2S_RX Port Mixer PRI_MI2S_TX' 1;\
                            (aplay -D hw:0,3 -P -R 8000 -C 1 &);\
                            (arec -D hw:0,15 -P -R 8000 -C 1 &)"
#define TONE_PLAY			"amix 'PRI_MI2S_RX Audio Mixer MultiMedia1' 1;\
							aplay /data/tone.wav"
#endif
/*=========================================================================*/
// Shor Messaging Service(SMS) API
/*=========================================================================*/


#define FEATURE_TOF_UI
#ifdef FEATURE_TOF_UI
//define and enum
#define	TOF_WMS_MAX_ADDRESS_LEN						(48)
#define	TOF_WMS_MAX_MSG_LEN								(255)
#define	TOF_WMS_MAX_ADDRESS_DIGIT				(21)
#define TOF_WMS_MAX_MSG_INFO_NUM					(255)

#define TOF_WMS_INVALID_CAUSE_CODE				(0xffff)
#define TOF_WMS_INVALID_GW_RP_CAUSE			(0xffff)

typedef enum
{
	TOF_wms_interface_type_qmi,
	TOF_wms_interface_type_at,
	TOF_wms_interface_type_diag
} TOF_wms_interface_type_e;

typedef enum
{
	TOF_wms_msg_tag_type_mt_read,
	TOF_wms_msg_tag_type_mt_not_read,
	TOF_wms_msg_tag_type_mo_sent,
	TOF_wms_msg_tag_type_mo_not_sent
} TOF_wms_msg_tag_type_e;

typedef enum
{
	TOF_wms_memory_status_not_available,
	TOF_wms_memory_status_available
} TOF_wms_memory_status_e;



//struct
typedef struct
{
	unsigned int message_index;
	TOF_wms_msg_tag_type_e message_tag_type;
} TOF_wms_message_info_s;

typedef struct
{
	unsigned char year;
	unsigned char month;
	unsigned char day;
	unsigned char hour;
	unsigned char minute;
	unsigned char second;
	char					timezone;
} TOF_wms_timestamp_s;



//define api function parameter struct
//TOF_wms_request_send_sms()

typedef struct
{
  int message_class;
  int message_class_valid;
  int validity_period;
  int validity_period_valid;
  int data_coding_scheme;
  int protocol_id;
  int message_reference;
  int user_data_length;
  char *smsc;
  char *dest_num;
  unsigned char* user_data;
} TOF_wms_request_encode_sms_s;
typedef TOF_wms_request_encode_sms_s TOF_request_encode_sms_s;

typedef struct
{
	unsigned char* destination_address;
	unsigned char* message;
} TOF_wms_request_send_sms_s;
typedef TOF_wms_request_send_sms_s		TOF_request_send_sms_s;

typedef struct
{
	unsigned short message_id;
	unsigned short cause_code;
} TOF_wms_response_send_sms_s;
typedef TOF_wms_response_send_sms_s	TOF_response_send_sms_s;



//TOF_wms_request_delete_sms()
typedef struct
{
	unsigned int message_index;
} TOF_wms_request_delete_sms_s;
typedef TOF_wms_request_delete_sms_s		TOF_request_delete_sms_s;

typedef struct
{
} TOF_wms_response_delete_sms_s;
typedef TOF_wms_response_delete_sms_s	TOF_response_delete_sms_s;



//TOF_wms_request_read_sms()
typedef struct
{
	unsigned int message_index;
} TOF_wms_request_read_sms_s;
typedef TOF_wms_request_read_sms_s			TOF_request_read_sms_s;

typedef struct
{
	unsigned int	originating_address_length;
	unsigned char originating_address[ TOF_WMS_MAX_ADDRESS_LEN ];

	TOF_wms_timestamp_s message_timestamp;

	unsigned int	message_length;
	unsigned char message[ TOF_WMS_MAX_MSG_LEN ];
} TOF_wms_response_read_sms_s;
typedef TOF_wms_response_read_sms_s		TOF_response_read_sms_s;



//TOF_wms_request_list_sms()
typedef struct
{
} TOF_wms_request_list_sms_s;
typedef TOF_wms_request_list_sms_s			TOF_request_list_sms_s;

typedef struct
{
	unsigned int 							message_info_num;
	TOF_wms_message_info_s		message_info_list[ TOF_WMS_MAX_MSG_INFO_NUM ];
} TOF_wms_response_list_sms_s;
typedef TOF_wms_response_list_sms_s		TOF_response_list_sms_s;



//TOF_wms_request_get_smsc_address()
typedef struct
{
} TOF_wms_request_get_smsc_address_s;
typedef TOF_wms_request_get_smsc_address_s		TOF_request_get_smsc_address_s;

typedef struct
{
	unsigned int	smsc_address_digits_length;
	unsigned char smsc_address_digits[ TOF_WMS_MAX_ADDRESS_DIGIT + 1 ];
} TOF_wms_response_get_smsc_address_s;
typedef TOF_wms_response_get_smsc_address_s	TOF_response_get_smsc_address_s;



//TOF_wms_request_set_smsc_address()
typedef struct
{
	unsigned char* smsc_address_digits;
} TOF_wms_request_set_smsc_address_s;
typedef TOF_wms_request_set_smsc_address_s		TOF_request_set_smsc_address_s;

typedef struct
{
} TOF_wms_response_set_smsc_address_s;
typedef TOF_wms_response_set_smsc_address_s	TOF_response_set_smsc_address_s;



//TOF_wms_request_get_memory_status()
typedef struct
{
} TOF_wms_request_get_memory_status_s;
typedef TOF_wms_request_get_memory_status_s		TOF_request_get_memory_status_s;

typedef struct
{
	TOF_wms_memory_status_e memory_available;
} TOF_wms_response_get_memory_status_s;
typedef TOF_wms_response_get_memory_status_s		TOF_response_get_memory_status_s;

//TOF_voice_request_dial_call()
typedef struct
{
	unsigned char* number;
} TOF_voice_request_dial_call_s;
typedef TOF_voice_request_dial_call_s 		TOF_request_dial_call_s;

typedef struct
{
} TOF_voice_response_dial_call_s;
typedef TOF_voice_response_dial_call_s		TOF_response_dial_call_s;
#endif

/*=========================================================================*/
// Data Service Interface API
/*=========================================================================*/

typedef enum
{
  DSI_MODE_AUTO = 0,
  DSI_MODE_MANUAL
} ds_call_mode_enum_t;

typedef enum  
{
  ds_tech_min = 0,
  ds_tech_umts = ds_tech_min,
  ds_tech_cdma,
  ds_tech_1x,
  ds_tech_do,
  ds_tech_lte,
  ds_tech_modem_link_local,
  ds_tech_auto,
  ds_tech_max
} ds_tech_t;


#define INET_ADDRSTRLEN        16
#define INET6_ADDRSTRLEN       46

typedef enum {
  TOF_QCMAP_MSGR_IP_FAMILY_V4_V01 = 0x04, /**<  IPv4 version  */
  TOF_QCMAP_MSGR_IP_FAMILY_V6_V01 = 0x06, /**<  IPv6 version  */
  TOF_QCMAP_MSGR_IP_FAMILY_V4V6_V01 = 0x0A, /**<  Dual mode version  */
} tof_qcmap_msgr_ip_family_enum_v01;

typedef enum {
  TOF_QCMAP_MSGR_WWAN_STATUS_CONNECTING_V01 = 0x01, /**<  IPv4 WWAN is in connecting state  */
  TOF_QCMAP_MSGR_WWAN_STATUS_CONNECTING_FAIL_V01 = 0x02, /**<  IPv4 connection to WWAN failed  */
  TOF_QCMAP_MSGR_WWAN_STATUS_CONNECTED_V01 = 0x03, /**<  IPv4 WWAN is in connected state  */
  TOF_QCMAP_MSGR_WWAN_STATUS_DISCONNECTING_V01 = 0x04, /**<  IPv4 WWAN is disconnecting  */
  TOF_QCMAP_MSGR_WWAN_STATUS_DISCONNECTING_FAIL_V01 = 0x05, /**<  IPv4 WWAN failed to disconnect  */
  TOF_QCMAP_MSGR_WWAN_STATUS_DISCONNECTED_V01 = 0x06, /**<  IPv4 WWAN is disconnected  */
  TOF_QCMAP_MSGR_WWAN_STATUS_IPV6_CONNECTING_V01 = 0x07, /**<  IPv6 WWAN is in connecting state  */
  TOF_QCMAP_MSGR_WWAN_STATUS_IPV6_CONNECTING_FAIL_V01 = 0x08, /**<  IPv6 connection to WWAN failed  */
  TOF_QCMAP_MSGR_WWAN_STATUS_IPV6_CONNECTED_V01 = 0x09, /**<  IPv6 WWAN is in connected state  */
  TOF_QCMAP_MSGR_WWAN_STATUS_IPV6_DISCONNECTING_V01 = 0x0A, /**<  IPv6 WWAN is disconnecting  */
  TOF_QCMAP_MSGR_WWAN_STATUS_IPV6_DISCONNECTING_FAIL_V01 = 0x0B, /**<  IPv6 WWAN failed to disconnect  */
  TOF_QCMAP_MSGR_WWAN_STATUS_IPV6_DISCONNECTED_V01 = 0x0C, /**<  IPv6 WWAN is disconnected  */
} tof_qcmap_msgr_wwan_status_enum_v01;

typedef struct {
  tof_qcmap_msgr_wwan_status_enum_v01   inet_status;
  tof_qcmap_msgr_wwan_status_enum_v01   inet6_status;
  char                                  inet_addr[INET_ADDRSTRLEN];
  char                                  inet_pdns_addr[INET_ADDRSTRLEN];
  char                                  inet_sdns_addr[INET_ADDRSTRLEN];
  char                                  inet6_addr[INET6_ADDRSTRLEN];
  char                                  inet6_pdns_addr[INET6_ADDRSTRLEN];
  char                                  inet6_sdns_addr[INET6_ADDRSTRLEN];
} tof_data_call_response;



typedef struct {
  boolean   ims_registered;
  uint16    ims_registration_failure_error_code;
} tof_Imsa_Reg_Status_Info;

#define TOF_QMI_WDS_MAX_APN_STR_SIZE (100+1) // Null included

typedef struct {
  char modem_sw_version[TOF_DMSI_EXCEPTION_SW_VERSION_LEN];
  char exception_date[TOF_DMSI_EXCEPTION_BUILD_DATE_LEN];
  char exception_time[TOF_DMSI_EXCEPTION_BUILD_TIME_LEN];
  uint32 exception_line;
  char exception_file[TOF_DMSI_EXCEPTION_FILE_NAME_LEN];
  char exception_msg[TOF_DMSI_EXCEPTION_MESSAGE_LEN];
}tof_dms_get_exception_info;

/*=========================================================================*/
//Location Interface API
/*=========================================================================*/

#define FEATURE_TOF_GPS

#ifdef FEATURE_TOF_GPS

/**  Maximum number of satellites in the satellite report.  */
#define TOF_QMI_LOC_SV_INFO_LIST_MAX_SIZE_V02 80

/**  Maximum length of the list containing the SVs that were used to generate
     a position report.  */
#define TOF_QMI_LOC_MAX_SV_USED_LIST_LENGTH_V02 80

typedef struct{
  uint32  loc_session_status;
  double  loc_latitude;
  double  loc_longtitude;
  uint64  loc_utc_timestamp;
}tof_loc_info_type;

/**  IPv6 address length in bytes.  */
#define LOC_IPV6_ADDR_LENGTH 8
/**  Maximum URL length accepted by the location engine.  */
#define TOF_LOC_MAX_SERVER_ADDR_LENGTH 255

typedef struct{
  uint8  loc_agps_supl_server_type;
  char   ipv4_addr[INET_ADDRSTRLEN+1]; /**<   IPv4 address. */
  uint16  ipv4_port; 
#if 0  
  char ipv6_addr[INET6_ADDRSTRLEN];
  /**<   IPv6 address. \n
       - Type: Array of unsigned integers \n
       - Maximum length of the array: 8 */
  uint32_t ipv6_port;
#endif  
  char urlAddr[TOF_LOC_MAX_SERVER_ADDR_LENGTH + 1];
}tof_loc_spl_server_info_type;
#endif /* FEATURE_TOF_GPS */

typedef uint32_t tof_qmiLocSvInfoValidMaskT_v02;
#define TOF_QMI_LOC_SV_INFO_MASK_VALID_SYSTEM_V02 ((tof_qmiLocSvInfoValidMaskT_v02)0x00000001) /**<  System field is valid in SV information  */
#define TOF_QMI_LOC_SV_INFO_MASK_VALID_GNSS_SVID_V02 ((tof_qmiLocSvInfoValidMaskT_v02)0x00000002) /**<  gnssSvId field is valid in SV information  */
#define TOF_QMI_LOC_SV_INFO_MASK_VALID_HEALTH_STATUS_V02 ((tof_qmiLocSvInfoValidMaskT_v02)0x00000004) /**<  healthStatus field is valid in SV information  */
#define TOF_QMI_LOC_SV_INFO_MASK_VALID_PROCESS_STATUS_V02 ((tof_qmiLocSvInfoValidMaskT_v02)0x00000008) /**<  processStatus field is valid in SV information  */
#define TOF_QMI_LOC_SV_INFO_MASK_VALID_SVINFO_MASK_V02 ((tof_qmiLocSvInfoValidMaskT_v02)0x00000010) /**<  svInfoMask field is valid in SV information  */
#define TOF_QMI_LOC_SV_INFO_MASK_VALID_ELEVATION_V02 ((tof_qmiLocSvInfoValidMaskT_v02)0x00000020) /**<  Elevation field is valid in SV information  */
#define TOF_QMI_LOC_SV_INFO_MASK_VALID_AZIMUTH_V02 ((tof_qmiLocSvInfoValidMaskT_v02)0x00000040) /**<  Azimuth field is valid in SV information  */
#define TOF_QMI_LOC_SV_INFO_MASK_VALID_SNR_V02 ((tof_qmiLocSvInfoValidMaskT_v02)0x00000080) /**<  SNR field is valid in SV information  */
typedef uint8_t tof_qmiLocSvInfoMaskT_v02;
#define TOF_QMI_LOC_SVINFO_MASK_HAS_EPHEMERIS_V02 ((tof_qmiLocSvInfoMaskT_v02)0x01) /**<  Ephemeris is available for this SV  */
#define TOF_QMI_LOC_SVINFO_MASK_HAS_ALMANAC_V02 ((tof_qmiLocSvInfoMaskT_v02)0x02) /**<  Almanac is available for this SV  */


typedef enum {
 TOF_QMILOCSVSYSTEMENUMT_MIN_ENUM_VAL_V02 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
 TOF_eQMI_LOC_SV_SYSTEM_GPS_V02 = 1, /**<  GPS satellite  */
 TOF_eQMI_LOC_SV_SYSTEM_GALILEO_V02 = 2, /**<  GALILEO satellite  */
 TOF_eQMI_LOC_SV_SYSTEM_SBAS_V02 = 3, /**<  SBAS satellite  */
 TOF_eQMI_LOC_SV_SYSTEM_COMPASS_V02 = 4, /**<  COMPASS satellite (Deprecated)  */
 TOF_eQMI_LOC_SV_SYSTEM_GLONASS_V02 = 5, /**<  GLONASS satellite  */
 TOF_eQMI_LOC_SV_SYSTEM_BDS_V02 = 6, /**<  BDS satellite  */
 TOF_eQMI_LOC_SV_SYSTEM_QZSS_V02 = 7, /**<  QZSS satellite  */
 TOF_QMILOCSVSYSTEMENUMT_MAX_ENUM_VAL_V02 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}tof_qmiLocSvSystemEnumT_v02;

typedef enum {
  TOF_QMILOCSVSTATUSENUMT_MIN_ENUM_VAL_V02 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  TOF_eQMI_LOC_SV_STATUS_IDLE_V02 = 1, /**<  SV is not being actively processed  */
  TOF_eQMI_LOC_SV_STATUS_SEARCH_V02 = 2, /**<  The system is searching for this SV  */
  TOF_eQMI_LOC_SV_STATUS_TRACK_V02 = 3, /**<  SV is being tracked  */
  TOF_QMILOCSVSTATUSENUMT_MAX_ENUM_VAL_V02 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}tof_qmiLocSvStatusEnumT_v02;

typedef struct {

  tof_qmiLocSvInfoValidMaskT_v02 validMask;
  /**<   Bitmask indicating which of the fields in this TLV are valid.

         Valid bitmasks: \begin{itemize1}
         \item    0x00000001 -- VALID_SYSTEM
         \item    0x00000002 -- VALID_GNSS_SVID
         \item    0x00000004 -- VALID_HEALTH_ STATUS
         \item    0x00000008 -- VALID_PROCESS_ STATUS
         \item    0x00000010 -- VALID_SVINFO_ MASK
         \item    0x00000020 -- VALID_ELEVATION
         \item    0x00000040 -- VALID_AZIMUTH
         \item    0x00000080 -- VALID_SNR
         \vspace{-0.18in} \end{itemize1}  */

  tof_qmiLocSvSystemEnumT_v02 system;
  /**<   Indicates to which constellation this SV belongs.

 Valid values: \n
      - eQMI_LOC_SV_SYSTEM_GPS (1) --  GPS satellite 
      - eQMI_LOC_SV_SYSTEM_GALILEO (2) --  GALILEO satellite 
      - eQMI_LOC_SV_SYSTEM_SBAS (3) --  SBAS satellite 
      - eQMI_LOC_SV_SYSTEM_COMPASS (4) --  COMPASS satellite (Deprecated) 
      - eQMI_LOC_SV_SYSTEM_GLONASS (5) --  GLONASS satellite 
      - eQMI_LOC_SV_SYSTEM_BDS (6) --  BDS satellite 
      - eQMI_LOC_SV_SYSTEM_QZSS (7) --  QZSS satellite 
 */

  uint16_t gnssSvId;
  /**<   GNSS SV ID.
         \begin{itemize1}
         \item Range:  \begin{itemize1}
           \item For GPS:      1 to 32
           \item For GLONASS:  1 to 32
           \item For SBAS:     120 to 158 and 183 to 187
           \item For QZSS:     193 to 197
           \item For BDS:      201 to 237
           \item For GAL:      301 to 336
         \end{itemize1} \end{itemize1}

        The GPS and GLONASS SVs can be disambiguated using the system field. */

  uint8_t healthStatus;
  /**<   Health status.
         \begin{itemize1}
         \item    Range: 0 to 1; 0 = unhealthy, \n 1 = healthy
         \vspace{-0.18in} \end{itemize1}*/

  tof_qmiLocSvStatusEnumT_v02 svStatus;
  /**<   SV processing status.

 Valid values: \n
      - eQMI_LOC_SV_STATUS_IDLE (1) --  SV is not being actively processed 
      - eQMI_LOC_SV_STATUS_SEARCH (2) --  The system is searching for this SV 
      - eQMI_LOC_SV_STATUS_TRACK (3) --  SV is being tracked 
 */

  tof_qmiLocSvInfoMaskT_v02 svInfoMask;
  /**<   Indicates whether almanac and ephemeris information is available. \n
         Valid bitmasks:

           - 0x01 -- SVINFO_HAS_EPHEMERIS \n
           - 0x02 -- SVINFO_HAS_ALMANAC
    */

  float elevation;
  /**<   SV elevation angle.\n
         - Units: Degrees \n
         - Range: 0 to 90 */

  float azimuth;
  /**<   SV azimuth angle.\n
         - Units: Degrees \n
         - Range: 0 to 360 */

  float snr;
  /**<   SV signal-to-noise ratio. \n
         - Units: dB-Hz */
}tof_qmiLocSvInfoStructT_v02;  /* Type */

typedef enum {
    TOF_QMILOCSESSIONSTATUSENUMT_MIN_ENUM_VAL_V02 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
    TOF_eQMI_LOC_SESS_STATUS_SUCCESS_V02 = 0, /**<  Session was successful  */
    TOF_eQMI_LOC_SESS_STATUS_IN_PROGRESS_V02 = 1, /**<  Session is still in progress; further position reports will be generated
       until either the fix criteria specified by the client are met or the
       client response timeout occurs  */
    TOF_eQMI_LOC_SESS_STATUS_GENERAL_FAILURE_V02 = 2, /**<  Session failed  */
    TOF_eQMI_LOC_SESS_STATUS_TIMEOUT_V02 = 3, /**<  Fix request failed because the session timed out  */
    TOF_eQMI_LOC_SESS_STATUS_USER_END_V02 = 4, /**<  Fix request failed because the session was ended by the user  */
    TOF_eQMI_LOC_SESS_STATUS_BAD_PARAMETER_V02 = 5, /**<  Fix request failed due to bad parameters in the request  */
    TOF_eQMI_LOC_SESS_STATUS_PHONE_OFFLINE_V02 = 6, /**<  Fix request failed because the phone is offline  */
    TOF_eQMI_LOC_SESS_STATUS_ENGINE_LOCKED_V02 = 7, /**<  Fix request failed because the engine is locked  */
    TOF_QMILOCSESSIONSTATUSENUMT_MAX_ENUM_VAL_V02 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}tof_qmiLocSessionStatusEnumT_v02;

typedef enum {
  TOF_QMILOCRELIABILITYENUMT_MIN_ENUM_VAL_V02 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  TOF_eQMI_LOC_RELIABILITY_NOT_SET_V02 = 0, /**<  Location reliability is not set  */
  TOF_eQMI_LOC_RELIABILITY_VERY_LOW_V02 = 1, /**<  Location reliability is very low; use it at your own risk  */
  TOF_eQMI_LOC_RELIABILITY_LOW_V02 = 2, /**<  Location reliability is low; little or no cross-checking is possible  */
  TOF_eQMI_LOC_RELIABILITY_MEDIUM_V02 = 3, /**<  Location reliability is medium; limited cross-check passed   */
  TOF_eQMI_LOC_RELIABILITY_HIGH_V02 = 4, /**<  Location reliability is high; strong cross-check passed  */
  TOF_QMILOCRELIABILITYENUMT_MAX_ENUM_VAL_V02 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}tof_qmiLocReliabilityEnumT_v02;

typedef uint32_t tof_qmiLocPosTechMaskT_v02;
#define TOF_QMI_LOC_POS_TECH_MASK_SATELLITE_V02 ((tof_qmiLocPosTechMaskT_v02)0x00000001) /**<  Satellites were used to generate the fix  */
#define TOF_QMI_LOC_POS_TECH_MASK_CELLID_V02 ((tof_qmiLocPosTechMaskT_v02)0x00000002) /**<  Cell towers were used to generate the fix  */
#define TOF_QMI_LOC_POS_TECH_MASK_WIFI_V02 ((tof_qmiLocPosTechMaskT_v02)0x00000004) /**<  Wi-Fi access points were used to generate the fix  */
#define TOF_QMI_LOC_POS_TECH_MASK_SENSORS_V02 ((tof_qmiLocPosTechMaskT_v02)0x00000008) /**<  Sensors were used to generate the fix  */
#define TOF_QMI_LOC_POS_TECH_MASK_REFERENCE_LOCATION_V02 ((tof_qmiLocPosTechMaskT_v02)0x00000010) /**<  Reference Location was used to generate the fix  */
#define TOF_QMI_LOC_POS_TECH_MASK_INJECTED_COARSE_POSITION_V02 ((tof_qmiLocPosTechMaskT_v02)0x00000020) /**<  Coarse position injected into the location engine was used to
        generate the fix  */
#define TOF_QMI_LOC_POS_TECH_MASK_AFLT_V02 ((tof_qmiLocPosTechMaskT_v02)0x00000040) /**<  AFLT was used to generate the fix  */
#define TOF_QMI_LOC_POS_TECH_MASK_HYBRID_V02 ((tof_qmiLocPosTechMaskT_v02)0x00000080) /**<  GNSS and network-provided measurements were used to */

typedef struct {

  float PDOP;
  /**<   Position dilution of precision.
       \begin{itemize1}
       \item    Range: 1 (highest accuracy) to 50 (lowest accuracy)
       \item    PDOP = square root of (HDOP^2 + VDOP^2)
       \vspace{-0.18in} \end{itemize1} */

  float HDOP;
  /**<   Horizontal dilution of precision.
       \begin{itemize1}
       \item    Range: 1 (highest accuracy) to 50 (lowest accuracy)
       \vspace{-0.18in} \end{itemize1} */

  float VDOP;
  /**<   Vertical dilution of precision.
       \begin{itemize1}
       \item    Range: 1 (highest accuracy) to 50 (lowest accuracy)
       \vspace{-0.18in} \end{itemize1} */
}tof_qmiLocDOPStructT_v02;  /* Type */

typedef struct {

  uint16_t gpsWeek;
  /**<   Current GPS week as calculated from midnight, Jan. 6, 1980. \n
       - Units: Weeks */

  uint32_t gpsTimeOfWeekMs;
  /**<   Amount of time into the current GPS week. \n
       - Units: Milliseconds */
}tof_qmiLocGPSTimeStructT_v02;  /* Type */

typedef enum {
  TOF_QMILOCTIMESOURCEENUMT_MIN_ENUM_VAL_V02 = -2147483647, /**< To force a 32 bit signed enum.  Do not change or use*/
  TOF_eQMI_LOC_TIME_SRC_INVALID_V02 = 0, /**<  Invalid time.  */
  TOF_eQMI_LOC_TIME_SRC_NETWORK_TIME_TRANSFER_V02 = 1, /**<  Time is set by the 1X system  */
  TOF_eQMI_LOC_TIME_SRC_NETWORK_TIME_TAGGING_V02 = 2, /**<  Time is set by WCDMA/GSM time tagging (that is,
       associating network time with GPS time)  */
  TOF_eQMI_LOC_TIME_SRC_EXTERNAL_INPUT_V02 = 3, /**<  Time is set by an external injection  */
  TOF_eQMI_LOC_TIME_SRC_TOW_DECODE_V02 = 4, /**<  Time is set after decoding over-the-air GPS navigation data
       from one GPS satellite  */
  TOF_eQMI_LOC_TIME_SRC_TOW_CONFIRMED_V02 = 5, /**<  Time is set after decoding over-the-air GPS navigation data
       from multiple satellites  */
  TOF_eQMI_LOC_TIME_SRC_TOW_AND_WEEK_CONFIRMED_V02 = 6, /**<  Both time of the week and the GPS week number are known  */
  TOF_eQMI_LOC_TIME_SRC_NAV_SOLUTION_V02 = 7, /**<  Time is set by the position engine after the fix is obtained  */
  TOF_eQMI_LOC_TIME_SRC_SOLVE_FOR_TIME_V02 = 8, /**<  Time is set by the position engine after performing SFT;
       this is done when the clock time uncertainty is large  */
  TOF_eQMI_LOC_TIME_SRC_GLO_TOW_DECODE_V02 = 9, /**<  Time is set after decoding GLO satellites  */
  TOF_eQMI_LOC_TIME_SRC_TIME_TRANSFORM_V02 = 10, /**<  Time is set after transforming the GPS to GLO time  */
  TOF_eQMI_LOC_TIME_SRC_WCDMA_SLEEP_TIME_TAGGING_V02 = 11, /**<  Time is set by the sleep time tag provided by the WCDMA network  */
  TOF_eQMI_LOC_TIME_SRC_GSM_SLEEP_TIME_TAGGING_V02 = 12, /**<  Time is set by the sleep time tag provided by the GSM network  */
  TOF_eQMI_LOC_TIME_SRC_UNKNOWN_V02 = 13, /**<  Source of the time is unknown  */
  TOF_eQMI_LOC_TIME_SRC_SYSTEM_TIMETICK_V02 = 14, /**<  Time is derived from the system clock (better known as the slow clock);
       GNSS time is maintained irrespective of the GNSS receiver state  */
  TOF_eQMI_LOC_TIME_SRC_QZSS_TOW_DECODE_V02 = 15, /**<  Time is set after decoding QZSS satellites  */
  TOF_eQMI_LOC_TIME_SRC_BDS_TOW_DECODE_V02 = 16, /**<  Time is set after decoding BDS satellites  */
  TOF_eQMI_LOC_TIME_SRC_GAL_TOW_DECODE_V02 = 17, /**<  Time is set after decoding GAL satellites  */
  TOF_QMILOCTIMESOURCEENUMT_MAX_ENUM_VAL_V02 = 2147483647 /**< To force a 32 bit signed enum.  Do not change or use*/
}tof_qmiLocTimeSourceEnumT_v02;

typedef uint32_t tof_qmiLocSensorUsageMaskT_v02;
#define TOF_QMI_LOC_SENSOR_MASK_USED_ACCEL_V02 ((tof_qmiLocSensorUsageMaskT_v02)0x00000001) /**<  Bitmask to specify whether an accelerometer was used.  */
#define TOF_QMI_LOC_SENSOR_MASK_USED_GYRO_V02 ((tof_qmiLocSensorUsageMaskT_v02)0x00000002) /**<  Bitmask to specify whether a gyroscope was used.  */
typedef uint32_t tof_qmiLocSensorAidedMaskT_v02;
#define TOF_QMI_LOC_SENSOR_AIDED_MASK_HEADING_V02 ((tof_qmiLocSensorAidedMaskT_v02)0x00000001) /**<  Bitmask to specify whether a sensor was used to calculate heading.  */
#define TOF_QMI_LOC_SENSOR_AIDED_MASK_SPEED_V02 ((tof_qmiLocSensorAidedMaskT_v02)0x00000002) /**<  Bitmask to specify whether a sensor was used to calculate speed.  */
#define TOF_QMI_LOC_SENSOR_AIDED_MASK_POSITION_V02 ((tof_qmiLocSensorAidedMaskT_v02)0x00000004) /**<  Bitmask to specify whether a sensor was used to calculate position.  */
#define TOF_QMI_LOC_SENSOR_AIDED_MASK_VELOCITY_V02 ((tof_qmiLocSensorAidedMaskT_v02)0x00000008) /**<  Bitmask to specify whether a sensor was used to calculate velocity.  */

typedef struct {

  tof_qmiLocSensorUsageMaskT_v02 usageMask;
  /**<   Specifies which sensors were used in calculating the position in the
       position report.

       Valid bitmasks: \begin{itemize1}
       \item    0x00000001 -- SENSOR_USED_ ACCEL
       \item    0x00000002 -- SENSOR_USED_ GYRO
       \vspace{-0.18in} \end{itemize1} */

  tof_qmiLocSensorAidedMaskT_v02 aidingIndicatorMask;
  /**<   Specifies which results were aided by sensors.

       Valid bitmasks: \n
         - 0x00000001 -- AIDED_HEADING \n
         - 0x00000002 -- AIDED_SPEED \n
         - 0x00000004 -- AIDED_POSITION \n
         - 0x00000008 -- AIDED_VELOCITY */
}tof_qmiLocSensorUsageIndicatorStructT_v02;  /* Type */

typedef struct {

  /* Mandatory */
  /*   Session Status */
  tof_qmiLocSessionStatusEnumT_v02 sessionStatus;
  /**<   Session status.

 Valid values: \n
      - TOF_eQMI_LOC_SESS_STATUS_SUCCESS (0) --  Session was successful 
      - TOF_eQMI_LOC_SESS_STATUS_IN_PROGRESS (1) --  Session is still in progress; further position reports will be generated
       until either the fix criteria specified by the client are met or the
       client response timeout occurs 
      - TOF_eQMI_LOC_SESS_STATUS_GENERAL_FAILURE (2) --  Session failed 
      - TOF_eQMI_LOC_SESS_STATUS_TIMEOUT (3) --  Fix request failed because the session timed out 
      - TOF_eQMI_LOC_SESS_STATUS_USER_END (4) --  Fix request failed because the session was ended by the user 
      - TOF_eQMI_LOC_SESS_STATUS_BAD_PARAMETER (5) --  Fix request failed due to bad parameters in the request 
      - TOF_eQMI_LOC_SESS_STATUS_PHONE_OFFLINE (6) --  Fix request failed because the phone is offline 
      - TOF_eQMI_LOC_SESS_STATUS_ENGINE_LOCKED (7) --  Fix request failed because the engine is locked 
 */

  /* Mandatory */
  /*   Session ID */
  uint8_t sessionId;
  /**<    ID of the session that was specified in the Start request
        QMI_LOC_START_REQ. \n
        - Range: 0 to 255 */

  /* Optional */
  /*  Latitude */
  uint8_t latitude_valid;  /**< Must be set to true if latitude is being passed */
  double latitude;
  /**<   Latitude (specified in WGS84 datum).
       \begin{itemize1}
       \item    Type: Floating point
       \item    Units: Degrees
       \item    Range: -90.0 to 90.0   \begin{itemize1}
         \item    Positive values indicate northern latitude
         \item    Negative values indicate southern latitude
       \vspace{-0.18in} \end{itemize1} \end{itemize1} */

  /* Optional */
  /*   Longitude */
  uint8_t longitude_valid;  /**< Must be set to true if longitude is being passed */
  double longitude;
  /**<   Longitude (specified in WGS84 datum).
       \begin{itemize1}
       \item    Type: Floating point
       \item    Units: Degrees
       \item    Range: -180.0 to 180.0   \begin{itemize1}
         \item    Positive values indicate eastern longitude
         \item    Negative values indicate western longitude
       \vspace{-0.18in} \end{itemize1} \end{itemize1} */

  /* Optional */
  /*   Circular Horizontal Position Uncertainty */
  uint8_t horUncCircular_valid;  /**< Must be set to true if horUncCircular is being passed */
  float horUncCircular;
  /**<   Horizontal position uncertainty (circular).\n
       - Units: Meters */

  /* Optional */
  /*  Horizontal Elliptical Uncertainty (Semi-Minor Axis) */
  uint8_t horUncEllipseSemiMinor_valid;  /**< Must be set to true if horUncEllipseSemiMinor is being passed */
  float horUncEllipseSemiMinor;
  /**<   Semi-minor axis of horizontal elliptical uncertainty.\n
       - Units: Meters */

  /* Optional */
  /*  Horizontal Elliptical Uncertainty (Semi-Major Axis) */
  uint8_t horUncEllipseSemiMajor_valid;  /**< Must be set to true if horUncEllipseSemiMajor is being passed */
  float horUncEllipseSemiMajor;
  /**<   Semi-major axis of horizontal elliptical uncertainty.\n
       - Units: Meters */

  /* Optional */
  /*  Elliptical Horizontal Uncertainty Azimuth */
  uint8_t horUncEllipseOrientAzimuth_valid;  /**< Must be set to true if horUncEllipseOrientAzimuth is being passed */
  float horUncEllipseOrientAzimuth;
  /**<   Elliptical horizontal uncertainty azimuth of orientation.\n
       - Units: Decimal degrees \n
       - Range: 0 to 180 */

  /* Optional */
  /*  Horizontal Confidence */
  uint8_t horConfidence_valid;  /**< Must be set to true if horConfidence is being passed */
  uint8_t horConfidence;
  /**<   Horizontal uncertainty confidence.
       If both elliptical and horizontal uncertainties are specified in this message,
       the confidence corresponds to the elliptical uncertainty. \n
       - Units: Percent \n
       - Range: 0 to 99 */

  /* Optional */
  /*  Horizontal Reliability */
  uint8_t horReliability_valid;  /**< Must be set to true if horReliability is being passed */
  tof_qmiLocReliabilityEnumT_v02 horReliability;
  /**<   Specifies the reliability of the horizontal position.
 Valid values: \n
      - eQMI_LOC_RELIABILITY_NOT_SET (0) --  Location reliability is not set 
      - eQMI_LOC_RELIABILITY_VERY_LOW (1) --  Location reliability is very low; use it at your own risk 
      - eQMI_LOC_RELIABILITY_LOW (2) --  Location reliability is low; little or no cross-checking is possible 
      - eQMI_LOC_RELIABILITY_MEDIUM (3) --  Location reliability is medium; limited cross-check passed  
      - eQMI_LOC_RELIABILITY_HIGH (4) --  Location reliability is high; strong cross-check passed 
 */

  /* Optional */
  /*  Horizontal Speed */
  uint8_t speedHorizontal_valid;  /**< Must be set to true if speedHorizontal is being passed */
  float speedHorizontal;
  /**<   Horizontal speed.\n
       - Units: Meters/second */

  /* Optional */
  /*  Speed Uncertainty */
  uint8_t speedUnc_valid;  /**< Must be set to true if speedUnc is being passed */
  float speedUnc;
  /**<   3-D Speed uncertainty.\n
       - Units: Meters/second */

  /* Optional */
  /*  Altitude With Respect to Ellipsoid */
  uint8_t altitudeWrtEllipsoid_valid;  /**< Must be set to true if altitudeWrtEllipsoid is being passed */
  float altitudeWrtEllipsoid;
  /**<   Altitude with respect to the WGS84 ellipsoid.\n
       - Units: Meters \n
       - Range: -500 to 15883 */

  /* Optional */
  /*  Altitude With Respect to Sea Level */
  uint8_t altitudeWrtMeanSeaLevel_valid;  /**< Must be set to true if altitudeWrtMeanSeaLevel is being passed */
  float altitudeWrtMeanSeaLevel;
  /**<   Altitude with respect to mean sea level.\n
       - Units: Meters */

  /* Optional */
  /*  Vertical Uncertainty */
  uint8_t vertUnc_valid;  /**< Must be set to true if vertUnc is being passed */
  float vertUnc;
  /**<   Vertical uncertainty.\n
       - Units: Meters */

  /* Optional */
  /*  Vertical Confidence */
  uint8_t vertConfidence_valid;  /**< Must be set to true if vertConfidence is being passed */
  uint8_t vertConfidence;
  /**<   Vertical uncertainty confidence.\n
       - Units: Percent \n
       - Range: 0 to 99 */

  /* Optional */
  /*  Vertical Reliability */
  uint8_t vertReliability_valid;  /**< Must be set to true if vertReliability is being passed */
  tof_qmiLocReliabilityEnumT_v02 vertReliability;
  /**<   Specifies the reliability of the vertical position.
 Valid values: \n
      - eQMI_LOC_RELIABILITY_NOT_SET (0) --  Location reliability is not set 
      - eQMI_LOC_RELIABILITY_VERY_LOW (1) --  Location reliability is very low; use it at your own risk 
      - eQMI_LOC_RELIABILITY_LOW (2) --  Location reliability is low; little or no cross-checking is possible 
      - eQMI_LOC_RELIABILITY_MEDIUM (3) --  Location reliability is medium; limited cross-check passed  
      - eQMI_LOC_RELIABILITY_HIGH (4) --  Location reliability is high; strong cross-check passed 
 */

  /* Optional */
  /*  Vertical Speed */
  uint8_t speedVertical_valid;  /**< Must be set to true if speedVertical is being passed */
  float speedVertical;
  /**<   Vertical speed.\n
         - Units: Meters/second */

  /* Optional */
  /*  Heading */
  uint8_t heading_valid;  /**< Must be set to true if heading is being passed */
  float heading;
  /**<   Heading.\n
         - Units: Degrees \n
         - Range: 0 to 359.999  */

  /* Optional */
  /*  Heading Uncertainty */
  uint8_t headingUnc_valid;  /**< Must be set to true if headingUnc is being passed */
  float headingUnc;
  /**<   Heading uncertainty.\n
       - Units: Degrees \n
       - Range: 0 to 359.999 */

  /* Optional */
  /*  Magnetic Deviation */
  uint8_t magneticDeviation_valid;  /**< Must be set to true if magneticDeviation is being passed */
  float magneticDeviation;
  /**<   Difference between the bearing to true north and the bearing shown
      on a magnetic compass. The deviation is positive when the magnetic
      north is east of true north. */

  /* Optional */
  /*  Technology Used */
  uint8_t technologyMask_valid;  /**< Must be set to true if technologyMask is being passed */
  tof_qmiLocPosTechMaskT_v02 technologyMask;
  /**<   Technology used in computing this fix.
 Valid bitmasks: \n
      - QMI_LOC_POS_TECH_MASK_SATELLITE (0x00000001) --  Satellites were used to generate the fix 
      - QMI_LOC_POS_TECH_MASK_CELLID (0x00000002) --  Cell towers were used to generate the fix 
      - QMI_LOC_POS_TECH_MASK_WIFI (0x00000004) --  Wi-Fi access points were used to generate the fix 
      - QMI_LOC_POS_TECH_MASK_SENSORS (0x00000008) --  Sensors were used to generate the fix 
      - QMI_LOC_POS_TECH_MASK_REFERENCE_LOCATION (0x00000010) --  Reference Location was used to generate the fix 
      - QMI_LOC_POS_TECH_MASK_INJECTED_COARSE_POSITION (0x00000020) --  Coarse position injected into the location engine was used to
        generate the fix 
      - QMI_LOC_POS_TECH_MASK_AFLT (0x00000040) --  AFLT was used to generate the fix 
      - QMI_LOC_POS_TECH_MASK_HYBRID (0x00000080) --  GNSS and network-provided measurements were used to
        generate the fix 
 */

  /* Optional */
  /*  Dilution of Precision */
  uint8_t DOP_valid;  /**< Must be set to true if DOP is being passed */
  tof_qmiLocDOPStructT_v02 DOP;
  /**<   \vspace{0.06in} \n Dilution of precision associated with this position. */

  /* Optional */
  /*  UTC Timestamp */
  uint8_t timestampUtc_valid;  /**< Must be set to true if timestampUtc is being passed */
  uint64_t timestampUtc;
  /**<   UTC timestamp. \n
       - Units: Milliseconds since Jan. 1, 1970 */

  /* Optional */
  /*  Leap Seconds */
  uint8_t leapSeconds_valid;  /**< Must be set to true if leapSeconds is being passed */
  uint8_t leapSeconds;
  /**<   Leap second information. If leapSeconds is not available,
         timestampUtc is calculated based on a hard-coded value
         for leap seconds. \n
         - Units: Seconds */

  /* Optional */
  /*  GPS Time */
  uint8_t gpsTime_valid;  /**< Must be set to true if gpsTime is being passed */
  tof_qmiLocGPSTimeStructT_v02 gpsTime;
  /**<   \vspace{0.06in} \n The number of weeks since Jan. 5, 1980, and
       milliseconds into the current week. */

  /* Optional */
  /*  Time Uncertainty */
  uint8_t timeUnc_valid;  /**< Must be set to true if timeUnc is being passed */
  float timeUnc;
  /**<   Time uncertainty. \n
       - Units: Milliseconds */

  /* Optional */
  /*  Time Source */
  uint8_t timeSrc_valid;  /**< Must be set to true if timeSrc is being passed */
  tof_qmiLocTimeSourceEnumT_v02 timeSrc;
  /**<   Time source. Valid values: \n
      - TOF_eQMI_LOC_TIME_SRC_INVALID (0) --  Invalid time. 
      - TOF_eQMI_LOC_TIME_SRC_NETWORK_TIME_TRANSFER (1) --  Time is set by the 1X system 
      - TOF_eQMI_LOC_TIME_SRC_NETWORK_TIME_TAGGING (2) --  Time is set by WCDMA/GSM time tagging (that is,
       associating network time with GPS time) 
      - TOF_eQMI_LOC_TIME_SRC_EXTERNAL_INPUT (3) --  Time is set by an external injection 
      - TOF_eQMI_LOC_TIME_SRC_TOW_DECODE (4) --  Time is set after decoding over-the-air GPS navigation data
       from one GPS satellite 
      - TOF_eQMI_LOC_TIME_SRC_TOW_CONFIRMED (5) --  Time is set after decoding over-the-air GPS navigation data
       from multiple satellites 
      - TOF_eQMI_LOC_TIME_SRC_TOW_AND_WEEK_CONFIRMED (6) --  Both time of the week and the GPS week number are known 
      - TOF_eQMI_LOC_TIME_SRC_NAV_SOLUTION (7) --  Time is set by the position engine after the fix is obtained 
      - TOF_eQMI_LOC_TIME_SRC_SOLVE_FOR_TIME (8) --  Time is set by the position engine after performing SFT;
       this is done when the clock time uncertainty is large 
      - TOF_eQMI_LOC_TIME_SRC_GLO_TOW_DECODE (9) --  Time is set after decoding GLO satellites 
      - TOF_eQMI_LOC_TIME_SRC_TIME_TRANSFORM (10) --  Time is set after transforming the GPS to GLO time 
      - TOF_eQMI_LOC_TIME_SRC_WCDMA_SLEEP_TIME_TAGGING (11) --  Time is set by the sleep time tag provided by the WCDMA network 
      - TOF_eQMI_LOC_TIME_SRC_GSM_SLEEP_TIME_TAGGING (12) --  Time is set by the sleep time tag provided by the GSM network 
      - TOF_eQMI_LOC_TIME_SRC_UNKNOWN (13) --  Source of the time is unknown 
      - TOF_eQMI_LOC_TIME_SRC_SYSTEM_TIMETICK (14) --  Time is derived from the system clock (better known as the slow clock);
       GNSS time is maintained irrespective of the GNSS receiver state 
      - TOF_eQMI_LOC_TIME_SRC_QZSS_TOW_DECODE (15) --  Time is set after decoding QZSS satellites 
      - TOF_eQMI_LOC_TIME_SRC_BDS_TOW_DECODE (16) --  Time is set after decoding BDS satellites 
      - TOF_eQMI_LOC_TIME_SRC_GAL_TOW_DECODE (17) --  Time is set after decoding GAL satellites  */

  /* Optional */
  /*  Sensor Data Usage */
  uint8_t sensorDataUsage_valid;  /**< Must be set to true if sensorDataUsage is being passed */
  tof_qmiLocSensorUsageIndicatorStructT_v02 sensorDataUsage;
  /**<   \vspace{0.06in} \n Indicates whether sensor data was used in computing the position in this
       position report. */

  /* Optional */
  /*  Fix Count for This Session */
  uint8_t fixId_valid;  /**< Must be set to true if fixId is being passed */
  uint32_t fixId;
  /**<   Fix count for the session. Starts with 0 and increments by one
       for each successive position report for a particular session. */

  /* Optional */
  /*  SVs Used to Calculate the Fix */
  uint8_t gnssSvUsedList_valid;  /**< Must be set to true if gnssSvUsedList is being passed */
  uint32_t gnssSvUsedList_len;  /**< Must be set to # of elements in gnssSvUsedList */
  uint16_t gnssSvUsedList[TOF_QMI_LOC_MAX_SV_USED_LIST_LENGTH_V02];
  /**<   Each entry in the list contains the SV ID of a satellite
      used for calculating this position report. The following
      information is associated with each SV ID: \n
      Range: \n
      - For GPS:     1 to 32 \n
      - For GLONASS: 65 to 96 \n
      - For QZSS:    193 to 197 \n
      - For BDS:     201 to 237 \n
      - For GAL:     301 to 336
      */

  /* Optional */
  /*  Altitude Assumed */
  uint8_t altitudeAssumed_valid;  /**< Must be set to true if altitudeAssumed is being passed */
  uint8_t altitudeAssumed;
  /**<   Indicates whether altitude is assumed or calculated: \begin{itemize1}
         \item    0x00 (FALSE) -- Altitude is calculated
         \item    0x01 (TRUE) -- Altitude is assumed; there may not be enough
                                 satellites to determine the precise altitude
        \vspace{-0.18in} \end{itemize1}*/
}tof_qmiLocEventPositionReportIndMsgT_v02;  /* Message */

typedef struct {

  /* Mandatory */
  /*  Altitude Assumed */
  uint8_t altitudeAssumed;
  /**<   Indicates whether altitude is assumed or calculated: \begin{itemize1}
         \item    0x00 (FALSE) -- Valid altitude is calculated
         \item    0x01 (TRUE) -- Valid altitude is assumed; there may not be
                                 enough satellites to determine precise altitude
          \vspace{-0.18in} \end{itemize1}*/

  /* Optional */
  /*  Satellite Info */
  uint8_t svList_valid;  /**< Must be set to true if svList is being passed */
  uint32_t svList_len;  /**< Must be set to # of elements in svList */
  tof_qmiLocSvInfoStructT_v02 svList[TOF_QMI_LOC_SV_INFO_LIST_MAX_SIZE_V02];
  /**<   \vspace{0.06in} \n SV information list. */
}tof_qmiLocEventGnssSvInfoIndMsgT_v02;


/*
  jaeyong1.park 2017-02-20 Network search information
*/
typedef struct {

  uint16_t mobile_country_code;
  /**<   A 16-bit integer representation of MCC. Range: 0 to 999.
   */

  uint16_t mobile_network_code;
  /**<   A 16-bit integer representation of MNC. Range: 0 to 999.
   */
   
  uint8_t rat;
  /**<   Radio access technology. Values: \n
       - 0x04 -- GERAN \n
       - 0x05 -- UMTS \n
       - 0x08 -- LTE \n
       - 0x09 -- TD-SCDMA 
   */

  uint8_t in_use_status;
 /**- 0 -- QMI_NAS_NETWORK_IN_USE_STATUS_ UNKNOWN          -- Unknown         \n
       - 1 -- QMI_NAS_NETWORK_IN_USE_STATUS_ CURRENT_SERVING  -- Current serving \n
       - 2 -- QMI_NAS_NETWORK_IN_USE_STATUS_ AVAILABLE        -- Available
    */
    
  uint8_t roaming_status;
 /**- 0 -- QMI_NAS_NETWORK_ROAMING_STATUS_ UNKNOWN         -- Unknown         \n
       - 1 -- QMI_NAS_NETWORK_ROAMING_STATUS_ HOME            -- Home            \n
       - 2 -- QMI_NAS_NETWORK_ROAMING_STATUS_ ROAM            -- Roam
       */
       
  uint8_t forbidden_status;
 /**- 0 -- QMI_NAS_NETWORK_FORBIDDEN_STATUS_ UNKNOWN       -- Unknown         \n
       - 1 -- QMI_NAS_NETWORK_FORBIDDEN_STATUS_ FORBIDDEN     -- Forbidden       \n
       - 2 -- QMI_NAS_NETWORK_FORBIDDEN_STATUS_ NOT_FORBIDDEN -- Not forbidden
       */
  
  uint8_t preferred_status;
 /**- 0 -- QMI_NAS_NETWORK_PREFERRED_STATUS_ UNKNOWN       -- Unknown         \n
       - 1 -- QMI_NAS_NETWORK_PREFERRED_STATUS_ PREFERRED     -- Preferred       \n
       - 2 -- QMI_NAS_NETWORK_PREFERRED_STATUS_ NOT_PREFERRED -- Not preferred
       */    

  char network_description[25];
  /**<   An optional string containing the network name or description.
   */
}tof_nas_available_networks_unit;

typedef struct {
	uint8_t scan_result;
	uint16_t num_of_networks;
	tof_nas_available_networks_unit networks[15];
}TOF_nas_available_networks;


typedef uint64_t TOF_Loc_Event_Reg_Mask_type;
#define TOF_LOC_EVENT_MASK_POSITION_REPORT ((TOF_Loc_Event_Reg_Mask_type)0x00000001ull) /**<  The control point must enable this mask to receive position report
       event indications.  */
#define TOF_LOC_EVENT_MASK_GNSS_SV_INFO ((TOF_Loc_Event_Reg_Mask_type)0x00000002ull) /**<  The control point must enable this mask to receive satellite report
       event indications. These reports are sent at a 1 Hz rate.  */
#define TOF_LOC_EVENT_MASK_NMEA ((TOF_Loc_Event_Reg_Mask_type)0x00000004ull) /**<  The control point must enable this mask to receive NMEA reports for
       position and satellites in view. The report is at a 1 Hz rate.  */
#define TOF_LOC_EVENT_MASK_NI_NOTIFY_VERIFY_REQ ((TOF_Loc_Event_Reg_Mask_type)0x00000008ull) /**<  The control point must enable this mask to receive NI Notify/Verify request
       event indications.  */
#define TOF_LOC_EVENT_MASK_INJECT_TIME_REQ ((TOF_Loc_Event_Reg_Mask_type)0x00000010ull) /**<  The control point must enable this mask to receive time injection request
       event indications.  */
#define TOF_LOC_EVENT_MASK_INJECT_PREDICTED_ORBITS_REQ ((TOF_Loc_Event_Reg_Mask_type)0x00000020ull) /**<  The control point must enable this mask to receive predicted orbits request
       event indications.  */
#define TOF_LOC_EVENT_MASK_INJECT_POSITION_REQ ((TOF_Loc_Event_Reg_Mask_type)0x00000040ull) /**<  The control point must enable this mask to receive position injection request
       event indications.  */
#define TOF_LOC_EVENT_MASK_ENGINE_STATE ((TOF_Loc_Event_Reg_Mask_type)0x00000080ull) /**<  The control point must enable this mask to receive engine state report
       event indications.  */
#define TOF_LOC_EVENT_MASK_FIX_SESSION_STATE ((TOF_Loc_Event_Reg_Mask_type)0x00000100ull) /**<  The control point must enable this mask to receive fix session status report
       event indications.  */
#define TOF_LOC_EVENT_MASK_WIFI_REQ ((TOF_Loc_Event_Reg_Mask_type)0x00000200ull) /**<  The control point must enable this mask to receive Wi-Fi position request
       event indications.  */
#define TOF_LOC_EVENT_MASK_SENSOR_STREAMING_READY_STATUS ((TOF_Loc_Event_Reg_Mask_type)0x00000400ull) /**<  The control point must enable this mask to receive notifications from the
       location engine indicating its readiness to accept data from the
       sensors (accelerometer, gyroscope, etc.).  */
#define TOF_LOC_EVENT_MASK_TIME_SYNC_REQ ((TOF_Loc_Event_Reg_Mask_type)0x00000800ull) /**<  The control point must enable this mask to receive time sync requests
       from the GPS engine. Time sync enables the GPS engine to synchronize
       its clock with the sensor processor's clock.  */
#define TOF_LOC_EVENT_MASK_SET_SPI_STREAMING_REPORT ((TOF_Loc_Event_Reg_Mask_type)0x00001000ull) /**<  The control point must enable this mask to receive Stationary Position
       Indicator (SPI) streaming report indications.  */
#define TOF_LOC_EVENT_MASK_LOCATION_SERVER_CONNECTION_REQ ((TOF_Loc_Event_Reg_Mask_type)0x00002000ull) /**<  The control point must enable this mask to receive location server
       requests. These requests are generated when the service wishes to
       establish a connection with a location server. */
#define TOF_LOC_EVENT_MASK_NI_GEOFENCE_NOTIFICATION ((TOF_Loc_Event_Reg_Mask_type)0x00004000ull) /**<  The control point must enable this mask to receive notifications
       related to network-initiated Geofences. These events notify the client
       when a network-initiated Geofence is added, deleted, or edited.  */
#define TOF_LOC_EVENT_MASK_GEOFENCE_GEN_ALERT ((TOF_Loc_Event_Reg_Mask_type)0x00008000ull) /**<  The control point must enable this mask to receive Geofence alerts.
       These alerts are generated to inform the client of the changes that may
       affect a Geofence, e.g., if GPS is turned off or if the network is
       unavailable.  */
#define TOF_LOC_EVENT_MASK_GEOFENCE_BREACH_NOTIFICATION ((TOF_Loc_Event_Reg_Mask_type)0x00010000ull) /**<  The control point must enable this mask to receive notifications when
       a Geofence is breached. These events are generated when a UE enters
       or leaves the perimeter of a Geofence. This breach report is for a single
       Geofence . */
#define TOF_LOC_EVENT_MASK_PEDOMETER_CONTROL ((TOF_Loc_Event_Reg_Mask_type)0x00020000ull) /**<  The control point must enable this mask to register for pedometer
       control requests from the location engine. The location engine sends
       this event to control the injection of pedometer reports.  */
#define TOF_LOC_EVENT_MASK_MOTION_DATA_CONTROL ((TOF_Loc_Event_Reg_Mask_type)0x00040000ull) /**<  The control point must enable this mask to register for motion data
       control requests from the location engine. The location engine sends
       this event to control the injection of motion data.  */
#define TOF_LOC_EVENT_MASK_BATCH_FULL_NOTIFICATION ((TOF_Loc_Event_Reg_Mask_type)0x00080000ull) /**<  The control point must enable this mask to receive notification when
       a batch is full. The location engine sends this event to notify of Batch Full
       for ongoing batching session.  */
#define TOF_LOC_EVENT_MASK_LIVE_BATCHED_POSITION_REPORT ((TOF_Loc_Event_Reg_Mask_type)0x00100000ull) /**<  The control point must enable this mask to receive position report
       indications along with an ongoing batching session. The location engine sends
       this event to notify the batched position report while a batching session
       is ongoing.  */
#define TOF_LOC_EVENT_MASK_INJECT_WIFI_AP_DATA_REQ ((TOF_Loc_Event_Reg_Mask_type)0x00200000ull) /**<  The control point must enable this mask to receive Wi-Fi AP data inject request
       event indications.  */
#define TOF_LOC_EVENT_MASK_GEOFENCE_BATCH_BREACH_NOTIFICATION ((TOF_Loc_Event_Reg_Mask_type)0x00400000ull) /**<  The control point must enable this mask to receive notifications when
       a Geofence is breached. These events are generated when a UE enters
       or leaves the perimeter of a Geofence. This breach notification is for
       multiple Geofences. Breaches from multiple Geofences are all batched and
       sent in the same notification .    */
#define TOF_LOC_EVENT_MASK_VEHICLE_DATA_READY_STATUS ((TOF_Loc_Event_Reg_Mask_type)0x00800000ull) /**<  The control point must enable this mask to receive notifications from the
       location engine indicating its readiness to accept vehicle data (vehicle
       accelerometer, vehicle angular rate, vehicle odometry, etc.). */
#define TOF_LOC_EVENT_MASK_GNSS_MEASUREMENT_REPORT ((TOF_Loc_Event_Reg_Mask_type)0x01000000ull) /**<  The control point must enable this mask to receive system clock and satellite
       measurement report events (system clock, SV time, Doppler, etc.). Reports are
       generated only for the GNSS satellite constellations that are enabled using
       TOF_LOC_SET_GNSS_CONSTELL_REPORT_CONFIG.   */
#define TOF_LOC_EVENT_MASK_GNSS_SV_POLYNOMIAL_REPORT ((TOF_Loc_Event_Reg_Mask_type)0x02000000ull) /**<  The control point must enable this mask to receive satellite position
        reports as polynomials. Reports are generated only for the GNSS satellite
        constellations that are enabled using TOF_LOC_SET_GNSS_CONSTELL_REPORT_CONFIG.  */
#define TOF_LOC_EVENT_MASK_GEOFENCE_PROXIMITY_NOTIFICATION ((TOF_Loc_Event_Reg_Mask_type)0x04000000ull) /**<  The control point must enable this mask to receive notifications when a Geofence proximity is entered
  and exited. The proximity of a Geofence may be due to different contexts. These contexts are identified
  using the context ID in this indication. The context of a Geofence may contain Wi-Fi area ID lists, IBeacon lists,
  Cell-ID list, and so forth.    */
#define TOF_LOC_EVENT_MASK_GDT_UPLOAD_BEGIN_REQ ((TOF_Loc_Event_Reg_Mask_type)0x08000000ull) /**<  The control point must enable this mask to receive Generic Data Transport (GDT)
        session begin request event indications.  */
#define TOF_LOC_EVENT_MASK_GDT_UPLOAD_END_REQ ((TOF_Loc_Event_Reg_Mask_type)0x10000000ull) /**<  The control point must enable this mask to receive GDT
        session end request event indications.  */
#define TOF_LOC_EVENT_MASK_GEOFENCE_BATCH_DWELL_NOTIFICATION ((TOF_Loc_Event_Reg_Mask_type)0x20000000ull) /**<  The control point must enable this mask to receive notifications when
       a Geofence is dwelled. These events are generated when a UE enters
       or leaves the perimeter of a Geofence and dwells inside or outside for a specified time.
       This dwell notification is for multiple Geofences. Dwells from multiple Geofences are all batched and
       sent in the same notification.  */
#define TOF_LOC_EVENT_MASK_GET_TIME_ZONE_REQ ((TOF_Loc_Event_Reg_Mask_type)0x40000000ull) /**<  The control point must enable this mask to receive requests for time zone information from
       the service. These events are generated when there is a need for time zone information in the
       service.  */
#define TOF_LOC_EVENT_MASK_BATCHING_STATUS ((TOF_Loc_Event_Reg_Mask_type)0x80000000ull) /**<  The control point must enable this mask to receive asynchronous events related
       to batching.  */

// Added Jamming detection Indication
typedef struct
{
  int32_t   l_PGAGain;

  /* BP1 params */
  uint32_t  q_Bp1LbwAmplI;
  uint32_t  q_Bp1LbwAmplQ; 

  /* BP3 GLO processor status */
  uint32_t  q_Bp3GloAmplI;
  uint32_t  q_Bp3GloAmplQ; 
} tof_qmiLocEventJammingRFIndMsgT_v02 ;

#ifdef __cplusplus
}
#endif

#endif

