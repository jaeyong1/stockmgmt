/******************************************************************************
  @file    qmi_ims.cpp
  @brief   The QMI ims client

  DESCRIPTION

  INITIALIZATION AND SEQUENCING REQUIREMENTS

  ---------------------------------------------------------------------------
  Copyright (c) 2013 LG Innotek Technologies Incorporated.
  All Rights Reserved. LG Innotek Proprietary and Confidential.
  ---------------------------------------------------------------------------
******************************************************************************/

#include <string.h>
#include "qmi.h"
#include "qmi_ims.h"

/* Log assertion level message */
#define QCRIL_ASSERT( xx_exp )                                         \
  if ( !( xx_exp ) )                                                       \
  {                                                                        \
    MSG_FATAL( "*****ASSERTION FAILED*****",0,0,0); \
  } 
  
qmi_client_handle_type ims_client_handle = QMI_INVALID_CLIENT_HANDLE;

#define QMI_IMS_SETTINGS_QIPCALL_CONFIG_IND_V01 0x0038


/*=========================================================================

  FUNCTION:  qmi_ims_indication_cb

===========================================================================*/
/*!
    @brief
    Callback for QMI indications.

    @return
    None
*/
/*=========================================================================*/
void qmi_ims_indication_cb
(
  int                            user_handle,
  qmi_service_id_type            service_id,
  void                         * user_data,
  qmi_ims_indication_id_type     ind_id,
  qmi_ims_indication_data_type * ind_data_ptr
)
{
  int                               ind_params_tot_size = 0;
  ims_0038_ind_s *ims_0038_ind;   

  switch(ind_id)
  {
    case QMI_IMS_SRVC_SETTINGS_REG_MGR_CONFIG_IND:
      break;
    
    case QMI_IMS_SETTINGS_QIPCALL_CONFIG_IND_V01:
      ims_0038_ind = (ims_0038_ind_s *)ind_data_ptr;            
    break;      
    
    default:
      break;
  }

  return;
} /* qmi_ims_indication_cb */

/*===========================================================================

  FUNCTION  qmi_ims_srvc_init
  
===========================================================================*/
bool qmi_ims_init()
{
  int rc = QMI_INTERNAL_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;

  ims_002A_req_s ims_002A_req;  

  if(ims_client_handle != QMI_INVALID_CLIENT_HANDLE) 
  {
    printf("qmi_ims_init()ims_client_handle already exist = %x \r\n", ims_client_handle);
    return RESULT_SUCCESS;
  }

  /* Initialize IMS service */
  if ((ims_client_handle = qmi_ims_srvc_init_client (QMI_PORT_RMNET_0,
                                                 qmi_ims_indication_cb, // callback function. 
                                                 NULL, 
                                                 &qmi_err_code)) < 0)
  {
    printf("Unable to start IMS service ims_client_handle= %x, qmi_err_code=%x\n", 
           ims_client_handle, 
           qmi_err_code);
    return RESULT_FAILURE;
  }
  else
  {
    printf("Opened IMS Client. ims_client_handle= %x \r\n", ims_client_handle);
  }  

  memset(&ims_002A_req, 0, sizeof(ims_002A_req_s));  

  rc = qmi_ims_indication_register((int)ims_client_handle,
                                              &ims_002A_req,
                                              &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[IMS]qmi_ims_indication_register!! rc: %d err_code : %d",rc,qmi_err_code, 0);
    return RESULT_FAILURE;
  }    

  return RESULT_SUCCESS;

/* IBOX Original Code */
#if 0 
  int rc = QMI_INTERNAL_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;

  ims_002A_req_s ims_002A_req;  

  ims_client_handle = qmi_ims_srvc_init_client(qmi_ims_indication_cb,&qmi_err_code);

  if(ims_client_handle == INVALID_HANDLE_VALUE)
  {
    MSG_ERROR("[IMS]error on qmi_ims_srvc_init_client",0 ,0, 0);
    return FALSE;
  }

  memset(&ims_002A_req, 0, sizeof(ims_002A_req_s));
  
  ims_002A_req.t17_valid = TRUE;
  ims_002A_req.t17.qipcall_config = 0x01;

  rc = qmi_ims_indication_register((int)ims_client_handle,
                                              &ims_002A_req,
                                              &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_ims_indication_register!! rc: %d err_code : %d",rc,qmi_err_code, 0);
    return FALSE;
  }    

  return TRUE;
#endif
} /* qmi_ims_srvc_init */

/*===========================================================================

  FUNCTION  qmi_ims_srvc_release
  
===========================================================================*/
int qmi_ims_release()
{
   int qmi_err_code = QMI_NO_ERR;
   int rc = QMI_NO_ERR;

   if(ims_client_handle == QMI_INVALID_CLIENT_HANDLE) return RESULT_SUCCESS;
    
  if(ims_client_handle != QMI_INVALID_CLIENT_HANDLE)
  {
    rc = qmi_ims_srvc_release_client(ims_client_handle, &qmi_err_code);
    if(rc != QMI_NO_ERR)
    {
      printf("qmi_ims_srvc_release_client rc = %d, qmi_err_code \n", rc, qmi_err_code);
      return RESULT_FAILURE;
    } 
  }
  else
  {
    printf("tof_qmi_release ims_client_handle= %x\r\n", ims_client_handle);
  }

  return RESULT_SUCCESS;

/* IBOX Original Code */
#if 0
  int ret = QMI_INTERNAL_ERR;
  int qmi_err_code = QMI_INTERNAL_ERR;

  if(ims_client_handle == INVALID_HANDLE_VALUE)
    return ret;

  ret = qmi_ims_srvc_release_client((int)ims_client_handle, &qmi_err_code);
  if(ret == QMI_NO_ERR)
    ims_client_handle = INVALID_HANDLE_VALUE;
  
  return ret;
#endif  
}

/*===========================================================================

  FUNCTION  ril_request_get_ims_reg_info
  
===========================================================================*/
uint8 ril_request_get_ims_reg_info(ims_reg_request_type req_type, RIL_Ims_Reg_Info *ims_info)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  ims_0026_rsp_s ims_0026_rsp;

  memset(&ims_0026_rsp, 0, sizeof(ims_0026_rsp_s));
  
  if(ims_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_ims_get_ims_reg_info((int)ims_client_handle, &ims_0026_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[IMS] qmi_ims_get_ims_reg_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    switch(req_type)
    {
      case REQUEST_PCSCF_PORT:
        if(ims_0026_rsp.t11_valid == TRUE)
        {
          ims_info->pcscf_port = ims_0026_rsp.t11.pcscf_port;
          MSG_ERROR("ril_request_get_ims_reg_info() pcscf_port =%d",ims_info->pcscf_port,0,0);
        }
      break;

      case REQUEST_PCSCF_DOMAIN:
        if(ims_0026_rsp.t12_valid == TRUE)
        {
          strcpy(ims_info->pcscf_domain, ims_0026_rsp.t12.pcscf_domain);

          MSG_ERROR("ril_request_get_ims_reg_info() pcscf_domain =%s",ims_info->pcscf_domain,0,0);
        }
      break;

      case REQUEST_IMS_TEST_MODE:
        if(ims_0026_rsp.t13_valid == TRUE)
        {
          ims_info->ims_test_mode = ims_0026_rsp.t13.ims_test_mode;

          MSG_ERROR("ril_request_get_ims_reg_info() ims_test_mode =%d",ims_info->ims_test_mode,0,0);
        }
      break;

      default:
      break;        
    }

    return RESULT_SUCCESS;
  }

}

/*===========================================================================

  FUNCTION  ril_request_set_ims_reg_info
  
===========================================================================*/
uint8 ril_request_set_ims_reg_info(ims_reg_request_type req_type, RIL_Ims_Reg_Info ims_info)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  ims_0021_req_s ims_0021_req;
  
  if(ims_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&ims_0021_req, 0, sizeof(ims_0021_req_s));

  switch(req_type)
  {
    case REQUEST_PCSCF_PORT:
      ims_0021_req.t10_valid = TRUE;
      ims_0021_req.t10.pcscf_port = ims_info.pcscf_port;

      MSG_ERROR("ril_request_set_ims_reg_info() pcscf_port =%d",ims_0021_req.t10.pcscf_port,0,0);
    break;

    case REQUEST_PCSCF_DOMAIN:
      ims_0021_req.t11_valid = TRUE;
      strcpy(ims_0021_req.t11.pcscf_domain, ims_info.pcscf_domain);

      MSG_ERROR("ril_request_get_ims_reg_info() pcscf_domain =%s",ims_0021_req.t11.pcscf_domain,0,0);
    break;

    case REQUEST_IMS_TEST_MODE:
      ims_0021_req.t12_valid = TRUE;
      ims_0021_req.t12.ims_test_mode = ims_info.ims_test_mode;

      MSG_ERROR("ril_request_set_ims_reg_info() ims_test_mode =%d",ims_0021_req.t12.ims_test_mode,0,0);
    break;

    default:
    break;        
  }

  rc = qmi_ims_set_ims_reg_info((int)ims_client_handle,
                                                &ims_0021_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_ims_set_ims_reg_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}

/*===========================================================================

  FUNCTION  ril_request_get_ims_user_info
  
===========================================================================*/
uint8 ril_request_get_ims_user_info(int request, RIL_Ims_User_Info *ims_info)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  ims_0028_rsp_s ims_0028_rsp;

  memset(&ims_0028_rsp, 0, sizeof(ims_0028_rsp_s));
  
  if(ims_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_ims_get_ims_user_info((int)ims_client_handle, &ims_0028_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[IMS] qmi_ims_get_ims_user_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    switch(request)
    {
      case REQUEST_DOMAIN_NAME:
        strcpy(ims_info->domain_name, ims_0028_rsp.t11.domain_name);
      break;

      default:
      break;
    }

    return RESULT_SUCCESS;
  }

}

/*===========================================================================

  FUNCTION  ril_request_set_ims_reg_info
  
===========================================================================*/
uint8 ril_request_set_ims_user_info(int request, RIL_Ims_User_Info ims_info)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  ims_0023_req_s ims_0023_req;
  
  if(ims_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&ims_0023_req, 0, sizeof(ims_0023_req_s));

  switch(request)
  {
    case REQUEST_DOMAIN_NAME:
      ims_0023_req.t10_valid = TRUE;
      strcpy(ims_0023_req.t10.domain_name, ims_info.domain_name);
    break;

    default:
    break;  
  }

  rc = qmi_ims_set_ims_user_info((int)ims_client_handle,
                                                &ims_0023_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_ims_set_ims_user_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}

/*===========================================================================

  FUNCTION  ril_request_get_ims_sip_info
  
===========================================================================*/
uint8 ril_request_get_ims_sip_info(ims_sip_request_type request, RIL_Ims_Sip_Info *ims_info)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  ims_0025_rsp_s ims_0025_rsp;

  memset(&ims_0025_rsp, 0, sizeof(ims_0025_rsp_s));
  
  if(ims_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_ims_get_ims_sip_info((int)ims_client_handle, &ims_0025_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[IMS] qmi_ims_get_ims_sip_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    switch(request)
    {
      case REQUEST_LOCAL_PORT:
        ims_info->sip_local_port = ims_0025_rsp.t11.sip_local_port;
      break;

      case REQUEST_REG_TIMER:
        ims_info->timer_sip_reg = ims_0025_rsp.t12.timer_sip_reg;
      break;

      case REQUEST_SUBSCRIBE_TIMER:
        ims_info->subscribe_timer = ims_0025_rsp.t13.subscribe_timer;
      break;

      case REQUEST_TIMER_T1:
        ims_info->timer_t1 = ims_0025_rsp.t14.timer_t1;
      break;

      case REQUEST_TIMER_T2:
        ims_info->timer_t2 = ims_0025_rsp.t15.timer_t2;
      break;

      case REQUEST_TIMER_F:
        ims_info->timer_f = ims_0025_rsp.t16.timer_f;
      break;
      
      default:
      break;
    }

    return RESULT_SUCCESS;
  }

}

/*===========================================================================

  FUNCTION  ril_request_set_ims_sip_info
  
===========================================================================*/
uint8 ril_request_set_ims_sip_info(ims_sip_request_type request, RIL_Ims_Sip_Info ims_info)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  ims_0020_req_s ims_0020_req;
  
  if(ims_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&ims_0020_req, 0, sizeof(ims_0020_req_s));

  switch(request)
  {
    case REQUEST_LOCAL_PORT:
      ims_0020_req.t10_valid = TRUE;
      ims_0020_req.t10.sip_local_port = ims_info.sip_local_port;
    break;

    case REQUEST_REG_TIMER:
      ims_0020_req.t11_valid = TRUE;
      ims_0020_req.t11.timer_sip_reg = ims_info.timer_sip_reg;
    break;    

    case REQUEST_SUBSCRIBE_TIMER:
      ims_0020_req.t12_valid = TRUE;
      ims_0020_req.t12.subscribe_timer = ims_info.subscribe_timer;
    break;    

    case REQUEST_TIMER_T1:
      ims_0020_req.t13_valid = TRUE;
      ims_0020_req.t13.timer_t1 = ims_info.timer_t1;
    break; 

    case REQUEST_TIMER_T2:
      ims_0020_req.t14_valid = TRUE;
      ims_0020_req.t14.timer_t2 = ims_info.timer_t2;
    break; 

    case REQUEST_TIMER_F:
      ims_0020_req.t15_valid = TRUE;
      ims_0020_req.t15.timer_f = ims_info.timer_f;
    break;    

    default:
    break;  
  }
  
  rc = qmi_ims_set_ims_sip_info((int)ims_client_handle,
                                                &ims_0020_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_ims_set_ims_sip_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}

/*===========================================================================

  FUNCTION  ril_request_get_amr_wb_enable
  
===========================================================================*/
uint8 ril_request_get_amr_wb_enable(boolean *amr_wb_enable)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  ims_0029_rsp_s ims_0029_rsp;

  memset(&ims_0029_rsp, 0, sizeof(ims_0029_rsp_s));
  
  if(ims_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_ims_get_ims_voip_info((int)ims_client_handle, &ims_0029_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[IMS] qmi_ims_get_ims_voip_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    *amr_wb_enable = ims_0029_rsp.t13.amr_wb_enable;
    return RESULT_SUCCESS;
  }

}

/*===========================================================================

  FUNCTION  ril_request_set_amr_wb_enable
  
===========================================================================*/
uint8 ril_request_set_amr_wb_enable(boolean amr_wb_enable)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  ims_0024_req_s ims_0024_req;
  
  if(ims_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&ims_0024_req, 0, sizeof(ims_0024_req_s));

  ims_0024_req.t12_valid = TRUE;
  ims_0024_req.t12.amr_wb_enable = amr_wb_enable;

  rc = qmi_ims_set_ims_voip_info((int)ims_client_handle,
                                                &ims_0024_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_ims_set_ims_voip_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}


/*===========================================================================

  FUNCTION  ril_request_get_ims_voip_info
  
===========================================================================*/
uint8 ril_request_get_ims_voip_info(int request, RIL_Ims_Voip_Info *ims_info)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  ims_0029_rsp_s ims_0029_rsp;

  memset(&ims_0029_rsp, 0, sizeof(ims_0029_rsp_s));
  
  if(ims_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_ims_get_ims_voip_info((int)ims_client_handle, &ims_0029_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[IMS] qmi_ims_get_ims_voip_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    switch(request)
    {
      case REQUEST_SESSION_TIMER:
        ims_info->session_expiry_timer = ims_0029_rsp.t11.session_expiry_timer;
      break;

      case REQUEST_MIN_TIMER:
        ims_info->min_session_expiry = ims_0029_rsp.t12.min_session_expiry;
      break;      

      case REQUEST_AMR_WB_ENABLE:
        ims_info->amr_wb_enable = ims_0029_rsp.t13.amr_wb_enable;
      break;         

      case REQUEST_AMR_CODEC_MODE_SET:
        ims_info->amr_mode = ims_0029_rsp.t16.amr_mode;
      break;

      case REQUEST_AMR_WB_CODEC_MODE_SET:
        ims_info->amr_wb_mode = ims_0029_rsp.t17.amr_wb_mode;
      break;       

      case REQUEST_AMR_PAYLOAD_FORMAT:
        ims_info->amr_octet_align = ims_0029_rsp.t18.amr_octet_align;
      break;            

      case REQUEST_AMR_WB_PAYLOAD_FORMAT:
        ims_info->amr_wb_octet_align = ims_0029_rsp.t19.amr_wb_octet_align;
      break;            

      default:
      break;
    }

    return RESULT_SUCCESS;
  }

}

/*===========================================================================

  FUNCTION  ril_request_set_ims_voip_info
  
===========================================================================*/
uint8 ril_request_set_ims_voip_info(int request, RIL_Ims_Voip_Info ims_info)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  ims_0024_req_s ims_0024_req;
  
  if(ims_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&ims_0024_req, 0, sizeof(ims_0024_req_s));

  switch(request)
  {
    case REQUEST_SESSION_TIMER:
      ims_0024_req.t10_valid = TRUE;
      ims_0024_req.t10.session_expiry_timer = ims_info.session_expiry_timer;
    break;

    case REQUEST_MIN_TIMER:
      ims_0024_req.t11_valid = TRUE;
      ims_0024_req.t11.min_session_expiry = ims_info.min_session_expiry;
    break;    

    case REQUEST_AMR_WB_ENABLE:
      ims_0024_req.t12_valid = TRUE;
      ims_0024_req.t12.amr_wb_enable = ims_info.amr_wb_enable;
    break;        

    case REQUEST_AMR_CODEC_MODE_SET:
      ims_0024_req.t15_valid = TRUE;
      ims_0024_req.t15.amr_mode = ims_info.amr_mode;
    break;        

    case REQUEST_AMR_WB_CODEC_MODE_SET:
      ims_0024_req.t16_valid = TRUE;
      ims_0024_req.t16.amr_wb_mode = ims_info.amr_wb_mode;
    break;     

    case REQUEST_AMR_PAYLOAD_FORMAT:
      ims_0024_req.t17_valid = TRUE;
      ims_0024_req.t17.amr_octet_align = ims_info.amr_octet_align;
    break;        

    case REQUEST_AMR_WB_PAYLOAD_FORMAT:
      ims_0024_req.t18_valid = TRUE;
      ims_0024_req.t18.amr_wb_octet_align = ims_info.amr_wb_octet_align;
    break;        

    default:
    break;  
  }

  rc = qmi_ims_set_ims_voip_info((int)ims_client_handle,
                                                &ims_0024_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_ims_set_ims_voip_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}


/*===========================================================================

  FUNCTION  ril_request_get_ims_qipcall_info
  
===========================================================================*/
uint8 ril_request_get_ims_qipcall_info(uint8 *hd_mode)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  ims_0037_rsp_s ims_0037_rsp;

  memset(&ims_0037_rsp, 0, sizeof(ims_0037_rsp_s));
  
  if(ims_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_ims_get_ims_qipcall_info((int)ims_client_handle, &ims_0037_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[IMS] qmi_ims_get_ims_qipcall_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    MSG_HIGH("[IMS] GET_LTE_HD_VOICE : %d", ims_0037_rsp.t13.volte_enabled, 0, 0);
    *hd_mode = ims_0037_rsp.t13.volte_enabled;
    return RESULT_SUCCESS;
  }

}

/*===========================================================================

  FUNCTION  ril_request_set_ims_qipcall_info
  
===========================================================================*/
uint8 ril_request_set_ims_qipcall_info(uint8 hd_mode)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  ims_0036_req_s ims_0036_req;
  
  if(ims_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&ims_0036_req, 0, sizeof(ims_0036_req_s));

  ims_0036_req.t12_valid = TRUE;
  ims_0036_req.t12.volte_enabled = hd_mode;


  rc = qmi_ims_set_ims_qipcall_info((int)ims_client_handle,
                                                &ims_0036_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_ims_set_ims_qipcall_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}

/*===========================================================================

  FUNCTION  ril_request_get_ims_sip_timer_info
  
===========================================================================*/
uint8 ril_request_get_ims_sip_timer_info(RIL_Ims_Sip_Timer_Info *ims_info)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  ims_0025_rsp_s ims_0025_rsp;

  memset(&ims_0025_rsp, 0, sizeof(ims_0025_rsp_s));
  
  if(ims_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  rc = qmi_ims_get_ims_sip_info((int)ims_client_handle, &ims_0025_rsp, &qmi_err_code);

  if(rc != QMI_NO_ERR || qmi_err_code != QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[IMS] qmi_ims_get_ims_sip_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }
  else
  {
    ims_info->timer_t1 = ims_0025_rsp.t14.timer_t1;
    ims_info->timer_t2 = ims_0025_rsp.t15.timer_t2;
    ims_info->timer_f = ims_0025_rsp.t16.timer_f;
    return RESULT_SUCCESS;
  }

}

/*===========================================================================

  FUNCTION  ril_request_set_ims_sip_timer_info
  
===========================================================================*/
uint8 ril_request_set_ims_sip_timer_info(RIL_Ims_Sip_Timer_Info ims_info)
{
  int rc = QMI_NO_ERR;
  int qmi_err_code = QMI_SERVICE_ERR_NONE;
  ims_0020_req_s ims_0020_req;
  
  if(ims_client_handle == INVALID_HANDLE_VALUE)
    return RESULT_FAILURE;

  memset(&ims_0020_req, 0, sizeof(ims_0020_req_s));

  ims_0020_req.t13_valid = TRUE;
  ims_0020_req.t13.timer_t1 = ims_info.timer_t1;

  ims_0020_req.t14_valid = TRUE;
  ims_0020_req.t14.timer_t2 = ims_info.timer_t2;

  ims_0020_req.t15_valid = TRUE;
  ims_0020_req.t15.timer_f = ims_info.timer_f;

  rc = qmi_ims_set_ims_sip_info((int)ims_client_handle,
                                                &ims_0020_req,
                                                &qmi_err_code);
  if(rc!=QMI_NO_ERR || qmi_err_code!=QMI_SERVICE_ERR_NONE)
  {
    MSG_ERROR("[NAS]qmi_ims_set_ims_sip_info!! rc: %d err_code : %d", rc, qmi_err_code, 0);
    return RESULT_FAILURE;
  }

  return RESULT_SUCCESS;

}
