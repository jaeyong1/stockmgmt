/************************************************************************/
/* Function             : apllication tof_app.c																*/
/* Description  				: lib test demo source													*/
/************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <termios.h>
#include <signal.h>
#include <fcntl.h>
#include <poll.h>


#include <sys/signal.h>
#include <sys/types.h>

#include <ctype.h>

#include <errno.h>

#include <time.h>
#include <sys/timeb.h>

#include "TOF_API.h"
#include "TOF_Definition.h"

//Definition
#define        NUL        0x00 
#define        SOH        0x01 
#define        STX        0x02 
#define        ETX        0x03 
#define        EOT        0x04 
#define        ENQ        0x05 
#define        ACK        0x06 
#define        BEL        0x07 
#define        BS         0x08 
#define        HT         0x09 
#define        LF         0x0a 
#define        VT         0x0b 
#define        FF         0x0c 
#define        CR         0x0d 
#define        SO         0x0e 
#define        SI         0x0f 
#define        DLE        0x10 
#define        DC1        0x11 
#define        DC2        0x12 
#define        DC3        0x13 
#define        DC4        0x14 
#define        NAK        0x15 
#define        SYN        0x16 
#define        ETB        0x17 
#define        CAN        0x18 
#define        EM         0x19 
#define        SUB        0x1a 
#define        ESC        0x1b 
#define        FS         0x1c 
#define        GS         0x1d 
#define        RS         0x1e 
#define        US         0x1f 
#define        DEL        0x7f 

#define MAXSIZE			1024
#define HIS_MAX     8

typedef enum
{
	E_MODEM_BASEVERSION = 0x01,
    E_MODEM_GETVENDORID,
    E_MODEM_SETVENDORID,
    E_MODEM_SETMAXPWR,
    
    E_TOF_LOGSTART = 0xFD,
    E_TOF_LOGSTOP = 0xFE,
} DMS_PARAM_TYPE;

typedef struct {
  char *CmdStr;                     				// ���� ���ڿ�
	int (*func)(int argc, char **argv);				// ���� �Լ�
} TCommand;

//function
int TOF_dms_Modem(int argc, char **argv);
int Get_Sim_Status(int argc, char **argv);
int Get_Pin_Status(int argc, char **argv);
int Dial(int argc, char **argv);
int Set_Modem_Mode(int argc, char **argv);
int Get_Imei_Status(int argc, char** argv);
int Get_Number(int argc, char** argv);
int Get_Iccid(int argc, char** argv);
int Modem_Reset(int argc, char **argv);
int Modem_Init(int argc, char **argv);
int Get_Regi_Status(int argc, char **argv);
int Get_Current_Calls(int argc, char **argv);
int Hangup(int argc, char **argv);
int Answer(int argc, char **argv);
int Last_Call_Fail_Cause(int argc, char **argv);
int Get_Imsi(int argc, char **argv);
int Get_Imeisv(int argc, char **argv);
int Enter_Sim_Pin(int argc, char **argv);
int Enter_Puk(int argc, char **argv);
int Change_Sim_Pin(int argc, char **argv);
int Get_Modem_Except_Info(int argc, char **argv);

int Get_Signal_Strength(int argc, char **argv);

int Setup_Data_Call(int argc, char **argv);
int Deactivate_Data_Call(int argc, char **argv);
int Data_Call_List(int argc, char **argv);
int Last_Data_Call_Fail_Cause(int argc, char **argv);
int Set_Data_Auto_Connect(int argc, char **argv);
int Get_Data_Auto_Connect(int argc, char **argv);
int Set_Data_Profile_Info(int argc, char **argv);
int Get_Data_Profile_Info(int argc, char **argv);

//20170215 yjoh add for cell info
int Get_cell_info(int argc, char **argv);
	
int Call_Switch(int argc, char **argv);
int Hangup_Foreground_Resume_Background(int argc, char **argv);
int Hangup_Waiting_Or_Background(int argc, char **argv);
int Dtmf_Start(int argc, char **argv);
int Dtmf_Stop(int argc, char **argv);
int Dtmf(int argc, char **argv);
int Set_volte(int argc, char **argv);
int Get_volte(int argc, char **argv);
int Set_IMS_enable(int argc, char **argv);
int Get_IMS_enable(int argc, char **argv);
int Set_volte_sess_time(int argc, char **argv);
int Get_volte_sess_time(int argc, char **argv);
int Set_amr_payload_format(int argc, char **argv);
int Get_amr_payload_format(int argc, char **argv);
int Set_amr_wb_payload_format(int argc, char **argv);
int Get_amr_wb_payload_format(int argc, char **argv);
int Set_amr_codec_mode_set(int argc, char **argv);
int Get_amr_codec_mode_set(int argc, char **argv);
int Set_amr_wb_codec_mode_set(int argc, char **argv);
int Get_amr_wb_codec_mode_set(int argc, char **argv);
int Set_amr_wb_enable(int argc, char **argv);
int Get_amr_wb_enable(int argc, char **argv);
int Set_rtcp_enable(int argc, char **argv);
int Get_rtcp_enable(int argc, char **argv);
int Set_pcscf_port(int argc, char **argv);
int Get_pcscf_port(int argc, char **argv);
int Set_pcscf_domain(int argc, char **argv);
int Get_pcscf_domain(int argc, char **argv);
int Set_ims_test_mode(int argc, char **argv);
int Get_ims_test_mode(int argc, char **argv);
int Set_sip_local_port(int argc, char **argv);
int Get_sip_local_port(int argc, char **argv);
int Set_sip_reg_timer(int argc, char **argv);
int Get_sip_reg_timer(int argc, char **argv);
int Set_sip_subscribe_timer(int argc, char **argv);
int Get_sip_subscribe_timer(int argc, char **argv);

//dsji_20160311 add {
int	Send_SMS( int arg_c, char** arg_v );
int Delete_SMS( int arg_c, char** arg_v );
int Read_SMS( int arg_c, char** arg_v );
int List_SMS( int arg_c, char** arg_v );
int Get_SMSC( int arg_c, char** arg_v );
int Set_SMSC( int arg_c, char** arg_v );
int Get_SMS_memory_status( int arg_c, char** arg_v );
int Test_SMS( int arg_c, char** arg_v );
//dsji_20160311 add }

int Set_pref_network(int argc, char **argv);
int Get_pref_network(int argc, char **argv);
int Set_pref_mode(int argc, char **argv);
int Get_pref_mode(int argc, char **argv);
int Set_Service_Domain(int argc, char **argv);
int Get_Service_Domain(int argc, char **argv);
int Set_wcdma_rrc_version(int argc, char **argv);
int Get_wcdma_rrc_version(int argc, char **argv);
int Set_wcdma_sms_mo_domain(int argc, char **argv);
int Get_wcdma_sms_mo_domain(int argc, char **argv);
int Set_isr_enable(int argc, char **argv);
int Get_isr_enable(int argc, char **argv);
int Delete_stored_cell(int argc, char **argv);
int Get_network_selection_mode(int argc, char **argv);
int Set_network_selection_auto(int argc, char **argv);
int Get_operator(int argc, char **argv);
int Get_ims_auth_scheme(int argc, char **argv);
int Set_ims_auth_scheme(int argc, char **argv);
int Get_ims_param_src(int argc, char **argv);
int Set_ims_param_src(int argc, char **argv);
int Get_ims_reg_event_enable(int argc, char **argv);
int Set_ims_reg_event_enable(int argc, char **argv);
int Get_voip_srv_status(int argc, char **argv);
int Get_ims_srv_status(int argc, char **argv);

int Set_GPS_reg_event(int argc, char **argv);
int Set_GPS_Func(int argc, char **argv);
int Set_GPS_Operation_Mode(int argc, char **argv);
int Get_GPS_Operation_Mode(int argc, char **argv);
int Set_GPS_nmea_type(int argc, char **argv);
int Get_GPS_nmea_type(int argc, char **argv);
int Get_GPS_reg_event(int argc, char **argv);
int Set_GPS_SPL_Server_Info(int argc, char **argv);
int Get_GPS_SPL_Server_Info(int argc, char **argv);
int Get_GPS_SPL_Server_conn_handle(int argc, char **argv);
int GPS_Del_Assist_Data(int argc, char **argv);
int GPS_GPS_Coordinates(int argc, char **argv);
int GPS_GPS_getHeading(int argc, char **argv);
int GPS_GPS_getSpeed(int argc, char **argv);
int GPS_GPS_getVerticalSpeed(int argc, char **argv);
int GPS_GPS_getVDOP(int argc, char **argv);
int GPS_GPS_getHDOP(int argc, char **argv);
int GPS_GPS_getPDOP(int argc, char **argv);
int GPS_GPS_getSpeedAccuracy(int argc, char **argv);
int GPS_GPS_getAltitudeMSL(int argc, char **argv);
int GPS_GPS_getHorizontalAccuracy(int argc, char **argv);

int GPS_getGnssSVInfo(int argc, char **argv);
int GPS_getPositionInfo(int argc, char **argv);

int Config_Gpio(int argc, char **argv);
int Config_Gpio_Print(int argc, char **argv);
int Intr_Gpio(int argc, char **argv);
int Set_Gpio(int argc, char **argv);
int Get_Gpio(int argc, char **argv);
int Set_Gpio_Edge(int argc, char **argv);
int Connect_WiFi(int argc, char **argv);
int Get_TOF_version(int argc, char **argv);

// LGInnotek-SH.Lee-20160919, 
int Dial_ecall(int argc, char **argv);

int MSDSet(int argc, char **argv);

//20160926 jaeyong1.park
int Set_ecall_enable (int argc, char **argv);

//20160929 jaeyong1.park
int Set_ecall_number (int argc, char **argv);
int Set_ecall_vocconf  (int argc, char **argv);
int Set_ecall_cannedmsd  (int argc, char **argv);
int Set_ecall_numtodial  (int argc, char **argv);
int Set_ecall_gnsssestimeout (int argc, char **argv);
int Set_ecall_callbacktimeout  (int argc, char **argv);

//20170220 jaeyong1.park
int Get_gsm_dtmsupported(int argc, char **argv);
int Get_gsm_pathloss_criteria (int argc, char **argv);

//20161017 jaeyong1.park
int Get_ecall_enable(int argc, char **argv);

//20161019 jaeyong1.park
int Get_ecall_number(int argc, char **argv);
int Get_ecall_vocconf(int argc, char **argv);
int Get_ecall_cannedmsd(int argc, char **argv);
int Get_ecall_numtodial(int argc, char **argv);
int Get_ecall_gnsssestimeout(int argc, char **argv);
int Get_ecall_callbacktimeout(int argc, char **argv);

//20170113 jaeyong1.park
int Get_modem_ver(int argc, char **argv);
int Get_isroaming(int argc, char **argv);
int Get_networkscan(int argc, char **argv);

//20170217 yhbyun
int get_thermal_info(int argc, char **argv);



//20161011 mwkim
int Set_ecall_only_mode (int argc, char **argv);

//20161014 mwkim
int Get_ecall_oper_mode (int argc, char **argv);

//Bosch
int unlock_sim(int argc, char **argv);
int is_locked(int argc, char **argv);
int is_enabled(int argc, char **argv);
int get_subsid(int argc, char **argv);
int get_iccident(int argc, char **argv);
int is_present(int argc, char **argv);
int get_fplmn(int argc, char **argv);
int set_fplmn(int argc, char **argv);
int get_imsi_long(int argc, char **argv);
int get_msin_long(int argc, char **argv);
int get_mcc(int argc, char **argv);
int get_mnc(int argc, char **argv);
int get_msin_string(int argc, char **argv);
int get_mcc_string(int argc, char **argv);
int get_mnc_string(int argc, char **argv);
int set_sim_event(int argc, char **argv);
int TOF_TELE_change_usb_composition(int argc, char **argv);
int TOF_TELE_get_enabled_usb_composition(int argc, char **argv);
int TOF_TELE_disable_usb_composition(int argc, char **argv);
int TOF_TELE_get_usb_mode(int argc, char **argv);
int TOF_TELE_change_usb_mode(int argc, char **argv);
int TOF_TELE_get_usb_storage_state(int argc, char **argv);
int set_clock_config(int argc, char **argv);
int get_current_clock(int argc, char **argv);
int set_ring_low(int argc, char **argv);
int set_reboot(int argc, char **argv);
int get_reboot(int argc, char **argv);

TCommand Cmds[] =
{
  //DMS
  { "DMS", TOF_dms_Modem },
  { "GETSIM", Get_Sim_Status },
  { "GETPIN", Get_Pin_Status },
  { "SETOPERMODE", Set_Modem_Mode},
  { "GETIMEI", Get_Imei_Status},
  { "GETIMSI", Get_Imsi},
  { "GETIMEISV", Get_Imeisv},
  { "MODEMRESET", Modem_Reset},
  { "MODEMINIT", Modem_Init},
  { "GETNUMBER", Get_Number},
  { "GETICCID", Get_Iccid},
  { "ENTERPIN1", Enter_Sim_Pin},
  { "ENTERPIN2", Enter_Sim_Pin},
  { "ENTERPUK1", Enter_Puk},
  { "ENTERPUK2", Enter_Puk},
  { "CHANGEPIN1", Change_Sim_Pin},
  { "CHANGEPIN2", Change_Sim_Pin},
  { "EXCEPINFO", Get_Modem_Except_Info},
  { "TOFVERSION", Get_TOF_version},

  //NAS
  { "REGISTAT", Get_Regi_Status },
  { "SIGINFO", Get_Signal_Strength },
  { "SETPREF", Set_pref_mode },
  { "GETPREF", Get_pref_mode },    
  { "SETSERVICEDOMAIN", Set_Service_Domain }, 
  { "GETSERVICEDOMAIN", Get_Service_Domain },   
  { "SETWCDMARRCVERSION", Set_wcdma_rrc_version}, 
  { "GETWCDMARRCVERSION", Get_wcdma_rrc_version },  
  { "SETWCDMASMSMODOMAIN", Set_wcdma_sms_mo_domain}, 
  { "GETWCDMASMSMODOMAIN", Get_wcdma_sms_mo_domain},  
  { "SETISRENABLE", Set_isr_enable}, 
  { "GETISRENABLE", Get_isr_enable },  
  { "DELETESTOREDCELL", Delete_stored_cell },  
  { "GETNETWORKMODE", Get_network_selection_mode },    
  { "SETNETWORKAUTOMODE", Set_network_selection_auto },   
  { "GETOPERATOR", Get_operator },     
  { "GETIMSAUTHSCHM", Get_ims_auth_scheme }, 
  { "SETIMSAUTHSCHM", Set_ims_auth_scheme },
  { "GETIMSPARAMSRC", Get_ims_param_src }, 
  { "SETIMSPARAMSRC", Set_ims_param_src },  
  { "GETIMSREGEVTEN", Get_ims_reg_event_enable },  
  { "SETIMSREGEVTEN", Set_ims_reg_event_enable }, 
  { "GETVOIPSRVSTAT", Get_voip_srv_status },  
  { "GETIMSSRVSTAT", Get_ims_srv_status },  
//20170215 yjoh add for cell info
	{ "GETCELLINFO", Get_cell_info },  
    
  //VOICE
  { "DIAL", Dial },
  { "GETCALLS", Get_Current_Calls},
  { "HANGUP", Hangup},  
  { "ANSWER", Answer},
  { "CALLSWITCH", Call_Switch},  
  { "HANGUPFRB", Hangup_Foreground_Resume_Background},  
  { "HANGUPWOB", Hangup_Waiting_Or_Background},
  { "DTMFSTART", Dtmf_Start},  
  { "DTMFSTOP", Dtmf_Stop},  
  { "DTMF", Dtmf},
  { "LASTCALLFAIL", Last_Call_Fail_Cause},
  { "SETVOLTE", Set_volte},
  { "GETVOLTE", Get_volte},
  { "SETIMS", Set_IMS_enable},
  { "GETIMS", Get_IMS_enable},
  { "SETSESSTIME", Set_volte_sess_time},
  { "GETSESSTIME", Get_volte_sess_time},
  { "SETAMRPLOADFMT", Set_amr_payload_format},
  { "GETAMRPLOADFMT", Get_amr_payload_format},
  { "SETAMRWBPLOADFMT", Set_amr_wb_payload_format},
  { "GETAMRWBPLOADFMT", Get_amr_wb_payload_format},
  { "SETAMRCODECMODSET", Set_amr_codec_mode_set},
  { "GETAMRCODECMODSET", Get_amr_codec_mode_set},
  { "SETAMRWBCODECMODSET", Set_amr_wb_codec_mode_set},
  { "GETAMRWBCODECMODSET", Get_amr_wb_codec_mode_set},
  { "SETAMRWBENABLE", Set_amr_wb_enable},
  { "GETAMRWBENABLE", Get_amr_wb_enable},
  { "SETRTCPENABLE", Set_rtcp_enable},
  { "GETRTCPENABLE", Get_rtcp_enable},
  { "SETPCSCFPORT", Set_pcscf_port},
  { "GETPCSCFPORT", Get_pcscf_port},
  { "SETPCSCFDOMAIN", Set_pcscf_domain},
  { "GETPCSCFDOMAIN", Get_pcscf_domain},
  { "SETIMSTSTMODE", Set_ims_test_mode},
  { "GETIMSTSTMODE", Get_ims_test_mode},  
  { "SETSIPLOCALPORT", Set_sip_local_port},
  { "GETSIPLOCALPORT", Get_sip_local_port},
  { "SETSIPREGTIMER", Set_sip_reg_timer},
  { "GETSIPREGTIMER", Get_sip_reg_timer},
  { "SETSIPSUBSCTIMER", Set_sip_subscribe_timer},
  { "GETSIPSUBSCTIMER", Get_sip_subscribe_timer},
   // LGInnotek-SH.Lee-20160919, 
  { "ECALL", Dial_ecall },

  { "MSDSET", MSDSet},

	//LG innotek. jaeyong1.park 
  { "ECALLON", Set_ecall_enable },
  { "SETECALLNUM", Set_ecall_number },  
  { "SETECALL_VOCCONFIG", Set_ecall_vocconf },
  { "SETECALL_CANNEDMSD", Set_ecall_cannedmsd },
  { "SETECALL_NUMTODIAL", Set_ecall_numtodial },    
  { "SETECALL_GNSS_SESSUPDATETIME", Set_ecall_gnsssestimeout },  
  { "SETECALL_CALLBACK_TIMEOUT", Set_ecall_callbacktimeout },  

  { "GETECALLON", Get_ecall_enable },	
  { "GETECALLNUM", Get_ecall_number },  
  { "GETECALL_VOCCONFIG", Get_ecall_vocconf },
  { "GETECALL_CANNEDMSD", Get_ecall_cannedmsd },
  { "GETECALL_NUMTODIAL", Get_ecall_numtodial },    
  { "GETECALL_GNSS_SESSUPDATETIME", Get_ecall_gnsssestimeout },  
  { "GETECALL_CALLBACK_TIMEOUT", Get_ecall_callbacktimeout },  

  { "GETGSMDTM", Get_gsm_dtmsupported },
  { "GETGSMPATHLOSS", Get_gsm_pathloss_criteria },

  // modem version
  { "GETMODEMVER", Get_modem_ver },	
  { "ISROAMING", Get_isroaming },

  // network search
  { "NETSCAN", Get_networkscan },
  

  	//LG innotek. mwkim
  { "SETECALLONLY", Set_ecall_only_mode },
  { "GETECALLMODE", Get_ecall_oper_mode },
  
  //DATA
  { "SETUPDATACALL", Setup_Data_Call},
  { "DEACTIVATEDATACALL", Deactivate_Data_Call},
  { "DATACALLLIST", Data_Call_List},
  { "LASTDATACALLFAILCAUSE", Last_Data_Call_Fail_Cause},
  { "SETDATAAUTOCONNECT", Set_Data_Auto_Connect},
  { "GETDATAAUTOCONNECT", Get_Data_Auto_Connect},
  { "SETDATAPROFILE", Set_Data_Profile_Info},
  { "GETDATAPROFILE", Get_Data_Profile_Info},

  //SMS
  //dsji_20160311 add {
  { "SEND_SMS", Send_SMS },
  { "DELETE_SMS", Delete_SMS },
  { "READ_SMS", Read_SMS },  
  { "LIST_SMS", List_SMS },  
  { "GET_SMSC", Get_SMSC },
  { "SET_SMSC", Set_SMSC },
  { "GET_SMS_MEM_STAT", Get_SMS_memory_status },  
  { "TEST_SMS", Test_SMS },
  //dsji_20160311 add }
  
  //LOC
  { "GPSREG", Set_GPS_reg_event },   
  { "GPSSET", Set_GPS_Func }, 
  { "GPSGETREGEVENT", Get_GPS_reg_event },    
  { "SETGPSOPERMODE", Set_GPS_Operation_Mode },  
  { "GETGPSOPERMODE", Get_GPS_Operation_Mode },    
  { "SETNMEATYPE", Set_GPS_nmea_type },  
  { "GETNMEATYPE", Get_GPS_nmea_type },   
  { "SETSPLSVINFO", Set_GPS_SPL_Server_Info },
  { "GETSPLSVINFO", Get_GPS_SPL_Server_Info },
  { "GPSSPLSVCONNHDL", Get_GPS_SPL_Server_conn_handle },
  { "GPSDELASSISTDATA", GPS_Del_Assist_Data },
  { "GETCOORDINATES", GPS_GPS_Coordinates },
  { "GETHEADING", GPS_GPS_getHeading },
  { "GETSPEED", GPS_GPS_getSpeed },
  { "GETVSPEED", GPS_GPS_getVerticalSpeed },  
  { "GETVDOP", GPS_GPS_getVDOP},  
  { "GETHDOP", GPS_GPS_getHDOP },  
  { "GETPDOP", GPS_GPS_getPDOP },  
  { "GETSACCURACY", GPS_GPS_getSpeedAccuracy},  
  { "GETALTMSL", GPS_GPS_getAltitudeMSL },  
  { "GETHACCURACY", GPS_GPS_getHorizontalAccuracy },  
  { "GETSATELITES", GPS_getGnssSVInfo },  
  { "GETPOSITIONINFO", GPS_getPositionInfo },  

  //AP
  { "CONFIG_GPIO", Config_Gpio },
  { "INTR_GPIO", Intr_Gpio },
  { "PRINT_GPIO", Config_Gpio_Print },
  { "SET_GPIO_EDGE", Set_Gpio_Edge },
  { "SET_GPIO", Set_Gpio }, 
  { "GET_GPIO", Get_Gpio }, 
  
  //THERMAL MITIGATION
  { "GET_THERMAL_INFO", get_thermal_info }, 
  //WLAN
  { "CONNECT_WIFI", Connect_WiFi}, 
  { "DISCONNECT_WIFI", TOF_wifi_disconnect}, 
  {"LOAD_WIFI_MODULE", TOF_wifi_module_load},
  {"UNLOAD_WIFI_MODULE", TOF_wifi_module_unload},

  //AUDIO CONTROL
  {"START_VOICE_CALL", TOF_START_VOICE_CALL},
  {"END_VOICE_CALL", TOF_END_VOICE_CALL},
  {"AUDIO_LOOPBACK", TOF_AUDIO_LOOBACK},
  {"TONE_PLAY", TOF_TONE_PLAY},

  //Bosch Java
  {"UNLOCK_SIM", unlock_sim},
  {"IS_LOCKED", is_locked},
  {"IS_ENABLED", is_enabled},  
  {"GET_SUBSID", get_subsid},
  {"GET_ICCIDENT", get_iccident},
  {"ISPRESENT", is_present},
  {"GET_FPLMN", get_fplmn},
  {"SET_FPLMN", set_fplmn},
  {"GET_IMSI", get_imsi_long},
  {"GET_MSIN", get_msin_long},
  {"GET_MCC", get_mcc},
  {"GET_MNC", get_mnc},  

  {"GET_SMSIN", get_msin_string},
  {"GET_SMCC", get_mcc_string},
  {"GET_SMNC", get_mnc_string},  
  {"SET_SIMEVT", set_sim_event},  

  {"CHANGE_USB_COMPOSITION", TOF_TELE_change_usb_composition},
  {"GET_ENABLED_USB_COMPOSITION", TOF_TELE_get_enabled_usb_composition},
  {"DISABLE_USB_COMPOSITION", TOF_TELE_disable_usb_composition},

  {"GET_USB_MODE", TOF_TELE_get_usb_mode},
  {"CHANGE_USB_MODE", TOF_TELE_change_usb_mode},

  {"GET_USB_STORAGE_STATE", TOF_TELE_get_usb_storage_state},

  {"SET_CLKCONFIG", set_clock_config}, 
  {"GET_CURRENTCLK", get_current_clock}, 
  {"SET_RINGLOW", set_ring_low},
  {"SET_REBOOT", set_reboot},
  {"GET_REBOOT", get_reboot},

  { NULL   		, NULL            	}
};

//Global Variable
int main_run_flag = FALSE;

char HisBuff[HIS_MAX][32] = { {0,}, };
int  HisCount               = 0;
int  HisIndex               = 0;

//------------------------------------------------------------------------------
// Description : �����丮�� �߰� �Ѵ�. 
// Parameters : s : ������ ���� �ּ� 
// Return Values : ���� ���ۿ� ����� �����丮 ��
// Remarks : 
//------------------------------------------------------------------------------
int his_append(char *s)
{
    int loop;

    // �̹� ���� ���ڿ��� ������ �����Ѵ�. 
    for( loop = 0; loop < HIS_MAX; loop++ )
    {
      if( strcmp( s, HisBuff[loop] ) == 0 ) 
      {
          HisIndex = 0;
          if( HisCount ) HisIndex = HisCount-1;
          return HisCount;
      } 
    } 

    // ���ο� ������ �����丮 ���ۿ� �߰� �Ѵ�. 
    if( HisCount < HIS_MAX )
    {
        strcpy( HisBuff[HisCount], s );
        HisCount++;
    }
    else
    {   
        for( loop = 1; loop < HIS_MAX ; loop++ )
        {
            strcpy( HisBuff[loop-1], HisBuff[loop] );
        }
        strcpy( HisBuff[HIS_MAX-1], s );
        HisIndex = HisCount-1;
    }

    HisIndex = 0; 
    if( HisCount ) HisIndex = HisCount-1;
    	
    return HisCount;
}

//------------------------------------------------------------------------------
// Description : �����丮�� ���� ���ۿ� �����Ѵ�. 
// Parameters : s : ������ ���� 
//        index : ������ ����  
// Return Values : ���� 
// Remarks : 
//------------------------------------------------------------------------------
int his_set(char *s, int index )
{
    int loop;
    int len;

    len = strlen( s );

    // ���� ���� ���ڿ��� �����. 
    for( loop = 0; loop < len; loop++ )
    {
      printf("\b \b");
    }
     
    // ���� ������ �����Ѵ�. 
    strcpy( s, HisBuff[index] ); 
    printf( "%s", s );

    return index;
}

//------------------------------------------------------------------------------
// Description : ���ڿ� �Է��� �޴´�. ( LF�� �Էµɶ����� )
// Parameters : ���� 
// Return Values : ���� 
// Remarks : �����丮 ����� �߰� �Ͽ���. 
//------------------------------------------------------------------------------
int gets_his(char *s)
{
     int cnt = 0;
     char  *fp;
     char  c;

     fp = s;
  
     while( 1 )
     {
          c = getchar();

          if( c == LF )		// CR�� ���� �ȵ�, LF�� �����ؾ� ��.
          {
              *s = 0;
              if( strlen( fp ) ) {
              	his_append( fp );
              }
              break;
          } 

          switch( c )
          {
          case 0x1a  : // ^Z
                       if( HisIndex >= 0 )
                       { 
                           his_set( fp, HisIndex );
                           if( HisIndex ) HisIndex--;
                           if( HisIndex >= HisCount ) HisIndex = HisCount -1;
                           cnt = strlen( fp );
                           s = fp + cnt; 
                       } 
                       break;
          case 0x18  : // ^X
                       if( HisIndex < HisCount )
                       { 
                           his_set( fp, HisIndex );
                           HisIndex++;
                           cnt = strlen( fp );
                           s = fp + cnt; 
                       }  
                       break;
      
          case BS    :
			if( cnt > 0 )
			{ 
				cnt--; *s-- = ' '; 
				printf("\b \b");  
			} 
			break;
          default    :
		  	if(c >= 0x20 && c <= 0x7A) //0x20: SP, 0x30: '1', 0x41: 'a', 0x7A: 'z'
		  	{
				cnt++;
				*s++ = c;
				//printf("%c 0x%x",c,c );
		  	}
			break;
          }
     }
   
     return(cnt);
}

//------------------------------------------------------------------------------
// Description : ���ɹ��ڸ� �� ��ū���� �и��Ͽ� ��ȯ�Ѵ�. 
// Parameters : cmdline : ���ɶ���
//        argv    : �и��� ��ū ���ڿ� �ּҰ� ����� �迭 
// Return Values : ��ū�� 
// Remarks : 
//------------------------------------------------------------------------------
static const char *delim = " \f\n\r\t\v";
static int parse_args(char *cmdline, char **argv)
{
	char *tok;
	int argc = 0;

	//printf("parse_args cmdline: %s argv[0]: %s argv[1]: %s \n", cmdline, argv[0], argv[1]);

	argv[argc] = NULL;
                   
	for (tok = strtok(cmdline, delim); tok; tok = strtok(NULL, delim)) 
 	{
 		//printf("parse_args cmdline: %s argv[%d]: %s  \n", cmdline, argc, argv[argc]);
		argv[argc++] = tok;
	}

	return argc;
}

char Hex2Char(char const* szHex)
{
  if(*szHex >= '0' && *szHex <= '9')
    return (*szHex - '0');
  else if(*szHex >= 'A' && *szHex <= 'F')
    return (*szHex - 55); //-'A' + 10
  else
    return 0xFF; 
}

//------------------------------------------------------------------------------
// Description : �빮�� ���ڿ��� �ٲ۴�. 
//------------------------------------------------------------------------------
void UpperStr( char *Str )
{
   while( *Str ){ *Str = toupper( *Str ); Str++; }
}
//------------------------------------------------------------------------------
// Description : �ҹ��� ���ڿ��� �ٲ۴�. 
//------------------------------------------------------------------------------
void LowerStr( char *Str )
{
   while( *Str ){ *Str = tolower( *Str ); Str++; }
}


/*===========================================================================

FUNCTION get_time_stamp_str
 
DESCRIPTION
  
===========================================================================*/
char *get_timestamp_str()
{
	static char time_stamp[25];
	long tm_msec = 0;
	struct timeval timeval;
	gettimeofday(&timeval, 0); // microsecond ����: gettimeofday(), Sec ����: time()
	struct tm* currentTime;
	currentTime = localtime( &timeval.tv_sec );
	tm_msec = timeval.tv_usec/1000;
		
	sprintf(time_stamp, "%04d-%02d-%02d %02d:%02d:%02d.%03d",
											currentTime->tm_year+1900,		
											currentTime->tm_mon+1,
											currentTime->tm_mday,
											currentTime->tm_hour,
											currentTime->tm_min,
											currentTime->tm_sec,
											(int)tm_msec);

	return time_stamp;
}

void CBF_Event(uint32 dwEvent, uint32 wParam, uint32 lParam, void *pUserData)
{
  char tmp_buf[256] = {0};
  char tmp_gps_buf[256] = {0};  
  char tmp_callIndMsgRawData[512] = {0, };  
  TOF_nas_available_networks tofnetinfo;
  int i;
  
  TOF_SignalStrength tof_signal_strength;

//    printf("CBF_Event:dwEvent =%d, wParam =%ld, lParam =%ld\n", wParam, lParam);
    switch(dwEvent)
    {
      case TOF_EVENT_NULL:
      printf("CBF_Event:TOF_EVENT_NULL, %ld, %ld\n", wParam, lParam);
      break;

      //DMS
      case TOF_EVENT_GET_MODEM_VERSION:
      printf("CBF_Event:TOF_EVENT_GET_MODEM_VERSION, %ld, %ld\n", wParam, lParam);
      break;

      //NAS
      case TOF_EVENT_NETWORK_STATE_CHANGED:
      printf("CBF_Event:TOF_EVENT_NETWORK_STATE_CHANGED\n");
       {
        memcpy(tmp_buf, (char*)lParam, sizeof(tmp_buf));
        printf("CBF_Event:srv_status : %s\n", tmp_buf);
        printf("CBF_Event:srv_status : %s\n", (char*)lParam);
       }
      break;
      
      case TOF_EVENT_SIGNAL_STRENGTH_CHANGED:
      printf("CBF_Event:TOF_EVENT_SIGNAL_STRENGTH_CHANGED\n");
       {
        /*
        memcpy(&tof_signal_strength, (TOF_SignalStrength*)lParam, sizeof(TOF_SignalStrength));
        printf("CBF_Event:signal strength : LTE RSSI=%d, RSRQ=%d, RSRP=%d, RSSNR=%d\n", tof_signal_strength.LTE_SignalStrength.signalStrength,
                                                                                                                                           tof_signal_strength.LTE_SignalStrength.rsrq,
                                                                                                                                           tof_signal_strength.LTE_SignalStrength.rsrp,
                                                                                                                                           tof_signal_strength.LTE_SignalStrength.rssnr);

        printf("CBF_Event:signal strength : WCDMA Signal Strength = %d BER = %d\n", tof_signal_strength.GW_SignalStrength.signalStrength,
                                                                                                                             tof_signal_strength.GW_SignalStrength.bitErrorRate);
        */                                                                                                                     
       }
      break;
      
      //UIM
      case TOF_EVENT_RESPONSE_SIM_STATUS_CHANGED:
      printf("CBF_Event:TOF_EVENT_RESPONSE_SIM_STATUS_CHANGED, %ld, %ld\n", wParam, lParam);
      break;

	  //VOICE
	  case TOF_EVENT_RESPONSE_CALL_STATE_CHANGED:
	  printf("CBF_Event:TOF_EVENT_RESPONSE_CALL_STATE_CHANGED\n");
		//Test Code
		Get_Current_Calls(1, NULL);
	  break;

      //DATA
      case TOF_EVENT_DATA_STATUS_CHANGED:
      printf("CBF_Event:TOF_EVENT_DATA_STATUS_CHANGED, %ld, %ld\n", wParam, lParam);
      break;

			//dsji_20160311 add {
			case TOF_EVENT_IND_RESPONSE_NEW_SMS:
      printf( "CBF_Event:TOF_EVENT_IND_RESPONSE_NEW_SMS, message_index:%d\n", wParam, lParam );
			break;
			//dsji_20160311 add }

      case TOF_EVENT_POSITION_REPORT_IND:
      //printf( "CBF_Event:TOF_EVENT_POSITION_REPORT_IND");
      {
        memcpy(tmp_gps_buf, (char*)lParam, sizeof(tmp_gps_buf));
        printf("POSITION : [%s] %s\n", get_timestamp_str(),tmp_gps_buf);
        //printf("CBF_Event:POSITION : %s\n", (char*)lParam);
      }
      break;

      case TOF_EVENT_POSITION_NMEA_REPORT_IND:
      //printf( "CBF_Event:TOF_EVENT_POSITION_NMEA_REPORT_IND");
      {
        memcpy(tmp_gps_buf, (char*)lParam, sizeof(tmp_gps_buf));
        printf("NMEA     : [%s] %s\n", get_timestamp_str(),tmp_gps_buf);
        //printf("CBF_Event:POSITION : %s\n", (char*)lParam);
      }
      break;

      case TOF_EVENT_GNSS_SV_INFO_IND:
        memcpy(tmp_gps_buf, (char*)lParam, sizeof(tmp_gps_buf));
        printf("SV INFO  : [%s] %s\n", get_timestamp_str(),tmp_gps_buf);
      break;

      case TOF_EVENT_GPS_SET_OPERATION_MODE_IND:
      printf( "CBF_Event:TOF_EVENT_GPS_SET_OPERATION_MODE_IND");
      {
        printf("CBF_Event: : %s\n", (char*)lParam);
      }
      break;

      case TOF_EVENT_GPS_GET_OPERATION_MODE_IND:
      printf( "CBF_Event:TOF_EVENT_GPS_GET_OPERATION_MODE_IND");
      {
        printf("CBF_Event: %s\n", (char*)lParam);
      }
      break;

      case TOF_EVENT_GPS_SET_NMEA_TYPE_IND:
      printf( "CBF_Event:TOF_EVENT_GPS_SET_NMEA_TYPE_IND");
      {
        printf("CBF_Event: : %s\n", (char*)lParam);
      }
      break;

      case TOF_EVENT_GPS_GET_NMEA_TYPE_IND:
      printf( "CBF_Event:TOF_EVENT_GPS_GET_NMEA_TYPE_IND");
      {
        printf("CBF_Event: %s\n", (char*)lParam);
      }
      break;

		  case TOF_EVENT_GPIO_USB_CONNECTED_IND:
      printf( "CBF_Event:TOF_EVENT_GPIO_USB_CONNECTED_IND");
      {
        printf("CBF_Event: %s\n", (char*)lParam);
      }
      break;	

      case TOF_EVENT_GET_REGISTERED_EVENT_IND:
      printf( "CBF_Event:TOF_EVENT_GET_REGISTERED_EVENT_IND");
      {
        printf("CBF_Event: %s\n", (char*)lParam);
      }
      break;			

      case TOF_EVENT_WAKEUP_STATE_CHANGED:
      printf( "TOF_EVENT_WAKEUP_STATE_CHANGED\n");
      {
//        printf("CBF_Event: %s\n", (char*)lParam);
      }
      break;
      case TOF_EVENT_USB_STORAGE_CHANGED:
      printf( "TOF_EVENT_USB_STORAGE_CHANGED\n");
      {
        printf("CBF_Event: %s\n", (char*)lParam);
      }
      break;
      case TOF_EVENT_SET_SUPL_SERVER_INFO_IND:
      printf( "TOF_EVENT_SET_SUPL_SERVER_INFO_IND\n");
      {
        printf("CBF_Event: %s\n", (char*)lParam);
      }
      break;
      case TOF_EVENT_GET_SUPL_SERVER_INFO_IND:
      printf( "TOF_EVENT_GET_SUPL_SERVER_INFO_IND\n");
      {
        printf("CBF_Event: %s\n", (char*)lParam);
      }
      break;
      case TOF_EVENT_DELETE_ASSIST_DATA_IND:
      printf( "TOF_EVENT_DELETE_ASSIST_DATA_IND\n");
      {
        printf("CBF_Event: %s\n", (char*)lParam);
      }
      break;

	  //eCall
	  case TOF_EVENT_ECALL_IND:
	  printf("CBF_Event:TOF_EVENT_ECALL_IND, event : %d \n", wParam);
	  break;

	  case TOF_EVENT_RESPONSE_CALL_STATE_CHANGED_TO_DELAYED_HANGUP:
	  	printf("CBF_Event:TOF_EVENT_RESPONSE_CALL_STATE_CHANGED_TO_DELAYED_HANGUP, call id : %d \n", wParam);
	  	break;

	  case TOF_EVENT_RESPONSE_CALL_STATE_CHANGED_CALLMSG_RAWDATA:
        //memcpy(tmp_callIndMsgRawData, (char*)lParam, sizeof(tmp_callIndMsgRawData));
		//printf("[TeleApp] %s\n", tmp_callIndMsgRawData);
		// -- ONLY for JAVA API --
		// -- DO NOTHING --
	  	break;


      // Added Jamming detection Indication
      case TOF_EVENT_JAMMING_RF_REPORT_IND:
      //printf( "CBF_Event:TOF_EVENT_JAMMING_RF_REPORT_IND");
      {
        memcpy(tmp_gps_buf, (char*)lParam, sizeof(tmp_gps_buf));
        printf("JAMMING : [%s] %s\n", get_timestamp_str(),tmp_gps_buf);
        //printf("CBF_Event:POSITION : %s\n", (char*)lParam);
      }
      break;  
    

	  case TOF_EVENT_RESPONSE_ASYNC_NETWORK_SEARCH_FINISHED:
	  	printf("TOF_EVENT_RESPONSE_ASYNC_NETWORK_SEARCH_FINISHED\n");
		memcpy(&tofnetinfo, (char*)lParam, sizeof(tofnetinfo));
		
		printf("[TeleApp] scan result %d\n", tofnetinfo.num_of_networks );
		for (i=0; i< tofnetinfo.num_of_networks ; i++)
		{
			printf(" [%d] MCC %d MNC %d RAT %d - U %d R %d F %d P %d - %s \n",
				i,
				tofnetinfo.networks[i].mobile_country_code,
				tofnetinfo.networks[i].mobile_network_code,
				tofnetinfo.networks[i].rat,
				tofnetinfo.networks[i].in_use_status,
				tofnetinfo.networks[i].roaming_status,
				tofnetinfo.networks[i].forbidden_status,				
				tofnetinfo.networks[i].preferred_status,
				tofnetinfo.networks[i].network_description
				);
		}		
	  	break;

		case TOF_EVENT_RESPONSE_NAS_SIM_STATE_CHANGED:
			printf("CBF_Event:TOF_EVENT_RESPONSE_NAS_SIM_STATE_CHANGED, event : %d \n", wParam);
			break;

      default:
      printf("CBF_Event:Unkown Event, %ld, %ld\n", wParam, lParam);  
      break;
    }
  
}

int TOF_dms_Modem(int argc, char **argv)
{
	int nType = 0;
	int nRet;
	char *pBaseband_version=NULL;
   tof_dms_get_modem_sw_version_resp_msg modem_sw_version;
   uint8 vendorID, tmp;
   tof_dms_max_power_type_v01 max_pwr;
   	
	if(argc < 2)
	{
		printf("    DMS [type]\n");
		printf("    [type]: MODEMVERSION\n");
		printf("EX) DMS MODEMVERSION\n");       
	}
	else
	{
		UpperStr( argv[1] );
        if(strcmp(argv[1], "MODEMVERSION") == 0)
		{
			nType = E_MODEM_BASEVERSION;
		}
        else if(strcmp(argv[1], "GETVENDORID") == 0)
		{
			nType = E_MODEM_GETVENDORID;
		}
         else if(strcmp(argv[1], "SETVENDORID") == 0)
		{
			nType = E_MODEM_SETVENDORID;
		}
       else if(strcmp(argv[1], "SETMAXPWR") == 0)
		{
			nType = E_MODEM_SETMAXPWR;
		}
        else if(strcmp(argv[1], "LOGSTART") == 0)
        {
          nType = E_TOF_LOGSTART;
        }
        else if(strcmp(argv[1], "LOGSTOP") == 0)
        {
          nType = E_TOF_LOGSTOP;
        }
        else if(strcmp(argv[1], "STOP") == 0)
		{
			main_run_flag = FALSE;  //test.
		}
			
		switch(nType)
		{			
			case E_MODEM_BASEVERSION:
				nRet = TOF_request_get_basebandversion(&modem_sw_version);
				if(nRet == TOF_SUCCESS)
				{				              
				   asprintf(&pBaseband_version, "MODEM.%s %s %s.%s %s %s",
                                  modem_sw_version.modem_sw_version,
                                  modem_sw_version.chip_solution_name,
                                  modem_sw_version.model_name,
                                  modem_sw_version.build_date,
                                  modem_sw_version.cal_info_version,
                                  modem_sw_version.modem_hw_version);
           
					printf("model=%s\n", pBaseband_version);
					printf("SUCCESS\n");
                  if(pBaseband_version != NULL) free(pBaseband_version);
				}
				else
				{
					printf("FAILED\n");
				}	
				break;	

          case E_TOF_LOGSTART:
          {
            TOF_SetLogPrint(TRUE);
            printf("LOG Print Start\n");
          }
          break;

          case E_TOF_LOGSTOP:
          {
            TOF_SetLogPrint(FALSE);
            printf("LOG Print Stop\n");
          }
          break;

          case E_MODEM_GETVENDORID:
          {
              TOF_request_get_vendorID(&vendorID);
              printf("Get vendorid ID : 0x%x\n", vendorID);
          }
          break;

           case E_MODEM_SETVENDORID:
          {
              tmp=vendorID = argv[2];  //C_TCU_VZW
              printf("Input : Set  vendorid ID : 0x%x\n", vendorID);
              TOF_request_set_vendorID(vendorID);
              vendorID = 0;
              if((TOF_request_get_vendorID(&vendorID) == TOF_SUCCESS) && (vendorID == tmp))
              {
                printf("Success : Set  vendorid ID : 0x%x\n", vendorID);
              }
              else printf("Fail : Set  vendorid ID : 0x%x\n", vendorID);
          }
          break;

          case E_MODEM_SETMAXPWR:
          {
              if(argc < 6)
              {
                printf("    DMS SETMAXPWR [ON/OFF] [RAT] [CHANNEL] [POWER]\n");
                printf("    [ON/OFF]: 0(ON) or 1(OFF) \n");
                printf("    [RAT]: 0(WCDMA), 1(LTE)\n");
                printf("    [CHANNEL]: 10700(WCDMA), 19575(LTE) \n");
                printf("    [POWER]: 23 \n");
                printf("EX) DMS SETMAXPWR 1 0 10700 23\n");  
                printf("EX) DMS SETMAXPWR 1 1 19575 23\n");
              }
              else
              {
                max_pwr.on_off = (uint8)atoi(argv[2]);
                max_pwr.rat = (uint8)atoi(argv[3]);
                max_pwr.channel_freq= (uint32)atoi(argv[4]);
                max_pwr.tx_power = (uint8)atoi(argv[5]);
                printf("Input : Set  MAX Power on_off(%d),rat(%d),ch(%d),pwr(%d)\n", 
                                   max_pwr.on_off,max_pwr.rat,max_pwr.channel_freq,max_pwr.tx_power);
                TOF_request_set_maxpwr(max_pwr);
              }              
          }
          break;

        default:
          printf("nType is unkown\n");      
          printf("EX) GET VERSION : DMS MODEMVERSION\n");
          printf("EX) GET VENDORID : DMS GETVENDORID\n");
          printf("EX) SET VENDORID : DMS SETVENDORID\n");
          printf("EX) SET MAXPWR : DMS SETMAXPWR 1 0 10700 23\n");
          printf("EX) START SAVE LOG : DMS LOGSTART\n");
          printf("EX) STOP SAVE LOG : DMS LOGSTOP\n");
          printf("EX) QMI STOP : DMS STOP\n");
          break;
		}
	}
  
	return 0;
}

int Get_Sim_Status(int argc, char **argv)
{
	int nRet;
	RIL_CardStatus_v6 card_status;
   	
	nRet = TOF_request_get_sim_status(&card_status);
	if(nRet == TOF_SUCCESS)
	{				                   
      printf("card_status.card_state=%d\n", card_status.card_state);
      printf("card_status.applications[0].app_state=%d\n", card_status.applications[0].app_state);
      printf("SUCCESS\n");
	}
	else
	{
		printf("FAILED\n");
	}	

	return 0;
}

int Get_Pin_Status(int argc, char **argv)
{
  int nRet;
  RIL_PinStatus pin_status;  

  nRet = TOF_request_get_pin_status(&pin_status);
  if(nRet == TOF_SUCCESS)
  {				                   
    printf("pin1_state %d pin1_num_retries %d puk1_num_retries %d\n", pin_status.pin1_state, pin_status.pin1_num_retries, pin_status.puk1_num_retries);
    printf("pin2_state %d pin2_num_retries %d puk2_num_retries %d\n", pin_status.pin2_state, pin_status.pin2_num_retries, pin_status.puk2_num_retries);
    printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  }	

  return 0;
}

int Enter_Sim_Pin(int argc, char **argv)
{
  int nRet;
  uint8 pin_id, pin_operation, pin_value[16 + 1];

 	if(argc < 3)
	{
    printf("Input ENTERPIN[PIN_Id] [PIN_Code] [Pin_Operation]\n");
    printf("EX) ENTERPIN1 0000 0\n");
    printf("    [PIN_Id] Input PIN Id\n");
    printf("    [PIN_Code] Input PIN Code\n");
    printf("    [Pin_Operation] Disable:0, Enable:1\n");
    printf("Try again...\n");
	}
  else
  {
    memcpy(pin_value, argv[1], 16 + 1);
    pin_operation = atoi(argv[2]);
    pin_id = atoi(&argv[0][strlen(argv[0])-1]);

    if(pin_id == 1)
    {
      nRet = TOF_request_enter_sim_pin(pin_id, pin_value, pin_operation);
      if(nRet == TOF_SUCCESS)
      {
        printf("SUCCESS\n");
      }
      else
      {
        printf("FAILED\n");
      }
    }
    else
    {
      nRet = TOF_request_enter_sim_pin2(pin_id, pin_value, pin_operation);
      if(nRet == TOF_SUCCESS)
      {
        printf("SUCCESS\n");
      }
      else
      {
        printf("FAILED\n");
      }
    }     
  }

  return 0;
}

int Enter_Puk(int argc, char **argv)
{
  int nRet;
  uint8 pin_id, puk_value[16 + 1], new_pin_value[16 + 1];

 	if(argc < 3)
	{
    printf("Input ENTERPUK[PIN_Id] [PUK_Code] [New_PIN_Code]\n");
    printf("EX) ENTERPUK1 0000 0000\n");
    printf("    [PIN_Id] Input PIN Id\n");
    printf("    [PUK_Code] Input PUK Code\n");
    printf("    [New_PIN_Code] Input New PIN Code\n");
    printf("Try again...\n");
	}
  else
  {
    memcpy(puk_value, argv[1], 16 + 1);
    memcpy(new_pin_value, argv[2], 16 + 1);
    pin_id = atoi(&argv[0][strlen(argv[0])-1]);

    if(pin_id == 1)
    {
      nRet = TOF_request_enter_sim_puk(pin_id, puk_value, new_pin_value);
      if(nRet == TOF_SUCCESS)
      {
        printf("SUCCESS\n");
      }
      else
      {
        printf("FAILED\n");
      }
    }
    else
    {
      nRet = TOF_request_enter_sim_puk2(pin_id, puk_value, new_pin_value);
      if(nRet == TOF_SUCCESS)
      {
        printf("SUCCESS\n");
      }
      else
      {
        printf("FAILED\n");
      }
    }
  }

  return 0;
}

int Change_Sim_Pin(int argc, char **argv)
{
  int nRet;
  uint8 pin_id, old_pin_value[16 + 1], new_pin_value[16 + 1];

 	if(argc < 3)
	{
    printf("Input CHANGEPIN[PIN_Id] [Old_PIN_Code] [New_PIN_Code]\n");
    printf("EX) CHANGEPIN1 0000 0000\n");
    printf("    [PIN_Id] Input PIN Id\n");
    printf("    [Old_PIN_Code] Input Old PIN Code\n");
    printf("    [New_PIN_Code] Input New PIN Code\n");
    printf("Try again...\n");
	}
  else
  {
    memcpy(old_pin_value, argv[1], 16 + 1);
    memcpy(new_pin_value, argv[2], 16 + 1);
    pin_id = atoi(&argv[0][strlen(argv[0])-1]);

    if(pin_id == 1)
    {
      nRet = TOF_request_change_sim_pin(pin_id, old_pin_value, new_pin_value);
      if(nRet == TOF_SUCCESS)
      {
        printf("SUCCESS\n");
      }
      else
      {
        printf("FAILED\n");
      }
    }
    else
    {
      nRet = TOF_request_change_sim_pin2(pin_id, old_pin_value, new_pin_value);
      if(nRet == TOF_SUCCESS)
      {
        printf("SUCCESS\n");
      }
      else
      {
        printf("FAILED\n");
      }
    }     
  }

  return 0;
}

int Get_Imei_Status(int argc, char** argv)
{
	int nRet;
  char imei[33] ;
  
  nRet = TOF_request_get_imei(imei);
	if(nRet == TOF_SUCCESS)
	{				                   
      printf("IMEI =%s\n", imei);
      printf("SUCCESS\n");
	}
	else
	{
		printf("FAILED\n");
	}	 
}

/*===========================================================================
  Example Code TOF_request_dial
===========================================================================*/
/*!
@brief
	The sample code is an example on how to call the dial for Originationg Voice Call.
	use TOF_request_dial() function for voice calls.
	Parameters of the TOF_request_dial() function  is TOF_Dial *
   When calling TOF_request_dial() you must put the arguments value of TOF_Dial *.

   The TOF_Dial structure contains the following values.
   address : The destination address of Char array Type (MAX Size VOICE_NUMBER_MAX+1)
   clir : int Type  
   			  (same as 'n' paremeter in TS 27.007 7.7 "+CLIR"
            clir == 0 on "use subscription default value"
            clir == 1 on "CLIR invocation" (restrict CLI presentation)
            clir == 2 on "CLIR suppression" (allow CLI presentation)
            If you do not use (Set 0)
            
   uusInfo : User-User Signaling Information of TOF_UUS_Info* Type
   					If you do not use (Set NULL)
            

@note
  - Dependencies
  
  - Side Effects

  - Notice
  The event (TOF_EVENT_RESPONSE_CALL_STATE_CHANGED) occurs when the Dial proceed successfully.
  When an event occurs,  must request information via TOF_request_get_current_calls() .
  Detailed description of the TOF_request_get_current_calls() function, 
  refer to the sample code Get_Current_Calls & Event receiver function (CBF_Event)
  
*/
/*=========================================================================*/

int Dial(int argc, char **argv)
{
	int nRet;
	TOF_Dial TOFDial;

	if ( 2 != argc )
	{
		printf( "  EX) DIAL 0123456789 \n" );
		return TRUE;
	}
	
	
	TOFDial.clir = 0;
	TOFDial.uusInfo = NULL;
	memcpy( TOFDial.address, argv[ 1 ], VOICE_NUMBER_MAX+1);
	
	printf("APP Request Dial [Number=%s]\n", TOFDial.address);
   	
	nRet = TOF_request_dial(&TOFDial);

	if(nRet == TOF_SUCCESS)
	{				                   
  	printf("APP Dial SUCCESS\n");
	}
	else
	{
		printf("APP Dial FAILED\n");
	}	
	return 0;
}

/*=========================================================
	FUNCTION	: DIAL_ECALL [Dial_ecall]

	DESCRIPTION

	DEPENDENCIES

	RETURN VALUES

	SIDE EFFECTS

	NOTES
		20160921	SH.Lee		Created.
=========================================================*/
#define ECALL_MAX_CHAR 5

int Dial_ecall(int argc, char **argv)
{
  int nRet;
  char argv_ecall[ECALL_MAX_CHAR];
  int mode=0;

  if ( 2 != argc )
  {
    printf( "  Command Format : ECALL [mode] \n  EX) ECALL 0 \n" );
    return TRUE;
  }

  memset(argv_ecall,0,ECALL_MAX_CHAR);
  memcpy( argv_ecall, argv[ 1 ], ECALL_MAX_CHAR);

  mode = (int)atoi(argv_ecall);
  printf("[ECALL] APP Request Dial eCall [argv_ecall=%s],[mode=%d]\n", argv_ecall,mode);
  
  nRet = TOF_request_ecall_dial(mode);

  if(nRet == TOF_SUCCESS)
  {				                   
     printf("[ECALL] APP Dial eCall SUCCESS\n");
  }
  else
  {
    printf("[ECALL] APP Dia eCalll FAILED\n");
  }	

  return 0;
}


/*=========================================================
	FUNCTION	: SET_ECALL_ENABLE [Set_ecall_enable]

	DESCRIPTION	
	  Enable ECALL Feature or Disable
	  (internally) set value in '/nv/item_files/modem/ecall/ecall_mode' (nv 65589) through QMI interface	                   	  
	  (usages)
	  ECALLON 0  : disable ecall feature
	  ECALLON 1  : enable ecall feature	  

	DEPENDENCIES
	  use QMI_NAS interface
	  
	RETURN VALUES
	  0 : run successful
	  1 : finally failed

	SIDE EFFECTS

	NOTES
		20160928	jaeyong1.park		Created.
=========================================================*/
int Set_ecall_enable (int argc, char **argv)
{
	int nRet;
	uint8 ecall_enable = 0;
	
	ecall_enable = (uint8)atoi(argv[1]);
	
	if((ecall_enable != 0) && (ecall_enable != 1))
	{
	  printf("Please Input a correct argument.. 0 or 1 !!\n");
	  return 1;
	}
	
	nRet = TOF_request_set_ecall_enable(ecall_enable);

	if(nRet == TOF_SUCCESS)
	{
	  if(ecall_enable == 1)
		printf("Success to enable a ECALL\n");
	  else
		printf("Success to disable a ECALL\n");
	}
	else
	{
	  printf("Setting FAILED\n");
	  return 1;
	}
	
	return 0;

}

/*=========================================================
	FUNCTION	: SET_ECALL_NUMBER [Set_ecall_number]

	DESCRIPTION	
	  Set Ecall number 
	  max length : 19

	DEPENDENCIES
	  use QMI_NAS interface
	  
	RETURN VALUES
	  0 : run successful
	  1 : finally failed

	SIDE EFFECTS

	NOTES
		20160929	jaeyong1.park		Created.
=========================================================*/

//jaeyong1.park
int Set_ecall_number (int argc, char **argv)
{
	int nRet;
	char ecall_number[20];
	
	if ( 2 != argc )
	{
	  printf( "  Command Format : ECALL [number] \n  EX) ECALL 12345678 \n" );
	  return TRUE;
	}
	
	memset(&ecall_number, 0, 20);

	strcpy(ecall_number, argv[1]);
	printf("input number : %s\n", ecall_number);

	nRet = TOF_request_set_ecall_number(ecall_number);

	if(nRet == TOF_SUCCESS)
	{
	  printf("Success to set ECALL number (%s) \n", ecall_number);
	}
	else
	{
	  printf("Setting FAILED\n");
	  return 1;
	}
	
	return 0;
}





/*=========================================================
	FUNCTION	: SETECALL_VOCCONFIG [Set_ecall_vocconf]

	DESCRIPTION	
	  Set   Set VOC_CONFIG  : 0(FALSE), 1(TRUE)
	  
	DEPENDENCIES
	  use QMI_NAS interface
	  
	RETURN VALUES
	  0 : run successful
	  1 : finally failed

	SIDE EFFECTS

	NOTES
		20161012	jaeyong1.park		Created.
=========================================================*/

int Set_ecall_vocconf  (int argc, char **argv)
{
	 
	int nRet;
	uint8 vocconf = 0;
	
	if ( 2 != argc )
	{
		printf( " Command Format : SETECALL_VOCCONFIG [arg] \n	VOC_CONFIG : 0(FALSE), 1(TRUE) \n EX) SETECALL_VOCCONFIG 1 \n" );
		  return 1;
	}
	
	vocconf = (uint8)atoi(argv[1]);

	if((vocconf != 0) && (vocconf != 1))
	{	 
 	  printf( "VOC_CONFIG : 0(FALSE), 1(TRUE) \n EX) SETECALL_VOCCONFIG 1 \n" );
	  return 1;
	}

	nRet = TOF_request_set_ecall_vocconf(vocconf);

	if(nRet == TOF_SUCCESS)
	{
	  if(vocconf == 1)
		printf("Success to enable a VOC\n");
	  else
		printf("Success to disable a VOC\n");
	}
	else
	{
	  printf("Setting FAILED\n");
	  return 1;
	}
	
	return 0;  
}

/*=========================================================
	FUNCTION	: SETECALL_CANNEDMSD [Set_ecall_cannedmsd]

	DESCRIPTION	
	CANNED_MSD  : 0(FALSE), 1(TRUE)

	DEPENDENCIES
	  use QMI_NAS interface
	  
	RETURN VALUES
	  0 : run successful
	  1 : finally failed

	SIDE EFFECTS

	NOTES
		20161012	jaeyong1.park		Created.
=========================================================*/

int Set_ecall_cannedmsd  (int argc, char **argv){
  	int nRet;
	uint8 cannedmsd = 0;

	if ( 2 != argc )
	{
	  printf( "	Command Format : SETECALL_CANNEDMSD [arg] \n  CANNED_MSD  : 0(FALSE), 1(TRUE) \n EX) SETECALL_CANNEDMSD 1 \n" );
	  return 1;
	}
		
	cannedmsd = (uint8)atoi(argv[1]);
	
	if((cannedmsd != 0) && (cannedmsd != 1))
	{	 
 	  printf( "CANNED_MSD  : 0(FALSE), 1(TRUE) \n EX) SETECALL_CANNEDMSD 1 \n" );
	  return 1;
	}
	
	nRet = TOF_request_set_ecall_cannedmsd(cannedmsd);

	if(nRet == TOF_SUCCESS)
	{
	  if(cannedmsd == 1)
		printf("Success to enable a CANNED MSD\n");
	  else
		printf("Success to disable a CANNED MSD\n");
	}
	else
	{
	  printf("Setting FAILED\n");
	  return 1;
	}
	
	return 0;  
}


/*=========================================================
	FUNCTION	: SETECALL_NUMTODIAL [Set_ecall_numtodial]

	DESCRIPTION	
	NUM_TO_DIAL : 0(NORMAL), 1(OVERRIDE)

	DEPENDENCIES
	  use QMI_NAS interface
	  
	RETURN VALUES
	  0 : run successful
	  1 : finally failed

	SIDE EFFECTS

	NOTES
		20161012	jaeyong1.park		Created.
=========================================================*/
int Set_ecall_numtodial  (int argc, char **argv){
  	int nRet;
	uint8 numtodial = 0;

	if ( 2 != argc )
	{
	   printf( "	Command Format : SETECALL_NUMTODIAL [arg] \n  NUM_TO_DIAL : 0(NORMAL), 1(OVERRIDE)  \n EX) SETECALL_NUMTODIAL 1 \n" );
	   return 1;
	}
	numtodial = (uint8)atoi(argv[1]);
	
	if((numtodial != 0) && (numtodial != 1))
	{	 
 	  printf( "NUM_TO_DIAL : 0(NORMAL), 1(OVERRIDE)  \n EX) SETECALL_NUMTODIAL 1 \n" );
	  return 1;
	}
	
	nRet = TOF_request_set_ecall_numtodial(numtodial);

	if(nRet == TOF_SUCCESS)
	{
	  if(numtodial == 1)
		printf("Success to set OVERRIDE a num to dial\n");
	  else
		printf("Success to set NORMAL a num to dial\n");
	}
	else
	{
	  printf("Setting FAILED\n");
	  return 1;
	}
	
	return 0;  
}



/*=========================================================
	FUNCTION	: SETECALL_GNSS_SESSUPDATETIME  [Set_ecall_gnsssestimeout]

	DESCRIPTION	
	GNSS_UPDATE_TIME_MS  : [Second]

	DEPENDENCIES
	  use QMI_NAS interface
	  
	RETURN VALUES
	  0 : run successful
	  1 : finally failed

	SIDE EFFECTS

	NOTES
		20161012	jaeyong1.park		Created.
=========================================================*/
int Set_ecall_gnsssestimeout (int argc, char **argv){
  	 
	int nRet;
	uint32 gnsstimeout = 0;
	if( 2 != argc )
	{	 
 	  printf( "	Command Format : SETECALL_GNSS_SESSUPDATETIME [second] \n   EX) SETECALL_GNSS_SESSUPDATETIME 10000 \n" );
	  return 1;
	}
	
	gnsstimeout = (uint32)atoi(argv[1]);
		
	nRet = TOF_request_set_ecall_gnsssestimeout(gnsstimeout);

	if(nRet == TOF_SUCCESS)
	{	  
		printf("Success to setting a GNSS_UPDATE_TIME_MS\n");
	}
	else
	{
	  printf("Setting FAILED\n");
	  return 1;
	}
	
	return 0;  
	

}


/*=========================================================
	FUNCTION	: SETECALL_CALLBACK_TIMEOUT [Set_ecall_callbacktimeout]

	DESCRIPTION	
	ECALL_CALLBACK_TIMEOUT: [Hour]

	DEPENDENCIES
	  use QMI_NAS interface
	  
	RETURN VALUES
	  0 : run successful
	  1 : finally failed

	SIDE EFFECTS

	NOTES
		20161012	jaeyong1.park		Created.
=========================================================*/
int Set_ecall_callbacktimeout  (int argc, char **argv){
  	 
	int nRet;
	uint32 ecallcbout = 0;
	
	if( 2 != argc )
	{	 
 	  printf( "	Command Format : SETECALL_CALLBACK_TIMEOUT [hour] \n   EX) SETECALL_CALLBACK_TIMEOUT 12\n" );
	  return 1;
	}
	
	ecallcbout = (uint32)atoi(argv[1]);
		
	nRet = TOF_request_set_ecall_callback_timeout(ecallcbout);
//nRet = TOF_request_set_ecall_ecallsession_timeout(ecallsessionout);
	if(nRet == TOF_SUCCESS)
	{	  
		printf("Success to setting a ECALL CALLBACK TIMEOUT\n");
	}
	else
	{
	  printf("Setting FAILED\n");
	  return 1;
	}
	
	return 0;  
}




/*=========================================================
	FUNCTION	: GET_ECALL_ENABLE [Get_ecall_enable]

	DESCRIPTION	
	
	Get ECALL Feature Enable or Disable
	(internally) set value in '/nv/item_files/modem/ecall/ecall_mode' (nv 65589) through QMI interface							
	(usages)
	ECALLON 0  : disable ecall feature
	ECALLON 1  : enable ecall feature	


	DEPENDENCIES
	  use QMI_NAS interface
	  
	RETURN VALUES
	  0 : run successful
	  1 : finally failed

	SIDE EFFECTS

	NOTES
		20161012	jaeyong1.park		Created.
=========================================================*/
int Get_ecall_enable(int argc, char **argv)
{
  int nRet;
  uint32 ecall_enable = 0;

  nRet = TOF_request_get_ecall_enable(&ecall_enable);

  printf("A ECALL Enable is %d!!\n",(uint8)ecall_enable);
  
  if(nRet == TOF_SUCCESS)
  {
    if((uint8)ecall_enable == 1)
      printf("A ECALL is enabled!!\n");
    else
      printf("A ECALL is disabled!!\n");
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}


/*=========================================================
	FUNCTION	: GET_ECALL_NUMBER [Get_ecall_number]

	DESCRIPTION		
      Get ecall number
      
	DEPENDENCIES
	  use QMI_NAS interface
	  
	RETURN VALUES
	  0 : run successful
	  1 : finally failed

	SIDE EFFECTS

	NOTES
		20161019	jaeyong1.park		Created.
=========================================================*/
int Get_ecall_number(int argc, char **argv)
{
  int nRet;
  char ecall_number[50];

  nRet = TOF_request_get_ecall_number(ecall_number);
  
  if(nRet == TOF_SUCCESS)
  {
	 printf("ECALL number : %s\n", ecall_number);
  }
  else
  {
    printf("GET Data FAILED\n");
  }

  return 0;
}



/*=========================================================
	FUNCTION	: GET_ECALL_VOCCONF [Get_ecall_vocconf]

	DESCRIPTION		
      
	DEPENDENCIES
	  use QMI_NAS interface
	  
	RETURN VALUES
	  0 : run successful
	  1 : finally failed

	SIDE EFFECTS

	NOTES
		20161019	jaeyong1.park		Created.
=========================================================*/


int Get_ecall_vocconf(int argc, char **argv) 
{
  int nRet;
  char data[50];

  nRet = TOF_request_get_ecall_vocconf(data);
  
  if(nRet == TOF_SUCCESS)
  {
	 printf("ECALL VOC CONF : %s\n", data);
  }
  else
  {
	printf("GET Data FAILED\n");
  }

  return 0;
}


/*=========================================================
	FUNCTION	: GET_ECALL_CANNED_MSD [Get_ecall_cannedmsd]

	DESCRIPTION		
      
	DEPENDENCIES
	  use QMI_NAS interface
	  
	RETURN VALUES
	  0 : run successful
	  1 : finally failed

	SIDE EFFECTS

	NOTES
		20161019	jaeyong1.park		Created.
=========================================================*/

int Get_ecall_cannedmsd(int argc, char **argv)
{
  int nRet;
  char data[50];

  nRet = TOF_request_get_ecall_cannedmsd(data);
  
  if(nRet == TOF_SUCCESS)
  {
	 printf("ECALL CANNED MSD : %s\n", data);
  }
  else
  {
	printf("GET Data FAILED\n");
  }

  return 0;
}	



/*=========================================================
	FUNCTION	: GET_ECALL_NUMBER_TO_DIAL [Get_ecall_numtodial]

	DESCRIPTION		
      
	DEPENDENCIES
	  use QMI_NAS interface
	  
	RETURN VALUES
	  0 : run successful
	  1 : finally failed

	SIDE EFFECTS

	NOTES
		20161019	jaeyong1.park		Created.
=========================================================*/

int Get_ecall_numtodial(int argc, char **argv)
{
  int nRet;
  char data[50];

  nRet = TOF_request_get_ecall_numtodial(data);
  
  if(nRet == TOF_SUCCESS)
  {
	 printf("ECALL NUMBER TO DIAL : %s\n", data);
  }
  else
  {
	printf("GET Data FAILED\n");
  }

  return 0;
}		


/*=========================================================
	FUNCTION	: GET_GNSS_TIMEOUT [Get_ecall_gnsssestimeout]

	DESCRIPTION		
      
	DEPENDENCIES
	  use QMI_NAS interface
	  
	RETURN VALUES
	  0 : run successful
	  1 : finally failed

	SIDE EFFECTS

	NOTES
		20161019	jaeyong1.park		Created.
=========================================================*/


int Get_ecall_gnsssestimeout(int argc, char **argv)
{
  int nRet;
  char data[50];

  nRet = TOF_request_get_ecall_gnsssestimeout(data);
  
  if(nRet == TOF_SUCCESS)
  {
	 printf("ECALL GNSS TIMEOUT : %s\n", data);
  }
  else
  {
	printf("GET Data FAILED\n");
  }

  return 0;
}	



/*=========================================================
	FUNCTION	: GET_ECALL_CALLBACK_TIMEOUT [Get_ecall_callbacktimeout]

	DESCRIPTION		
      
	DEPENDENCIES
	  use QMI_NAS interface
	  
	RETURN VALUES
	  0 : run successful
	  1 : finally failed

	SIDE EFFECTS

	NOTES
		20161019	jaeyong1.park		Created.
=========================================================*/

int Get_ecall_callbacktimeout(int argc, char **argv)
{
  int nRet;
  char data[50];

  nRet = TOF_request_get_ecall_callback_timeout(data);
  
  if(nRet == TOF_SUCCESS)
  {
	 printf("ECALL CALLBACK TIMEOUT : %s\n", data);
  }
  else
  {
	printf("GET Data FAILED\n");
  }

  return 0;
}	



/*=========================================================
	FUNCTION	: GET_GSM_DTMSUPPORTED [Get_gsm_dtmsupported]

	DESCRIPTION		
	 Qualcomm devices support Class A. 
	 when camped on GSM, if the cell supports DTM (Dual TRasnfewr Mode), both GPRS and GSM services are possible simultaneously.
	 First parram indicated that cell supports DTM.
      
	DEPENDENCIES
	  use QMI_NAS interface
	  
	RETURN VALUES
	  0 : run successful
	  1 : finally failed

	SIDE EFFECTS

	NOTES
		20170220	jaeyong1.park		Created.
=========================================================*/

int Get_gsm_dtmsupported(int argc, char **argv)
{
  int nRet;
  uint32 dtmsupported;

  nRet = TOF_request_get_gsm_dtm_supported(&dtmsupported);
  
  if(nRet == TOF_SUCCESS)
  {
	 printf("Get DTM supported(GSM only) : %d\n", dtmsupported);
  }
  else
  {
	printf("Get GSM DTM supported FAILED\n");
  }

  return 0;
}	


/*=========================================================
	FUNCTION	: GET_GSM_PATHLOSS_CRITERIA  [Get_gsm_pathloss_criteria ]

	DESCRIPTION		
	 3GPP TS 45.008 6.1	 
	 The path loss criterion parameter C1 used for cell selection and reselection.
	 The path loss criterion (3GPP TS 43.022) is satisfied if C1 > 0.
      
	DEPENDENCIES
	  use QMI_NAS interface
	  
	RETURN VALUES
	  0 : run successful
	  1 : finally failed

	SIDE EFFECTS

	NOTES
		20170220	jaeyong1.park		Created.
=========================================================*/

int Get_gsm_pathloss_criteria (int argc, char **argv)
{
  int nRet;
  TOF_GSM_PathLossCriteria_list criterias;

  nRet = TOF_request_get_gsm_pathhloss_criteria(&criterias);
  
  if(nRet == TOF_SUCCESS)
  {
	 printf("Get path loss criteria(GSM only) arfcn number for calc c1 : %d, C1 = %d\n\n", criterias.info[0].arfcn_num, criterias.info[0].calculated_c1);
  }
  else
  {
	printf("Get GSM DTM supported FAILED\n");
  }

  return 0;
}	




/*=========================================================
	FUNCTION	: GET_MODEM_VERSION [Get_modem_ver]

	DESCRIPTION		
      
	DEPENDENCIES
	  use QMI_NAS interface
	  
	RETURN VALUES
	  0 : run successful
	  1 : finally failed

	SIDE EFFECTS

	NOTES
    20161019  jaeyong1.park     Created.
		20170125	Young-hwan Byun		Modified.
=========================================================*/

int Get_modem_ver(int argc, char **argv)
{
  int nRet;
  char ap_version[20];
  char tof_version[20]={NULL,};
  char version_info[50];
  
  nRet = TOF_getModemVersion(version_info);
  if(nRet == TOF_SUCCESS)
  {
	  printf("Get modem version : %s\n", version_info);
  }
  else
  {
	  printf("GET modem version FAILED\n");
  }

  return 0;
}	



/*=========================================================
	FUNCTION	: GET_ISROAMING [Get_isroaming]

	DESCRIPTION		
      
	DEPENDENCIES
	  use QMI_NAS interface
	  
	RETURN VALUES
	  0 : run successful
	  1 : finally failed

	SIDE EFFECTS

	NOTES
		20160117	jaeyong1.park		Created.
=========================================================*/

int Get_isroaming(int argc, char **argv){
	int nRet;	
	uint8 is_roaming_value;
	
	nRet = TOF_get_is_roaming(&is_roaming_value);	
	
	if(nRet == TOF_SUCCESS)
	{
	   printf("Is roaming : %d\n", is_roaming_value);
	}
	else
	{
	  printf("FAILED to get a roaming\n");
	}
	
	return 0;

}




/*=========================================================
	FUNCTION	: GET_NETWORKSCAN  [Get_networkscan ]

	DESCRIPTION		
      
	DEPENDENCIES
	  use QMI_NAS interface
	  
	RETURN VALUES
	  0 : run successful
	  1 : finally failed

	SIDE EFFECTS

	NOTES
		20170117	jaeyong1.park		Created.
=========================================================*/

int Get_networkscan(int argc, char **argv){
	int nRet;	
	
	nRet = TOF_get_networkscan();	
	
	if(nRet == TOF_SUCCESS)
	{
	   printf("TOF_get_networkscan scan start SUCCESS\n");
	}
	else
	{
	  printf("FAILED to network scan start\n");
	}
	
	return 0;
}



// 2016-10-11 mwkim, InnoJIRA : AS045-670, 672
// 2016-10-11 mwkim, InnoJIRA : AS045-673

/*=========================================================
	FUNCTION	: ENABLE_ECALL_ONLY_MODE [Set_ecall_only_mode]

	DESCRIPTION	
	  Enable eCall only mode or Disable
	  (internally) Change value in NV#50081 through QMI interface	                   	  
	  (usages)
	  ECALLONLY 0  : Disable eCall only mode [Normal mode]
	  ECALLONLY 1  : Enable eCall only mode	  

	DEPENDENCIES
	  use QMI_NAS interface
	  
	RETURN VALUES
	  0 : run successful
	  1 : finally failed

	SIDE EFFECTS

	NOTES
		20161011	mwkim		Created.
=========================================================*/
int Set_ecall_only_mode(int argc,char * * argv)
{
	int nRet;
	uint8 ecallonly_enable = 0;
	
	ecallonly_enable = (uint8)atoi(argv[1]);
	
	if((ecallonly_enable != 0) && (ecallonly_enable != 1))
	{
	  printf("Please Input a correct argument.. 0 or 1 !!\n");
	  return 1;
	}
	
	nRet = TOF_request_set_ecall_only_mode(ecallonly_enable);

	if(nRet == TOF_SUCCESS)
	{
	  if(ecallonly_enable == 1)
		printf("Successfully changed to eCall only mode\n");
	  else
		printf("Successfully changed to Normal mode\n");
	}
	else
	{
	  printf("Setting FAILED\n");
	  return 1;
	}
	
	return 0;

}

// 2016-10-14 mwkim, InnoJIRA : AS045-671
/*=========================================================
	FUNCTION	: GET_ECALL_OPER_MODE [get_ecall_oper_mode]

	DESCRIPTION	
	  Get eCall operation mode
	  (internally) Read value in NV#50081 through QMI interface	                   	  
	  (usages)
	  ECALLMODE?  : Get present eCall operation mode and display value.

	DEPENDENCIES
	  use QMI_NAS interface
	  
	RETURN VALUES
	  0 : run successful
	  1 : finally failed

	SIDE EFFECTS

	NOTES
		20161014	mwkim		Created.
=========================================================*/
int Get_ecall_oper_mode(int argc, char ** argv)
{
	int  nRet;
	uint8 ecall_mode_value;
	
	nRet = TOF_request_get_ecall_oper_mode(&ecall_mode_value);	

	if(nRet == TOF_SUCCESS)
	{
	  if( ecall_mode_value == 1 )
		printf("eCall mode : %d [eCall only mode]\n", ecall_mode_value);
	  else
		printf("eCall mode : %d [Normal mode]\n", ecall_mode_value);
	}
	else
	{
	  printf("Reading FAILED\n");
	  return 1;
	}
	
	return 0;

}


//20160921 yjoh
int MSDSet(int argc, char **argv)
{
	int nRet;
	uint8 ecall_mode = 0;
	uint8 temp_msd_array[ECALL_MSD_MAX_LEN  * 2 +1] = {0,};
		
	if ( 3 != argc )
	{
	   printf( "  Command Format : MSDSET [mode] [msd]\n  " );
		printf( "  EX)MSDSET 0 c5e165...  \n" );
		return TRUE;
	}

	ecall_mode = (uint8)atoi(argv[1]);
	
   	memcpy(temp_msd_array, argv[2], sizeof (temp_msd_array));
	nRet = TOF_request_ecall_set_msd(ecall_mode, temp_msd_array);

	if(nRet == TOF_SUCCESS)
	{				                   
  		printf("[ECALL]  APP MSD set SUCCESS\n");
	}
	else
	{
		printf("[ECALL]  APP MSD set  FAILED\n");
	}	
	return 0;
}

int Get_Imsi(int argc, char **argv)
{
  int nRet;
  char imsi[32 + 1]; //Max IMSI char is 32

  nRet = TOF_request_get_imsi(imsi);
  if(nRet == TOF_SUCCESS)
  {
    printf("IMSI : %s\n", imsi);
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Get_Imeisv(int argc, char **argv)
{
  int nRet;
  char imeisv[255 + 1]; //Max IMEISV char is 255

  nRet = TOF_request_get_imeisv(imeisv);
  if(nRet == TOF_SUCCESS)
  {
    printf("IMEISV : %s\n", imeisv);
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Get_Current_Calls(int argc, char **argv)
{
	int nRet;
	int i =0;
	TOF_Current_Call_Info Current_Call_info;

	if ( 1 != argc )
	{
		printf( "  EX) GETCALLS\n" );
		return TRUE;
	}

	printf("APP Request Get Current Calls Info\n");
   	
	nRet = TOF_request_get_current_calls(&Current_Call_info);

	
	/*Debug*/
	for ( i = 0; i < Current_Call_info.call_count; ++i )
  {
 		printf("APP Call Info list [%d][index:%d, state:%d, toa:%d, isVoice:%d, number:%s]\n",
			i,
			Current_Call_info.call_info[i].index,
			(TOF_CallState)Current_Call_info.call_info[i].state,
			Current_Call_info.call_info[i].toa,
			Current_Call_info.call_info[i].isVoice,
			Current_Call_info.call_info[i].number);
	}

	if(nRet == TOF_SUCCESS)
	{				                   
  	printf("APP SUCCESS\n");
	}
	else
	{
		printf("APP FAIL\n");
	}	

	return 0;
}

int Hangup(int argc, char **argv)
{
	int nRet;

	uint8 call_id = 0;

	if ( 2 != argc )
	{
		printf( "  EX) HANGUP 1\n" );
		return TRUE;
	}
	
	call_id = (uint8)atoi( argv[ 1 ] );

	printf("APP Request Hangup [Call ID : %d]\n",call_id);

	nRet = TOF_request_hangup(call_id);

	if(nRet == TOF_SUCCESS)
	{				                   
  	printf("APP Hangup SUCCESS\n");
	}
	else
	{
		printf("APP Hangup FAILED\n");
	}	

	return 0;
}

int Answer(int argc, char **argv)
{
	int nRet;

	if ( 1 != argc )
	{
		printf( "  EX) ANSWER \n" );
		return TRUE;
	}

	printf("APP Request Answer \n");

	nRet = TOF_request_answer();

	if(nRet == TOF_SUCCESS)
	{				                   
  	printf("APP Answer SUCCESS\n");
	}
	else
	{
		printf("APP Answer FAILED\n");
	}	

	return 0;
}

int Last_Call_Fail_Cause(int argc, char **argv)
{
	int nRet;
	int fail_cause=0;

	if ( 1 != argc )
	{
		printf( "  EX) LASTCALLFAIL \n" );
		return TRUE;
	}

	printf("APP Request Last_Call_Fail_Cause \n");

	nRet = TOF_request_last_call_fail_cause(&fail_cause);

	/*Debug*/
	printf("Last Voice Call Fail Cause : %d \n",fail_cause);

	if(nRet == TOF_SUCCESS)
	{				                   
  	printf("APP Last_Call_Fail_Cause SUCCESS\n");
	}
	else
	{
		printf("APP Last_Call_Fail_Cause FAILED\n");
	}	

	return 0;
}

int Call_Switch(int argc, char **argv)
{
	int nRet;

	if ( 1 != argc )
	{
		printf( "  EX) CALLSWITCH \n" );
		return TRUE;
	}

	printf("APP Request switch_waiting_or_holding_and_active \n");

	nRet = TOF_request_switch_waiting_or_holding_and_active();


	if(nRet == TOF_SUCCESS)
	{				                   
  	printf("APP switch_waiting_or_holding_and_active SUCCESS\n");
	}
	else
	{
		printf("APP switch_waiting_or_holding_and_active FAILED\n");
	}	

	return 0;
}

int Hangup_Foreground_Resume_Background(int argc, char **argv)
{
	int nRet;

	if ( 1 != argc )
	{
		printf( "  EX) HANGUPFRB \n" );
		return TRUE;
	}

	printf("APP Request Hangup_Foreground_Resume_Background \n");

	nRet = TOF_request_hangup_foreground_resume_background();


	if(nRet == TOF_SUCCESS)
	{				                   
  	printf("APP Hangup_Foreground_Resume_Background SUCCESS\n");
	}
	else
	{
		printf("APP Hangup_Foreground_Resume_Background FAILED\n");
	}	

	return 0;
}

int Hangup_Waiting_Or_Background(int argc, char **argv)
{
	int nRet;

	if ( 1 != argc )
	{
		printf( "  EX) HANGUPWOB \n" );
		return TRUE;
	}

	printf("APP Request Hangup_Waiting_Or_Background \n");

	nRet = TOF_request_hangup_waiting_or_background();


	if(nRet == TOF_SUCCESS)
	{				                   
  	printf("APP Hangup_Waiting_Or_Background SUCCESS\n");
	}
	else
	{
		printf("APP Hangup_Waiting_Or_Background FAILED\n");
	}	

	return 0;
}

int Dtmf_Start(int argc, char **argv)
{
	int nRet;
	char key;

	if ( 2 != argc )
	{
		printf( "  EX) DTMFSTART (0-9 or * or #)  \n" );
		return TRUE;
	}

	memcpy( &key, argv[ 1 ], sizeof(char));

	printf("APP Request Dtmf_Start \n");

	nRet = TOF_request_dtmf_start(&key);


	if(nRet == TOF_SUCCESS)
	{				                   
  	printf("APP Dtmf_Start SUCCESS\n");
	}
	else
	{
		printf("APP Dtmf_Start FAILED\n");
	}	

	return 0;
}

int Dtmf_Stop(int argc, char **argv)
{
	int nRet;

	if ( 1 != argc )
	{
		printf( "  EX) DTMFSTOP \n" );
		return TRUE;
	}

	printf("APP Request Dtmf_Stop \n");

	nRet = TOF_request_dtmf_stop();


	if(nRet == TOF_SUCCESS)
	{				                   
  	printf("APP Dtmf_Stop SUCCESS\n");
	}
	else
	{
		printf("APP Dtmf_Stop FAILED\n");
	}	

	return 0;
}

int Dtmf(int argc, char **argv)
{
	int nRet;
	char key;

	if ( 2 != argc )
	{
		printf( "  EX) DTMF (0-9 or * or #)  \n" );
		return TRUE;
	}
	
	memcpy( &key, argv[ 1 ], sizeof(char));

	printf("APP Request DTMF \n");

	nRet = TOF_request_dtmf(&key);


	if(nRet == TOF_SUCCESS)
	{				                   
  	printf("APP DTMF SUCCESS\n");
	}
	else
	{
		printf("APP DTMF FAILED\n");
	}	

	return 0;
}

int Set_volte(int argc, char **argv)
{
  int nRet;
  uint8 volte_enable = 0;

  volte_enable = (uint8)atoi(argv[1]);

  if((volte_enable != 0) && (volte_enable != 1))
  {
    printf("Please Input a correct number between 0~1!!\n");
    return 0;
  }
  
  nRet = TOF_request_set_volte(volte_enable);
  if(nRet == TOF_SUCCESS)
  {
    if(volte_enable == 1)
      printf("Success to enable a VoLTE\n");
    else
      printf("Success to disable a VoLTE\n");
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Get_volte(int argc, char **argv)
{
  int nRet;
  uint8 volte_enable = 0;

  nRet = TOF_request_get_volte(&volte_enable);

//  printf("A VoLTE is %d!!\n",volte_enable);
  
  if(nRet == TOF_SUCCESS)
  {
    if(volte_enable == 1)
      printf("A VoLTE is enabled!!\n");
    else
      printf("A VoLTE is disabled!!\n");
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Set_IMS_enable(int argc, char **argv)
{
  int nRet;
  uint8 ims_enable = 0;

  ims_enable = (uint8)atoi(argv[1]);

  if((ims_enable != 0) && (ims_enable != 1))
  {
    printf("Please Input a correct number between 0~1!!\n");
    return 0;
  }
  
  nRet = TOF_request_set_ims_enable(ims_enable);
  if(nRet == TOF_SUCCESS)
  {
    if(ims_enable == 1)
      printf("Success to enable a IMS\n");
    else
      printf("Success to disable a IMS\n");
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Get_IMS_enable(int argc, char **argv)
{
  int nRet;
  uint8 ims_enable = 0;

  nRet = TOF_request_get_ims_enable(&ims_enable);

  printf("A IMS is %d!!\n",ims_enable);
  
  if(nRet == TOF_SUCCESS)
  {
    if(ims_enable == 1)
      printf("A IMS is enabled!!\n");
    else
      printf("A IMS is disabled!!\n");
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Set_volte_sess_time(int argc, char **argv)
{
  int nRet;
  uint16 sess_time = 0;

  sess_time = (uint16 )atoi(argv[1]);
  
  nRet = TOF_request_set_volte_session_timer(sess_time);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("Success to set VoLTE Session Time\n");
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Get_volte_sess_time(int argc, char **argv)
{
  int nRet;
  uint16 sess_time = 0;

  nRet = TOF_request_get_volte_session_timer(&sess_time);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("VoLTE Session Time = %d\n",sess_time);
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Set_amr_payload_format(int argc, char **argv)
{
  int nRet;
  boolean amr_payload_format = 0;

  amr_payload_format = (uint16 )atoi(argv[1]);
  
  nRet = TOF_request_set_amr_payload_format(amr_payload_format);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("Success to set AMR Payload Format\n");
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Get_amr_payload_format(int argc, char **argv)
{
  int nRet;
  boolean amr_payload_format = 0;

  nRet = TOF_request_get_amr_payload_format(&amr_payload_format);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("AMR Payload Format = %d\n",amr_payload_format);
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Set_amr_wb_payload_format(int argc, char **argv)
{
  int nRet;
  boolean amr_wb_payload_format = 0;

  amr_wb_payload_format = (uint16 )atoi(argv[1]);
  
  nRet = TOF_request_set_amr_wb_payload_format(amr_wb_payload_format);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("Success to set AMR WB Payload Format\n");
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Get_amr_wb_payload_format(int argc, char **argv)
{
  int nRet;
  boolean amr_wb_payload_format = 0;

  nRet = TOF_request_get_amr_wb_payload_format(&amr_wb_payload_format);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("AMR WB Payload Format = %d\n",amr_wb_payload_format);
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Set_amr_codec_mode_set(int argc, char **argv)
{
  int nRet;
  uint8 amr_codec_mode = 0;

  amr_codec_mode = (uint16 )atoi(argv[1]);
  
  nRet = TOF_request_set_amr_codec_mode_set(amr_codec_mode);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("Success to set AMR Codec Mode Set\n");
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Get_amr_codec_mode_set(int argc, char **argv)
{
  int nRet;
  uint8 amr_codec_mode = 0;

  nRet = TOF_request_get_amr_codec_mode_set(&amr_codec_mode);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("AMR Codec Mode Set = %d\n",amr_codec_mode);
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Set_amr_wb_codec_mode_set(int argc, char **argv)
{
  int nRet;
  uint16 amr_wb_codec_mode = 0;

  amr_wb_codec_mode = (uint16 )atoi(argv[1]);
  
  nRet = TOF_request_set_amr_wb_codec_mode_set(amr_wb_codec_mode);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("Success to set AMR WB Codec Mode Set\n");
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Get_amr_wb_codec_mode_set(int argc, char **argv)
{
  int nRet;
  uint16 amr_wb_codec_mode = 0;

  nRet = TOF_request_get_amr_wb_codec_mode_set(&amr_wb_codec_mode);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("AMR WB Codec Mode Set = %d\n",amr_wb_codec_mode);
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Set_amr_wb_enable(int argc, char **argv)
{
  int nRet;
  boolean amr_wb_enable = 0;

  amr_wb_enable = (uint16 )atoi(argv[1]);
  
  nRet = TOF_request_set_amr_wb_enable(amr_wb_enable);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("Success to set AMR WB Enable\n");
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Get_amr_wb_enable(int argc, char **argv)
{
  int nRet;
  boolean amr_wb_enable = 0;

  nRet = TOF_request_get_amr_wb_enable(&amr_wb_enable);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("AMR WB Enable = %d\n",amr_wb_enable);
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Set_rtcp_enable(int argc, char **argv)
{
  int nRet;
  boolean rtcp_enable = 0;

  rtcp_enable = (uint16 )atoi(argv[1]);
  
  nRet = TOF_request_set_rtcp_enable(rtcp_enable);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("Success to set RTCP Enable\n");
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Get_rtcp_enable(int argc, char **argv)
{
  int nRet;
  boolean rtcp_enable = 0;

  nRet = TOF_request_get_rtcp_enable(&rtcp_enable);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("RTCP Enable = %d\n",rtcp_enable);
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Set_pcscf_port(int argc, char **argv)
{
  int nRet;
  uint16 pcscf_port = 0;

  pcscf_port = (uint16 )atoi(argv[1]);
  
  nRet = TOF_request_set_pcscf_port(pcscf_port);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("Success to set PCSCF Port\n");
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Get_pcscf_port(int argc, char **argv)
{
  int nRet;
  uint16 pcscf_port = 0;

  nRet = TOF_request_get_pcscf_port(&pcscf_port);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("PCSCF Port = %d\n",pcscf_port);
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Set_pcscf_domain(int argc, char **argv)
{
  int nRet;
  char pcscf_domain[255];

  memset(pcscf_domain,0,255);
  
  strncpy( pcscf_domain, argv[ 1 ],strlen(argv[1])>255?255:strlen(argv[1]));
  
  nRet = TOF_request_set_pcscf_domain(pcscf_domain);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("Success to set PCSCF Domain Name\n");
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Get_pcscf_domain(int argc, char **argv)
{
  int nRet;
  char pcscf_domain[255];

  memset(pcscf_domain,0,255);
  
  nRet = TOF_request_get_pcscf_domain(&pcscf_domain);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("PCSCF Domain Name = %s\n",pcscf_domain);
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Set_ims_test_mode(int argc, char **argv)
{
  int nRet;
  boolean ims_test_mode = 0;

  ims_test_mode = (uint16 )atoi(argv[1]);
  
  nRet = TOF_request_set_ims_test_mode(ims_test_mode);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("Success to set IMS Test Mode\n");
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Get_ims_test_mode(int argc, char **argv)
{
  int nRet;
  boolean ims_test_mode = 0;

  nRet = TOF_request_get_ims_test_mode(&ims_test_mode);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("IMS Test Mode = %d\n",ims_test_mode);
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Set_sip_local_port(int argc, char **argv)
{
  int nRet;
  uint16 local_port = 0;

  local_port = (uint16 )atoi(argv[1]);
  
  nRet = TOF_request_set_sip_local_port(local_port);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("Success to set SIP Local Port\n");
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Get_sip_local_port(int argc, char **argv)
{
  int nRet;
  uint16 local_port = 0;

  nRet = TOF_request_get_sip_local_port(&local_port);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("SIP Local Port = %d\n",local_port);
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Set_sip_reg_timer(int argc, char **argv)
{
  int nRet;
  uint32 reg_timer = 0;

  reg_timer = (uint32 )atoi(argv[1]);
  
  nRet = TOF_request_set_sip_reg_timer(reg_timer);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("Success to set SIP Reg Timer\n");
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Get_sip_reg_timer(int argc, char **argv)
{
  int nRet;
  uint32 reg_timer = 0;

  nRet = TOF_request_get_sip_reg_timer(&reg_timer);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("SIP Reg Timer = %d\n",reg_timer);
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Set_sip_subscribe_timer(int argc, char **argv)
{
  int nRet;
  uint32 subsc_timer = 0;

  subsc_timer = (uint32 )atoi(argv[1]);
  
  nRet = TOF_request_set_sip_subscribe_timer(subsc_timer);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("Success to set SIP Subscribe Timer\n");
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Get_sip_subscribe_timer(int argc, char **argv)
{
  int nRet;
  uint32 subsc_timer = 0;

  nRet = TOF_request_get_sip_subscribe_timer(&subsc_timer);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("SIP Subscribe Timer = %d\n",subsc_timer);
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Set_Modem_Mode(int argc, char **argv)
{
	int nRet;
	uint8 modem_mode = 0;

	modem_mode = (uint8)atoi(argv[1]);
   	
	nRet = TOF_request_set_modem_mode(modem_mode);
	if(nRet == TOF_SUCCESS)
	{				                   
    printf("set modem mode : %d\n", modem_mode);
    printf("SUCCESS\n");
	}
	else
	{
		printf("FAILED\n");
	}	

	return 0;
}

int Modem_Reset(int argc, char **argv)
{
  int nRet;
  printf("Modem_Reset \n");
  nRet = TOF_request_modem_reset();

  return 0;
}

int Modem_Init(int argc, char **argv)
{
  int nRet;
  nRet = TOF_request_modem_init();

  return 0;
}

int Get_Regi_Status(int argc, char **argv)
{
  int nRet;
  tof_registration_status_type data_regi_status;
//  char *data_regi_status;
  int i=0;
  
  /*
    reg_status, or gprs_status;       //only WCDMA
    lac;
    cell_id;
    rat;
    bs_id;
    bs_latitude;
    bs_longitude;
    services_support_ind;
    sid;
    nid;
    roaming_ind;
    prl_ind;
    default_roaming_ind;
    reject_cause;    
    */
  
  if(argc < 2)
  {
    printf("    REGISTAT [type]\n");
    printf("    [type]: DATAREGISTAT or VOICEREGISTAT \n");
    printf("EX) REGISTAT DATAREGISTAT\n");  
    printf("EX) REGISTAT VOICEREGISTAT\n");
  }
  else
  {    
    UpperStr( argv[1] );
    
    if(strcmp(argv[1], "DATAREGISTAT") == 0)
    {
      nRet = TOF_request_data_registration_state(&data_regi_status);

      if(nRet == TOF_SUCCESS)
      {
        printf("Get_Regi_Status() Success to read  DATAREGISTAT \n",0,0,0);

        
        printf("Data_Status =%d, LAC =%x, Cell_ID =%x, RAT =%d, Reject_Cause =%d \n",
                    data_regi_status.reg_status,data_regi_status.lac,data_regi_status.cell_id,
                    data_regi_status.rat,data_regi_status.reject_cause);
      }
      else
      {
        printf("Get_Regi_Status() Failed to read  DATAREGISTAT \n",0,0,0);
      }
    }
    else if(strcmp(argv[1], "VOICEREGISTAT") == 0)
    {
      nRet = TOF_request_voice_registration_state(&data_regi_status);

      if(nRet == TOF_SUCCESS)
      {
        printf("Get_Regi_Status() Success to read  DATAREGISTAT \n",0,0,0);

        
        printf("Voice_Status =%d, LAC =%x, Cell_ID =%x, RAT =%d, Reject_Cause =%d \n",
                    data_regi_status.reg_status,data_regi_status.lac,data_regi_status.cell_id,
                    data_regi_status.rat,data_regi_status.reject_cause);
      }
      else
      {
        printf("Get_Regi_Status() Failed to read  DATAREGISTAT \n",0,0,0);
      }
    }
    
  }

  return 0;
}

/* 20160309/JJSON/SIGINFO Command �Լ� ���� */
int Get_Signal_Strength(int argc, char **argv)
{
  int nRet;  

  memset(&tof_signal_strength, 0x0, sizeof(tof_signal_strength));
  
  nRet = TOF_request_signal_strength(&tof_signal_strength);
  if(nRet == TOF_SUCCESS)
  {				                   
    printf("GSM Signal Strength RSSI = %d dBm = %d\n",
              tof_signal_strength.GSM_SignalStrength.signalStrength,
              tof_signal_strength.GSM_SignalStrength.signalStrengt_dBm);
    
    printf("WCDMA Signal Strength RSSI = %d BER = %d\n",
              tof_signal_strength.GW_SignalStrength.signalStrength,
              tof_signal_strength.GW_SignalStrength.bitErrorRate);

    printf("LTE Signal Strength RSSI = %d RSRP = %d RSRQ = %d SNR = %d\n",
              tof_signal_strength.LTE_SignalStrength.signalStrength,
              tof_signal_strength.LTE_SignalStrength.rsrp,
              tof_signal_strength.LTE_SignalStrength.rsrq,
              tof_signal_strength.LTE_SignalStrength.rssnr);
    
    printf("TD-CDMA Signal Strength RSCP = %d\n",
              tof_signal_strength.TD_SCDMA_SignalStrength.rscp);
    
    printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  }	

  return 0;
}

int Setup_Data_Call(int argc, char **argv)
{
  int nRet                    = TOF_FAIL;
  int profile                 = 0;
  tof_qcmap_msgr_ip_family_enum_v01 ip_family = TOF_QCMAP_MSGR_IP_FAMILY_V4_V01;

  if(3 == argc)
  {
    profile = atoi(argv[1]);
    ip_family = (tof_qcmap_msgr_ip_family_enum_v01)atoi(argv[2]);
  }

  nRet = TOF_request_setup_data_call(profile, ip_family);
  if(nRet == TOF_SUCCESS)
  {
    printf("TOF_setup_data_call SUCCESS\n");
  }
  else
  {
    printf("TOF_setup_data_call FAILED\n");
  }	

  return 0;
}

int Deactivate_Data_Call(int argc, char **argv)
{
  int nRet  = TOF_FAIL;

  nRet = TOF_request_deactivate_data_call();
  if(nRet == TOF_SUCCESS)
  {				                   
    printf("TOF_request_deactivate_data_call SUCCESS\n");
  }
  else
  {
    printf("TOF_request_deactivate_data_call FAILED\n");
  }	

  return 0;
}

int Data_Call_List(int argc, char **argv)
{
  int nRet = TOF_FAIL;
  tof_data_call_response call_resp;

  nRet = TOF_request_data_call_list(&call_resp);
  if(nRet == TOF_SUCCESS)
  {
    printf("inet  status = %d, addr = %s\n", call_resp.inet_status, call_resp.inet_addr);
    printf("inet  DNS primary = %s, secondary = %s\n", call_resp.inet_pdns_addr, call_resp.inet_sdns_addr);
    printf("inet6 status = %d, addr = %s\n", call_resp.inet6_status, call_resp.inet6_addr);
    printf("inet6 DNS primary = %s, secondary = %s\n", call_resp.inet6_pdns_addr, call_resp.inet6_sdns_addr);
    printf("TOF_request_data_call_list SUCCESS\n");
  }
  else
  {
    printf("TOF_request_data_call_list FAILED\n");
  }	

  return 0;
}

int Last_Data_Call_Fail_Cause(int argc, char **argv)
{
  int nRet = TOF_FAIL;
  int32_t reason_code = 0;

  nRet = TOF_request_last_data_call_fail_cause(&reason_code);
  if(nRet == TOF_SUCCESS)
  {
    printf("Last call end reason = %d\n", reason_code);
    printf("TOF_request_last_data_call_fail_cause SUCCESS\n");
  }
  else
  {
    printf("TOF_request_last_data_call_fail_cause FAILED\n");
  }	

  return 0;
}

int Set_Data_Auto_Connect(int argc, char **argv)
{
  int nRet                    = TOF_FAIL;
  int enable                  = 0;
  int profile                 = 0;

  if(2 == argc)
  {
    enable = atoi(argv[1]);
  }
  else if(3 == argc)
  {
    enable    = atoi(argv[1]);
    profile   = atoi(argv[2]);
  }

  if(enable)
  {
    if(profile > 0)
    {
      nRet = TOF_request_enable_data_auto_connect(profile);
    }
    else
    {
      nRet = TOF_FAIL;
      printf("TOF_request_enable_data_auto_connect cannot start\n");
    }
  }
  else
  {
    nRet = TOF_request_disable_data_auto_connect();
  }
  
  if(nRet == TOF_SUCCESS)
  {
    printf("TOF_request_%s_data_auto_connect SUCCESS\n", (enable ? "enable" : "disable"));
  }
  else
  {
    printf("TOF_request_%s_data_auto_connect FAILED\n", (enable ? "enable" : "disable"));
  }	

  return 0;
}

int Get_Data_Auto_Connect(int argc, char **argv)
{
  int nRet = TOF_FAIL;
  boolean enable = FALSE;
  
  nRet = TOF_request_get_data_auto_connect(&enable);
  if(nRet == TOF_SUCCESS)
  {
    printf("Data Auto Connection = %d\n", enable);
    printf("TOF_request_get_data_auto_connect SUCCESS\n");
  }
  else
  {
    printf("TOF_request_get_data_auto_connect FAILED\n");
  }	

  return 0;
}

int Set_Data_Profile_Info(int argc, char **argv)
{
  int   nRet                                   = TOF_FAIL;
  int   profile                                = 0;
  char* apn_name                               = NULL;
  tof_qcmap_msgr_ip_family_enum_v01 ip_family  = TOF_QCMAP_MSGR_IP_FAMILY_V4_V01;

  if(4 == argc)
  {
    profile   = atoi(argv[1]);
    apn_name  = (char*)(argv[2]);
    ip_family = (tof_qcmap_msgr_ip_family_enum_v01)atoi(argv[3]);
  }
  else
  {
    printf("Set_Data_Profile_Info Invalid Params\n");
  }

  nRet = TOF_request_set_data_profile_info(profile, apn_name, ip_family);
  if(nRet == TOF_SUCCESS)
  {
    printf("TOF_request_set_data_profile_info SUCCESS\n");
  }
  else
  {
    printf("TOF_request_set_data_profile_info FAILED\n");
  }

  return 0;
}

int Get_Data_Profile_Info(int argc, char **argv)
{
  int   nRet                                   = TOF_FAIL;
  int   profile                                = 0;
  char  apn_name[100]                          = {0};
  tof_qcmap_msgr_ip_family_enum_v01 ip_family;

  if(2 == argc)
  {
    profile   = atoi(argv[1]);
  }
  else
  {
    printf("Get_Data_Profile_Info Invalid Params\n");
  }

  nRet = TOF_request_get_data_profile_info(profile, apn_name, sizeof(apn_name), &ip_family);
  if(nRet == TOF_SUCCESS)
  {
    printf("Profile = %d, APN name = %s, IP family = %d\n", profile, apn_name, ip_family);
    printf("TOF_request_set_data_profile_info SUCCESS\n");
  }
  else
  {
    printf("TOF_request_set_data_profile_info FAILED\n");
  }

  return 0;
}

//20170215 yjoh add for cell info
int Get_cell_info(int argc, char **argv)
{
  int   nRet                                   = TOF_FAIL;
int i=0;
  TOF_cellinfo cellinfo;

  nRet = TOF_request_get_cell_info(&cellinfo);
  if(nRet == TOF_SUCCESS)
  {
	printf("TOF_request_get_cell_info SUCCESS\n");   
	if (cellinfo.gsm_info_valid==TRUE)
	{
		printf(" gsm_cellinfo.arfcn %d \n", cellinfo.gsm_cellinfo.arfcn);
		printf(" gsm_cellinfo.bsic %d \n", cellinfo.gsm_cellinfo.bsic);
		printf(" gsm_cellinfo.bsic_ncc %d \n", cellinfo.gsm_cellinfo.bsic_ncc);
		printf(" gsm_cellinfo.bsic_bcc %d \n", cellinfo.gsm_cellinfo.bsic_bcc);
		printf(" gsm_cellinfo.cell_id %d \n", cellinfo.gsm_cellinfo.cell_id);
		printf(" gsm_cellinfo.lac %d \n", cellinfo.gsm_cellinfo.lac);
		printf(" gsm_cellinfo.rx_lev %d \n", cellinfo.gsm_cellinfo.rx_lev);
		printf(" gsm_cellinfo.timing_advance %d \n", cellinfo.gsm_cellinfo.timing_advance);

	}
	if (cellinfo.wcdma_info_valid==TRUE)
	{
		printf(" wcdma_cellinfo.cell_id %d \n", cellinfo.wcdma_cellinfo.cell_id);
		printf(" wcdma_cellinfo.ecio %d \n", cellinfo.wcdma_cellinfo.ecio);
		printf(" wcdma_cellinfo.lac %d \n", cellinfo.wcdma_cellinfo.lac);
		printf(" wcdma_cellinfo.psc %d \n", cellinfo.wcdma_cellinfo.psc);
		printf(" wcdma_cellinfo.rscp %d \n", cellinfo.wcdma_cellinfo.rscp);
		printf(" wcdma_cellinfo.uarfcn %d \n", cellinfo.wcdma_cellinfo.uarfcn);
		
for ( i=0;i<4;i++){
		printf(" wcdma_cellinfo.umts_monitored_cell[%d].umts_psc %d \n",i, cellinfo.wcdma_cellinfo.umts_monitored_cell[i].umts_psc);
		printf(" wcdma_cellinfo.umts_monitored_cell[%d].umts_rscp %d \n",i, cellinfo.wcdma_cellinfo.umts_monitored_cell[i].umts_rscp);
		printf(" wcdma_cellinfo.umts_monitored_cell[%d].umts_ecio %d \n",i, cellinfo.wcdma_cellinfo.umts_monitored_cell[i].umts_ecio);
}
	}
	if (cellinfo.lte_info_valid==TRUE)
	{
		printf(" lte_cellinfo.cell_resel_priority %d \n", cellinfo.lte_cellinfo.cell_resel_priority);
		printf(" lte_cellinfo.earfcn %d \n", cellinfo.lte_cellinfo.earfcn);
		printf(" lte_cellinfo.global_cell_id %d \n", cellinfo.lte_cellinfo.global_cell_id);
		printf(" lte_cellinfo.serving_cell_id %d \n", cellinfo.lte_cellinfo.serving_cell_id);
		printf(" lte_cellinfo.s_intra_search %d \n", cellinfo.lte_cellinfo.s_intra_search);
		printf(" lte_cellinfo.s_non_intra_search %d \n", cellinfo.lte_cellinfo.s_non_intra_search);
		printf(" lte_cellinfo.tac %d \n", cellinfo.lte_cellinfo.tac);
		printf(" lte_cellinfo.thresh_serving_low %d \n", cellinfo.lte_cellinfo.thresh_serving_low);
		printf(" lte_cellinfo.rsrp %d \n", cellinfo.lte_cellinfo.rsrp);
		printf(" lte_cellinfo.rsrq %d \n", cellinfo.lte_cellinfo.rsrq);

		for ( i=0;i<4;i++){
		printf(" lte_cellinfo.cells[%d].pci %d \n",i, cellinfo.lte_cellinfo.cells[i].pci);
		printf(" lte_cellinfo.cells[%d].rsrp %d \n",i, cellinfo.lte_cellinfo.cells[i].rsrp);
		printf(" lte_cellinfo.cells[%d].rsrq %d \n",i, cellinfo.lte_cellinfo.cells[i].rsrq);
}
	}

		printf(" p_tmsi %llu \n", cellinfo.p_tmsi);
		printf(" network_mode %d \n", cellinfo.network_mode);
	
  }
  else
  {
    printf("TOF_request_get_cell_info FAILED\n");
  }

  return 0;
}

//dsji_20160311 add {
int	Send_SMS( int arg_c, char** arg_v )
{
	TOF_request_send_sms_s  	TOF_req;
	TOF_response_send_sms_s		TOF_rsp;

	if ( 3 != arg_c )
	{
    printf( "SEND_SMS [destination_address] [message]\n" );
    printf( "[destination_address] : destination to send SMS\n" );
    printf( "[message] : message of SMS. only support alphabet now\n" );
    printf( "ex) SEND_SMS 01048321143 abcdefghijklmnopqrstuvwxyz\n" );  
		
		return FALSE;
	}

	TOF_req.destination_address = arg_v[ 1 ];
	TOF_req.message = arg_v[ 2 ];
	
	if ( TRUE == TOF_request_send_sms( &TOF_req, &TOF_rsp ) )
	{
		printf( "send SMS ok, message_id:%d\n", TOF_rsp.message_id );
	}
	else
	{
		printf( "send SMS fail, cause_code:%d\n", TOF_rsp.cause_code );
	}
	
	return TRUE;
}



int Delete_SMS( int arg_c, char** arg_v )
{
	TOF_request_delete_sms_s  	TOF_req;
	TOF_response_delete_sms_s		TOF_rsp;

	if ( 2 != arg_c )
	{
    printf( "DELETE_SMS [message_index]\n" );
    printf( "[message_index] : index of SMS to delete\n" );
    printf( "ex) DELETE_SMS 3\n" );  

		return FALSE;
	}

	TOF_req.message_index = atoi( arg_v[ 1 ] );
	
	if ( TRUE == TOF_request_delete_sms( &TOF_req, &TOF_rsp ) )
	{
		printf( "index %d SMS delete ok\n", TOF_req.message_index );
	}

	return TRUE;
}



int	Read_SMS( int arg_c, char** arg_v )
{
	TOF_request_read_sms_s  	TOF_req;
	TOF_response_read_sms_s		TOF_rsp;

	if ( 2 != arg_c )
	{
    printf( "READ_SMS [message_index]\n" );
    printf( "[message_index] : index of SMS to read\n" );
    printf( "ex) READ_SMS 3\n" );  

		return FALSE;
	}

	TOF_req.message_index = atoi( arg_v[ 1 ] );
	
	if ( TRUE == TOF_request_read_sms( &TOF_req, &TOF_rsp ) )
	{
		printf( "date : %04d/%02d/%02d %02d:%02d:%02d\n",
								TOF_rsp.message_timestamp.year,
								TOF_rsp.message_timestamp.month,
								TOF_rsp.message_timestamp.day,
								TOF_rsp.message_timestamp.hour,
								TOF_rsp.message_timestamp.minute,
								TOF_rsp.message_timestamp.second );
		printf( "originating address : %s\n", TOF_rsp.originating_address );
		printf( "message : %s\n", TOF_rsp.message );
		printf( "index %d SMS read ok\n", TOF_req.message_index );
	}

	return TRUE;
}



int List_SMS( int arg_c, char** arg_v )
{
	TOF_request_list_sms_s 	TOF_req;
	TOF_response_list_sms_s	TOF_rsp;
	
	if ( TRUE == TOF_request_list_sms( &TOF_req, &TOF_rsp ) )
	{
		int i;

		printf( "SMS count : %d\n", TOF_rsp.message_info_num );

		for ( i = 0; i < TOF_rsp.message_info_num; ++i )
		{
			printf( "message_index : %d, message_tag_type : %d\n", 
								TOF_rsp.message_info_list[ i ].message_index, 
								TOF_rsp.message_info_list[ i ].message_tag_type );
		}
	}	

	return TRUE;
}



int Get_SMSC( int arg_c, char** arg_v )
{
	TOF_request_get_smsc_address_s		TOF_req;
	TOF_response_get_smsc_address_s 	TOF_rsp;
	
	if ( TRUE == TOF_request_get_smsc_address( &TOF_req, &TOF_rsp ) )
	{
		printf( "SMSC : %s\n", TOF_rsp.smsc_address_digits );
	}	

	return TRUE;
}



int Set_SMSC( int arg_c, char** arg_v )
{
	TOF_request_set_smsc_address_s		TOF_req;
	TOF_response_set_smsc_address_s 	TOF_rsp;

	if ( 2 != arg_c )
	{
    printf( "SET_SMSC [address_digit]\n" );
    printf( "[address_digit] : string of SMSC digit to set\n" );
    printf( "ex) SET_SMSC 158740343\n" );  

		return FALSE;
	}

	TOF_req.smsc_address_digits = arg_v[ 1 ];
	
	if ( TRUE == TOF_request_set_smsc_address( &TOF_req, &TOF_rsp ) )
	{
		printf( "set SMSC to : %s ok\n", TOF_req.smsc_address_digits );
	}	

	return TRUE;
}



int Get_SMS_memory_status( int arg_c, char** arg_v )
{
	TOF_request_get_memory_status_s TOF_req;
	TOF_response_get_memory_status_s TOF_rsp;
	
	if ( TRUE == TOF_request_get_memory_status( &TOF_req, &TOF_rsp ) )
	{
		printf( "memory_available : %d\n", TOF_rsp.memory_available );
	}	

	return TRUE;
}



int Test_SMS( int arg_c, char** arg_v )
{
	TOF_request_dial_call_s 	TOF_req;
	TOF_response_dial_call_s TOF_rsp;

	if ( 2 != arg_c )
	{
    printf( "Test_SMS argument fail\n" );
		
		return FALSE;
	}
	
	TOF_req.number = arg_v[ 1 ];

	if ( TRUE == TOF_request_dial_call( &TOF_req, &TOF_rsp ) )
	{
		printf( "dial call number : %s\n", TOF_req.number );
	}

	return TRUE;
}
//dsji_20160311 add }

int Set_pref_network(int argc, char **argv)
{
	int nRet;
	uint8 mode_pref = 0;

	mode_pref = (uint8)atoi(argv[1]);
   	
	nRet = TOF_request_set_pref_network(mode_pref);
	if(nRet == TOF_SUCCESS)
	{				                   
    printf("\n set preferred network type : %d\n", mode_pref);
    printf("SUCCESS\n");
	}
	else
	{
		printf("FAILED\n");
	}	

	return 0;

}

int Get_pref_network(int argc, char **argv)
{
	int nRet;
	uint16 mode_pref;
   	
	nRet = TOF_request_get_pref_network(&mode_pref);
	if(nRet == TOF_SUCCESS)
	{				                   
      printf("\n get preferred network type :  %d \n", mode_pref);   
      printf("SUCCESS\n");
	}
	else
	{
		printf("FAILED\n");
	}	

	return 0;

}

int Set_pref_mode(int argc, char **argv)
{
	int nRet;
	uint8 mode_pref = 0;
	uint64 mode_band_pref = 0;

	mode_pref = (uint8)atoi(argv[1]);
	mode_band_pref = (uint64)atoi(argv[2]);	

	nRet = TOF_request_set_pref_mode(mode_pref, mode_band_pref);
	if(nRet == TOF_SUCCESS)
	{				                   
    printf("\n set preferred mode 2: %d, %ld\n", mode_pref, mode_band_pref);
    printf("SUCCESS\n");
	}
	else
	{
		printf("FAILED\n");
	}	

	return 0;

}

int Get_pref_mode(int argc, char **argv)
{
	int nRet;
	uint16 mode_pref;
   	uint64 mode_band_pref;
			
	nRet = TOF_request_get_pref_mode(&mode_pref, &mode_band_pref);
	if(nRet == TOF_SUCCESS)
	{				                   
      printf("\n get preferred mode :  %d , %ld \n", mode_pref, mode_band_pref);   
      printf("SUCCESS\n");
	}
	else
	{
		printf("FAILED\n");
	}	

	return 0;

}

int Set_Service_Domain(int argc, char **argv)
{
	int nRet;
	uint16 service_domain = 0;

	service_domain = (uint16)atoi(argv[1]);
   	
	nRet = TOF_request_set_service_domain(service_domain);
	if(nRet == TOF_SUCCESS)
	{				                   
    printf("\n set service domain : %d\n", service_domain);
    printf("SUCCESS\n");
	}
	else
	{
		printf("FAILED\n");
	}	

	return 0;

}

int Get_Service_Domain(int argc, char **argv)
{
  int nRet;
  uint16 sercie_domain;
    
  nRet = TOF_request_get_service_domain(&sercie_domain);
            
  if(nRet == TOF_SUCCESS)
  {                          
      printf("\n get service domain :  %d \n", sercie_domain);   
      printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  } 

  return 0;

}

int Set_wcdma_rrc_version(int argc, char **argv)
{
	int nRet;
	uint16 rrc_version = 0;

	rrc_version = (uint16)atoi(argv[1]);
   	
	nRet = TOF_request_set_wcdma_rrc_version(rrc_version);
	if(nRet == TOF_SUCCESS)
	{				                   
    printf("\n set wcdma rrc version : %d\n", rrc_version);
    printf("SUCCESS\n");
	}
	else
	{
		printf("FAILED\n");
	}	

	return 0;

}

int Get_wcdma_rrc_version(int argc, char **argv)
{
  int nRet;
  uint16 rrc_version;
    
  nRet = TOF_request_get_wcdma_rrc_version(&rrc_version);
  if(nRet == TOF_SUCCESS)
  {                          
      printf("\n get wcdma rrc version :  %d \n", rrc_version);   
      printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  } 

  return 0;

}

int Set_wcdma_sms_mo_domain(int argc, char **argv)
{
	int nRet;
	byte mo_domain = 0;

	mo_domain = (byte)atoi(argv[1]);
   	
	nRet = TOF_request_set_wcdma_sms_mo_domain(mo_domain);
	if(nRet == TOF_SUCCESS)
	{				                   
    printf("\n set sms mo doamin : %d\n", mo_domain);
    printf("SUCCESS\n");
	}
	else
	{
		printf("FAILED\n");
	}	

	return 0;

}

int Get_wcdma_sms_mo_domain(int argc, char **argv)
{
  int nRet;
  byte mo_domain;
    
  nRet = TOF_request_get_wcdma_sms_mo_domain(&mo_domain);
  if(nRet == TOF_SUCCESS)
  {                          
      printf("\n get sms mo domain :  %d \n", mo_domain);   
      printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  } 

  return 0;
}

int Set_isr_enable(int argc, char **argv)
{
  int nRet;
  boolean isr_enable = 0;

  isr_enable = (boolean)atoi(argv[1]);
   	
  nRet = TOF_request_set_isr_enable(isr_enable);
  if(nRet == TOF_SUCCESS)
  {				                   
    printf("\n set isr enable : %d\n", isr_enable);
    printf("SUCCESS\n");
  }
  else
  {
  	printf("FAILED\n");
  }	

  return 0;

}

int Get_isr_enable(int argc, char **argv)
{
  int nRet;
  boolean isr_enable;
    
  nRet = TOF_request_get_isr_enable(&isr_enable);
  if(nRet == TOF_SUCCESS)
  {                          
      printf("\n get isr enable :  %d \n", isr_enable);   
      printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  } 

  return 0;

}

int Delete_stored_cell(int argc, char **argv)
{
  int nRet;
    
  nRet = TOF_request_delete_stored_cell();
  if(nRet == TOF_SUCCESS)
  {                          
      printf("\n deleted stored cell \n");   
      printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  } 

  return 0;

}

int Get_network_selection_mode(int argc, char **argv)
{
  int nRet;
  uint8 mode;	
    
  nRet = TOF_request_get_network_selection_mode(&mode);
  if(nRet == TOF_SUCCESS)
  {                          
	  printf("\n get network selection mode :  %d \n", mode); 	
    printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  } 

  return 0;

}

int Set_network_selection_auto(int argc, char **argv)
{
  int nRet;
    
  nRet = TOF_request_set_network_selection_auto();
  if(nRet == TOF_SUCCESS)
  {                          
    printf("\n set network selection automode \n");   
    printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  } 

  return 0;

}

int Get_operator(int argc, char **argv)
{
  int nRet;
  TOF_Operator_Info Tof_Operator;	
    
  nRet = TOF_request_get_operator(&Tof_Operator);
  if(nRet == TOF_SUCCESS)
  {                          
	  printf("\n mcc :  %d \n", Tof_Operator.mcc); 	
	  printf("\n mnc :  %d \n", Tof_Operator.mnc); 	
	  printf("\n network name :  %s \n", Tof_Operator.network_name); 			
    printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  } 

  return 0;

}

int Get_ims_auth_scheme(int argc, char **argv)
{
  int nRet;
  uint8 auth_scheme;
    
  nRet = TOF_request_get_ims_auth_scheme(&auth_scheme);
  if(nRet == TOF_SUCCESS)
  {                          
    printf("\n get auth_scheme :  %d \n", auth_scheme);
    printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  } 

  return 0;

}

int Set_ims_auth_scheme(int argc, char **argv)
{
  int nRet;
  uint8 auth_scheme;

  auth_scheme = (uint8)atoi(argv[1]);
  nRet = TOF_request_set_ims_auth_scheme(auth_scheme);
  if(nRet == TOF_SUCCESS)
  {                          
    printf("\n set ims auth scheme \n");   
    printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  } 

  return 0;

}

int Get_ims_param_src(int argc, char **argv)
{
  int nRet;
  uint8 ims_param_src;
    
  nRet = TOF_request_get_ims_dpl_param_src(&ims_param_src);
  if(nRet == TOF_SUCCESS)
  {                          
    printf("\n get IMS Param Source :  %d \n", ims_param_src);
    printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  } 

  return 0;

}

int Set_ims_param_src(int argc, char **argv)
{
  int nRet;
  uint8 ims_param_src;

  ims_param_src = (uint8)atoi(argv[1]);
  nRet = TOF_request_set_ims_dpl_param_src(ims_param_src);
  if(nRet == TOF_SUCCESS)
  {                          
    printf("\n set IMS Param Source \n");   
    printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  } 

  return 0;

}

int Get_ims_reg_event_enable(int argc, char **argv)
{
  int nRet;
  uint8 reg_event_en;
    
  nRet = TOF_request_get_reg_event(&reg_event_en);
  if(nRet == TOF_SUCCESS)
  {                          
    printf("\n get IMS Reg Event Enable :  %d \n", reg_event_en);
    printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  } 

  return 0;

}

int Set_ims_reg_event_enable(int argc, char **argv)
{
  int nRet;
  uint8 reg_event_en;

  reg_event_en = (uint8)atoi(argv[1]);

  if((reg_event_en != 0) && (reg_event_en != 1))
  {
    printf("Please input a proper value between 0 ~ 1\n");
    return 0;
  }
  
  nRet = TOF_request_set_reg_event(reg_event_en);
  if(nRet == TOF_SUCCESS)
  {                          
    printf("\n set IMS Reg Event Enable \n");   
    printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  } 

  return 0;

}

int Get_voip_srv_status(int argc, char **argv)
{
  int nRet;
  uint8 voip_srv_stat = 0;

  nRet = TOF_request_get_voip_srv_status(&voip_srv_stat);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("VoIP Service Status = %d\n",voip_srv_stat);
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Get_ims_srv_status(int argc, char **argv)
{
  int nRet;
  tof_Imsa_Reg_Status_Info ims_reg_stat;

  nRet = TOF_request_get_ims_srv_status(&ims_reg_stat);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("IMS Registration Status = %d, Registration Error Code =%d\n",
                  ims_reg_stat.ims_registered,ims_reg_stat.ims_registration_failure_error_code);
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int Set_GPS_reg_event(int argc, char **argv)
{
  int nRet;
  UINT16 type;
  
  if(argc < 2)
  {
    printf("    GPSREG [type]\n");

    printf("EX) GPSREG 1\n");  
    printf("EX) GPSREG 4\n");
    printf("EX) GPSREG 8196\n");
  }
  else
  {    
  	type = (UINT16)atoi(argv[1]);
    
    nRet = TOF_request_gps_reg_event(type);
    if(nRet == TOF_SUCCESS)
    {                          
        printf("\n request gps reg event \n");   
        printf("SUCCESS\n");
    }
    else
    {
      printf("FAILED\n");
    } 
    
    return 0;
  }
}

int Set_GPS_Func(int argc, char **argv)
{
  int nRet;
  int i=0;
  UINT16 oper_mode;
  
  if(argc < 2)
  {
    printf("    GPSSET [type]\n");
    printf("    [type]: START or STOP \n");
    printf("EX) GPSSET START\n");  
    printf("EX) GPSSET STOP\n");
  }
  else
  {    
    UpperStr( argv[1] );
    
    if(strcmp(argv[1], "START") == 0)
    {
      //oper_mode = (UINT16)atoi(argv[2]);
      
      nRet = TOF_request_gps_start();

      if(nRet == TOF_SUCCESS)
      {
        printf("Set_GPS_Func() Success to read  GPS START \n");

      }
      else
      {
        printf("Set_GPS_Func() Failed to read  GPS START \n");
      }
    }
    else if(strcmp(argv[1], "STOP") == 0)
    {
      nRet = TOF_request_gps_stop();

      if(nRet == TOF_SUCCESS)
      {
        printf("Set_GPS_Func() Success to read  GPS STOP \n");

      }
      else
      {
        printf("Set_GPS_Func() Failed to read  GPS STOP \n");
      }
    }   
    else
    {
      printf("FAILED\n");    
    }
  }

  return 0;
}


int Set_GPS_Operation_Mode(int argc, char **argv)
{
  int nRet;
  UINT16 mode;

  if(argc < 2)
  {
    printf("    SETGPSOPERMODE [oper mode]\n");

    printf("EX) SETGPSOPERMODE 0\n");  
  }
  else
  {    
    mode = (UINT16)atoi(argv[1]);

      nRet = TOF_request_gps_set_operation_mode(mode);
      if(nRet == TOF_SUCCESS)
      {                          
          printf("\n request gps set operation mode \n");   
          printf("SUCCESS\n");
      }
      else
      {
        printf("FAILED\n");
      } 
      
      return 0;
  }
}


int Get_GPS_Operation_Mode(int argc, char **argv)
{
  int nRet;
  uint16 mode;
    
  nRet = TOF_request_gps_get_operation_mode();
            
  if(nRet == TOF_SUCCESS)
  {                          
      printf("\n get GPS Operation mode \n" );   
      printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  } 

  return 0;

}


int Set_GPS_nmea_type(int argc, char **argv)
{
  int nRet;
  UINT32 mode;

  if(argc < 2)
  {
    printf("    GPSNMEATYPE [type]\n");

    printf("EX) GPSNMEATYPE 0\n");  
  }
  else
  {    
    mode = (UINT32)atoi(argv[1]);

      nRet = TOF_request_gps_set_nmea_type(mode);
      if(nRet == TOF_SUCCESS)
      {                          
          printf("\n request gps set nmea type \n");   
          printf("SUCCESS\n");
      }
      else
      {
        printf("FAILED\n");
      } 
      
      return 0;
  }
}


int Get_GPS_nmea_type(int argc, char **argv)
{
  int nRet;
  uint16 mode;
    
  nRet = TOF_request_gps_get_nmea_type();
            
  if(nRet == TOF_SUCCESS)
  {                          
      printf("\n get GPS nmea type \n" );   
      printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  } 

  return 0;

}

int Get_GPS_reg_event(int argc, char **argv)
{
  int nRet;
  UINT16 type;

  nRet = TOF_request_gps_get_reg_event();
  if(nRet == TOF_SUCCESS)
  {                          
      printf("\n request get gps reg event \n");   
      printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  } 
  
  return 0;
}

int Set_GPS_SPL_Server_Info(int argc, char **argv)
{
  int nRet;
  uint8 server_type;
  tof_loc_spl_server_info_type supl_info;

  memset(&supl_info,0,sizeof(tof_loc_spl_server_info_type));

  if(argc >= 2)
    supl_info.loc_agps_supl_server_type = (uint8 )atoi(argv[1]);
  printf("SUCCESS 1, argc =%d\n",argc);
  if(argc >= 3)
  {
    if(strlen(argv[2]) > 4)
    {
      strncpy(supl_info.ipv4_addr,argv[2],strlen(argv[2])>INET_ADDRSTRLEN?INET_ADDRSTRLEN:strlen(argv[2]));
    }    
  }    
  printf("SUCCESS 2, argv[2] length =%d\n",strlen(argv[2]));
  if(argc >= 4)
  {
    if(strlen(argv[2]) > 4)
    {
      supl_info.ipv4_port = (uint16 )atoi(argv[3]);
    }
  }    
  printf("SUCCESS 3, ipv4_port =%d\n",supl_info.ipv4_port);
  if(argc >= 5)
  {
    printf("SUCCESS 3-1\n");
    strncpy(supl_info.urlAddr,argv[4],strlen(argv[4])>TOF_LOC_MAX_SERVER_ADDR_LENGTH?TOF_LOC_MAX_SERVER_ADDR_LENGTH:strlen(argv[4]));
  }
  else
  {
    printf("SUCCESS 3-2\n");
    memset(supl_info.urlAddr,NULL,TOF_LOC_MAX_SERVER_ADDR_LENGTH + 1);
  }
  printf("SUCCESS 4 urlAddr_len =%d\n",strlen(supl_info.urlAddr));
  
  nRet = TOF_request_gps_set_spl_server_info(supl_info);
            
  if(nRet == TOF_SUCCESS)
  {                          
      printf("\n get GPS SPL Server Info \n" );   
      printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  } 

  return 0;

}

int Get_GPS_SPL_Server_Info(int argc, char **argv)
{
  int nRet;
  int srv_type;

  if(argc < 2)
  {
    printf("    GETSPLSVINFO [type]\n");
    printf("type >> 1:CMDA PDE, 2:CDMA_MPC, 3:UMTS_SLP, 4:CUSTOM_PDE\r\n");
    printf("EX) GETSPLSVINFO 1\n");  

    return 0;
  }
  srv_type = (INT32)atoi(argv[1]);
  nRet = TOF_request_gps_get_spl_server_info(srv_type);
            
  if(nRet == TOF_SUCCESS)
  {                          
      printf("\n get GPS SPL Server Info \n" );   
      printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  } 

  return 0;

}

int Get_GPS_SPL_Server_conn_handle(int argc, char **argv)
{
  int nRet;
  int srv_type;

  if(argc < 2)
  {
    printf("    GPSSPLSVCONNHDL [type]\n");
    printf("type >> 1:Open Connection, 2:Close Connection\r\n");
    printf("EX) GPSSPLSVCONNHDL 1\n");  

    return 0;
  }
  srv_type = (INT32)atoi(argv[1]);
  nRet = TOF_request_gps_spl_server_conn_handle(srv_type);
            
  if(nRet == TOF_SUCCESS)
  {                          
      printf("\n get GPS SPL Server Connection Handle \n" );   
      printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  } 

  return 0;

}

int GPS_Del_Assist_Data(int argc, char **argv)
{
  int nRet;
  int all_data;

  if(argc < 2)
  {
    printf("    GPSDELASSISTDATA [type]\n");
    printf("EX) GPSDELASSISTDATA 1\n");  

    return 0;
  }
  all_data = (INT32)atoi(argv[1]);
  nRet = TOF_request_gps_del_assist_data(all_data);
            
  if(nRet == TOF_SUCCESS)
  {                          
      printf("\n Delete a Assiste Data! \n" );   
      printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  } 

  return 0;

}

int GPS_GPS_Coordinates(int argc, char **argv)
{
  int nRet;
  double lat=0;
  double lon=0;
  float alt=0;
  
  if(argc < 2)
  {
    printf("    GETCOORDINATES [type]\n");
    printf("    [type]: LAT,LON,ALT \n");
    printf("EX) GETCOORDINATES LAT\n");  
    printf("EX) GETCOORDINATES LON\n");  
    printf("EX) GETCOORDINATES ALT\n");  
  }
  else
  {    
    UpperStr( argv[1] );
    
    if(strcmp(argv[1], "LAT") == 0)
    {
      nRet = TOF_request_gps_getLatitude(&lat);

      if(nRet == TOF_SUCCESS)
      {
          printf("Latitude %lf\n",lat);
      }
      else
      {
        printf("GPS_GPS_Coordinates() Failed to read  Latitude \n");
      }
    }
    else if(strcmp(argv[1], "LON") == 0)
    {
      nRet = TOF_request_gps_getLongitude(&lon);

      if(nRet == TOF_SUCCESS)
      {
          printf("Longitude %lf\n",lon);
      }
      else
      {
        printf("GPS_GPS_Coordinates() Failed to read  Longitude \n");
      }
    }   
    else if(strcmp(argv[1], "ALT") == 0)
    {
      nRet = TOF_request_gps_getAltitude(&alt);

      if(nRet == TOF_SUCCESS)
      {
          printf("Altitude %f\n",alt);
      }
      else
      {
        printf("GPS_GPS_Coordinates() Failed to read  Altitude \n");
      }
    }       
    else
    {
      printf("FAILED\n");    
    }
  }

  return 0;
}

int GPS_GPS_getHeading(int argc, char **argv)
{
  int nRet;
  float heading=0;
  
  nRet = TOF_request_gps_getHeading(&heading);

	if(nRet == TOF_SUCCESS)
	{				                   
      printf("heading %f\n",heading);
      printf("SUCCESS\n");
	}
	else
	{
		printf("FAILED\n");
	}	

  return 0;
}

int GPS_GPS_getSpeed(int argc, char **argv)
{
  int nRet;
  float speed=0;
  
  nRet = TOF_request_gps_getSpeed(&speed);

	if(nRet == TOF_SUCCESS)
	{				                   
      printf("speed %f\n",speed);
      printf("SUCCESS\n");
	}
	else
	{
		printf("FAILED\n");
	}	

  return 0;
}

int GPS_GPS_getVerticalSpeed(int argc, char **argv)
{
  int nRet;
  float vspeed=0;
  
  nRet = TOF_request_gps_getVerticalSpeed(&vspeed);

  if(nRet == TOF_SUCCESS)
  {				                   
      printf("vspeed %f\n",vspeed);
      printf("SUCCESS\n");
  }
  else
  {
  	printf("FAILED\n");
  }	

  return 0;
}

int GPS_GPS_getVDOP(int argc, char **argv)
{
  int nRet;
  float vdop=0;
  
  nRet = TOF_request_gps_getVDOP(&vdop);

  if(nRet == TOF_SUCCESS)
  {				                   
      printf("vdop %f\n",vdop);
      printf("SUCCESS\n");
  }
  else
  {
  	printf("FAILED\n");
  }	

  return 0;
}

int GPS_GPS_getHDOP(int argc, char **argv)
{
  int nRet;
  float hdop=0;
  
  nRet = TOF_request_gps_getHDOP(&hdop);

  if(nRet == TOF_SUCCESS)
  {				                   
    printf("hdop %f\n",hdop);
    printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED\n");
  }	

  return 0;
}

int GPS_GPS_getPDOP(int argc, char **argv)
{
  int nRet;
  float pdop=0;
  
  nRet = TOF_request_gps_getPDOP(&pdop);

	if(nRet == TOF_SUCCESS)
	{				                   
      printf("pdop %f\n",pdop);
      printf("SUCCESS\n");
	}
	else
	{
		printf("FAILED\n");
	}	

  return 0;
}

int GPS_GPS_getSpeedAccuracy(int argc, char **argv)
{
  int nRet;
  float sacc=0;
  
  nRet = TOF_request_gps_getSpeedAccuracy(&sacc);

	if(nRet == TOF_SUCCESS)
	{				                   
      printf("speedaccuracy %f\n",sacc);
      printf("SUCCESS\n");
	}
	else
	{
		printf("FAILED\n");
	}	

  return 0;
}

int GPS_GPS_getAltitudeMSL(int argc, char **argv)
{
  int nRet;
  float altmsl=0;
  
  nRet = TOF_request_gps_getAltitudeMSL(&altmsl);

	if(nRet == TOF_SUCCESS)
	{				                   
      printf("altmsl %f\n",altmsl);
      printf("SUCCESS\n");
	}
	else
	{
		printf("FAILED\n");
	}	

  return 0;
}

int GPS_GPS_getHorizontalAccuracy(int argc, char **argv)
{
  int nRet;
  float haccuracy=0;
  
  nRet = TOF_request_gps_getHorizontalAccuracy(&haccuracy);

	if(nRet == TOF_SUCCESS)
	{				                   
      printf("haccuracy %f\n",haccuracy);
      printf("SUCCESS\n");
	}
	else
	{
		printf("FAILED\n");
	}	

  return 0;
}

int GPS_getGnssSVInfo(int argc, char **argv)
{
  int nRet;
  tof_qmiLocEventGnssSvInfoIndMsgT_v02 SvInfo;

  nRet = TOF_request_gps_getGnssSVInfo(&SvInfo);

	if(nRet == TOF_SUCCESS)
	{	
      printf("SvInfo.svList.gnssSvId 1 %d\n",SvInfo.svList[0].gnssSvId);
      printf("SvInfo.svList.gnssSvId 2 %d\n",SvInfo.svList[1].gnssSvId);
      printf("SvInfo.svList.gnssSvId 3 %d\n",SvInfo.svList[2].gnssSvId);
      printf("SvInfo.svList.gnssSvId 4 %d\n",SvInfo.svList[3].gnssSvId);
      printf("SvInfo.svList.gnssSvId 5 %d\n",SvInfo.svList[4].gnssSvId);
      printf("SvInfo.svList.gnssSvId 6 %d\n",SvInfo.svList[5].gnssSvId);      
      printf("SvInfo.svList.gnssSvId 7 %d\n",SvInfo.svList[6].gnssSvId);
      printf("SvInfo.svList.gnssSvId 8 %d\n",SvInfo.svList[7].gnssSvId);
      printf("SvInfo.svList.gnssSvId 9 %d\n",SvInfo.svList[8].gnssSvId);
              
      printf("SUCCESS\n");
	}
	else
	{
		printf("FAILED\n");
	}	

  return 0;
}

int GPS_getPositionInfo(int argc, char **argv)
{
  int nRet;
  tof_qmiLocEventPositionReportIndMsgT_v02 PoInfo;
   
  nRet = TOF_request_gps_getPositionInfo(&PoInfo);

	if(nRet == TOF_SUCCESS)
	{	
      printf("PoInfo.gnssSvUsedList[0] %d\n",PoInfo.gnssSvUsedList[0]);
      printf("PoInfo.gnssSvUsedList[1] %d\n",PoInfo.gnssSvUsedList[1]);
      printf("PoInfo.gnssSvUsedList[2] %d\n",PoInfo.gnssSvUsedList[2]);
      printf("PoInfo.gnssSvUsedList[3] %d\n",PoInfo.gnssSvUsedList[3]);
      printf("PoInfo.gnssSvUsedList[4] %d\n",PoInfo.gnssSvUsedList[4]);
      printf("PoInfo.gnssSvUsedList[5] %d\n",PoInfo.gnssSvUsedList[5]);
      printf("PoInfo.gnssSvUsedList[6] %d\n",PoInfo.gnssSvUsedList[6]);
      printf("PoInfo.gnssSvUsedList[7] %d\n",PoInfo.gnssSvUsedList[7]);      
      printf("PoInfo.gnssSvUsedList[8] %d\n",PoInfo.gnssSvUsedList[8]);

              
      printf("SUCCESS\n");
	}
	else
	{
		printf("FAILED\n");
	}	

  return 0;
}

void printf_cmd_list(void)
{
  int cmdlp = 0;
  
  while( Cmds[cmdlp].CmdStr )
  {
      printf("Cmds[%d].CmdStr: %s, \n", cmdlp,Cmds[cmdlp].CmdStr);			
      cmdlp++;
  }
      
}

void main(void)
{
  char ReadBuffer[1024];
  int   argc;
  char *argv[128];
  int   cmdlp;	

  if(TOF_API_init() != TOF_SUCCESS) return;

  //TODO : add function.
  main_run_flag = TRUE;

  printf("Modem Type - Callback Type API\n");
  if(TOF_SetEventHandle(CBF_Event, NULL) != TOF_SUCCESS) 
    return;

/*----------------GPS Test Only ------------------*/
/*
  TOF_request_gps_reg_event(7);
  TOF_request_gps_set_operation_mode(4);
  TOF_request_gps_set_nmea_type(32767);
  TOF_request_gps_start(); 
*/

  while(main_run_flag)
  {
    printf( "COMMAND>");
    memset( ReadBuffer, 0 , sizeof( ReadBuffer ) );
    // �ø��󿡼� ���ɾ �Էµɶ����� ����Ѵ�.
    gets_his( ReadBuffer );
    printf( "\n");
    argc = parse_args( ReadBuffer, argv );

    if(argc)
    {
      boolean list = FALSE;
      boolean found = FALSE;

      UpperStr( argv[0] );
      printf("strcmp( argv[0]: %s \n", argv[0]);			

      if( strcmp( argv[0], "EXIT") == 0 ) break;

      if( strcmp( argv[0], "LS") == 0 )
      {
        list = TRUE;        
        found = TRUE;
      }
      
      cmdlp = 0;
      
      while( Cmds[cmdlp].CmdStr )
      {
        if(list)
        {   
          printf_cmd_list();
          break;
        }

        if( strcmp( argv[0], Cmds[cmdlp].CmdStr ) == 0 )
        {
          printf("argc: %d argv[0]:%s argv[1]: %s, \n", argc, argv[0], argv[1]);
          Cmds[cmdlp].func( argc, argv );
          printf( "\n");
          found  = TRUE;
          break;
        }

        cmdlp++;
      }
      
      if(!found)
        printf_cmd_list();
    }
  }

  TOF_API_release();
  printf("TOF_API_release\n");

  exit(0);
}

int Get_Number(int argc, char** argv)
{
  int nRet = 0;
  char number[33] ;
  
  nRet = TOF_request_get_phone_number(number);
  if(nRet == TOF_SUCCESS)
  {				                   
      printf("number =%s\n", number);
      printf("SUCCESS\n");
  }
  else
  {
  	printf("FAILED\n");
  }	 

  return nRet;
}

int Get_Iccid(int argc, char** argv)
{
  int nRet = 0;
  char iccid[21] ;
  
  nRet = TOF_request_get_iccid(iccid);
  if(nRet == TOF_SUCCESS)
  {				                   
      printf("iccid =%s\n", iccid);
      printf("SUCCESS\n");
  }
  else
  {
  	printf("FAILED\n");
  }	 

  return nRet;
}

int Config_Gpio(int argc, char **argv)
{
  int nRet;
  int gpio_num, gpio_flag;

  nRet = TOF_FAIL;

  if(argc < 3)
  {
    printf("    CONFIG_GPIO [PAD] [DIRECTION]\n");
    printf("    [PAD]: PAD NUMBER\n");
    printf("    [DIRECTION]: 0(IN) or 1(OUT) \n");
    printf("EX) CONFIG_GPIO 70 1\n");  
    printf("EX) CONFIG_GPIO 70 0\n");
    //print_supported_gpios();
  }
  else
  {
    gpio_num = atoi(argv[1]);
    gpio_flag = atoi(argv[2]);

    if(gpio_flag != 0 && gpio_flag != 1)
    {
      printf("Input ERROR! Only 0 or 1 value is supported for [DIRECTION] \n");
      return TOF_FAIL;
    }
    nRet = TOF_gpio_config(gpio_num, gpio_flag);
    if(nRet == TOF_SUCCESS)
    {
      printf("SUCCESS\n");
    }
    else
    {
      printf("FAILED\n");
    }	 
  }
  return nRet;
}

int Config_Gpio_Print(int argc, char **argv)
{
    int gpio_num = 0;
    int val = -1;
    char buf_edge[10];
    char buf_dir[5];

    if(argc < 2)
    {
        printf("PRINT_GPIO [PAD]\n");
        printf("[PAD]: PAD NUMBER\n");
        printf("EX) PRINT_GPIO 68\n");
    }
    else
    {
        gpio_num = atoi(argv[1]);
        
        if((TOF_gpio_get(gpio_num, &val) == TOF_SUCCESS ) && (TOF_gpio_get_edge(gpio_num, buf_edge) == TOF_SUCCESS) && (TOF_gpio_get_direction(gpio_num, buf_dir) == TOF_SUCCESS))
        {
            printf("Config Gpio Print : 0x%x\n", gpio_num);
            printf("Direction : %s : \n", buf_dir);
            printf("Value : %d (0:LOW, 1:HIGH)\n", val);
            printf("EDGE : %s\n", buf_edge); 
        }
        else
        {
            printf("Config Gpio Print Fail\n");
            return -1;
        }
    }

    return TOF_SUCCESS;
}

int Intr_Gpio(int argc, char **argv)
{
  int nRet = 0;
  int gpio_num, gpio_fd;
  char edge[10];

  struct pollfd fdset[2];
  int nfds = 2;
  int rc;
  char *buf[64];

  if(argc < 3)
  {
    printf("    INTR_GPIO [PAD] [EDGE]\n");
    printf("    [PAD]: PAD NUMBER\n");
    printf("    [EDGE]: 0(IN) or 1(OUT) \n");
    printf("EX) INTR_GPIO 70 polling\n");  
    printf("EX) INTR_GPIO 70 rising\n");
    //print_supported_gpios();
  }
  else
  {
    gpio_num = atoi(argv[1]);
    strcpy(edge, argv[2]);
    
    nRet = TOF_gpio_set_edge(gpio_num, edge);
    if(nRet == TOF_SUCCESS)
    {
      if(TOF_SUCCESS == TOF_gpio_fd_open(gpio_num,&gpio_fd))
        {
          printf("Config_Gpio : gpio_fd = 0x%x \n",gpio_fd);
          printf("Waiting for interrupt...");
          while (1) {
            memset((void*)fdset, 0, sizeof(fdset));      
            fdset[0].fd = STDIN_FILENO;
            fdset[0].events = POLLIN;
              
            fdset[1].fd = gpio_fd;
            fdset[1].events = POLLPRI;
        
            rc = poll(fdset, nfds, 3000);      
        
            if (rc < 0) {
              printf("\npoll() failed!\n");
              return -1;
            }
              
            if (rc == 0) {
              printf(".");
            }
                    
            if (fdset[1].revents & POLLPRI) {
              read(fdset[1].fd, buf, 64);
              printf("\npoll() GPIO %d interrupt occurred\n", gpio_num);
            }
        
            if (fdset[0].revents & POLLIN) {
              break;
              //(void)read(fdset[0].fd, buf, 1);
              //printf("\npoll() stdin read 0x%2.2X\n", (unsigned int) buf[0]);              
            }
        
            fflush(stdout);
            lseek(gpio_fd, 0, SEEK_SET);
            usleep(100000);
          }
          TOF_gpio_fd_close(gpio_fd);
          printf("SUCCESS\n");
      }
    }
    else
    {
      printf("FAILED\n");
    }	 
  }
	return nRet;
}

int Set_Gpio_Edge(int argc, char **argv)
{
  int nRet = 0;
  int gpio_num, edge_status;
  char* edge;

  if(argc < 3)
  {
    printf("    SET_GPIO_EDGE [PAD] [VALUE]\n");
    printf("    [PAD]: PAD NUMBER\n");
    printf("    [VALUE]: 0(NONE) or 1(RISING) or 2(FALLING) or 3(BOTH) \n");
    printf("EX) SET_GPIO_EDGE 70 2\n");  
    printf("EX) SET_GPIO_EDGE 70 1\n");  
    printf("EX) SET_GPIO_EDGE 70 0\n");
    //print_supported_gpios();
  }
  else
  {
    gpio_num = atoi(argv[1]);
    edge_status = atoi(argv[2]);
    
	switch(edge_status)
	{
	case 0:
	    nRet = TOF_gpio_set_edge(gpio_num, "none");
        break;
	case 1:
	    nRet = TOF_gpio_set_edge(gpio_num, "rising");
        break;
	case 2:
	    nRet = TOF_gpio_set_edge(gpio_num, "falling");
        break;
    case 3:
        nRet = TOF_gpio_set_edge(gpio_num, "both");
        break;
	default:
        printf("Wrong Argument (VALUE : [0-3])\n");
	}
    
    if(nRet == TOF_SUCCESS)
    {
      printf("SUCCESS\n");
    }
    else
    {
      printf("FAILED\n");
    }	
  }
  
  return nRet;
}

int Set_Gpio(int argc, char **argv)
{
  int nRet = 0;
  int gpio_num, gpio_status;

  if(argc < 3)
  {
    printf("    SET_GPIO [PAD] [VALUE]\n");
    printf("    [PAD]: PAD NUMBER\n");
    printf("    [VALUE]: 0(LOW) or 1(HIGH) \n");
    printf("EX) SET_GPIO 70 1\n");  
    printf("EX) SET_GPIO 70 0\n");
    //print_supported_gpios();
  }
  else
  {
    gpio_num = atoi(argv[1]);
    gpio_status = atoi(argv[2]);
    
    nRet = TOF_gpio_set(gpio_num, gpio_status);
    if(nRet == TOF_SUCCESS)
    {
      printf("SUCCESS\n");
    }
    else
    {
      printf("FAILED\n");
    }	
  }
	return nRet;
}
int Get_Gpio(int argc, char **argv)
{
  int nRet = 0;
  int gpio_num, gpio_status;

  if(argc < 2)
  {
    printf("    GET_GPIO [PAD]\n");
    printf("    [PAD]: PAD NUMBER\n");
    printf("EX) GET_GPIO 70\n");  
    printf("EX) SET_GPIO 70\n");
    //print_supported_gpios();
  }
  else
  {
    gpio_num = atoi(argv[1]);
    
    nRet = TOF_gpio_get(gpio_num, &gpio_status);
    if(nRet == TOF_SUCCESS)
    {
      printf("SUCCESS\n");
      printf("GPIO %d status is %d (0:LOW, 1:HIGH)",gpio_num,gpio_status);
    }
    else
    {
      printf("FAILED\n");
    }
  }
	return nRet;
}

int Connect_WiFi(int argc, char **argv)
{
  int nRet = 0;
  
  if(argc < 2)
  {
    printf("type SSID\n");
  }
  else if(argc==2)
  {
    nRet = TOF_wifi_connect(argv[1],NULL,0);
  }
  else
  {
    nRet = TOF_wifi_connect(argv[1],argv[2],argv[3][0]-'0');
  }
  
  return nRet;
}

int Get_Modem_Except_Info(int argc, char** argv)
{
  int nRet=TOF_SUCCESS, i, option;
  uint8 count=0;
  tof_dms_get_exception_info except_info;

  if(argc < 2)
  {
    printf("    EXCEPINFO [Option]\n");
    printf("Get Exception Count : EXCEPINFO 1\n");
    printf("Get Exception Info : EXCEPINFO 2\n");
    printf("Del Exception Info : EXCEPINFO 3\n");
  }
  else
  {
    option = atoi(argv[1]);

    switch(option)
    {
      case 1:
      {
        nRet = TOF_request_get_exception_count(&count);

        if(nRet == TOF_SUCCESS)
        {
          printf("exception count = %d\n", count);
          printf("SUCCESS\n");
        }
        else
        {
          printf("FAILED\n");
        }
      }
      break;

      case 2:
      {
        nRet = TOF_request_get_exception_count(&count);

        if(nRet == TOF_SUCCESS)
        {
          printf("exception count = %d\n", count);
        }
        else
        {
          printf("Get exception count failed..\n");
          return nRet;
        }
        
        if (count == 0)
        {
          printf("No exception file saved..\n");
        }
        else
        {
          for (i=0; i<count; i++)
          {
              memset(&except_info, 0x0, sizeof(tof_dms_get_exception_info));
              nRet = TOF_request_get_exception_info((uint8)i, &except_info);

            if(nRet == TOF_SUCCESS)
            {
                printf("Index[%02d] : modem_version  = %s\n", i+1, except_info.modem_sw_version);
                printf("Index[%02d] : exception_date = %s\n", i+1, except_info.exception_date);
                printf("Index[%02d] : exception_time = %s\n", i+1, except_info.exception_time);
                printf("Index[%02d] : exception_line = %d\n", i+1, except_info.exception_line);
                printf("Index[%02d] : exception_file = %s\n", i+1, except_info.exception_file);
                printf("Index[%02d] : exception_msg  = %s\n", i+1, except_info.exception_msg);
                printf("---------------------------------------------\n");
            }
            else
            {
              printf("FAILED\n");
              return nRet;
            }
          }
        }
      }
      break;

      case 3:
      {
        nRet = TOF_request_delete_exception_info();

        if(nRet == TOF_SUCCESS)
        {
          printf("SUCCESS\n");
        }
        else
        {
          printf("FAILED\n");
        }
      }
      break;

      default:
      {
        printf("Argument failed..\n");
        nRet = TOF_FAIL;
      }
      break;
    }
  }

  return nRet;
}

int unlock_sim(int argc, char **argv)
{
  int nRet;
  char pin_value[16 + 1] = {0.};

  if(argc < 1)
  {
    printf("Input ENTERPIN [PIN_Code]\n");
    printf("Try again...\n");
  }
  else
  {
    strcpy(pin_value, argv[1]);

    printf("unlock_sim %s\n", pin_value);
    
    nRet = TOF_unlock_sim(pin_value);
    
    if(nRet == TOF_SUCCESS)
    {
      printf("SUCCESS\n");
    }
    else
    {
      printf("FAILED Return %d\n",nRet);
    }
  }

  return 0;
}

int is_locked(int argc, char **argv)
{
  int nRet;
  boolean lock;

  nRet = TOF_is_locked(&lock);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("PIN1 lock : %d\n",lock);
    printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED Return %d\n",nRet);
  }

  return 0;
}

int is_enabled(int argc, char **argv)
{
  int nRet;
  boolean enabled;

  nRet = TOF_is_enabled(&enabled);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("PIN1 enabled : %d\n",enabled);
    printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED Return %d\n",nRet);
  }

  return 0;
}

int get_subsid(int argc, char **argv)
{
  int nRet;
  uint8 imsi[9] = {0,};

  nRet = TOF_GetSubscriberId(imsi);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED Return %d\n",nRet);
  }

  return 0;
}

int get_iccident(int argc, char **argv)
{
  int nRet;
  uint8 iccid[10] = {0,};

  nRet = TOF_GetICCIdentification(iccid);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED Return %d\n",nRet);
  }

  return 0;
}

int is_present(int argc, char **argv)
{
  printf("TOF_IsPresent %d\n", TOF_IsPresent());
 
  return 0;
}

int get_fplmn(int argc, char **argv)
{
  int nRet;
  uint8 fplmn[12] = {0,};

  nRet = TOF_ReadFPLMN(fplmn);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("SUCCESS\n");
  }
  else
  {
    printf("FAILED Return %d\n",nRet);
  }

  return 0;
}

int set_fplmn(int argc, char **argv)
  {
  int nRet;
  char fplmn[24] = {0.};
  char param[12] = {0,};
  int i =0;

  if(argc < 1)
  {
    printf("Input SET_FPLMN [FPLMN]\n");
    printf("Try again...\n");
  }
  else
  {
    
    strcpy(fplmn, argv[1]);

    printf("set_fplmn %s\n", fplmn);

    for(i=0;i<12;i++)
    {
      param[i] = Hex2Char(&fplmn[i*2]) <<4;
      param[i] += Hex2Char(&fplmn[(i*2)+1]);
    }

    printf("%02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X\n", 
    fplmn[0], fplmn[1], fplmn[2], fplmn[3], fplmn[4], fplmn[5],
    fplmn[6], fplmn[7], fplmn[8], fplmn[9], fplmn[10], fplmn[11]);
    
    printf("%02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X\n", 
    param[0], param[1], param[2], param[3], param[4], param[5],
    param[6], param[7], param[8], param[9], param[10], param[11]);
        
    nRet = TOF_WriteFPLMN(param);
    
    if(nRet == TOF_SUCCESS)
    {
      printf("SUCCESS\n");
    }
    else
    {
      printf("FAILED Return %d\n",nRet);
    }
  }

  return 0;
}

int get_imsi_long(int argc, char **argv)
{
  int nRet;
  uint64 imsi = 0;
  
  nRet = TOF_getIMSI(&imsi);
  if(nRet == TOF_SUCCESS)
  {
    printf("IMSI : %llu\n", imsi);
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int get_msin_long(int argc, char **argv)
{
  int nRet;
  uint64 msin = 0;
  
  nRet = TOF_getMSIN(&msin);
  if(nRet == TOF_SUCCESS)
  {
    printf("MSIN : %llu\n", msin);
  }
  else
  {
    printf("FAILED\n");
  }

  return 0;
}

int get_mcc(int argc, char **argv)
{
  printf("get_mcc : %d\n", TOF_getMCC());
  return 0;
}

int get_mnc(int argc, char **argv)
{
  printf("get_mnc : %d\n", TOF_getMNC());
  return 0;
}

int get_msin_string
(int argc, char **argv)
{
  int nRet;
  uint8 msin[10] = {0,};

  nRet = TOF_getMSINString(msin);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("SUCCESS %s\n", msin);
  }
  else
  {
    printf("FAILED Return %d\n",nRet);
  }

  return 0;
}

int get_mcc_string(int argc, char **argv)
{
  int nRet;
  uint8 mcc[10] = {0,};

  nRet = TOF_getMCCString(mcc);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("SUCCESS %s\n", mcc);
  }
  else
  {
    printf("FAILED Return %d\n",nRet);
  }

  return 0;
}

int get_mnc_string(int argc, char **argv)
{
  int nRet;
  uint8 mnc[10] = {0,};

  nRet = TOF_getMNCString(mnc);
  
  if(nRet == TOF_SUCCESS)
  {
    printf("SUCCESS %s\n", mnc);
  }
  else
  {
    printf("FAILED Return %d\n",nRet);
  }

  return 0;
}

int set_sim_event(int argc, char **argv)
{
  int nRet;

  nRet = TOF_setFieldsChangedEvent();
  
  if(nRet == TOF_SUCCESS)
  {
    printf("SUCCESS \n");
  }
  else
  {
    printf("FAILED Return %d\n",nRet);
  }

  return 0;
}

int Get_TOF_version(int argc, char **argv)
{
  int nRet = 0;
	char ver_string[20]={NULL,};
  
  nRet = TOF_API_version(ver_string);

	if(TOF_SUCCESS == nRet)
	{
		printf("version: %s\n", ver_string);
	}else
	{
		printf("Fail to get version\n");
	}
 
  
  return nRet;

}

int TOF_TELE_change_usb_composition(int argc, char **argv)
{
	int nRet;

	if (argc != 2)
	{
		printf("argc != 2\n");
		return TOF_FAIL;
	}

	nRet = TOF_change_usb_composition(argv[1]);

	printf("result = %d\n", nRet);

	return nRet;
}

int TOF_TELE_get_enabled_usb_composition(int argc, char **argv)
{
	int nRet;

	nRet = TOF_get_enabled_usb_composition();

	printf("result = %x\n", nRet);

	return nRet;
}

int TOF_TELE_disable_usb_composition(int argc, char **argv)
{
    int nRet;

    nRet = TOF_disable_usb_composition();

    printf("result = %x\n", nRet);

    return nRet;
}

int TOF_TELE_get_usb_mode(int argc, char **argv)
{
	int nRet;

	char usb_mode[15] = {0,};

	nRet = TOF_get_usb_mode(usb_mode);

	printf("TOF_TELE_get_usb_mode nRet = %d, usb_mode = %s\n", nRet, usb_mode);

	return nRet;
}

int TOF_TELE_change_usb_mode(int argc, char **argv)
{
	int nRet;

	nRet = TOF_change_usb_mode(argv[1]);

	printf("result = %x\n", nRet);

	return nRet;
}

int TOF_TELE_get_usb_storage_state(int argc, char **argv)
{
	int nRet;

	char buf[25] = {0,};

	nRet = TOF_get_usb_storage_state(buf);

	printf("TOF_TELE_get_usb_storage_state nRet = %d state = %s\n", nRet, buf);

	return nRet;
}

int get_thermal_info(int arc, char **argv)
{
  int nRet = 0;

  tof_thermal_info var;
  tof_thermal_info* pVar = &var;
  

  printf("DEBUG\n");
  nRet = TOF_request_get_thermal_management_info(pVar);

  if(nRet) { 
    printf("Fail to get thermal_info\n"); 
  }

  printf("info,Temp:%d, Action:%d, Threshold %d ~ %d\n",var.cur_temperature,
      var.cur_action_lvl, var.thresh_trig, var.thresh_clr);
  printf("End\n");

  return 0;
}

int set_clock_config(int argc, char **argv)
{
  int nRet;
  boolean nitzEnable, gnssEnable, ntpEnable;
  char* ntpServerUrl = NULL;

  nRet = TOF_FAIL;

  if(argc < 5)
  {
    printf("    SET_CLKCONFIG [nitzEnable] [gnssEnable] [ntpEnable] [ntpServerUrl]\n");
    printf("    [nitzEnable]: 0(disable) or 1(enable) \n");
    printf("    [gnssEnable]: 0(disable) or 1(enable) \n");
    printf("    [ntpEnable] : 0(disable) or 1(enable) \n");
    printf("    [ntpServerUrl] : ntp server url \n");
    printf("EX) SET_CLKCONFIG 0 0 1 cn.pool.ntp.org \n");  
  }
  else
  {
    nitzEnable = (boolean)atoi(argv[1]);
    gnssEnable = (boolean)atoi(argv[2]);
    ntpEnable = (boolean)atoi(argv[3]);
    ntpServerUrl  = (char*)(argv[4]);

    nRet = TOF_setClockConfig(nitzEnable, gnssEnable, ntpEnable,ntpServerUrl);
    if(nRet == TOF_SUCCESS)
    {
      printf("SUCCESS\n");
    }
    else
    {
      printf("FAILED\n");
    }	 
  }
  return nRet;
}

int get_current_clock(int argc, char **argv)
{
  int nRet;
  int clk_source = 0;
  
  nRet = TOF_FAIL;
  
  nRet = TOF_getCurrentClock(&clk_source);
  if(nRet == TOF_SUCCESS)
  {
    printf("SUCCESS, source = %d\n",clk_source);
  }
  else
  {
    printf("FAILED\n");
  }	
  return nRet;
}

int set_ring_low(int argc, char **argv)
{
  TOF_setRingIndicatorLow();
  return TOF_SUCCESS;
}

int set_reboot(int argc, char **argv)
{
  int nRet;
  char* reboot_reason = NULL;

  nRet = TOF_FAIL;
  if(argc < 2)
  {
    printf("    SET_REBOOT [reason]\n");
    printf("EX) SET_REBOOT user_reboot \n");
  }
  else
  {
    reboot_reason  = (char*)(argv[1]);
    nRet = TOF_set_reboot(reboot_reason);
  }
  return nRet;
}

int get_reboot(int argc, char **argv)
{
  int nRet;
  char buf[50] = {0,};

  nRet = TOF_FAIL;
  nRet = TOF_get_reboot(buf);
  if(nRet == TOF_SUCCESS)
  {
    printf("SUCCESS, reboot reason = %s\n",buf);
  }
  else
  {
    printf("FAILED\n");
  }
  return nRet;
}
